import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../screens/about_screen.dart';
import '../screens/developer_screen.dart';
import '../screens/community_screen.dart';
import '../screens/credits_screen.dart';
import '../screens/how_it_works_screen.dart';
import '../screens/privacy_policy_screen.dart';
import '../screens/report_bug_screen.dart';
import '../screens/theme_screen.dart';
import '../utils/theme_provider.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    final t = ThemeProvider().current;
    return Drawer(
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [t.drawerBg1, t.drawerBg2],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Column(
          children: [
            _DrawerHeader(),
            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  const SizedBox(height: 8),
                  _DrawerItem(
                    icon: Icons.palette_rounded,
                    label: 'Themes',
                    highlight: true,
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const ThemeScreen()));
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.menu_book_rounded,
                    label: 'How It Works',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const HowItWorksScreen()));
                    },
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
                    child: Divider(color: t.dividerColor, thickness: 1),
                  ),
                  _DrawerItem(
                    icon: Icons.info_outline_rounded,
                    label: 'About',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const AboutScreen()));
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.person_outline_rounded,
                    label: 'Developer',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const DeveloperScreen()));
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.star_rounded,
                    label: 'Credits',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const CreditsScreen()));
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.shield_outlined,
                    label: 'Privacy Policy',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const PrivacyPolicyScreen()));
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.bug_report_outlined,
                    label: 'Report a Bug',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const ReportBugScreen()));
                    },
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                    child: Divider(color: t.dividerColor, thickness: 1),
                  ),
                  _DrawerItem(
                    icon: Icons.groups_rounded,
                    label: 'Join Our Community',
                    accent: true,
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const CommunityScreen()));
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DrawerHeader extends StatefulWidget {
  @override
  State<_DrawerHeader> createState() => _DrawerHeaderState();
}

class _DrawerHeaderState extends State<_DrawerHeader>
    with TickerProviderStateMixin {
  late final AnimationController _pulseCtrl;
  late final AnimationController _orbitCtrl;
  late final AnimationController _scanCtrl;

  late final Animation<double> _pulseAnim;
  late final Animation<double> _scanAnim;

  @override
  void initState() {
    super.initState();

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _orbitCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 5000),
    )..repeat();

    _scanCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..repeat();

    _pulseAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );

    _scanAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _scanCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _orbitCtrl.dispose();
    _scanCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final t = ThemeProvider().current;
    return Container(
      width: double.infinity,
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 24,
        bottom: 24,
        left: 20,
        right: 20,
      ),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [t.headerBg1, t.headerBg2],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        border: Border(
          bottom: BorderSide(color: t.primary.withOpacity(0.3)),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          AnimatedBuilder(
            animation: Listenable.merge([_pulseAnim, _orbitCtrl, _scanAnim]),
            builder: (context, _) {
              final pulse   = _pulseAnim.value;
              final orbit   = _orbitCtrl.value;
              final scan    = _scanAnim.value;

              final glowOpacity = 0.30 + pulse * 0.25;
              final outerGlow   = 0.12 + pulse * 0.10;

              final scanOpacity = scan < 0.5
                  ? (scan * 2).clamp(0.0, 1.0)
                  : ((1.0 - scan) * 2).clamp(0.0, 1.0);
              final scanY = scan * 64.0;

              return SizedBox(
                width: 96,
                height: 96,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Container(
                      width: 92 + pulse * 6,
                      height: 92 + pulse * 6,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: t.primary.withOpacity(outerGlow),
                          width: 1,
                        ),
                      ),
                    ),
                    Transform.rotate(
                      angle: orbit * 2 * math.pi,
                      child: CustomPaint(
                        size: const Size(84, 84),
                        painter: _DrawerOrbitPainter(
                          color: Color.lerp(t.primary, t.highlightColor, pulse)!,
                          opacity: 0.55 + pulse * 0.25,
                        ),
                      ),
                    ),
                    Transform.rotate(
                      angle: -orbit * 2 * math.pi * 0.6,
                      child: CustomPaint(
                        size: const Size(72, 72),
                        painter: _DrawerDotOrbitPainter(
                          color: t.secondary,
                          opacity: 0.40 + pulse * 0.20,
                        ),
                      ),
                    ),
                    Transform.scale(
                      scale: 1.0 + pulse * 0.04,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: Stack(
                          children: [
                            Container(
                              width: 64,
                              height: 64,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Color.lerp(t.primary, t.secondary, pulse)!,
                                    Color.lerp(t.primary, t.headerBg1, 0.5)!,
                                  ],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: t.primary.withOpacity(glowOpacity),
                                    blurRadius: 20,
                                    spreadRadius: 2,
                                  ),
                                ],
                              ),
                              child: Icon(
                                Icons.memory_rounded,
                                color: t.textColor,
                                size: 32,
                              ),
                            ),
                            Positioned(
                              top: scanY - 2,
                              left: 0,
                              right: 0,
                              child: Opacity(
                                opacity: scanOpacity * 0.65,
                                child: Container(
                                  height: 2,
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [
                                        Colors.transparent,
                                        t.highlightColor,
                                        Colors.transparent,
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
          const SizedBox(height: 12),
          Text(
            'TAURUS SHIELD',
            style: TextStyle(
              color: t.textColor,
              fontSize: 20,
              fontWeight: FontWeight.w900,
              letterSpacing: 3,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Taurus Shield v1.0',
            style: TextStyle(color: t.subtextColor, fontSize: 12),
          ),
        ],
      ),
    );
  }
}

class _DrawerOrbitPainter extends CustomPainter {
  final Color color;
  final double opacity;
  const _DrawerOrbitPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r  = (size.width / 2) - 2;

    final paint = Paint()
      ..color = color.withOpacity(opacity)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round;

    const gapRad = math.pi / 3;
    const arcRad = math.pi / 3;
    for (int i = 0; i < 3; i++) {
      final start = i * (arcRad + gapRad);
      canvas.drawArc(
        Rect.fromCircle(center: Offset(cx, cy), radius: r),
        start,
        arcRad,
        false,
        paint,
      );
    }

    final dotPaint = Paint()
      ..color = color.withOpacity(opacity * 0.9)
      ..style = PaintingStyle.fill;

    for (int i = 0; i < 3; i++) {
      final angle = i * (arcRad + gapRad) + arcRad / 2;
      canvas.drawCircle(
        Offset(cx + r * math.cos(angle), cy + r * math.sin(angle)),
        2.4,
        dotPaint,
      );
    }
  }

  @override
  bool shouldRepaint(_DrawerOrbitPainter old) =>
      old.color != color || old.opacity != opacity;
}

class _DrawerDotOrbitPainter extends CustomPainter {
  final Color color;
  final double opacity;
  const _DrawerDotOrbitPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r  = (size.width / 2) - 1;

    for (int i = 0; i < 6; i++) {
      final angle  = i * (math.pi / 3);
      final radius = i % 2 == 0 ? 2.0 : 1.2;
      canvas.drawCircle(
        Offset(cx + r * math.cos(angle), cy + r * math.sin(angle)),
        radius,
        Paint()
          ..color = color.withOpacity(opacity * (i % 2 == 0 ? 1.0 : 0.5))
          ..style = PaintingStyle.fill,
      );
    }
  }

  @override
  bool shouldRepaint(_DrawerDotOrbitPainter old) =>
      old.color != color || old.opacity != opacity;
}

class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool accent;
  final bool highlight;

  const _DrawerItem({
    required this.icon,
    required this.label,
    required this.onTap,
    this.accent = false,
    this.highlight = false,
  });

  @override
  Widget build(BuildContext context) {
    final t = ThemeProvider().current;
    final Color color = accent
        ? t.secondary
        : highlight
            ? Colors.white
            : t.textColor;

    BoxDecoration? deco;
    if (accent) {
      deco = BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        gradient: LinearGradient(
          colors: [t.borderColor, t.headerBg1],
        ),
        border: Border.all(color: t.primary.withOpacity(0.4)),
      );
    } else if (highlight) {
      deco = BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: Colors.white.withOpacity(0.06),
        border: Border.all(color: Colors.white.withOpacity(0.15)),
      );
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: deco,
            child: Row(
              children: [
                Icon(icon, color: color, size: 22),
                const SizedBox(width: 14),
                Text(
                  label,
                  style: TextStyle(
                    color: color,
                    fontSize: 15,
                    fontWeight: (accent || highlight)
                        ? FontWeight.w700
                        : FontWeight.w500,
                  ),
                ),
                if (accent || highlight) ...[
                  const Spacer(),
                  Icon(Icons.arrow_forward_ios_rounded, color: color, size: 14),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
