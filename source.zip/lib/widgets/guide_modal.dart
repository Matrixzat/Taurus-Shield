import '../utils/theme_provider.dart';
import 'package:flutter/material.dart';

void showGuideModal(BuildContext context, {int initialIndex = 0, bool singleTool = false}) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => _GuideSheet(initialIndex: initialIndex, singleTool: singleTool),
  );
}

// ── Outer sheet — HBC Tool | Blutter | Dex2C ──────────────────────────────────

class _GuideSheet extends StatefulWidget {
  final int initialIndex;
  final bool singleTool;
  const _GuideSheet({this.initialIndex = 0, this.singleTool = false});
  @override
  State<_GuideSheet> createState() => _GuideSheetState();
}

class _GuideSheetState extends State<_GuideSheet>
    with SingleTickerProviderStateMixin {
  late TabController _outerTab;

  @override
  void initState() {
    super.initState();
    _outerTab = TabController(length: 11, vsync: this, initialIndex: widget.initialIndex);
    _outerTab.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _outerTab.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).padding.bottom;
    return Container(
      height: MediaQuery.of(context).size.height * 0.88,
      decoration: BoxDecoration(
        color: ThemeProvider().current.appBarBg,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        border: Border(
          top: BorderSide(color: ThemeProvider().current.primary, width: 1.5),
        ),
      ),
      child: Column(
        children: [
          // ── Drag handle
          Container(
            margin: const EdgeInsets.only(top: 12, bottom: 4),
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: const Color(0xFF4b3a6e),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          // ── Header
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
            child: Row(
              children: [
                Container(
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: ThemeProvider().current.primary.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                        color: ThemeProvider().current.primary.withOpacity(0.4)),
                  ),
                  child: Icon(Icons.menu_book_rounded,
                      color: ThemeProvider().current.secondary, size: 20),
                ),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'HOW TO USE',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2,
                      ),
                    ),
                    Text(
                      widget.singleTool
                          ? const [
                              'HBC Tool', 'Spoofer', 'Blutter', 'Dex2C',
                              'DPT Shell', 'APK Tool', 'Ads Patch',
                              'Matrix Killer', 'Black Forge', 'Mod Engine',
                            ][widget.initialIndex]
                          : 'Step-by-step guide',
                      style: const TextStyle(
                          color: Color(0xFF6b7280), fontSize: 11),
                    ),
                  ],
                ),
                const Spacer(),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    padding: EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: ThemeProvider().current.surfaceColor,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(Icons.close_rounded,
                        color: Color(0xFF6b7280), size: 18),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          // ── Outer tool tabs (wrapped, 2 rows) — hidden in single-tool mode
          if (!widget.singleTool)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: AnimatedBuilder(
                animation: _outerTab,
                builder: (_, __) => Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        _GuideTab(index: 0, label: 'HBC Tool',      icon: Icons.terminal_rounded,                color: ThemeProvider().current.primary, controller: _outerTab),
                        _GuideTab(index: 1, label: 'Spoofer',        icon: Icons.perm_device_information_rounded, color: const Color(0xFF0891b2), controller: _outerTab),
                        _GuideTab(index: 2, label: 'Blutter',        icon: Icons.biotech_rounded,                 color: const Color(0xFF0e7490), controller: _outerTab),
                        _GuideTab(index: 3, label: 'Dex2C',          icon: Icons.enhanced_encryption_rounded,     color: const Color(0xFF059669), controller: _outerTab),
                        _GuideTab(index: 4, label: 'DPT Shell',      icon: Icons.security_rounded,                color: const Color(0xFFea580c), controller: _outerTab),
                        _GuideTab(index: 5, label: 'APK Tool',       icon: Icons.android_rounded,                 color: const Color(0xFF1d4ed8), controller: _outerTab),
                        _GuideTab(index: 6, label: 'Ads Patch',      icon: Icons.block_rounded,                   color: const Color(0xFFef4444), controller: _outerTab),
                        _GuideTab(index: 7, label: 'Matrix Killer',  icon: Icons.shield_rounded,                  color: const Color(0xFF8B5CF6), controller: _outerTab),
                        _GuideTab(index: 8, label: 'Black Forge',    icon: Icons.local_fire_department_rounded,   color: const Color(0xFFFF6B35), controller: _outerTab),
                        _GuideTab(index: 9,  label: 'Il2Cpp + Mod',  icon: Icons.terminal_rounded,   color: const Color(0xFF8B5CF6), controller: _outerTab),
                        _GuideTab(index: 10, label: 'Cocos2d-x',    icon: Icons.gamepad_rounded,    color: const Color(0xFFF97316), controller: _outerTab),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Divider(color: ThemeProvider().current.surfaceColor, height: 1, thickness: 1),
                  ],
                ),
              ),
            ),
          const SizedBox(height: 4),
          // ── Content
          Expanded(
            child: TabBarView(
              controller: _outerTab,
              physics: widget.singleTool
                  ? const NeverScrollableScrollPhysics()
                  : const ScrollPhysics(),
              children: const [
                _HbcTabContent(),
                _SpoofGuide(),
                _BlutterGuide(),
                _Dex2CGuide(),
                _DptShellGuide(),
                _ApkToolGuide(),
                _AdsPatchGuide(),
                _AntiKillerGuide(),
                _BlackForgeGuide(),
                _ModEngineGuide(),
                _CocosGuide(),
              ],
            ),
          ),
          SizedBox(height: bottom + 8),
        ],
      ),
    );
  }
}

// ── HBC Tool tab — contains inner Disassemble / Assemble tabs ──────────────────

class _HbcTabContent extends StatefulWidget {
  const _HbcTabContent();
  @override
  State<_HbcTabContent> createState() => _HbcTabContentState();
}

class _HbcTabContentState extends State<_HbcTabContent>
    with SingleTickerProviderStateMixin {
  late TabController _tab;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
    _tab.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SizedBox(height: 12),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Container(
            decoration: BoxDecoration(
              color: Color(0xFF0a0a18),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: ThemeProvider().current.surfaceColor),
            ),
            child: TabBar(
              controller: _tab,
              indicator: BoxDecoration(
                gradient: LinearGradient(
                  colors: [ThemeProvider().current.primary, Color(0xFF4f1fa0)],
                ),
                borderRadius: BorderRadius.circular(10),
              ),
              indicatorSize: TabBarIndicatorSize.tab,
              dividerColor: Colors.transparent,
              labelColor: Colors.white,
              unselectedLabelColor: const Color(0xFF6b7280),
              labelStyle: const TextStyle(
                  fontWeight: FontWeight.w700, fontSize: 13),
              unselectedLabelStyle: const TextStyle(
                  fontWeight: FontWeight.w500, fontSize: 13),
              tabs: const [
                Tab(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.code_rounded, size: 15),
                      SizedBox(width: 6),
                      Text('Disassemble'),
                    ],
                  ),
                ),
                Tab(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.build_rounded, size: 15),
                      SizedBox(width: 6),
                      Text('Assemble'),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 4),
        Expanded(
          child: TabBarView(
            controller: _tab,
            children: [
              _StepList(steps: _dsmSteps),
              _StepList(steps: _asmSteps),
            ],
          ),
        ),
      ],
    );
  }
}

// ── Blutter guide tab — tabbed: Analyze / Dump Folder / String Patch / Int Patch / ASM Editor ──

class _BlutterGuide extends StatefulWidget {
  const _BlutterGuide();
  @override
  State<_BlutterGuide> createState() => _BlutterGuideState();
}

class _BlutterGuideState extends State<_BlutterGuide>
    with SingleTickerProviderStateMixin {
  late TabController _tab;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 5, vsync: this);
    _tab.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SizedBox(height: 12),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Container(
            decoration: BoxDecoration(
              color: Color(0xFF0a0a18),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: ThemeProvider().current.surfaceColor),
            ),
            child: TabBar(
              controller: _tab,
              isScrollable: true,
              tabAlignment: TabAlignment.start,
              indicator: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF0891b2), Color(0xFF0e7490)],
                ),
                borderRadius: BorderRadius.circular(10),
              ),
              indicatorSize: TabBarIndicatorSize.tab,
              dividerColor: Colors.transparent,
              labelColor: Colors.white,
              unselectedLabelColor: const Color(0xFF6b7280),
              labelStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
              unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w500, fontSize: 12),
              tabs: const [
                Tab(child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.biotech_rounded, size: 14), SizedBox(width: 5), Text('Analyze')])),
                Tab(child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.folder_open_rounded, size: 14), SizedBox(width: 5), Text('Dump Folder')])),
                Tab(child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.text_fields_rounded, size: 14), SizedBox(width: 5), Text('String Patch')])),
                Tab(child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.tag_rounded, size: 14), SizedBox(width: 5), Text('Int Patch')])),
                Tab(child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.code_rounded, size: 14), SizedBox(width: 5), Text('ASM Editor')])),
              ],
            ),
          ),
        ),
        const SizedBox(height: 4),
        Expanded(
          child: TabBarView(
            controller: _tab,
            children: [
              _BlutterStepList(steps: _blutterSteps),
              _BlutterStepList(steps: _blutterDumpFolderSteps),
              _BlutterStepList(steps: _blutterStringPatchSteps),
              _BlutterStepList(steps: _blutterIntPatchSteps),
              _BlutterStepList(steps: _blutterAsmEditorSteps),
            ],
          ),
        ),
      ],
    );
  }
}

class _BlutterStepList extends StatelessWidget {
  final List<_Step> steps;
  const _BlutterStepList({required this.steps});

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: EdgeInsets.fromLTRB(20, 16, 20, 24),
      itemCount: steps.length + 1,
      separatorBuilder: (_, i) => i < steps.length - 1
          ? _StepConnector(color: ThemeProvider().current.highlightColor)
          : const SizedBox(height: 20),
      itemBuilder: (_, i) {
        if (i < steps.length) return _StepCard(step: steps[i], index: i);
        return _BlutterOutputNote();
      },
    );
  }
}

class _BlutterOutputNote extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Color(0xFF0a161e),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: ThemeProvider().current.highlightColor.withOpacity(0.3)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: ThemeProvider().current.highlightColor.withOpacity(0.12),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(Icons.folder_open_rounded,
                color: ThemeProvider().current.highlightColor, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Where to find your output',
                  style: TextStyle(
                    color: ThemeProvider().current.highlightColor,
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Open any file manager and navigate to:',
                  style: TextStyle(
                      color: Color(0xFF6b7280), fontSize: 11.5),
                ),
                SizedBox(height: 6),
                Text(
                  'Internal Storage → Taurus-Shield → output → blutter',
                  style: TextStyle(
                    color: Color(0xFF67e8f9),
                    fontSize: 11,
                    fontFamily: 'monospace',
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ── Dex2C guide tab ────────────────────────────────────────────────────────────

class _Dex2CGuide extends StatelessWidget {
  const _Dex2CGuide();

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
      itemCount: _dex2cSteps.length + 1,
      separatorBuilder: (_, i) => i < _dex2cSteps.length - 1
          ? _StepConnector(color: const Color(0xFF10b981))
          : const SizedBox(height: 20),
      itemBuilder: (_, i) {
        if (i < _dex2cSteps.length) {
          return _StepCard(step: _dex2cSteps[i], index: i);
        }
        return _Dex2COutputNote();
      },
    );
  }
}

class _Dex2COutputNote extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF091a12),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: const Color(0xFF10b981).withOpacity(0.3)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: const Color(0xFF10b981).withOpacity(0.12),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(Icons.folder_open_rounded,
                color: Color(0xFF10b981), size: 18),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Where to find your protected APK',
                  style: TextStyle(
                    color: Color(0xFF10b981),
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Open any file manager and navigate to:',
                  style: TextStyle(
                      color: Color(0xFF6b7280), fontSize: 11.5),
                ),
                SizedBox(height: 6),
                Text(
                  'Internal Storage → Taurus-Shield → output → dex2c',
                  style: TextStyle(
                    color: Color(0xFF34d399),
                    fontSize: 11,
                    fontFamily: 'monospace',
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ── Shared widgets ─────────────────────────────────────────────────────────────

class _StepList extends StatelessWidget {
  final List<_Step> steps;
  const _StepList({required this.steps});

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: EdgeInsets.fromLTRB(20, 16, 20, 24),
      itemCount: steps.length + 1,
      separatorBuilder: (_, i) => i < steps.length - 1
          ? _StepConnector(color: ThemeProvider().current.primary)
          : const SizedBox(height: 20),
      itemBuilder: (_, i) {
        if (i < steps.length) return _StepCard(step: steps[i], index: i);
        return _OutputNote();
      },
    );
  }
}

class _StepConnector extends StatelessWidget {
  final Color color;
  const _StepConnector({required this.color});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 22),
      child: Container(
        width: 2,
        height: 18,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              color.withOpacity(0.5),
              color.withOpacity(0.15),
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
      ),
    );
  }
}

class _StepCard extends StatelessWidget {
  final _Step step;
  final int index;
  const _StepCard({required this.step, required this.index});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0f0f22),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: step.color.withOpacity(0.25)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: step.color.withOpacity(0.15),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: step.color.withOpacity(0.5)),
            ),
            child: Center(
              child: Text(
                '${index + 1}',
                style: TextStyle(
                  color: step.color,
                  fontWeight: FontWeight.w900,
                  fontSize: 13,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(step.icon, color: step.color, size: 15),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        step.title,
                        style: TextStyle(
                          color: step.color,
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                          letterSpacing: 0.3,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 5),
                Text(
                  step.body,
                  style: const TextStyle(
                    color: Color(0xFFa0aec0),
                    fontSize: 12,
                    height: 1.6,
                  ),
                ),
                if (step.tag != null) ...[
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: step.color.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(
                          color: step.color.withOpacity(0.3)),
                    ),
                    child: Text(
                      step.tag!,
                      style: TextStyle(
                        color: step.color,
                        fontSize: 10.5,
                        fontFamily: 'monospace',
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _OutputNote extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0a160a),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: const Color(0xFF22c55e).withOpacity(0.3)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: const Color(0xFF22c55e).withOpacity(0.12),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(Icons.folder_open_rounded,
                color: Color(0xFF22c55e), size: 18),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Where to find your output',
                  style: TextStyle(
                    color: Color(0xFF22c55e),
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Open any file manager app and navigate to:',
                  style: TextStyle(
                      color: Color(0xFF6b7280), fontSize: 11.5),
                ),
                SizedBox(height: 6),
                Text(
                  'Internal Storage → Taurus-Shield → output',
                  style: TextStyle(
                    color: Color(0xFF4ade80),
                    fontSize: 11,
                    fontFamily: 'monospace',
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ── Step data model ────────────────────────────────────────────────────────────

class _Step {
  final IconData icon;
  final String title;
  final String body;
  final Color color;
  final String? tag;
  const _Step({
    required this.icon,
    required this.title,
    required this.body,
    required this.color,
    this.tag,
  });
}

const Color _amber   = Color(0xFFfbbf24);
const Color _green   = Color(0xFF4ade80);
const Color _teal    = Color(0xFF2dd4bf);
const Color _sky     = Color(0xFF38bdf8);
const Color _rose    = Color(0xFFfb7185);
const Color _emerald = Color(0xFF10b981);
const Color _lime    = Color(0xFF86efac);

// ── HBC Tool — Disassemble steps ───────────────────────────────────────────────

final List<_Step> _dsmSteps = [
  _Step(
    icon: Icons.touch_app_rounded,
    title: 'Open the file picker',
    body: 'Tap the file select area in the centre of the home screen.',
    color: ThemeProvider().current.secondary,
  ),
  _Step(
    icon: Icons.insert_drive_file_rounded,
    title: 'Pick your bytecode file',
    body: 'Choose a .bundle or .hbc file. You can also select a .zip that contains a .bundle or .hbc inside — it will be extracted automatically.',
    color: ThemeProvider().current.highlightColor,
    tag: 'Accepted: .bundle  .hbc  .zip (containing bundle)',
  ),
  _Step(
    icon: Icons.auto_awesome_rounded,
    title: 'Mode auto-detects as DSM',
    body: 'The pill badge below the file name will show "DSM". If it shows something else, the file may not be a valid Hermes bytecode.',
    color: _amber,
  ),
  _Step(
    icon: Icons.play_arrow_rounded,
    title: 'Tap "Disassemble (DSM)"',
    body: 'Press the large purple button. A progress log appears showing each step of the disassembly.',
    color: ThemeProvider().current.secondary,
  ),
  _Step(
    icon: Icons.check_circle_rounded,
    title: 'Done — check your output',
    body: 'A confirmation toast appears when finished. Your .hasm files are saved to the output folder shown below.',
    color: _green,
  ),
];

// ── HBC Tool — Assemble steps ──────────────────────────────────────────────────

final List<_Step> _asmSteps = [
  _Step(
    icon: Icons.touch_app_rounded,
    title: 'Open the file picker',
    body: 'Tap the file select area in the centre of the home screen.',
    color: ThemeProvider().current.secondary,
  ),
  _Step(
    icon: Icons.folder_zip_rounded,
    title: 'Pick your hasm file or zip',
    body: 'Choose a .hasm file directly, or a .zip folder that contains .hasm + metadata.json inside. The folder inside the zip can have any name.',
    color: ThemeProvider().current.highlightColor,
    tag: 'Accepted: .hasm  .zip (containing .hasm + metadata.json)',
  ),
  _Step(
    icon: Icons.auto_awesome_rounded,
    title: 'Mode auto-detects as ASM',
    body: 'The pill badge will show "ASM". If you picked a zip, it is scanned internally to confirm it contains hasm assembly files.',
    color: _amber,
  ),
  _Step(
    icon: Icons.play_arrow_rounded,
    title: 'Tap "Assemble (ASM)"',
    body: 'Press the large purple button. The assembler reads the hasm files and rebuilds the Hermes bytecode.',
    color: ThemeProvider().current.secondary,
  ),
  _Step(
    icon: Icons.check_circle_rounded,
    title: 'Done — check your output',
    body: 'A confirmation toast appears when finished. Your rebuilt .hbc file is saved to the output folder shown below.',
    color: _green,
  ),
];

// ── Blutter — step-by-step guide ──────────────────────────────────────────────

final List<_Step> _blutterSteps = [
  _Step(
    icon: Icons.folder_zip_rounded,
    title: 'Get the arm64-v8a folder',
    body: 'Rename your target Flutter APK to .zip and extract it. Inside you will find a lib/arm64-v8a/ folder. That folder contains the two files you need.',
    color: _amber,
    tag: 'lib/arm64-v8a/  →  libapp.so  +  libflutter.so',
  ),
  _Step(
    icon: Icons.archive_rounded,
    title: 'Create a ZIP archive',
    body: 'Select both libapp.so and libflutter.so (or the entire arm64-v8a folder) and compress them into a single .zip file. Name it anything you like — e.g. arm64-v8a.zip.',
    color: _sky,
    tag: 'Required inside ZIP: libapp.so  +  libflutter.so',
  ),
  _Step(
    icon: Icons.touch_app_rounded,
    title: 'Open Blutter from the tool picker',
    body: 'From the main screen tap "Blutter — Flutter RE" to open the Blutter analyser.',
    color: ThemeProvider().current.highlightColor,
  ),
  _Step(
    icon: Icons.upload_file_rounded,
    title: 'Select your ZIP file',
    body: 'Tap the file selector area and pick the arm64-v8a.zip you just created. Only .zip files are accepted here.',
    color: _teal,
    tag: 'Accepted: .zip  (must contain libapp.so)',
  ),
  _Step(
    icon: Icons.manage_search_rounded,
    title: 'Dart version auto-detected',
    body: 'The app reads libflutter.so inside the ZIP to find the Dart VM version. This works even on fully stripped release builds where libapp.so has no version string.',
    color: ThemeProvider().current.highlightColor,
  ),
  _Step(
    icon: Icons.tag_rounded,
    title: 'Version not found? Use "Set Ver"',
    body: 'If auto-detection still fails (very rare), tap the "Set Ver" button next to Analyse. Enter the Dart version in X.Y.Z format — you can find it in the Flutter build logs or pubspec.lock of the original project.',
    color: _rose,
    tag: 'Example: 3.4.0  or  3.10.6',
  ),
  _Step(
    icon: Icons.play_arrow_rounded,
    title: 'Tap "Analyse (Blutter)"',
    body: 'Press the cyan button. If this is the first time for this Dart version, the matching blutter engine (~30–50 MB) is downloaded automatically. Internet is required for this step only.',
    color: ThemeProvider().current.highlightColor,
  ),
  _Step(
    icon: Icons.terminal_rounded,
    title: 'Watch the live log',
    body: 'The output console streams blutter\'s progress in real time. Use the auto-scroll toggle to follow the log or scroll freely. Copy the full log with the copy button.',
    color: _teal,
  ),
  _Step(
    icon: Icons.check_circle_rounded,
    title: 'Analysis complete',
    body: 'A toast confirms success. Your Dart symbols, class dumps, and disassembly are saved to the output folder shown below. Re-running with the same Dart version is instant — no re-download needed.',
    color: _green,
  ),
];

// ── Blutter — Dump Folder steps ───────────────────────────────────────────────

final List<_Step> _blutterDumpFolderSteps = [
  _Step(
    icon: Icons.touch_app_rounded,
    title: 'Open Blutter from the tool picker',
    body: 'From the main screen tap "Blutter — Flutter RE" to open the analyser. You will land on the welcome screen with the file selector.',
    color: ThemeProvider().current.highlightColor,
  ),
  _Step(
    icon: Icons.folder_open_rounded,
    title: 'Tap "Already have a dump folder? Select it →"',
    body: 'At the bottom of the welcome screen you will see the secondary option. Tap it to open a folder picker instead of the file picker.',
    color: _teal,
  ),
  _Step(
    icon: Icons.drive_folder_upload_rounded,
    title: 'Navigate to your existing dump folder',
    body: 'Browse to the folder that contains your previous Blutter output — it should have an asm/ directory, pp.dart, and dump.dart inside it. Select that folder.',
    color: ThemeProvider().current.highlightColor,
    tag: 'Folder must contain: asm/  pp.dart  dump.dart',
  ),
  _Step(
    icon: Icons.bolt_rounded,
    title: 'App skips cloud analysis',
    body: 'Because the dump already exists, no upload or cloud job is triggered. The app loads the output folder instantly and opens straight into the PATCHER tab.',
    color: _sky,
  ),
  _Step(
    icon: Icons.check_circle_rounded,
    title: 'Ready to patch',
    body: 'Your existing Blutter output is now loaded. You can use String Patcher, Integer Patcher, and ASM Editor exactly as if you had just run a fresh analysis.',
    color: _green,
  ),
];

// ── Blutter — String Patcher steps ────────────────────────────────────────────

final List<_Step> _blutterStringPatchSteps = [
  _Step(
    icon: Icons.biotech_rounded,
    title: 'Run analysis first (or load a dump folder)',
    body: 'String Patcher works on the Blutter output. Either run a fresh Analyse, or load an existing dump folder using the "Already have a dump folder?" option.',
    color: ThemeProvider().current.highlightColor,
  ),
  _Step(
    icon: Icons.expand_more_rounded,
    title: 'Scroll down in the PATCHER tab and tap "STRING PATCHER"',
    body: 'After analysis completes the PATCHER tab is active. Scroll down past the keyword scan section and tap the "STRING PATCHER" row to expand the panel.',
    color: _teal,
  ),
  _Step(
    icon: Icons.search_rounded,
    title: 'Type a keyword and tap SCAN',
    body: 'Enter any word or phrase from the string you want to change (e.g. "Premium", "Upgrade", "pro_user"). Tap SCAN to search across all Dart class files in the dump.',
    color: _sky,
    tag: 'Example keyword:  Premium  or  unlocked',
  ),
  _Step(
    icon: Icons.list_alt_rounded,
    title: 'Browse the results and select a match',
    body: 'Results list the file, method, and the exact original string value. Tap any row to select it — the original string is shown and the replacement field becomes active.',
    color: ThemeProvider().current.highlightColor,
  ),
  _Step(
    icon: Icons.edit_rounded,
    title: 'Type your replacement string',
    body: 'Enter the new string value you want to inject. This replaces the Dart constant in the compiled binary. Leave blank to replace with an empty string.',
    color: _teal,
    tag: 'Tip: keep the same length or shorter for best results',
  ),
  _Step(
    icon: Icons.build_rounded,
    title: 'Tap "APPLY ALL PATCHES"',
    body: 'Press the button at the bottom of the PATCHER tab. The app auto-commits all pending edits, patches libapp.so with the new string values, and saves the output.',
    color: ThemeProvider().current.highlightColor,
  ),
  _Step(
    icon: Icons.check_circle_rounded,
    title: 'Patched libapp.so is ready',
    body: 'A success toast confirms the patch. The modified libapp.so is saved alongside your dump folder. Replace the original in your APK and re-sign to install.',
    color: _green,
    tag: 'Output: <dump_folder>/libapp.so (patched)',
  ),
];

// ── Blutter — Integer Patcher steps ───────────────────────────────────────────

final List<_Step> _blutterIntPatchSteps = [
  _Step(
    icon: Icons.biotech_rounded,
    title: 'Run analysis first (or load a dump folder)',
    body: 'Integer Patcher requires a completed Blutter dump. Either run Analyse or load an existing dump folder using the "Already have a dump folder?" shortcut.',
    color: ThemeProvider().current.highlightColor,
  ),
  _Step(
    icon: Icons.expand_more_rounded,
    title: 'Scroll down in the PATCHER tab and tap "INTEGER PATCHER"',
    body: 'After analysis the PATCHER tab is active. Scroll past the String Patcher section and tap the "INTEGER PATCHER" row to expand the panel.',
    color: _teal,
  ),
  _Step(
    icon: Icons.search_rounded,
    title: 'Enter a keyword and tap SCAN',
    body: 'Type a method or field name associated with the integer you want to change (e.g. "isPremium", "maxLevel", "0x30"). Tap SCAN to search across all disassembly files.',
    color: _sky,
    tag: 'Example:  isPremium  or  0x30  or  maxRetry',
  ),
  _Step(
    icon: Icons.list_alt_rounded,
    title: 'Browse results and select a match',
    body: 'Each result shows the file, method, and the integer constant found (shown in hex and decimal). Tap a result row to select it for editing.',
    color: ThemeProvider().current.highlightColor,
  ),
  _Step(
    icon: Icons.edit_rounded,
    title: 'Enter the new integer value',
    body: 'Type the replacement value in decimal or hex (prefix 0x for hex). For example, to patch isPremium from 0 to 1, enter 1. The app handles the encoding.',
    color: _teal,
    tag: 'Accepts: decimal (1, 99) or hex (0x1, 0x63)',
  ),
  _Step(
    icon: Icons.build_rounded,
    title: 'Tap "APPLY ALL PATCHES"',
    body: 'Press the button at the bottom of the PATCHER tab to apply all pending integer and string patches together. The patched libapp.so is saved automatically.',
    color: ThemeProvider().current.highlightColor,
  ),
  _Step(
    icon: Icons.check_circle_rounded,
    title: 'Patched libapp.so is ready',
    body: 'A success toast confirms the patch. Drop the modified libapp.so back into your APK (replace inside lib/arm64-v8a/), re-sign the APK, and install.',
    color: _green,
    tag: 'Output: <dump_folder>/libapp.so (patched)',
  ),
];

// ── Blutter — ASM Editor steps ─────────────────────────────────────────────────

final List<_Step> _blutterAsmEditorSteps = [
  _Step(
    icon: Icons.biotech_rounded,
    title: 'Run analysis first (or load a dump folder)',
    body: 'The ASM Editor works on the asm/ directory produced by Blutter. Run a fresh Analyse or load an existing dump folder. The ASM EDITOR tab appears after the dump is loaded.',
    color: ThemeProvider().current.highlightColor,
  ),
  _Step(
    icon: Icons.swap_horiz_rounded,
    title: 'Switch to the ASM EDITOR tab',
    body: 'Tap the "ASM EDITOR" chip at the top of the Blutter screen (to the right of PATCHER). The file browser opens showing the Dart class folder tree from your dump.',
    color: _teal,
  ),
  _Step(
    icon: Icons.folder_rounded,
    title: 'Browse the class file tree',
    body: 'Folders represent Dart packages and classes. Tap any folder to navigate into it. Tap the back button to go up one level. Files (*.dart) are the ARM64 disassembly for each method.',
    color: _sky,
  ),
  _Step(
    icon: Icons.manage_search_rounded,
    title: 'Use global search to find instructions',
    body: 'Tap the search icon (top right) to open the global search panel. Type any instruction, register, hex address, or symbol name. Matches across all files are listed with file and line info.',
    color: ThemeProvider().current.highlightColor,
    tag: 'Example:  bl 0x1234  or  cbz x0  or  isPremium',
  ),
  _Step(
    icon: Icons.open_in_full_rounded,
    title: 'Open a file and read the disassembly',
    body: 'Tap any .dart file to open it. ARM64 instructions are syntax-highlighted — addresses in purple, instructions in dark grey, Dart annotations in blue, branch targets in teal. Pinch to zoom or use the font-size buttons.',
    color: _teal,
  ),
  _Step(
    icon: Icons.edit_rounded,
    title: 'Tap a line to edit (inline patch)',
    body: 'Tap any ARM64 instruction line to activate the inline editor. Modify the instruction text directly — e.g. change "cbz x0, #0x8" to "b #0x8" to force a branch. Dart annotation lines are skipped automatically.',
    color: _sky,
    tag: 'Example:  cbz x0, #label  →  b #label  (force branch)',
  ),
  _Step(
    icon: Icons.save_rounded,
    title: 'Commit and apply',
    body: 'Changed lines are highlighted in amber. Tap the tick button on the line to confirm an edit. When ready, tap "APPLY ALL PATCHES" from the PATCHER tab — the ASM editor auto-commits before patching and the modified libapp.so is saved.',
    color: ThemeProvider().current.highlightColor,
  ),
  _Step(
    icon: Icons.check_circle_rounded,
    title: 'Patched libapp.so is ready',
    body: 'The modified binary is saved to your dump folder. Replace the original libapp.so inside your APK\'s lib/arm64-v8a/ directory, re-sign the APK, and install it.',
    color: _green,
    tag: 'Output: <dump_folder>/libapp.so (patched)',
  ),
];

const Color _orange  = Color(0xFFf97316);
const Color _orangeL = Color(0xFFfb923c);

// ── DPT Shell ─────────────────────────────────────────────────────────────────

class _DptShellGuide extends StatelessWidget {
  const _DptShellGuide();

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
      itemCount: _dptShellSteps.length + 1,
      separatorBuilder: (_, i) => i < _dptShellSteps.length - 1
          ? _StepConnector(color: _orange)
          : const SizedBox(height: 20),
      itemBuilder: (_, i) {
        if (i < _dptShellSteps.length) {
          return _StepCard(step: _dptShellSteps[i], index: i);
        }
        return _DptShellOutputNote();
      },
    );
  }
}

class _DptShellOutputNote extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF1a0e00),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _orange.withOpacity(0.3)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: _orange.withOpacity(0.12),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(Icons.folder_open_rounded,
                color: _orange, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Where to find your protected APK',
                  style: TextStyle(
                    color: _orange,
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Open any file manager and navigate to:',
                  style: TextStyle(
                      color: Color(0xFF6b7280), fontSize: 11.5),
                ),
                const SizedBox(height: 6),
                Text(
                  'Internal Storage → Taurus-Shield → output → dptshell',
                  style: TextStyle(
                    color: _orangeL,
                    fontSize: 11,
                    fontFamily: 'monospace',
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

final List<_Step> _dptShellSteps = [
  _Step(
    icon: Icons.info_outline_rounded,
    title: 'What is DPT Shell?',
    body: 'DPT Shell applies DEX hollowing protection to your APK. It extracts each '
        'DEX class\'s bytecode and wraps it inside a native shell layer (.so), '
        'preventing static decompilation and analysis of your code.\n\n'
        'The original DEX files are replaced with hollowed stubs; the real logic '
        'only runs through the native shell at runtime.',
    color: _orange,
    tag: 'Technique: DEX Hollowing',
  ),
  _Step(
    icon: Icons.touch_app_rounded,
    title: 'Open DPT Shell from the tool picker',
    body: 'From the main screen tap "DPT Shell — DEX Hollowing Protection" to open the protection screen.',
    color: _orange,
  ),
  _Step(
    icon: Icons.android_rounded,
    title: 'Select your APK file',
    body: 'Tap the file selector and pick your .apk file directly. '
        'No ZIP packaging is needed — just select the APK and the app handles the rest. '
        'Files up to 100 MB are supported.',
    color: _orangeL,
    tag: 'Accepted: .apk  (Max 100 MB)',
  ),
  _Step(
    icon: Icons.toggle_on_rounded,
    title: 'Choose signing option',
    body: 'Toggle "Sign APK" on to have the protected APK automatically signed with a debug keystore — useful for testing. '
        'Turn it off if you want to sign with your own release key after downloading.',
    color: _orange,
  ),
  _Step(
    icon: Icons.cloud_upload_rounded,
    title: 'Tap "Protect (DPT Shell)"',
    body: 'Press the orange button. Your APK is packaged and uploaded to the cloud, '
        'then the cloud engine runs the DPT-Shell process automatically. '
        'An active internet connection is required.',
    color: _orange,
  ),
  _Step(
    icon: Icons.terminal_rounded,
    title: 'Watch live cloud progress',
    body: 'The log panel streams real-time updates — packaging, upload, extract, install Java, '
        'download DPT Shell, apply DEX hollowing, sign. '
        'The timer shows elapsed time. DPT Shell typically takes 3–10 minutes.',
    color: _orangeL,
    tag: 'Avg: 3–10 min',
  ),
  _Step(
    icon: Icons.check_circle_rounded,
    title: 'Done — protected APK downloaded',
    body: 'A success toast confirms completion. Your shell-protected APK is automatically '
        'downloaded from the cloud and saved to the output folder on your device. '
        'Install it directly to test the protection.',
    color: _green,
  ),
];

// ── Dex2C — step-by-step guide ─────────────────────────────────────────────────

final List<_Step> _dex2cSteps = [
  _Step(
    icon: Icons.edit_note_rounded,
    title: 'Write your filter.txt',
    body: 'Each line is a regex rule in the format  class/path;method_name.\n\n'
        'WHITELIST (protect): lines without ! — matched methods get compiled to native .so.\n'
        'BLACKLIST (exclude): prefix a line with ! — those methods are left as-is.\n\n'
        'To protect the ENTIRE APK just put a single line:  .*\n\n'
        'To target specific classes/methods use the class path and method name separated by a semicolon:\n\n'
        '  .*                                → protect every method in the whole APK\n'
        '  com/example/app/Utils;.*          → protect all methods in Utils\n'
        '  com/example/app/Utils;encrypt\\(.*  → protect only the encrypt method\n'
        '  com/example/secure/.*;.*           → protect every class under a package\n'
        '  .*;onCreate\\(.*                   → protect onCreate in every class\n'
        '  !.*;onCreate\\(.*                  → exclude onCreate everywhere\n'
        '  !com/example/app/MainActivity;.*  → exclude all of MainActivity',
    color: _lime,
    tag: 'Tip: a single line  .*  protects the whole APK  |  ! = exclude',
  ),
  _Step(
    icon: Icons.folder_zip_rounded,
    title: 'Pack your ZIP',
    body: 'Create a ZIP file containing exactly one .apk and the filter.txt you just made. Both files must be at the root of the ZIP — not inside a sub-folder.',
    color: _emerald,
    tag: 'Required inside ZIP: app.apk  +  filter.txt',
  ),
  _Step(
    icon: Icons.touch_app_rounded,
    title: 'Open Dex2C from the tool picker',
    body: 'From the main screen tap "Dex2C — APK Native Protection" to open the protection screen.',
    color: _emerald,
  ),
  _Step(
    icon: Icons.upload_file_rounded,
    title: 'Select your ZIP file',
    body: 'Tap the file selector and choose your prepared ZIP. The app checks it contains exactly one .apk and one filter.txt before letting you proceed.',
    color: _teal,
    tag: 'Accepted: .zip  (must contain .apk + filter.txt)',
  ),
  _Step(
    icon: Icons.toggle_on_rounded,
    title: 'Choose signing option',
    body: 'Toggle "Sign APK" on to have the protected APK automatically signed with a debug keystore — useful for testing. Turn it off if you want to sign it with your own release key later.',
    color: _lime,
  ),
  _Step(
    icon: Icons.cloud_upload_rounded,
    title: 'Tap "Start Cloud Protection"',
    body: 'Press the green button. Your ZIP is uploaded to the cloud and protection starts automatically. An active internet connection is required for this step.',
    color: _emerald,
  ),
  _Step(
    icon: Icons.terminal_rounded,
    title: 'Watch live cloud progress',
    body: 'The log panel streams real-time updates from the cloud — upload, compile, convert DEX to C, sign. The timer shows elapsed time. This may take 5–20 minutes depending on APK size.',
    color: _teal,
  ),
  _Step(
    icon: Icons.check_circle_rounded,
    title: 'Done — protected APK downloaded',
    body: 'A success toast confirms completion. Your protected APK is automatically downloaded from the cloud and saved to the output folder. Install it directly on your device.',
    color: _green,
  ),
];

// ── APK Tool ───────────────────────────────────────────────────────────────────

const Color _blue  = Color(0xFF3b82f6);
const Color _blueL = Color(0xFF60a5fa);

class _ApkToolGuide extends StatefulWidget {
  const _ApkToolGuide();
  @override
  State<_ApkToolGuide> createState() => _ApkToolGuideState();
}

class _ApkToolGuideState extends State<_ApkToolGuide>
    with SingleTickerProviderStateMixin {
  late TabController _tab;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
    _tab.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Padding(
        padding: EdgeInsets.fromLTRB(20, 12, 20, 8),
        child: Container(
          decoration: BoxDecoration(
            color: Color(0xFF0a0a18),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: ThemeProvider().current.surfaceColor),
          ),
          child: TabBar(
            controller: _tab,
            indicator: BoxDecoration(
              gradient: LinearGradient(
                colors: [_blue, const Color(0xFF1d4ed8)],
              ),
              borderRadius: BorderRadius.circular(10),
            ),
            indicatorSize: TabBarIndicatorSize.tab,
            dividerColor: Colors.transparent,
            labelColor: Colors.white,
            unselectedLabelColor: const Color(0xFF6b7280),
            labelStyle: const TextStyle(
                fontWeight: FontWeight.w700, fontSize: 12),
            unselectedLabelStyle: const TextStyle(
                fontWeight: FontWeight.w500, fontSize: 12),
            tabs: const [
              Tab(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.arrow_downward_rounded, size: 14),
                    SizedBox(width: 5),
                    Text('Decompile'),
                  ],
                ),
              ),
              Tab(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.arrow_upward_rounded, size: 14),
                    SizedBox(width: 5),
                    Text('Recompile'),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      Expanded(
        child: TabBarView(
          controller: _tab,
          children: [
            _ApkToolStepList(steps: _apkDecompileSteps),
            _ApkToolStepList(steps: _apkRecompileSteps),
          ],
        ),
      ),
    ]);
  }
}

class _ApkToolStepList extends StatelessWidget {
  final List<_Step> steps;
  const _ApkToolStepList({required this.steps});

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
      itemCount: steps.length + 1,
      separatorBuilder: (_, i) => i < steps.length - 1
          ? _StepConnector(color: _blue)
          : const SizedBox(height: 20),
      itemBuilder: (_, i) {
        if (i < steps.length) return _StepCard(step: steps[i], index: i);
        return _ApkToolOutputNote();
      },
    );
  }
}

class _ApkToolOutputNote extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0a1020),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _blue.withOpacity(0.3)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: _blue.withOpacity(0.12),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(Icons.folder_open_rounded, color: _blue, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Where to find your output',
                  style: TextStyle(
                    color: _blue,
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Open any file manager and navigate to:',
                  style: TextStyle(
                      color: Color(0xFF6b7280), fontSize: 11.5),
                ),
                const SizedBox(height: 6),
                Text(
                  'Internal Storage → Taurus-Shield → output → apktool',
                  style: TextStyle(
                    color: _blueL,
                    fontSize: 11,
                    fontFamily: 'monospace',
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ── APK Tool — Decompile steps ─────────────────────────────────────────────────

final List<_Step> _apkDecompileSteps = [
  _Step(
    icon: Icons.touch_app_rounded,
    title: 'Open APK Tool from the tool picker',
    body: 'From the main screen tap "APK Tool — Decompile / Recompile APK" to open the tool.',
    color: _blue,
  ),
  _Step(
    icon: Icons.upload_file_rounded,
    title: 'Select your APK file',
    body: 'Tap the file selector and pick any .apk file. The app auto-detects DECOMPILE mode. Files up to 100 MB are accepted.',
    color: _blueL,
    tag: 'Accepted: .apk  (any Android APK)',
  ),
  _Step(
    icon: Icons.auto_awesome_rounded,
    title: 'Mode auto-detects as DECOMPILE',
    body: 'The blue DECOMPILE badge appears below the file name. No sign toggle is shown — decompile does not produce an installable APK.',
    color: _blue,
  ),
  _Step(
    icon: Icons.cloud_upload_rounded,
    title: 'Tap "Decompile (APK Tool)"',
    body: 'Press the blue button. Your APK is uploaded to the cloud and decompiled automatically. An active internet connection is required.',
    color: _blue,
  ),
  _Step(
    icon: Icons.terminal_rounded,
    title: 'Watch live cloud progress',
    body: 'The log panel streams real-time updates — upload, install Java, run apktool, package output. The timer shows elapsed time. Decompile typically takes 1–3 minutes.',
    color: _blueL,
  ),
  _Step(
    icon: Icons.check_circle_rounded,
    title: 'Done — decompiled project downloaded',
    body: 'A success toast confirms completion. Your decompiled project (smali/, res/, AndroidManifest.xml, apktool.yml, etc.) is saved as a ZIP in the output folder.',
    color: _green,
  ),
];

// ── Android ID Spoofer guide ───────────────────────────────────────────────────

const Color _spCyan    = Color(0xFF00E5FF);
const Color _spCyanDim = Color(0xFF0891b2);

class _SpoofGuide extends StatelessWidget {
  const _SpoofGuide();

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
      itemCount: _spoofSteps.length + 2,
      separatorBuilder: (_, i) => i < _spoofSteps.length - 1
          ? _StepConnector(color: _spCyan)
          : const SizedBox(height: 20),
      itemBuilder: (_, i) {
        if (i < _spoofSteps.length) return _StepCard(step: _spoofSteps[i], index: i);
        if (i == _spoofSteps.length) return _SpoofOutputNote();
        return _SpoofBenefitsCard();
      },
    );
  }
}

class _SpoofOutputNote extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF051a20),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _spCyan.withOpacity(0.3)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: _spCyan.withOpacity(0.12),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(Icons.folder_open_rounded, color: _spCyan, size: 18),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Where to find your spoofed APK',
                  style: TextStyle(
                    color: _spCyan,
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Open any file manager and navigate to:',
                  style: TextStyle(color: Color(0xFF6b7280), fontSize: 11.5),
                ),
                SizedBox(height: 6),
                Text(
                  'Internal Storage → Taurus-Shield → output → spoofer',
                  style: TextStyle(
                    color: Color(0xFF67e8f9),
                    fontSize: 11,
                    fontFamily: 'monospace',
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SpoofBenefitsCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    const benefits = [
      (Icons.fingerprint_rounded,       'Unique Device Identity',    'Each spoofed APK reports a different Android ID, making your device appear as a completely new unique unit to the app.'),
      (Icons.block_rounded,             'Bypass Ban Detection',      'Spoof past hardware-level bans and account restrictions tied to your Android ID — apps see a fresh device, not a flagged one.'),
      (Icons.privacy_tip_rounded,       'Privacy Protection',        'Prevent apps from tracking you across sessions using your hardware ID. Reclaim control over what identity you expose.'),
      (Icons.recycling_rounded,         'Unlimited Fresh Starts',    'Spin up as many spoofed identities as you need. No root required — the patch is embedded directly inside the APK.'),
      (Icons.verified_user_rounded,     'Signed & Ready to Install', 'Toggle signing on to get a debug-signed APK you can sideload immediately, or leave it unsigned to sign with your own key.'),
      (Icons.cloud_done_rounded,        'Cloud-Powered — No Root',   'All patching happens on a secure cloud builder. No root, no Xposed, no special permissions needed on your device.'),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 8),
        Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: _spCyan.withOpacity(0.12),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _spCyan.withOpacity(0.3)),
              ),
              child: const Icon(Icons.auto_awesome_rounded, color: _spCyan, size: 16),
            ),
            const SizedBox(width: 10),
            const Text(
              'Why Use Android ID Spoofer?',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w800,
                fontSize: 14,
                letterSpacing: 0.3,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        ...benefits.map((b) => _BenefitRow(icon: b.$1, title: b.$2, body: b.$3)),
      ],
    );
  }
}

class _BenefitRow extends StatelessWidget {
  final IconData icon;
  final String title;
  final String body;
  const _BenefitRow({required this.icon, required this.title, required this.body});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFF08141e),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _spCyan.withOpacity(0.15)),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(5),
              decoration: BoxDecoration(
                color: _spCyan.withOpacity(0.1),
                borderRadius: BorderRadius.circular(7),
              ),
              child: Icon(icon, color: _spCyan, size: 15),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: _spCyan,
                      fontWeight: FontWeight.w700,
                      fontSize: 12,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    body,
                    style: const TextStyle(
                      color: Color(0xFF9ca3af),
                      fontSize: 11,
                      height: 1.5,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

final List<_Step> _spoofSteps = [
  _Step(
    icon: Icons.touch_app_rounded,
    title: 'Open Android ID Spoofer',
    body: 'From the main screen tap "Android ID Spoofer" to open the tool. You will see the ID input, file selector, and sign toggle.',
    color: _spCyan,
  ),
  _Step(
    icon: Icons.tag_rounded,
    title: 'Enter or generate your Android ID',
    body: 'Type any 16-character hex string into the ID field, or tap the dice icon to auto-generate a random valid ID. The field validates your input and shows an error if the format is wrong.',
    color: _spCyanDim,
    tag: 'Must be exactly 16 hex characters  (0-9, a-f)',
  ),
  _Step(
    icon: Icons.upload_file_rounded,
    title: 'Select your APK file',
    body: 'Tap the file selector and pick the .apk you want to patch. The app shows the file name and size. Any standard Android APK is accepted.',
    color: _spCyan,
    tag: 'Accepted: .apk  (any Android APK)',
  ),
  _Step(
    icon: Icons.toggle_on_rounded,
    title: 'Choose signing option',
    body: 'Toggle "Sign APK" on to have the spoofed APK automatically signed with a debug key — you can sideload it immediately after. Turn it off if you want to sign it yourself with a release key.',
    color: _spCyanDim,
  ),
  _Step(
    icon: Icons.cloud_upload_rounded,
    title: 'Tap "Patch APK"',
    body: 'Press the button to start. Your APK is uploaded directly to the cloud, decompiled, patched with your Android ID, rebuilt and optionally signed — all automatically.',
    color: _spCyan,
  ),
  _Step(
    icon: Icons.terminal_rounded,
    title: 'Watch live cloud progress',
    body: 'The log panel streams real-time updates — upload, decompile, patch, rebuild, sign. The timer shows elapsed time. Patching typically takes 3–10 minutes depending on APK size.',
    color: _spCyanDim,
  ),
  _Step(
    icon: Icons.check_circle_rounded,
    title: 'Done — spoofed APK downloaded',
    body: 'A success toast confirms completion. Your patched APK is automatically downloaded and saved. The filename ends in _spoofed.apk. Sideload it to your device and the app will read your custom Android ID.',
    color: _green,
  ),
];

// ── APK Tool — Recompile steps ─────────────────────────────────────────────────

final List<_Step> _apkRecompileSteps = [
  _Step(
    icon: Icons.edit_note_rounded,
    title: 'Start from a decompiled project',
    body: 'Use the Decompile tab first to get an apktool project, or use any existing apktool output directory. Edit the smali files or resources as needed.',
    color: _blueL,
    tag: 'Project must contain: apktool.yml',
  ),
  _Step(
    icon: Icons.folder_zip_rounded,
    title: 'Pack your project into a ZIP',
    body: 'Select the decompiled project folder (containing apktool.yml, smali/, res/, AndroidManifest.xml) and compress it into a single .zip file.',
    color: _blue,
    tag: 'Required inside ZIP: apktool.yml  (at root level)',
  ),
  _Step(
    icon: Icons.touch_app_rounded,
    title: 'Open APK Tool from the tool picker',
    body: 'From the main screen tap "APK Tool — Decompile / Recompile APK".',
    color: _blue,
  ),
  _Step(
    icon: Icons.upload_file_rounded,
    title: 'Select your project ZIP',
    body: 'Tap the file selector and pick your ZIP. The app scans it for apktool.yml and auto-detects RECOMPILE mode. Files up to 100 MB are accepted.',
    color: _blueL,
    tag: 'Accepted: .zip  (must contain apktool.yml)',
  ),
  _Step(
    icon: Icons.toggle_on_rounded,
    title: 'Choose signing option (optional)',
    body: 'Toggle "Sign APK" on to have the rebuilt APK automatically signed with a debug keystore — useful for installing to a test device. Leave off if you have your own signing setup.',
    color: _blue,
  ),
  _Step(
    icon: Icons.cloud_upload_rounded,
    title: 'Tap "Recompile (APK Tool)"',
    body: 'Press the blue button. Your ZIP is uploaded to the cloud and the APK is rebuilt automatically. An active internet connection is required.',
    color: _blue,
  ),
  _Step(
    icon: Icons.terminal_rounded,
    title: 'Watch live cloud progress',
    body: 'The log panel streams real-time updates — upload, install Java, run apktool build, optionally sign. Recompile typically takes 1–4 minutes.',
    color: _blueL,
  ),
  _Step(
    icon: Icons.check_circle_rounded,
    title: 'Done — rebuilt APK downloaded',
    body: 'A success toast confirms completion. Your rebuilt APK (out.apk) is saved to the output folder. Install it directly on your device to test your changes.',
    color: _green,
  ),
];

// ── Ads Patch guide ────────────────────────────────────────────────────────────

const _red = Color(0xFFef4444);

class _AdsPatchGuide extends StatelessWidget {
  const _AdsPatchGuide();

  @override
  Widget build(BuildContext context) {
    return _SimpleStepList(steps: _adsPatchSteps, accent: _red);
  }
}

class _SimpleStepList extends StatelessWidget {
  final List<_Step> steps;
  final Color accent;
  const _SimpleStepList({required this.steps, required this.accent});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: _red.withOpacity(0.07),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _red.withOpacity(0.25)),
          ),
          child: Row(children: [
            Icon(Icons.block_rounded, color: _red, size: 16),
            const SizedBox(width: 8),
            const Expanded(child: Text(
              'Removes ad SDKs from Android APKs by patching smali bytecode. '
              'Choose a patch level — higher levels are more aggressive.',
              style: TextStyle(color: Color(0xFFd1d5db), fontSize: 11, height: 1.5),
            )),
          ]),
        ),
        const SizedBox(height: 14),
        ...steps.map((s) => Padding(
          padding: const EdgeInsets.only(bottom: 14),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(
              width: 34, height: 34,
              decoration: BoxDecoration(
                color: s.color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(9),
                border: Border.all(color: s.color.withOpacity(0.35)),
              ),
              child: Icon(s.icon, color: s.color, size: 16),
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(s.title, style: const TextStyle(
                  color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
              const SizedBox(height: 3),
              Text(s.body, style: const TextStyle(
                  color: Color(0xFF9ca3af), fontSize: 11, height: 1.5)),
            ])),
          ]),
        )),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFF0a0a18),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFF2a1020)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Patch Levels', style: TextStyle(
                color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            ...[
              ['Basic',   'Neutralizes loadAd / renderAd methods only'],
              ['Low',     '+ Comments out GMS ad invoke calls'],
              ['Mid',     '+ Blocks ad network URLs and AdMob pub IDs'],
              ['Advance', '+ NOPs full ad SDK invoke calls (recommended)'],
              ['All',     'Combines every technique above'],
            ].map((e) => Padding(
              padding: const EdgeInsets.only(bottom: 5),
              child: Row(children: [
                Container(width: 6, height: 6,
                    decoration: BoxDecoration(shape: BoxShape.circle, color: _red.withOpacity(0.7))),
                const SizedBox(width: 8),
                Text('${e[0]}: ', style: TextStyle(
                    color: _red, fontSize: 10.5, fontWeight: FontWeight.w700)),
                Expanded(child: Text(e[1], style: const TextStyle(
                    color: Color(0xFF9ca3af), fontSize: 10.5))),
              ]),
            )),
          ]),
        ),
      ],
    );
  }
}

const _adsPatchSteps = [
  _Step(
    icon: Icons.upload_file_rounded,
    title: 'Select your APK',
    body: 'Tap the file picker and choose an APK. The file is uploaded directly to the processing cluster over a secure connection.',
    color: _red,
  ),
  _Step(
    icon: Icons.tune_rounded,
    title: 'Choose patch level',
    body: 'Select Basic for a quick light patch, or Advance / All for maximum ad removal. Higher levels are more effective but may rarely affect app stability.',
    color: Color(0xFFf97316),
  ),
  _Step(
    icon: Icons.verified_user_rounded,
    title: 'Enable signing (optional)',
    body: 'Toggle Sign APK on to debug-sign the patched APK automatically. This lets you install it directly on your device without a separate signing step.',
    color: Color(0xFF22c55e),
  ),
  _Step(
    icon: Icons.cloud_upload_rounded,
    title: 'Start patch',
    body: 'Tap Start Ads Patch. The APK is decompiled, patched using the cloud engine, rebuilt, and optionally signed. Typical time: 2–5 minutes.',
    color: Color(0xFF3b82f6),
  ),
  _Step(
    icon: Icons.check_circle_rounded,
    title: 'Download patched APK',
    body: 'The finished APK (out.apk) is saved to Internal Storage → Taurus-Shield → output. Tap the folder icon to open it directly.',
    color: Color(0xFF22c55e),
  ),
];

// ── Anti-Dialog Killer guide ───────────────────────────────────────────────────

const _akPurple    = Color(0xFF8B5CF6);
const _akPurpleDim = Color(0xFF6D28D9);

class _AntiKillerGuide extends StatelessWidget {
  const _AntiKillerGuide();

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: _akPurple.withOpacity(0.07),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _akPurple.withOpacity(0.25)),
          ),
          child: Row(children: [
            Icon(Icons.shield_rounded, color: _akPurple, size: 16),
            const SizedBox(width: 8),
            const Expanded(child: Text(
              'Patches your APK to protect your subscription, update, and paywall dialogs. '
              'Shields the app against external hook attempts to dismiss your dialogs, '
              'hardens it against tampering, and wraps the entire package with DPT protection.',
              style: TextStyle(color: Color(0xFFd1d5db), fontSize: 11, height: 1.5),
            )),
          ]),
        ),
        const SizedBox(height: 14),
        ..._antiKillerSteps.map((s) => Padding(
          padding: const EdgeInsets.only(bottom: 14),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(
              width: 34, height: 34,
              decoration: BoxDecoration(
                color: s.color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(9),
                border: Border.all(color: s.color.withOpacity(0.35)),
              ),
              child: Icon(s.icon, color: s.color, size: 16),
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(s.title, style: const TextStyle(
                  color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
              const SizedBox(height: 3),
              if (s.tag != null) ...[
                Container(
                  margin: const EdgeInsets.only(bottom: 4),
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: s.color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(color: s.color.withOpacity(0.3)),
                  ),
                  child: Text(s.tag!, style: TextStyle(
                      color: s.color, fontSize: 9.5, fontWeight: FontWeight.w600,
                      fontFamily: 'monospace')),
                ),
              ],
              Text(s.body, style: const TextStyle(
                  color: Color(0xFF9ca3af), fontSize: 11, height: 1.5)),
            ])),
          ]),
        )),
      ],
    );
  }
}

const _antiKillerSteps = [
  _Step(
    icon: Icons.upload_file_rounded,
    title: 'Select your APK',
    body: 'Tap the file picker and choose any Android APK. It will be uploaded securely to the cloud for processing.',
    color: _akPurple,
  ),
  _Step(
    icon: Icons.memory_rounded,
    title: 'Enter Main Activity',
    body: 'Paste the fully-qualified main activity class name (e.g. com.example.app.MainActivity). This is required — find it in your app\'s AndroidManifest.xml.',
    color: _akPurpleDim,
    tag: 'e.g. com.example.app.MainActivity',
  ),
  _Step(
    icon: Icons.verified_user_rounded,
    title: 'Enable signing',
    body: 'Toggle Sign APK on to debug-sign the patched APK. This lets you sideload it immediately. Turn off if you plan to sign with your own release key.',
    color: Color(0xFF22c55e),
  ),
  _Step(
    icon: Icons.cloud_upload_rounded,
    title: 'Start Matrix Killer',
    body: 'Tap the button. The APK is uploaded, decompiled, hooked with Matrix Killer, rebuilt, integrity-sealed, and signed. Typical time: 3–8 minutes.',
    color: Color(0xFF3b82f6),
  ),
  _Step(
    icon: Icons.check_circle_rounded,
    title: 'Download patched APK',
    body: 'The finished APK (out.apk) is saved to Internal Storage → Taurus-Shield → output. Tap the folder icon to open it directly.',
    color: Color(0xFF22c55e),
  ),
];

// ── Shared helper widgets ──────────────────────────────────────────────────────

class _GuideTab extends StatelessWidget {
  final int             index;
  final String          label;
  final IconData        icon;
  final Color           color;
  final TabController   controller;
  const _GuideTab({required this.index, required this.label, required this.icon, required this.color, required this.controller});

  @override
  Widget build(BuildContext context) {
    final selected = controller.index == index;
    return GestureDetector(
      onTap: () => controller.animateTo(index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: selected ? color.withOpacity(0.15) : Color(0xFF0a0a18),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: selected ? color.withOpacity(0.65) : ThemeProvider().current.surfaceColor,
            width: selected ? 1.5 : 1,
          ),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 13, color: selected ? color : const Color(0xFF6b7280)),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(
              fontSize: 11,
              fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
              color: selected ? Colors.white : const Color(0xFF6b7280),
            ),
          ),
        ]),
      ),
    );
  }
}

class _OutFile extends StatelessWidget {
  final String name;
  final String desc;
  final Color  color;
  const _OutFile({required this.name, required this.desc, required this.color});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Icon(Icons.insert_drive_file_rounded, color: color, size: 14),
      const SizedBox(width: 8),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(name, style: TextStyle(color: color, fontFamily: 'monospace', fontSize: 11, fontWeight: FontWeight.w700)),
        Text(desc, style: const TextStyle(color: Color(0xFF6b7280), fontSize: 10)),
      ])),
    ]);
  }
}

const _forgeOrange = Color(0xFFFF6B35);

class _BlackForgeGuide extends StatelessWidget {
  const _BlackForgeGuide();

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: _forgeOrange.withOpacity(0.07),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _forgeOrange.withOpacity(0.25)),
          ),
          child: Row(children: [
            Icon(Icons.local_fire_department_rounded, color: _forgeOrange, size: 16),
            const SizedBox(width: 8),
            const Expanded(child: Text(
              'Protect your personal files with military-grade encryption and '
              'compress them into secure archives. Everything runs 100% offline '
              'on your device — nothing is uploaded or shared.',
              style: TextStyle(color: Color(0xFFd1d5db), fontSize: 11, height: 1.5),
            )),
          ]),
        ),
        const SizedBox(height: 18),
        _forgeSection(
          icon: Icons.lock_rounded,
          color: _forgeOrange,
          title: 'ENCRYPT',
          subtitle: 'Lock your files so nobody else can open them',
        ),
        const SizedBox(height: 6),
        ..._forgeEncryptSteps.map(_forgeStepTile),
        const SizedBox(height: 18),
        _forgeSection(
          icon: Icons.lock_open_rounded,
          color: const Color(0xFF4ADE80),
          title: 'DECRYPT',
          subtitle: 'Unlock your encrypted .enc files',
        ),
        const SizedBox(height: 6),
        ..._forgeDecryptSteps.map(_forgeStepTile),
        const SizedBox(height: 18),
        _forgeSection(
          icon: Icons.archive_rounded,
          color: const Color(0xFF42A5F5),
          title: 'ARCHIVE',
          subtitle: 'Compress and bundle files together',
        ),
        const SizedBox(height: 6),
        ..._forgeArchiveSteps.map(_forgeStepTile),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: const Color(0xFF0a0a18),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _forgeOrange.withOpacity(0.15)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Icon(Icons.lightbulb_rounded, color: _forgeOrange, size: 14),
              const SizedBox(width: 6),
              const Text('What can you protect?', style: TextStyle(
                  color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
            ]),
            const SizedBox(height: 10),
            _useCase(Icons.photo_library_rounded, const Color(0xFFE879F9), 'Photos & Screenshots',
                'Encrypt private photos so no one can view them without your password.'),
            _useCase(Icons.videocam_rounded, const Color(0xFFFB923C), 'Videos & Recordings',
                'Lock personal videos, screen recordings, or camera footage behind AES-256.'),
            _useCase(Icons.description_rounded, const Color(0xFF60A5FA), 'Documents & PDFs',
                'Protect contracts, IDs, bank statements, or any sensitive documents.'),
            _useCase(Icons.folder_zip_rounded, const Color(0xFF4ADE80), 'ZIP / APK / Any File',
                'Encrypt any file type — APKs, ZIPs, databases, backups, anything.'),
            _useCase(Icons.cloud_upload_rounded, const Color(0xFF818CF8), 'Before Uploading to Cloud',
                'Encrypt files before uploading to Google Drive, Telegram, etc. Even if someone intercepts them, they cannot open them.'),
            _useCase(Icons.share_rounded, const Color(0xFFFBBF24), 'Sharing Privately',
                'Encrypt a file, share it via any app, and send the password separately. Only the receiver can decrypt it.'),
          ]),
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFF7f1d1d).withOpacity(0.15),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFFef4444).withOpacity(0.25)),
          ),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Icon(Icons.warning_rounded, color: Color(0xFFef4444), size: 16),
            const SizedBox(width: 8),
            const Expanded(child: Text(
              'If you lose your password or key, your files CANNOT be recovered. '
              'There is no backdoor, no reset, no cloud backup. '
              'Always save your password/key somewhere safe.',
              style: TextStyle(color: Color(0xFFfca5a5), fontSize: 11, height: 1.5),
            )),
          ]),
        ),
      ],
    );
  }

  static Widget _forgeSection({
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(0.25)),
      ),
      child: Row(children: [
        Icon(icon, color: color, size: 18),
        const SizedBox(width: 10),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: TextStyle(color: color, fontSize: 12,
              fontWeight: FontWeight.w900, letterSpacing: 1.5)),
          Text(subtitle, style: const TextStyle(color: Color(0xFF9ca3af), fontSize: 10)),
        ]),
      ]),
    );
  }

  static Widget _forgeStepTile(_Step s) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          width: 30, height: 30,
          decoration: BoxDecoration(
            color: s.color.withOpacity(0.12),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: s.color.withOpacity(0.35)),
          ),
          child: Icon(s.icon, color: s.color, size: 14),
        ),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(s.title, style: const TextStyle(
              color: Colors.white, fontSize: 11.5, fontWeight: FontWeight.w700)),
          const SizedBox(height: 2),
          Text(s.body, style: const TextStyle(
              color: Color(0xFF9ca3af), fontSize: 10.5, height: 1.5)),
        ])),
      ]),
    );
  }

  static Widget _useCase(IconData icon, Color color, String title, String desc) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: color, size: 16),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w700)),
          const SizedBox(height: 2),
          Text(desc, style: const TextStyle(color: Color(0xFF9ca3af), fontSize: 10.5, height: 1.4)),
        ])),
      ]),
    );
  }
}

const _forgeEncryptSteps = [
  _Step(
    icon: Icons.touch_app_rounded,
    title: 'Pick a file',
    body: 'Tap "Tap to select file" and choose any file — a photo, video, document, APK, ZIP, anything you want to protect.',
    color: Color(0xFFFF6B35),
  ),
  _Step(
    icon: Icons.key_rounded,
    title: 'Choose your key source',
    body: 'Password — type a strong password and the app derives an uncrackable key from it.\n'
        'Raw hex — paste your own 256-bit key for full control.\n'
        'Auto-generate — the app creates a random key. You MUST save it.',
    color: Color(0xFFFFA726),
  ),
  _Step(
    icon: Icons.tune_rounded,
    title: 'Set iterations (600K / 1M / 2M / 5M / 7M / 10M)',
    body: 'Higher = harder to crack but takes a few seconds longer. '
        '600K is fast and still very strong. 1M is recommended. 5M is paranoid-level. 7M and 10M are maximum-security — use for your most critical files.',
    color: Color(0xFFE879F9),
  ),
  _Step(
    icon: Icons.fingerprint_rounded,
    title: 'AAD (optional)',
    body: 'Add a label like "my-photos-2024". It\'s not encrypted but cryptographically bound — '
        'if anyone changes it, decryption fails. Think of it as a tamper-proof tag.',
    color: Color(0xFF42A5F5),
  ),
  _Step(
    icon: Icons.lock_rounded,
    title: 'Tap Encrypt',
    body: 'Your file is encrypted with AES-256-GCM and saved as a .enc file to '
        'Internal Storage → Taurus-Shield → output → forge. '
        'The original stays untouched. Share the .enc file safely — without the password, it\'s unreadable.',
    color: Color(0xFF4ADE80),
  ),
];

const _forgeDecryptSteps = [
  _Step(
    icon: Icons.file_open_rounded,
    title: 'Select .enc file',
    body: 'Pick the encrypted file you want to unlock.',
    color: Color(0xFF4ADE80),
  ),
  _Step(
    icon: Icons.password_rounded,
    title: 'Enter password or key',
    body: 'Type the exact same password (or hex key) you used when encrypting. '
        'If you used AAD, enter that too — it must match exactly.',
    color: Color(0xFFFFA726),
  ),
  _Step(
    icon: Icons.lock_open_rounded,
    title: 'Tap Decrypt',
    body: 'If the password is correct, your original file is restored. '
        'If wrong or the file was tampered with, decryption is refused — no partial or corrupted output.',
    color: Color(0xFF42A5F5),
  ),
];

const _forgeArchiveSteps = [
  _Step(
    icon: Icons.create_new_folder_rounded,
    title: 'Create Archive',
    body: 'Tap "Create" to select files. Choose format (7z, zip, tar, etc.), compression level '
        '(Fastest to Ultra), and optionally set AES-256 encryption with a password.',
    color: Color(0xFF42A5F5),
  ),
  _Step(
    icon: Icons.content_cut_rounded,
    title: 'Split Volumes',
    body: 'Split large archives into smaller parts (5MB to 4GB). '
        'Useful for sending big files through apps with size limits like email or Telegram.',
    color: Color(0xFF818CF8),
  ),
  _Step(
    icon: Icons.unarchive_rounded,
    title: 'Extract',
    body: 'Tap "Extract" to open any archive (7z, zip, tar.gz, etc.). '
        'Enter the password if it\'s encrypted. Files are extracted to a folder.',
    color: Color(0xFFFBBF24),
  ),
  _Step(
    icon: Icons.delete_sweep_rounded,
    title: 'Delete Source',
    body: 'Toggle "Delete source" to automatically remove the original files after archiving. '
        'Use with caution — the originals are permanently deleted.',
    color: Color(0xFFEF5350),
  ),
];

// ── Mod Engine guide ──────────────────────────────────────────────────────────

const _modCyan = Color(0xFF00E5FF);

class _ModEngineGuide extends StatelessWidget {
  const _ModEngineGuide();

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
      children: [
        // Banner
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: _modCyan.withOpacity(0.07),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _modCyan.withOpacity(0.25)),
          ),
          child: Row(children: [
            Icon(Icons.memory, color: _modCyan, size: 16),
            const SizedBox(width: 8),
            const Expanded(child: Text(
              'Patch any Unity IL2CPP game — no root, no cloud build, no mod APK. '
              'Taurus Shield writes ARM64 instructions directly into libil2cpp.so '
              'on your device. You put it back with MT Manager.',
              style: TextStyle(color: Color(0xFFd1d5db), fontSize: 11, height: 1.5),
            )),
          ]),
        ),
        const SizedBox(height: 18),

        // PHASE 1 — Dump
        _modSection(Icons.radar_rounded, _modCyan, 'PHASE 1 — ANALYSE', 'Scan the game to find moddable values'),
        const SizedBox(height: 8),
        ..._modDumpSteps.map(_modStepTile),
        const SizedBox(height: 18),

        // PHASE 2 — Select
        _modSection(Icons.checklist_rounded, const Color(0xFF818CF8), 'PHASE 2 — SELECT FEATURES', 'Choose what you want to change'),
        const SizedBox(height: 8),
        ..._modSelectSteps.map(_modStepTile),
        const SizedBox(height: 18),

        // PHASE 3 — Patch
        _modSection(Icons.memory, const Color(0xFF4ADE80), 'PHASE 3 — PATCH', 'On-device — writes ARM64 bytes, no cloud needed'),
        const SizedBox(height: 8),
        ..._modPatchSteps.map(_modStepTile),
        const SizedBox(height: 18),

        // What can be modded
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: const Color(0xFF0a0a18),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _modCyan.withOpacity(0.15)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Icon(Icons.lightbulb_rounded, color: _modCyan, size: 14),
              const SizedBox(width: 6),
              const Text('What can you mod?', style: TextStyle(
                  color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
            ]),
            const SizedBox(height: 10),
            _modUseCase(Icons.monetization_on_rounded,    const Color(0xFFFBBF24), 'Coins / Currency',    'int or long → 999999. Patches any currency getter. Works on Subway Surfers, Temple Run and most offline games.'),
            _modUseCase(Icons.speed_rounded,              const Color(0xFFf97316), 'Speed / Movement',    'float → 2.0–5.0. Targets speed multiplier, jump height, and gravity — all patchable as float returns.'),
            _modUseCase(Icons.lock_open_rounded,          const Color(0xFF4ADE80), 'Unlock / IAP Checks', 'bool → true. Flips ownership and unlock booleans — bypasses item locks, level gates, and IAP walls.'),
            _modUseCase(Icons.health_and_safety_rounded,  const Color(0xFFef4444), 'Health / Lives',      'int → high value. Patch any HP or lives getter to return a fixed maximum.'),
            _modUseCase(Icons.block_rounded,              const Color(0xFF818CF8), 'Ad Removal',          'void (early return) on ad-show methods, or bool → false on "should show ad" checks. No ads fire.'),
            _modUseCase(Icons.device_hub_rounded,         const Color(0xFFA78BFA), 'Branch Patches',      'B always / B never: converts a conditional branch (BEQ, CBZ…) to always or never jump. Use on if-checks found via Radare2 or Ghidra.'),
            _modUseCase(Icons.timer_off_rounded,          const Color(0xFF0891b2), 'Timers / Cooldowns',  'float → 0.0 or tiny value on cooldown methods. NOP a timer-increment instruction to freeze it entirely.'),
          ]),
        ),
        const SizedBox(height: 14),

        // Warning
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFF7f1d1d).withOpacity(0.15),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFFef4444).withOpacity(0.25)),
          ),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Icon(Icons.warning_rounded, color: Color(0xFFef4444), size: 16),
            const SizedBox(width: 8),
            const Expanded(child: Text(
              'What matters is not online vs offline — it\'s whether the value you\'re patching '
              'is validated by the server. Subway Surfers is "online" but coins, speed, and score '
              'multipliers run purely on-device in the IL2CPP binary — the server only syncs your '
              'leaderboard score after a run, so those patches work perfectly.\n\n'
              'Patches will not work when the server deducts/validates the value in real-time '
              '(e.g. buying items from a live server shop, multiplayer health in PvP). '
              'Offline logic that runs in libil2cpp.so is always patchable.',
              style: TextStyle(color: Color(0xFFfca5a5), fontSize: 11, height: 1.5),
            )),
          ]),
        ),
        const SizedBox(height: 12),
        // On-device note
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: const Color(0xFF0a0a18),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFF2a1040)),
          ),
          child: const Row(children: [
            Icon(Icons.memory, color: Color(0xFF6b7280), size: 18),
            SizedBox(width: 10),
            Expanded(child: Text(
              'Phase 1 (analysis) needs internet to run Il2CppDumper on the cloud. '
              'Phase 3 (patching) is fully on-device — no internet required. '
              'Output is saved to  Internal Storage › Taurus-Shield › output › mod-engine.',
              style: TextStyle(color: Color(0xFF6b7280), fontSize: 11, height: 1.5),
            )),
          ]),
        ),
      ],
    );
  }

  static Widget _modSection(IconData icon, Color color, String title, String subtitle) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(0.25)),
      ),
      child: Row(children: [
        Icon(icon, color: color, size: 18),
        const SizedBox(width: 10),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: TextStyle(color: color, fontSize: 12,
              fontWeight: FontWeight.w900, letterSpacing: 1.2)),
          Text(subtitle, style: const TextStyle(color: Color(0xFF9ca3af), fontSize: 10)),
        ]),
      ]),
    );
  }

  static Widget _modStepTile(_Step s) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          width: 30, height: 30,
          decoration: BoxDecoration(
            color: s.color.withOpacity(0.12),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: s.color.withOpacity(0.35)),
          ),
          child: Icon(s.icon, color: s.color, size: 14),
        ),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(s.title, style: const TextStyle(
              color: Colors.white, fontSize: 11.5, fontWeight: FontWeight.w700)),
          const SizedBox(height: 2),
          Text(s.body, style: const TextStyle(
              color: Color(0xFF9ca3af), fontSize: 10.5, height: 1.5)),
        ])),
      ]),
    );
  }

  static Widget _modUseCase(IconData icon, Color color, String title, String desc) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: color, size: 15),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w700)),
          const SizedBox(height: 2),
          Text(desc, style: const TextStyle(color: Color(0xFF9ca3af), fontSize: 10.5, height: 1.4)),
        ])),
      ]),
    );
  }
}

const _modDumpSteps = [
  _Step(
    icon: Icons.folder_open_rounded,
    title: 'Open the APK in MT Manager',
    body: 'Open MT Manager → tap the game APK → browse inside it like a folder. '
        'Navigate to  lib › arm64-v8a  and long-press libil2cpp.so → Extract. '
        'Then go to  assets › bin › Data › Managed › Metadata  and extract global-metadata.dat. '
        'Both files must be on your device storage.',
    color: _modCyan,
  ),
  _Step(
    icon: Icons.folder_zip_outlined,
    title: 'Zip the two files together',
    body: 'Create a new zip containing exactly libil2cpp.so and global-metadata.dat at the root '
        '(not inside any sub-folder). You can use MT Manager → New → Zip, or any zip app. '
        'Name it anything — e.g.  game_il2cpp.zip.',
    color: Color(0xFF818CF8),
  ),
  _Step(
    icon: Icons.upload_rounded,
    title: 'Pick the zip & Analyse',
    body: 'Back in Taurus Shield, tap the zip picker and select your zip. '
        'Tap "Analyse Game". Only this slim zip is uploaded — not the full APK. '
        'Il2CppDumper maps every C# method name, its file offset, and its return type.',
    color: _modCyan,
  ),
  _Step(
    icon: Icons.hourglass_bottom_rounded,
    title: 'Wait for analysis (~3–8 min)',
    body: 'Live progress is shown in the log panel. The engine scores each method '
        'by how patchable it is and saves the full results to your device.',
    color: Color(0xFFFBBF24),
  ),
];

const _modSelectSteps = [
  _Step(
    icon: Icons.filter_list_rounded,
    title: 'Browse the method list',
    body: 'After analysis a list of all detected methods appears. '
        'Use the search bar to filter by method name, class, offset, or return type — '
        'it searches all methods in real time. '
        'Toggle "Suggestions only" to see engine-recommended methods, '
        'or turn it off to browse every single method in the binary.',
    color: Color(0xFF818CF8),
  ),
  _Step(
    icon: Icons.check_box_rounded,
    title: 'Select & configure each patch',
    body: 'Tick a method to select it. Use the type row to pick the patch strategy:\n'
        '• bool → returns true or false\n'
        '• int / long → returns a fixed number\n'
        '• float → returns a decimal value\n'
        '• void → early return (RET), no value\n'
        '• NOP → kills one instruction at that offset\n'
        '• B always / B never → force or kill a conditional branch',
    color: _modCyan,
  ),
  _Step(
    icon: Icons.tune_rounded,
    title: 'Quick value guide',
    body: 'Coins / Keys: int or long → 999999.\n'
        'Speed: float → 2.0–5.0 (above 5× may cause clipping).\n'
        'Unlocks / IAP: bool → true.\n'
        'Ad calls: void (early return) or bool → false.\n'
        'Gravity: float → 0.3–1.0 (0.0 freezes the player).\n'
        'NOP / Branch: use on specific condition checks you find in a disassembler.',
    color: Color(0xFF4ADE80),
  ),
];

const _modPatchSteps = [
  _Step(
    icon: Icons.android_rounded,
    title: 'Pick the original game APK',
    body: 'At the bottom of the feature list tap "Pick APK" and select the original '
        '(unmodified) game APK. Taurus Shield extracts libil2cpp.so from it directly — '
        'you do not need to extract it manually this time.',
    color: Color(0xFF4ADE80),
  ),
  _Step(
    icon: Icons.memory,
    title: 'Patch on-device (seconds)',
    body: 'Tap "Patch libil2cpp.so". Taurus Shield writes the ARM64 instructions at '
        'each selected offset entirely on your device — no cloud, no internet needed. '
        'Takes a few seconds. The patched file is saved to:\n'
        'Internal Storage › Taurus-Shield › output › mod-engine',
    color: _modCyan,
  ),
  _Step(
    icon: Icons.swap_horiz_rounded,
    title: 'Replace in APK with MT Manager',
    body: '1. Open the original APK in MT Manager.\n'
        '2. Navigate to  lib › arm64-v8a.\n'
        '3. Long-press libil2cpp.so → Replace → pick the patched .so file.\n'
        '4. Tap Sign in MT Manager to re-sign the APK.\n'
        '5. Install over the original game — done.',
    color: Color(0xFFf97316),
  ),
];

class _CloudNote extends StatelessWidget {
  const _CloudNote();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0a0a18),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF2a1040)),
      ),
      child: const Row(children: [
        Icon(Icons.cloud_done_rounded, color: Color(0xFF6b7280), size: 18),
        SizedBox(width: 10),
        Expanded(child: Text(
          'This tool runs on Taurus cloud infrastructure. '
          'An active internet connection is required. Results are saved to '
          'Internal Storage → Taurus-Shield → output.',
          style: TextStyle(color: Color(0xFF6b7280), fontSize: 11, height: 1.5),
        )),
      ]),
    );
  }
}

// ── Cocos2d-x Guide ───────────────────────────────────────────────────────────

const _cocosOrange = Color(0xFFF97316);

class _CocosGuide extends StatelessWidget {
  const _CocosGuide();

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: _cocosOrange.withOpacity(0.07),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _cocosOrange.withOpacity(0.25)),
          ),
          child: Row(children: [
            const Icon(Icons.gamepad_rounded, color: _cocosOrange, size: 16),
            const SizedBox(width: 8),
            const Expanded(child: Text(
              'Fully on-device — no cloud, no internet. Auto-detects Lua, JS, or '
              'Native C++ game type from the APK structure.',
              style: TextStyle(color: Color(0xFFd1d5db), fontSize: 11, height: 1.5),
            )),
          ]),
        ),
        const SizedBox(height: 18),

        _cocosSection(Icons.search_rounded, _cocosOrange, 'STEP 1 — DETECT', 'Pick APK — analyser detects game type'),
        const SizedBox(height: 8),
        ...[
          _CoStep(icon: Icons.android_rounded,     color: _cocosOrange,              title: 'Pick the game APK', body: 'Tap "Pick Game APK" and select any Cocos2d-x game from your storage.'),
          _CoStep(icon: Icons.auto_awesome_rounded, color: const Color(0xFF4ADE80), title: 'Auto-detection', body: 'The analyser scans assets/ for .luac / .jsc / .js files. If found → Lua or JS game. If none → Native C++ game.'),
        ].map(_cocosStepTile),
        const SizedBox(height: 18),

        _cocosSection(Icons.lock_open_rounded, const Color(0xFF4ADE80), 'LUA / JS PATH', 'Script games — most powerful'),
        const SizedBox(height: 8),
        ...[
          _CoStep(icon: Icons.key_rounded,          color: const Color(0xFFFBBF24), title: 'XXTEA key extraction', body: 'The encryption key is extracted directly from libcocos2dcpp.so by locating the sign prefix in script files and finding it in the binary.'),
          _CoStep(icon: Icons.lock_open_rounded,    color: const Color(0xFF4ADE80), title: 'Script decryption', body: 'All .luac / .jsc files are decrypted on-device using the extracted XXTEA key. Plain-text scripts are detected and shown as-is.'),
          _CoStep(icon: Icons.tune_rounded,         color: _cocosOrange,            title: 'Find & patch values', body: 'The analyser scans decrypted scripts for variables named after coins, health, speed etc. and scores them. Select the ones you want to change and type the new value.'),
          _CoStep(icon: Icons.folder_zip_outlined,  color: const Color(0xFF60A5FA), title: 'Repack on-device', body: 'Changed scripts are re-encrypted with the same key and repacked into a new APK entirely on-device. Sign with MT Manager and install.'),
        ].map(_cocosStepTile),
        const SizedBox(height: 18),

        _cocosSection(Icons.memory_rounded, _cocosOrange, 'NATIVE C++ PATH', 'Binary patching — same as IL2CPP'),
        const SizedBox(height: 8),
        ...[
          _CoStep(icon: Icons.list_alt_rounded,     color: const Color(0xFF818CF8), title: 'ELF symbol scan', body: 'The .dynsym section of libcocos2dcpp.so is parsed. Exported function names (if not stripped) are scored for game relevance.'),
          _CoStep(icon: Icons.text_fields_rounded,  color: const Color(0xFF4ADE80), title: 'String scan', body: 'All printable strings in the binary are extracted and scored. Strings like "not enough coins" point to nearby value functions.'),
          _CoStep(icon: Icons.memory_rounded,       color: _cocosOrange,            title: 'ARM64 binary patch', body: 'Select a symbol, choose patch type (bool/int/float/void/nop), enter the value. Taurus writes the ARM64 instructions into libcocos2dcpp.so at the exact file offset.'),
          _CoStep(icon: Icons.swap_horiz_rounded,   color: const Color(0xFF60A5FA), title: 'Replace via MT Manager', body: 'Open the original APK in MT Manager → navigate to lib/arm64-v8a → long-press libcocos2dcpp.so → Replace with the patched file → Sign → Install.'),
        ].map(_cocosStepTile),
        const SizedBox(height: 18),

        // Game type comparison
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: const Color(0xFF0D0A04),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _cocosOrange.withOpacity(0.15)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Icon(Icons.compare_arrows_rounded, color: _cocosOrange, size: 14),
              const SizedBox(width: 6),
              const Text('Game type comparison', style: TextStyle(
                color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
            ]),
            const SizedBox(height: 12),
            _cocosCompRow('Lua game',    const Color(0xFF4ADE80), 'BEST',   'Scripts readable → find any variable by name → full text edit → repack'),
            _cocosCompRow('JS game',     const Color(0xFFFBBF24), 'GREAT',  'Same as Lua — decrypt .jsc → edit JS → re-encrypt → repack APK'),
            _cocosCompRow('Native C++',  _cocosOrange,            'USABLE', 'No script names — use ELF symbols + strings to find offsets for ARM64 patch'),
          ]),
        ),
        const SizedBox(height: 14),

        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFF431407).withOpacity(0.3),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _cocosOrange.withOpacity(0.2)),
          ),
          child: const Row(children: [
            Icon(Icons.info_outline_rounded, color: _cocosOrange, size: 15),
            SizedBox(width: 8),
            Expanded(child: Text(
              'Output is saved to Internal Storage → Taurus-Shield → output → cocos → game_name. '
              'For Lua/JS: cocos_patched.apk. For Native: game_libcocos2dcpp_patched.so.',
              style: TextStyle(color: Color(0xFFd97706), fontSize: 11, height: 1.5),
            )),
          ]),
        ),
      ],
    );
  }

  static Widget _cocosSection(IconData icon, Color color, String title, String subtitle) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(0.25)),
      ),
      child: Row(children: [
        Icon(icon, color: color, size: 18),
        const SizedBox(width: 10),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: TextStyle(color: color, fontSize: 12,
            fontWeight: FontWeight.w900, letterSpacing: 1.2)),
          Text(subtitle, style: const TextStyle(color: Color(0xFF9ca3af), fontSize: 10)),
        ]),
      ]),
    );
  }

  static Widget _cocosStepTile(_CoStep s) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          width: 30, height: 30,
          decoration: BoxDecoration(
            color: s.color.withOpacity(0.12),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: s.color.withOpacity(0.35)),
          ),
          child: Icon(s.icon, color: s.color, size: 14),
        ),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(s.title, style: const TextStyle(
            color: Colors.white, fontSize: 11.5, fontWeight: FontWeight.w700)),
          const SizedBox(height: 2),
          Text(s.body, style: const TextStyle(
            color: Color(0xFF9ca3af), fontSize: 10.5, height: 1.5)),
        ])),
      ]),
    );
  }

  static Widget _cocosCompRow(String label, Color color, String badge, String desc) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
          decoration: BoxDecoration(
            color: color.withOpacity(0.12),
            borderRadius: BorderRadius.circular(5),
            border: Border.all(color: color.withOpacity(0.35)),
          ),
          child: Text(badge, style: TextStyle(
            color: color, fontSize: 9, fontWeight: FontWeight.w800)),
        ),
        const SizedBox(width: 8),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w700)),
          const SizedBox(height: 1),
          Text(desc, style: const TextStyle(color: Color(0xFF9ca3af), fontSize: 10, height: 1.4)),
        ])),
      ]),
    );
  }
}

class _CoStep {
  final IconData icon;
  final Color    color;
  final String   title;
  final String   body;
  const _CoStep({required this.icon, required this.color, required this.title, required this.body});
}
