import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:package_info_plus/package_info_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../screens/update_screen.dart';
import 'native_secrets.dart';

class UpdateService {
  UpdateService._();

  static String? _workerUrl;
  static String? _deviceId;

  static Future<void> init() async {
    _deviceId  = await _getOrCreateDeviceId();
    _workerUrl = await NativeSecrets.updaterUrl();
  }

  static Future<void> checkAndPrompt(BuildContext context) async {
    try {
      final info = await PackageInfo.fromPlatform();
      final versionCode = int.tryParse(info.buildNumber) ?? 0;

      await _sendHeartbeat(info.version);

      final res = await http.get(
        Uri.parse('$_workerUrl/check-update?version_code=$versionCode'),
      ).timeout(const Duration(seconds: 10));

      if (res.statusCode != 200) return;
      final data = jsonDecode(res.body) as Map<String, dynamic>;

      if (data['has_update'] == true && context.mounted) {
        Navigator.of(context).push(
          PageRouteBuilder(
            opaque: true,
            barrierDismissible: false,
            pageBuilder: (_, __, ___) => UpdateScreen(
              apkUrl: data['apk_url']?.toString() ?? '',
              versionName: data['version_name']?.toString() ?? '',
              changelog: data['changelog']?.toString() ?? '',
              updateSize: data['update_size']?.toString() ?? '',
              force: data['force_update'] == true,
            ),
            transitionsBuilder: (_, anim, __, child) =>
                FadeTransition(opacity: anim, child: child),
            transitionDuration: const Duration(milliseconds: 150),
          ),
        );
      }

      await _checkNotification();
    } catch (_) {}
  }

  static Future<void> _sendHeartbeat(String appVersion) async {
    try {
      await http.post(
        Uri.parse('$_workerUrl/devices/heartbeat'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'device_id': _deviceId, 'app_version': appVersion}),
      ).timeout(const Duration(seconds: 8));
    } catch (_) {}
  }

  static Future<void> _checkNotification() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final lastId = prefs.getInt('last_notif_id') ?? 0;

      if (lastId == 0) {
        final maxRes = await http.get(
          Uri.parse('$_workerUrl/notifications/max-id'),
        ).timeout(const Duration(seconds: 8));
        if (maxRes.statusCode == 200) {
          final maxData = jsonDecode(maxRes.body) as Map<String, dynamic>;
          await prefs.setInt('last_notif_id', (maxData['max_id'] as int?) ?? 0);
        }
        return;
      }

      final res = await http.get(
        Uri.parse('$_workerUrl/notifications/latest?last_id=$lastId'),
      ).timeout(const Duration(seconds: 8));

      if (res.statusCode != 200) return;
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['has_notification'] == true) {
        final id = data['id'] as int;
        await prefs.setInt('last_notif_id', id);
        _pendingNotif = (
          title: data['title']?.toString() ?? 'Taurus Shield',
          body: data['body']?.toString() ?? '',
        );
      }
    } catch (_) {}
  }

  static ({String title, String body})? _pendingNotif;

  static void showPendingNotification(BuildContext context) {
    final notif = _pendingNotif;
    if (notif == null || !context.mounted) return;
    _pendingNotif = null;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(notif.title,
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 13)),
            if (notif.body.isNotEmpty)
              Text(notif.body,
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.75), fontSize: 12)),
          ],
        ),
        backgroundColor: const Color(0xFF1a0a30),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.all(12),
        duration: const Duration(seconds: 5),
      ),
    );
  }

  static Future<String> _getOrCreateDeviceId() async {
    // Use the real Android ID (unique per device + app signing key, stable across reinstalls)
    final androidId = await NativeSecrets.androidId();
    if (androidId.isNotEmpty) return androidId;

    // Fallback: persist a random ID if Android ID is somehow unavailable
    final prefs = await SharedPreferences.getInstance();
    var id = prefs.getString('taurus_device_uuid');
    if (id != null && id.isNotEmpty) return id;
    final bytes = List<int>.generate(
        16, (_) => DateTime.now().microsecondsSinceEpoch & 0xFF);
    id = bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
    await prefs.setString('taurus_device_uuid', id);
    return id;
  }
}
