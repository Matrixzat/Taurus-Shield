import 'package:flutter/services.dart';

class NativeSecrets {
  static const _ch = MethodChannel('com.taurus.shield/secrets');

  static Future<String> workerUrl() async {
    try {
      return await _ch
              .invokeMethod<String>('getWorkerUrl')
              .timeout(const Duration(seconds: 5)) ??
          '';
    } catch (_) {
      return '';
    }
  }

  static Future<String> updaterUrl() async {
    try {
      return await _ch
              .invokeMethod<String>('getUpdaterUrl')
              .timeout(const Duration(seconds: 5)) ??
          '';
    } catch (_) {
      return '';
    }
  }

  static Future<String> androidId() async {
    try {
      return await _ch
              .invokeMethod<String>('getAndroidId')
              .timeout(const Duration(seconds: 5)) ??
          '';
    } catch (_) {
      return '';
    }
  }
}
