import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

typedef ProgressCb = void Function(int sent, int total);

class CancelledException implements Exception {
  const CancelledException();
  @override
  String toString() => 'Upload cancelled';
}

class CancelToken {
  bool _cancelled = false;
  HttpClient? _client;
  bool get isCancelled => _cancelled;
  void cancel() {
    _cancelled = true;
    try { _client?.close(force: true); } catch (_) {}
  }
  void reset() {
    _cancelled = false;
    _client = null;
  }
}

class UploadResult {
  final String url;
  final String hostName;
  final String expiryNote;
  const UploadResult(this.url, this.hostName, this.expiryNote);
}

class TempHost {
  final String name;
  final String expiryNote;
  final int maxBytes;
  final Future<String> Function(File f, ProgressCb p, CancelToken t) _impl;
  const TempHost(this.name, this.expiryNote, this.maxBytes, this._impl);
  Future<String> upload(File f, ProgressCb p, CancelToken t) => _impl(f, p, t);
}

class UploadHosts {
  static const _kInf = 1 << 62;

  static final List<TempHost> all = [
    TempHost('Litterbox', 'stays online 72 hours', 1024 * 1024 * 1024,
        _uploadLitterbox),
    TempHost('filebin.net', 'stays online 7 days', 5 * 1024 * 1024 * 1024,
        _uploadFilebin),
    TempHost('qu.ax', 'stays online ~30 days', 256 * 1024 * 1024, _uploadQuAx),
    TempHost('x0.at', 'stays online up to 100 days (size-dependent)',
        1024 * 1024 * 1024, _uploadX0at),
    TempHost('uguu.se', 'stays online 3 hours', 128 * 1024 * 1024, _uploadUguu),
    TempHost('tmpfiles.org', 'stays online about 60 minutes',
        100 * 1024 * 1024, _uploadTmpFiles),
  ];

  /// Tries every host in order, skipping those whose maxBytes is too small.
  /// onHostStart is called with the host name each time a new attempt begins.
  static Future<UploadResult> dispatch(
    File file, {
    required ProgressCb onProgress,
    required void Function(String hostName) onHostStart,
    required CancelToken token,
  }) async {
    final size = await file.length();
    final errors = <String>[];
    for (final host in all) {
      if (token.isCancelled) throw const CancelledException();
      if (size > host.maxBytes) {
        errors.add('${host.name}: file too large');
        continue;
      }
      onHostStart(host.name);
      try {
        final url = await host.upload(file, onProgress, token);
        return UploadResult(url, host.name, host.expiryNote);
      } on CancelledException {
        rethrow;
      } catch (e) {
        // If the user cancelled mid-flight the underlying HTTP error is
        // typically a generic SocketException — treat it as cancellation.
        if (token.isCancelled) throw const CancelledException();
        errors.add('${host.name}: $e');
        continue;
      }
    }
    if (token.isCancelled) throw const CancelledException();
    throw Exception('All hosts failed:\n${errors.join('\n')}');
  }
}

// ─── multipart helper with byte-level progress ─────────────────────────────

Future<String> _multipart({
  required Uri url,
  Map<String, String> fields = const {},
  required File file,
  required String fileField,
  String mime = 'application/octet-stream',
  Map<String, String> headers = const {},
  required ProgressCb onProgress,
  required CancelToken token,
}) async {
  final boundary =
      '----TaurusShield${DateTime.now().millisecondsSinceEpoch}${math.Random().nextInt(1 << 30)}';
  final client = HttpClient()
    ..connectionTimeout = const Duration(seconds: 30)
    ..idleTimeout = const Duration(seconds: 60);
  token._client = client;
  try {
    final req = await client.postUrl(url);
    req.headers.set(
        HttpHeaders.contentTypeHeader, 'multipart/form-data; boundary=$boundary');
    headers.forEach(req.headers.set);

    final prologue = StringBuffer();
    fields.forEach((k, v) {
      prologue
        ..write('--$boundary\r\n')
        ..write('Content-Disposition: form-data; name="$k"\r\n\r\n')
        ..write(v)
        ..write('\r\n');
    });
    final fileName = file.uri.pathSegments.isNotEmpty
        ? file.uri.pathSegments.last
        : 'file.bin';
    prologue
      ..write('--$boundary\r\n')
      ..write(
          'Content-Disposition: form-data; name="$fileField"; filename="$fileName"\r\n')
      ..write('Content-Type: $mime\r\n\r\n');
    final prologueBytes = utf8.encode(prologue.toString());
    final epilogueBytes = utf8.encode('\r\n--$boundary--\r\n');

    final fileLen = await file.length();
    final total = prologueBytes.length + fileLen + epilogueBytes.length;
    req.contentLength = total;

    int sent = 0;
    int lastEmit = 0;
    void tick(int n) {
      sent += n;
      final now = DateTime.now().millisecondsSinceEpoch;
      if (now - lastEmit >= 200 || sent >= total) {
        lastEmit = now;
        onProgress(sent, total);
      }
    }

    req.add(prologueBytes);
    tick(prologueBytes.length);

    await for (final chunk in file.openRead()) {
      if (token.isCancelled) throw const CancelledException();
      req.add(chunk);
      tick(chunk.length);
      await req.flush();
    }

    req.add(epilogueBytes);
    tick(epilogueBytes.length);

    final resp = await req.close();
    final body = await utf8.decoder.bind(resp).join();
    if (resp.statusCode < 200 || resp.statusCode >= 300) {
      throw 'HTTP ${resp.statusCode} — ${body.substring(0, math.min(120, body.length))}';
    }
    return body;
  } finally {
    token._client = null;
    client.close();
  }
}

Future<String> _binaryPost({
  required Uri url,
  required File file,
  String mime = 'application/octet-stream',
  Map<String, String> headers = const {},
  required ProgressCb onProgress,
  required CancelToken token,
}) async {
  final client = HttpClient()
    ..connectionTimeout = const Duration(seconds: 30)
    ..idleTimeout = const Duration(seconds: 60);
  token._client = client;
  try {
    final req = await client.postUrl(url);
    req.headers.set(HttpHeaders.contentTypeHeader, mime);
    headers.forEach(req.headers.set);
    final total = await file.length();
    req.contentLength = total;

    int sent = 0;
    int lastEmit = 0;
    void tick(int n) {
      sent += n;
      final now = DateTime.now().millisecondsSinceEpoch;
      if (now - lastEmit >= 200 || sent >= total) {
        lastEmit = now;
        onProgress(sent, total);
      }
    }

    await for (final chunk in file.openRead()) {
      if (token.isCancelled) throw const CancelledException();
      req.add(chunk);
      tick(chunk.length);
      await req.flush();
    }
    final resp = await req.close();
    final body = await utf8.decoder.bind(resp).join();
    if (resp.statusCode < 200 || resp.statusCode >= 300) {
      throw 'HTTP ${resp.statusCode}';
    }
    return body;
  } finally {
    token._client = null;
    client.close();
  }
}

// ─── individual host implementations ───────────────────────────────────────

Future<String> _uploadLitterbox(File f, ProgressCb p, CancelToken t) async {
  final body = await _multipart(
    url: Uri.parse('https://litterbox.catbox.moe/resources/internals/api.php'),
    fields: const {'reqtype': 'fileupload', 'time': '72h'},
    file: f,
    fileField: 'fileToUpload',
    onProgress: p,
    token: t,
  );
  final s = body.trim();
  if (!s.startsWith('http')) throw 'Litterbox: $s';
  return s;
}

Future<String> _uploadFilebin(File f, ProgressCb p, CancelToken t) async {
  final bin = 'tx${_randomHex(14)}';
  final safeName = Uri.encodeComponent(f.uri.pathSegments.last);
  await _binaryPost(
    url: Uri.parse('https://filebin.net/$bin/$safeName'),
    file: f,
    headers: const {'accept': 'application/json'},
    onProgress: p,
    token: t,
  );
  return 'https://filebin.net/$bin/$safeName';
}

Future<String> _uploadQuAx(File f, ProgressCb p, CancelToken t) async {
  final body = await _multipart(
    url: Uri.parse('https://qu.ax/upload.php'),
    file: f,
    fileField: 'files[]',
    onProgress: p,
    token: t,
  );
  final j = jsonDecode(body) as Map<String, dynamic>;
  if (j['success'] != true) throw 'qu.ax: not successful';
  final files = j['files'] as List;
  return (files.first as Map)['url'].toString();
}

Future<String> _uploadX0at(File f, ProgressCb p, CancelToken t) async {
  final body = await _multipart(
    url: Uri.parse('https://x0.at'),
    file: f,
    fileField: 'file',
    onProgress: p,
    token: t,
  );
  final s = body.trim();
  if (!s.startsWith('http')) throw 'x0.at: $s';
  return s;
}

Future<String> _uploadUguu(File f, ProgressCb p, CancelToken t) async {
  final body = await _multipart(
    url: Uri.parse('https://uguu.se/upload.php'),
    file: f,
    fileField: 'files[]',
    onProgress: p,
    token: t,
  );
  final j = jsonDecode(body) as Map<String, dynamic>;
  if (j['success'] != true) throw 'uguu.se: not successful';
  final files = j['files'] as List;
  return (files.first as Map)['url'].toString();
}

Future<String> _uploadTmpFiles(File f, ProgressCb p, CancelToken t) async {
  final body = await _multipart(
    url: Uri.parse('https://tmpfiles.org/api/v1/upload'),
    file: f,
    fileField: 'file',
    onProgress: p,
    token: t,
  );
  final j = jsonDecode(body) as Map<String, dynamic>;
  if (j['status'] != 'success') throw 'tmpfiles: status not success';
  final url = (j['data'] as Map)['url'].toString();
  return url.replaceFirst('tmpfiles.org/', 'tmpfiles.org/dl/');
}

String _randomHex(int n) {
  final r = math.Random.secure();
  final buf = StringBuffer();
  while (buf.length < n) {
    buf.write(r.nextInt(1 << 32).toRadixString(16).padLeft(8, '0'));
  }
  return buf.toString().substring(0, n);
}
