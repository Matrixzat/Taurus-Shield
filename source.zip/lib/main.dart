import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'screens/tool_selection_screen.dart';
import 'utils/notification_helper.dart';
import 'services/update_service.dart';
import 'utils/theme_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await UpdateService.init();
  await ThemeProvider().load();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  runApp(const HbcToolApp());
}

class HbcToolApp extends StatefulWidget {
  const HbcToolApp({super.key});

  @override
  State<HbcToolApp> createState() => _HbcToolAppState();
}

class _HbcToolAppState extends State<HbcToolApp> {
  @override
  void initState() {
    super.initState();
    ThemeProvider().addListener(_onThemeChange);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      NotificationHelper.requestPermission();
    });
  }

  void _onThemeChange() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    ThemeProvider().removeListener(_onThemeChange);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Taurus Shield',
      debugShowCheckedModeBanner: false,
      theme: ThemeProvider().current.toThemeData(),
      home: const ToolSelectionScreen(),
    );
  }
}
