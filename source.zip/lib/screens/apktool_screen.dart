import '../utils/theme_provider.dart';
import '../widgets/guide_modal.dart';
import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:archive/archive.dart';
import '../utils/hbc_channel.dart';
import '../utils/storage_helper.dart';
import '../utils/permission_helper.dart';

const _kApkAccent      = Color(0xFF3b82f6);
const _kApkAccentLight = Color(0xFF60a5fa);

class ApkToolScreen extends StatefulWidget {
  const ApkToolScreen({super.key});
  @override
  State<ApkToolScreen> createState() => _ApkToolScreenState();
}

class _ApkToolScreenState extends State<ApkToolScreen>
    with TickerProviderStateMixin {
  String? _selectedFilePath;
  String? _selectedFileName;
  bool    _isProcessing     = false;
  bool    _logVisible       = false;
  String  _logs             = '';
  String? _outputDir;
  int     _downloadProgress = -1;
  bool    _autoScroll       = true;
  String? _fileStatus;
  bool    _fileValid        = false;
  String  _detectedMode     = '';
  bool    _signApk          = false;
  StreamSubscription<String>? _streamSub;
  final Stopwatch _stopwatch  = Stopwatch();
  Timer?  _tickTimer;
  String  _elapsed           = '00:00';
  final ScrollController _logScrollCtrl  = ScrollController();
  final ScrollController _pageScrollCtrl = ScrollController();
  final GlobalKey        _logPanelKey    = GlobalKey();

  late final AnimationController _pulseCtrl;
  late final AnimationController _orbitCtrl;
  late final AnimationController _scanCtrl;
  late final AnimationController _logCtrl;
  late final Animation<double>   _pulseAnim;
  late final Animation<double>   _logFade;

  static const _accent      = _kApkAccent;
  static const _accentLight = _kApkAccentLight;

  @override
  void initState() {
    super.initState();

    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _orbitCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 4500),
    )..repeat();

    _scanCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2400),
    )..repeat();

    _logCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 400),
    );

    _pulseAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
    _logFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _logCtrl, curve: Curves.easeOut),
    );

    _checkCloudState();
  }

  Timer? _pollTimer;

  Future<void> _checkCloudState() async {
    try {
      final state     = await HbcChannel.apkToolCloudState();
      final running   = state['running'] == true;
      final status    = (state['status'] as String?) ?? '';
      final logs      = (state['logs']   as String?) ?? '';
      final filePath  = (state['filePath']  as String?) ?? '';
      final outputDir = (state['outputDir'] as String?) ?? '';
      final mode      = (state['mode'] as String?) ?? 'decompile';

      if (running && mounted) {
        setState(() {
          _isProcessing     = true;
          _logVisible       = true;
          _logs             = logs;
          _detectedMode     = mode;
          _selectedFilePath = filePath.isNotEmpty ? filePath : _selectedFilePath;
          _selectedFileName = filePath.isNotEmpty ? filePath.split('/').last : _selectedFileName;
        });
        _logCtrl.forward(from: 0);
        if (!_stopwatch.isRunning) _startTimer();
        _startPollingCloudState();
      } else if (status == 'success' && mounted) {
        setState(() {
          _isProcessing = false;
          _logVisible   = true;
          _logs         = logs;
          _outputDir    = outputDir.isNotEmpty ? outputDir : null;
          _detectedMode = mode;
          _selectedFilePath = filePath.isNotEmpty ? filePath : _selectedFilePath;
          _selectedFileName = filePath.isNotEmpty ? filePath.split('/').last : _selectedFileName;
        });
        _logCtrl.forward(from: 0);
        _showSnack('Operation complete',
            icon: Icons.check_circle_rounded, color: const Color(0xFF22c55e));
      } else if (status == 'cancelled' && mounted) {
        setState(() {
          _isProcessing = false;
          _logVisible   = true;
          _logs         = logs;
          _detectedMode = mode;
        });
        _logCtrl.forward(from: 0);
        _showSnack('Operation cancelled',
            icon: Icons.cancel_outlined, color: const Color(0xFFf59e0b));
      } else if (status == 'error' && logs.isNotEmpty && mounted) {
        final error = (state['error'] as String?) ?? 'Operation failed';
        setState(() {
          _isProcessing = false;
          _logVisible   = true;
          _logs         = logs;
          _detectedMode = mode;
        });
        _logCtrl.forward(from: 0);
        _showSnack(error, icon: Icons.error_rounded, color: const Color(0xFFef4444));
      }
    } catch (_) {}
  }

  void _startPollingCloudState() {
    _pollTimer?.cancel();
    _streamSub?.cancel();

    _streamSub = HbcChannel.logStream.listen((line) {
      if (!mounted) return;
      if (line.startsWith('DOWNLOAD_PROGRESS:')) {
        final pct = int.tryParse(line.substring('DOWNLOAD_PROGRESS:'.length)) ?? -1;
        setState(() { _downloadProgress = pct; });
        return;
      }
      if (line == '__TAURUS_DONE__') {
        _pollTimer?.cancel();
        _checkCloudState();
        return;
      }
      setState(() { _logs += '$line\n'; });
      if (_autoScroll) _scrollLogToBottom();
    });

    int consecutiveErrors = 0;
    const maxErrors = 5;

    _pollTimer = Timer.periodic(const Duration(seconds: 25), (_) async {
      try {
        final state     = await HbcChannel.apkToolCloudState();
        final running   = state['running'] == true;
        final status    = (state['status'] as String?) ?? '';
        final logs      = (state['logs']   as String?) ?? '';
        final outputDir = (state['outputDir'] as String?) ?? '';
        consecutiveErrors = 0;

        if (logs.isNotEmpty && mounted) {
          setState(() { _logs = logs; });
          if (_autoScroll) _scrollLogToBottom();
        }

        if (!running) {
          _pollTimer?.cancel();
          _streamSub?.cancel();
          final success   = status == 'success';
          final cancelled = status == 'cancelled';
          final totalTime = _stopTimer();

          if (mounted) {
            setState(() {
              _isProcessing     = false;
              _logs             = logs;
              _outputDir        = outputDir.isNotEmpty ? outputDir : null;
              _downloadProgress = -1;
              if (cancelled) {
                _logs += '\nCancelled by user.\n';
              } else {
                _logs += '\n${success ? "Completed" : "Failed"} in $totalTime\n';
              }
            });
            if (cancelled) {
              _showSnack('Operation cancelled',
                  icon: Icons.cancel_outlined, color: const Color(0xFFf59e0b));
            } else {
              _showSnack(
                success ? 'Operation complete — $totalTime' : 'Operation failed',
                icon: success ? Icons.check_circle_rounded : Icons.error_rounded,
                color: success ? const Color(0xFF22c55e) : const Color(0xFFef4444),
              );
            }
          }
          return;
        }
      } catch (_) {
        consecutiveErrors++;
        if (consecutiveErrors >= maxErrors && mounted) {
          _pollTimer?.cancel();
          _streamSub?.cancel();
          _stopTimer();
          setState(() {
            _isProcessing     = false;
            _downloadProgress = -1;
            _logs += '\nLost connection to processing service after $maxErrors attempts.\n';
          });
          _showSnack('Connection lost — check service status',
              icon: Icons.error_rounded, color: const Color(0xFFef4444));
        }
      }
    });
  }

  void _startTimer() {
    _stopwatch.reset();
    _stopwatch.start();
    _tickTimer?.cancel();
    _tickTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      final e = _stopwatch.elapsed;
      setState(() {
        _elapsed = '${e.inMinutes.toString().padLeft(2, '0')}:'
            '${(e.inSeconds % 60).toString().padLeft(2, '0')}';
      });
    });
  }

  String _stopTimer() {
    _tickTimer?.cancel();
    _stopwatch.stop();
    final e = _stopwatch.elapsed;
    final t = e.inSeconds < 60
        ? '${e.inSeconds}s'
        : '${e.inMinutes}m ${e.inSeconds % 60}s';
    setState(() { _elapsed = '00:00'; });
    return t;
  }

  void _scrollLogToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_logScrollCtrl.hasClients) {
        _logScrollCtrl.animateTo(
          _logScrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _showSnack(String msg, {required IconData icon, required Color color}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(icon, color: color, size: 18),
        const SizedBox(width: 10),
        Expanded(child: Text(msg, style: const TextStyle(color: Colors.white))),
      ]),
      backgroundColor: const Color(0xFF1a1a2e),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: color.withOpacity(0.4)),
      ),
      behavior: SnackBarBehavior.floating,
      duration: const Duration(seconds: 4),
    ));
  }

  Future<void> _pickFile() async {
    final hasPermission = await PermissionHelper.ensureStorage(
        context, accent: _accent);
    if (!hasPermission) return;

    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['apk', 'zip'],
      allowMultiple: false,
    );
    if (result == null || result.files.isEmpty) return;

    final picked = result.files.first;
    final path   = picked.path;
    if (path == null) return;

    final file   = File(path);
    final sizeMb = file.lengthSync() / 1048576.0;
    if (sizeMb > 100) {
      setState(() {
        _selectedFilePath = path;
        _selectedFileName = picked.name;
        _fileStatus  = 'File too large (${sizeMb.toStringAsFixed(1)} MB) — 100 MB limit';
        _fileValid   = false;
        _detectedMode = '';
      });
      return;
    }

    final ext = picked.name.toLowerCase();

    if (ext.endsWith('.apk')) {
      setState(() {
        _selectedFilePath = path;
        _selectedFileName = picked.name;
        _detectedMode     = 'decompile';
        _fileStatus       = 'APK detected — will Decompile';
        _fileValid        = true;
      });
      return;
    }

    // ZIP — scan contents to determine mode
    setState(() {
      _selectedFilePath = path;
      _selectedFileName = picked.name;
      _fileStatus       = 'Scanning ZIP...';
      _fileValid        = false;
      _detectedMode     = '';
    });

    try {
      final bytes   = file.readAsBytesSync();
      final archive = ZipDecoder().decodeBytes(bytes);
      final names   = archive.files.map((f) => f.name.toLowerCase()).toSet();

      final hasApktoolYml  = names.any((n) => n == 'apktool.yml' || n.endsWith('/apktool.yml'));
      final hasManifest    = names.any((n) => n.endsWith('androidmanifest.xml'));
      final hasSmali       = names.any((n) => n.contains('smali'));

      if (hasApktoolYml || (hasManifest && hasSmali)) {
        setState(() {
          _detectedMode = 'recompile';
          _fileStatus   = 'apktool project detected — will Recompile';
          _fileValid    = true;
        });
      } else {
        setState(() {
          _detectedMode = '';
          _fileStatus   = 'ZIP does not look like an apktool project.\nExpected: apktool.yml or smali/ + AndroidManifest.xml';
          _fileValid    = false;
        });
      }
    } catch (_) {
      setState(() {
        _fileStatus   = 'Could not read ZIP file — it may be corrupt';
        _fileValid    = false;
        _detectedMode = '';
      });
    }
  }

  Future<void> _runOperation() async {
    if (!_fileValid || _selectedFilePath == null || _detectedMode.isEmpty) return;

    final hasPermission = await PermissionHelper.ensureStorage(
        context, accent: _accent);
    if (!hasPermission) return;

    final outputDir = await StorageHelper.buildOutputDir(prefix: 'apktool');

    setState(() {
      _isProcessing     = true;
      _logVisible       = true;
      _logs             = '';
      _outputDir        = null;
      _downloadProgress = -1;
    });
    _logCtrl.forward(from: 0);
    _startTimer();

    try {
      final result = await HbcChannel.apkToolAnalyze(
        filePath:  _selectedFilePath!,
        fileName:  _selectedFileName ?? _selectedFilePath!.split('/').last,
        outputDir: outputDir,
        mode:      _detectedMode,
        signApk:   _signApk,
      );

      if (result['started'] != true) {
        final msg = (result['error'] as String?) ?? 'Could not start operation';
        setState(() { _isProcessing = false; });
        _stopTimer();
        _showSnack(msg, icon: Icons.error_rounded, color: const Color(0xFFef4444));
        return;
      }

      _startPollingCloudState();
    } catch (e) {
      setState(() { _isProcessing = false; });
      _stopTimer();
      _showSnack('Failed to start: $e',
          icon: Icons.error_rounded, color: const Color(0xFFef4444));
    }
  }

  Future<void> _cancelOperation() async {
    _pollTimer?.cancel();
    _tickTimer?.cancel();
    _streamSub?.cancel();
    await HbcChannel.apkToolCancel();
    if (!mounted) return;
    setState(() { _isProcessing = false; });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Operation cancelled'),
        backgroundColor: Color(0xFF7f1d1d),
        duration: Duration(seconds: 3),
      ),
    );
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _streamSub?.cancel();
    _tickTimer?.cancel();
    _pulseCtrl.dispose();
    _orbitCtrl.dispose();
    _scanCtrl.dispose();
    _logCtrl.dispose();
    _logScrollCtrl.dispose();
    _pageScrollCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => true,
      child: Scaffold(
        
        body: SafeArea(
          child: Column(
            children: [
              _buildTopBar(),
              Expanded(
                child: SingleChildScrollView(
                  controller: _pageScrollCtrl,
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const SizedBox(height: 12),
                      _buildHeader(),
                      const SizedBox(height: 18),
                      _buildFileSelector(),
                      const SizedBox(height: 10),
                      _buildModeAndOptions(),
                      const SizedBox(height: 14),
                      _buildActionRow(),
                      if (_logVisible) ...[
                        const SizedBox(height: 16),
                        _buildLogPanel(),
                      ],
                      if (_outputDir != null && !_isProcessing) ...[
                        const SizedBox(height: 16),
                        _buildOutputCard(),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 8, 16, 4),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_rounded,
                color: Colors.white, size: 20),
            onPressed: () => Navigator.pop(context),
          ),
          const Expanded(
            child: Text('APK Tool',
                style: TextStyle(
                    color: Colors.white, fontSize: 18,
                    fontWeight: FontWeight.w800, letterSpacing: 0.5)),
          ),
          if (_isProcessing)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: _accent.withOpacity(0.15),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _accent.withOpacity(0.4)),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                SizedBox(
                  width: 10, height: 10,
                  child: CircularProgressIndicator(
                      strokeWidth: 1.5, color: _accent),
                ),
                const SizedBox(width: 6),
                Text(_elapsed,
                    style: TextStyle(
                        color: _accent, fontSize: 11,
                        fontFamily: 'monospace')),
              ]),
            ),
          if (!_isProcessing && _outputDir != null)
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: _accent.withOpacity(0.15),
                foregroundColor: _accent,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20)),
                side: BorderSide(color: _accent.withOpacity(0.4)),
                padding: const EdgeInsets.symmetric(
                    horizontal: 14, vertical: 6),
                elevation: 0,
              ),
              onPressed: () => Navigator.pop(context),
              child: Text(_isProcessing ? 'Leave (keeps running)' : 'Leave'),
            ),
          IconButton(
            icon: const Icon(Icons.menu_book_rounded, color: Colors.white54, size: 20),
            tooltip: 'How to Use',
            onPressed: () => showGuideModal(context, initialIndex: 5, singleTool: true),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return AnimatedBuilder(
      animation: Listenable.merge([_pulseAnim, _orbitCtrl, _scanCtrl]),
      builder: (_, __) {
        final pulse = _pulseAnim.value;
        final orbit = _orbitCtrl.value;
        final scan  = _scanCtrl.value;

        final scanOpacity = scan < 0.5
            ? (scan * 2).clamp(0.0, 1.0)
            : ((1.0 - scan) * 2).clamp(0.0, 1.0);
        final scanY = scan * 64.0;

        return Container(
          padding: const EdgeInsets.fromLTRB(16, 18, 16, 18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(
              colors: [Color(0xFF080e1e), Color(0xFF0a1228), Color(0xFF080e1e)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            border: Border.all(
              color: Color.lerp(
                _accent.withOpacity(0.25),
                _accentLight.withOpacity(0.20),
                pulse,
              )!,
            ),
            boxShadow: [
              BoxShadow(
                color: _accent.withOpacity(0.05 + pulse * 0.06),
                blurRadius: 24, spreadRadius: 2,
              ),
            ],
          ),
          child: Row(
            children: [
              SizedBox(
                width: 96, height: 96,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Container(
                      width: 90 + pulse * 6,
                      height: 90 + pulse * 6,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: _accent.withOpacity(0.08 + pulse * 0.08),
                          width: 1,
                        ),
                      ),
                    ),
                    Transform.rotate(
                      angle: orbit * 2 * math.pi,
                      child: CustomPaint(
                        size: const Size(80, 80),
                        painter: _ApkOrbitPainter(
                          color: _accent,
                          opacity: 0.45 + pulse * 0.25,
                        ),
                      ),
                    ),
                    Transform.rotate(
                      angle: -orbit * 2 * math.pi * 0.6,
                      child: CustomPaint(
                        size: const Size(62, 62),
                        painter: _ApkDotPainter(
                          color: _accentLight,
                          opacity: 0.30 + pulse * 0.20,
                        ),
                      ),
                    ),
                    Transform.scale(
                      scale: 1.0 + pulse * 0.03,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(18),
                        child: Stack(
                          children: [
                            Container(
                              width: 64, height: 64,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Color.lerp(const Color(0xFF1a3a6a),
                                        const Color(0xFF1e4a7a), pulse)!,
                                    const Color(0xFF080e2a),
                                  ],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: _accent
                                        .withOpacity(0.25 + pulse * 0.20),
                                    blurRadius: 18, spreadRadius: 1,
                                  ),
                                ],
                              ),
                              child: Icon(Icons.android_rounded,
                                  color: _accent, size: 32),
                            ),
                            Positioned(
                              top: scanY - 2, left: 0, right: 0,
                              child: Opacity(
                                opacity: scanOpacity * 0.6,
                                child: Container(
                                  height: 2,
                                  decoration: const BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [
                                        Colors.transparent,
                                        Color(0xFF60a5fa),
                                        Colors.transparent,
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ShaderMask(
                      shaderCallback: (bounds) => LinearGradient(
                        colors: [
                          Colors.white,
                          Color.lerp(const Color(0xFFffffff),
                              const Color(0xFF93c5fd), pulse)!,
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ).createShader(bounds),
                      child: const Text(
                        'APK Tool',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'Decompile · Recompile APK',
                      style: TextStyle(
                        color: _accentLight,
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 6, runSpacing: 4,
                      children: const [
                        _HeaderChip('.apk'),
                        _HeaderChip('.zip'),
                        _HeaderChip('apktool'),
                        _HeaderChip('smali'),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        _LiveDot(color: _accent),
                        const SizedBox(width: 5),
                        const Text(
                          'apktool 2.x  ·  smali/baksmali',
                          style: TextStyle(
                            fontSize: 10,
                            color: Color(0xFF6b7280),
                            letterSpacing: 0.3,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildFileSelector() {
    final hasFile = _selectedFileName != null;
    return GestureDetector(
      onTap: _isProcessing ? null : _pickFile,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: const Color(0xFF111122),
          border: Border.all(
            color: hasFile
                ? (_fileValid
                    ? _accent.withOpacity(0.35)
                    : Color(0xFFef4444).withOpacity(0.4))
                : ThemeProvider().current.surfaceColor,
          ),
        ),
        child: Row(children: [
          Icon(
            hasFile ? Icons.android_rounded : Icons.upload_file_rounded,
            color: hasFile
                ? (_fileValid ? _accent : const Color(0xFFef4444))
                : const Color(0xFF4b5563),
            size: 28,
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(
                hasFile ? _selectedFileName! : 'Select APK or ZIP file',
                style: TextStyle(
                    color: hasFile ? Colors.white : const Color(0xFF6b7280),
                    fontSize: 14, fontWeight: FontWeight.w600),
                overflow: TextOverflow.ellipsis,
              ),
              if (hasFile && _selectedFilePath != null)
                Text(_selectedFilePath!,
                    style: const TextStyle(
                        color: Color(0xFF4b5563), fontSize: 10),
                    overflow: TextOverflow.ellipsis),
              if (!hasFile)
                const Text(
                  'APK → Decompile  |  ZIP → Recompile  |  Max 100 MB',
                  style: TextStyle(color: Color(0xFF4b5563), fontSize: 10),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              if (hasFile && _fileStatus != null)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(
                    _fileStatus!,
                    style: TextStyle(
                      color: _fileValid
                          ? _accentLight
                          : const Color(0xFFf87171),
                      fontSize: 10.5,
                    ),
                  ),
                ),
            ]),
          ),
          Icon(
            _isProcessing ? Icons.lock_rounded : Icons.chevron_right_rounded,
            color: const Color(0xFF4b5563), size: 20,
          ),
        ]),
      ),
    );
  }

  Widget _buildModeAndOptions() {
    if (_detectedMode.isEmpty && !_isProcessing) return const SizedBox.shrink();

    final isDecompile = _detectedMode == 'decompile';
    final modeColor   = isDecompile ? _accent : _accentLight;
    final modeLabel   = isDecompile ? 'DECOMPILE' : 'RECOMPILE';
    final modeIcon    = isDecompile
        ? Icons.arrow_downward_rounded
        : Icons.arrow_upward_rounded;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF0f0f22),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: modeColor.withOpacity(0.25)),
      ),
      child: Row(children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(
            color: modeColor.withOpacity(0.12),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: modeColor.withOpacity(0.4)),
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(modeIcon, color: modeColor, size: 13),
            const SizedBox(width: 5),
            Text(modeLabel,
                style: TextStyle(
                    color: modeColor, fontSize: 11,
                    fontWeight: FontWeight.w800, letterSpacing: 1)),
          ]),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            isDecompile
                ? 'APK will be decompiled to resources + smali'
                : 'apktool project will be rebuilt into APK',
            style: const TextStyle(
                color: Color(0xFF9ca3af), fontSize: 11.5),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ),
        if (!isDecompile) ...[
          const SizedBox(width: 8),
          GestureDetector(
            onTap: _isProcessing ? null : () => setState(() => _signApk = !_signApk),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: _signApk
                    ? modeColor.withOpacity(0.15)
                    : const Color(0xFF1a1a2e),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: _signApk
                      ? modeColor.withOpacity(0.5)
                      : const Color(0xFF2a2a3e),
                ),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(
                  _signApk
                      ? Icons.verified_rounded
                      : Icons.lock_open_rounded,
                  color: _signApk ? modeColor : const Color(0xFF6b7280),
                  size: 13,
                ),
                const SizedBox(width: 4),
                Text(
                  'Sign APK',
                  style: TextStyle(
                    color: _signApk ? modeColor : const Color(0xFF6b7280),
                    fontSize: 10.5, fontWeight: FontWeight.w600,
                  ),
                ),
              ]),
            ),
          ),
        ],
      ]),
    );
  }

  Widget _buildActionRow() {
    final hasFile = _selectedFileName != null;
    final canRun  = _fileValid && hasFile && _detectedMode.isNotEmpty;
    final label   = _detectedMode == 'recompile'
        ? 'Recompile  (APK Tool)'
        : 'Decompile  (APK Tool)';

    return Column(children: [
      Row(children: [
        Expanded(
          child: GestureDetector(
            onTap: (_isProcessing || !canRun) ? null : _runOperation,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                gradient: (_isProcessing || !canRun)
                    ? null
                    : LinearGradient(
                        colors: [_accent, const Color(0xFF1d4ed8)]),
                color: (_isProcessing || !canRun)
                    ? const Color(0xFF1a1a2e)
                    : null,
                border: Border.all(
                  color: _isProcessing
                      ? _accent.withOpacity(0.3)
                      : !canRun
                          ? const Color(0xFF2a2a3e)
                          : Colors.transparent,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (_isProcessing) ...[
                    SizedBox(
                      width: 16, height: 16,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: _accent),
                    ),
                    const SizedBox(width: 10),
                  ],
                  Text(
                    _isProcessing ? 'Processing...' : label,
                    style: TextStyle(
                      color: (_isProcessing || !canRun)
                          ? const Color(0xFF6b7280)
                          : Colors.white,
                      fontWeight: FontWeight.w700, fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ]),
      if (_isProcessing) ...[
        const SizedBox(height: 8),
        SizedBox(
          width: double.infinity,
          child: GestureDetector(
            onTap: _cancelOperation,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: const Color(0xFF1a1a2e),
                border: Border.all(
                    color: const Color(0xFFef4444).withOpacity(0.5)),
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.cancel_outlined,
                      color: Color(0xFFef4444), size: 16),
                  SizedBox(width: 8),
                  Text('Cancel',
                      style: TextStyle(
                          color: Color(0xFFef4444),
                          fontWeight: FontWeight.w600, fontSize: 14)),
                ],
              ),
            ),
          ),
        ),
      ],
    ]);
  }

  Widget _buildProgressBar() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      ClipRRect(
        borderRadius: BorderRadius.circular(6),
        child: LinearProgressIndicator(
          value: _downloadProgress / 100.0,
          backgroundColor: const Color(0xFF1a1a2e),
          color: _accent, minHeight: 4,
        ),
      ),
      const SizedBox(height: 4),
      Text('$_downloadProgress%',
          style: const TextStyle(
              color: Color(0xFF6b7280),
              fontSize: 10, fontFamily: 'monospace')),
    ]);
  }

  Widget _buildLogPanel() {
    return FadeTransition(
      opacity: _logFade,
      child: Container(
        key: _logPanelKey,
        decoration: BoxDecoration(
          color: const Color(0xFF080812),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _accent.withOpacity(0.2)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Container(
            padding: EdgeInsets.fromLTRB(14, 10, 10, 10),
            decoration: BoxDecoration(
              color: ThemeProvider().current.appBarBg,
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(14)),
              border: Border(
                  bottom: BorderSide(color: _accent.withOpacity(0.15))),
            ),
            child: Row(children: [
              Container(
                width: 8, height: 8,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _isProcessing
                      ? _accent
                      : const Color(0xFF22c55e),
                  boxShadow: [
                    BoxShadow(
                        color: (_isProcessing ? _accent : const Color(0xFF22c55e))
                            .withOpacity(0.5),
                        blurRadius: 6),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Text(
                _isProcessing ? 'Processing...' : 'Live Output',
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12, fontWeight: FontWeight.w700),
              ),
              const Spacer(),
              if (_downloadProgress >= 0 && _downloadProgress < 100) ...[
                SizedBox(
                  width: 120,
                  child: _buildProgressBar(),
                ),
                const SizedBox(width: 8),
              ],
              GestureDetector(
                onTap: () => setState(() => _autoScroll = !_autoScroll),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: _autoScroll
                        ? _accent.withOpacity(0.15)
                        : const Color(0xFF1a1a2e),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(
                      color: _autoScroll
                          ? _accent.withOpacity(0.4)
                          : const Color(0xFF2a2a3e),
                    ),
                  ),
                  child: Text('Auto',
                      style: TextStyle(
                          color: _autoScroll ? _accent : const Color(0xFF6b7280),
                          fontSize: 10, fontWeight: FontWeight.w600)),
                ),
              ),
              const SizedBox(width: 6),
              GestureDetector(
                onTap: () {
                  if (_logs.isEmpty || _isProcessing) return;
                  Clipboard.setData(ClipboardData(text: _logs));
                  _showSnack('Log copied',
                      icon: Icons.copy_rounded,
                      color: _accent);
                },
                child: Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1a1a2e),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: const Icon(Icons.copy_rounded,
                      color: Color(0xFF6b7280), size: 14),
                ),
              ),
              const SizedBox(width: 6),
              GestureDetector(
                onTap: () {
                  if (_logs.isEmpty || _isProcessing) return;
                  _pollTimer?.cancel();
                  _streamSub?.cancel();
                  _stopwatch.stop();
                  _stopwatch.reset();
                  _tickTimer?.cancel();
                  setState(() {
                    _logs             = '';
                    _isProcessing     = false;
                    _logVisible       = false;
                    _outputDir        = null;
                    _downloadProgress = -1;
                    _elapsed          = '00:00';
                  });
                  _logCtrl.reverse();
                  try { HbcChannel.apkToolClearState(); } catch (_) {}
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 6, vertical: 4),
                  decoration: BoxDecoration(
                    color: const Color(0xFFef4444).withOpacity(0.08),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(
                        color: const Color(0xFFef4444).withOpacity(0.35)),
                  ),
                  child: const Icon(
                    Icons.delete_outline_rounded,
                    color: Color(0xFFf87171),
                    size: 14,
                  ),
                ),
              ),
            ]),
          ),
          SizedBox(
            height: 260,
            child: _logs.isEmpty
                ? Center(
                    child: Text('Waiting for output...',
                        style: TextStyle(
                            color: _accent.withOpacity(0.4),
                            fontSize: 12, fontFamily: 'monospace')),
                  )
                : Scrollbar(
                    controller: _logScrollCtrl,
                    thumbVisibility: true,
                    child: SingleChildScrollView(
                      controller: _logScrollCtrl,
                      padding: const EdgeInsets.all(12),
                      child: Text(
                        _logs,
                        style: const TextStyle(
                            color: Color(0xFFd1fae5),
                            fontSize: 11, fontFamily: 'monospace',
                            height: 1.55),
                      ),
                    ),
                  ),
          ),
        ]),
      ),
    );
  }

  String _friendlyPath(String raw) {
    const prefix = '/storage/emulated/0/';
    if (raw.startsWith(prefix)) return raw.substring(prefix.length);
    return raw;
  }

  Widget _buildOutputCard() {
    const green = Color(0xFF22c55e);
    final friendlyDir = _outputDir != null ? _friendlyPath(_outputDir!) : '';

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF0a1a10),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: green.withOpacity(0.35)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: green.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.task_alt_rounded, color: green, size: 20),
          ),
          const SizedBox(width: 10),
          const Text('Results saved',
              style: TextStyle(
                  color: green,
                  fontSize: 13, fontWeight: FontWeight.w700)),
        ]),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: const Color(0xFF0d1a0d),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: green.withOpacity(0.15)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Icon(Icons.folder_open_rounded, color: green, size: 14),
              const SizedBox(width: 6),
              const Text('Save Location',
                  style: TextStyle(
                      color: green,
                      fontSize: 11, fontWeight: FontWeight.w600)),
            ]),
            const SizedBox(height: 6),
            Text(
              'Internal Storage  →  $friendlyDir',
              style: const TextStyle(
                  color: Color(0xFF86efac),
                  fontSize: 10.5, fontFamily: 'monospace', height: 1.4),
            ),
            const SizedBox(height: 4),
            Text(
              _outputDir ?? '',
              style: const TextStyle(
                  color: Color(0xFF374151),
                  fontSize: 9, fontFamily: 'monospace'),
              overflow: TextOverflow.ellipsis,
            ),
          ]),
        ),
        const SizedBox(height: 8),
        const Text(
          'Open any file manager and navigate to the path above to find your output files.',
          style: TextStyle(
              color: Color(0xFF6b7280), fontSize: 10.5, height: 1.4),
        ),
      ]),
    );
  }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

class _HeaderChip extends StatelessWidget {
  final String label;
  const _HeaderChip(this.label);
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: _kApkAccent.withOpacity(0.08),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _kApkAccent.withOpacity(0.25)),
      ),
      child: Text(label,
          style: TextStyle(
              color: _kApkAccent.withOpacity(0.8),
              fontSize: 10.5, fontWeight: FontWeight.w600)),
    );
  }
}

class _ApkOrbitPainter extends CustomPainter {
  final Color color;
  final double opacity;
  const _ApkOrbitPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withOpacity(opacity)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    final c = Offset(size.width / 2, size.height / 2);
    final r = size.width / 2;
    canvas.drawCircle(c, r, paint);
    final dotPaint = Paint()
      ..color = color.withOpacity((opacity * 1.8).clamp(0.0, 1.0))
      ..style = PaintingStyle.fill;
    canvas.drawCircle(Offset(c.dx + r, c.dy), 3, dotPaint);
  }

  @override
  bool shouldRepaint(_ApkOrbitPainter o) =>
      o.opacity != opacity || o.color != color;
}

class _ApkDotPainter extends CustomPainter {
  final Color color;
  final double opacity;
  const _ApkDotPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withOpacity(opacity)
      ..style = PaintingStyle.fill;
    final c = Offset(size.width / 2, size.height / 2);
    final r = size.width / 2;
    for (int i = 0; i < 8; i++) {
      final angle = (i / 8) * 2 * math.pi;
      canvas.drawCircle(
          Offset(c.dx + r * math.cos(angle), c.dy + r * math.sin(angle)),
          1.5, paint);
    }
  }

  @override
  bool shouldRepaint(_ApkDotPainter o) =>
      o.opacity != opacity || o.color != color;
}

class _LiveDot extends StatelessWidget {
  final Color color;
  const _LiveDot({required this.color});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 6, height: 6,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color,
        boxShadow: [BoxShadow(color: color.withOpacity(0.6), blurRadius: 6)],
      ),
    );
  }
}
