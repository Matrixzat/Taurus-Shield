import '../utils/theme_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class PythonIdleScreen extends StatefulWidget {
  const PythonIdleScreen({super.key});
  @override
  State<PythonIdleScreen> createState() => _PythonIdleScreenState();
}

class _PythonIdleScreenState extends State<PythonIdleScreen>
    with SingleTickerProviderStateMixin {
  static const _channel = MethodChannel('com.taurus.shield/python_idle');

  static const _accent   = Color(0xFF3b82f6);
  static const _accentDk = Color(0xFF1d4ed8);
  static const _termBg   = Color(0xFF0d1117);
  static const _editorBg = Color(0xFF161b22);

  final _codeCtrl         = TextEditingController();
  final _outputScrollCtrl = ScrollController();
  final _codeScrollCtrl   = ScrollController();
  final _codeFocus        = FocusNode();

  String _stdout  = '';
  String _stderr  = '';
  bool   _running = false;
  bool   _hasRun  = false;

  // Script history (most recent first)
  final List<String> _history = [];

  late AnimationController _pulseCtrl;
  late Animation<double>   _pulse;

  static const _examples = <String, String>{
    'Hello World': 'print("Hello, World!")',
    'Base64 Decode': '''import base64

encoded = "SGVsbG8gZnJvbSBUYXVydXMgU2hpZWxkIQ=="
decoded = base64.b64decode(encoded).decode()
print("Decoded:", decoded)''',
    'File Hash': '''import hashlib

data = b"Taurus Shield APK content here"
print("MD5   :", hashlib.md5(data).hexdigest())
print("SHA1  :", hashlib.sha1(data).hexdigest())
print("SHA256:", hashlib.sha256(data).hexdigest())''',
    'Struct / Binary': '''import struct

data = bytes.fromhex("504B0304140000000800")
fields = struct.unpack_from("<IHHHH", data)
sig = data[:2]
print("Signature:", sig.hex().upper(),
      "(" + ("ZIP" if sig == b"PK" else "unknown") + ")")
print("Fields:", fields)''',
    'JSON Parse': r"""import json

raw = '{"name":"TaurusShield","version":"3.1.0","tools":["ssl","blutter","dex2c"]}'
obj = json.loads(raw)
print("App:", obj["name"], "v" + obj["version"])
print("Tools:", ", ".join(obj["tools"]))""",
    'Persistent Variables': '''# Variables persist between runs until you tap Reset Session
if "counter" not in dir():
    counter = 0
counter += 1
print(f"Run count: {counter}")
print("Tap Run multiple times to see it increment.")
print("Tap Reset Session to start fresh.")''',
    'DEX Magic Check': '''data = bytes([0x64,0x65,0x78,0x0A,0x30,0x33,0x35,0x00])
magic = data[:4].decode("ascii", errors="replace")
ver   = data[4:7].decode("ascii", errors="replace")
print(f"Magic  : {magic!r}")
print(f"Version: {ver}")
print(f"Hex    : {data[:8].hex()}") ''',
    'Regex Match': r"""import re

apk_name = "com.example.app_v3.1.0-release.apk"
m = re.search(r'([a-z.]+)_v([\d.]+)', apk_name)
if m:
    print("Package:", m.group(1))
    print("Version:", m.group(2))""",
    'OS / Python Info': '''import os, sys

print("Python:", sys.version)
print("Platform:", sys.platform)
print("CWD:", os.getcwd())
print("Env vars:", len(os.environ))''',
    'Requests (HTTP)': '''import requests

# Tip: internet must be available on the device
try:
    r = requests.get("https://httpbin.org/json", timeout=5)
    data = r.json()
    print("Status:", r.status_code)
    print("Data:", data)
except Exception as e:
    print("Error:", e)''',
    'pyelftools (ELF)': '''from elftools.elf.elffile import ELFFile
import io

# Minimal ELF header (64-bit) for demo
header = (
    b"\\x7fELF"   # magic
    b"\\x02"      # 64-bit
    b"\\x01"      # little-endian
    b"\\x01"      # ELF version
    b"\\x00" * 9  # padding
    b"\\x02\\x00" # ET_EXEC
    b"\\xb7\\x00" # ARM64
    b"\\x01\\x00\\x00\\x00"  # version
    + b"\\x00" * 48          # zeroed rest
)
try:
    elf = ELFFile(io.BytesIO(header))
    print("ELF class:", elf.elfclass)
    print("Byte order:", elf.little_endian)
except Exception as e:
    print("Parse error (expected for stub):", e)''',
  };

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1500))
      ..repeat(reverse: true);
    _pulse = Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
    _codeCtrl.text = _examples['Hello World']!;
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _codeCtrl.dispose();
    _outputScrollCtrl.dispose();
    _codeScrollCtrl.dispose();
    _codeFocus.dispose();
    super.dispose();
  }

  // ── Run code ────────────────────────────────────────────────────────────────
  Future<void> _runCode() async {
    final code = _codeCtrl.text.trim();
    if (code.isEmpty || _running) return;
    setState(() { _running = true; _stdout = ''; _stderr = ''; _hasRun = false; });
    try {
      final res = await _channel.invokeMapMethod<String, String>(
          'run_code', {'code': code});
      if (!mounted) return;
      // Save to history (most recent first, deduplicated)
      _history.remove(code);
      _history.insert(0, code);
      if (_history.length > 50) _history.removeLast();
      setState(() {
        _stdout  = res?['stdout'] ?? '';
        _stderr  = res?['stderr'] ?? '';
        _running = false;
        _hasRun  = true;
      });
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_outputScrollCtrl.hasClients) _outputScrollCtrl.jumpTo(0);
      });
    } catch (e) {
      if (!mounted) return;
      setState(() { _stderr = 'Channel error: $e'; _running = false; _hasRun = true; });
    }
  }

  // ── Reset session ───────────────────────────────────────────────────────────
  Future<void> _resetSession() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1e2030),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Reset Session',
            style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700)),
        content: const Text(
            'All variables and imports defined in this session will be cleared. '
            'Your code in the editor stays untouched.',
            style: TextStyle(color: Color(0xFF9ca3af), fontSize: 13, height: 1.5)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel',
                  style: TextStyle(color: Color(0xFF6b7280)))),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Reset',
                  style: TextStyle(color: Color(0xFFef4444), fontWeight: FontWeight.w700))),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    try {
      await _channel.invokeMethod('reset_session');
      if (!mounted) return;
      setState(() { _stdout = ''; _stderr = ''; _hasRun = false; });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Session reset — all variables cleared'),
          duration: Duration(seconds: 2),
          backgroundColor: Color(0xFF1e2030),
        ),
      );
    } catch (_) {}
  }

  // ── Helpers ─────────────────────────────────────────────────────────────────
  void _clearOutput() => setState(() { _stdout = ''; _stderr = ''; _hasRun = false; });

  void _loadExample(String name) {
    _codeCtrl.text = _examples[name]!;
    _clearOutput();
  }

  void _loadFromHistory(String code) {
    _codeCtrl.text = code;
    _clearOutput();
    Navigator.pop(context);
  }

  // ── Top bar ────────────────────────────────────────────────────────────────
  Widget _buildTopBar() {
    final theme = ThemeProvider().current;
    return Container(
      decoration: BoxDecoration(
        color: theme.appBarBg,
        border: Border(bottom: BorderSide(color: _accent.withOpacity(0.2))),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
          child: Row(
            children: [
              IconButton(
                icon: const Icon(Icons.arrow_back_ios_new_rounded,
                    size: 18, color: Colors.white70),
                onPressed: () => Navigator.pop(context),
              ),
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: _accent.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _accent.withOpacity(0.35)),
                ),
                child: const Icon(Icons.terminal_rounded,
                    color: _accent, size: 18),
              ),
              const SizedBox(width: 10),
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('PYTHON IDLE',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1.2)),
                  Text('Python 3.8 · on-device',
                      style: TextStyle(color: Color(0xFF6b7280), fontSize: 10)),
                ],
              ),
              const Spacer(),
              // History
              IconButton(
                icon: const Icon(Icons.history_rounded,
                    color: Colors.white54, size: 20),
                tooltip: 'Script history',
                onPressed: _history.isEmpty ? null : _showHistory,
              ),
              // Examples
              PopupMenuButton<String>(
                icon: const Icon(Icons.science_rounded,
                    color: Colors.white54, size: 20),
                tooltip: 'Examples',
                color: const Color(0xFF1e2030),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                itemBuilder: (_) => _examples.keys
                    .map((n) => PopupMenuItem(
                          value: n,
                          child: Text(n,
                              style: const TextStyle(
                                  color: Colors.white70, fontSize: 13)),
                        ))
                    .toList(),
                onSelected: _loadExample,
              ),
              // Packages info
              IconButton(
                icon: const Icon(Icons.inventory_2_outlined,
                    color: Colors.white38, size: 20),
                tooltip: 'Available packages',
                onPressed: _showPackages,
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── History sheet ──────────────────────────────────────────────────────────
  void _showHistory() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1e2030),
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.55,
        minChildSize: 0.35,
        maxChildSize: 0.85,
        builder: (_, ctrl) => Column(
          children: [
            const SizedBox(height: 12),
            Container(
              width: 36,
              height: 4,
              decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(2)),
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: [
                  const Icon(Icons.history_rounded,
                      color: _accent, size: 18),
                  const SizedBox(width: 8),
                  const Text('Script History',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.w700)),
                  const Spacer(),
                  Text('${_history.length} scripts',
                      style: const TextStyle(
                          color: Color(0xFF6b7280), fontSize: 12)),
                ],
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: ListView.builder(
                controller: ctrl,
                padding: const EdgeInsets.fromLTRB(12, 0, 12, 20),
                itemCount: _history.length,
                itemBuilder: (_, i) {
                  final script = _history[i];
                  final preview = script.length > 80
                      ? '${script.substring(0, 80)}…'
                      : script;
                  final firstLine =
                      script.split('\n').first.trim();
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: InkWell(
                      onTap: () => _loadFromHistory(script),
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.04),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: Colors.white.withOpacity(0.08)),
                        ),
                        child: Column(
                          crossAxisAlignment:
                              CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Container(
                                  width: 6,
                                  height: 6,
                                  decoration: const BoxDecoration(
                                      color: _accent,
                                      shape: BoxShape.circle),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    firstLine.startsWith('#')
                                        ? firstLine
                                            .replaceFirst('#', '')
                                            .trim()
                                        : firstLine,
                                    style: const TextStyle(
                                        color: Colors.white70,
                                        fontSize: 12,
                                        fontWeight:
                                            FontWeight.w600,
                                        fontFamily: 'monospace'),
                                    overflow:
                                        TextOverflow.ellipsis,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                const Icon(
                                    Icons.arrow_forward_ios_rounded,
                                    size: 10,
                                    color: Color(0xFF6b7280)),
                              ],
                            ),
                            if (script.contains('\n')) ...[
                              const SizedBox(height: 4),
                              Text(preview,
                                  style: const TextStyle(
                                      color: Color(0xFF6b7280),
                                      fontSize: 10,
                                      fontFamily: 'monospace',
                                      height: 1.4),
                                  maxLines: 3,
                                  overflow: TextOverflow.ellipsis),
                            ],
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Package info sheet ─────────────────────────────────────────────────────
  void _showPackages() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1e2030),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 32),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Available Packages',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            const Text('Pre-bundled in APK · No internet required',
                style: TextStyle(
                    color: Color(0xFF6b7280), fontSize: 11)),
            const SizedBox(height: 4),
            const Text(
                'Note: requests requires device internet access.',
                style: TextStyle(
                    color: Color(0xFF6b7280), fontSize: 10)),
            const SizedBox(height: 16),
            const Text('Standard Library',
                style: TextStyle(
                    color: Color(0xFF9ca3af),
                    fontSize: 11,
                    fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Wrap(spacing: 8, runSpacing: 8, children: [
              for (final p in [
                'sys', 'os', 'json', 're', 'struct', 'hashlib',
                'base64', 'io', 'zipfile', 'pathlib', 'collections',
                'itertools', 'functools', 'math', 'random', 'string',
                'datetime', 'urllib', 'socket', 'threading', 'time',
                'csv', 'ast', 'inspect', 'copy', 'enum',
              ])
                _PkgChip(label: p, color: _accent),
            ]),
            const SizedBox(height: 14),
            const Text('Pip-bundled',
                style: TextStyle(
                    color: Color(0xFF9ca3af),
                    fontSize: 11,
                    fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Wrap(spacing: 8, runSpacing: 8, children: [
              for (final p in [
                'requests', 'click', 'colorama', 'construct',
                'pyelftools',
              ])
                _PkgChip(label: p, color: const Color(0xFF10b981)),
            ]),
            const SizedBox(height: 14),
            const Divider(color: Colors.white12),
            const SizedBox(height: 10),
            const Text(
              '⚠  input() is not supported — assign values as variables instead.',
              style: TextStyle(
                  color: Color(0xFFf59e0b),
                  fontSize: 11,
                  height: 1.5),
            ),
            const SizedBox(height: 4),
            const Text(
              '⚑  Variables persist between runs until you tap Reset Session.',
              style: TextStyle(
                  color: Color(0xFF6b7280),
                  fontSize: 11,
                  height: 1.5),
            ),
            const SizedBox(height: 12),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Close',
                      style: TextStyle(color: Color(0xFF6b7280)))),
            ),
          ],
        ),
      ),
    );
  }

  // ── Code editor ────────────────────────────────────────────────────────────
  Widget _buildEditor() {
    return Container(
      color: _editorBg,
      child: Column(
        children: [
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              color: _termBg,
              border: Border(
                  bottom: BorderSide(
                      color: Colors.white.withOpacity(0.06))),
            ),
            child: Row(
              children: [
                const Icon(Icons.edit_rounded,
                    size: 11, color: _accent),
                const SizedBox(width: 6),
                const Text('editor.py',
                    style: TextStyle(
                        color: Color(0xFF6b7280),
                        fontSize: 11,
                        fontFamily: 'monospace')),
                const Spacer(),
                GestureDetector(
                  onTap: () {
                    Clipboard.setData(
                        ClipboardData(text: _codeCtrl.text));
                    ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                            content: Text('Code copied'),
                            duration: Duration(seconds: 1)));
                  },
                  child: const Icon(Icons.copy_rounded,
                      size: 14, color: Color(0xFF6b7280)),
                ),
              ],
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              controller: _codeScrollCtrl,
              child: IntrinsicHeight(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Line numbers
                    AnimatedBuilder(
                      animation: _codeCtrl,
                      builder: (_, __) {
                        final lines =
                            _codeCtrl.text.split('\n').length.clamp(1, 9999);
                        return Container(
                          width: 38,
                          color: _termBg,
                          padding:
                              const EdgeInsets.only(top: 12, right: 6),
                          child: Column(
                            crossAxisAlignment:
                                CrossAxisAlignment.end,
                            children: List.generate(
                              lines,
                              (i) => Text('${i + 1}',
                                  style: const TextStyle(
                                      color: Color(0xFF444c56),
                                      fontSize: 11,
                                      fontFamily: 'monospace',
                                      height: 1.55)),
                            ),
                          ),
                        );
                      },
                    ),
                    // Code area
                    Expanded(
                      child: TextField(
                        controller: _codeCtrl,
                        focusNode: _codeFocus,
                        maxLines: null,
                        style: const TextStyle(
                            color: Color(0xFFe6edf3),
                            fontSize: 13,
                            fontFamily: 'monospace',
                            height: 1.55),
                        decoration: const InputDecoration(
                          contentPadding:
                              EdgeInsets.fromLTRB(8, 12, 12, 12),
                          border: InputBorder.none,
                          hintText: '# Write Python code here...',
                          hintStyle: TextStyle(
                              color: Color(0xFF444c56),
                              fontSize: 13,
                              fontFamily: 'monospace'),
                        ),
                        onChanged: (_) => setState(() {}),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Run / action bar ───────────────────────────────────────────────────────
  Widget _buildRunBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: _termBg,
        border: Border.symmetric(
            horizontal:
                BorderSide(color: _accent.withOpacity(0.15))),
      ),
      child: Row(
        children: [
          // ── Run button ──────────────────────────────────────────────────
          AnimatedBuilder(
            animation: _pulse,
            builder: (_, __) => GestureDetector(
              onTap: _running ? null : _runCode,
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 18, vertical: 9),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: _running
                        ? [
                            const Color(0xFF374151),
                            const Color(0xFF1f2937)
                          ]
                        : [
                            Color.lerp(_accent, _accentDk,
                                _pulse.value)!,
                            _accentDk
                          ],
                  ),
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: _running
                      ? []
                      : [
                          BoxShadow(
                              color: _accent.withOpacity(
                                  0.3 + _pulse.value * 0.2),
                              blurRadius: 10)
                        ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: _running
                      ? const [
                          SizedBox(
                              width: 12,
                              height: 12,
                              child: CircularProgressIndicator(
                                  strokeWidth: 1.5,
                                  color: Colors.white54)),
                          SizedBox(width: 8),
                          Text('Running...',
                              style: TextStyle(
                                  color: Colors.white54,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600)),
                        ]
                      : const [
                          Icon(Icons.play_arrow_rounded,
                              color: Colors.white, size: 16),
                          SizedBox(width: 6),
                          Text('Run',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w700)),
                        ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),

          // ── Clear output ─────────────────────────────────────────────────
          if (_hasRun)
            GestureDetector(
              onTap: _clearOutput,
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 10, vertical: 9),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.white12),
                ),
                child: const Text('Clear',
                    style: TextStyle(
                        color: Color(0xFF6b7280), fontSize: 12)),
              ),
            ),
          if (_hasRun) const SizedBox(width: 8),

          // ── Reset Session ────────────────────────────────────────────────
          GestureDetector(
            onTap: _running ? null : _resetSession,
            child: Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 10, vertical: 9),
              decoration: BoxDecoration(
                color: const Color(0xFFef4444).withOpacity(0.08),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                    color: const Color(0xFFef4444).withOpacity(0.3)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.refresh_rounded,
                      size: 12,
                      color: _running
                          ? const Color(0xFF6b7280)
                          : const Color(0xFFf87171)),
                  const SizedBox(width: 4),
                  Text('Reset',
                      style: TextStyle(
                          color: _running
                              ? const Color(0xFF6b7280)
                              : const Color(0xFFf87171),
                          fontSize: 11,
                          fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          ),

          const Spacer(),

          // ── Status indicator ─────────────────────────────────────────────
          if (_hasRun)
            Row(
              children: [
                Container(
                  width: 7,
                  height: 7,
                  decoration: BoxDecoration(
                    color: _stderr.isNotEmpty
                        ? const Color(0xFFef4444)
                        : const Color(0xFF22c55e),
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  _stderr.isNotEmpty ? 'Error' : 'OK',
                  style: TextStyle(
                    color: _stderr.isNotEmpty
                        ? const Color(0xFFef4444)
                        : const Color(0xFF22c55e),
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }

  // ── Output console ─────────────────────────────────────────────────────────
  Widget _buildOutput() {
    final hasOutput = _stdout.isNotEmpty || _stderr.isNotEmpty;
    return Container(
      color: _termBg,
      child: Column(
        children: [
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              color: _editorBg,
              border: Border(
                  bottom: BorderSide(
                      color: Colors.white.withOpacity(0.06))),
            ),
            child: Row(
              children: [
                const Icon(Icons.terminal_rounded,
                    size: 11, color: Color(0xFF6b7280)),
                const SizedBox(width: 6),
                const Text('output',
                    style: TextStyle(
                        color: Color(0xFF6b7280),
                        fontSize: 11,
                        fontFamily: 'monospace')),
                const Spacer(),
                if (hasOutput)
                  GestureDetector(
                    onTap: () {
                      final all = [
                        if (_stdout.isNotEmpty) _stdout,
                        if (_stderr.isNotEmpty)
                          '--- stderr ---\n$_stderr',
                      ].join('\n');
                      Clipboard.setData(ClipboardData(text: all));
                      ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                              content: Text('Output copied'),
                              duration: Duration(seconds: 1)));
                    },
                    child: const Icon(Icons.copy_rounded,
                        size: 14, color: Color(0xFF6b7280)),
                  ),
              ],
            ),
          ),
          Expanded(
            child: hasOutput
                ? SingleChildScrollView(
                    controller: _outputScrollCtrl,
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (_stdout.isNotEmpty)
                          SelectableText(
                            _stdout,
                            style: const TextStyle(
                                color: Color(0xFFe6edf3),
                                fontSize: 12,
                                fontFamily: 'monospace',
                                height: 1.6),
                          ),
                        if (_stderr.isNotEmpty) ...[
                          if (_stdout.isNotEmpty)
                            const SizedBox(height: 8),
                          SelectableText(
                            _stderr,
                            style: const TextStyle(
                                color: Color(0xFFf87171),
                                fontSize: 12,
                                fontFamily: 'monospace',
                                height: 1.6),
                          ),
                        ],
                      ],
                    ),
                  )
                : Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.terminal_rounded,
                            size: 36,
                            color:
                                Colors.white.withOpacity(0.07)),
                        const SizedBox(height: 10),
                        Text('Output appears here',
                            style: TextStyle(
                                color:
                                    Colors.white.withOpacity(0.18),
                                fontSize: 12)),
                        const SizedBox(height: 4),
                        Text('Tap Run to execute your code',
                            style: TextStyle(
                                color:
                                    Colors.white.withOpacity(0.1),
                                fontSize: 10)),
                      ],
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _termBg,
      body: Column(
        children: [
          _buildTopBar(),
          Expanded(
            child: Column(
              children: [
                Flexible(flex: 5, child: _buildEditor()),
                _buildRunBar(),
                Flexible(flex: 4, child: _buildOutput()),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PkgChip extends StatelessWidget {
  final String label;
  final Color color;
  const _PkgChip({required this.label, required this.color});

  @override
  Widget build(BuildContext context) => Container(
        padding:
            const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(
          color: color.withOpacity(0.12),
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Text(label,
            style: TextStyle(
                color: color,
                fontSize: 11,
                fontFamily: 'monospace')),
      );
}
