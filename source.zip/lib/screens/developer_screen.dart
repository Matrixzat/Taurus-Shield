import '../utils/theme_provider.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../utils/app_links.dart';

class DeveloperScreen extends StatelessWidget {
  const DeveloperScreen({super.key});

  Future<void> _openContact(BuildContext context) async {
    final uri = Uri.parse(AppLinks.contactDev);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not open Telegram')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('DEVELOPER')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _DevCard(onContact: () => _openContact(context)),
            const SizedBox(height: 16),
            _ContactButton(onTap: () => _openContact(context)),
            const SizedBox(height: 20),
            _InfoCard(
              icon: Icons.code_rounded,
              title: 'Tech Stack',
              items: const [
                ('Flutter 3.29', 'Cross-platform UI framework'),
                ('Dart', 'Primary language'),
                ('Kotlin', 'Android native bridge'),
                ('Python 3.8 (Chaquopy)', 'Python 3.8 runtime'),
                ('hbctool (Kirlif)', 'HBC parsing engine'),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _DevCard extends StatelessWidget {
  final VoidCallback onContact;
  const _DevCard({required this.onContact});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onContact,
      child: Container(
        padding: EdgeInsets.all(24),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(
            colors: [Color(0xFF0d1a30), ThemeProvider().current.headerBg1],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          border: Border.all(color: const Color(0xFF0ea5e9).withOpacity(0.5)),
          boxShadow: [BoxShadow(color: const Color(0xFF0ea5e9).withOpacity(0.15), blurRadius: 24)],
        ),
        child: Row(
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(36),
                gradient: LinearGradient(colors: [Color(0xFF0ea5e9), ThemeProvider().current.primary]),
                boxShadow: [BoxShadow(color: const Color(0xFF0ea5e9).withOpacity(0.5), blurRadius: 18)],
              ),
              child: const Icon(Icons.terminal_rounded, color: Colors.white, size: 36),
            ),
            const SizedBox(width: 18),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Matrix Dev',
                    style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800),
                  ),
                  SizedBox(height: 4),
                  Text(
                    'Reverse Engineer & Tool Developer',
                    style: TextStyle(color: Color(0xFF0ea5e9), fontSize: 13),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Passionate about mobile security, bytecode analysis, APK reverse engineering, and building tools that empower researchers.',
                    style: TextStyle(color: Color(0xFF6b7280), fontSize: 11, height: 1.6),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ContactButton extends StatelessWidget {
  final VoidCallback onTap;
  const _ContactButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          gradient: const LinearGradient(
            colors: [Color(0xFF0088cc), Color(0xFF005fa3)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          boxShadow: [BoxShadow(color: const Color(0xFF0088cc).withOpacity(0.35), blurRadius: 16, offset: const Offset(0, 4))],
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.send_rounded, color: Colors.white, size: 20),
            SizedBox(width: 10),
            Text(
              'Contact Developer on Telegram',
              style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w700, letterSpacing: 0.3),
            ),
          ],
        ),
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final List<(String, String)> items;

  const _InfoCard({required this.icon, required this.title, required this.items});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: ThemeProvider().current.surfaceColor,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: ThemeProvider().current.borderColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Icon(icon, color: ThemeProvider().current.primary, size: 20),
            const SizedBox(width: 10),
            Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15)),
          ]),
          const SizedBox(height: 14),
          ...items.map((item) => Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 6, height: 6,
                  margin: EdgeInsets.only(top: 5, right: 10),
                  decoration: BoxDecoration(
                    color: ThemeProvider().current.primary,
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(item.$1, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 13)),
                      Text(item.$2, style: const TextStyle(color: Color(0xFF6b7280), fontSize: 11)),
                    ],
                  ),
                ),
              ],
            ),
          )),
        ],
      ),
    );
  }
}
