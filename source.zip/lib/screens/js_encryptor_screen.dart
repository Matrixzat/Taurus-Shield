import '../utils/theme_provider.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:share_plus/share_plus.dart';
import 'package:archive/archive_io.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/hbc_channel.dart';
import '../utils/storage_helper.dart';
import '../utils/permission_helper.dart';
import '../utils/session_state.dart';

// ─── Colors ──────────────────────────────────────────────────────────────────
const _gold     = Color(0xFFF59E0B);
const _goldDim  = Color(0xFFD97706);
const _goldGlow = Color(0xFFFBBF24);
const _border   = Color(0xFF1a1a35);

// ─── Method animation types ───────────────────────────────────────────────────
enum _AnimType { spin, breathe, flicker, bounce }

// ─── Method definitions ───────────────────────────────────────────────────────
class _Method {
  final String id;
  final String label;
  final IconData icon;
  final Color color;
  final String hint;
  final _AnimType animType;
  const _Method(this.id, this.label, this.icon, this.color, this.hint, this.animType);
}

const _methods = [
  _Method('encmatrix',    'Matrix',    Icons.dashboard_customize_rounded, Color(0xFF6366F1), 'Randomised IDs + CFF + string enc',   _AnimType.spin),
  _Method('encultra',     'Ultra',     Icons.flash_on_rounded,            Color(0xFFFBBF24), 'Compact alphanumeric IDs + RGF',       _AnimType.breathe),
  _Method('encarab',      'Arab',      Icons.translate_rounded,           Color(0xFF8B5CF6), 'Arabic-char identifiers',              _AnimType.bounce),
  _Method('encjapxab',    'JapxArab',  Icons.join_full_rounded,           Color(0xFFEC4899), 'Japanese + Arabic mixed IDs',          _AnimType.bounce),
  _Method('enchector',    'Hector',    Icons.security_rounded,            Color(0xFF3B82F6), 'NX-prefix IDs + flatten + RGF',        _AnimType.breathe),
  _Method('encinvisible', 'Invisible', Icons.hide_source_rounded,         Color(0xFF94A3B8), 'xZ-prefix + concealing + flatten',     _AnimType.flicker),
  _Method('encstealth',   'Stealth',   Icons.radar_rounded,               Color(0xFF14B8A6), 'Mixed font identifiers + CFF',         _AnimType.flicker),
  _Method('dracula',      'Dracula',   Icons.nights_stay_rounded,         Color(0xFF7C3AED), 'Named-namespace + stable seed',        _AnimType.breathe),
  _Method('encchina',     'China',     Icons.language_rounded,            Color(0xFFEF4444), 'Chinese kanji identifiers',            _AnimType.bounce),
  _Method('encquantum',   'Quantum',   Icons.scatter_plot_rounded,        Color(0xFF06B6D4), 'Timestamp-seeded IDs + RGF',           _AnimType.spin),
  _Method('encnova',      'Nova',      Icons.auto_awesome_rounded,        Color(0xFFF97316), 'Multi-prefix + concealing',            _AnimType.breathe),
  _Method('encvampire',   'Vampire',   Icons.water_drop_rounded,          Color(0xFF818CF8), 'Uppercase IDs + 0.98 CFF',             _AnimType.flicker),
  _Method('encjapan',     'Japan',     Icons.spa_rounded,                 Color(0xFF4ADE80), 'Pure hiragana identifiers',            _AnimType.bounce),
  _Method('encfatality',  'Fatality',  Icons.local_fire_department_rounded,Color(0xFFDC2626),'Japanese+FATALITY IDs + full CFF',     _AnimType.spin),
  _Method('immortal',     'Immortal',  Icons.all_inclusive_rounded,       Color(0xFFF59E0B), 'CalceKarik SiuSiu — mixed Unicode IDs',_AnimType.spin),
  _Method('decrypt',      'Decrypt',   Icons.lock_open_rounded,           Color(0xFF34D399), 'Deobfuscate and recover JS source',    _AnimType.flicker),
];

// ─── Manual tab models ────────────────────────────────────────────────────────
class _MAssign {
  String method;
  String szKey;
  _MAssign({required this.method, this.szKey = ''});
  Map<String, dynamic> toJson() => {'method': method, 'szKey': szKey};
  factory _MAssign.fromJson(Map<String, dynamic> j) =>
      _MAssign(method: j['method'] as String? ?? 'encmatrix', szKey: j['szKey'] as String? ?? '');
}

class _ZipNode {
  final String path;
  final bool   isDir;
  final int    depth;
  bool expanded;
  bool visible;
  _ZipNode({required this.path, required this.isDir, required this.depth,
            this.expanded = true, this.visible = true});
  String get name {
    final p = path.endsWith('/') ? path.substring(0, path.length - 1) : path;
    return p.contains('/') ? p.substring(p.lastIndexOf('/') + 1) : p;
  }
  bool get isJs   => !isDir && path.toLowerCase().endsWith('.js');
  bool get isHtml => !isDir && (path.toLowerCase().endsWith('.html') || path.toLowerCase().endsWith('.htm'));
  bool get selectable => isJs;
}

class JsEncryptorScreen extends StatefulWidget {
  const JsEncryptorScreen({super.key});
  @override
  State<JsEncryptorScreen> createState() => _JsEncryptorScreenState();
}

class _JsEncryptorScreenState extends State<JsEncryptorScreen>
    with TickerProviderStateMixin, WidgetsBindingObserver {

  String? _selectedFilePath;
  String? _selectedFileName;
  String _selectedMethodId = 'encmatrix';

  bool   _isProcessing = false;
  bool   _logVisible   = false;
  bool   _autoScroll   = true;
  String _logs         = '';
  String? _outputDir;
  String? _outputFile;

  bool   _manualMode = false;

  Timer? _pollTimer;
  final _logScroll  = ScrollController();
  final _pageScroll = ScrollController();
  final _szKeyCtrl  = TextEditingController();

  // ── Manual tab state ────────────────────────────────────────────────────────
  static const _kManZip    = 'jsenc_m_zip';
  static const _kManName   = 'jsenc_m_name';
  static const _kManAssign = 'jsenc_m_assign';

  String?               _mZipPath;
  String?               _mZipName;
  List<_ZipNode>        _mNodes      = [];
  Map<String, _MAssign> _mAssign     = {};
  bool                  _mProcessing = false;
  bool                  _mLogVisible = false;
  bool                  _mAutoScroll = true;
  String                _mLogs       = '';
  String?               _mOutputDir;
  String?               _mOutputFile;
  Timer?                _mPollTimer;
  final _mLogScroll = ScrollController();

  late AnimationController _mLogCtrl;
  late Animation<double>   _mLogFade;

  late AnimationController _pulseCtrl;
  late AnimationController _orbitCtrl;
  late AnimationController _scanCtrl;
  late AnimationController _cardCtrl;
  late AnimationController _btnCtrl;
  late AnimationController _logCtrl;
  late AnimationController _spinCtrl;
  late AnimationController _flickCtrl;
  late AnimationController _bounceCtrl;
  late Animation<double>   _pulse;
  late Animation<double>   _scanAnim;
  late Animation<double>   _cardFade;
  late Animation<Offset>   _cardSlide;
  late Animation<double>   _btnScale;
  late Animation<double>   _logFade;
  late Animation<double>   _spin;
  late Animation<double>   _flick;
  late Animation<double>   _bounce;

  @override
  void initState() {
    super.initState();
    _mLogCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 400));
    _mLogFade = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _mLogCtrl, curve: Curves.easeIn));

    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _pulse = Tween<double>(begin: 0.0, end: 1.0)
        .animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _orbitCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 4200))
      ..repeat();

    _scanCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 3))
      ..repeat();
    _scanAnim = Tween<double>(begin: 0.0, end: 1.0)
        .animate(CurvedAnimation(parent: _scanCtrl, curve: Curves.linear));

    _cardCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 700));
    _cardFade = Tween<double>(begin: 0.0, end: 1.0)
        .animate(CurvedAnimation(parent: _cardCtrl, curve: Curves.easeOut));
    _cardSlide = Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero)
        .animate(CurvedAnimation(parent: _cardCtrl, curve: Curves.easeOutCubic));

    _btnCtrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _btnScale = Tween<double>(begin: 0.85, end: 1.0)
        .animate(CurvedAnimation(parent: _btnCtrl, curve: Curves.easeOutBack));

    _logCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 400));
    _logFade = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _logCtrl, curve: Curves.easeIn));

    _spinCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400))
      ..repeat();
    _spin = Tween<double>(begin: 0, end: 1).animate(_spinCtrl);

    _flickCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 550))
      ..repeat(reverse: true);
    _flick = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _flickCtrl, curve: Curves.easeInOut));

    _bounceCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 700))
      ..repeat(reverse: true);
    _bounce = Tween<double>(begin: -3.0, end: 3.0)
        .animate(CurvedAnimation(parent: _bounceCtrl, curve: Curves.easeInOut));

    Future.delayed(const Duration(milliseconds: 100), () {
      if (mounted) { _cardCtrl.forward(); _btnCtrl.forward(); }
    });

    WidgetsBinding.instance.addObserver(this);
    _restoreSession();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _checkState();
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _mPollTimer?.cancel();
    _mLogCtrl.dispose();
    _mLogScroll.dispose();
    _pulseCtrl.dispose(); _orbitCtrl.dispose(); _scanCtrl.dispose();
    _cardCtrl.dispose(); _btnCtrl.dispose();
    _logCtrl.dispose(); _spinCtrl.dispose();
    _flickCtrl.dispose(); _bounceCtrl.dispose();
    _logScroll.dispose(); _pageScroll.dispose();
    _szKeyCtrl.dispose();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Future<void> _resetAll() async {
    _pollTimer?.cancel();
    _mPollTimer?.cancel();
    try { await HbcChannel.jsEncryptorCancel(); } catch (_) {}
    try { await HbcChannel.jsEncryptorClearState(); } catch (_) {}
    try { await HbcChannel.jsEncryptorBatchCancel(); } catch (_) {}
    try { await HbcChannel.jsEncryptorBatchClearState(); } catch (_) {}
    _szKeyCtrl.clear();
    _logCtrl.reset();
    _mLogCtrl.reset();
    setState(() {
      _selectedFilePath = null;
      _selectedFileName = null;
      _isProcessing     = false;
      _logVisible       = false;
      _logs             = '';
      _outputDir        = null;
      _outputFile       = null;
      _autoScroll       = true;
      _mProcessing      = false;
      _mLogVisible      = false;
      _mLogs            = '';
      _mOutputDir       = null;
      _mOutputFile      = null;
      _mAutoScroll      = true;
    });
  }

  Future<void> _restoreSession() async {
    final state = await HbcChannel.jsEncryptorState();
    if (!mounted) return;
    if (state['running'] == true) {
      setState(() { _isProcessing = true; _logVisible = true; });
      _logCtrl.forward();
      _startPoll();
    } else if ((state['status'] as String?) == 'done' ||
               (state['status'] as String?) == 'error') {
      _applyFinishedState(state);
    }
    await SessionState.saveLastTool('jsencryptor');
    _restoreManualState();
  }

  // ─── Manual tab persistence ────────────────────────────────────────────────

  Future<void> _saveManualState() async {
    final p = await SharedPreferences.getInstance();
    if (_mZipPath != null) await p.setString(_kManZip,  _mZipPath!);
    if (_mZipName != null) await p.setString(_kManName, _mZipName!);
    final map = _mAssign.map((k, v) => MapEntry(k, v.toJson()));
    await p.setString(_kManAssign, jsonEncode(map));
  }

  Future<void> _restoreManualState() async {
    final p       = await SharedPreferences.getInstance();
    final zipPath = p.getString(_kManZip);
    final zipName = p.getString(_kManName);
    if (zipPath != null && File(zipPath).existsSync() && mounted) {
      setState(() { _mZipPath = zipPath; _mZipName = zipName; });
      await _buildZipTree(zipPath);
      final assignJson = p.getString(_kManAssign);
      if (assignJson != null && mounted) {
        try {
          final decoded = jsonDecode(assignJson) as Map<String, dynamic>;
          final restored = <String, _MAssign>{};
          decoded.forEach((k, v) { restored[k] = _MAssign.fromJson(v as Map<String, dynamic>); });
          setState(() { _mAssign = restored; });
        } catch (_) {}
      }
    }
    if (!mounted) return;
    final bs = await HbcChannel.jsEncryptorBatchState();
    if (!mounted) return;
    if (bs['running'] == true) {
      setState(() { _mProcessing = true; _mLogVisible = true; });
      _mLogCtrl.forward();
      _startManualPoll();
    } else if (bs['status'] == 'done' || bs['status'] == 'error') {
      _applyManualFinished(bs);
    }
  }

  void _applyManualFinished(Map<String, dynamic> s) {
    setState(() {
      _mProcessing = false;
      _mLogs       = (s['log'] as String?) ?? '';
      _mOutputDir  = s['outputDir'] as String?;
      _mOutputFile = s['outputFile'] as String?;
      _mLogVisible = _mLogs.isNotEmpty;
    });
    if (_mLogVisible) _mLogCtrl.forward();
  }

  void _startManualPoll() {
    _mPollTimer?.cancel();
    _mPollTimer = Timer.periodic(const Duration(seconds: 2), (_) async {
      final s = await HbcChannel.jsEncryptorBatchState();
      if (!mounted) return;
      setState(() { _mLogs = (s['log'] as String?) ?? ''; });
      _scrollManualLog();
      if (s['running'] != true) {
        _mPollTimer?.cancel();
        _applyManualFinished(s);
      }
    });
  }

  void _scrollManualLog() {
    if (_mAutoScroll && _mLogScroll.hasClients) {
      _mLogScroll.animateTo(
        _mLogScroll.position.maxScrollExtent,
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeOut,
      );
    }
  }

  // ─── Manual tab actions ────────────────────────────────────────────────────

  Future<void> _pickManualZip() async {
    final hasPerms = await PermissionHelper.ensureStorage(context, accent: _gold);
    if (!hasPerms) return;
    FilePickerResult? res;
    try {
      res = await FilePicker.platform.pickFiles(
        dialogTitle: 'Select ZIP file',
        type: FileType.custom,
        allowedExtensions: ['zip'],
      );
    } catch (_) {
      res = await FilePicker.platform.pickFiles(dialogTitle: 'Select ZIP file');
    }
    if (res == null || res.files.isEmpty) return;
    final f = res.files.first;
    if (f.path == null) return;
    if (!f.path!.toLowerCase().endsWith('.zip')) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(_snack('Please select a .zip file', isError: true));
      return;
    }
    setState(() { _mZipPath = f.path; _mZipName = f.name; _mNodes = []; _mAssign = {}; });
    await _buildZipTree(f.path!);
    _saveManualState();
  }

  Future<void> _buildZipTree(String zipPath) async {
    try {
      final bytes = await File(zipPath).readAsBytes();
      final archive = ZipDecoder().decodeBytes(bytes);
      final dirPaths  = <String>{};
      final filePaths = <String>[];
      for (final entry in archive.files) {
        final n = entry.name;
        if (!entry.isFile) continue;
        filePaths.add(n);
        final parts = n.split('/');
        for (int i = 1; i < parts.length; i++) {
          dirPaths.add(parts.sublist(0, i).join('/'));
        }
      }
      final all = <String, bool>{};
      for (final d in dirPaths)  all[d]       = true;
      for (final f in filePaths) all[f]        = false;
      final sorted = all.keys.toList()..sort();
      final nodes = sorted.map((path) {
        final isDir = all[path]!;
        final depth = path.split('/').length - 1;
        return _ZipNode(path: path, isDir: isDir, depth: depth);
      }).toList();
      if (mounted) setState(() { _mNodes = nodes; });
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(_snack('Cannot read ZIP: $e', isError: true));
    }
  }

  void _toggleFolder(_ZipNode node) {
    final idx = _mNodes.indexOf(node);
    node.expanded = !node.expanded;
    final prefix = '${node.path}/';
    for (int i = idx + 1; i < _mNodes.length; i++) {
      final n = _mNodes[i];
      if (!n.path.startsWith(prefix)) break;
      if (n.depth == node.depth + 1) n.visible = node.expanded;
      else if (!node.expanded) n.visible = false;
      else {
        final parentPath = n.path.contains('/') ? n.path.substring(0, n.path.lastIndexOf('/')) : '';
        final parent = _mNodes.firstWhere((x) => x.path == parentPath, orElse: () => node);
        n.visible = parent.expanded;
      }
    }
    setState(() {});
  }

  void _toggleFile(_ZipNode node) {
    if (!node.selectable) return;
    setState(() {
      if (_mAssign.containsKey(node.path)) {
        _mAssign.remove(node.path);
      } else {
        _mAssign[node.path] = _MAssign(method: 'encmatrix');
      }
    });
    _saveManualState();
  }

  Future<void> _selectAllSelectable() async {
    final selectableNodes = _mNodes.where((n) => !n.isDir && n.selectable).toList();
    if (selectableNodes.isEmpty) return;

    String selectedMethod = 'encmatrix';
    String szKey          = '';
    final szKeyCtrl       = TextEditingController();

    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF12122a),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setBS) => Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 16, 18, 8),
                child: Row(children: [
                  Icon(Icons.select_all_rounded, color: _gold, size: 16),
                  const SizedBox(width: 8),
                  Expanded(child: Text(
                    'Method for all ${selectableNodes.length} JS file${selectableNodes.length == 1 ? '' : 's'}',
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 14),
                    overflow: TextOverflow.ellipsis)),
                  IconButton(
                    icon: const Icon(Icons.close_rounded, color: Colors.white38, size: 20),
                    onPressed: () => Navigator.pop(ctx),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
                  ),
                ]),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Wrap(
                  spacing: 6, runSpacing: 6,
                  children: _methods.map((m) {
                    final sel = selectedMethod == m.id;
                    return GestureDetector(
                      onTap: () => setBS(() => selectedMethod = m.id),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 180),
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                        decoration: BoxDecoration(
                          color: sel ? m.color.withOpacity(0.18) : m.color.withOpacity(0.05),
                          borderRadius: BorderRadius.circular(9),
                          border: Border.all(
                              color: sel ? m.color.withOpacity(0.75) : m.color.withOpacity(0.20),
                              width: sel ? 1.5 : 1),
                        ),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          Icon(m.icon, size: 13, color: m.color.withOpacity(sel ? 1.0 : 0.45)),
                          const SizedBox(width: 5),
                          Text(m.label, style: TextStyle(
                              color: m.color.withOpacity(sel ? 1.0 : 0.5),
                              fontSize: 11,
                              fontWeight: sel ? FontWeight.w800 : FontWeight.w500)),
                        ]),
                      ),
                    );
                  }).toList(),
                ),
              ),
              if (selectedMethod == 'subzero') ...[
                Padding(
                  padding: const EdgeInsets.fromLTRB(14, 14, 14, 0),
                  child: Row(children: [
                    const Icon(Icons.ac_unit_rounded, size: 13, color: Color(0xFF67E8F9)),
                    const SizedBox(width: 6),
                    const Text('SubZero Key',
                        style: TextStyle(color: Color(0xFF67E8F9), fontSize: 12, fontWeight: FontWeight.w700)),
                  ]),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 6, 12, 0),
                  child: TextField(
                    controller: szKeyCtrl,
                    keyboardType: TextInputType.number,
                    style: const TextStyle(color: Colors.white, fontSize: 14,
                        fontFamily: 'monospace', letterSpacing: 2),
                    cursorColor: const Color(0xFF67E8F9),
                    autocorrect: false, enableSuggestions: false,
                    onChanged: (v) => szKey = v,
                    decoration: InputDecoration(
                      hintText: 'Any number — e.g. 5437, 1234, 9823',
                      hintStyle: const TextStyle(color: Color(0x3367E8F9), fontSize: 12),
                      filled: true, fillColor: Colors.white.withOpacity(0.04),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Color(0x3867E8F9))),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Color(0xAA67E8F9), width: 1.5)),
                    ),
                  ),
                ),
              ],
              Padding(
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 18),
                child: SizedBox(
                  width: double.infinity,
                  height: 46,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _gold,
                      foregroundColor: Colors.black87,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: () {
                      if (selectedMethod == 'subzero') szKey = szKeyCtrl.text.trim();
                      setState(() {
                        for (final n in selectableNodes) {
                          _mAssign[n.path] = _MAssign(method: selectedMethod, szKey: szKey);
                        }
                      });
                      _saveManualState();
                      Navigator.pop(ctx);
                    },
                    child: Text(
                      'Select All  (${selectableNodes.length} file${selectableNodes.length == 1 ? '' : 's'})',
                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
    szKeyCtrl.dispose();
  }

  void _clearAllSelections() {
    setState(() { _mAssign.clear(); });
    _saveManualState();
  }

  Future<void> _showMethodPicker(_ZipNode node) async {
    final current = _mAssign[node.path] ?? _MAssign(method: 'encmatrix');
    String selectedMethod = current.method;
    String szKey          = current.szKey;
    final szKeyCtrl = TextEditingController(text: szKey);

    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF12122a),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setBS) => Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 16, 18, 8),
                child: Row(children: [
                  Icon(Icons.tune_rounded, color: _gold, size: 16),
                  const SizedBox(width: 8),
                  Expanded(child: Text('Method for  ${node.name}',
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 14),
                    overflow: TextOverflow.ellipsis)),
                  IconButton(
                    icon: const Icon(Icons.close_rounded, color: Colors.white38, size: 20),
                    onPressed: () => Navigator.pop(ctx),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
                  ),
                ]),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Wrap(
                  spacing: 6, runSpacing: 6,
                  children: _methods.map((m) {
                    final sel = selectedMethod == m.id;
                    return GestureDetector(
                      onTap: () => setBS(() => selectedMethod = m.id),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 180),
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                        decoration: BoxDecoration(
                          color: sel ? m.color.withOpacity(0.18) : m.color.withOpacity(0.05),
                          borderRadius: BorderRadius.circular(9),
                          border: Border.all(color: sel ? m.color.withOpacity(0.75) : m.color.withOpacity(0.20),
                              width: sel ? 1.5 : 1),
                        ),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          Icon(m.icon, size: 13, color: m.color.withOpacity(sel ? 1.0 : 0.45)),
                          const SizedBox(width: 5),
                          Text(m.label, style: TextStyle(color: m.color.withOpacity(sel ? 1.0 : 0.5),
                              fontSize: 11, fontWeight: sel ? FontWeight.w800 : FontWeight.w500)),
                        ]),
                      ),
                    );
                  }).toList(),
                ),
              ),
              if (selectedMethod == 'subzero') ...[
                Padding(
                  padding: const EdgeInsets.fromLTRB(14, 14, 14, 0),
                  child: Row(children: [
                    const Icon(Icons.ac_unit_rounded, size: 13, color: Color(0xFF67E8F9)),
                    const SizedBox(width: 6),
                    const Text('SubZero Key',
                      style: TextStyle(color: Color(0xFF67E8F9), fontSize: 12, fontWeight: FontWeight.w700)),
                  ]),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 6, 12, 0),
                  child: TextField(
                    controller: szKeyCtrl,
                    keyboardType: TextInputType.number,
                    style: const TextStyle(color: Colors.white, fontSize: 14, fontFamily: 'monospace', letterSpacing: 2),
                    cursorColor: const Color(0xFF67E8F9),
                    autocorrect: false, enableSuggestions: false,
                    onChanged: (v) => szKey = v,
                    decoration: InputDecoration(
                      hintText: 'Any number — e.g. 5437, 1234, 9823',
                      hintStyle: const TextStyle(color: Color(0x3367E8F9), fontSize: 12),
                      filled: true, fillColor: Colors.white.withOpacity(0.04),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
                      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Color(0x3867E8F9))),
                      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(color: Color(0xAA67E8F9), width: 1.5)),
                    ),
                  ),
                ),
              ],
              Padding(
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 18),
                child: SizedBox(
                  width: double.infinity,
                  height: 46,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _gold,
                      foregroundColor: Colors.black87,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: () {
                      if (selectedMethod == 'subzero') szKey = szKeyCtrl.text.trim();
                      setState(() {
                        _mAssign[node.path] = _MAssign(method: selectedMethod, szKey: szKey);
                      });
                      _saveManualState();
                      Navigator.pop(ctx);
                    },
                    child: const Text('Confirm', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
    szKeyCtrl.dispose();
  }

  Future<void> _startManualBatch() async {
    if (_mZipPath == null) {
      ScaffoldMessenger.of(context).showSnackBar(_snack('Select a ZIP file first', isError: true));
      return;
    }
    if (_mAssign.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(_snack('Check at least one file to encrypt', isError: true));
      return;
    }
    if (_mProcessing) return;

    final isAlreadyRunning = (await HbcChannel.jsEncryptorBatchState())['running'] == true;
    if (isAlreadyRunning) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(_snack('Already processing', isError: true));
      return;
    }

    // Validate SubZero assignments have keys
    for (final e in _mAssign.entries) {
      if (e.value.method == 'subzero' && e.value.szKey.isEmpty) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          _snack('Enter a SubZero key for  ${e.key.split('/').last}  first', isError: true));
        return;
      }
    }

    final outDir = await StorageHelper.buildOutputDir(prefix: 'jsenc_batch');
    await HbcChannel.jsEncryptorBatchClearState();

    final tasks = _mAssign.entries.map((e) => {
      'path':   e.key,
      'method': e.value.method,
      'szKey':  e.value.szKey,
    }).toList();

    await HbcChannel.jsEncryptorBatchAnalyze(
      zipPath:   _mZipPath!,
      zipName:   _mZipName ?? 'batch.zip',
      outputDir: outDir,
      tasksJson: jsonEncode(tasks),
    );

    setState(() {
      _mProcessing = true;
      _mLogVisible = true;
      _mLogs       = '';
      _mOutputDir  = outDir;
      _mOutputFile = null;
    });
    _mLogCtrl.reset();
    _mLogCtrl.forward();
    _startManualPoll();
  }

  Future<void> _openManualOutput() async {
    final dir = _mOutputFile != null ? File(_mOutputFile!).parent.path : _mOutputDir;
    if (dir == null) return;
    try {
      await const MethodChannel('com.taurus.shield/storage').invokeMethod('openFolder', {'path': dir});
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(_snack('Output: $dir'));
    }
  }

  Future<void> _shareManualOutput() async {
    if (_mOutputFile == null) return;
    await Share.shareXFiles([XFile(_mOutputFile!)]);
  }

  Future<void> _resetManual() async {
    _mPollTimer?.cancel();
    try { await HbcChannel.jsEncryptorBatchCancel(); } catch (_) {}
    try { await HbcChannel.jsEncryptorBatchClearState(); } catch (_) {}
    _mLogCtrl.reset();
    final p = await SharedPreferences.getInstance();
    await p.remove(_kManZip);
    await p.remove(_kManName);
    await p.remove(_kManAssign);
    setState(() {
      _mZipPath = null; _mZipName = null;
      _mNodes = []; _mAssign = {};
      _mProcessing = false; _mLogVisible = false;
      _mLogs = ''; _mOutputDir = null; _mOutputFile = null;
      _mAutoScroll = true;
    });
  }

  void _applyFinishedState(Map<String, dynamic> state) {
    setState(() {
      _isProcessing = false;
      _logs       = (state['log'] as String?) ?? '';
      _outputDir  = state['outputDir'] as String?;
      _outputFile = state['outputFile'] as String?;
      _logVisible = _logs.isNotEmpty;
    });
    if (_logVisible) _logCtrl.forward();
  }

  void _startPoll() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 2), (_) async {
      final state = await HbcChannel.jsEncryptorState();
      if (!mounted) return;
      final log = (state['log'] as String?) ?? '';
      setState(() { _logs = log; });
      _scrollLog();
      if (state['running'] != true) {
        _pollTimer?.cancel();
        _applyFinishedState(state);
      }
    });
  }

  void _scrollLog() {
    if (_autoScroll && _logScroll.hasClients) {
      _logScroll.animateTo(
        _logScroll.position.maxScrollExtent,
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeOut,
      );
    }
  }

  Future<void> _pickFile() async {
    final hasPerms = await PermissionHelper.ensureStorage(context, accent: _gold);
    if (!hasPerms) return;

    final isSubZero = _selectedMethodId == 'subzero';
    final allowed   = isSubZero ? ['html', 'htm', 'zip'] : ['js', 'zip'];
    final dialogTitle = isSubZero
        ? 'Select .html / .zip'
        : 'Select .js or .zip';

    FilePickerResult? res;
    try {
      res = await FilePicker.platform.pickFiles(
        dialogTitle: dialogTitle,
        type: isSubZero ? FileType.any : FileType.custom,
        allowedExtensions: isSubZero ? null : allowed,
      );
    } catch (_) {
      res = await FilePicker.platform.pickFiles(dialogTitle: dialogTitle);
    }

    if (res == null || res.files.isEmpty) return;
    final f = res.files.first;
    if (f.path == null) return;

    final ext = f.path!.split('.').last.toLowerCase();
    if (!allowed.contains(ext)) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(_snack(
          'Unsupported file type — use ${allowed.map((e) => '.$e').join(' ')}',
          isError: true));
      }
      return;
    }

    setState(() {
      _selectedFilePath = f.path;
      _selectedFileName = f.name;
    });
  }

  Future<void> _startEncrypt() async {
    if (_selectedFilePath == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        _snack('Please select a file first', isError: true));
      return;
    }
    if (_isProcessing) return;

    if (_selectedMethodId == 'subzero') {
      if (_szKeyCtrl.text.trim().isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          _snack('Enter your SubZero key before encrypting', isError: true));
        return;
      }
    }

    final isAlreadyRunning = (await HbcChannel.jsEncryptorState())['running'] == true;
    if (isAlreadyRunning) {
      ScaffoldMessenger.of(context).showSnackBar(
        _snack('Already processing — wait for it to finish', isError: true));
      return;
    }

    final outDir = await StorageHelper.buildOutputDir(prefix: 'jsenc');

    await HbcChannel.jsEncryptorClearState();

    final isSubZeroCall = _selectedMethodId == 'subzero';
    final szKey = isSubZeroCall ? _szKeyCtrl.text.trim() : null;

    await HbcChannel.jsEncryptorAnalyze(
      filePath:   _selectedFilePath!,
      fileName:   _selectedFileName ?? _selectedFilePath!.split('/').last,
      outputDir:  outDir,
      method:     _selectedMethodId,
      subzeroKey: szKey,
    );

    setState(() {
      _isProcessing = true;
      _logVisible   = true;
      _logs         = '';
      _outputDir    = outDir;
      _outputFile   = null;
    });
    _logCtrl.forward();
    _startPoll();
  }

  Future<void> _openOutput() async {
    final dir = _outputFile != null
        ? File(_outputFile!).parent.path
        : _outputDir;
    if (dir == null) return;
    try {
      await const MethodChannel('com.taurus.shield/storage')
          .invokeMethod('openFolder', {'path': dir});
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          _snack('Output: $dir', isError: false));
      }
    }
  }

  Future<void> _shareOutput() async {
    if (_outputFile == null) return;
    await Share.shareXFiles([XFile(_outputFile!)]);
  }

  void _copyLogs() {
    if (_logs.isEmpty) return;
    Clipboard.setData(ClipboardData(text: _logs));
    ScaffoldMessenger.of(context).showSnackBar(_snack('Logs copied'));
  }

  SnackBar _snack(String msg, {bool isError = false}) => SnackBar(
    content: Text(msg, style: TextStyle(color: Colors.white, fontSize: 13)),
    backgroundColor: ThemeProvider().current.surfaceColor,
    behavior: SnackBarBehavior.floating,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(10),
      side: BorderSide(color: isError ? Colors.redAccent : _gold, width: 1),
    ),
    margin: const EdgeInsets.all(12),
    duration: const Duration(seconds: 3),
  );

  void _checkState() => _restoreSession();

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !_isProcessing && !_mProcessing,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && (_isProcessing || _mProcessing)) {
          ScaffoldMessenger.of(context).showSnackBar(
            _snack('Encryption running in background — safe to leave'));
          Navigator.of(context).pop();
        }
      },
      child: Scaffold(
        backgroundColor: ThemeProvider().current.scaffoldBg,
        appBar: _buildAppBar(),
        body: Column(
          children: [
            _buildModeBar(),
            Expanded(
              child: _manualMode ? _buildManualTab() : _buildDefaultBody(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildModeBar() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      height: 42,
      decoration: BoxDecoration(
        color: const Color(0xFF12122a),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _gold.withOpacity(0.18)),
      ),
      child: Row(
        children: [
          _modeBtn('Single File', !_manualMode, Icons.insert_drive_file_rounded,
              () { if (_manualMode) setState(() => _manualMode = false); }),
          _modeBtn('Manual ZIP', _manualMode, Icons.account_tree_rounded,
              () { if (!_manualMode) setState(() => _manualMode = true); }),
        ],
      ),
    );
  }

  Widget _modeBtn(String label, bool active, IconData icon, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          margin: const EdgeInsets.all(3),
          decoration: BoxDecoration(
            color: active ? _gold.withOpacity(0.18) : Colors.transparent,
            borderRadius: BorderRadius.circular(9),
            border: active ? Border.all(color: _gold.withOpacity(0.45)) : null,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 14, color: active ? _gold : Colors.white30),
              const SizedBox(width: 6),
              Text(
                label,
                style: TextStyle(
                  color: active ? _gold : Colors.white30,
                  fontWeight: FontWeight.w700,
                  fontSize: 12.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDefaultBody() {
    return FadeTransition(
      opacity: _cardFade,
      child: SlideTransition(
        position: _cardSlide,
        child: ListView(
          controller: _pageScroll,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          children: [
            _buildBrandBanner(),
            const SizedBox(height: 18),
            _buildSectionLabel(Icons.tune_rounded, 'STEP 1', 'Choose Obfuscation Method'),
            const SizedBox(height: 8),
            _buildMethodGrid(),
            const SizedBox(height: 18),
            _buildSectionLabel(Icons.upload_file_rounded, 'STEP 2', 'Upload File to Encrypt'),
            const SizedBox(height: 8),
            _buildFileCard(),
            if (_selectedMethodId == 'subzero') ...[
              const SizedBox(height: 14),
              _buildSubZeroKeyCard(),
            ],
            const SizedBox(height: 14),
            _buildActionButton(),
            if (_isProcessing) ...[
              const SizedBox(height: 10),
              GestureDetector(
                onTap: _resetAll,
                child: Container(
                  height: 44,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.redAccent.withOpacity(0.6)),
                    color: Colors.red.withOpacity(0.07),
                  ),
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.stop_circle_outlined, color: Colors.redAccent, size: 20),
                      SizedBox(width: 8),
                      Text('Cancel', style: TextStyle(
                        color: Colors.redAccent, fontSize: 14,
                        fontWeight: FontWeight.w700, letterSpacing: 1.1,
                      )),
                    ],
                  ),
                ),
              ),
            ],
            if (_logVisible) ...[
              const SizedBox(height: 14),
              _buildLogPanel(),
            ],
            if (_outputDir != null && !_isProcessing) ...[
              const SizedBox(height: 12),
              _buildOutputBar(),
            ],
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  AppBar _buildAppBar() {
    return AppBar(
      centerTitle: true,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios_rounded, color: Colors.white70),
        onPressed: () => Navigator.of(context).pop(),
      ),
      title: const Text('JS ENCRYPTOR',
          style: TextStyle(color: _gold, fontWeight: FontWeight.w900, letterSpacing: 2.5, fontSize: 17)),
      actions: [
        Tooltip(
          message: 'Reset session',
          child: IconButton(
            icon: const Icon(Icons.restart_alt_rounded, size: 22),
            color: Colors.white38,
            splashRadius: 22,
            onPressed: () async {
              final confirm = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  backgroundColor: const Color(0xFF12122a),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  title: const Text('Reset session?',
                      style: TextStyle(color: _gold, fontSize: 15, fontWeight: FontWeight.w700)),
                  content: const Text(
                      'Clears the selected file, all logs and output info.',
                      style: TextStyle(color: Colors.white60, fontSize: 13)),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(ctx, false),
                      child: const Text('Cancel', style: TextStyle(color: Colors.white38)),
                    ),
                    TextButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      child: const Text('Reset', style: TextStyle(color: _gold, fontWeight: FontWeight.w700)),
                    ),
                  ],
                ),
              );
              if (confirm == true) _resetAll();
            },
          ),
        ),
      ],
      flexibleSpace: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [ThemeProvider().current.appBarBg, const Color(0xFF1a0a20)],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
        ),
      ),
    );
  }

  Widget _buildBrandBanner() {
    return AnimatedBuilder(
      animation: Listenable.merge([_pulse, _scanAnim]),
      builder: (_, __) {
        final pulse = _pulse.value;
        final scan  = _scanAnim.value;
        final scanY = scan * 100.0;
        final scanOpacity = scan < 0.5
            ? (scan * 2).clamp(0.0, 1.0)
            : ((1.0 - scan) * 2).clamp(0.0, 1.0);
        return ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(20, 22, 20, 22),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              gradient: LinearGradient(
                colors: [
                  Color.lerp(const Color(0xFF1a0e00), const Color(0xFF231400), pulse)!,
                  Color.lerp(const Color(0xFF0e0e1e), const Color(0xFF14102a), pulse)!,
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              border: Border.all(
                color: Color.lerp(_gold.withOpacity(0.28), _goldGlow.withOpacity(0.5), pulse)!,
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: _gold.withOpacity(0.08 + pulse * 0.10),
                  blurRadius: 32, spreadRadius: 2,
                ),
              ],
            ),
            child: Stack(
              children: [
                // Scan line
                Positioned(
                  top: scanY, left: 0, right: 0,
                  child: Opacity(
                    opacity: scanOpacity * 0.4,
                    child: Container(
                      height: 1.5,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [
                          Colors.transparent,
                          _goldGlow.withOpacity(0.9),
                          Colors.transparent,
                        ]),
                      ),
                    ),
                  ),
                ),
                Row(
                  children: [
                    // JS Icon box with orbit ring
                    SizedBox(
                      width: 76, height: 76,
                      child: Stack(alignment: Alignment.center, children: [
                        AnimatedBuilder(
                          animation: _orbitCtrl,
                          builder: (_, __) => Transform.rotate(
                            angle: _orbitCtrl.value * 2 * math.pi,
                            child: CustomPaint(
                              size: const Size(76, 76),
                              painter: _JsOrbitPainter(
                                color: Color.lerp(_gold, _goldGlow, pulse)!,
                                opacity: 0.38 + pulse * 0.22,
                              ),
                            ),
                          ),
                        ),
                        Container(
                          width: 58, height: 58,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(14),
                            gradient: const LinearGradient(
                              colors: [Color(0xFF2a1a00), Color(0xFF1a1200)],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: _gold.withOpacity(0.22 + pulse * 0.18),
                                blurRadius: 16, spreadRadius: 1,
                              ),
                            ],
                            border: Border.all(
                              color: _gold.withOpacity(0.35 + pulse * 0.2),
                            ),
                          ),
                          child: Icon(Icons.javascript_rounded,
                              color: Color.lerp(_gold, _goldGlow, pulse), size: 32),
                        ),
                      ]),
                    ),
                    const SizedBox(width: 18),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Text('JS Encryptor',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 22,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 0.5,
                                  )),
                              const SizedBox(width: 10),
                              _badge('ADVANCED', _gold),
                            ],
                          ),
                          const SizedBox(height: 6),
                          Text(
                            '15 obfuscation methods · Decrypt',
                            style: TextStyle(
                              color: _gold.withOpacity(0.65),
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                              letterSpacing: 0.3,
                            ),
                          ),
                          const SizedBox(height: 3),
                          const Text(
                            'Air-gapped · Hardened sovereign core',
                            style: TextStyle(
                              color: Color(0xFF9ca3af),
                              fontSize: 11,
                              height: 1.4,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildSectionLabel(IconData icon, String step, String label) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
          decoration: BoxDecoration(
            color: _gold.withOpacity(0.13),
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: _gold.withOpacity(0.28)),
          ),
          child: Text(step,
              style: const TextStyle(
                color: _gold,
                fontSize: 10,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.2,
              )),
        ),
        const SizedBox(width: 10),
        Icon(icon, color: _gold.withOpacity(0.55), size: 15),
        const SizedBox(width: 6),
        Text(label,
            style: const TextStyle(
              color: Colors.white70,
              fontSize: 13,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.3,
            )),
      ],
    );
  }

  Widget _buildHeroCard() {
    return AnimatedBuilder(
      animation: Listenable.merge([_pulse, _orbitCtrl, _scanAnim]),
      builder: (_, __) {
        final pulse = _pulse.value;
        final orbit = _orbitCtrl.value;
        final scan  = _scanAnim.value;
        final scanOpacity = scan < 0.5 ? (scan * 2).clamp(0.0, 1.0) : ((1.0 - scan) * 2).clamp(0.0, 1.0);
        final scanY = scan * 64.0;

        return Container(
        padding: const EdgeInsets.fromLTRB(16, 18, 16, 18),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: LinearGradient(
            colors: [
              Color.lerp(const Color(0xFF120b00), const Color(0xFF1a1000), pulse)!,
              Color.lerp(const Color(0xFF0a0e20), const Color(0xFF0c1020), pulse)!,
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          border: Border.all(
            color: Color.lerp(_gold.withOpacity(0.22), _goldGlow.withOpacity(0.38), pulse)!,
          ),
          boxShadow: [
            BoxShadow(
              color: _gold.withOpacity(0.05 + pulse * 0.07),
              blurRadius: 28,
              spreadRadius: 2,
            ),
          ],
        ),
        child: Row(
          children: [
            SizedBox(
              width: 96, height: 96,
              child: Stack(alignment: Alignment.center, children: [
                // Outer pulse ring
                Container(
                  width: 90 + pulse * 6,
                  height: 90 + pulse * 6,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: _gold.withOpacity(0.07 + pulse * 0.07),
                      width: 1,
                    ),
                  ),
                ),
                // Rotating orbit arc
                Transform.rotate(
                  angle: orbit * 2 * math.pi,
                  child: CustomPaint(
                    size: const Size(82, 82),
                    painter: _JsOrbitPainter(
                      color: Color.lerp(_gold, _goldGlow, pulse)!,
                      opacity: 0.48 + pulse * 0.22,
                    ),
                  ),
                ),
                // Counter-rotating dot ring
                Transform.rotate(
                  angle: -orbit * 2 * math.pi * 0.55,
                  child: CustomPaint(
                    size: const Size(66, 66),
                    painter: _JsDotPainter(
                      color: _goldGlow,
                      opacity: 0.30 + pulse * 0.18,
                    ),
                  ),
                ),
                // Icon box with scan line
                Transform.scale(
                  scale: 1.0 + pulse * 0.03,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(18),
                    child: Stack(children: [
                      Container(
                        width: 64, height: 64,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Color.lerp(const Color(0xFF3d2800), const Color(0xFF4a3200), pulse)!,
                              const Color(0xFF1a1200),
                            ],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: _gold.withOpacity(0.22 + pulse * 0.18),
                              blurRadius: 18, spreadRadius: 1,
                            ),
                          ],
                        ),
                        child: Icon(Icons.javascript_rounded,
                            color: Color.lerp(_gold, _goldGlow, pulse), size: 32),
                      ),
                      // Scan line
                      Positioned(
                        top: scanY - 2, left: 0, right: 0,
                        child: Opacity(
                          opacity: scanOpacity * 0.55,
                          child: Container(
                            height: 2,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(colors: [
                                Colors.transparent,
                                _goldGlow.withOpacity(0.9),
                                Colors.transparent,
                              ]),
                            ),
                          ),
                        ),
                      ),
                    ]),
                  ),
                ),
              ]),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Text('JS Encryptor',
                          style: TextStyle(color: Colors.white, fontSize: 18,
                              fontWeight: FontWeight.w900, letterSpacing: 1)),
                      const SizedBox(width: 8),
                      _badge('FORTRESS', _gold),
                    ],
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    '15 obfuscation methods • Decrypt\n'
                    'Hardened sovereign core · air-gapped · leaves no trace',
                    style: TextStyle(color: Color(0xFF9ca3af), fontSize: 11.5, height: 1.5),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
      },
    );
  }

  Widget _buildMethodGrid() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: const LinearGradient(
          colors: [Color(0xFF0f0f1e), Color(0xFF0c0c18)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        border: Border.all(color: const Color(0xFF252540), width: 1.2),
        boxShadow: const [
          BoxShadow(color: Color(0x18000000), blurRadius: 16, spreadRadius: 2),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
            child: Row(
              children: [
                Icon(Icons.tune_rounded, size: 16, color: _gold.withOpacity(0.85)),
                const SizedBox(width: 8),
                const Text('Select Method',
                    style: TextStyle(color: Colors.white, fontSize: 13.5,
                        fontWeight: FontWeight.w700, letterSpacing: 0.5)),
                const Spacer(),
                _methodBadge(_selectedMethodId),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 0, 8, 12),
            child: LayoutBuilder(
              builder: (context, constraints) {
                const spacing = 6.0;
                const cols = 2;
                final tileW = (constraints.maxWidth - spacing * (cols - 1)) / cols;
                final tiles = _methods.map((m) => SizedBox(
                  width: tileW,
                  child: _buildMethodTile(m),
                )).toList();
                final hasOddLast = _methods.length.isOdd;
                if (hasOddLast) {
                  final last = tiles.removeLast();
                  return Column(children: [
                    Wrap(
                      spacing: spacing,
                      runSpacing: spacing,
                      children: tiles,
                    ),
                    SizedBox(height: spacing),
                    Center(child: last),
                  ]);
                }
                return Wrap(
                  spacing: spacing,
                  runSpacing: spacing,
                  children: tiles,
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMethodTile(_Method m) {
    final selected = _selectedMethodId == m.id;

    Animation<double> anim;
    switch (m.animType) {
      case _AnimType.spin:    anim = _spin;
      case _AnimType.flicker: anim = _flick;
      case _AnimType.bounce:  anim = _bounce;
      case _AnimType.breathe: anim = _pulse;
    }

    return GestureDetector(
      onTap: () => setState(() => _selectedMethodId = m.id),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(13),
          gradient: LinearGradient(
            colors: selected
                ? [m.color.withOpacity(0.28), m.color.withOpacity(0.10)]
                : [m.color.withOpacity(0.13), m.color.withOpacity(0.05)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          border: Border.all(
            color: selected ? m.color.withOpacity(0.80) : m.color.withOpacity(0.32),
            width: selected ? 1.6 : 1.1,
          ),
          boxShadow: selected
              ? [BoxShadow(color: m.color.withOpacity(0.30), blurRadius: 14, spreadRadius: 1)]
              : [BoxShadow(color: m.color.withOpacity(0.06), blurRadius: 6)],
        ),
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 11),
        child: Row(
          children: [
            AnimatedBuilder(
              animation: anim,
              builder: (_, __) {
                // Build the icon box
                Widget iconBox = Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    gradient: LinearGradient(
                      colors: [
                        m.color.withOpacity(selected ? 0.55 : 0.30),
                        m.color.withOpacity(selected ? 0.25 : 0.12),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: m.color.withOpacity(selected ? 0.45 : 0.18),
                        blurRadius: selected ? 12 : 6,
                        spreadRadius: 0,
                      ),
                    ],
                    border: Border.all(
                      color: m.color.withOpacity(selected ? 0.60 : 0.28),
                      width: 1,
                    ),
                  ),
                  child: Icon(m.icon, size: 20, color: Colors.white.withOpacity(selected ? 1.0 : 0.82)),
                );

                switch (m.animType) {
                  case _AnimType.spin:
                    return Transform.rotate(
                      angle: anim.value * 2 * math.pi,
                      child: iconBox,
                    );
                  case _AnimType.flicker:
                    return Opacity(
                      opacity: (selected ? 0.75 : 0.60) + anim.value * 0.25,
                      child: iconBox,
                    );
                  case _AnimType.bounce:
                    return Transform.translate(
                      offset: Offset(0, anim.value * (selected ? 1.2 : 0.7)),
                      child: iconBox,
                    );
                  case _AnimType.breathe:
                    final scale = (selected ? 0.92 : 0.95) + anim.value * (selected ? 0.10 : 0.06);
                    return Transform.scale(scale: scale, child: iconBox);
                }
              },
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    m.label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 12.5,
                      fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                      color: selected ? Colors.white : Colors.white.withOpacity(0.82),
                      letterSpacing: 0.2,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    m.hint,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 9,
                      color: m.color.withOpacity(selected ? 0.85 : 0.55),
                      letterSpacing: 0,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _methodBadge(String id) {
    final m = _methods.firstWhere((e) => e.id == id, orElse: () => _methods.first);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: m.color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: m.color.withOpacity(0.45)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(m.icon, size: 11, color: m.color),
          const SizedBox(width: 5),
          Text(m.label,
              style: TextStyle(color: m.color, fontSize: 11, fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }

  Widget _badge(String label, Color color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
    decoration: BoxDecoration(
      color: color.withOpacity(0.15),
      borderRadius: BorderRadius.circular(5),
      border: Border.all(color: color.withOpacity(0.5)),
    ),
    child: Text(label,
        style: TextStyle(color: color, fontSize: 9.5, fontWeight: FontWeight.w800,
            letterSpacing: 1)),
  );

  Widget _buildFileCard() {
    return Container(
      decoration: BoxDecoration(
        color: ThemeProvider().current.surfaceColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
            child: Row(
              children: [
                Icon(Icons.attach_file_rounded, size: 16, color: _gold.withOpacity(0.8)),
                const SizedBox(width: 8),
                const Text('Input File',
                    style: TextStyle(color: Colors.white, fontSize: 13.5,
                        fontWeight: FontWeight.w700, letterSpacing: 0.5)),
              ],
            ),
          ),
          const SizedBox(height: 10),
          GestureDetector(
            onTap: _isProcessing ? null : _pickFile,
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 12),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: _selectedFilePath != null
                    ? _gold.withOpacity(0.07)
                    : Colors.white.withOpacity(0.03),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: _selectedFilePath != null
                      ? _gold.withOpacity(0.4)
                      : Colors.white.withOpacity(0.1),
                  style: BorderStyle.solid,
                  width: 1.5,
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    _selectedFilePath != null
                        ? Icons.insert_drive_file_rounded
                        : Icons.upload_file_rounded,
                    color: _selectedFilePath != null ? _gold : Colors.white38,
                    size: 22,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      _selectedFilePath != null
                          ? (_selectedFileName ?? _selectedFilePath!.split('/').last)
                          : 'Tap to select file',
                      style: TextStyle(
                        color: _selectedFilePath != null ? Colors.white : Colors.white38,
                        fontSize: 13,
                        fontStyle: _selectedFilePath == null ? FontStyle.italic : FontStyle.normal,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  if (_selectedFilePath != null)
                    GestureDetector(
                      onTap: () => setState(() {
                        _selectedFilePath = null;
                        _selectedFileName = null;
                      }),
                      child: const Icon(Icons.close_rounded, color: Colors.white38, size: 18),
                    ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
            child: Text(
              _selectedMethodId == 'subzero'
                  ? 'Accepts: .html  .htm  .zip'
                  : 'Accepts: .js  .zip (multi-file)',
              style: const TextStyle(color: Color(0xFF6b7280), fontSize: 11),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSubZeroKeyCard() {
    const ice = Color(0xFF67E8F9);
    return Container(
      decoration: BoxDecoration(
        color: ThemeProvider().current.surfaceColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: ice.withOpacity(0.35)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
            child: Row(
              children: [
                Icon(Icons.ac_unit_rounded, size: 15, color: ice.withOpacity(0.85)),
                const SizedBox(width: 8),
                const Text('SubZero Key',
                    style: TextStyle(color: Colors.white, fontSize: 13.5,
                        fontWeight: FontWeight.w700, letterSpacing: 0.5)),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 6),
            child: Text(
              'Type any number as your SubZero key (e.g. 5437, 1234, 9823). It seeds the kanji XOR encoding — the output HTML will auto-decrypt in any browser, with the key embedded and obfuscated inside.',
              style: TextStyle(color: Colors.white.withOpacity(0.38), fontSize: 11, height: 1.5),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 14),
            child: TextField(
              controller: _szKeyCtrl,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.white, fontSize: 14,
                  fontFamily: 'monospace', letterSpacing: 2),
              cursorColor: ice,
              autocorrect: false,
              enableSuggestions: false,
              obscureText: false,
              decoration: InputDecoration(
                hintText: 'Any number — e.g. 5437, 1234, 9823',
                hintStyle: TextStyle(color: ice.withOpacity(0.25), fontSize: 13, letterSpacing: 1),
                filled: true,
                fillColor: Colors.white.withOpacity(0.04),
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: ice.withOpacity(0.22)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: ice.withOpacity(0.7), width: 1.5),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton() {
    final isDecrypt  = _selectedMethodId == 'decrypt';
    final isSubZero  = _selectedMethodId == 'subzero';
    final btnLabel   = _isProcessing
        ? 'Processing…'
        : isDecrypt
            ? 'Decrypt File'
            : isSubZero
                ? 'SubZero Encrypt'
                : 'Encrypt File';
    final btnIcon = _isProcessing
        ? Icons.hourglass_top_rounded
        : isDecrypt
            ? Icons.lock_open_rounded
            : Icons.lock_rounded;

    return ScaleTransition(
      scale: _btnScale,
      child: GestureDetector(
        onTap: _isProcessing ? null : _startEncrypt,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          height: 54,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: LinearGradient(
              colors: _isProcessing
                  ? [const Color(0xFF2a2a40), const Color(0xFF2a2a40)]
                  : [_goldDim, _gold],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: _isProcessing ? [] : [
              BoxShadow(color: _gold.withOpacity(0.35), blurRadius: 18, spreadRadius: -2),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (_isProcessing)
                AnimatedBuilder(
                  animation: _spin,
                  builder: (_, c) => Transform.rotate(
                    angle: _spin.value * 6.28,
                    child: const Icon(Icons.autorenew_rounded, color: Colors.white54, size: 22),
                  ),
                )
              else
                Icon(btnIcon, color: Colors.black87, size: 22),
              const SizedBox(width: 10),
              Text(btnLabel,
                  style: TextStyle(
                    color: _isProcessing ? Colors.white54 : Colors.black87,
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.2,
                  )),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLogPanel() {
    final method = _methods.firstWhere(
        (m) => m.id == _selectedMethodId, orElse: () => _methods.first);
    final hasOutput = _outputFile != null && !_isProcessing;
    final isSuccess = hasOutput && !_logs.contains('[!] Error');

    return FadeTransition(
      opacity: _logFade,
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF0c0c1e),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: _isProcessing
                ? _gold.withOpacity(0.4)
                : isSuccess
                    ? const Color(0xFF22c55e).withOpacity(0.5)
                    : Colors.red.withOpacity(0.4),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 8, 0),
              child: Row(
                children: [
                  Icon(Icons.terminal_rounded,
                      size: 14,
                      color: _isProcessing ? _gold : Colors.white38),
                  const SizedBox(width: 6),
                  Icon(method.icon,
                      size: 13,
                      color: _isProcessing
                          ? _gold
                          : isSuccess
                              ? const Color(0xFF22c55e)
                              : Colors.redAccent),
                  const SizedBox(width: 5),
                  Flexible(
                    child: Text(
                      _isProcessing
                          ? 'Processing  [${method.label}]'
                          : isSuccess
                              ? 'Complete  [${method.label}]'
                              : 'Error  [${method.label}]',
                      style: TextStyle(
                        color: _isProcessing
                            ? _gold
                            : isSuccess
                                ? const Color(0xFF22c55e)
                                : Colors.redAccent,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.content_copy_rounded,
                        size: 16, color: Colors.white38),
                    onPressed: _copyLogs,
                    tooltip: 'Copy logs',
                    constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
                    padding: EdgeInsets.zero,
                  ),
                  Switch(
                    value: _autoScroll,
                    onChanged: (v) => setState(() => _autoScroll = v),
                    activeColor: _gold,
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                ],
              ),
            ),
            Container(
              height: 220,
              margin: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.black45,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Scrollbar(
                controller: _logScroll,
                thumbVisibility: true,
                child: ListView(
                  controller: _logScroll,
                  padding: const EdgeInsets.all(10),
                  children: [
                    Text(
                      _logs.isEmpty ? 'Waiting for engine…' : _logs,
                      style: TextStyle(
                        fontFamily: 'monospace',
                        fontSize: 11.5,
                        color: _logs.isEmpty
                            ? Colors.white24
                            : Colors.white.withOpacity(0.85),
                        height: 1.55,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOutputBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF22c55e).withOpacity(0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF22c55e).withOpacity(0.35)),
      ),
      child: Row(
        children: [
          const Icon(Icons.folder_open_rounded, color: Color(0xFF22c55e), size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              'Output: ${_outputDir ?? ''}',
              style: const TextStyle(color: Colors.white70, fontSize: 11.5),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          const SizedBox(width: 8),
          if (_outputFile != null)
            IconButton(
              icon: const Icon(Icons.share_rounded, color: Color(0xFF22c55e), size: 20),
              onPressed: _shareOutput,
              tooltip: 'Share file',
              constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
              padding: EdgeInsets.zero,
            ),
          IconButton(
            icon: const Icon(Icons.open_in_new_rounded, color: Color(0xFF22c55e), size: 20),
            onPressed: _openOutput,
            tooltip: 'Open folder',
            constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
            padding: EdgeInsets.zero,
          ),
        ],
      ),
    );
  }
  // ─── Manual tab UI ────────────────────────────────────────────────────────

  Widget _buildManualTab() {
    final hasZip     = _mZipPath != null;
    final selected   = _mAssign.length;
    final visNodes   = _mNodes.where((n) => n.visible).toList();
    final isSuccess  = _mOutputFile != null && !_mProcessing;
    final hasResult  = _mOutputDir != null && !_mProcessing;

    return ListView(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      children: [
        // ── ZIP picker card ─────────────────────────────────────────────────
        Container(
          decoration: BoxDecoration(
            color: ThemeProvider().current.surfaceColor,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: hasZip ? _gold.withOpacity(0.4) : _border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
                child: Row(children: [
                  Icon(Icons.folder_zip_rounded, size: 16, color: _gold.withOpacity(0.8)),
                  const SizedBox(width: 8),
                  const Text('Source ZIP', style: TextStyle(color: Colors.white,
                      fontSize: 13.5, fontWeight: FontWeight.w700, letterSpacing: 0.5)),
                ]),
              ),
              const SizedBox(height: 10),
              GestureDetector(
                onTap: _mProcessing ? null : _pickManualZip,
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 12),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: hasZip ? _gold.withOpacity(0.07) : Colors.white.withOpacity(0.03),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: hasZip ? _gold.withOpacity(0.4) : Colors.white.withOpacity(0.1),
                      width: 1.5,
                    ),
                  ),
                  child: Row(children: [
                    Icon(hasZip ? Icons.folder_zip_rounded : Icons.upload_file_rounded,
                        color: hasZip ? _gold : Colors.white38, size: 22),
                    const SizedBox(width: 12),
                    Expanded(child: Text(
                      hasZip ? (_mZipName ?? _mZipPath!.split('/').last) : 'Tap to select ZIP file',
                      style: TextStyle(color: hasZip ? Colors.white : Colors.white38,
                          fontSize: 13, fontStyle: hasZip ? FontStyle.normal : FontStyle.italic),
                      maxLines: 2, overflow: TextOverflow.ellipsis,
                    )),
                    if (hasZip)
                      GestureDetector(
                        onTap: () => setState(() {
                          _mZipPath = null; _mZipName = null;
                          _mNodes = []; _mAssign = {};
                        }),
                        child: const Icon(Icons.close_rounded, color: Colors.white38, size: 18),
                      ),
                  ]),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 14),
                child: Text(
                  hasZip
                      ? '${_mNodes.where((n) => !n.isDir).length} file(s) found · ${_mNodes.where((n) => !n.isDir && n.selectable).length} selectable'
                      : 'Accepts: .zip  —  pick JS files to encrypt per method',
                  style: const TextStyle(color: Color(0xFF6b7280), fontSize: 11),
                ),
              ),
            ],
          ),
        ),

        // ── File tree ────────────────────────────────────────────────────────
        if (hasZip && _mNodes.isNotEmpty) ...[
          const SizedBox(height: 14),
          Container(
            decoration: BoxDecoration(
              color: ThemeProvider().current.surfaceColor,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: _border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 14, 8, 10),
                  child: Row(children: [
                    Icon(Icons.account_tree_rounded, size: 16, color: _gold.withOpacity(0.8)),
                    const SizedBox(width: 8),
                    const Text('File Browser', style: TextStyle(color: Colors.white,
                        fontSize: 13.5, fontWeight: FontWeight.w700, letterSpacing: 0.5)),
                    const Spacer(),
                    if (selected > 0)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: _gold.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: _gold.withOpacity(0.5)),
                        ),
                        child: Text('$selected selected',
                            style: const TextStyle(color: _gold, fontSize: 10, fontWeight: FontWeight.w800)),
                      ),
                    const SizedBox(width: 4),
                    TextButton(
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        minimumSize: Size.zero,
                      ),
                      onPressed: _selectAllSelectable,
                      child: const Text('All', style: TextStyle(color: _gold, fontSize: 11, fontWeight: FontWeight.w700)),
                    ),
                    TextButton(
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        minimumSize: Size.zero,
                      ),
                      onPressed: _clearAllSelections,
                      child: const Text('Clear', style: TextStyle(color: Colors.white38, fontSize: 11)),
                    ),
                    const SizedBox(width: 4),
                  ]),
                ),
                const Divider(color: Color(0xFF1a1a35), height: 1),
                Container(
                  constraints: const BoxConstraints(maxHeight: 360),
                  child: ListView.builder(
                    shrinkWrap: true,
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    itemCount: visNodes.length,
                    itemBuilder: (_, i) => _buildTreeRow(visNodes[i]),
                  ),
                ),
              ],
            ),
          ),
        ],

        // ── Encrypt button ───────────────────────────────────────────────────
        if (hasZip) ...[
          const SizedBox(height: 14),
          GestureDetector(
            onTap: _mProcessing ? null : _startManualBatch,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              height: 54,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                gradient: LinearGradient(
                  colors: _mProcessing
                      ? [const Color(0xFF2a2a40), const Color(0xFF2a2a40)]
                      : (selected > 0 ? [_goldDim, _gold] : [const Color(0xFF1a1a30), const Color(0xFF252540)]),
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: (_mProcessing || selected == 0) ? [] : [
                  BoxShadow(color: _gold.withOpacity(0.35), blurRadius: 18, spreadRadius: -2),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (_mProcessing)
                    AnimatedBuilder(
                      animation: _spin,
                      builder: (_, __) => Transform.rotate(
                        angle: _spin.value * 6.28,
                        child: const Icon(Icons.autorenew_rounded, color: Colors.white54, size: 22),
                      ),
                    )
                  else
                    Icon(Icons.lock_rounded,
                        color: selected > 0 ? Colors.black87 : Colors.white24, size: 22),
                  const SizedBox(width: 10),
                  Text(
                    _mProcessing
                        ? 'Processing…'
                        : selected > 0
                            ? 'Encrypt  ($selected file${selected == 1 ? '' : 's'})'
                            : 'Select files above',
                    style: TextStyle(
                      color: _mProcessing ? Colors.white54 : (selected > 0 ? Colors.black87 : Colors.white24),
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.2,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],

        // ── Cancel button (batch) ────────────────────────────────────────────
        if (_mProcessing) ...[
          const SizedBox(height: 10),
          GestureDetector(
            onTap: _resetManual,
            child: Container(
              height: 44,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.redAccent.withOpacity(0.6)),
                color: Colors.red.withOpacity(0.07),
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.stop_circle_outlined, color: Colors.redAccent, size: 20),
                  SizedBox(width: 8),
                  Text('Cancel', style: TextStyle(
                    color: Colors.redAccent, fontSize: 14,
                    fontWeight: FontWeight.w700, letterSpacing: 1.1,
                  )),
                ],
              ),
            ),
          ),
        ],

        // ── Live log terminal ────────────────────────────────────────────────
        if (_mLogVisible) ...[
          const SizedBox(height: 14),
          _buildManualLogPanel(isSuccess),
        ],

        // ── Output bar ───────────────────────────────────────────────────────
        if (hasResult) ...[
          const SizedBox(height: 12),
          _buildManualOutputBar(),
        ],

        const SizedBox(height: 30),
      ],
    );
  }

  Widget _buildTreeRow(_ZipNode node) {
    final indent = (node.depth * 20.0) + 12.0;
    if (node.isDir) {
      return InkWell(
        onTap: () => _toggleFolder(node),
        child: Padding(
          padding: EdgeInsets.only(left: indent, right: 12, top: 6, bottom: 6),
          child: Row(children: [
            AnimatedRotation(
              turns: node.expanded ? 0.25 : 0,
              duration: const Duration(milliseconds: 200),
              child: const Icon(Icons.chevron_right_rounded, size: 16, color: Colors.white54),
            ),
            const SizedBox(width: 6),
            Icon(node.expanded ? Icons.folder_open_rounded : Icons.folder_rounded,
                size: 16, color: _gold.withOpacity(0.65)),
            const SizedBox(width: 8),
            Expanded(child: Text(node.name,
                style: const TextStyle(color: Colors.white70, fontSize: 12.5, fontWeight: FontWeight.w600),
                overflow: TextOverflow.ellipsis)),
            Text(
              '${_mNodes.where((n) => !n.isDir && n.path.startsWith('${node.path}/')).length}',
              style: const TextStyle(color: Colors.white24, fontSize: 10.5),
            ),
            const SizedBox(width: 4),
          ]),
        ),
      );
    }

    // File row
    final checked    = _mAssign.containsKey(node.path);
    final assign     = _mAssign[node.path];
    final canSelect  = node.selectable;
    final fileColor  = node.isJs ? _gold : node.isHtml ? const Color(0xFF67E8F9) : Colors.white24;

    return InkWell(
      onTap: canSelect ? () => _toggleFile(node) : null,
      child: Padding(
        padding: EdgeInsets.only(left: indent, right: 12, top: 4, bottom: 4),
        child: Row(children: [
          SizedBox(
            width: 20, height: 20,
            child: canSelect
                ? Checkbox(
                    value: checked,
                    onChanged: (_) => _toggleFile(node),
                    activeColor: _gold,
                    checkColor: Colors.black,
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    side: BorderSide(color: Colors.white24),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                  )
                : const Icon(Icons.remove_rounded, size: 14, color: Colors.white12),
          ),
          const SizedBox(width: 8),
          Icon(Icons.insert_drive_file_rounded, size: 14, color: fileColor),
          const SizedBox(width: 6),
          Expanded(child: Text(node.name,
              style: TextStyle(
                color: canSelect ? Colors.white.withOpacity(0.85) : Colors.white24,
                fontSize: 12.5,
              ),
              overflow: TextOverflow.ellipsis)),
          if (checked && assign != null) ...[
            const SizedBox(width: 6),
            GestureDetector(
              onTap: () => _showMethodPicker(node),
              child: Builder(builder: (_) {
                final m = _methods.firstWhere((e) => e.id == assign.method, orElse: () => _methods.first);
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: m.color.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(7),
                    border: Border.all(color: m.color.withOpacity(0.55)),
                  ),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(m.icon, size: 10, color: m.color),
                    const SizedBox(width: 4),
                    Text(m.label, style: TextStyle(color: m.color, fontSize: 10, fontWeight: FontWeight.w800)),
                    const SizedBox(width: 3),
                    Icon(Icons.expand_more_rounded, size: 11, color: m.color.withOpacity(0.7)),
                  ]),
                );
              }),
            ),
          ] else if (!canSelect) ...[
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.04),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                node.path.split('.').last.toUpperCase(),
                style: const TextStyle(color: Colors.white24, fontSize: 9, fontWeight: FontWeight.w600, letterSpacing: 0.5),
              ),
            ),
          ],
          const SizedBox(width: 2),
        ]),
      ),
    );
  }

  Widget _buildManualLogPanel(bool isSuccess) {
    return FadeTransition(
      opacity: _mLogFade,
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF0c0c1e),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: _mProcessing
                ? _gold.withOpacity(0.4)
                : isSuccess
                    ? const Color(0xFF22c55e).withOpacity(0.5)
                    : Colors.red.withOpacity(0.4),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 8, 0),
              child: Row(children: [
                Icon(Icons.terminal_rounded, size: 14,
                    color: _mProcessing ? _gold : Colors.white38),
                const SizedBox(width: 6),
                Icon(Icons.folder_zip_rounded, size: 13,
                    color: _mProcessing ? _gold : isSuccess ? const Color(0xFF22c55e) : Colors.redAccent),
                const SizedBox(width: 5),
                Flexible(child: Text(
                  _mProcessing ? 'Batch Processing…' : isSuccess ? 'Batch Complete' : 'Batch Error',
                  style: TextStyle(
                    color: _mProcessing ? _gold : isSuccess ? const Color(0xFF22c55e) : Colors.redAccent,
                    fontSize: 12, fontWeight: FontWeight.w700,
                  ),
                  overflow: TextOverflow.ellipsis,
                )),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.content_copy_rounded, size: 16, color: Colors.white38),
                  onPressed: () {
                    if (_mLogs.isEmpty) return;
                    Clipboard.setData(ClipboardData(text: _mLogs));
                    ScaffoldMessenger.of(context).showSnackBar(_snack('Logs copied'));
                  },
                  tooltip: 'Copy logs',
                  constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
                  padding: EdgeInsets.zero,
                ),
                Switch(
                  value: _mAutoScroll,
                  onChanged: (v) => setState(() => _mAutoScroll = v),
                  activeColor: _gold,
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
              ]),
            ),
            Container(
              height: 220,
              margin: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.black45,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Scrollbar(
                controller: _mLogScroll,
                thumbVisibility: true,
                child: ListView(
                  controller: _mLogScroll,
                  padding: const EdgeInsets.all(10),
                  children: [
                    Text(
                      _mLogs.isEmpty ? 'Waiting for engine…' : _mLogs,
                      style: TextStyle(
                        fontFamily: 'monospace',
                        fontSize: 11.5,
                        color: _mLogs.isEmpty ? Colors.white24 : Colors.white.withOpacity(0.85),
                        height: 1.55,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildManualOutputBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF22c55e).withOpacity(0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF22c55e).withOpacity(0.35)),
      ),
      child: Row(children: [
        const Icon(Icons.folder_open_rounded, color: Color(0xFF22c55e), size: 20),
        const SizedBox(width: 10),
        Expanded(child: Text(
          'Output: ${_mOutputDir ?? ''}',
          style: const TextStyle(color: Colors.white70, fontSize: 11.5),
          maxLines: 2, overflow: TextOverflow.ellipsis,
        )),
        const SizedBox(width: 8),
        if (_mOutputFile != null)
          IconButton(
            icon: const Icon(Icons.share_rounded, color: Color(0xFF22c55e), size: 20),
            onPressed: _shareManualOutput,
            tooltip: 'Share file',
            constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
            padding: EdgeInsets.zero,
          ),
        IconButton(
          icon: const Icon(Icons.open_in_new_rounded, color: Color(0xFF22c55e), size: 20),
          onPressed: _openManualOutput,
          tooltip: 'Open folder',
          constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
          padding: EdgeInsets.zero,
        ),
      ]),
    );
  }
}

// ── Custom painters for JS encryptor animated header ──────────────────────────

class _JsOrbitPainter extends CustomPainter {
  final Color color;
  final double opacity;
  const _JsOrbitPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r  = math.min(cx, cy) - 1;
    final paint = Paint()
      ..color = color.withOpacity(opacity)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4
      ..strokeCap = StrokeCap.round;

    const dashAngle = 0.38;
    const gapAngle  = 0.22;
    double angle = 0;
    while (angle < math.pi * 2) {
      canvas.drawArc(
        Rect.fromCircle(center: Offset(cx, cy), radius: r),
        angle, dashAngle, false, paint,
      );
      angle += dashAngle + gapAngle;
    }
  }

  @override
  bool shouldRepaint(_JsOrbitPainter old) =>
      old.color != color || old.opacity != opacity;
}

class _JsDotPainter extends CustomPainter {
  final Color color;
  final double opacity;
  const _JsDotPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r  = math.min(cx, cy) - 2;
    final paint = Paint()
      ..color = color.withOpacity(opacity)
      ..style = PaintingStyle.fill;

    const count = 6;
    for (var i = 0; i < count; i++) {
      final a = (i / count) * math.pi * 2;
      canvas.drawCircle(
        Offset(cx + r * math.cos(a), cy + r * math.sin(a)),
        2.0, paint,
      );
    }
  }

  @override
  bool shouldRepaint(_JsDotPainter old) =>
      old.color != color || old.opacity != opacity;
}
