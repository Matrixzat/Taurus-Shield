import '../widgets/guide_modal.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:share_plus/share_plus.dart';
import '../utils/storage_helper.dart';
import 'package:pointycastle/export.dart' as pc;
import '../utils/theme_provider.dart';

// ── Magic-byte extension detector — used when decrypted file has no extension ──
String? _detectExtension(Uint8List b) {
  if (b.length < 4) return null;
  // MP3 (ID3 tag or sync word)
  if ((b[0] == 0xFF && (b[1] & 0xE0) == 0xE0) ||
      (b[0] == 0x49 && b[1] == 0x44 && b[2] == 0x33)) return 'mp3';
  // JPEG
  if (b[0] == 0xFF && b[1] == 0xD8 && b[2] == 0xFF) return 'jpg';
  // PNG
  if (b[0] == 0x89 && b[1] == 0x50 && b[2] == 0x4E && b[3] == 0x47) return 'png';
  // GIF
  if (b[0] == 0x47 && b[1] == 0x49 && b[2] == 0x46) return 'gif';
  // PDF
  if (b[0] == 0x25 && b[1] == 0x50 && b[2] == 0x44 && b[3] == 0x46) return 'pdf';
  // ZIP / APK
  if (b[0] == 0x50 && b[1] == 0x4B && b[2] == 0x03 && b[3] == 0x04) return 'zip';
  // MP4 / M4A / MOV (ftyp box at offset 4)
  if (b.length >= 12 &&
      b[4] == 0x66 && b[5] == 0x74 && b[6] == 0x79 && b[7] == 0x70) return 'mp4';
  // WAV / AVI (RIFF)
  if (b[0] == 0x52 && b[1] == 0x49 && b[2] == 0x46 && b[3] == 0x46) {
    if (b.length >= 12 && b[8] == 0x57 && b[9] == 0x41 && b[10] == 0x56 && b[11] == 0x45) return 'wav';
    return 'avi';
  }
  // OGG (audio/video)
  if (b[0] == 0x4F && b[1] == 0x67 && b[2] == 0x67 && b[3] == 0x53) return 'ogg';
  // FLAC
  if (b[0] == 0x66 && b[1] == 0x4C && b[2] == 0x61 && b[3] == 0x43) return 'flac';
  // AAC (ADTS)
  if (b[0] == 0xFF && (b[1] & 0xF6) == 0xF0) return 'aac';
  // MKV / WebM
  if (b[0] == 0x1A && b[1] == 0x45 && b[2] == 0xDF && b[3] == 0xA3) return 'mkv';
  // DEX (Android)
  if (b[0] == 0x64 && b[1] == 0x65 && b[2] == 0x78 && b[3] == 0x0A) return 'dex';
  // ELF (binary / .so)
  if (b[0] == 0x7F && b[1] == 0x45 && b[2] == 0x4C && b[3] == 0x46) return 'elf';
  return null;
}

// ── Background isolate workers — all CPU-heavy crypto here, never on UI thread ──

Map<String, dynamic> _decryptIsolate(Map<String, dynamic> p) {
  final pwText     = p['pwText']     as String;
  final aadText    = p['aadText']    as String;
  final keyBits    = p['keyBits']    as int;
  final iv         = p['iv']         as Uint8List;
  final ciphertext = p['ciphertext'] as Uint8List;
  final derivedKey = p['derivedKey'] as Uint8List?;

  Uint8List encKey;
  if (derivedKey != null) {
    // password mode — key already derived natively before entering isolate
    encKey = derivedKey;
  } else {
    // hex key mode — decode directly
    encKey = Uint8List.fromList(
      List.generate(pwText.length ~/ 2,
          (i) => int.parse(pwText.substring(i * 2, i * 2 + 2), radix: 16)),
    );
  }

  final aad = aadText.isNotEmpty ? Uint8List.fromList(utf8.encode(aadText)) : Uint8List(0);

  final cipher = pc.GCMBlockCipher(pc.AESEngine());
  cipher.init(false, pc.AEADParameters(pc.KeyParameter(encKey), 128, iv, aad));
  return {'plaintext': cipher.process(ciphertext)};
}

Map<String, dynamic> _encryptIsolate(Map<String, dynamic> p) {
  final keySourceIdx = p['keySourceIdx'] as int;
  final hexKey       = p['hexKey']       as String;
  final keyBits      = p['keyBits']      as int;
  final pbkdf2Iter   = p['pbkdf2Iter']   as int;
  final kdfHash      = p['kdfHash']      as String;
  final aadText      = p['aadText']      as String;
  final plaintext    = p['plaintext']    as Uint8List;
  final derivedKey   = p['derivedKey']   as Uint8List?;
  final preGenSalt   = p['preGenSalt']   as Uint8List?;
  final preGenIv     = p['preGenIv']     as Uint8List?;

  final rng = pc.SecureRandom('Fortuna')
    ..seed(pc.KeyParameter(
        Uint8List.fromList(List.generate(32, (_) => Random.secure().nextInt(256)))));

  final salt = preGenSalt ?? rng.nextBytes(32);
  final iv   = preGenIv   ?? rng.nextBytes(12);

  Uint8List encKey;
  String?   autoKey;

  if (derivedKey != null) {
    // password mode — key already derived natively before entering isolate
    encKey = derivedKey;
  } else if (keySourceIdx == 2) {
    // auto-generate
    encKey  = rng.nextBytes(keyBits ~/ 8);
    autoKey = encKey.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
  } else {
    // raw hex
    final hex = hexKey.replaceAll(RegExp(r'[^0-9a-fA-F]'), '');
    encKey = Uint8List.fromList(
      List.generate(hex.length ~/ 2,
          (i) => int.parse(hex.substring(i * 2, i * 2 + 2), radix: 16)),
    );
  }

  final aad = aadText.isNotEmpty ? Uint8List.fromList(utf8.encode(aadText)) : null;

  final cipher = pc.GCMBlockCipher(pc.AESEngine());
  cipher.init(true, pc.AEADParameters(
    pc.KeyParameter(encKey), 128, iv, aad ?? Uint8List(0),
  ));
  final ciphertext = cipher.process(plaintext);

  final header = <int>[
    0x42, 0x46, 0x45, 0x01,
    keyBits == 256 ? 0x02 : 0x01,
    kdfHash == 'SHA-512' ? 0x02 : 0x01,
    ...(keySourceIdx == 0
        ? [(pbkdf2Iter >> 16) & 0xFF, (pbkdf2Iter >> 8) & 0xFF, pbkdf2Iter & 0xFF]
        : [0, 0, 0]),
    aad != null ? 0x01 : 0x00,
  ];

  return {
    'output':  Uint8List.fromList([...header, ...salt, ...iv, ...ciphertext]),
    'autoKey': autoKey,
  };
}

class BlackForgeScreen extends StatefulWidget {
  const BlackForgeScreen({super.key});
  @override
  State<BlackForgeScreen> createState() => _BlackForgeScreenState();
}

class _BlackForgeScreenState extends State<BlackForgeScreen>
    with TickerProviderStateMixin {
  late TabController _tabCtrl;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 4, vsync: this);
    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = ThemeProvider().current;
    return Scaffold(
      backgroundColor: theme.scaffoldBg,
      appBar: AppBar(
        backgroundColor: theme.appBarBg,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text('BLACK FORGE',
            style: TextStyle(color: theme.highlightColor, fontSize: 18,
                fontWeight: FontWeight.w900, letterSpacing: 2)),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.menu_book_rounded, color: theme.highlightColor, size: 20),
            tooltip: 'How to Use',
            onPressed: () => showGuideModal(context, initialIndex: 8, singleTool: true),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(kTextTabBarHeight + 1),
          child: Column(children: [
            TabBar(
              controller: _tabCtrl,
              indicatorColor: theme.highlightColor,
              labelColor: theme.highlightColor,
              unselectedLabelColor: Colors.white38,
              labelStyle: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
              tabs: const [
                Tab(icon: Icon(Icons.lock_rounded, size: 17), text: 'Encrypt'),
                Tab(icon: Icon(Icons.lock_open_rounded, size: 17), text: 'Decrypt'),
                Tab(icon: Icon(Icons.archive_rounded, size: 17), text: 'Archive'),
                Tab(icon: Icon(Icons.shield_rounded, size: 17), text: 'Security'),
              ],
            ),
            Container(height: 1, color: theme.highlightColor.withOpacity(0.20)),
          ]),
        ),
      ),
      body: TabBarView(
        controller: _tabCtrl,
        children: [
          _EncryptTab(pulseAnim: _pulseAnim),
          const _DecryptTab(),
          const _ArchiveTab(),
          const _SecurityInfoTab(),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// ENCRYPT TAB
// ─────────────────────────────────────────────────────────────────────────────
enum _KeySource { password, hex, autoGen }

class _EncryptTab extends StatefulWidget {
  final Animation<double> pulseAnim;
  const _EncryptTab({required this.pulseAnim});
  @override
  State<_EncryptTab> createState() => _EncryptTabState();
}

class _EncryptTabState extends State<_EncryptTab> {
  static const _channel = MethodChannel('com.taurus.shield/forge');

  _KeySource _keySource = _KeySource.password;
  final _pwCtrl = TextEditingController();
  final _hexCtrl = TextEditingController();
  final _aadCtrl = TextEditingController();
  bool _obscurePw = true;
  String _keySize = 'AES-256';
  int _pbkdf2Iter = 1000000;
  String _kdfHash = 'SHA-512';
  String? _selectedFilePath;
  String? _selectedFileName;
  bool _processing = false;
  double _progress = 0;
  String _status = '';
  Timer? _progressTimer;

  final _keySizes = ['AES-128', 'AES-256'];
  final _iterations = [600000, 1000000, 2000000, 5000000, 7000000, 10000000];
  final _hashes = ['SHA-256', 'SHA-512'];

  int get _keyBits => _keySize == 'AES-256' ? 256 : 128;

  static String _iterLabel(int n) {
    if (n >= 1000000) return '${n ~/ 1000000}M';
    return '${n ~/ 1000}k';
  }

  @override
  void dispose() {
    _progressTimer?.cancel();
    _pwCtrl.dispose();
    _hexCtrl.dispose();
    _aadCtrl.dispose();
    super.dispose();
  }

  void _startProgressPolling() {
    _progressTimer?.cancel();
    _progressTimer = Timer.periodic(const Duration(milliseconds: 150), (_) async {
      if (!_processing || !mounted) { _progressTimer?.cancel(); return; }
      try {
        final p = await _channel.invokeMethod<int>('forge_get_progress');
        if (mounted && _processing) {
          setState(() { _progress = ((p ?? 0).clamp(0, 100)) / 100.0; });
        }
      } catch (_) {}
    });
  }

  Future<void> _cancel() async {
    try { await _channel.invokeMethod('forge_cancel'); } catch (_) {}
    _progressTimer?.cancel();
    _progressTimer = null;
    if (mounted) setState(() { _processing = false; _status = 'Cancelled.'; _progress = 0; });
  }

  Future<void> _pickFile() async {
    final r = await FilePicker.platform.pickFiles();
    if (r != null && r.files.single.path != null) {
      setState(() {
        _selectedFilePath = r.files.single.path;
        _selectedFileName = r.files.single.name;
      });
    }
  }

  Future<void> _encrypt() async {
    if (_selectedFilePath == null) return;

    // 150 MB hard limit
    final fileSize = File(_selectedFilePath!).lengthSync();
    if (fileSize > 150 * 1024 * 1024) {
      _showMsg('File too large — maximum size for encryption is 150 MB');
      return;
    }

    // Fast validation only — no crypto on the UI thread
    if (_keySource == _KeySource.hex) {
      final hex = _hexCtrl.text.replaceAll(RegExp(r'[^0-9a-fA-F]'), '');
      if (hex.length != (_keyBits ~/ 4)) {
        _showMsg('Hex key must be ${_keyBits ~/ 4} hex chars (${_keyBits ~/ 8} bytes)');
        return;
      }
    } else if (_keySource == _KeySource.password) {
      if (_pwCtrl.text.isEmpty) { _showMsg('Enter a password'); return; }
    }

    setState(() { _processing = true; _progress = 0; _status = 'Starting...'; });
    _startProgressPolling();

    try {
      final root     = await StorageHelper.getRootDir();
      final forgeDir = '$root/${StorageHelper.appFolder}/output/forge';

      // Entire pipeline runs natively: file I/O + PBKDF2 + AES-GCM (hardware-accelerated).
      // No 259 MB data transfer through Dart — Kotlin reads, encrypts, and writes directly.
      final result = await _channel.invokeMethod<Map>('forge_encrypt_file', {
        'filePath':   _selectedFilePath,
        'keySource':  _keySource.index,
        'password':   _pwCtrl.text,
        'hexKey':     _hexCtrl.text,
        'keyBits':    _keyBits,
        'iterations': _pbkdf2Iter,
        'hashAlg':    _kdfHash == 'SHA-512' ? 'SHA512' : 'SHA256',
        'aadText':    _aadCtrl.text,
        'outputDir':  forgeDir,
      });

      _progressTimer?.cancel();
      setState(() { _progress = 1.0; });

      final outPath = result?['outputPath'] as String? ?? '';
      final autoKey = result?['autoKey']   as String?;
      final outName = outPath.split('/').last;

      setState(() { _status = 'Encrypted: $outName'; });

      if (!mounted) return;
      _showResult(outPath, outName, autoKey);
    } catch (e) {
      _progressTimer?.cancel();
      final msg = e.toString();
      if (msg.contains('CANCELLED')) {
        setState(() { _status = 'Cancelled.'; _progress = 0; });
      } else {
        setState(() { _status = 'Error: $msg'; });
      }
    } finally {
      _progressTimer?.cancel();
      _progressTimer = null;
      setState(() => _processing = false);
    }
  }

  String _bytesToHex(Uint8List bytes) =>
      bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();

  void _showMsg(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: Colors.red.shade800),
    );
  }

  void _showResult(String path, String name, String? autoKey) {
    final theme = ThemeProvider().current;
    showModalBottomSheet(
      context: context,
      backgroundColor: theme.surfaceColor,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.check_circle_rounded, color: theme.highlightColor, size: 48),
          const SizedBox(height: 12),
          Text('Encryption Complete', style: TextStyle(
              color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text(name, style: const TextStyle(color: Colors.white60, fontSize: 12)),
          if (autoKey != null) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.red.shade900.withOpacity(0.3),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.red.shade400.withOpacity(0.5)),
              ),
              child: Column(children: [
                const Text('SAVE THIS KEY — you cannot recover it!',
                    style: TextStyle(color: Colors.redAccent, fontSize: 11, fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                SelectableText(autoKey,
                    style: const TextStyle(color: Colors.white70, fontSize: 10, fontFamily: 'monospace')),
              ]),
            ),
          ],
          const SizedBox(height: 16),
          Row(children: [
            Expanded(child: OutlinedButton.icon(
              icon: const Icon(Icons.copy_rounded, size: 16),
              label: const Text('Copy Path'),
              style: OutlinedButton.styleFrom(foregroundColor: theme.highlightColor,
                  side: BorderSide(color: theme.highlightColor.withOpacity(0.5))),
              onPressed: () {
                Clipboard.setData(ClipboardData(text: path));
                Navigator.pop(context);
                _showMsg('Path copied');
              },
            )),
            const SizedBox(width: 10),
            Expanded(child: ElevatedButton.icon(
              icon: const Icon(Icons.share_rounded, size: 16),
              label: const Text('Share'),
              style: ElevatedButton.styleFrom(backgroundColor: theme.highlightColor,
                  foregroundColor: Colors.black),
              onPressed: () {
                Share.shareXFiles([XFile(path)]);
                Navigator.pop(context);
              },
            )),
          ]),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = ThemeProvider().current;
    final hl = theme.highlightColor;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionLabel('Key source', hl),
        const SizedBox(height: 8),
        Row(children: [
          _chip('Password', _keySource == _KeySource.password, hl,
              () => setState(() => _keySource = _KeySource.password)),
          const SizedBox(width: 8),
          _chip('Raw hex', _keySource == _KeySource.hex, hl,
              () => setState(() => _keySource = _KeySource.hex)),
          const SizedBox(width: 8),
          _chip('Auto-generate', _keySource == _KeySource.autoGen, hl,
              () => setState(() => _keySource = _KeySource.autoGen)),
        ]),
        const SizedBox(height: 16),
        if (_keySource == _KeySource.password)
          _inputField(
            controller: _pwCtrl, hint: 'Password', hl: hl,
            obscure: _obscurePw,
            suffix: IconButton(
              icon: Icon(_obscurePw ? Icons.visibility_off : Icons.visibility,
                  color: Colors.white38, size: 20),
              onPressed: () => setState(() => _obscurePw = !_obscurePw),
            ),
          ),
        if (_keySource == _KeySource.hex)
          _inputField(controller: _hexCtrl,
              hint: 'Hex key (${_keyBits ~/ 4} chars)', hl: hl),
        if (_keySource == _KeySource.autoGen)
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: hl.withOpacity(0.08),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: hl.withOpacity(0.25)),
            ),
            child: Text('A random ${_keyBits}-bit key will be generated.\nYou must save it — it cannot be recovered.',
                style: TextStyle(color: hl, fontSize: 12, height: 1.5)),
          ),
        const SizedBox(height: 20),
        _sectionLabel('Encryption config', hl),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: _dropdown('Key size', _keySize, _keySizes, hl,
              (v) => setState(() => _keySize = v!))),
          const SizedBox(width: 10),
          if (_keySource == _KeySource.password)
            Expanded(child: _dropdown('PBKDF2 iterations',
                _iterLabel(_pbkdf2Iter),
                _iterations.map(_iterLabel).toList(), hl,
                (v) {
                  final idx = _iterations.indexWhere((i) => _iterLabel(i) == v);
                  if (idx >= 0) setState(() => _pbkdf2Iter = _iterations[idx]);
                })),
        ]),
        const SizedBox(height: 10),
        Row(children: [
          if (_keySource == _KeySource.password)
            Expanded(child: _dropdown('KDF hash', _kdfHash, _hashes, hl,
                (v) => setState(() => _kdfHash = v!))),
          Expanded(child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
            decoration: BoxDecoration(
              color: hl.withOpacity(0.06),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: hl.withOpacity(0.20)),
            ),
            child: Text('96-bit (GCM standard)',
                style: TextStyle(color: hl.withOpacity(0.7), fontSize: 12)),
          )),
        ]),
        const SizedBox(height: 16),
        _inputField(controller: _aadCtrl,
            hint: 'AAD — additional authenticated data (optional)', hl: hl),
        const SizedBox(height: 6),
        Text('AAD is not encrypted but cryptographically bound — any mismatch fails decryption.',
            style: TextStyle(color: Colors.white30, fontSize: 10, height: 1.4)),
        const SizedBox(height: 20),
        _sectionLabel('Input file', hl),
        const SizedBox(height: 8),
        GestureDetector(
          onTap: _pickFile,
          child: AnimatedBuilder(
            animation: widget.pulseAnim,
            builder: (_, __) => Container(
              padding: const EdgeInsets.symmetric(vertical: 28),
              decoration: BoxDecoration(
                color: hl.withOpacity(0.06 + widget.pulseAnim.value * 0.04),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: hl.withOpacity(0.25 + widget.pulseAnim.value * 0.15)),
              ),
              child: Column(children: [
                Icon(Icons.upload_file_rounded, color: hl, size: 32),
                const SizedBox(height: 8),
                Text(_selectedFileName ?? 'Tap to select file',
                    style: TextStyle(color: _selectedFileName != null ? Colors.white : Colors.white54,
                        fontSize: 13)),
              ]),
            ),
          ),
        ),
        const SizedBox(height: 20),
        if (_processing) ...[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(_status, style: TextStyle(color: hl, fontSize: 11)),
              Text('${(_progress * 100).toInt()}%',
                  style: TextStyle(color: hl, fontSize: 13, fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: _progress,
              backgroundColor: Colors.white10,
              color: hl,
              minHeight: 6,
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            height: 40,
            child: OutlinedButton.icon(
              icon: const Icon(Icons.cancel_rounded, size: 16),
              label: const Text('Cancel', style: TextStyle(fontWeight: FontWeight.w600)),
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.redAccent,
                side: const BorderSide(color: Colors.redAccent),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              onPressed: _cancel,
            ),
          ),
          const SizedBox(height: 12),
        ],
        if (!_processing)
        SizedBox(
          width: double.infinity,
          height: 48,
          child: ElevatedButton.icon(
            icon: const Icon(Icons.lock_rounded, size: 18),
            label: const Text('Encrypt',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
            style: ElevatedButton.styleFrom(
              backgroundColor: hl,
              foregroundColor: Colors.black,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            onPressed: _encrypt,
          ),
        ),
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// DECRYPT TAB
// ─────────────────────────────────────────────────────────────────────────────
class _DecryptTab extends StatefulWidget {
  const _DecryptTab();
  @override
  State<_DecryptTab> createState() => _DecryptTabState();
}

class _DecryptTabState extends State<_DecryptTab> {
  static const _channel = MethodChannel('com.taurus.shield/forge');

  final _pwCtrl = TextEditingController();
  final _aadCtrl = TextEditingController();
  String? _selectedFilePath;
  String? _selectedFileName;
  bool _processing = false;
  double _progress = 0;
  String _status = '';
  Timer? _progressTimer;

  @override
  void dispose() {
    _progressTimer?.cancel();
    _pwCtrl.dispose();
    _aadCtrl.dispose();
    super.dispose();
  }

  void _startProgressPolling() {
    _progressTimer?.cancel();
    _progressTimer = Timer.periodic(const Duration(milliseconds: 150), (_) async {
      if (!_processing || !mounted) { _progressTimer?.cancel(); return; }
      try {
        final p = await _channel.invokeMethod<int>('forge_get_progress');
        if (mounted && _processing) {
          setState(() { _progress = ((p ?? 0).clamp(0, 100)) / 100.0; });
        }
      } catch (_) {}
    });
  }

  Future<void> _cancel() async {
    try { await _channel.invokeMethod('forge_cancel'); } catch (_) {}
    _progressTimer?.cancel();
    _progressTimer = null;
    if (mounted) setState(() { _processing = false; _status = 'Cancelled.'; _progress = 0; });
  }

  Future<void> _pickFile() async {
    final r = await FilePicker.platform.pickFiles(
      type: FileType.any,
    );
    if (r != null && r.files.single.path != null) {
      setState(() {
        _selectedFilePath = r.files.single.path;
        _selectedFileName = r.files.single.name;
      });
    }
  }

  Future<void> _decrypt() async {
    if (_selectedFilePath == null) { _showMsg('Select a .enc file'); return; }
    if (_pwCtrl.text.isEmpty) { _showMsg('Enter password or hex key'); return; }

    // 150 MB hard limit (applies to the .enc file size)
    final fileSize = File(_selectedFilePath!).lengthSync();
    if (fileSize > 150 * 1024 * 1024) {
      _showMsg('File too large — maximum size for decryption is 150 MB');
      return;
    }

    setState(() { _processing = true; _progress = 0; _status = 'Starting...'; });
    _startProgressPolling();

    try {
      final root     = await StorageHelper.getRootDir();
      final forgeDir = '$root/${StorageHelper.appFolder}/output/forge';

      // Entire pipeline runs natively: file I/O + PBKDF2 + AES-GCM (hardware-accelerated).
      // Kotlin reads the header, derives the key, decrypts, and writes the output file.
      final result = await _channel.invokeMethod<Map>('forge_decrypt_file', {
        'filePath':  _selectedFilePath,
        'password':  _pwCtrl.text,
        'aadText':   _aadCtrl.text,
        'outputDir': forgeDir,
      });

      _progressTimer?.cancel();
      setState(() { _progress = 1.0; });

      final outPath = result?['outputPath'] as String? ?? '';
      final outName = outPath.split('/').last;

      setState(() => _status = 'Decrypted: $outName');

      if (!mounted) return;
      final theme = ThemeProvider().current;
      showModalBottomSheet(
        context: context,
        backgroundColor: theme.surfaceColor,
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
        builder: (_) => Padding(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.check_circle_rounded, color: theme.highlightColor, size: 48),
            const SizedBox(height: 12),
            const Text('Decryption Complete', style: TextStyle(
                color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(outName, style: const TextStyle(color: Colors.white60, fontSize: 12)),
            const SizedBox(height: 16),
            Row(children: [
              Expanded(child: OutlinedButton.icon(
                icon: const Icon(Icons.copy_rounded, size: 16),
                label: const Text('Copy Path'),
                style: OutlinedButton.styleFrom(foregroundColor: theme.highlightColor,
                    side: BorderSide(color: theme.highlightColor.withOpacity(0.5))),
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: outPath));
                  Navigator.pop(context);
                },
              )),
              const SizedBox(width: 10),
              Expanded(child: ElevatedButton.icon(
                icon: const Icon(Icons.share_rounded, size: 16),
                label: const Text('Share'),
                style: ElevatedButton.styleFrom(backgroundColor: theme.highlightColor,
                    foregroundColor: Colors.black),
                onPressed: () {
                  Share.shareXFiles([XFile(outPath)]);
                  Navigator.pop(context);
                },
              )),
            ]),
          ]),
        ),
      );
    } catch (e) {
      _progressTimer?.cancel();
      final msg = e.toString();
      if (msg.contains('CANCELLED')) {
        setState(() { _status = 'Cancelled.'; _progress = 0; });
      } else if (msg.contains('BAD_TAG') || msg.contains('Tag mismatch') || msg.contains('mac')) {
        _showMsg('Wrong password / key, or file is corrupted');
      } else {
        _showMsg('Decryption failed: $msg');
      }
    } finally {
      _progressTimer?.cancel();
      _progressTimer = null;
      setState(() => _processing = false);
    }
  }

  void _showMsg(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: Colors.red.shade800),
    );
  }

  @override
  Widget build(BuildContext context) {
    final hl = ThemeProvider().current.highlightColor;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionLabel('Decrypt .enc file', hl),
        const SizedBox(height: 12),
        GestureDetector(
          onTap: _pickFile,
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 28),
            decoration: BoxDecoration(
              color: hl.withOpacity(0.06),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: hl.withOpacity(0.25)),
            ),
            child: Column(children: [
              Icon(Icons.file_open_rounded, color: hl, size: 32),
              const SizedBox(height: 8),
              Text(_selectedFileName ?? 'Tap to select .enc file',
                  style: TextStyle(color: _selectedFileName != null ? Colors.white : Colors.white54, fontSize: 13)),
            ]),
          ),
        ),
        const SizedBox(height: 16),
        _inputField(controller: _pwCtrl, hint: 'Password or hex key (same as encryption)', hl: hl),
        const SizedBox(height: 12),
        _inputField(controller: _aadCtrl, hint: 'AAD (leave blank if none was used)', hl: hl),
        const SizedBox(height: 20),
        if (_processing) ...[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(_status, style: TextStyle(color: hl, fontSize: 11)),
              Text('${(_progress * 100).toInt()}%',
                  style: TextStyle(color: hl, fontSize: 13, fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: _progress,
              backgroundColor: Colors.white10,
              color: hl,
              minHeight: 6,
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            height: 40,
            child: OutlinedButton.icon(
              icon: const Icon(Icons.cancel_rounded, size: 16),
              label: const Text('Cancel', style: TextStyle(fontWeight: FontWeight.w600)),
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.redAccent,
                side: const BorderSide(color: Colors.redAccent),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              onPressed: _cancel,
            ),
          ),
          const SizedBox(height: 12),
        ],
        if (_status.isNotEmpty && !_processing)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Text(_status, style: TextStyle(color: hl, fontSize: 11)),
          ),
        if (!_processing)
        SizedBox(
          width: double.infinity,
          height: 48,
          child: ElevatedButton.icon(
            icon: const Icon(Icons.lock_open_rounded, size: 18),
            label: const Text('Decrypt',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
            style: ElevatedButton.styleFrom(
              backgroundColor: hl,
              foregroundColor: Colors.black,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            onPressed: _decrypt,
          ),
        ),
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// ARCHIVE TAB
// ─────────────────────────────────────────────────────────────────────────────
class _ArchiveTab extends StatefulWidget {
  const _ArchiveTab();
  @override
  State<_ArchiveTab> createState() => _ArchiveTabState();
}

class _ArchiveTabState extends State<_ArchiveTab> {
  static const _channel = MethodChannel('com.taurus.shield/forge');

  String _mode = 'compress'; // 'compress' or 'extract'
  String _format = '7z';
  String _compression = 'Maximum';
  String _encryption = 'AES-256 (data + filenames)';
  String _splitVolume = 'No';
  final _pwCtrl = TextEditingController();
  bool _deleteSource = false;
  bool _obscurePw = true;
  final List<String> _selectedFiles = [];
  final List<String> _selectedNames = [];
  bool _processing = false;
  String _status = '';
  double _progress = 0;
  String? _pendingExtractPath;

  final _formats = ['7z', 'zip', 'tar', 'bzip2', 'gzip', 'xz', 'lz4', 'zstd',
    'tar.bz2', 'tar.gz', 'tar.xz', 'tar.lz4', 'tar.zstd'];
  final _compressions = ['No compression', 'Fastest', 'Fast', 'Normal', 'Maximum', 'Ultra'];
  final _encryptions = ['None', 'AES-256 (data)', 'AES-256 (data + filenames)'];
  final _splits = ['No', '5MB', '8MB', '10MB', '24MB', '50MB', '100MB', '250MB', '500MB', '1GB', '2GB', '4GB'];

  @override
  void initState() {
    super.initState();
    _checkRunning();
  }

  Future<void> _checkRunning() async {
    try {
      final state = await _channel.invokeMethod<Map>('forge_state');
      if (state != null && state['running'] == true) {
        setState(() { _processing = true; _status = state['logs']?.toString() ?? 'Processing...'; });
        _pollState();
      }
    } catch (_) {}
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _pwCtrl.dispose();
    super.dispose();
  }

  int _compressionLevel() {
    switch (_compression) {
      case 'No compression': return 0;
      case 'Fastest': return 1;
      case 'Fast': return 3;
      case 'Normal': return 5;
      case 'Maximum': return 7;
      case 'Ultra': return 9;
      default: return 7;
    }
  }

  String? _splitSize() {
    if (_splitVolume == 'No') return null;
    return _splitVolume.toLowerCase();
  }

  Future<void> _pickFiles() async {
    final r = await FilePicker.platform.pickFiles(allowMultiple: true);
    if (r != null) {
      setState(() {
        _selectedFiles.clear();
        _selectedNames.clear();
        for (final f in r.files) {
          if (f.path != null) {
            _selectedFiles.add(f.path!);
            _selectedNames.add(f.name);
          }
        }
      });
    }
  }

  Future<void> _compress() async {
    if (_selectedFiles.isEmpty) { _showMsg('Select files first'); return; }
    if (_encryption != 'None' && _pwCtrl.text.isEmpty) { _showMsg('Enter a password for encryption'); return; }

    setState(() { _processing = true; _progress = 0; _status = 'Compressing...'; });

    try {
      await _channel.invokeMethod('forge_compress', {
        'files': _selectedFiles,
        'format': _format,
        'level': _compressionLevel(),
        'encryption': _encryption == 'None' ? 'none'
            : _encryption.contains('filenames') ? 'aes256_full' : 'aes256_data',
        'password': _pwCtrl.text,
        'split': _splitSize(),
        'deleteSource': _deleteSource,
      });
      _pollState();
    } on PlatformException catch (e) {
      setState(() { _status = 'Error: ${e.message}'; _processing = false; });
    }
  }

  Future<void> _extract() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.any);
    if (r == null || r.files.single.path == null) return;

    _pendingExtractPath = r.files.single.path;
    setState(() { _processing = true; _status = 'Checking archive...'; });

    // Step 1: detect encryption before touching the archive
    bool isEncrypted = false;
    try {
      final detect = await _channel.invokeMethod<Map>('forge_detect', {
        'file': _pendingExtractPath,
      });
      isEncrypted = detect?['encrypted'] == true;
    } catch (_) {
      // if detect fails, proceed without password
    }

    String password = '';
    if (isEncrypted) {
      setState(() { _processing = false; _status = ''; });
      final pw = await _showPasswordDialog(title: 'Archive is encrypted');
      if (pw == null) {
        setState(() { _status = ''; });
        return;
      }
      password = pw;
    }

    setState(() { _processing = true; _status = 'Extracting...'; });
    try {
      await _channel.invokeMethod('forge_extract', {
        'file': _pendingExtractPath,
        'password': password,
      });
      _pollState(isExtract: true);
    } on PlatformException catch (e) {
      setState(() { _status = 'Error: ${e.message}'; _processing = false; });
    }
  }

  Future<void> _retryExtractWithPassword(String password) async {
    if (_pendingExtractPath == null) return;
    setState(() { _processing = true; _status = 'Extracting...'; });
    try {
      await _channel.invokeMethod('forge_extract', {
        'file': _pendingExtractPath,
        'password': password,
      });
      _pollState(isExtract: false);
    } on PlatformException catch (e) {
      setState(() { _status = 'Error: ${e.message}'; _processing = false; });
    }
  }

  Timer? _pollTimer;

  bool _looksLikePasswordError(String error) {
    final lower = error.toLowerCase();
    return lower.contains('password') ||
        lower.contains('wrong') ||
        lower.contains('encrypt') ||
        lower.contains('cannot open') ||
        lower.contains('data error');
  }

  void _pollState({bool isExtract = false}) {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 1), (_) async {
      try {
        final state = await _channel.invokeMethod<Map>('forge_state');
        if (state == null) return;
        final running = state['running'] == true;
        final logs = state['logs']?.toString() ?? '';
        final status = state['status']?.toString() ?? '';
        final output = state['output']?.toString() ?? '';
        final error = state['error']?.toString() ?? '';

        if (!mounted) { _pollTimer?.cancel(); return; }

        if (running) {
          final pct = (state['progress'] as int? ?? 0) / 100.0;
          setState(() {
            _status = logs.isNotEmpty ? logs : 'Processing...';
            if (pct > 0) _progress = pct;
          });
        } else {
          _pollTimer?.cancel();
          if (status == 'success') {
            setState(() { _status = 'Done: $output'; _progress = 1.0; _processing = false; });
            _showMsg('Completed successfully');
          } else if (isExtract && _looksLikePasswordError(error)) {
            setState(() { _processing = false; _status = ''; });
            final password = await _showPasswordDialog(title: 'Archive is encrypted');
            if (password != null && password.isNotEmpty) {
              _retryExtractWithPassword(password);
            } else {
              setState(() { _status = 'Extraction cancelled — archive is encrypted'; });
            }
          } else {
            setState(() { _status = 'Error: $error'; _processing = false; });
          }
        }
      } catch (_) {}
    });
  }

  Future<String?> _showPasswordDialog({String title = 'Archive password'}) async {
    final ctrl = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: ThemeProvider().current.surfaceColor,
        title: Text(title, style: const TextStyle(color: Colors.white, fontSize: 14)),
        content: TextField(
          controller: ctrl,
          obscureText: true,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: 'Leave empty if none',
            hintStyle: const TextStyle(color: Colors.white30),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(color: ThemeProvider().current.highlightColor.withOpacity(0.3)),
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, ''), child: const Text('Skip')),
          TextButton(onPressed: () => Navigator.pop(ctx, ctrl.text), child: const Text('OK')),
        ],
      ),
    );
  }

  void _showMsg(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: ThemeProvider().current.highlightColor.withOpacity(0.8)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final hl = ThemeProvider().current.highlightColor;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(children: [
          Expanded(child: SizedBox(height: 44, child: ElevatedButton.icon(
            icon: const Icon(Icons.archive_rounded, size: 18),
            label: const Text('Compress', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
            style: ElevatedButton.styleFrom(
                backgroundColor: _mode == 'compress' ? hl.withOpacity(0.18) : Colors.transparent,
                foregroundColor: _mode == 'compress' ? hl : Colors.white38,
                elevation: 0,
                side: BorderSide(color: _mode == 'compress' ? hl.withOpacity(0.5) : Colors.white12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            onPressed: _processing ? null : () => setState(() => _mode = 'compress'),
          ))),
          const SizedBox(width: 10),
          Expanded(child: SizedBox(height: 44, child: ElevatedButton.icon(
            icon: const Icon(Icons.unarchive_rounded, size: 18),
            label: const Text('Extract', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
            style: ElevatedButton.styleFrom(
                backgroundColor: _mode == 'extract' ? hl.withOpacity(0.18) : Colors.transparent,
                foregroundColor: _mode == 'extract' ? hl : Colors.white38,
                elevation: 0,
                side: BorderSide(color: _mode == 'extract' ? hl.withOpacity(0.5) : Colors.white12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            onPressed: _processing ? null : () => setState(() => _mode = 'extract'),
          ))),
        ]),
        if (_mode == 'compress') ...[
          const SizedBox(height: 20),
          _sectionLabel('Archive settings', hl),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: _dropdown('Format', _format, _formats, hl,
                (v) => setState(() => _format = v!))),
            const SizedBox(width: 10),
            Expanded(child: _dropdown('Compression', _compression, _compressions, hl,
                (v) => setState(() => _compression = v!))),
          ]),
          const SizedBox(height: 10),
          _dropdown('Encryption', _encryption, _encryptions, hl,
              (v) => setState(() => _encryption = v!)),
          const SizedBox(height: 10),
          if (_encryption != 'None')
            _inputField(controller: _pwCtrl, hint: 'Password', hl: hl,
                obscure: _obscurePw,
                suffix: IconButton(
                  icon: Icon(_obscurePw ? Icons.visibility_off : Icons.visibility,
                      color: Colors.white38, size: 20),
                  onPressed: () => setState(() => _obscurePw = !_obscurePw),
                )),
          if (_encryption != 'None') const SizedBox(height: 10),
          Row(children: [
            Expanded(child: _dropdown('Split volumes', _splitVolume, _splits, hl,
                (v) => setState(() => _splitVolume = v!))),
            const SizedBox(width: 10),
            Expanded(child: GestureDetector(
              onTap: () => setState(() => _deleteSource = !_deleteSource),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                decoration: BoxDecoration(
                  color: _deleteSource ? hl.withOpacity(0.12) : Colors.white.withOpacity(0.04),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _deleteSource ? hl.withOpacity(0.5) : Colors.white12),
                ),
                child: Row(children: [
                  Icon(_deleteSource ? Icons.check_box : Icons.check_box_outline_blank,
                      color: _deleteSource ? hl : Colors.white30, size: 18),
                  const SizedBox(width: 8),
                  Expanded(child: Text('Delete source', style: TextStyle(
                      color: _deleteSource ? hl : Colors.white38, fontSize: 11))),
                ]),
              ),
            )),
          ]),
          const SizedBox(height: 20),
          _sectionLabel('Select files', hl),
          const SizedBox(height: 8),
          GestureDetector(
            onTap: _pickFiles,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 24),
              decoration: BoxDecoration(
                color: hl.withOpacity(0.06),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: hl.withOpacity(0.25)),
              ),
              child: Column(children: [
                Icon(Icons.add_rounded, color: hl, size: 28),
                const SizedBox(height: 6),
                Text(_selectedFiles.isEmpty
                    ? 'Tap to select files'
                    : '${_selectedFiles.length} file(s) selected',
                    style: TextStyle(color: _selectedFiles.isNotEmpty ? Colors.white : Colors.white54, fontSize: 13)),
                if (_selectedNames.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(_selectedNames.take(3).join(', ') + (_selectedNames.length > 3 ? '...' : ''),
                        style: const TextStyle(color: Colors.white30, fontSize: 10)),
                  ),
              ]),
            ),
          ),
        ],
        if (_mode == 'extract') ...[
          const SizedBox(height: 40),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 32),
            decoration: BoxDecoration(
              color: hl.withOpacity(0.06),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: hl.withOpacity(0.2)),
            ),
            child: Column(children: [
              Icon(Icons.unarchive_rounded, color: hl.withOpacity(0.5), size: 36),
              const SizedBox(height: 12),
              Text('Tap Extract to pick an archive file',
                  style: TextStyle(color: Colors.white38, fontSize: 13)),
              const SizedBox(height: 4),
              Text('Supports 7z, zip, tar, gz, bz2, xz and more',
                  style: TextStyle(color: Colors.white24, fontSize: 11)),
            ]),
          ),
        ],
        const SizedBox(height: 20),
        if (_processing) ...[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(_status, style: TextStyle(color: hl, fontSize: 11),
                    overflow: TextOverflow.ellipsis),
              ),
              const SizedBox(width: 8),
              Text(
                _progress > 0 ? '${(_progress * 100).toInt()}%' : '...',
                style: TextStyle(color: hl, fontSize: 13, fontWeight: FontWeight.bold),
              ),
            ],
          ),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: _progress > 0 ? _progress : null,
              backgroundColor: Colors.white10,
              color: hl,
              minHeight: 6,
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            height: 40,
            child: OutlinedButton.icon(
              icon: const Icon(Icons.cancel_rounded, size: 16),
              label: const Text('Cancel', style: TextStyle(fontWeight: FontWeight.w600)),
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.redAccent,
                side: const BorderSide(color: Colors.redAccent),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              onPressed: () async {
                try { await _channel.invokeMethod('forge_cancel_archive'); } catch (_) {}
                _pollTimer?.cancel();
                setState(() { _processing = false; _status = 'Cancelled.'; _progress = 0; });
              },
            ),
          ),
          const SizedBox(height: 12),
        ],
        if (!_processing)
        SizedBox(
          width: double.infinity,
          height: 48,
          child: ElevatedButton.icon(
            icon: Icon(_mode == 'compress' ? Icons.archive_rounded : Icons.unarchive_rounded, size: 18),
            label: Text(
              _mode == 'compress' ? 'Compress' : 'Extract',
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: hl,
              foregroundColor: Colors.black,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            onPressed: _mode == 'compress' ? _compress : _extract,
          ),
        ),
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// SECURITY INFO TAB
// ─────────────────────────────────────────────────────────────────────────────
class _SecurityInfoTab extends StatelessWidget {
  const _SecurityInfoTab();

  @override
  Widget build(BuildContext context) {
    final hl = ThemeProvider().current.highlightColor;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionLabel('Current config', hl),
        const SizedBox(height: 10),
        _infoRow('Cipher', 'AES-256-GCM (authenticated encryption)', hl),
        _infoRow('KDF', 'PBKDF2-SHA-512', hl),
        _infoRow('Iterations', '1,000,000 — 10,000,000', hl),
        _infoRow('Salt', '256-bit random — new every encryption', hl),
        _infoRow('IV / Nonce', '96-bit random — new every encryption', hl),
        _infoRow('Auth tag', '128-bit GCM tag', hl),
        _infoRow('AAD binding', 'Optional', hl),
        const SizedBox(height: 24),
        _sectionLabel('Why this cannot be cracked', hl),
        const SizedBox(height: 12),
        _securityCard(
          icon: Icons.shield_rounded,
          color: hl,
          title: 'AES-256-GCM',
          desc: 'NSA/NIST approved. 2²⁵⁶ key combinations — all computers on Earth combined cannot brute-force this.',
        ),
        const SizedBox(height: 10),
        _securityCard(
          icon: Icons.key_rounded,
          color: const Color(0xFFFFA726),
          title: 'PBKDF2 (600K–10M iterations)',
          desc: 'Each password guess costs up to 10,000,000 hash operations. At 1 billion/sec, that allows only 100 guesses/sec — brute-force is computationally impossible even against nation-state hardware.',
        ),
        const SizedBox(height: 10),
        _securityCard(
          icon: Icons.shuffle_rounded,
          color: const Color(0xFF42A5F5),
          title: 'Random salt (256-bit)',
          desc: 'Same password → completely different key every time. Defeats rainbow tables.',
        ),
        const SizedBox(height: 10),
        _securityCard(
          icon: Icons.fingerprint_rounded,
          color: const Color(0xFFEF5350),
          title: 'Random IV per message',
          desc: 'Same plaintext encrypted twice = completely different ciphertext. Zero pattern leakage.',
        ),
        const SizedBox(height: 10),
        _securityCard(
          icon: Icons.verified_rounded,
          color: const Color(0xFF66BB6A),
          title: 'GCM auth tag (128-bit)',
          desc: 'Any 1-bit change in ciphertext is instantly detected. Modified data cannot be decrypted.',
        ),
        const SizedBox(height: 10),
        _securityCard(
          icon: Icons.devices_rounded,
          color: const Color(0xFFAB47BC),
          title: '100% Offline',
          desc: 'All encryption and decryption happens on your device. No data is uploaded, transmitted, or stored externally.',
        ),
        const SizedBox(height: 20),
      ],
    );
  }

  static Widget _securityCard({
    required IconData icon,
    required Color color,
    required String title,
    required String desc,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withOpacity(0.06),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.20)),
      ),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: color, size: 22),
        const SizedBox(width: 12),
        Expanded(child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text(desc, style: const TextStyle(color: Colors.white54, fontSize: 11, height: 1.5)),
          ],
        )),
      ]),
    );
  }

  static Widget _infoRow(String label, String value, Color hl) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.white.withOpacity(0.06))),
      ),
      child: Row(children: [
        SizedBox(width: 100, child: Text(label, style: const TextStyle(color: Colors.white54, fontSize: 12))),
        Expanded(child: Text(value, style: const TextStyle(color: Colors.white, fontSize: 12))),
      ]),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// SHARED WIDGETS
// ─────────────────────────────────────────────────────────────────────────────
Widget _sectionLabel(String text, Color hl) {
  return Text(text, style: TextStyle(color: hl, fontSize: 13, fontWeight: FontWeight.w700));
}

Widget _inputField({
  required TextEditingController controller,
  required String hint,
  required Color hl,
  bool obscure = false,
  Widget? suffix,
}) {
  return TextField(
    controller: controller,
    obscureText: obscure,
    style: const TextStyle(color: Colors.white, fontSize: 13),
    decoration: InputDecoration(
      hintText: hint,
      hintStyle: const TextStyle(color: Colors.white30, fontSize: 12),
      filled: true,
      fillColor: hl.withOpacity(0.05),
      suffixIcon: suffix,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: hl.withOpacity(0.20)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: hl.withOpacity(0.60)),
      ),
    ),
  );
}

Widget _chip(String label, bool selected, Color hl, VoidCallback onTap) {
  return GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: selected ? hl : Colors.transparent,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: selected ? hl : Colors.white24),
      ),
      child: Text(label, style: TextStyle(
        color: selected ? Colors.black : Colors.white54,
        fontSize: 11, fontWeight: FontWeight.w600,
      )),
    ),
  );
}

Widget _dropdown(String label, String value, List<String> items, Color hl,
    ValueChanged<String?> onChanged) {
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
    decoration: BoxDecoration(
      color: hl.withOpacity(0.06),
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: hl.withOpacity(0.20)),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: TextStyle(color: hl.withOpacity(0.6), fontSize: 9)),
        DropdownButton<String>(
          value: value,
          isExpanded: true,
          isDense: true,
          underline: const SizedBox.shrink(),
          dropdownColor: const Color(0xFF1a1a2e),
          style: const TextStyle(color: Colors.white, fontSize: 12),
          icon: Icon(Icons.expand_more, color: hl.withOpacity(0.5), size: 18),
          items: items.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
          onChanged: onChanged,
        ),
      ],
    ),
  );
}
