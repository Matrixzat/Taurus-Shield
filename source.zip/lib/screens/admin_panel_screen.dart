import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../services/native_secrets.dart';

class AdminPanelScreen extends StatefulWidget {
  const AdminPanelScreen({super.key});
  @override
  State<AdminPanelScreen> createState() => _AdminPanelScreenState();
}

class _AdminPanelScreenState extends State<AdminPanelScreen> {
  late final WebViewController _ctrl;
  bool _loading = true;
  String _url = '';

  static const _kPrimary = Color(0xFFFF0A0A);
  static const _kBg      = Color(0xFF060610);

  @override
  void initState() {
    super.initState();
    _initWebView();
  }

  Future<void> _initWebView() async {
    final workerUrl = await NativeSecrets.updaterUrl();
    final base = workerUrl.isNotEmpty
        ? workerUrl
        : 'https://taurus-shield-updater.matrixzat99.workers.dev';

    setState(() => _url = base);

    _ctrl = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(_kBg)
      ..setNavigationDelegate(NavigationDelegate(
        onPageStarted: (_) => setState(() => _loading = true),
        onPageFinished: (_) => setState(() => _loading = false),
        onWebResourceError: (_) => setState(() => _loading = false),
      ))
      ..loadRequest(Uri.parse(base));

    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light,
      child: Scaffold(
        backgroundColor: _kBg,
        appBar: AppBar(
          backgroundColor: const Color(0xFF0d0d20),
          foregroundColor: Colors.white,
          elevation: 0,
          title: const Text(
            'DEVICE MANAGER',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w800,
              letterSpacing: 2,
              color: Colors.white,
            ),
          ),
          centerTitle: true,
          actions: [
            IconButton(
              tooltip: 'Reload',
              icon: const Icon(Icons.refresh_rounded, size: 20),
              onPressed: () => _ctrl.reload(),
            ),
          ],
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(1),
            child: Container(
              height: 1,
              color: const Color(0xFF1a1a35),
            ),
          ),
        ),
        body: Stack(
          children: [
            if (_url.isNotEmpty)
              WebViewWidget(controller: _ctrl)
            else
              const Center(
                child: CircularProgressIndicator(
                  color: Color(0xFF7c3aed),
                  strokeWidth: 2,
                ),
              ),
            if (_loading && _url.isNotEmpty)
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: LinearProgressIndicator(
                  backgroundColor: Colors.transparent,
                  color: _kPrimary,
                  minHeight: 2,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
