import '../utils/theme_provider.dart';
import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import '../utils/hbc_channel.dart';
import '../utils/storage_helper.dart';

const _kSslAccent      = Color(0xFF06b6d4);
const _kSslAccentDark  = Color(0xFF0891b2);
const _kSslAccentLight = Color(0xFF67e8f9);

class SslUnpinnerScreen extends StatefulWidget {
  const SslUnpinnerScreen({super.key});

  @override
  State<SslUnpinnerScreen> createState() => _SslUnpinnerScreenState();
}

class _SslUnpinnerScreenState extends State<SslUnpinnerScreen>
    with TickerProviderStateMixin {

  String? _selectedFilePath;
  String? _selectedFileName;
  bool    _isProcessing    = false;
  bool    _logVisible      = false;
  String  _logs            = '';
  String? _outputDir;
  String? _outputPath;
  bool    _autoScroll      = true;

  StreamSubscription<String>? _streamSub;
  Timer?  _pollTimer;
  final Stopwatch _stopwatch = Stopwatch();
  Timer?  _tickTimer;
  String  _elapsed = '00:00';

  final ScrollController _logScrollCtrl  = ScrollController();
  final ScrollController _pageScrollCtrl = ScrollController();
  final GlobalKey        _logPanelKey    = GlobalKey();

  late final AnimationController _pulseCtrl;
  late final AnimationController _orbitCtrl;
  late final AnimationController _scanCtrl;
  late final AnimationController _logCtrl;
  late final AnimationController _shieldCtrl;
  late final Animation<double> _pulseAnim;
  late final Animation<double> _logFade;
  late final Animation<double> _scanAnim;
  late final Animation<double> _shieldAnim;

  static const _accent = _kSslAccent;

  @override
  void initState() {
    super.initState();

    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _orbitCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 4500),
    )..repeat();

    _scanCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2200),
    )..repeat();

    _logCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 400),
    );

    _shieldCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 3000),
    )..repeat(reverse: true);

    _pulseAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
    _logFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _logCtrl, curve: Curves.easeOut),
    );
    _scanAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _scanCtrl, curve: Curves.easeInOut),
    );
    _shieldAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _shieldCtrl, curve: Curves.easeInOut),
    );

    _checkState();
  }

  Future<void> _checkState() async {
    try {
      final state   = await HbcChannel.sslUnpinState();
      final running = state['running'] == true;
      final status  = (state['status'] as String?) ?? '';
      final logs    = (state['logs'] as String?) ?? '';
      final fp      = (state['filePath'] as String?) ?? '';
      final od      = (state['outputDir'] as String?) ?? '';
      final op      = (state['outputPath'] as String?) ?? '';

      if (running && mounted) {
        setState(() {
          _isProcessing = true;
          _logVisible   = true;
          _logs         = logs;
          if (fp.isNotEmpty) {
            _selectedFilePath = fp;
            _selectedFileName = fp.split('/').last;
          }
        });
        _logCtrl.forward(from: 0);
        if (!_stopwatch.isRunning) _startTimer();
        _startPolling();
      } else if (status == 'success' && mounted) {
        setState(() {
          _isProcessing = false;
          _logVisible   = true;
          _logs         = logs;
          _outputDir    = od.isNotEmpty ? od : null;
          _outputPath   = op.isNotEmpty ? op : null;
          if (fp.isNotEmpty) {
            _selectedFilePath = fp;
            _selectedFileName = fp.split('/').last;
          }
        });
        _logCtrl.forward(from: 0);
        _showSnack('SSL pinning removed successfully',
            icon: Icons.lock_open_rounded, color: const Color(0xFF22c55e));
      } else if (status == 'cancelled' && mounted) {
        setState(() {
          _isProcessing = false;
          _logVisible   = logs.isNotEmpty;
          _logs         = logs;
        });
        if (logs.isNotEmpty) _logCtrl.forward(from: 0);
      } else if (status == 'error' && mounted) {
        setState(() {
          _isProcessing = false;
          _logVisible   = logs.isNotEmpty;
          _logs         = logs;
        });
        if (logs.isNotEmpty) _logCtrl.forward(from: 0);
      }
    } catch (_) {}
  }

  void _startPolling() {
    _pollTimer?.cancel();
    _streamSub?.cancel();

    _streamSub = HbcChannel.logStream.listen((line) {
      if (!mounted) return;
      if (line == '__TAURUS_DONE__') {
        _pollTimer?.cancel();
        _checkState();
        return;
      }
      setState(() {
        _logs += (_logs.isEmpty ? '' : '\n') + line;
      });
      if (_autoScroll) _scrollLogToBottom();
    }, onDone: () {}, onError: (_) {});

    _pollTimer = Timer.periodic(const Duration(seconds: 20), (_) async {
      if (!mounted) { _pollTimer?.cancel(); return; }
      try {
        final state   = await HbcChannel.sslUnpinState();
        final running = state['running'] == true;
        final logs    = (state['logs'] as String?) ?? '';
        final status  = (state['status'] as String?) ?? '';
        final od      = (state['outputDir'] as String?) ?? '';
        final op      = (state['outputPath'] as String?) ?? '';

        if (logs != _logs && mounted) {
          setState(() { _logs = logs; });
          if (_autoScroll) _scrollLogToBottom();
        }

        if (!running) {
          _pollTimer?.cancel();
          _streamSub?.cancel();
          final success   = status == 'success';
          final cancelled = status == 'cancelled';
          final totalTime = _stopTimer();

          if (mounted) {
            setState(() {
              _isProcessing = false;
              _logs         = logs;
              _outputDir    = od.isNotEmpty ? od : null;
              _outputPath   = op.isNotEmpty ? op : null;
              if (cancelled) {
                _logs += '\nCancelled by user.\n';
              } else {
                _logs += '\n${success ? "Completed" : "Failed"} in $totalTime\n';
              }
            });
            if (cancelled) {
              _showSnack('SSL unpin cancelled',
                  icon: Icons.cancel_outlined, color: const Color(0xFFf59e0b));
            } else {
              _showSnack(
                success ? 'SSL pinning removed — $totalTime'
                        : 'SSL unpin failed',
                icon: success ? Icons.lock_open_rounded : Icons.error_rounded,
                color: success ? const Color(0xFF22c55e) : const Color(0xFFef4444),
              );
            }
          }
        }
      } catch (_) {}
    });
  }

  void _scrollLogToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_logScrollCtrl.hasClients) {
        _logScrollCtrl.animateTo(
          _logScrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _streamSub?.cancel();
    _tickTimer?.cancel();
    _pulseCtrl.dispose();
    _orbitCtrl.dispose();
    _scanCtrl.dispose();
    _logCtrl.dispose();
    _shieldCtrl.dispose();
    _logScrollCtrl.dispose();
    _pageScrollCtrl.dispose();
    super.dispose();
  }

  String _formatDuration(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  void _startTimer() {
    _stopwatch.reset();
    _stopwatch.start();
    _tickTimer?.cancel();
    _tickTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _elapsed = _formatDuration(_stopwatch.elapsed));
    });
  }

  String _stopTimer() {
    _stopwatch.stop();
    _tickTimer?.cancel();
    _tickTimer = null;
    final t = _formatDuration(_stopwatch.elapsed);
    setState(() => _elapsed = t);
    return t;
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['apk', 'apks', 'xapk', 'apkm'],
    );
    if (result == null || result.files.isEmpty) return;

    final file = result.files.single;
    if (file.path == null) return;

    final sizeMb = File(file.path!).lengthSync() / 1048576.0;
    if (sizeMb > 500) {
      _showSnack('File too large — 500 MB limit',
          icon: Icons.warning_rounded, color: const Color(0xFFf59e0b));
      return;
    }

    setState(() {
      _selectedFilePath = file.path;
      _selectedFileName = file.name;
      _logs         = '';
      _logVisible   = false;
      _outputDir    = null;
      _outputPath   = null;
      _isProcessing = false;
      _stopwatch.reset();
      _tickTimer?.cancel();
      _elapsed = '00:00';
    });
  }

  Future<void> _runUnpin() async {
    if (_selectedFilePath == null) return;

    final hasAccess = await StorageHelper.hasFullStorageAccess();
    if (!hasAccess) {
      await StorageHelper.requestFullStorageAccess();
      final hasNow = await StorageHelper.hasFullStorageAccess();
      if (!hasNow) {
        _showSnack('Storage permission required',
            icon: Icons.error_rounded, color: const Color(0xFFef4444));
        return;
      }
    }

    final outputDir = await StorageHelper.buildOutputDir(prefix: 'SslUnpin');

    await HbcChannel.sslUnpinClearState();

    setState(() {
      _isProcessing = true;
      _logVisible   = true;
      _logs         = '';
      _outputDir    = null;
      _outputPath   = null;
      _elapsed      = '00:00';
    });
    _logCtrl.forward(from: 0);
    _startTimer();

    try {
      final res = await HbcChannel.sslUnpinAnalyze(
        filePath:  _selectedFilePath!,
        fileName:  _selectedFileName!,
        outputDir: outputDir,
        signApk:   false,
      );

      if (res['started'] == true) {
        _showSnack('SSL Unpinner started',
            icon: Icons.lock_open_rounded, color: _accent);
        _startPolling();
      } else {
        final err = (res['error'] as String?) ?? 'Failed to start service';
        setState(() { _isProcessing = false; });
        _stopTimer();
        _showSnack(err, icon: Icons.error_rounded, color: const Color(0xFFef4444));
      }
    } catch (e) {
      setState(() { _isProcessing = false; });
      _stopTimer();
      _showSnack('Error: $e', icon: Icons.error_rounded, color: const Color(0xFFef4444));
    }
  }

  Future<void> _cancelUnpin() async {
    _pollTimer?.cancel();
    _streamSub?.cancel();
    _tickTimer?.cancel();
    // Update UI immediately — don't wait for native to finish.
    if (mounted) setState(() { _isProcessing = false; });
    HbcChannel.sslUnpinCancel(); // fire-and-forget
    _showSnack('Operation cancelled',
        icon: Icons.cancel_outlined, color: const Color(0xFFf59e0b));
  }

  Future<void> _clearAndReset() async {
    await HbcChannel.sslUnpinClearState();
    if (!mounted) return;
    setState(() {
      _selectedFilePath = null;
      _selectedFileName = null;
      _logs         = '';
      _logVisible   = false;
      _outputDir    = null;
      _outputPath   = null;
      _isProcessing = false;
      _stopwatch.reset();
      _elapsed = '00:00';
    });
  }

  /// Instantly cancels any running operation and wipes all state.
  Future<void> _resetAll() async {
    _pollTimer?.cancel();
    _streamSub?.cancel();
    _tickTimer?.cancel();
    _stopwatch.reset();
    // Snap UI to blank state immediately.
    if (mounted) {
      setState(() {
        _isProcessing     = false;
        _selectedFilePath = null;
        _selectedFileName = null;
        _logs             = '';
        _logVisible       = false;
        _outputDir        = null;
        _outputPath       = null;
        _elapsed          = '00:00';
      });
    }
    // Fire native cancel + clear in background — UI already reset.
    HbcChannel.sslUnpinCancel();
    HbcChannel.sslUnpinClearState();
    _showSnack('Reset', icon: Icons.refresh_rounded, color: _kSslAccent);
  }

  void _showSnack(String msg, {IconData icon = Icons.info_rounded, Color color = _kSslAccent}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(icon, color: Colors.white, size: 18),
        const SizedBox(width: 10),
        Expanded(child: Text(msg, style: const TextStyle(color: Colors.white, fontSize: 13))),
      ]),
      backgroundColor: color.withOpacity(0.9),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      margin: const EdgeInsets.all(12),
      duration: const Duration(seconds: 3),
    ));
  }

  // ── Build ─────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final t = ThemeProvider().current;
    return Scaffold(
      appBar: AppBar(
        title: const Text('SSL Unpinner'),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [t.appBarBg, const Color(0xFF001a20)],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: _kSslAccent),
            tooltip: 'Reset',
            onPressed: _resetAll,
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: _accent.withOpacity(0.25)),
        ),
      ),
      body: SingleChildScrollView(
        controller: _pageScrollCtrl,
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _buildHeader(),
            const SizedBox(height: 20),
            _buildFileSelector(),
            const SizedBox(height: 14),
            _buildActionRow(),
            if (_logVisible) ...[
              const SizedBox(height: 16),
              _buildLogPanel(),
            ],
            if (_outputDir != null && !_isProcessing) ...[
              const SizedBox(height: 14),
              _buildOutputSection(),
            ],
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  // ── Header with animations ────────────────────────────────────────────────

  Widget _buildHeader() {
    return AnimatedBuilder(
      animation: Listenable.merge([_pulseAnim, _orbitCtrl, _scanAnim, _shieldAnim]),
      builder: (_, __) {
        final pulse  = _pulseAnim.value;
        final orbit  = _orbitCtrl.value;
        final scan   = _scanAnim.value;
        final shield = _shieldAnim.value;
        return Container(
          padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: RadialGradient(
              center: Alignment.center,
              radius: 1.2,
              colors: [
                _accent.withOpacity(0.06 + 0.05 * pulse),
                ThemeProvider().current.scaffoldBg,
              ],
            ),
            border: Border.all(color: _accent.withOpacity(0.10 + 0.10 * pulse)),
          ),
          child: Column(children: [
            SizedBox(
              width: 72,
              height: 72,
              child: Stack(alignment: Alignment.center, children: [
                // Outer orbit ring
                Transform.rotate(
                  angle: orbit * math.pi * 2,
                  child: CustomPaint(
                    size: const Size(72, 72),
                    painter: _SslOrbitPainter(color: _accent, opacity: 0.25 + 0.20 * pulse),
                  ),
                ),
                // Inner counter-orbit
                Transform.rotate(
                  angle: -orbit * math.pi * 2 * 0.7,
                  child: CustomPaint(
                    size: const Size(46, 46),
                    painter: _SslDotPainter(color: _accent, opacity: 0.35 + 0.25 * pulse),
                  ),
                ),
                // Scan line effect
                ClipOval(
                  child: SizedBox(
                    width: 44,
                    height: 44,
                    child: CustomPaint(
                      painter: _SslScanPainter(
                        color: _accent,
                        progress: scan,
                        opacity: 0.18 + 0.12 * pulse,
                      ),
                    ),
                  ),
                ),
                // Shield icon with glow
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: _accent.withOpacity(0.3 + 0.2 * shield),
                        blurRadius: 16 + 8 * shield,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: Icon(
                    Icons.lock_open_rounded,
                    color: _accent.withOpacity(0.75 + 0.25 * pulse),
                    size: 22,
                  ),
                ),
              ]),
            ),
            const SizedBox(height: 16),
            Text(
              'SSL Unpinner',
              style: TextStyle(
                color: Colors.white.withOpacity(0.92),
                fontSize: 18,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.2,
              ),
            ),
            const SizedBox(height: 6),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _HeaderChip('DEX Patch'),
                const SizedBox(width: 8),
                _HeaderChip('NSC Inject'),
                const SizedBox(width: 8),
                _HeaderChip('SSL Patcher'),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              'Eliminates SSL certificate trust restrictions from any APK.\nNo root. No limits. No trace.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: const Color(0xFF9ca3af).withOpacity(0.75),
                fontSize: 11,
                height: 1.5,
              ),
            ),
          ]),
        );
      },
    );
  }

  // ── File selector ─────────────────────────────────────────────────────────

  Widget _buildFileSelector() {
    final hasFile = _selectedFileName != null;
    return GestureDetector(
      onTap: _isProcessing ? null : _pickFile,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: const Color(0xFF0a1a1f),
          border: Border.all(
            color: hasFile
                ? _accent.withOpacity(0.35)
                : ThemeProvider().current.surfaceColor,
          ),
        ),
        child: Row(children: [
          Icon(
            hasFile ? Icons.android_rounded : Icons.upload_file_rounded,
            color: hasFile ? _accent : const Color(0xFF4b5563),
            size: 28,
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  hasFile ? _selectedFileName! : 'Select APK / bundle',
                  style: TextStyle(
                    color: hasFile ? Colors.white : const Color(0xFF6b7280),
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
                if (hasFile && _selectedFilePath != null)
                  Text(
                    _selectedFilePath!,
                    style: const TextStyle(color: Color(0xFF4b5563), fontSize: 10),
                    overflow: TextOverflow.ellipsis,
                  ),
                if (!hasFile)
                  const Text(
                    'Supports .apk  .apks  .xapk  .apkm',
                    style: TextStyle(color: Color(0xFF4b5563), fontSize: 10),
                  ),
              ],
            ),
          ),
          if (hasFile)
            GestureDetector(
              onTap: _isProcessing ? null : () {
                setState(() {
                  _selectedFilePath = null;
                  _selectedFileName = null;
                  _logs       = '';
                  _logVisible = false;
                  _outputDir  = null;
                  _outputPath = null;
                });
              },
              child: Icon(Icons.close_rounded,
                  color: const Color(0xFF6b7280).withOpacity(0.6), size: 20),
            ),
        ]),
      ),
    );
  }

  // ── Action row ────────────────────────────────────────────────────────────

  Widget _buildActionRow() {
    final hasFile = _selectedFileName != null;
    final canRun  = hasFile && !_isProcessing;
    return Row(children: [
      Expanded(
        child: GestureDetector(
          onTap: canRun ? _runUnpin : (_isProcessing ? _cancelUnpin : null),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              gradient: canRun
                  ? const LinearGradient(colors: [_kSslAccent, _kSslAccentDark])
                  : null,
              color: (!canRun && !_isProcessing) ? const Color(0xFF0a1a1f) : null,
              border: Border.all(
                color: _isProcessing
                    ? _accent.withOpacity(0.4)
                    : (!hasFile ? const Color(0xFF1a2a30) : Colors.transparent),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (_isProcessing) ...[
                  SizedBox(
                    width: 16, height: 16,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: _accent,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    'Unpinning — $_elapsed',
                    style: TextStyle(
                      color: _accent,
                      fontWeight: FontWeight.w700,
                      fontSize: 14,
                    ),
                  ),
                ] else ...[
                  Icon(
                    hasFile ? Icons.lock_open_rounded : Icons.upload_file_rounded,
                    color: hasFile ? Colors.white : const Color(0xFF4b5563),
                    size: 18,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    hasFile ? 'Remove SSL Pinning' : 'Select a file first',
                    style: TextStyle(
                      color: hasFile ? Colors.white : const Color(0xFF4b5563),
                      fontWeight: FontWeight.w700,
                      fontSize: 14,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
      if (_isProcessing) ...[
        const SizedBox(width: 10),
        GestureDetector(
          onTap: _cancelUnpin,
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: const Color(0xFF7f1d1d).withOpacity(0.25),
              border: Border.all(color: const Color(0xFFef4444).withOpacity(0.3)),
            ),
            child: const Icon(Icons.stop_rounded, color: Color(0xFFef4444), size: 20),
          ),
        ),
      ],
    ]);
  }

  // ── Log panel ─────────────────────────────────────────────────────────────

  Widget _buildLogPanel() {
    return FadeTransition(
      opacity: _logFade,
      child: Container(
        key: _logPanelKey,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: const Color(0xFF010a0d),
          border: Border.all(color: _accent.withOpacity(0.15)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Log header
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              child: Row(children: [
                AnimatedBuilder(
                  animation: _pulseAnim,
                  builder: (_, __) => Container(
                    width: 8, height: 8,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _isProcessing
                          ? _accent.withOpacity(0.5 + 0.5 * _pulseAnim.value)
                          : (_logs.contains('Completed') ? const Color(0xFF22c55e) : const Color(0xFF6b7280)),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  _isProcessing ? 'Processing...' : 'Output Log',
                  style: TextStyle(
                    color: _accent.withOpacity(0.85),
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.8,
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: () => setState(() => _autoScroll = !_autoScroll),
                  child: Icon(
                    _autoScroll ? Icons.vertical_align_bottom_rounded : Icons.pause_rounded,
                    size: 16,
                    color: _autoScroll ? _accent : const Color(0xFF6b7280),
                  ),
                ),
                const SizedBox(width: 12),
                GestureDetector(
                  onTap: () {
                    Clipboard.setData(ClipboardData(text: _logs));
                    _showSnack('Log copied', icon: Icons.copy_rounded);
                  },
                  child: Icon(Icons.copy_rounded, size: 16, color: const Color(0xFF4b5563)),
                ),
              ]),
            ),
            Container(height: 1, color: _accent.withOpacity(0.08)),
            // Log content
            SizedBox(
              height: 260,
              child: SingleChildScrollView(
                controller: _logScrollCtrl,
                padding: const EdgeInsets.all(12),
                child: Text(
                  _logs.isEmpty ? '...' : _logs,
                  style: TextStyle(
                    color: _logs.isEmpty
                        ? const Color(0xFF374151)
                        : const Color(0xFFd1fae5),
                    fontSize: 11.5,
                    fontFamily: 'monospace',
                    height: 1.6,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Output section ────────────────────────────────────────────────────────

  Widget _buildOutputSection() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: const Color(0xFF022c22),
        border: Border.all(color: const Color(0xFF22c55e).withOpacity(0.25)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            const Icon(Icons.check_circle_rounded,
                color: Color(0xFF22c55e), size: 18),
            const SizedBox(width: 8),
            const Text('Output Ready',
                style: TextStyle(
                  color: Color(0xFF22c55e),
                  fontWeight: FontWeight.w700,
                  fontSize: 13,
                )),
            const Spacer(),
            GestureDetector(
              onTap: _clearAndReset,
              child: Icon(Icons.refresh_rounded,
                  size: 18, color: Colors.white.withOpacity(0.4)),
            ),
          ]),
          const SizedBox(height: 8),
          Row(children: [
            const Icon(Icons.folder_rounded, color: Color(0xFF22c55e), size: 14),
            const SizedBox(width: 6),
            const Text('Saved to:',
                style: TextStyle(
                    color: Color(0xFF22c55e), fontSize: 10, fontWeight: FontWeight.w600)),
          ]),
          const SizedBox(height: 4),
          Text(
            _outputPath ?? _outputDir ?? '',
            style: const TextStyle(
              color: Color(0xFF86efac),
              fontSize: 10,
              fontFamily: 'monospace',
            ),
            overflow: TextOverflow.ellipsis,
            maxLines: 2,
          ),
          const SizedBox(height: 10),
          Text(
            'APK is unsigned — sign manually before installing.',
            style: TextStyle(
              color: const Color(0xFF4ade80).withOpacity(0.7),
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }
}

// ── Chip widget ───────────────────────────────────────────────────────────────

class _HeaderChip extends StatelessWidget {
  final String label;
  const _HeaderChip(this.label);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: _kSslAccent.withOpacity(0.10),
        border: Border.all(color: _kSslAccent.withOpacity(0.25)),
      ),
      child: Text(label,
          style: TextStyle(
            color: _kSslAccentLight.withOpacity(0.85),
            fontSize: 10,
            fontWeight: FontWeight.w600,
          )),
    );
  }
}

// ── Custom painters ────────────────────────────────────────────────────────────

class _SslOrbitPainter extends CustomPainter {
  final Color color;
  final double opacity;
  _SslOrbitPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final r = size.width / 2;
    final paint = Paint()
      ..color = color.withOpacity(opacity)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    // Elliptical orbit
    canvas.drawOval(
      Rect.fromCenter(center: center, width: r * 2, height: r * 1.2),
      paint,
    );
    // Dot on orbit
    final dotPaint = Paint()
      ..color = color.withOpacity(opacity + 0.2)
      ..style = PaintingStyle.fill;
    canvas.drawCircle(Offset(center.dx + r, center.dy), 3, dotPaint);
  }

  @override
  bool shouldRepaint(_SslOrbitPainter old) =>
      old.opacity != opacity;
}

class _SslDotPainter extends CustomPainter {
  final Color color;
  final double opacity;
  _SslDotPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final paint = Paint()
      ..color = color.withOpacity(opacity)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0
      ..strokeCap = StrokeCap.round;

    // Dashed arc
    const dashes = 8;
    for (int i = 0; i < dashes; i++) {
      final startAngle = (i / dashes) * math.pi * 2;
      final sweepAngle = (1 / dashes) * math.pi * 2 * 0.6;
      canvas.drawArc(
        Rect.fromCenter(center: center, width: size.width, height: size.height),
        startAngle,
        sweepAngle,
        false,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(_SslDotPainter old) => old.opacity != opacity;
}

class _SslScanPainter extends CustomPainter {
  final Color color;
  final double progress;
  final double opacity;
  _SslScanPainter({required this.color, required this.progress, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final h = size.height;
    final scanY = progress * h;
    final gradient = LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [
        color.withOpacity(0),
        color.withOpacity(opacity),
        color.withOpacity(0),
      ],
      stops: const [0, 0.5, 1],
    );
    final rect = Rect.fromLTWH(0, scanY - 12, size.width, 24);
    final paint = Paint()
      ..shader = gradient.createShader(rect);
    canvas.drawRect(rect, paint);
  }

  @override
  bool shouldRepaint(_SslScanPainter old) => old.progress != progress;
}
