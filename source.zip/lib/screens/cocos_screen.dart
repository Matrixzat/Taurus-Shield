import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import '../utils/permission_helper.dart';
import '../widgets/guide_modal.dart';

const _kAccent     = Color(0xFFF97316);
const _kAccentDark = Color(0xFF431407);
const _kAccentSoft = Color(0xFFFB923C);
const _kSurface    = Color(0xFF0A0802);
const _kSurface2   = Color(0xFF120E06);
const _kBorder     = Color(0xFF7C3A0E);

const _kCocosChannel = MethodChannel('com.taurus.shield/cocos');

// ── Data models ───────────────────────────────────────────────────────────────

class CocosSymbol {
  final String name;
  final String offset;
  final String type;
  final int    score;
  bool   selected  = false;
  String patchType = 'bool';
  String patchValue = '1';

  CocosSymbol({
    required this.name,
    required this.offset,
    required this.type,
    required this.score,
  });
}

class CocosScriptValue {
  final String file;
  final String varName;
  final String currentValue;
  final int    line;
  final int    score;
  final String findStr;
  final bool   isBool;
  bool   selected = false;
  String newValue = '';

  CocosScriptValue({
    required this.file,
    required this.varName,
    required this.currentValue,
    required this.line,
    required this.score,
    required this.findStr,
    required this.isBool,
  });
}

// ── Screen ────────────────────────────────────────────────────────────────────

class CocosScreen extends StatefulWidget {
  const CocosScreen({super.key});
  @override
  State<CocosScreen> createState() => _CocosScreenState();
}

class _CocosScreenState extends State<CocosScreen>
    with TickerProviderStateMixin {

  int     _step = 0;
  String? _apkPath;
  String? _apkName;
  String? _analysisJsonPath;
  String  _gameType = '';

  List<CocosSymbol>      _symbols      = [];
  List<CocosSymbol>      _filtSymbols  = [];
  List<CocosScriptValue> _values       = [];
  List<CocosScriptValue> _filtValues   = [];

  String _filterQuery  = '';
  bool   _onlyScored   = true;

  bool   _isProcessing = false;
  String _logs         = '';
  String _phase        = '';
  int    _progress     = -1;
  String _resultPath   = '';

  Timer? _pollTimer;
  Timer? _filterDebounce;
  late final AnimationController _pulseCtrl;
  late final Animation<double>   _pulseAnim;
  final ScrollController _logCtrl = ScrollController();

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
    _restoreState();
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _pollTimer?.cancel();
    _filterDebounce?.cancel();
    _logCtrl.dispose();
    super.dispose();
  }

  // ── Restore state ──────────────────────────────────────────────────────────
  Future<void> _restoreState() async {
    try {
      final r = await _kCocosChannel.invokeMethod<Map>('getState');
      if (r == null) return;
      final running = r['running'] as bool? ?? false;
      final status  = r['result_status'] as String? ?? '';
      final path    = r['result'] as String? ?? '';
      final logs    = r['logs'] as String? ?? '';
      final gt      = r['game_type'] as String? ?? '';

      if (running) {
        setState(() { _isProcessing = true; _phase = r['phase'] as String? ?? ''; _logs = logs; });
        _startPolling();
        return;
      }
      if (status == 'success' && path.isNotEmpty && File(path).existsSync()) {
        setState(() { _logs = logs; _resultPath = path; _gameType = gt; });
        if (path.endsWith('.json')) await _loadAnalysis(path);
        else if (path.endsWith('.so') || path.endsWith('.apk')) setState(() { _step = 4; });
      }
    } catch (_) {}
  }

  // ── Pick APK ───────────────────────────────────────────────────────────────
  Future<void> _pickApk() async {
    final ok = await PermissionHelper.ensureStorage(context, accent: _kAccent);
    if (!ok) return;
    final r = await FilePicker.platform.pickFiles(
      type: FileType.custom, allowedExtensions: ['apk']);
    if (r == null || r.files.isEmpty) return;
    setState(() {
      _apkPath = r.files.first.path!;
      _apkName = r.files.first.name.replaceAll('.apk', '').replaceAll(' ', '_');
    });
  }

  // ── Start analysis ─────────────────────────────────────────────────────────
  Future<void> _startAnalysis() async {
    if (_apkPath == null) return;
    setState(() { _step = 1; _isProcessing = true; _logs = ''; _phase = 'analysing'; });
    try {
      await _kCocosChannel.invokeMethod('startAnalyse', {
        'apk_path': _apkPath, 'game_name': _apkName ?? 'game',
      });
      _startPolling();
    } catch (e) {
      setState(() { _step = 0; _isProcessing = false; });
    }
  }

  // ── Load analysis JSON ─────────────────────────────────────────────────────
  Future<void> _loadAnalysis(String path) async {
    try {
      final raw  = File(path).readAsStringSync();
      final json = jsonDecode(raw) as Map<String, dynamic>;
      _analysisJsonPath = path;
      _gameType = json['game_type'] as String? ?? 'native';

      if (_gameType == 'native') {
        final syms = (json['interesting'] as List? ?? []).cast<Map<String, dynamic>>();
        _symbols = syms.map((m) => CocosSymbol(
          name:   m['name']   as String? ?? '',
          offset: m['offset'] as String? ?? '0x0',
          type:   m['type']   as String? ?? 'FUNC',
          score:  (m['score'] as num?)?.toInt() ?? 0,
        )).toList();
        _applySymbolFilter();
      } else {
        final items = (json['interesting'] as List? ?? []).cast<Map<String, dynamic>>();
        _values = items.map((m) => CocosScriptValue(
          file:         m['file']    as String? ?? '',
          varName:      m['var']     as String? ?? '',
          currentValue: m['value']   as String? ?? '',
          line:         (m['line']   as num?)?.toInt() ?? 0,
          score:        (m['score']  as num?)?.toInt() ?? 0,
          findStr:      m['find_str'] as String? ?? '',
          isBool:       m['is_bool'] as bool? ?? false,
        )).toList();
        _values.sort((a, b) => b.score.compareTo(a.score));
        _applyValueFilter();
      }
      setState(() { _step = 2; });
    } catch (e) {
      setState(() { _logs = '$_logs\nError loading analysis: $e'; });
    }
  }

  // ── Filters ────────────────────────────────────────────────────────────────
  void _applySymbolFilter() {
    final q = _filterQuery.toLowerCase();
    setState(() {
      _filtSymbols = _symbols.where((s) {
        if (_onlyScored && s.score == 0) return false;
        if (q.isEmpty) return true;
        return s.name.toLowerCase().contains(q) || s.offset.contains(q) || s.type.toLowerCase().contains(q);
      }).toList();
    });
  }

  void _applyValueFilter() {
    final q = _filterQuery.toLowerCase();
    setState(() {
      _filtValues = _values.where((v) {
        if (_onlyScored && v.score == 0) return false;
        if (q.isEmpty) return true;
        return v.varName.toLowerCase().contains(q) || v.file.toLowerCase().contains(q) || v.currentValue.contains(q);
      }).toList();
    });
  }

  void _onFilterChanged(String q) {
    _filterQuery = q.toLowerCase().trim();
    _filterDebounce?.cancel();
    _filterDebounce = Timer(const Duration(milliseconds: 220), () {
      if (_gameType == 'native') _applySymbolFilter(); else _applyValueFilter();
    });
  }

  // ── Patch native ───────────────────────────────────────────────────────────
  Future<void> _startPatchNative() async {
    if (_apkPath == null) return;
    final selected = _symbols.where((s) => s.selected).toList();
    if (selected.isEmpty) return;

    final features = jsonEncode(selected.map((s) => {
      'name':        s.name,
      'file_offset': s.offset,
      'type':        s.patchType,
      'value':       s.patchValue,
    }).toList());

    setState(() { _step = 3; _isProcessing = true; _logs = ''; _phase = 'patching'; });
    try {
      await _kCocosChannel.invokeMethod('startPatchNative', {
        'apk_path':      _apkPath,
        'game_name':     _apkName ?? 'game',
        'features_json': features,
      });
      _startPolling();
    } catch (e) {
      setState(() { _step = 2; _isProcessing = false; });
    }
  }

  // ── Patch scripts ──────────────────────────────────────────────────────────
  Future<void> _startPatchScripts() async {
    if (_apkPath == null) return;
    final selected = _values.where((v) => v.selected && v.newValue.isNotEmpty).toList();
    if (selected.isEmpty) return;

    final patches = jsonEncode(selected.map((v) => {
      'file':    v.file,
      'find':    v.findStr,
      'replace': v.findStr.replaceFirst(v.currentValue, v.newValue),
    }).toList());

    setState(() { _step = 3; _isProcessing = true; _logs = ''; _phase = 'patching'; });
    try {
      await _kCocosChannel.invokeMethod('startPatchScript', {
        'apk_path':     _apkPath,
        'game_name':    _apkName ?? 'game',
        'patches_json': patches,
      });
      _startPolling();
    } catch (e) {
      setState(() { _step = 2; _isProcessing = false; });
    }
  }

  // ── Polling ────────────────────────────────────────────────────────────────
  void _startPolling() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 2), (_) async {
      try {
        final r = await _kCocosChannel.invokeMethod<Map>('getState');
        if (r == null) return;
        final running = r['running'] as bool? ?? false;
        final logs    = r['logs']   as String? ?? '';
        final phase   = r['phase']  as String? ?? '';
        final prog    = r['progress'] as int? ?? -1;
        final status  = r['result_status'] as String? ?? '';
        final path    = r['result'] as String? ?? '';
        final gt      = r['game_type'] as String? ?? '';

        setState(() { _logs = logs; _phase = phase; _progress = prog; });
        _scrollLogsToBottom();

        if (!running) {
          _pollTimer?.cancel();
          setState(() { _isProcessing = false; });
          if (status == 'success') {
            setState(() { _resultPath = path; _gameType = gt; });
            if (path.endsWith('.json')) await _loadAnalysis(path);
            else setState(() { _step = 4; });
          } else if (status.startsWith('error:')) {
            setState(() { _step = _step > 1 ? 2 : 0; });
          }
        }
      } catch (_) {}
    });
  }

  void _scrollLogsToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_logCtrl.hasClients) _logCtrl.jumpTo(_logCtrl.position.maxScrollExtent);
    });
  }

  // ── Build ──────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: _kSurface,
    appBar: AppBar(
      backgroundColor: _kSurface,
      elevation: 0,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _kAccentSoft, size: 20),
        onPressed: () => Navigator.pop(context),
      ),
      title: Row(children: [
        Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: _kAccent.withOpacity(0.15),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: _kAccent.withOpacity(0.4)),
          ),
          child: const Icon(Icons.gamepad_rounded, color: _kAccent, size: 18),
        ),
        const SizedBox(width: 10),
        const Text('Cocos2d-x Analyser',
          style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
      ]),
      actions: [
        IconButton(
          icon: const Icon(Icons.help_outline_rounded, color: _kAccentSoft, size: 22),
          onPressed: () => showGuideModal(context, initialIndex: 10, singleTool: true),
        ),
        if (_isProcessing)
          IconButton(
            icon: const Icon(Icons.stop_circle_rounded, color: Color(0xFFf87171), size: 22),
            onPressed: () => _kCocosChannel.invokeMethod('cancelCocos'),
          ),
      ],
    ),
    body: _buildBody(),
  );

  Widget _buildBody() {
    switch (_step) {
      case 0: return _buildPickStep();
      case 1: return _buildProcessingStep('Analysing Game…', 'Detecting type · Extracting symbols · Scanning scripts');
      case 2: return _buildResultsStep();
      case 3: return _buildProcessingStep('Patching…', 'Writing patches on-device');
      case 4: return _buildDoneStep();
      default: return _buildPickStep();
    }
  }

  // ── Step 0 — Pick APK ─────────────────────────────────────────────────────
  Widget _buildPickStep() => SingleChildScrollView(
    padding: const EdgeInsets.all(20),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // Banner
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: _kAccent.withOpacity(0.07),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _kAccent.withOpacity(0.25)),
        ),
        child: Row(children: [
          const Icon(Icons.memory_rounded, color: _kAccent, size: 18),
          const SizedBox(width: 10),
          const Expanded(child: Text(
            'Fully on-device — no cloud, no internet needed.\n'
            'Auto-detects Lua · JS · Native C++ game types.',
            style: TextStyle(color: Color(0xFFd1d5db), fontSize: 11.5, height: 1.5),
          )),
        ]),
      ),
      const SizedBox(height: 24),

      // APK picker
      GestureDetector(
        onTap: _pickApk,
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: _kSurface2,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _apkPath != null
              ? _kAccent.withOpacity(0.5) : Colors.white12),
          ),
          child: Row(children: [
            Container(
              padding: const EdgeInsets.all(11),
              decoration: BoxDecoration(
                color: _kAccent.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _kAccent.withOpacity(0.3)),
              ),
              child: Icon(
                _apkPath != null ? Icons.check_circle_rounded : Icons.android_rounded,
                color: _kAccent, size: 24),
            ),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(
                _apkPath != null ? 'APK selected' : 'Pick Game APK',
                style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
              const SizedBox(height: 3),
              Text(
                _apkPath != null
                  ? (_apkName ?? 'game')
                  : 'Any Cocos2d-x game — Lua, JS, or native C++',
                style: const TextStyle(color: Colors.white54, fontSize: 11.5),
                overflow: TextOverflow.ellipsis),
            ])),
            if (_apkPath != null)
              const Icon(Icons.edit_rounded, color: Colors.white38, size: 18),
          ]),
        ),
      ),
      const SizedBox(height: 20),

      // How it works
      _howItWorksCard(),
      const SizedBox(height: 24),

      // Analyse button
      SizedBox(
        width: double.infinity,
        child: ElevatedButton.icon(
          onPressed: _apkPath != null ? _startAnalysis : null,
          style: ElevatedButton.styleFrom(
            backgroundColor: _kAccent,
            foregroundColor: Colors.black,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          icon: const Icon(Icons.analytics_rounded),
          label: const Text('Analyse Game',
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
        ),
      ),
    ]),
  );

  Widget _howItWorksCard() {
    final steps = [
      ('1', 'Pick the game APK',                           Icons.android_rounded),
      ('2', 'Auto-detect: Lua / JS / Native C++',          Icons.search_rounded),
      ('3', 'Lua/JS: extract XXTEA key → decrypt scripts', Icons.lock_open_rounded),
      ('4', 'Native: parse ELF symbols + string scan',     Icons.memory_rounded),
      ('5', 'Browse & select values to patch',             Icons.tune_rounded),
      ('6', 'Lua/JS: re-encrypt + repack APK on-device',   Icons.folder_zip_outlined),
      ('7', 'Native: write ARM64 bytes into libcocos2dcpp.so', Icons.code_rounded),
    ];
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF0D0A04),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white12),
      ),
      child: Column(
        children: steps.asMap().entries.map((e) {
          final i = e.key; final step = e.value;
          return Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              border: i < steps.length - 1
                ? const Border(bottom: BorderSide(color: Colors.white10)) : null),
            child: Row(children: [
              Container(width: 26, height: 26,
                decoration: BoxDecoration(shape: BoxShape.circle, color: _kAccentDark),
                child: Center(child: Text(step.$1,
                  style: const TextStyle(color: _kAccent, fontSize: 11, fontWeight: FontWeight.bold)))),
              const SizedBox(width: 12),
              Icon(step.$3, color: _kAccentSoft, size: 16),
              const SizedBox(width: 10),
              Expanded(child: Text(step.$2,
                style: const TextStyle(color: Colors.white70, fontSize: 12.5))),
            ]),
          );
        }).toList(),
      ),
    );
  }

  // ── Step 1/3 — Processing ─────────────────────────────────────────────────
  Widget _buildProcessingStep(String title, String sub) => Column(children: [
    Container(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 14),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        AnimatedBuilder(
          animation: _pulseAnim,
          builder: (_, __) => Opacity(
            opacity: _pulseAnim.value,
            child: const Icon(Icons.gamepad_rounded, color: _kAccent, size: 56)),
        ),
        const SizedBox(height: 14),
        Text(title, style: const TextStyle(color: _kAccent, fontSize: 19, fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        Text(sub, textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.white54, fontSize: 11.5)),
        const SizedBox(height: 10),
        if (_phase.isNotEmpty) ...[
          if (_progress >= 0) ...[
            const SizedBox(height: 4),
            SizedBox(width: 200, child: Column(children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text(_phase.toUpperCase(),
                  style: const TextStyle(color: _kAccent, fontSize: 10, letterSpacing: 1.2)),
                Text('$_progress%',
                  style: const TextStyle(color: _kAccentSoft, fontSize: 12,
                    fontWeight: FontWeight.bold, fontFamily: 'monospace')),
              ]),
              const SizedBox(height: 5),
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: _progress / 100.0,
                  backgroundColor: _kAccentDark,
                  valueColor: const AlwaysStoppedAnimation<Color>(_kAccent),
                  minHeight: 5,
                ),
              ),
            ])),
          ] else
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
              decoration: BoxDecoration(
                color: _kAccentDark.withOpacity(0.5),
                borderRadius: BorderRadius.circular(20)),
              child: Text(_phase.toUpperCase(),
                style: const TextStyle(color: _kAccent, fontSize: 10, letterSpacing: 1.2)),
            ),
        ],
      ]),
    ),
    Expanded(
      child: Container(
        width: double.infinity, color: Colors.black,
        child: _logs.isEmpty
          ? const Center(child: Text('Starting…',
              style: TextStyle(color: Colors.white24, fontSize: 12, fontFamily: 'monospace')))
          : SingleChildScrollView(
              controller: _logCtrl,
              padding: const EdgeInsets.all(12),
              child: Text(_logs,
                style: const TextStyle(color: Color(0xFFFF8C42), fontSize: 11,
                  fontFamily: 'monospace', height: 1.4)),
            ),
      ),
    ),
  ]);

  // ── Step 2 — Results ──────────────────────────────────────────────────────
  Widget _buildResultsStep() {
    final isNative = _gameType == 'native';
    final total    = isNative ? _symbols.length : _values.length;
    final selCount = isNative
      ? _symbols.where((s) => s.selected).length
      : _values.where((v) => v.selected && v.newValue.isNotEmpty).length;

    return Column(children: [
      // Header
      Container(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
        color: _kSurface2,
        child: Column(children: [
          Row(children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: _gameTypeBadgeColor().withOpacity(0.15),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _gameTypeBadgeColor().withOpacity(0.5)),
              ),
              child: Text(_gameTypeLabel(),
                style: TextStyle(color: _gameTypeBadgeColor(),
                  fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.1)),
            ),
            const SizedBox(width: 10),
            Text('$total found', style: const TextStyle(color: Colors.white54, fontSize: 12)),
            const Spacer(),
            GestureDetector(
              onTap: () {
                setState(() { _onlyScored = !_onlyScored; });
                if (isNative) _applySymbolFilter(); else _applyValueFilter();
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: _onlyScored ? _kAccent.withOpacity(0.15) : Colors.white10,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: _onlyScored ? _kAccent.withOpacity(0.4) : Colors.white12),
                ),
                child: Text(_onlyScored ? 'Scored only' : 'All',
                  style: TextStyle(color: _onlyScored ? _kAccent : Colors.white38, fontSize: 11)),
              ),
            ),
          ]),
          const SizedBox(height: 10),
          // Search
          TextField(
            onChanged: _onFilterChanged,
            style: const TextStyle(color: Colors.white, fontSize: 13),
            decoration: InputDecoration(
              hintText: isNative ? 'Search symbols…' : 'Search variables…',
              hintStyle: const TextStyle(color: Colors.white38, fontSize: 13),
              prefixIcon: const Icon(Icons.search_rounded, color: Colors.white38, size: 18),
              filled: true,
              fillColor: Colors.white10,
              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide.none),
            ),
          ),
        ]),
      ),

      // List
      Expanded(child: isNative ? _buildSymbolList() : _buildValueList()),

      // Bottom action bar
      Container(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 20),
        color: _kSurface2,
        child: SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: selCount > 0
              ? (isNative ? _startPatchNative : _startPatchScripts)
              : null,
            style: ElevatedButton.styleFrom(
              backgroundColor: _kAccent,
              foregroundColor: Colors.black,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            icon: Icon(isNative ? Icons.memory_rounded : Icons.edit_note_rounded),
            label: Text(
              selCount == 0
                ? (isNative ? 'Select symbols to patch' : 'Select values to patch')
                : isNative
                  ? 'Patch $selCount symbol(s) → libcocos2dcpp.so'
                  : 'Patch $selCount value(s) → Repack APK',
              style: const TextStyle(fontWeight: FontWeight.bold)),
          ),
        ),
      ),
    ]);
  }

  Color  _gameTypeBadgeColor() => _gameType == 'lua'
    ? const Color(0xFF4ADE80) : _gameType == 'js'
    ? const Color(0xFFFBBF24) : _kAccent;

  String _gameTypeLabel() => _gameType == 'lua' ? 'LUA GAME'
    : _gameType == 'js' ? 'JS GAME' : 'NATIVE C++';

  // ── Symbol list (native) ───────────────────────────────────────────────────
  Widget _buildSymbolList() {
    if (_filtSymbols.isEmpty) {
      return const Center(child: Text('No symbols found',
        style: TextStyle(color: Colors.white38, fontSize: 13)));
    }
    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 4),
      itemCount: _filtSymbols.length,
      itemBuilder: (_, i) {
        final s = _filtSymbols[i];
        return _SymbolTile(
          symbol: s,
          accent: _kAccent,
          onChanged: () => setState(() {}),
        );
      },
    );
  }

  // ── Script value list (Lua/JS) ─────────────────────────────────────────────
  Widget _buildValueList() {
    if (_filtValues.isEmpty) {
      return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.info_outline_rounded, color: Colors.white24, size: 32),
        const SizedBox(height: 8),
        Text(
          _gameType == 'native'
            ? 'Native C++ game — no script values found'
            : 'No patchable values found in scripts',
          style: const TextStyle(color: Colors.white38, fontSize: 13)),
      ]));
    }
    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 4),
      itemCount: _filtValues.length,
      itemBuilder: (_, i) {
        final v = _filtValues[i];
        return _ValueTile(
          value: v,
          accent: _kAccent,
          onChanged: () => setState(() {}),
        );
      },
    );
  }

  // ── Step 4 — Done ─────────────────────────────────────────────────────────
  Widget _buildDoneStep() => SingleChildScrollView(
    padding: const EdgeInsets.all(24),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Center(child: Column(children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: const Color(0xFF052E16).withOpacity(0.6),
            shape: BoxShape.circle,
            border: Border.all(color: const Color(0xFF4ADE80), width: 2),
          ),
          child: const Icon(Icons.check_rounded, color: Color(0xFF4ADE80), size: 48),
        ),
        const SizedBox(height: 16),
        const Text('Done!',
          style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Text(_resultPath.endsWith('.apk')
          ? 'Patched APK ready — sign & install'
          : 'Patched .so ready — replace in APK',
          style: const TextStyle(color: Colors.white54, fontSize: 13)),
      ])),
      const SizedBox(height: 28),

      // Output path
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: _kSurface2,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white12),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Output', style: TextStyle(color: Colors.white38, fontSize: 11)),
          const SizedBox(height: 6),
          Text(_resultPath,
            style: const TextStyle(color: Colors.white70, fontSize: 11.5,
              fontFamily: 'monospace', height: 1.4)),
          const SizedBox(height: 8),
          GestureDetector(
            onTap: () {
              Clipboard.setData(ClipboardData(text: _resultPath));
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Path copied'), backgroundColor: Color(0xFF166534)));
            },
            child: const Row(children: [
              Icon(Icons.copy_rounded, color: Color(0xFF4ADE80), size: 14),
              SizedBox(width: 6),
              Text('Copy path', style: TextStyle(color: Color(0xFF4ADE80), fontSize: 12)),
            ]),
          ),
        ]),
      ),
      const SizedBox(height: 16),

      // Next steps
      _nextStepsCard(),
      const SizedBox(height: 20),

      // Start over
      SizedBox(
        width: double.infinity,
        child: OutlinedButton.icon(
          onPressed: () {
            _kCocosChannel.invokeMethod('clearState').catchError((_) {});
            setState(() {
              _step = 0; _logs = ''; _phase = ''; _resultPath = '';
              _symbols = []; _values = []; _gameType = '';
            });
          },
          style: OutlinedButton.styleFrom(
            foregroundColor: _kAccent,
            side: BorderSide(color: _kAccent.withOpacity(0.4)),
            padding: const EdgeInsets.symmetric(vertical: 12),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          icon: const Icon(Icons.refresh_rounded),
          label: const Text('Analyse another game'),
        ),
      ),
    ]),
  );

  Widget _nextStepsCard() {
    final isApk = _resultPath.endsWith('.apk');
    final steps = isApk
      ? [
          (Icons.draw_rounded,      'Sign the patched APK', 'Open in MT Manager → Sign (or use APK Signer)'),
          (Icons.install_mobile_rounded, 'Install', 'Install over the original game — done'),
        ]
      : [
          (Icons.folder_open_rounded, 'Open APK in MT Manager', 'Tap the original game APK'),
          (Icons.swap_horiz_rounded,  'Replace libcocos2dcpp.so', 'Navigate to lib/arm64-v8a → long-press → Replace'),
          (Icons.draw_rounded,        'Sign the APK', 'Tap Sign in MT Manager'),
          (Icons.install_mobile_rounded, 'Install', 'Install over the original game — done'),
        ];

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _kSurface2,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _kAccent.withOpacity(0.2)),
      ),
      child: Column(children: steps.asMap().entries.map((e) {
        final i = e.key; final s = e.value;
        return Padding(
          padding: EdgeInsets.only(bottom: i < steps.length - 1 ? 12 : 0),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(
              width: 28, height: 28,
              decoration: BoxDecoration(
                color: _kAccentDark, borderRadius: BorderRadius.circular(8)),
              child: Icon(s.$1, color: _kAccentSoft, size: 15),
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(s.$2, style: const TextStyle(color: Colors.white, fontSize: 12.5,
                fontWeight: FontWeight.w600)),
              const SizedBox(height: 2),
              Text(s.$3, style: const TextStyle(color: Colors.white54, fontSize: 11.5)),
            ])),
          ]),
        );
      }).toList()),
    );
  }
}

// ── Symbol tile (native) ───────────────────────────────────────────────────────

class _SymbolTile extends StatefulWidget {
  final CocosSymbol symbol;
  final Color       accent;
  final VoidCallback onChanged;
  const _SymbolTile({required this.symbol, required this.accent, required this.onChanged});
  @override
  State<_SymbolTile> createState() => _SymbolTileState();
}

class _SymbolTileState extends State<_SymbolTile> {
  late final TextEditingController _valCtrl;

  @override
  void initState() {
    super.initState();
    _valCtrl = TextEditingController(text: widget.symbol.patchValue);
  }

  @override
  void dispose() { _valCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final s = widget.symbol;
    final typeColors = <String, Color>{
      'FUNC': const Color(0xFF60A5FA), 'OBJECT': const Color(0xFFFBBF24),
      'NOTYPE': Colors.white38, 'STRING': const Color(0xFF4ADE80),
    };
    final tc = typeColors[s.type] ?? Colors.white38;

    return GestureDetector(
      onTap: () { setState(() { s.selected = !s.selected; }); widget.onChanged(); },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: s.selected ? widget.accent.withOpacity(0.08) : const Color(0xFF120E06),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: s.selected
            ? widget.accent.withOpacity(0.4) : Colors.white10),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              width: 20, height: 20,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: s.selected ? widget.accent : Colors.white10,
                border: Border.all(
                  color: s.selected ? widget.accent : Colors.white24)),
              child: s.selected
                ? const Icon(Icons.check_rounded, size: 12, color: Colors.black)
                : null,
            ),
            const SizedBox(width: 10),
            Expanded(child: Text(s.name,
              style: const TextStyle(color: Colors.white, fontSize: 12.5,
                fontWeight: FontWeight.w600),
              overflow: TextOverflow.ellipsis)),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: tc.withOpacity(0.12),
                borderRadius: BorderRadius.circular(4)),
              child: Text(s.type, style: TextStyle(
                color: tc, fontSize: 9.5, fontFamily: 'monospace'))),
          ]),
          Padding(
            padding: const EdgeInsets.only(left: 30, top: 4),
            child: Row(children: [
              Text(s.offset, style: const TextStyle(
                color: Colors.white38, fontSize: 10, fontFamily: 'monospace')),
              if (s.score > 0) ...[
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                  decoration: BoxDecoration(
                    color: widget.accent.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(4)),
                  child: Text('score ${s.score}',
                    style: TextStyle(color: widget.accent, fontSize: 9))),
              ],
            ]),
          ),
          if (s.selected) ...[
            const SizedBox(height: 10),
            const Divider(color: Colors.white10, height: 1),
            const SizedBox(height: 8),
            // Patch type row
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: ['bool','int','float','void','nop','branch_always','branch_never']
                .map((t) => GestureDetector(
                  onTap: () { setState(() { s.patchType = t; }); widget.onChanged(); },
                  child: Container(
                    margin: const EdgeInsets.only(right: 6),
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: s.patchType == t ? widget.accent.withOpacity(0.2) : Colors.white10,
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: s.patchType == t
                        ? widget.accent.withOpacity(0.5) : Colors.white12)),
                    child: Text(t, style: TextStyle(
                      color: s.patchType == t ? widget.accent : Colors.white38,
                      fontSize: 10, fontFamily: 'monospace')),
                  ),
                )).toList(),
              ),
            ),
            if (!['void','branch_always','branch_never','nop'].contains(s.patchType)) ...[
              const SizedBox(height: 8),
              SizedBox(height: 36,
                child: TextField(
                  controller: _valCtrl,
                  onChanged: (v) { s.patchValue = v; widget.onChanged(); },
                  keyboardType: s.patchType == 'float'
                    ? const TextInputType.numberWithOptions(decimal: true)
                    : TextInputType.number,
                  style: const TextStyle(color: Colors.white, fontSize: 12, fontFamily: 'monospace'),
                  decoration: InputDecoration(
                    hintText: s.patchType == 'float' ? '1.0' : '999999',
                    hintStyle: const TextStyle(color: Colors.white24, fontSize: 12),
                    filled: true, fillColor: Colors.white10,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide.none),
                  ),
                )),
            ],
          ],
        ]),
      ),
    );
  }
}

// ── Script value tile (Lua/JS) ─────────────────────────────────────────────────

class _ValueTile extends StatefulWidget {
  final CocosScriptValue value;
  final Color            accent;
  final VoidCallback     onChanged;
  const _ValueTile({required this.value, required this.accent, required this.onChanged});
  @override
  State<_ValueTile> createState() => _ValueTileState();
}

class _ValueTileState extends State<_ValueTile> {
  late final TextEditingController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = TextEditingController(text: widget.value.newValue);
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final v = widget.value;
    return GestureDetector(
      onTap: () { setState(() { v.selected = !v.selected; }); widget.onChanged(); },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: v.selected ? widget.accent.withOpacity(0.08) : const Color(0xFF120E06),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: v.selected
            ? widget.accent.withOpacity(0.4) : Colors.white10),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              width: 20, height: 20,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: v.selected ? widget.accent : Colors.white10,
                border: Border.all(
                  color: v.selected ? widget.accent : Colors.white24)),
              child: v.selected
                ? const Icon(Icons.check_rounded, size: 12, color: Colors.black) : null,
            ),
            const SizedBox(width: 10),
            Expanded(child: Text(v.varName,
              style: const TextStyle(color: Colors.white, fontSize: 12.5,
                fontWeight: FontWeight.w700),
              overflow: TextOverflow.ellipsis)),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: (v.isBool ? const Color(0xFF60A5FA) : const Color(0xFFFBBF24))
                  .withOpacity(0.12),
                borderRadius: BorderRadius.circular(4)),
              child: Text(v.isBool ? 'bool' : 'num',
                style: TextStyle(
                  color: v.isBool ? const Color(0xFF60A5FA) : const Color(0xFFFBBF24),
                  fontSize: 9.5, fontFamily: 'monospace'))),
          ]),
          Padding(
            padding: const EdgeInsets.only(left: 30, top: 4),
            child: Row(children: [
              Text('= ${v.currentValue}',
                style: const TextStyle(color: Colors.white38, fontSize: 11,
                  fontFamily: 'monospace')),
              const SizedBox(width: 6),
              Text('line ${v.line}',
                style: const TextStyle(color: Colors.white24, fontSize: 10)),
              if (v.score > 0) ...[
                const SizedBox(width: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                  decoration: BoxDecoration(
                    color: widget.accent.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(4)),
                  child: Text('score ${v.score}',
                    style: TextStyle(color: widget.accent, fontSize: 9))),
              ],
            ]),
          ),
          if (v.selected) ...[
            const SizedBox(height: 10),
            const Divider(color: Colors.white10, height: 1),
            const SizedBox(height: 8),
            Row(children: [
              const Text('New value →', style: TextStyle(color: Colors.white54, fontSize: 11)),
              const SizedBox(width: 10),
              Expanded(child: SizedBox(height: 34,
                child: TextField(
                  controller: _ctrl,
                  onChanged: (val) { v.newValue = val; widget.onChanged(); },
                  keyboardType: v.isBool
                    ? TextInputType.text
                    : const TextInputType.numberWithOptions(decimal: true),
                  style: const TextStyle(color: Colors.white, fontSize: 12,
                    fontFamily: 'monospace'),
                  decoration: InputDecoration(
                    hintText: v.isBool ? 'true / false' : '999999',
                    hintStyle: const TextStyle(color: Colors.white24, fontSize: 11),
                    filled: true, fillColor: Colors.white10,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide.none),
                  ),
                ))),
            ]),
          ],
        ]),
      ),
    );
  }
}
