import '../utils/theme_provider.dart';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:file_picker/file_picker.dart';
import 'package:http/http.dart' as http;
import 'package:archive/archive.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/storage_helper.dart';
import '../utils/permission_helper.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../utils/cloudflare_api.dart';

// ── Brand colours ─────────────────────────────────────────────────────────────
const _cfOrange     = Color(0xFFF6821F);
const _cfOrangeGlow = Color(0xFFF6821F);
const _workerGreen  = Color(0xFF22c55e);
const _cardBg       = Color(0xFF111127);
const _textDim      = Color(0xFF8892a4);
const _textMid      = Color(0xFFb0bec5);

// ── SharedPrefs keys ──────────────────────────────────────────────────────────
const _kToken     = 'cf_token';
const _kAccountId = 'cf_account_id';
const _kEmail     = 'cf_email';
const _kAcctName  = 'cf_acct_name';

// ═════════════════════════════════════════════════════════════════════════════
class CloudflareScreen extends StatefulWidget {
  const CloudflareScreen({super.key});
  @override
  State<CloudflareScreen> createState() => _CloudflareScreenState();
}

class _CloudflareScreenState extends State<CloudflareScreen>
    with TickerProviderStateMixin {

  String? _token;
  String? _accountId;
  String? _email;
  String? _acctName;
  bool _loading = true;

  int _tabIndex = 0;

  // animations
  late final AnimationController _bgCtrl;
  late final AnimationController _connectCtrl;
  late final Animation<double> _connectScale;
  late final Animation<double> _connectFade;

  @override
  void initState() {
    super.initState();
    _bgCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 6),
    )..repeat(reverse: true);

    _connectCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 800),
    );
    _connectScale = Tween<double>(begin: 0.85, end: 1.0).animate(
      CurvedAnimation(parent: _connectCtrl, curve: Curves.elasticOut),
    );
    _connectFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _connectCtrl, curve: Curves.easeOut),
    );

    _loadSession();
  }

  Future<void> _loadSession() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _token     = prefs.getString(_kToken);
      _accountId = prefs.getString(_kAccountId);
      _email     = prefs.getString(_kEmail);
      _acctName  = prefs.getString(_kAcctName);
      _loading   = false;
    });
    if (_token == null) _connectCtrl.forward();
  }

  Future<void> _disconnect() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_kToken);
    await prefs.remove(_kAccountId);
    await prefs.remove(_kEmail);
    await prefs.remove(_kAcctName);
    if (!mounted) return;
    setState(() {
      _token = _accountId = _email = _acctName = null;
      _tabIndex = 0;
    });
    _connectCtrl.forward(from: 0);
  }

  Future<void> _saveSession(
      String token, String accountId, String email, String name) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kToken, token);
    await prefs.setString(_kAccountId, accountId);
    await prefs.setString(_kEmail, email);
    await prefs.setString(_kAcctName, name);
    if (!mounted) return;
    setState(() {
      _token     = token;
      _accountId = accountId;
      _email     = email;
      _acctName  = name;
    });
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _connectCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Scaffold(
        backgroundColor: ThemeProvider().current.scaffoldBg,
        body: Center(
          child: CircularProgressIndicator(color: _cfOrange),
        ),
      );
    }

    return Scaffold(
      backgroundColor: ThemeProvider().current.scaffoldBg,
      body: _token == null
          ? _ConnectView(
              bgCtrl: _bgCtrl,
              scaleAnim: _connectScale,
              fadeAnim: _connectFade,
              onConnected: _saveSession,
            )
          : _DashboardView(
              bgCtrl: _bgCtrl,
              token: _token!,
              accountId: _accountId!,
              email: _email ?? '',
              acctName: _acctName ?? '',
              tabIndex: _tabIndex,
              onTabChange: (i) => setState(() => _tabIndex = i),
              onDisconnect: _disconnect,
            ),
    );
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// CONNECT VIEW
// ═════════════════════════════════════════════════════════════════════════════
class _ConnectView extends StatefulWidget {
  final AnimationController bgCtrl;
  final Animation<double> scaleAnim;
  final Animation<double> fadeAnim;
  final Future<void> Function(String, String, String, String) onConnected;
  const _ConnectView({
    required this.bgCtrl,
    required this.scaleAnim,
    required this.fadeAnim,
    required this.onConnected,
  });
  @override
  State<_ConnectView> createState() => _ConnectViewState();
}

class _ConnectViewState extends State<_ConnectView>
    with SingleTickerProviderStateMixin {
  final _tokenCtrl = TextEditingController();
  bool _busy = false;
  String? _err;
  bool _obscure = true;

  late final AnimationController _cloudCtrl;

  @override
  void initState() {
    super.initState();
    _cloudCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 3),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _cloudCtrl.dispose();
    _tokenCtrl.dispose();
    super.dispose();
  }

  Future<void> _connect() async {
    final tok = _tokenCtrl.text.trim();
    if (tok.isEmpty) return;
    setState(() { _busy = true; _err = null; });

    final api = CfApi(tok);
    final verify = await api.verifyToken();
    if (!verify.ok) {
      setState(() { _busy = false; _err = 'Invalid token — ${verify.error}'; });
      return;
    }

    final accounts = await api.listAccounts();
    if (!accounts.ok) {
      setState(() { _busy = false; _err = accounts.error; });
      return;
    }

    final list = (accounts.data['result'] as List?) ?? [];
    if (list.isEmpty) {
      setState(() { _busy = false; _err = 'No accounts found for this token.'; });
      return;
    }

    final userInfo = await api.getUserInfo();
    final email = userInfo.ok
        ? (userInfo.data['result']?['email'] ?? '')
        : '';

    String accountId;
    String acctName;

    if (list.length == 1) {
      accountId = list[0]['id'];
      acctName  = list[0]['name'];
    } else {
      if (!mounted) return;
      final picked = await showDialog<Map>(
        context: context,
        builder: (_) => _AccountPickerDialog(accounts: list),
      );
      if (picked == null) {
        setState(() { _busy = false; });
        return;
      }
      accountId = picked['id'];
      acctName  = picked['name'];
    }

    await widget.onConnected(tok, accountId, email, acctName);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Stack(
        children: [
          // animated bg gradient
          AnimatedBuilder(
            animation: widget.bgCtrl,
            builder: (_, __) {
              final t = widget.bgCtrl.value;
              return Container(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment(
                      -0.5 + t * 0.8,
                      -0.3 + t * 0.4,
                    ),
                    radius: 1.2,
                    colors: [
                      _cfOrange.withOpacity(0.08 + t * 0.05),
                      ThemeProvider().current.scaffoldBg,
                    ],
                  ),
                ),
              );
            },
          ),

          Center(
            child: FadeTransition(
              opacity: widget.fadeAnim,
              child: ScaleTransition(
                scale: widget.scaleAnim,
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 32),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // ── Animated CF Icon ──────────────────────────────────
                      AnimatedBuilder(
                        animation: _cloudCtrl,
                        builder: (_, __) {
                          final t = _cloudCtrl.value;
                          return Container(
                            width: 100,
                            height: 100,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: _cfOrange.withOpacity(0.08 + t * 0.06),
                              boxShadow: [
                                BoxShadow(
                                  color: _cfOrangeGlow.withOpacity(0.25 + t * 0.20),
                                  blurRadius: 30 + t * 20,
                                  spreadRadius: 2,
                                ),
                              ],
                            ),
                            padding: const EdgeInsets.all(22),
                            child: SvgPicture.asset(
                              'assets/icon/cloudflare.svg',
                              colorFilter: ColorFilter.mode(
                                Color.lerp(_cfOrange,
                                    const Color(0xFFFFAA44), t)!,
                                BlendMode.srcIn,
                              ),
                            ),
                          );
                        },
                      ),

                      const SizedBox(height: 24),
                      const Text(
                        'Cloudflare Manager',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 26,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.5,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Connect your account to manage Workers,\nDNS, Pages & Analytics',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: _textDim,
                          fontSize: 13.5,
                          height: 1.5,
                        ),
                      ),

                      const SizedBox(height: 36),

                      // ── Token input ─────────────────────────────────────
                      Container(
                        decoration: BoxDecoration(
                          color: _cardBg,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: _cfOrange.withOpacity(0.35)),
                          boxShadow: [
                            BoxShadow(
                              color: _cfOrange.withOpacity(0.08),
                              blurRadius: 16,
                              spreadRadius: 1,
                            ),
                          ],
                        ),
                        child: TextField(
                          controller: _tokenCtrl,
                          obscureText: _obscure,
                          style: const TextStyle(
                            color: Colors.white, fontSize: 13.5,
                            fontFamily: 'monospace',
                          ),
                          decoration: InputDecoration(
                            hintText: 'Cloudflare API Token',
                            hintStyle: TextStyle(color: _textDim.withOpacity(0.6)),
                            prefixIcon: Icon(
                              Icons.vpn_key_rounded,
                              color: _cfOrange.withOpacity(0.7),
                              size: 20,
                            ),
                            suffixIcon: IconButton(
                              icon: Icon(
                                _obscure
                                    ? Icons.visibility_off_rounded
                                    : Icons.visibility_rounded,
                                color: _textDim,
                                size: 20,
                              ),
                              onPressed: () =>
                                  setState(() => _obscure = !_obscure),
                            ),
                            border: InputBorder.none,
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 16,
                            ),
                          ),
                        ),
                      ),

                      if (_err != null) ...[
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 10),
                          decoration: BoxDecoration(
                            color: Colors.red.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: Colors.red.withOpacity(0.3)),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.error_outline_rounded,
                                  color: Colors.red, size: 16),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  _err!,
                                  style: const TextStyle(
                                      color: Colors.red, fontSize: 12.5),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],

                      const SizedBox(height: 20),

                      SizedBox(
                        width: double.infinity,
                        child: _CfButton(
                          label: _busy ? 'Verifying...' : 'Connect Account',
                          icon: _busy ? null : Icons.link_rounded,
                          loading: _busy,
                          onTap: _busy ? null : _connect,
                        ),
                      ),

                      const SizedBox(height: 28),
                      const _TokenGuide(),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // back button
          Positioned(
            top: 8, left: 8,
            child: IconButton(
              icon: const Icon(Icons.arrow_back_ios_new_rounded,
                  color: _textDim, size: 20),
              onPressed: () => Navigator.pop(context),
            ),
          ),
        ],
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// DASHBOARD VIEW
// ═════════════════════════════════════════════════════════════════════════════
class _DashboardView extends StatelessWidget {
  final AnimationController bgCtrl;
  final String token;
  final String accountId;
  final String email;
  final String acctName;
  final int tabIndex;
  final ValueChanged<int> onTabChange;
  final VoidCallback onDisconnect;

  const _DashboardView({
    required this.bgCtrl,
    required this.token,
    required this.accountId,
    required this.email,
    required this.acctName,
    required this.tabIndex,
    required this.onTabChange,
    required this.onDisconnect,
  });

  @override
  Widget build(BuildContext context) {
    final api = CfApi(token);
    final tabs = [
      _WorkersTab(api: api, accountId: accountId),
      _DnsTab(api: api),
      _PagesTab(api: api, accountId: accountId),
      _StatsTab(api: api, accountId: accountId),
      _StorageTab(api: api, accountId: accountId),
    ];
    return Scaffold(
      backgroundColor: ThemeProvider().current.scaffoldBg,
      appBar: _CfAppBar(
        bgCtrl: bgCtrl,
        acctName: acctName,
        email: email,
        onDisconnect: onDisconnect,
      ),
      body: IndexedStack(
        index: tabIndex,
        children: tabs,
      ),
      bottomNavigationBar: _CfNavBar(
        selected: tabIndex,
        onTap: onTabChange,
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// APP BAR
// ═════════════════════════════════════════════════════════════════════════════
class _CfAppBar extends StatelessWidget implements PreferredSizeWidget {
  final AnimationController bgCtrl;
  final String acctName;
  final String email;
  final VoidCallback onDisconnect;

  const _CfAppBar({
    required this.bgCtrl,
    required this.acctName,
    required this.email,
    required this.onDisconnect,
  });

  @override
  Size get preferredSize => const Size.fromHeight(64);

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: bgCtrl,
      builder: (_, __) {
        return Container(
          decoration: BoxDecoration(
            color: _cardBg,
            border: Border(
              bottom: BorderSide(
                color: _cfOrange.withOpacity(0.15 + bgCtrl.value * 0.10),
              ),
            ),
            boxShadow: [
              BoxShadow(
                color: _cfOrange.withOpacity(0.04 + bgCtrl.value * 0.04),
                blurRadius: 12,
              ),
            ],
          ),
          child: SafeArea(
            bottom: false,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back_ios_new_rounded,
                        color: _textDim, size: 20),
                    onPressed: () => Navigator.pop(context),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                  ),
                  const SizedBox(width: 10),
                  SvgPicture.asset(
                    'assets/icon/cloudflare.svg',
                    width: 26,
                    height: 26,
                    colorFilter: const ColorFilter.mode(
                        _cfOrange, BlendMode.srcIn),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text(
                          'Cloudflare Manager',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 0.3,
                          ),
                        ),
                        Text(
                          acctName.isNotEmpty ? acctName : email,
                          style: const TextStyle(
                            color: _cfOrange,
                            fontSize: 11,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.logout_rounded,
                        color: _textDim, size: 20),
                    tooltip: 'Disconnect',
                    onPressed: () async {
                      final ok = await showDialog<bool>(
                        context: context,
                        builder: (_) => _CfConfirmDialog(
                          title: 'Disconnect Account',
                          message:
                              'Remove your Cloudflare token from this device?',
                          confirmLabel: 'Disconnect',
                          confirmColor: Colors.red,
                        ),
                      );
                      if (ok == true) onDisconnect();
                    },
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// BOTTOM NAV BAR
// ═════════════════════════════════════════════════════════════════════════════
class _CfNavBar extends StatelessWidget {
  final int selected;
  final ValueChanged<int> onTap;
  const _CfNavBar({required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final items = [
      (Icons.terminal_rounded, 'Workers'),
      (Icons.dns_rounded, 'DNS'),
      (Icons.web_rounded, 'Pages'),
      (Icons.bar_chart_rounded, 'Stats'),
      (Icons.storage_rounded, 'Storage'),
    ];
    return Container(
      decoration: BoxDecoration(
        color: _cardBg,
        border: Border(
          top: BorderSide(color: ThemeProvider().current.surfaceColor),
        ),
      ),
      child: Row(
        children: items.asMap().entries.map((entry) {
          final i = entry.key;
          final (icon, label) = entry.value;
          final active = selected == i;
          return Expanded(
            child: GestureDetector(
              onTap: () => onTap(i),
              behavior: HitTestBehavior.opaque,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 18, vertical: 6),
                      decoration: BoxDecoration(
                        color: active
                            ? _cfOrange.withOpacity(0.15)
                            : Colors.transparent,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Icon(
                        icon,
                        color: active ? _cfOrange : _textDim,
                        size: 22,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      label,
                      style: TextStyle(
                        color: active ? _cfOrange : _textDim,
                        fontSize: 10.5,
                        fontWeight:
                            active ? FontWeight.w700 : FontWeight.w400,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// WORKERS TAB
// ═════════════════════════════════════════════════════════════════════════════
class _WorkersTab extends StatefulWidget {
  final CfApi api;
  final String accountId;
  const _WorkersTab({required this.api, required this.accountId});
  @override
  State<_WorkersTab> createState() => _WorkersTabState();
}

class _WorkersTabState extends State<_WorkersTab>
    with AutomaticKeepAliveClientMixin {
  List<Map> _workers = [];
  bool _loading = true;
  String? _err;
  String _search = '';
  String? _subdomain;
  final _searchCtrl = TextEditingController();

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.listWorkers(widget.accountId);
    final sub = await widget.api.getWorkerSubdomain(widget.accountId);
    if (!mounted) return;
    if (!r.ok) {
      setState(() { _loading = false; _err = r.error; });
      return;
    }
    setState(() {
      _workers = List<Map>.from(r.data['result'] ?? []);
      final subResult = sub.ok ? sub.data['result'] : null;
      _subdomain = subResult is Map ? subResult['subdomain'] as String? : null;
      _loading = false;
    });
  }

  List<Map> get _filtered => _search.isEmpty
      ? _workers
      : _workers
          .where((w) => (w['id'] as String? ?? '')
              .toLowerCase()
              .contains(_search.toLowerCase()))
          .toList();

  Future<void> _uploadNew() async {
    final res = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['js', 'mjs', 'ts', 'zip'],
      allowMultiple: false,
    );
    if (res == null || res.files.isEmpty) return;
    final file = res.files.first;
    if (file.path == null) return;

    final nameCtrl = TextEditingController();
    if (!mounted) return;
    final name = await showDialog<String>(
      context: context,
      builder: (_) => _WorkerNameDialog(
        controller: nameCtrl,
        subdomain: _subdomain ?? '',
      ),
    );
    if (name == null || name.trim().isEmpty) return;

    _showBusy('Uploading ${file.name}...');

    String? script;
    final isZip = file.name.toLowerCase().endsWith('.zip');
    if (isZip) {
      final bytes = await File(file.path!).readAsBytes();
      script = CfApi.extractJsFromZip(bytes);
      if (script == null) {
        if (!mounted) return;
        Navigator.pop(context);
        _toast('No JavaScript entry point found in ZIP.\nExpected: index.js, worker.js, src/index.js', error: true);
        return;
      }
    } else {
      script = await _readFileStr(file.path!);
    }

    final r = await widget.api.uploadWorkerScript(widget.accountId, name.trim(), script);
    if (!mounted) return;
    Navigator.pop(context);
    if (r.ok) {
      _toast('Worker "${name.trim()}" deployed!');
      _load();
    } else {
      _toast('${r.error}', error: true);
    }
  }

  Future<String> _readFileStr(String path) async {
    try {
      return await File(path).readAsString();
    } catch (_) {
      return '';
    }
  }

  void _showBusy(String msg) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _BusyDialog(message: msg),
    );
  }

  void _toast(String msg, {bool error = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(children: [
          Icon(
            error ? Icons.error_rounded : Icons.check_circle_rounded,
            color: Colors.white,
            size: 18,
          ),
          const SizedBox(width: 8),
          Expanded(child: Text(msg, style: const TextStyle(color: Colors.white))),
        ]),
        backgroundColor: error ? Colors.red.shade800 : _cfOrange,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Column(
      children: [
        // search bar + count
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 4),
          child: Row(
            children: [
              Expanded(
                child: _CfSearchField(
                  controller: _searchCtrl,
                  hint: 'Search workers...',
                  onChanged: (v) => setState(() => _search = v),
                ),
              ),
              const SizedBox(width: 8),
              _CfIconBtn(
                icon: Icons.refresh_rounded,
                tooltip: 'Refresh',
                onTap: _load,
              ),
              const SizedBox(width: 6),
              _CfIconBtn(
                icon: Icons.upload_rounded,
                tooltip: 'Upload new worker',
                onTap: _uploadNew,
              ),
            ],
          ),
        ),
        if (!_loading && _err == null)
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 6),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: _workerGreen.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: _workerGreen.withOpacity(0.35)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.bolt_rounded, color: _workerGreen, size: 13),
                      const SizedBox(width: 5),
                      Text(
                        'Total workers: ${_workers.length}',
                        style: const TextStyle(
                          color: _workerGreen,
                          fontSize: 11.5,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
                if (_search.isNotEmpty && _filtered.length != _workers.length) ...[
                  const SizedBox(width: 8),
                  Text(
                    '${_filtered.length} shown',
                    style: TextStyle(color: _textDim.withOpacity(0.7), fontSize: 11),
                  ),
                ],
              ],
            ),
          ),
        Expanded(
          child: _loading
              ? const _LoadingView()
              : _err != null
                  ? _ErrorView(error: _err!, onRetry: _load)
                  : _filtered.isEmpty
                      ? _EmptyView(
                          icon: Icons.bolt_rounded,
                          title: _search.isEmpty
                              ? 'No workers yet'
                              : 'No matches',
                          subtitle: _search.isEmpty
                              ? 'Tap ↑ to upload your first worker'
                              : 'Try a different search term',
                        )
                      : RefreshIndicator(
                          color: _cfOrange,
                          onRefresh: _load,
                          child: ListView.builder(
                            padding: const EdgeInsets.fromLTRB(14, 4, 14, 80),
                            itemCount: _filtered.length,
                            itemBuilder: (_, i) {
                              final w = _filtered[i];
                              final name = w['id'] as String? ?? '';
                              final url = _subdomain != null
                                  ? 'https://$name.$_subdomain.workers.dev'
                                  : null;
                              return _WorkerCard(
                                key: ValueKey(name),
                                name: name,
                                url: url,
                                modified: w['modified_on'] as String? ?? '',
                                api: widget.api,
                                accountId: widget.accountId,
                                onChanged: _load,
                              );
                            },
                          ),
                        ),
        ),
      ],
    );
  }
}

// ── Worker Card ───────────────────────────────────────────────────────────────
class _WorkerCard extends StatefulWidget {
  final String name;
  final String? url;
  final String modified;
  final CfApi api;
  final String accountId;
  final VoidCallback onChanged;

  const _WorkerCard({
    super.key,
    required this.name,
    this.url,
    required this.modified,
    required this.api,
    required this.accountId,
    required this.onChanged,
  });
  @override
  State<_WorkerCard> createState() => _WorkerCardState();
}

class _WorkerCardState extends State<_WorkerCard>
    with TickerProviderStateMixin {
  bool _expanded = false;
  late final AnimationController _expandCtrl;
  late final Animation<double> _expandAnim;
  late final AnimationController _pulseCtrl;
  late final Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    _expandCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 280),
    );
    _expandAnim = CurvedAnimation(parent: _expandCtrl, curve: Curves.easeOut);

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.88, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _expandCtrl.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  void _toggle() {
    setState(() => _expanded = !_expanded);
    if (_expanded) _expandCtrl.forward();
    else _expandCtrl.reverse();
  }

  Future<void> _viewScript() async {
    _showBusy('Fetching script...');
    final content = await widget.api
        .getWorkerScript(widget.accountId, widget.name);
    if (!mounted) return;
    Navigator.pop(context);
    if (content == null || content.isEmpty) {
      _toast('Could not fetch script', error: true);
      return;
    }
    if (!mounted) return;
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => _ScriptViewScreen(
        name: widget.name,
        content: content,
        api: widget.api,
        accountId: widget.accountId,
      ),
    ));
  }

  Future<void> _downloadScript() async {
    final hasAccess = await PermissionHelper.ensureStorage(context, accent: _workerGreen);
    if (!hasAccess || !mounted) return;
    _showBusy('Fetching script...');
    final content = await widget.api.getWorkerScript(widget.accountId, widget.name);
    if (!mounted) return;
    Navigator.pop(context);
    if (content == null || content.isEmpty) { _toast('Could not fetch script', error: true); return; }
    try {
      final root = await StorageHelper.getRootDir();
      final saveDir = Directory('$root/${StorageHelper.appFolder}/cloudflare');
      await saveDir.create(recursive: true);
      final path = '${saveDir.path}/${widget.name}.js';
      await File(path).writeAsString(content);
      _toast('Saved → Taurus-Shield/cloudflare/${widget.name}.js');
    } catch (e) {
      _toast('Save failed: $e', error: true);
    }
  }

  Future<void> _replaceScript() async {
    final res = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['js', 'mjs', 'ts', 'zip'],
    );
    if (res == null || res.files.isEmpty) return;
    final file = res.files.first;
    if (file.path == null) return;
    _showBusy('Replacing script...');
    String? content;
    if (file.name.toLowerCase().endsWith('.zip')) {
      final bytes = await File(file.path!).readAsBytes();
      content = CfApi.extractJsFromZip(bytes);
      if (content == null) {
        if (!mounted) return;
        Navigator.pop(context);
        _toast('No JS entry point found in ZIP (expected index.js or worker.js)', error: true);
        return;
      }
    } else {
      content = await _readStr(file.path!);
    }
    final r = await widget.api.uploadWorkerScript(widget.accountId, widget.name, content);
    if (!mounted) return;
    Navigator.pop(context);
    _toast(r.ok ? 'Script replaced!' : '${r.error}', error: !r.ok);
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => _CfConfirmDialog(
        title: 'Delete Worker',
        message: 'Delete "${widget.name}"? This cannot be undone.',
        confirmLabel: 'Delete',
        confirmColor: Colors.red,
      ),
    );
    if (ok != true) return;
    _showBusy('Deleting...');
    final r =
        await widget.api.deleteWorker(widget.accountId, widget.name);
    if (!mounted) return;
    Navigator.pop(context);
    if (r.ok) {
      _toast('Deleted');
      widget.onChanged();
    } else {
      _toast('${r.error}', error: true);
    }
  }

  Future<void> _rename() async {
    final ctrl = TextEditingController(text: widget.name);
    final newName = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _cardBg,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16),
            side: BorderSide(color: ThemeProvider().current.surfaceColor)),
        title: const Text('Rename Worker', style: TextStyle(color: Colors.white, fontSize: 16)),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          style: TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: 'new-worker-name',
            hintStyle: TextStyle(color: _textDim),
            filled: true, fillColor: ThemeProvider().current.scaffoldBg,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10),
                borderSide: const BorderSide(color: _workerGreen)),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel', style: TextStyle(color: _textDim))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: _workerGreen, foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)), elevation: 0),
            onPressed: () => Navigator.pop(context, ctrl.text.trim()),
            child: const Text('Rename'),
          ),
        ],
      ),
    );
    if (newName == null || newName.isEmpty || newName == widget.name || !mounted) return;
    _showBusy('Renaming worker...');
    final r = await widget.api.renameWorker(widget.accountId, widget.name, newName);
    if (!mounted) return;
    Navigator.pop(context);
    if (r.ok) { widget.onChanged(); _toast('Renamed to "$newName"'); }
    else _toast('${r.error}', error: true);
  }

  Future<void> _viewRoutes() async {
    if (!mounted) return;
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => _RoutesScreen(
        api: widget.api,
        workerName: widget.name,
      ),
    ));
  }

  Future<void> _openSecrets() => Navigator.push(context, MaterialPageRoute(
    builder: (_) => _WorkerSecretsScreen(api: widget.api, accountId: widget.accountId, workerName: widget.name),
  ));

  Future<void> _openBindings() => Navigator.push(context, MaterialPageRoute(
    builder: (_) => _WorkerBindingsScreen(api: widget.api, accountId: widget.accountId, workerName: widget.name),
  ));

  Future<void> _openCrons() => Navigator.push(context, MaterialPageRoute(
    builder: (_) => _WorkerCronsScreen(api: widget.api, accountId: widget.accountId, workerName: widget.name),
  ));

  Future<void> _openDomains() => Navigator.push(context, MaterialPageRoute(
    builder: (_) => _WorkerDomainsScreen(api: widget.api, accountId: widget.accountId, workerName: widget.name),
  ));

  Future<void> _openSettings() => Navigator.push(context, MaterialPageRoute(
    builder: (_) => _WorkerSettingsScreen(api: widget.api, accountId: widget.accountId, workerName: widget.name),
  ));

  void _copyUrl() {
    if (widget.url == null) return;
    Clipboard.setData(ClipboardData(text: widget.url!));
    _toast('Copied URL');
  }

  void _showBusy(String msg) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _BusyDialog(message: msg),
    );
  }

  void _toast(String msg, {bool error = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(children: [
          Icon(
            error ? Icons.error_rounded : Icons.check_circle_rounded,
            color: Colors.white,
            size: 18,
          ),
          const SizedBox(width: 8),
          Expanded(child: Text(msg, style: const TextStyle(color: Colors.white))),
        ]),
        backgroundColor: error ? Colors.red.shade800 : _workerGreen,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  Future<String> _readStr(String path) async {
    try {
      final f = await (File(path)).readAsString();
      return f;
    } catch (_) {
      return '';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: _cardBg,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: _expanded
              ? _workerGreen.withOpacity(0.45)
              : ThemeProvider().current.surfaceColor,
        ),
        boxShadow: _expanded
            ? [
                BoxShadow(
                  color: _workerGreen.withOpacity(0.10),
                  blurRadius: 16,
                  spreadRadius: 1,
                )
              ]
            : [],
      ),
      child: Column(
        children: [
          // header
          InkWell(
            onTap: _toggle,
            borderRadius: BorderRadius.circular(14),
            child: Padding(
              padding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 13),
              child: Row(
                children: [
                  // Pulsing green icon
                  AnimatedBuilder(
                    animation: _pulseAnim,
                    builder: (_, __) => Transform.scale(
                      scale: _pulseAnim.value,
                      child: Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: _workerGreen.withOpacity(0.14),
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: [
                            BoxShadow(
                              color: _workerGreen.withOpacity(
                                  0.18 + 0.18 * _pulseAnim.value),
                              blurRadius: 10,
                              spreadRadius: 0,
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.terminal_rounded,
                          color: _workerGreen,
                          size: 20,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.name,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        if (widget.url != null)
                          Text(
                            widget.url!,
                            style: const TextStyle(
                              color: _workerGreen,
                              fontSize: 10.5,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                      ],
                    ),
                  ),
                  AnimatedRotation(
                    turns: _expanded ? 0.5 : 0,
                    duration: const Duration(milliseconds: 280),
                    child: const Icon(
                      Icons.keyboard_arrow_down_rounded,
                      color: _textDim,
                    ),
                  ),
                ],
              ),
            ),
          ),

          // expanded actions
          SizeTransition(
            sizeFactor: _expandAnim,
            child: Column(
              children: [
                Container(
                  height: 1,
                  margin: EdgeInsets.symmetric(horizontal: 12),
                  color: ThemeProvider().current.surfaceColor,
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
                  child: Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      _ActionChip(
                        icon: Icons.code_rounded,
                        label: 'View Script',
                        onTap: _viewScript,
                      ),
                      _ActionChip(
                        icon: Icons.download_rounded,
                        label: 'Download',
                        onTap: _downloadScript,
                      ),
                      _ActionChip(
                        icon: Icons.upload_file_rounded,
                        label: 'Replace Script',
                        onTap: _replaceScript,
                      ),
                      _ActionChip(
                        icon: Icons.drive_file_rename_outline_rounded,
                        label: 'Rename',
                        onTap: _rename,
                      ),
                      _ActionChip(
                        icon: Icons.lock_rounded,
                        label: 'Secrets',
                        onTap: _openSecrets,
                      ),
                      _ActionChip(
                        icon: Icons.link_rounded,
                        label: 'Bindings',
                        onTap: _openBindings,
                      ),
                      _ActionChip(
                        icon: Icons.schedule_rounded,
                        label: 'Cron Triggers',
                        onTap: _openCrons,
                      ),
                      _ActionChip(
                        icon: Icons.route_rounded,
                        label: 'Routes',
                        onTap: _viewRoutes,
                      ),
                      _ActionChip(
                        icon: Icons.language_rounded,
                        label: 'Domains',
                        onTap: _openDomains,
                      ),
                      _ActionChip(
                        icon: Icons.tune_rounded,
                        label: 'Settings',
                        onTap: _openSettings,
                      ),
                      if (widget.url != null)
                        _ActionChip(
                          icon: Icons.copy_rounded,
                          label: 'Copy URL',
                          onTap: _copyUrl,
                        ),
                      _ActionChip(
                        icon: Icons.delete_outline_rounded,
                        label: 'Delete',
                        color: Colors.red.shade400,
                        onTap: _delete,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ── Script View Screen ────────────────────────────────────────────────────────
class _ScriptViewScreen extends StatefulWidget {
  final String name;
  final String content;
  final CfApi api;
  final String accountId;
  const _ScriptViewScreen({
    required this.name,
    required this.content,
    required this.api,
    required this.accountId,
  });
  @override
  State<_ScriptViewScreen> createState() => _ScriptViewScreenState();
}

class _ScriptViewScreenState extends State<_ScriptViewScreen>
    with TickerProviderStateMixin {
  late final TextEditingController _ctrl;
  bool _isEditing = false;
  bool _isDeploying = false;
  bool _deploySuccess = false;
  String? _workerUrl;

  late final AnimationController _successCtrl;
  late final AnimationController _pulseCtrl;
  late final Animation<double> _successScale;
  late final Animation<double> _successFade;
  late final Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    _ctrl = TextEditingController(text: widget.content);

    _successCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 700));
    _successScale = Tween<double>(begin: 0.55, end: 1.0).animate(
        CurvedAnimation(parent: _successCtrl, curve: Curves.elasticOut));
    _successFade = Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(parent: _successCtrl, curve: Curves.easeOut));

    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1400))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.7, end: 1.0).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    _successCtrl.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  Future<void> _download() async {
    final hasAccess =
        await PermissionHelper.ensureStorage(context, accent: _workerGreen);
    if (!hasAccess || !mounted) return;
    try {
      final root = await StorageHelper.getRootDir();
      final saveDir =
          Directory('$root/${StorageHelper.appFolder}/cloudflare');
      await saveDir.create(recursive: true);
      final path = '${saveDir.path}/${widget.name}.js';
      await File(path).writeAsString(_ctrl.text);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content:
              Text('Saved → Taurus-Shield/cloudflare/${widget.name}.js'),
          backgroundColor: _workerGreen,
        ));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Save failed: $e'),
          backgroundColor: Colors.red,
        ));
      }
    }
  }

  Future<void> _deploy() async {
    setState(() {
      _isDeploying = true;
      _deploySuccess = false;
    });
    final script = _ctrl.text;
    final r = await widget.api
        .uploadWorkerScript(widget.accountId, widget.name, script);
    if (!mounted) return;
    if (r.ok) {
      final subR = await widget.api.getWorkerSubdomain(widget.accountId);
      String? url;
      if (subR.ok) {
        final sub =
            subR.data?['result']?['subdomain'] as String?;
        if (sub != null && sub.isNotEmpty) {
          url = 'https://${widget.name}.$sub.workers.dev';
        }
      }
      setState(() {
        _isDeploying = false;
        _deploySuccess = true;
        _workerUrl = url;
      });
      _successCtrl.forward(from: 0);
    } else {
      setState(() => _isDeploying = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(r.error ?? 'Deploy failed'),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
        ));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeProvider().current.scaffoldBg,
      appBar: AppBar(
        backgroundColor: _cardBg,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.name,
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w700)),
            Text(
              _isEditing ? 'Editing script' : 'Viewing script',
              style: const TextStyle(color: _textDim, fontSize: 10),
            ),
          ],
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded,
              color: _textDim, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          if (!_isEditing && !_deploySuccess) ...[
            IconButton(
              icon: const Icon(Icons.download_rounded,
                  color: _workerGreen),
              tooltip: 'Download',
              onPressed: _download,
            ),
            IconButton(
              icon:
                  const Icon(Icons.copy_rounded, color: _workerGreen),
              tooltip: 'Copy',
              onPressed: () {
                Clipboard.setData(ClipboardData(text: _ctrl.text));
                ScaffoldMessenger.of(context)
                    .showSnackBar(const SnackBar(
                  content: Text('Script copied!'),
                  backgroundColor: _workerGreen,
                ));
              },
            ),
          ],
          if (!_deploySuccess)
            IconButton(
              icon: Icon(
                _isEditing
                    ? Icons.check_circle_rounded
                    : Icons.edit_rounded,
                color: _workerGreen,
              ),
              tooltip: _isEditing ? 'Done editing' : 'Edit script',
              onPressed: () =>
                  setState(() => _isEditing = !_isEditing),
            ),
        ],
      ),
      body: Stack(
        children: [
          if (!_deploySuccess)
            _isEditing
                ? TextField(
                    controller: _ctrl,
                    maxLines: null,
                    expands: true,
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 11.5,
                      fontFamily: 'monospace',
                      height: 1.5,
                    ),
                    decoration: const InputDecoration(
                      contentPadding: EdgeInsets.all(14),
                      border: InputBorder.none,
                      filled: true,
                      fillColor: Colors.transparent,
                    ),
                  )
                : SingleChildScrollView(
                    padding: const EdgeInsets.all(14),
                    child: SelectableText(
                      _ctrl.text,
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 11.5,
                        fontFamily: 'monospace',
                        height: 1.5,
                      ),
                    ),
                  ),
          if (_deploySuccess) _buildSuccessView(),
          if (_isDeploying) _buildDeployOverlay(),
        ],
      ),
      floatingActionButton: (!_deploySuccess && !_isDeploying)
          ? FloatingActionButton.extended(
              onPressed: _deploy,
              backgroundColor: _workerGreen,
              foregroundColor: Colors.white,
              icon: const Icon(Icons.rocket_launch_rounded),
              label: const Text('Deploy',
                  style: TextStyle(fontWeight: FontWeight.w800)),
            )
          : null,
    );
  }

  Widget _buildDeployOverlay() {
    return Container(
      color: ThemeProvider().current.scaffoldBg.withOpacity(0.93),
      child: Center(
        child: AnimatedBuilder(
          animation: _pulseAnim,
          builder: (_, __) => Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                width: 80,
                height: 80,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Transform.scale(
                      scale: _pulseAnim.value,
                      child: Container(
                        width: 80,
                        height: 80,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color:
                              _workerGreen.withOpacity(0.08 * _pulseAnim.value),
                          border: Border.all(
                            color: _workerGreen
                                .withOpacity(0.25 * _pulseAnim.value),
                            width: 1.5,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      width: 52,
                      height: 52,
                      child: CircularProgressIndicator(
                        color: _workerGreen,
                        strokeWidth: 3,
                      ),
                    ),
                    const Icon(Icons.rocket_launch_rounded,
                        color: _workerGreen, size: 20),
                  ],
                ),
              ),
              const SizedBox(height: 22),
              const Text('Deploying...',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 17,
                      fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              const Text('Uploading script to Cloudflare Workers',
                  style: TextStyle(color: _textDim, fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSuccessView() {
    return AnimatedBuilder(
      animation: _successCtrl,
      builder: (_, __) => Opacity(
        opacity: _successFade.value,
        child: Container(
          color: ThemeProvider().current.scaffoldBg,
          child: Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 28),
              child: Transform.scale(
                scale: _successScale.value,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 92,
                      height: 92,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _workerGreen.withOpacity(0.12),
                        border: Border.all(
                            color: _workerGreen, width: 2.5),
                        boxShadow: [
                          BoxShadow(
                            color: _workerGreen.withOpacity(0.35),
                            blurRadius: 28,
                            spreadRadius: 4,
                          ),
                        ],
                      ),
                      child: const Icon(Icons.check_rounded,
                          color: _workerGreen, size: 48),
                    ),
                    const SizedBox(height: 22),
                    const Text('Deployed Successfully',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 21,
                            fontWeight: FontWeight.w900)),
                    const SizedBox(height: 8),
                    Text(
                      '${widget.name} is now live on Cloudflare Workers',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                          color: _textDim,
                          fontSize: 13,
                          height: 1.5),
                    ),
                    if (_workerUrl != null) ...[
                      const SizedBox(height: 18),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 10),
                        decoration: BoxDecoration(
                          color: _workerGreen.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                              color: _workerGreen.withOpacity(0.3)),
                        ),
                        child: Text(
                          _workerUrl!,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: _workerGreen,
                            fontSize: 11.5,
                            fontFamily: 'monospace',
                          ),
                        ),
                      ),
                      const SizedBox(height: 18),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          onPressed: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => _WorkerBrowserScreen(
                                      url: _workerUrl!,
                                      title: widget.name))),
                          icon: const Icon(
                              Icons.open_in_browser_rounded,
                              size: 18),
                          label: const Text('Open Endpoint',
                              style: TextStyle(
                                  fontWeight: FontWeight.w800,
                                  fontSize: 15)),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _workerGreen,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(
                                vertical: 15),
                            shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.circular(14)),
                            elevation: 0,
                          ),
                        ),
                      ),
                    ],
                    const SizedBox(height: 12),
                    TextButton(
                      onPressed: () =>
                          setState(() => _deploySuccess = false),
                      child: const Text('Back to Script',
                          style: TextStyle(color: _textDim)),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ── In-app Worker endpoint browser ────────────────────────────────────────────
class _WorkerBrowserScreen extends StatefulWidget {
  final String url;
  final String title;
  const _WorkerBrowserScreen(
      {required this.url, required this.title});
  @override
  State<_WorkerBrowserScreen> createState() =>
      _WorkerBrowserScreenState();
}

class _WorkerBrowserScreenState extends State<_WorkerBrowserScreen> {
  late final WebViewController _webCtrl;
  bool _loading = true;
  int _progress = 0;

  @override
  void initState() {
    super.initState();
    _webCtrl = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
        onPageStarted: (_) =>
            setState(() {
              _loading = true;
              _progress = 0;
            }),
        onPageFinished: (_) => setState(() => _loading = false),
        onProgress: (p) => setState(() => _progress = p),
      ))
      ..loadRequest(Uri.parse(widget.url));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeProvider().current.scaffoldBg,
      appBar: AppBar(
        backgroundColor: _cardBg,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.title,
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w700)),
            Text(widget.url,
                style: const TextStyle(
                    color: _textDim, fontSize: 10),
                overflow: TextOverflow.ellipsis),
          ],
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded,
              color: _textDim, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon:
                const Icon(Icons.refresh_rounded, color: _workerGreen),
            tooltip: 'Refresh',
            onPressed: () => _webCtrl.reload(),
          ),
          IconButton(
            icon: const Icon(Icons.open_in_browser_rounded,
                color: _workerGreen),
            tooltip: 'Open in browser',
            onPressed: () => launchUrl(Uri.parse(widget.url),
                mode: LaunchMode.externalApplication),
          ),
        ],
        bottom: _loading
            ? PreferredSize(
                preferredSize: const Size.fromHeight(3),
                child: LinearProgressIndicator(
                  value: _progress / 100,
                  backgroundColor: _cardBg,
                  valueColor:
                      const AlwaysStoppedAnimation(_workerGreen),
                  minHeight: 3,
                ),
              )
            : null,
      ),
      body: WebViewWidget(controller: _webCtrl),
    );
  }
}

// ── Routes Screen ─────────────────────────────────────────────────────────────
class _RoutesScreen extends StatefulWidget {
  final CfApi api;
  final String workerName;
  const _RoutesScreen({required this.api, required this.workerName});
  @override
  State<_RoutesScreen> createState() => _RoutesScreenState();
}

class _RoutesScreenState extends State<_RoutesScreen> {
  List<Map> _zones = [];
  List<Map> _routes = [];
  String? _selectedZoneId;
  bool _loading = true;
  String? _err;

  @override
  void initState() {
    super.initState();
    _loadZones();
  }

  Future<void> _loadZones() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.listZones();
    if (!mounted) return;
    if (!r.ok) {
      setState(() { _loading = false; _err = r.error; });
      return;
    }
    final zones = List<Map>.from(r.data['result'] ?? []);
    setState(() { _zones = zones; _loading = false; });
    if (zones.isNotEmpty) _selectZone(zones.first['id']);
  }

  Future<void> _selectZone(String zoneId) async {
    setState(() { _selectedZoneId = zoneId; _loading = true; });
    final r = await widget.api.getWorkerRoutes(zoneId);
    if (!mounted) return;
    setState(() {
      _routes = List<Map>.from(r.data?['result'] ?? [])
          .where((rt) => rt['script'] == widget.workerName)
          .toList();
      _loading = false;
    });
  }

  Future<void> _addRoute() async {
    if (_selectedZoneId == null) return;
    final ctrl = TextEditingController();
    final pattern = await showDialog<String>(
      context: context,
      builder: (_) => _TextInputDialog(
        title: 'Add Route',
        hint: 'example.com/*',
        label: 'Route pattern (e.g. example.com/*)',
        controller: ctrl,
      ),
    );
    if (pattern == null || pattern.trim().isEmpty) return;
    _showBusy('Adding route...');
    final r = await widget.api
        .createWorkerRoute(_selectedZoneId!, pattern.trim(), widget.workerName);
    if (!mounted) return;
    Navigator.pop(context);
    if (r.ok) {
      _toast('Route added!');
      _selectZone(_selectedZoneId!);
    } else {
      _toast('${r.error}', error: true);
    }
  }

  Future<void> _deleteRoute(String routeId) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => _CfConfirmDialog(
        title: 'Delete Route',
        message: 'Remove this route?',
        confirmLabel: 'Delete',
        confirmColor: Colors.red,
      ),
    );
    if (ok != true) return;
    _showBusy('Deleting...');
    final r =
        await widget.api.deleteWorkerRoute(_selectedZoneId!, routeId);
    if (!mounted) return;
    Navigator.pop(context);
    if (r.ok) {
      _toast('Route deleted');
      _selectZone(_selectedZoneId!);
    } else {
      _toast('${r.error}', error: true);
    }
  }

  void _showBusy(String msg) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _BusyDialog(message: msg),
    );
  }

  void _toast(String msg, {bool error = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(
          error ? Icons.error_rounded : Icons.check_circle_rounded,
          color: Colors.white,
          size: 18,
        ),
        const SizedBox(width: 8),
        Expanded(child: Text(msg, style: const TextStyle(color: Colors.white))),
      ]),
      backgroundColor: error ? Colors.red.shade800 : _cfOrange,
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeProvider().current.scaffoldBg,
      appBar: AppBar(
        backgroundColor: _cardBg,
        title: Text('Routes — ${widget.workerName}',
            style: const TextStyle(color: Colors.white, fontSize: 14)),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded,
              color: _textDim, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_rounded, color: _cfOrange),
            tooltip: 'Add route',
            onPressed: _addRoute,
          ),
        ],
      ),
      body: Column(
        children: [
          if (_zones.isNotEmpty)
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 6),
              child: Row(
                children: _zones.map((z) {
                  final sel = z['id'] == _selectedZoneId;
                  return GestureDetector(
                    onTap: () => _selectZone(z['id']),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      margin: const EdgeInsets.only(right: 8),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 7),
                      decoration: BoxDecoration(
                        color: sel
                            ? _cfOrange.withOpacity(0.15)
                            : _cardBg,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: sel
                              ? _cfOrange
                              : ThemeProvider().current.surfaceColor,
                        ),
                      ),
                      child: Text(
                        z['name'] ?? '',
                        style: TextStyle(
                          color: sel ? _cfOrange : _textDim,
                          fontSize: 12.5,
                          fontWeight: sel
                              ? FontWeight.w700
                              : FontWeight.w400,
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
          Expanded(
            child: _loading
                ? const _LoadingView()
                : _err != null
                    ? _ErrorView(error: _err!, onRetry: _loadZones)
                    : _routes.isEmpty
                        ? _EmptyView(
                            icon: Icons.route_rounded,
                            title: 'No routes',
                            subtitle: 'Tap + to add a route for this worker',
                          )
                        : ListView.builder(
                            padding:
                                const EdgeInsets.fromLTRB(14, 8, 14, 80),
                            itemCount: _routes.length,
                            itemBuilder: (_, i) {
                              final rt = _routes[i];
                              return Container(
                                margin: const EdgeInsets.only(bottom: 8),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 14, vertical: 12),
                                decoration: BoxDecoration(
                                  color: _cardBg,
                                  borderRadius:
                                      BorderRadius.circular(12),
                                  border: Border.all(
                                      color: ThemeProvider().current.surfaceColor),
                                ),
                                child: Row(
                                  children: [
                                    const Icon(Icons.route_rounded,
                                        color: _cfOrange, size: 18),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Text(
                                        rt['pattern'] ?? '',
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 13,
                                          fontFamily: 'monospace',
                                        ),
                                      ),
                                    ),
                                    IconButton(
                                      icon: Icon(
                                          Icons.delete_outline_rounded,
                                          color:
                                              Colors.red.shade400,
                                          size: 20),
                                      onPressed: () =>
                                          _deleteRoute(rt['id']),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
          ),
        ],
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// DNS TAB
// ═════════════════════════════════════════════════════════════════════════════
class _DnsTab extends StatefulWidget {
  final CfApi api;
  const _DnsTab({required this.api});
  @override
  State<_DnsTab> createState() => _DnsTabState();
}

class _DnsTabState extends State<_DnsTab>
    with AutomaticKeepAliveClientMixin {
  List<Map> _zones = [];
  List<Map> _records = [];
  String? _selectedZoneId;
  String? _selectedZoneName;
  bool _loadingZones = true;
  bool _loadingRecords = false;
  String? _err;
  String _search = '';
  final _searchCtrl = TextEditingController();

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _loadZones();
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadZones() async {
    setState(() { _loadingZones = true; _err = null; });
    final r = await widget.api.listZones();
    if (!mounted) return;
    if (!r.ok) {
      setState(() { _loadingZones = false; _err = r.error; });
      return;
    }
    final zones = List<Map>.from(r.data['result'] ?? []);
    setState(() { _zones = zones; _loadingZones = false; });
    if (zones.isNotEmpty) _selectZone(zones.first);
  }

  Future<void> _selectZone(Map zone) async {
    _searchCtrl.clear();
    setState(() {
      _selectedZoneId   = zone['id'];
      _selectedZoneName = zone['name'];
      _loadingRecords   = true;
      _search           = '';
    });
    final r = await widget.api.listDNSRecords(zone['id']);
    if (!mounted) return;
    setState(() {
      _records        = List<Map>.from(r.data?['result'] ?? []);
      _loadingRecords = false;
    });
  }

  List<Map> get _filtered => _search.isEmpty
      ? _records
      : _records.where((rec) {
          final name = (rec['name'] as String? ?? '').toLowerCase();
          final content = (rec['content'] as String? ?? '').toLowerCase();
          final q = _search.toLowerCase();
          return name.contains(q) || content.contains(q);
        }).toList();

  Future<void> _addRecord() async {
    if (_selectedZoneId == null) return;
    if (!mounted) return;
    await Navigator.push(context, MaterialPageRoute(
      builder: (_) => _DnsEditScreen(
        api: widget.api,
        zoneId: _selectedZoneId!,
        zoneName: _selectedZoneName ?? '',
      ),
    ));
    if (_selectedZoneId != null) {
      _selectZone({'id': _selectedZoneId!, 'name': _selectedZoneName});
    }
  }

  Future<void> _editRecord(Map record) async {
    if (!mounted) return;
    await Navigator.push(context, MaterialPageRoute(
      builder: (_) => _DnsEditScreen(
        api: widget.api,
        zoneId: _selectedZoneId!,
        zoneName: _selectedZoneName ?? '',
        existingRecord: record,
      ),
    ));
    if (_selectedZoneId != null) {
      _selectZone({'id': _selectedZoneId!, 'name': _selectedZoneName});
    }
  }

  Future<void> _deleteRecord(String recordId) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => _CfConfirmDialog(
        title: 'Delete DNS Record',
        message: 'Delete this record? This cannot be undone.',
        confirmLabel: 'Delete',
        confirmColor: Colors.red,
      ),
    );
    if (ok != true || !mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const _BusyDialog(message: 'Deleting record...'),
    );
    final r = await widget.api
        .deleteDNSRecord(_selectedZoneId!, recordId);
    if (!mounted) return;
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(r.ok ? Icons.check_circle_rounded : Icons.error_rounded,
            color: Colors.white, size: 18),
        const SizedBox(width: 8),
        Expanded(child: Text(r.ok ? 'Record deleted' : '${r.error}',
            style: const TextStyle(color: Colors.white))),
      ]),
      backgroundColor: r.ok ? _cfOrange : Colors.red.shade800,
    ));
    if (r.ok) {
      _selectZone({'id': _selectedZoneId!, 'name': _selectedZoneName});
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    if (_loadingZones) return const _LoadingView();
    if (_err != null) return _ErrorView(error: _err!, onRetry: _loadZones);

    return Column(
      children: [
        // zone chips
        if (_zones.isNotEmpty)
          SizedBox(
            height: 48,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              itemCount: _zones.length,
              itemBuilder: (_, i) {
                final z = _zones[i];
                final sel = z['id'] == _selectedZoneId;
                return GestureDetector(
                  onTap: () => _selectZone(z),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    margin: const EdgeInsets.only(right: 8),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 6),
                    decoration: BoxDecoration(
                      color: sel
                          ? _cfOrange.withOpacity(0.15)
                          : _cardBg,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: sel ? _cfOrange : ThemeProvider().current.surfaceColor,
                      ),
                    ),
                    child: Text(
                      z['name'] ?? '',
                      style: TextStyle(
                        color: sel ? _cfOrange : _textDim,
                        fontSize: 12.5,
                        fontWeight: sel
                            ? FontWeight.w700
                            : FontWeight.w400,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),

        // search + add
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 6, 14, 8),
          child: Row(
            children: [
              Expanded(
                child: _CfSearchField(
                  controller: _searchCtrl,
                  hint: 'Search records...',
                  onChanged: (v) => setState(() => _search = v),
                ),
              ),
              const SizedBox(width: 8),
              _CfIconBtn(
                icon: Icons.refresh_rounded,
                tooltip: 'Refresh',
                onTap: _selectedZoneId != null
                    ? () => _selectZone({'id': _selectedZoneId!, 'name': _selectedZoneName})
                    : null,
              ),
              const SizedBox(width: 6),
              _CfIconBtn(
                icon: Icons.add_rounded,
                tooltip: 'Add record',
                onTap: _selectedZoneId != null ? _addRecord : null,
              ),
            ],
          ),
        ),

        // records list
        Expanded(
          child: _loadingRecords
              ? const _LoadingView()
              : _filtered.isEmpty
                  ? _EmptyView(
                      icon: Icons.dns_rounded,
                      title: _search.isEmpty ? 'No DNS records' : 'No matches',
                      subtitle: _search.isEmpty
                          ? 'Tap + to add a record'
                          : 'Try different search term',
                    )
                  : ListView.builder(
                      padding:
                          const EdgeInsets.fromLTRB(14, 4, 14, 80),
                      itemCount: _filtered.length,
                      itemBuilder: (_, i) {
                        final rec = _filtered[i];
                        return _DnsRecordCard(
                          record: rec,
                          onEdit: () => _editRecord(rec),
                          onDelete: () => _deleteRecord(rec['id']),
                        );
                      },
                    ),
        ),
      ],
    );
  }
}

class _DnsRecordCard extends StatelessWidget {
  final Map record;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  const _DnsRecordCard({
    required this.record,
    required this.onEdit,
    required this.onDelete,
  });

  Color _typeColor(String type) {
    switch (type) {
      case 'A':          return Colors.greenAccent.shade400;
      case 'AAAA':       return Colors.tealAccent.shade400;
      case 'CNAME':      return Colors.blueAccent.shade200;
      case 'MX':         return Colors.purpleAccent.shade200;
      case 'TXT':        return Colors.orangeAccent.shade200;
      case 'NS':         return Colors.lightBlueAccent.shade200;
      case 'CAA':        return Colors.redAccent.shade200;
      case 'CERT':       return Colors.amberAccent.shade200;
      case 'DNSKEY':     return const Color(0xFF64FFDA);
      case 'DS':         return const Color(0xFFFFD740);
      case 'HTTPS':      return const Color(0xFF40C4FF);
      case 'LOC':        return const Color(0xFFB9F6CA);
      case 'NAPTR':      return const Color(0xFFE040FB);
      case 'OPENPGPKEY': return const Color(0xFFFFAB40);
      case 'PTR':        return const Color(0xFF69F0AE);
      case 'SMIMEA':     return const Color(0xFFFF6E40);
      case 'SRV':        return const Color(0xFF7C4DFF);
      case 'SSHFP':      return const Color(0xFF00E5FF);
      case 'SVCB':       return const Color(0xFFF4FF81);
      case 'TLSA':       return const Color(0xFFFF4081);
      case 'URI':        return const Color(0xFFCCFF90);
      default:           return _textMid;
    }
  }

  @override
  Widget build(BuildContext context) {
    final type    = record['type'] as String? ?? '';
    final name    = record['name'] as String? ?? '';
    final content = record['content'] as String? ?? '';
    final proxied = record['proxied'] == true;

    return Container(
      margin: EdgeInsets.only(bottom: 8),
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 11),
      decoration: BoxDecoration(
        color: _cardBg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: ThemeProvider().current.surfaceColor),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            padding: const EdgeInsets.symmetric(vertical: 4),
            decoration: BoxDecoration(
              color: _typeColor(type).withOpacity(0.12),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              type,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: _typeColor(type),
                fontSize: 11,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        name,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (proxied)
                      Container(
                        margin: const EdgeInsets.only(left: 4),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: _cfOrange.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: const Text(
                          'Proxied',
                          style: TextStyle(
                            color: _cfOrange,
                            fontSize: 9.5,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  content,
                  style: const TextStyle(
                    color: _textDim,
                    fontSize: 11.5,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.edit_rounded,
                color: _textMid, size: 18),
            onPressed: onEdit,
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(),
          ),
          const SizedBox(width: 8),
          IconButton(
            icon: Icon(Icons.delete_outline_rounded,
                color: Colors.red.shade400, size: 18),
            onPressed: onDelete,
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(),
          ),
        ],
      ),
    );
  }
}

// ── DNS Edit Screen ───────────────────────────────────────────────────────────
class _DnsEditScreen extends StatefulWidget {
  final CfApi api;
  final String zoneId;
  final String zoneName;
  final Map? existingRecord;
  const _DnsEditScreen({
    required this.api,
    required this.zoneId,
    required this.zoneName,
    this.existingRecord,
  });
  @override
  State<_DnsEditScreen> createState() => _DnsEditScreenState();
}

class _DnsEditScreenState extends State<_DnsEditScreen> {
  // ── Universal ─────────────────────────────────────────────────────────────
  final _nameCtrl    = TextEditingController();
  final _commentCtrl = TextEditingController();
  String _type    = 'A';
  bool   _proxied = false;
  bool   _busy    = false;

  static const _types = [
    'A', 'AAAA', 'CAA', 'CERT', 'CNAME', 'DNSKEY', 'DS', 'HTTPS',
    'LOC', 'MX', 'NAPTR', 'NS', 'OPENPGPKEY', 'PTR', 'SMIMEA',
    'SRV', 'SSHFP', 'SVCB', 'TLSA', 'TXT', 'URI',
  ];

  // ── A / AAAA / CNAME / NS / PTR / TXT / OPENPGPKEY ──────────────────────
  final _contentCtrl = TextEditingController();

  // ── MX ───────────────────────────────────────────────────────────────────
  final _mxPrioCtrl = TextEditingController(text: '10');

  // ── CAA ──────────────────────────────────────────────────────────────────
  int    _caaFlag = 0;
  String _caaTag  = 'issue';
  final  _caaValueCtrl = TextEditingController();

  // ── CERT ─────────────────────────────────────────────────────────────────
  final _certTypeCtrl   = TextEditingController(text: '1');
  final _certKeyTagCtrl = TextEditingController(text: '0');
  final _certAlgoCtrl   = TextEditingController(text: '8');
  final _certCertCtrl   = TextEditingController();

  // ── DNSKEY ───────────────────────────────────────────────────────────────
  final _dnskeyFlagsCtrl  = TextEditingController(text: '257');
  final _dnskeyProtoCtrl  = TextEditingController(text: '3');
  final _dnskeyAlgoCtrl   = TextEditingController(text: '13');
  final _dnskeyPubKeyCtrl = TextEditingController();

  // ── DS ───────────────────────────────────────────────────────────────────
  final _dsKeyTagCtrl     = TextEditingController(text: '0');
  final _dsAlgoCtrl       = TextEditingController(text: '8');
  final _dsDigestTypeCtrl = TextEditingController(text: '2');
  final _dsDigestCtrl     = TextEditingController();

  // ── HTTPS / SVCB ─────────────────────────────────────────────────────────
  final _svcPrioCtrl   = TextEditingController(text: '1');
  final _svcTargetCtrl = TextEditingController(text: '.');
  final _svcValueCtrl  = TextEditingController();

  // ── LOC ──────────────────────────────────────────────────────────────────
  final _locLatDegCtrl  = TextEditingController(text: '0');
  final _locLatMinCtrl  = TextEditingController(text: '0');
  final _locLatSecCtrl  = TextEditingController(text: '0');
  String _locLatDir     = 'N';
  final _locLongDegCtrl = TextEditingController(text: '0');
  final _locLongMinCtrl = TextEditingController(text: '0');
  final _locLongSecCtrl = TextEditingController(text: '0');
  String _locLongDir    = 'E';
  final _locAltCtrl     = TextEditingController(text: '0');
  final _locSizeCtrl    = TextEditingController(text: '1');
  final _locPHCtrl      = TextEditingController(text: '10000');
  final _locPVCtrl      = TextEditingController(text: '10');

  // ── NAPTR ────────────────────────────────────────────────────────────────
  final _naptrOrderCtrl = TextEditingController(text: '100');
  final _naptrPrefCtrl  = TextEditingController(text: '10');
  final _naptrFlagsCtrl = TextEditingController();
  final _naptrSvcCtrl   = TextEditingController();
  final _naptrRegexCtrl = TextEditingController();
  final _naptrReplCtrl  = TextEditingController();

  // ── SMIMEA ───────────────────────────────────────────────────────────────
  int   _smimeaUsage     = 0;
  int   _smimeaSelector  = 0;
  int   _smimeaMatchType = 1;
  final _smimeaCertCtrl  = TextEditingController();

  // ── SRV ──────────────────────────────────────────────────────────────────
  final  _srvSvcCtrl    = TextEditingController();
  String _srvProto      = '_tcp';
  final  _srvPrioCtrl   = TextEditingController(text: '10');
  final  _srvWeightCtrl = TextEditingController(text: '1');
  final  _srvPortCtrl   = TextEditingController(text: '443');
  final  _srvTargetCtrl = TextEditingController();

  // ── SSHFP ────────────────────────────────────────────────────────────────
  int   _sshfpAlgo = 2;
  int   _sshfpType = 2;
  final _sshfpFpCtrl = TextEditingController();

  // ── TLSA ─────────────────────────────────────────────────────────────────
  int   _tlsaUsage     = 3;
  int   _tlsaSelector  = 1;
  int   _tlsaMatchType = 1;
  final _tlsaCertCtrl  = TextEditingController();

  // ── URI ──────────────────────────────────────────────────────────────────
  final _uriPrioCtrl    = TextEditingController(text: '10');
  final _uriWeightCtrl  = TextEditingController(text: '1');
  final _uriContentCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    final r = widget.existingRecord;
    if (r == null) return;
    _type    = (r['type']    as String?) ?? 'A';
    _proxied = r['proxied'] == true;
    _nameCtrl.text    = (r['name']    as String?) ?? '';
    _commentCtrl.text = (r['comment'] as String?) ?? '';
    final d = r['data'] as Map?;
    final content = (r['content'] as String?) ?? '';
    switch (_type) {
      case 'A': case 'AAAA': case 'CNAME':
      case 'NS': case 'PTR': case 'TXT': case 'OPENPGPKEY':
        _contentCtrl.text = content; break;
      case 'MX':
        _contentCtrl.text = content;
        _mxPrioCtrl.text  = '${r['priority'] ?? 10}'; break;
      case 'CAA':
        _caaFlag = (d?['flags'] as num?)?.toInt() ?? 0;
        _caaTag  = (d?['tag']   as String?) ?? 'issue';
        _caaValueCtrl.text = (d?['value'] as String?) ?? ''; break;
      case 'CERT':
        _certTypeCtrl.text   = '${d?['type'] ?? 1}';
        _certKeyTagCtrl.text = '${d?['key_tag'] ?? 0}';
        _certAlgoCtrl.text   = '${d?['algorithm'] ?? 8}';
        _certCertCtrl.text   = (d?['certificate'] as String?) ?? content; break;
      case 'DNSKEY':
        _dnskeyFlagsCtrl.text  = '${d?['flags'] ?? 257}';
        _dnskeyProtoCtrl.text  = '${d?['protocol'] ?? 3}';
        _dnskeyAlgoCtrl.text   = '${d?['algorithm'] ?? 13}';
        _dnskeyPubKeyCtrl.text = (d?['public_key'] as String?) ?? content; break;
      case 'DS':
        _dsKeyTagCtrl.text     = '${d?['key_tag'] ?? 0}';
        _dsAlgoCtrl.text       = '${d?['algorithm'] ?? 8}';
        _dsDigestTypeCtrl.text = '${d?['digest_type'] ?? 2}';
        _dsDigestCtrl.text     = (d?['digest'] as String?) ?? content; break;
      case 'HTTPS': case 'SVCB':
        _svcPrioCtrl.text   = '${d?['priority'] ?? 1}';
        _svcTargetCtrl.text = (d?['target'] as String?) ?? '.';
        _svcValueCtrl.text  = (d?['value']  as String?) ?? ''; break;
      case 'LOC':
        _locLatDegCtrl.text  = '${d?['lat_degrees']  ?? 0}';
        _locLatMinCtrl.text  = '${d?['lat_minutes']  ?? 0}';
        _locLatSecCtrl.text  = '${d?['lat_seconds']  ?? 0}';
        _locLatDir           = (d?['lat_direction']  as String?) ?? 'N';
        _locLongDegCtrl.text = '${d?['long_degrees'] ?? 0}';
        _locLongMinCtrl.text = '${d?['long_minutes'] ?? 0}';
        _locLongSecCtrl.text = '${d?['long_seconds'] ?? 0}';
        _locLongDir          = (d?['long_direction'] as String?) ?? 'E';
        _locAltCtrl.text     = '${d?['altitude']       ?? 0}';
        _locSizeCtrl.text    = '${d?['size']           ?? 1}';
        _locPHCtrl.text      = '${d?['precision_horiz'] ?? 10000}';
        _locPVCtrl.text      = '${d?['precision_vert']  ?? 10}'; break;
      case 'NAPTR':
        _naptrOrderCtrl.text = '${d?['order']      ?? 100}';
        _naptrPrefCtrl.text  = '${d?['preference'] ?? 10}';
        _naptrFlagsCtrl.text = (d?['flags']       as String?) ?? '';
        _naptrSvcCtrl.text   = (d?['service']     as String?) ?? '';
        _naptrRegexCtrl.text = (d?['regex']       as String?) ?? '';
        _naptrReplCtrl.text  = (d?['replacement'] as String?) ?? ''; break;
      case 'SMIMEA':
        _smimeaUsage     = (d?['usage']         as num?)?.toInt() ?? 0;
        _smimeaSelector  = (d?['selector']      as num?)?.toInt() ?? 0;
        _smimeaMatchType = (d?['matching_type'] as num?)?.toInt() ?? 1;
        _smimeaCertCtrl.text = (d?['certificate'] as String?) ?? content; break;
      case 'SRV':
        _srvSvcCtrl.text    = (d?['service']  as String?) ?? '';
        _srvProto           = (d?['proto']    as String?) ?? '_tcp';
        _srvPrioCtrl.text   = '${d?['priority'] ?? 10}';
        _srvWeightCtrl.text = '${d?['weight']   ?? 1}';
        _srvPortCtrl.text   = '${d?['port']     ?? 443}';
        _srvTargetCtrl.text = (d?['target'] as String?) ?? ''; break;
      case 'SSHFP':
        _sshfpAlgo       = (d?['algorithm'] as num?)?.toInt() ?? 2;
        _sshfpType       = (d?['type']      as num?)?.toInt() ?? 2;
        _sshfpFpCtrl.text = (d?['fingerprint'] as String?) ?? content; break;
      case 'TLSA':
        _tlsaUsage       = (d?['usage']         as num?)?.toInt() ?? 3;
        _tlsaSelector    = (d?['selector']      as num?)?.toInt() ?? 1;
        _tlsaMatchType   = (d?['matching_type'] as num?)?.toInt() ?? 1;
        _tlsaCertCtrl.text = (d?['certificate'] as String?) ?? content; break;
      case 'URI':
        _uriPrioCtrl.text    = '${d?['priority'] ?? 10}';
        _uriWeightCtrl.text  = '${d?['weight']   ?? 1}';
        _uriContentCtrl.text = (d?['content'] as String?) ?? content; break;
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose(); _commentCtrl.dispose();
    _contentCtrl.dispose(); _mxPrioCtrl.dispose();
    _caaValueCtrl.dispose();
    _certTypeCtrl.dispose(); _certKeyTagCtrl.dispose();
    _certAlgoCtrl.dispose(); _certCertCtrl.dispose();
    _dnskeyFlagsCtrl.dispose(); _dnskeyProtoCtrl.dispose();
    _dnskeyAlgoCtrl.dispose(); _dnskeyPubKeyCtrl.dispose();
    _dsKeyTagCtrl.dispose(); _dsAlgoCtrl.dispose();
    _dsDigestTypeCtrl.dispose(); _dsDigestCtrl.dispose();
    _svcPrioCtrl.dispose(); _svcTargetCtrl.dispose(); _svcValueCtrl.dispose();
    _locLatDegCtrl.dispose(); _locLatMinCtrl.dispose(); _locLatSecCtrl.dispose();
    _locLongDegCtrl.dispose(); _locLongMinCtrl.dispose(); _locLongSecCtrl.dispose();
    _locAltCtrl.dispose(); _locSizeCtrl.dispose();
    _locPHCtrl.dispose(); _locPVCtrl.dispose();
    _naptrOrderCtrl.dispose(); _naptrPrefCtrl.dispose();
    _naptrFlagsCtrl.dispose(); _naptrSvcCtrl.dispose();
    _naptrRegexCtrl.dispose(); _naptrReplCtrl.dispose();
    _smimeaCertCtrl.dispose();
    _srvSvcCtrl.dispose(); _srvPrioCtrl.dispose();
    _srvWeightCtrl.dispose(); _srvPortCtrl.dispose(); _srvTargetCtrl.dispose();
    _sshfpFpCtrl.dispose(); _tlsaCertCtrl.dispose();
    _uriPrioCtrl.dispose(); _uriWeightCtrl.dispose(); _uriContentCtrl.dispose();
    super.dispose();
  }

  bool get _canProxy => ['A', 'AAAA', 'CNAME'].contains(_type);

  String _typeDesc() {
    switch (_type) {
      case 'A':          return '[name] points to an IPv4 address and traffic can be proxied through Cloudflare.';
      case 'AAAA':       return '[name] points to an IPv6 address and traffic can be proxied through Cloudflare.';
      case 'CNAME':      return '[name] is an alias of another domain name and traffic can be proxied through Cloudflare.';
      case 'MX':         return '[name] mail is handled by [priority] [mail server].';
      case 'TXT':        return '[name] has the text record [content]. Used for SPF, DKIM, DMARC, and domain verification.';
      case 'NS':         return '[name] is delegated to the name server [content].';
      case 'PTR':        return 'Reverse DNS lookup: [name] maps to [domain name].';
      case 'CAA':        return 'Restricts which certificate authorities may issue certificates for [name].';
      case 'CERT':       return 'Stores certificates and related information (PKIX, SPKI, PGP, etc.) in the DNS.';
      case 'DNSKEY':     return 'Contains a public signing key used for DNSSEC validation in the zone.';
      case 'DS':         return 'Contains the hash of a DNSKEY record, used to authenticate DNSSEC delegation.';
      case 'HTTPS':      return 'Provides HTTPS service endpoint information (alpn, ipv4hint, ipv6hint, etc.) for [name].';
      case 'LOC':        return 'Specifies a geographic location (latitude, longitude, altitude) associated with [name].';
      case 'NAPTR':      return 'Name Authority Pointer: supports dynamic delegation for URIs and services at [name].';
      case 'OPENPGPKEY': return 'Stores an OpenPGP public key for email encryption associated with [name].';
      case 'SMIMEA':     return 'Associates an S/MIME certificate with an email address for authentication at [name].';
      case 'SRV':        return 'Specifies the host and port for a specific service (e.g. SIP, XMPP) at [name].';
      case 'SSHFP':      return 'Stores SSH public key fingerprints to allow clients to verify the server identity at [name].';
      case 'SVCB':       return 'Service Binding: provides service endpoint parameters and alternative authorities for [name].';
      case 'TLSA':       return 'Associates a TLS server certificate or public key with [name] using DANE.';
      case 'URI':        return 'Maps a hostname to one or more URIs that host a particular service at [name].';
      default:           return '[name] has a $_type record.';
    }
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        const Icon(Icons.error_rounded, color: Colors.white, size: 18),
        const SizedBox(width: 8),
        Expanded(child: Text(msg, style: const TextStyle(color: Colors.white))),
      ]),
      backgroundColor: Colors.red.shade800,
    ));
  }

  Future<void> _save() async {
    final name = _nameCtrl.text.trim();
    if (name.isEmpty) { _showError('Name is required'); return; }

    final payload = <String, dynamic>{'type': _type, 'name': name, 'ttl': 1, 'proxied': false};
    final cmt = _commentCtrl.text.trim();
    if (cmt.isNotEmpty) payload['comment'] = cmt;

    switch (_type) {
      case 'A':
      case 'AAAA':
        {
          final v = _contentCtrl.text.trim();
          if (v.isEmpty) { _showError('IP address is required'); return; }
          payload['content'] = v; payload['proxied'] = _proxied;
        }
        break;
      case 'CNAME':
        {
          final v = _contentCtrl.text.trim();
          if (v.isEmpty) { _showError('Target is required'); return; }
          payload['content'] = v; payload['proxied'] = _proxied;
        }
        break;
      case 'NS':
        {
          final v = _contentCtrl.text.trim();
          if (v.isEmpty) { _showError('Name server is required'); return; }
          payload['content'] = v;
        }
        break;
      case 'PTR':
        {
          final v = _contentCtrl.text.trim();
          if (v.isEmpty) { _showError('Domain name is required'); return; }
          payload['content'] = v;
        }
        break;
      case 'TXT':
        {
          final v = _contentCtrl.text.trim();
          if (v.isEmpty) { _showError('Content is required'); return; }
          payload['content'] = v;
        }
        break;
      case 'OPENPGPKEY':
        {
          final v = _contentCtrl.text.trim();
          if (v.isEmpty) { _showError('Public key is required'); return; }
          payload['content'] = v;
        }
        break;
      case 'MX':
        {
          final v = _contentCtrl.text.trim();
          if (v.isEmpty) { _showError('Mail server is required'); return; }
          payload['content'] = v;
          payload['priority'] = int.tryParse(_mxPrioCtrl.text) ?? 10;
        }
        break;
      case 'CAA':
        {
          final v = _caaValueCtrl.text.trim();
          if (v.isEmpty) { _showError('CA domain is required'); return; }
          payload['data'] = {'flags': _caaFlag, 'tag': _caaTag, 'value': v};
        }
        break;
      case 'CERT':
        payload['data'] = {
          'type':        int.tryParse(_certTypeCtrl.text)   ?? 1,
          'key_tag':     int.tryParse(_certKeyTagCtrl.text) ?? 0,
          'algorithm':   int.tryParse(_certAlgoCtrl.text)   ?? 8,
          'certificate': _certCertCtrl.text.trim(),
        };
        break;
      case 'DNSKEY':
        payload['data'] = {
          'flags':      int.tryParse(_dnskeyFlagsCtrl.text) ?? 257,
          'protocol':   int.tryParse(_dnskeyProtoCtrl.text) ?? 3,
          'algorithm':  int.tryParse(_dnskeyAlgoCtrl.text)  ?? 13,
          'public_key': _dnskeyPubKeyCtrl.text.trim(),
        };
        break;
      case 'DS':
        payload['data'] = {
          'key_tag':     int.tryParse(_dsKeyTagCtrl.text)     ?? 0,
          'algorithm':   int.tryParse(_dsAlgoCtrl.text)       ?? 8,
          'digest_type': int.tryParse(_dsDigestTypeCtrl.text) ?? 2,
          'digest':      _dsDigestCtrl.text.trim(),
        };
        break;
      case 'HTTPS':
      case 'SVCB':
        payload['data'] = {
          'priority': int.tryParse(_svcPrioCtrl.text) ?? 1,
          'target':   _svcTargetCtrl.text.trim().isEmpty ? '.' : _svcTargetCtrl.text.trim(),
          'value':    _svcValueCtrl.text.trim(),
        };
        break;
      case 'LOC':
        payload['data'] = {
          'lat_degrees':    int.tryParse(_locLatDegCtrl.text)  ?? 0,
          'lat_minutes':    int.tryParse(_locLatMinCtrl.text)  ?? 0,
          'lat_seconds':    double.tryParse(_locLatSecCtrl.text) ?? 0.0,
          'lat_direction':  _locLatDir,
          'long_degrees':   int.tryParse(_locLongDegCtrl.text) ?? 0,
          'long_minutes':   int.tryParse(_locLongMinCtrl.text) ?? 0,
          'long_seconds':   double.tryParse(_locLongSecCtrl.text) ?? 0.0,
          'long_direction': _locLongDir,
          'altitude':       double.tryParse(_locAltCtrl.text)  ?? 0.0,
          'size':           double.tryParse(_locSizeCtrl.text) ?? 1.0,
          'precision_horiz': double.tryParse(_locPHCtrl.text)  ?? 10000.0,
          'precision_vert':  double.tryParse(_locPVCtrl.text)  ?? 10.0,
        };
        break;
      case 'NAPTR':
        payload['data'] = {
          'order':       int.tryParse(_naptrOrderCtrl.text) ?? 100,
          'preference':  int.tryParse(_naptrPrefCtrl.text)  ?? 10,
          'flags':       _naptrFlagsCtrl.text.trim(),
          'service':     _naptrSvcCtrl.text.trim(),
          'regex':       _naptrRegexCtrl.text.trim(),
          'replacement': _naptrReplCtrl.text.trim(),
        };
        break;
      case 'SMIMEA':
        {
          final cert = _smimeaCertCtrl.text.trim();
          if (cert.isEmpty) { _showError('Certificate is required'); return; }
          payload['data'] = {
            'usage':         _smimeaUsage,
            'selector':      _smimeaSelector,
            'matching_type': _smimeaMatchType,
            'certificate':   cert,
          };
        }
        break;
      case 'SRV':
        {
          final svc = _srvSvcCtrl.text.trim();
          if (svc.isEmpty) { _showError('Service is required'); return; }
          payload['data'] = {
            'service':  svc.startsWith('_') ? svc : '_$svc',
            'proto':    _srvProto,
            'name':     name,
            'priority': int.tryParse(_srvPrioCtrl.text)   ?? 10,
            'weight':   int.tryParse(_srvWeightCtrl.text) ?? 1,
            'port':     int.tryParse(_srvPortCtrl.text)   ?? 443,
            'target':   _srvTargetCtrl.text.trim(),
          };
        }
        break;
      case 'SSHFP':
        {
          final fp = _sshfpFpCtrl.text.trim();
          if (fp.isEmpty) { _showError('Fingerprint is required'); return; }
          payload['data'] = {'algorithm': _sshfpAlgo, 'type': _sshfpType, 'fingerprint': fp};
        }
        break;
      case 'TLSA':
        {
          final cert = _tlsaCertCtrl.text.trim();
          if (cert.isEmpty) { _showError('Certificate/hash is required'); return; }
          payload['data'] = {
            'usage':         _tlsaUsage,
            'selector':      _tlsaSelector,
            'matching_type': _tlsaMatchType,
            'certificate':   cert,
          };
        }
        break;
      case 'URI':
        {
          final uri = _uriContentCtrl.text.trim();
          if (uri.isEmpty) { _showError('URI is required'); return; }
          payload['data'] = {
            'content':  uri,
            'priority': int.tryParse(_uriPrioCtrl.text)   ?? 10,
            'weight':   int.tryParse(_uriWeightCtrl.text) ?? 1,
          };
        }
        break;
    }

    setState(() => _busy = true);
    final CfResult r;
    if (widget.existingRecord != null) {
      r = await widget.api.updateDNSRecord(widget.zoneId, widget.existingRecord!['id'], payload);
    } else {
      r = await widget.api.createDNSRecord(widget.zoneId, payload);
    }
    if (!mounted) return;
    setState(() => _busy = false);
    if (r.ok) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Row(children: [
          const Icon(Icons.check_circle_rounded, color: Colors.white, size: 18),
          const SizedBox(width: 8),
          Expanded(child: Text(widget.existingRecord != null ? 'Record updated!' : 'Record created!',
              style: const TextStyle(color: Colors.white))),
        ]),
        backgroundColor: _cfOrange,
      ));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Row(children: [
          const Icon(Icons.error_rounded, color: Colors.white, size: 18),
          const SizedBox(width: 8),
          Expanded(child: Text('${r.error}', style: const TextStyle(color: Colors.white))),
        ]),
        backgroundColor: Colors.red.shade800,
      ));
    }
  }

  Widget _field(TextEditingController ctrl, String hint, {
    TextInputType? kb, int maxLines = 1, int? maxLength,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: _cardBg, borderRadius: BorderRadius.circular(10),
        border: Border.all(color: ThemeProvider().current.surfaceColor),
      ),
      child: TextField(
        controller: ctrl, keyboardType: kb,
        maxLines: maxLines, maxLength: maxLength,
        style: const TextStyle(color: Colors.white, fontSize: 14),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(color: _textDim.withOpacity(0.45), fontSize: 13),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
          counterStyle: TextStyle(color: _textDim.withOpacity(0.4), fontSize: 10),
        ),
      ),
    );
  }

  Widget _lbl(String t) => Padding(
    padding: const EdgeInsets.only(bottom: 6),
    child: Text(t, style: const TextStyle(color: _textMid, fontSize: 13, fontWeight: FontWeight.w500)),
  );

  Widget _numField(TextEditingController ctrl, String hint) =>
      _field(ctrl, hint, kb: const TextInputType.numberWithOptions(decimal: true));

  Widget _inlineDropdown<T>({
    required T value,
    required List<DropdownMenuItem<T>> items,
    required void Function(T?) onChanged,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: _cardBg, borderRadius: BorderRadius.circular(10),
        border: Border.all(color: ThemeProvider().current.surfaceColor),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
      child: DropdownButton<T>(
        value: value, isExpanded: true,
        dropdownColor: const Color(0xFF1a1a2e),
        underline: const SizedBox.shrink(),
        icon: const Icon(Icons.arrow_drop_down, color: _textDim, size: 20),
        style: const TextStyle(color: Colors.white, fontSize: 13),
        onChanged: onChanged, items: items,
      ),
    );
  }

  Widget _simpleContent(String label, String hint, {int maxLines = 1}) =>
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _lbl(label), _field(_contentCtrl, hint, maxLines: maxLines),
      ]);

  Widget _mxFields() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    _lbl('Mail server (required)'),
    _field(_contentCtrl, 'mail.example.com'),
    const SizedBox(height: 16),
    _lbl('Priority'),
    _numField(_mxPrioCtrl, '10'),
  ]);

  Widget _caaFields() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _lbl('Tag'),
        _inlineDropdown<String>(
          value: _caaTag,
          items: const [
            DropdownMenuItem(value: 'issue',     child: Text('issue')),
            DropdownMenuItem(value: 'issuewild', child: Text('issuewild')),
            DropdownMenuItem(value: 'iodef',     child: Text('iodef')),
          ],
          onChanged: (v) => setState(() => _caaTag = v ?? 'issue'),
        ),
      ])),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _lbl('Flag'),
        _inlineDropdown<int>(
          value: _caaFlag,
          items: const [
            DropdownMenuItem(value: 0,   child: Text('0 – non-critical')),
            DropdownMenuItem(value: 128, child: Text('128 – critical')),
          ],
          onChanged: (v) => setState(() => _caaFlag = v ?? 0),
        ),
      ])),
    ]),
    const SizedBox(height: 16),
    _lbl('CA domain (required)'),
    _field(_caaValueCtrl, 'letsencrypt.org'),
  ]);

  Widget _certFields() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Type'), _numField(_certTypeCtrl, '1')])),
      const SizedBox(width: 8),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Key Tag'), _numField(_certKeyTagCtrl, '0')])),
      const SizedBox(width: 8),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Algorithm'), _numField(_certAlgoCtrl, '8')])),
    ]),
    const SizedBox(height: 16),
    _lbl('Certificate (base64)'),
    _field(_certCertCtrl, 'Base64-encoded certificate', maxLines: 4),
  ]);

  Widget _dnskeyFields() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Flags'), _numField(_dnskeyFlagsCtrl, '257')])),
      const SizedBox(width: 8),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Protocol'), _numField(_dnskeyProtoCtrl, '3')])),
      const SizedBox(width: 8),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Algorithm'), _numField(_dnskeyAlgoCtrl, '13')])),
    ]),
    const SizedBox(height: 16),
    _lbl('Public key (base64)'),
    _field(_dnskeyPubKeyCtrl, 'Base64-encoded public key', maxLines: 3),
  ]);

  Widget _dsFields() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Key Tag'), _numField(_dsKeyTagCtrl, '0')])),
      const SizedBox(width: 8),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Algorithm'), _numField(_dsAlgoCtrl, '8')])),
      const SizedBox(width: 8),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Digest Type'), _numField(_dsDigestTypeCtrl, '2')])),
    ]),
    const SizedBox(height: 16),
    _lbl('Digest (hex)'),
    _field(_dsDigestCtrl, 'Hexadecimal digest string', maxLines: 2),
  ]);

  Widget _svcFields() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [
      SizedBox(width: 90, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Priority'), _numField(_svcPrioCtrl, '1')])),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Target (. for same origin)'), _field(_svcTargetCtrl, '.')])),
    ]),
    const SizedBox(height: 16),
    _lbl('Parameters (SvcParams)'),
    _field(_svcValueCtrl, 'alpn="h3,h2" ipv4hint="1.2.3.4"', maxLines: 2),
  ]);

  Widget _locFields() {
    Widget dirDrop(List<String> opts, String val, void Function(String) set) =>
        _inlineDropdown<String>(
          value: val, onChanged: (v) => setState(() => set(v!)),
          items: opts.map((o) => DropdownMenuItem(value: o, child: Text(o))).toList(),
        );
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      _lbl('Latitude'),
      Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Degrees'), _numField(_locLatDegCtrl, '0')])),
        const SizedBox(width: 6),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Minutes'), _numField(_locLatMinCtrl, '0')])),
        const SizedBox(width: 6),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Seconds'), _numField(_locLatSecCtrl, '0')])),
        const SizedBox(width: 6),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Dir'), dirDrop(['N','S'], _locLatDir, (v) { _locLatDir = v; })])),
      ]),
      const SizedBox(height: 12),
      _lbl('Longitude'),
      Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Degrees'), _numField(_locLongDegCtrl, '0')])),
        const SizedBox(width: 6),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Minutes'), _numField(_locLongMinCtrl, '0')])),
        const SizedBox(width: 6),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Seconds'), _numField(_locLongSecCtrl, '0')])),
        const SizedBox(width: 6),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Dir'), dirDrop(['E','W'], _locLongDir, (v) { _locLongDir = v; })])),
      ]),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Altitude (m)'), _numField(_locAltCtrl, '0')])),
        const SizedBox(width: 6),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Size (m)'), _numField(_locSizeCtrl, '1')])),
        const SizedBox(width: 6),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('H Prec'), _numField(_locPHCtrl, '10000')])),
        const SizedBox(width: 6),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('V Prec'), _numField(_locPVCtrl, '10')])),
      ]),
    ]);
  }

  Widget _naptrFields() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Order'), _numField(_naptrOrderCtrl, '100')])),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Preference'), _numField(_naptrPrefCtrl, '10')])),
    ]),
    const SizedBox(height: 16),
    Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Flags'), _field(_naptrFlagsCtrl, 'S, A, U, or P')])),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Service'), _field(_naptrSvcCtrl, 'SIP+D2U')])),
    ]),
    const SizedBox(height: 16),
    _lbl('Regex'),
    _field(_naptrRegexCtrl, '!^.*\$!sip:info@example.com!'),
    const SizedBox(height: 16),
    _lbl('Replacement'),
    _field(_naptrReplCtrl, '_sip._udp.example.com'),
  ]);

  List<DropdownMenuItem<int>> _usageItems() => const [
    DropdownMenuItem(value: 0, child: Text('0 – CA constraint (PKIX-TA)')),
    DropdownMenuItem(value: 1, child: Text('1 – Service cert (PKIX-EE)')),
    DropdownMenuItem(value: 2, child: Text('2 – Trust anchor (DANE-TA)')),
    DropdownMenuItem(value: 3, child: Text('3 – Domain cert (DANE-EE)')),
  ];

  List<DropdownMenuItem<int>> _selectorItems() => const [
    DropdownMenuItem(value: 0, child: Text('0 – Full certificate')),
    DropdownMenuItem(value: 1, child: Text('1 – SubjectPublicKeyInfo')),
  ];

  List<DropdownMenuItem<int>> _matchTypeItems() => const [
    DropdownMenuItem(value: 0, child: Text('0 – Exact match')),
    DropdownMenuItem(value: 1, child: Text('1 – SHA-256')),
    DropdownMenuItem(value: 2, child: Text('2 – SHA-512')),
  ];

  Widget _smimeaFields() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    _lbl('Usage'),
    _inlineDropdown<int>(value: _smimeaUsage, items: _usageItems(), onChanged: (v) => setState(() => _smimeaUsage = v ?? 0)),
    const SizedBox(height: 12),
    _lbl('Selector'),
    _inlineDropdown<int>(value: _smimeaSelector, items: _selectorItems(), onChanged: (v) => setState(() => _smimeaSelector = v ?? 0)),
    const SizedBox(height: 12),
    _lbl('Matching Type'),
    _inlineDropdown<int>(value: _smimeaMatchType, items: _matchTypeItems(), onChanged: (v) => setState(() => _smimeaMatchType = v ?? 1)),
    const SizedBox(height: 16),
    _lbl('Certificate (hex or base64)'),
    _field(_smimeaCertCtrl, 'Certificate data', maxLines: 3),
  ]);

  Widget _srvFields() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _lbl('Service (required)'),
        _field(_srvSvcCtrl, '_sip'),
      ])),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _lbl('Protocol'),
        _inlineDropdown<String>(
          value: _srvProto,
          items: const [
            DropdownMenuItem(value: '_tcp',  child: Text('TCP')),
            DropdownMenuItem(value: '_udp',  child: Text('UDP')),
            DropdownMenuItem(value: '_tls',  child: Text('TLS')),
            DropdownMenuItem(value: '_sctp', child: Text('SCTP')),
          ],
          onChanged: (v) => setState(() => _srvProto = v ?? '_tcp'),
        ),
      ])),
    ]),
    const SizedBox(height: 16),
    Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Priority'), _numField(_srvPrioCtrl, '10')])),
      const SizedBox(width: 8),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Weight'), _numField(_srvWeightCtrl, '1')])),
      const SizedBox(width: 8),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Port'), _numField(_srvPortCtrl, '443')])),
    ]),
    const SizedBox(height: 16),
    _lbl('Target'),
    _field(_srvTargetCtrl, 'sip.example.com'),
  ]);

  Widget _sshfpFields() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _lbl('Algorithm'),
        _inlineDropdown<int>(
          value: _sshfpAlgo,
          items: const [
            DropdownMenuItem(value: 1, child: Text('1 – RSA')),
            DropdownMenuItem(value: 2, child: Text('2 – DSA')),
            DropdownMenuItem(value: 3, child: Text('3 – ECDSA')),
            DropdownMenuItem(value: 4, child: Text('4 – Ed25519')),
          ],
          onChanged: (v) => setState(() => _sshfpAlgo = v ?? 2),
        ),
      ])),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _lbl('Hash type'),
        _inlineDropdown<int>(
          value: _sshfpType,
          items: const [
            DropdownMenuItem(value: 1, child: Text('1 – SHA-1')),
            DropdownMenuItem(value: 2, child: Text('2 – SHA-256')),
          ],
          onChanged: (v) => setState(() => _sshfpType = v ?? 2),
        ),
      ])),
    ]),
    const SizedBox(height: 16),
    _lbl('Fingerprint (hex)'),
    _field(_sshfpFpCtrl, 'SHA-256 hex fingerprint', maxLines: 2),
  ]);

  Widget _tlsaFields() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    _lbl('Usage'),
    _inlineDropdown<int>(value: _tlsaUsage, items: _usageItems(), onChanged: (v) => setState(() => _tlsaUsage = v ?? 3)),
    const SizedBox(height: 12),
    _lbl('Selector'),
    _inlineDropdown<int>(value: _tlsaSelector, items: _selectorItems(), onChanged: (v) => setState(() => _tlsaSelector = v ?? 1)),
    const SizedBox(height: 12),
    _lbl('Matching Type'),
    _inlineDropdown<int>(value: _tlsaMatchType, items: _matchTypeItems(), onChanged: (v) => setState(() => _tlsaMatchType = v ?? 1)),
    const SizedBox(height: 16),
    _lbl('Certificate / hash (hex)'),
    _field(_tlsaCertCtrl, 'SHA-256 hex digest of the certificate', maxLines: 3),
  ]);

  Widget _uriFields() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Priority'), _numField(_uriPrioCtrl, '10')])),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_lbl('Weight'), _numField(_uriWeightCtrl, '1')])),
    ]),
    const SizedBox(height: 16),
    _lbl('Target URI (required)'),
    _field(_uriContentCtrl, 'https://example.com/', maxLines: 2),
  ]);

  Widget _buildTypeFields() {
    switch (_type) {
      case 'A':          return _simpleContent('IPv4 address (required)', '192.0.2.1');
      case 'AAAA':       return _simpleContent('IPv6 address (required)', '2001:db8::1');
      case 'CNAME':      return _simpleContent('Target (required)', 'target.example.com');
      case 'NS':         return _simpleContent('Name server (required)', 'ns1.example.com');
      case 'PTR':        return _simpleContent('Domain name (required)', 'example.com');
      case 'TXT':        return _simpleContent('Content (required)', 'v=spf1 include:example.com ~all', maxLines: 4);
      case 'OPENPGPKEY': return _simpleContent('Public key (base64, required)', '', maxLines: 4);
      case 'MX':         return _mxFields();
      case 'CAA':        return _caaFields();
      case 'CERT':       return _certFields();
      case 'DNSKEY':     return _dnskeyFields();
      case 'DS':         return _dsFields();
      case 'HTTPS':
      case 'SVCB':       return _svcFields();
      case 'LOC':        return _locFields();
      case 'NAPTR':      return _naptrFields();
      case 'SMIMEA':     return _smimeaFields();
      case 'SRV':        return _srvFields();
      case 'SSHFP':      return _sshfpFields();
      case 'TLSA':       return _tlsaFields();
      case 'URI':        return _uriFields();
      default:           return _simpleContent('Content (required)', '');
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.existingRecord != null;
    return Scaffold(
      backgroundColor: ThemeProvider().current.scaffoldBg,
      appBar: AppBar(
        backgroundColor: _cardBg,
        title: Text(isEdit ? 'Edit DNS Record' : 'Add DNS Record',
            style: const TextStyle(color: Colors.white, fontSize: 15)),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _textDim, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              decoration: BoxDecoration(color: _cardBg, borderRadius: BorderRadius.circular(10)),
              child: Text(_typeDesc(), style: const TextStyle(color: _textMid, fontSize: 13, height: 1.5)),
            ),
            const SizedBox(height: 20),
            _lbl('Type'),
            Container(
              decoration: BoxDecoration(
                color: _cardBg, borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _cfOrange, width: 1.5),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
              child: DropdownButton<String>(
                value: _type, isExpanded: true,
                dropdownColor: const Color(0xFF1a1a2e),
                underline: const SizedBox.shrink(),
                icon: const Icon(Icons.arrow_drop_down, color: _textDim),
                style: const TextStyle(color: Colors.white, fontSize: 15),
                onChanged: (v) {
                  if (v != null) setState(() { _type = v; if (!_canProxy) _proxied = false; });
                },
                items: _types.map((t) => DropdownMenuItem(value: t, child: Text(t))).toList(),
              ),
            ),
            const SizedBox(height: 20),
            _lbl('Name (required)'),
            _field(_nameCtrl, ''),
            const Padding(
              padding: EdgeInsets.only(top: 4),
              child: Text('Use @ for root', style: TextStyle(color: _textDim, fontSize: 11)),
            ),
            const SizedBox(height: 16),
            _buildTypeFields(),
            if (_canProxy) ...[
              const SizedBox(height: 20),
              _lbl('Proxy status'),
              Row(children: [
                Switch(value: _proxied, onChanged: (v) => setState(() => _proxied = v), activeColor: _cfOrange),
                const SizedBox(width: 8),
                Icon(Icons.cloud, color: _proxied ? _cfOrange : _textDim, size: 24),
              ]),
            ],
            SizedBox(height: 20),
            _lbl('TTL'),
            Divider(color: ThemeProvider().current.surfaceColor),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 10),
              child: Text('Auto', style: TextStyle(color: Colors.white, fontSize: 15)),
            ),
            Divider(color: ThemeProvider().current.surfaceColor),
            const SizedBox(height: 24),
            const Text('Record Attributes',
                style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            const Text(
              'The information provided here will not impact DNS record '
              'resolution and is only meant for your reference.',
              style: TextStyle(color: _textDim, fontSize: 12, height: 1.45),
            ),
            const SizedBox(height: 14),
            _lbl('Comment'),
            _field(_commentCtrl, 'Enter your comment here (up to 100 chars)', maxLength: 100),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _busy ? null : _save,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1D4ED8),
                  disabledBackgroundColor: _cardBg,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: _busy
                    ? const SizedBox(width: 20, height: 20,
                        child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : const Text('Save',
                        style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600)),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF374151),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: const Text('Cancel',
                    style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600)),
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// PAGES TAB
// ═════════════════════════════════════════════════════════════════════════════
class _PagesTab extends StatefulWidget {
  final CfApi api;
  final String accountId;
  const _PagesTab({required this.api, required this.accountId});
  @override
  State<_PagesTab> createState() => _PagesTabState();
}

class _PagesTabState extends State<_PagesTab>
    with AutomaticKeepAliveClientMixin {
  List<Map> _projects = [];
  bool _loading = true;
  String? _err;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.listPagesProjects(widget.accountId);
    if (!mounted) return;
    if (!r.ok) {
      setState(() { _loading = false; _err = r.error; });
      return;
    }
    setState(() {
      _projects = List<Map>.from(r.data['result'] ?? []);
      _loading  = false;
    });
  }

  Future<void> _createProject() async {
    final ctrl = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (_) => _TextInputDialog(
        title: 'New Pages Project',
        hint: 'my-website',
        label: 'Project name (lowercase, hyphens only)',
        controller: ctrl,
      ),
    );
    if (name == null || name.trim().isEmpty) return;
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const _BusyDialog(message: 'Creating project...'),
    );
    final r = await widget.api
        .createPagesProject(widget.accountId, name.trim().toLowerCase());
    if (!mounted) return;
    Navigator.pop(context);
    if (r.ok) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Row(children: [
          const Icon(Icons.check_circle_rounded, color: Colors.white, size: 18),
          const SizedBox(width: 8),
          const Expanded(child: Text('Project created!', style: TextStyle(color: Colors.white))),
        ]),
        backgroundColor: _cfOrange,
      ));
      _load();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Row(children: [
          const Icon(Icons.error_rounded, color: Colors.white, size: 18),
          const SizedBox(width: 8),
          Expanded(child: Text('${r.error}', style: const TextStyle(color: Colors.white))),
        ]),
        backgroundColor: Colors.red.shade800,
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 4),
          child: Row(
            children: [
              const Text(
                'Pages Projects',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const Spacer(),
              _CfIconBtn(
                  icon: Icons.refresh_rounded,
                  tooltip: 'Refresh',
                  onTap: _load),
              const SizedBox(width: 6),
              _CfIconBtn(
                  icon: Icons.add_rounded,
                  tooltip: 'Create project',
                  onTap: _createProject),
            ],
          ),
        ),
        if (!_loading && _err == null)
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 6),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: _cfOrange.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: _cfOrange.withOpacity(0.35)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.web_rounded, color: _cfOrange, size: 13),
                      const SizedBox(width: 5),
                      Text(
                        'Total pages: ${_projects.length}',
                        style: const TextStyle(
                          color: _cfOrange,
                          fontSize: 11.5,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        Expanded(
          child: _loading
              ? const _LoadingView()
              : _err != null
                  ? _ErrorView(error: _err!, onRetry: _load)
                  : _projects.isEmpty
                      ? _EmptyView(
                          icon: Icons.web_rounded,
                          title: 'No Pages projects',
                          subtitle: 'Tap + to create your first project',
                        )
                      : RefreshIndicator(
                          color: _cfOrange,
                          onRefresh: _load,
                          child: ListView.builder(
                            padding: const EdgeInsets.fromLTRB(14, 4, 14, 80),
                            itemCount: _projects.length,
                            itemBuilder: (_, i) {
                              return _PagesProjectCard(
                                key: ValueKey(_projects[i]['name']),
                                project: _projects[i],
                                api: widget.api,
                                accountId: widget.accountId,
                                onChanged: _load,
                              );
                            },
                          ),
                        ),
        ),
      ],
    );
  }
}

class _PagesProjectCard extends StatefulWidget {
  final Map project;
  final CfApi api;
  final String accountId;
  final VoidCallback onChanged;
  const _PagesProjectCard({
    super.key,
    required this.project,
    required this.api,
    required this.accountId,
    required this.onChanged,
  });
  @override
  State<_PagesProjectCard> createState() => _PagesProjectCardState();
}

class _PagesProjectCardState extends State<_PagesProjectCard>
    with SingleTickerProviderStateMixin {
  bool _expanded = false;
  late final AnimationController _ctrl;
  late final Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 260));
    _anim = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _toggle() {
    setState(() => _expanded = !_expanded);
    _expanded ? _ctrl.forward() : _ctrl.reverse();
  }

  Future<void> _viewDeployments() async {
    if (!mounted) return;
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => _DeploymentsScreen(
        api: widget.api,
        accountId: widget.accountId,
        projectName: widget.project['name'] ?? '',
      ),
    ));
  }

  void _pagesSnack(String msg, {bool error = false, bool warn = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(
          error ? Icons.error_rounded : warn ? Icons.warning_amber_rounded : Icons.check_circle_rounded,
          color: Colors.white, size: 18,
        ),
        const SizedBox(width: 8),
        Expanded(child: Text(msg, style: const TextStyle(color: Colors.white))),
      ]),
      backgroundColor: error ? Colors.red.shade800 : warn ? Colors.orange : _cfOrange,
      duration: const Duration(seconds: 5),
    ));
  }

  void _pagesShowBusy(String msg) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _BusyDialog(message: msg),
    );
  }

  Future<void> _uploadDeploy() async {
    final res = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['zip'],
      allowMultiple: false,
    );
    if (res == null || res.files.isEmpty) return;
    final file = res.files.first;
    if (file.path == null) return;
    if (!mounted) return;

    final projectName = widget.project['name'] as String? ?? '';
    _pagesShowBusy('Uploading ${file.name}...\nThis may take a moment');

    final bytes = await File(file.path!).readAsBytes();
    final r = await widget.api.deployPagesZip(widget.accountId, projectName, bytes);

    if (!mounted) return;
    Navigator.pop(context);
    if (r.ok) {
      final url = r.data?['result']?['url'] as String?;
      _pagesSnack('Deployed! ${url ?? ''}');
    } else {
      _pagesSnack('${r.error}', error: true);
    }
  }

  Future<void> _delete() async {
    final name = widget.project['name'] ?? '';
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => _CfConfirmDialog(
        title: 'Delete Project',
        message: 'Delete "$name"? All deployments will be lost.',
        confirmLabel: 'Delete',
        confirmColor: Colors.red,
      ),
    );
    if (ok != true || !mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const _BusyDialog(message: 'Deleting project...'),
    );
    final r =
        await widget.api.deletePagesProject(widget.accountId, name);
    if (!mounted) return;
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(r.ok ? Icons.check_circle_rounded : Icons.error_rounded,
            color: Colors.white, size: 18),
        const SizedBox(width: 8),
        Expanded(child: Text(r.ok ? 'Project deleted' : '${r.error}',
            style: const TextStyle(color: Colors.white))),
      ]),
      backgroundColor: r.ok ? _cfOrange : Colors.red.shade800,
    ));
    if (r.ok) widget.onChanged();
  }

  @override
  Widget build(BuildContext context) {
    final name = widget.project['name'] as String? ?? '';
    final url  = 'https://$name.pages.dev';
    final env  = widget.project['latest_deployment']?['environment'] as String?;
    final live = env == 'production';

    return Container(
      margin: EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: _cardBg,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: _expanded ? _cfOrange.withOpacity(0.4) : ThemeProvider().current.surfaceColor),
        boxShadow: _expanded
            ? [BoxShadow(color: _cfOrange.withOpacity(0.07), blurRadius: 14)]
            : [],
      ),
      child: Column(
        children: [
          InkWell(
            onTap: _toggle,
            borderRadius: BorderRadius.circular(14),
            child: Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
              child: Row(
                children: [
                  Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: Colors.blueAccent.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.web_rounded,
                        color: Colors.blueAccent, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(
                              name,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            if (live) ...[
                              const SizedBox(width: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: Colors.green.withOpacity(0.15),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: const Text('Live',
                                    style: TextStyle(
                                        color: Colors.greenAccent,
                                        fontSize: 9.5,
                                        fontWeight: FontWeight.w700)),
                              ),
                            ],
                          ],
                        ),
                        Text(url,
                            style: const TextStyle(
                                color: _cfOrange, fontSize: 10.5)),
                      ],
                    ),
                  ),
                  AnimatedRotation(
                    turns: _expanded ? 0.5 : 0,
                    duration: const Duration(milliseconds: 260),
                    child: const Icon(Icons.keyboard_arrow_down_rounded,
                        color: _textDim),
                  ),
                ],
              ),
            ),
          ),
          SizeTransition(
            sizeFactor: _anim,
            child: Column(
              children: [
                Container(height: 1, margin: EdgeInsets.symmetric(horizontal: 12), color: ThemeProvider().current.surfaceColor),
                Padding(
                  padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
                  child: Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      _ActionChip(
                        icon: Icons.folder_open_rounded,
                        label: 'Browse Files',
                        onTap: () => Navigator.push(context, MaterialPageRoute(
                          builder: (_) => _PageFileBrowserScreen(
                            api: widget.api,
                            accountId: widget.accountId,
                            projectName: widget.project['name'] ?? '',
                          ),
                        )),
                      ),
                      _ActionChip(
                        icon: Icons.history_rounded,
                        label: 'Deployments',
                        onTap: _viewDeployments,
                      ),
                      _ActionChip(
                        icon: Icons.upload_rounded,
                        label: 'Deploy ZIP',
                        onTap: _uploadDeploy,
                      ),
                      _ActionChip(
                        icon: Icons.copy_rounded,
                        label: 'Copy URL',
                        onTap: () {
                          Clipboard.setData(ClipboardData(text: url));
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                            content: Text('Copied!'),
                            backgroundColor: _cfOrange,
                          ));
                        },
                      ),
                      _ActionChip(
                        icon: Icons.delete_outline_rounded,
                        label: 'Delete',
                        color: Colors.red.shade400,
                        onTap: _delete,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ── Deployments Screen ────────────────────────────────────────────────────────
class _DeploymentsScreen extends StatefulWidget {
  final CfApi api;
  final String accountId;
  final String projectName;
  const _DeploymentsScreen({
    required this.api,
    required this.accountId,
    required this.projectName,
  });
  @override
  State<_DeploymentsScreen> createState() => _DeploymentsScreenState();
}

class _DeploymentsScreenState extends State<_DeploymentsScreen> {
  List<Map> _deployments = [];
  bool _loading = true;
  String? _err;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api
        .listPagesDeployments(widget.accountId, widget.projectName);
    if (!mounted) return;
    if (!r.ok) {
      setState(() { _loading = false; _err = r.error; });
      return;
    }
    setState(() {
      _deployments = List<Map>.from(r.data['result'] ?? []);
      _loading     = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeProvider().current.scaffoldBg,
      appBar: AppBar(
        backgroundColor: _cardBg,
        title: Text(
          'Deployments — ${widget.projectName}',
          style: const TextStyle(color: Colors.white, fontSize: 14),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded,
              color: _textDim, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: _cfOrange),
            onPressed: _load,
          ),
        ],
      ),
      body: _loading
          ? const _LoadingView()
          : _err != null
              ? _ErrorView(error: _err!, onRetry: _load)
              : _deployments.isEmpty
                  ? _EmptyView(
                      icon: Icons.rocket_launch_rounded,
                      title: 'No deployments',
                      subtitle: 'Deploy a site via the Cloudflare dashboard',
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.all(14),
                      itemCount: _deployments.length,
                      itemBuilder: (_, i) {
                        final d = _deployments[i];
                        final env = d['environment'] as String? ?? '';
                        final status = d['latest_stage']?['status'] as String? ?? '';
                        final url = d['url'] as String? ?? '';
                        final created = d['created_on'] as String? ?? '';
                        final live = env == 'production' && status == 'success';
                        return Container(
                          margin: EdgeInsets.only(bottom: 8),
                          padding: EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: _cardBg,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: ThemeProvider().current.surfaceColor),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                live
                                    ? Icons.check_circle_rounded
                                    : Icons.radio_button_unchecked_rounded,
                                color: live
                                    ? Colors.greenAccent
                                    : _textDim,
                                size: 20,
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      env.toUpperCase(),
                                      style: TextStyle(
                                        color: live
                                            ? Colors.greenAccent
                                            : _textMid,
                                        fontSize: 11,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                    if (url.isNotEmpty)
                                      Text(url,
                                          style: const TextStyle(
                                              color: _cfOrange,
                                              fontSize: 11),
                                          overflow: TextOverflow.ellipsis),
                                    Text(
                                      _formatDate(created),
                                      style: const TextStyle(
                                          color: _textDim, fontSize: 10.5),
                                    ),
                                  ],
                                ),
                              ),
                              if (url.isNotEmpty)
                                IconButton(
                                  icon: const Icon(Icons.copy_rounded,
                                      color: _textDim, size: 16),
                                  onPressed: () {
                                    Clipboard.setData(
                                        ClipboardData(text: url));
                                    ScaffoldMessenger.of(context)
                                        .showSnackBar(const SnackBar(
                                      content: Text('Copied!'),
                                      backgroundColor: _cfOrange,
                                    ));
                                  },
                                ),
                            ],
                          ),
                        );
                      },
                    ),
    );
  }

  String _formatDate(String iso) {
    try {
      final d = DateTime.parse(iso).toLocal();
      return '${d.year}-${d.month.toString().padLeft(2,'0')}-${d.day.toString().padLeft(2,'0')} '
          '${d.hour.toString().padLeft(2,'0')}:${d.minute.toString().padLeft(2,'0')}';
    } catch (_) {
      return iso;
    }
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// STATS TAB
// ═════════════════════════════════════════════════════════════════════════════
class _StatsTab extends StatefulWidget {
  final CfApi api;
  final String accountId;
  const _StatsTab({required this.api, required this.accountId});
  @override
  State<_StatsTab> createState() => _StatsTabState();
}

class _StatsTabState extends State<_StatsTab>
    with AutomaticKeepAliveClientMixin {
  int _days = 1;
  bool _loading = false;
  String? _err;
  Map<String, dynamic> _stats = {};
  int _totalRequests = 0;
  int _totalErrors   = 0;
  double _totalCpu   = 0;
  List<MapEntry<String, Map<String, dynamic>>> _sorted = [];

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api
        .getWorkersAnalytics(widget.accountId, _days);
    if (!mounted) return;
    if (!r.ok) {
      setState(() { _loading = false; _err = r.error; });
      return;
    }

    final accounts = r.data['data']?['viewer']?['accounts'] as List?;
    final acct = (accounts?.isNotEmpty == true) ? accounts![0] : null;
    final invocations =
        (acct?['workersInvocationsAdaptive'] as List?) ?? [];
    final cpuData = (acct?['workersCpuTime'] as List?) ?? [];

    final workerMap = <String, Map<String, dynamic>>{};
    int totalReq = 0, totalErr = 0;

    for (final inv in invocations) {
      final name = inv['dimensions']?['scriptName'] as String? ?? 'unknown';
      final reqs = (inv['sum']?['requests'] as num?)?.toInt() ?? 0;
      final errs = (inv['sum']?['errors'] as num?)?.toInt() ?? 0;
      workerMap[name] = {
        'requests': (workerMap[name]?['requests'] ?? 0) + reqs,
        'errors':   (workerMap[name]?['errors'] ?? 0) + errs,
        'cpu': workerMap[name]?['cpu'] ?? 0.0,
      };
      totalReq += reqs;
      totalErr += errs;
    }

    double totalCpu = 0;
    for (final cpu in cpuData) {
      final name = cpu['dimensions']?['scriptName'] as String? ?? 'unknown';
      final p50 = (cpu['quantiles']?['cpuTimeP50'] as num?)?.toDouble() ?? 0;
      if (workerMap.containsKey(name)) {
        workerMap[name]!['cpu'] = p50;
      }
      totalCpu += p50;
    }

    final sorted = workerMap.entries
        .toList()
      ..sort((a, b) =>
          (b.value['requests'] as int).compareTo(a.value['requests'] as int));

    setState(() {
      _stats         = workerMap;
      _totalRequests = totalReq;
      _totalErrors   = totalErr;
      _totalCpu      = totalCpu;
      _sorted        = sorted;
      _loading       = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Column(
      children: [
        // time range
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
          child: Row(
            children: [
              const Text(
                'Analytics',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const Spacer(),
              _TimeRangeBtn(days: _days, label: '24h', value: 1, onTap: _setDays),
              const SizedBox(width: 6),
              _TimeRangeBtn(days: _days, label: '7d', value: 7, onTap: _setDays),
              const SizedBox(width: 6),
              _TimeRangeBtn(days: _days, label: '30d', value: 30, onTap: _setDays),
              const SizedBox(width: 8),
              _CfIconBtn(
                icon: Icons.refresh_rounded,
                tooltip: 'Refresh',
                onTap: _load,
              ),
            ],
          ),
        ),
        Expanded(
          child: _loading
              ? const _LoadingView()
              : _err != null
                  ? _ErrorView(error: _err!, onRetry: _load)
                  : RefreshIndicator(
                      color: _cfOrange,
                      onRefresh: _load,
                      child: ListView(
                        padding: const EdgeInsets.fromLTRB(14, 4, 14, 80),
                        children: [
                          // summary cards
                          Row(
                            children: [
                              Expanded(
                                child: _StatSummaryCard(
                                  icon: Icons.bolt_rounded,
                                  label: 'Requests',
                                  value: _fmtNum(_totalRequests),
                                  color: _cfOrange,
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: _StatSummaryCard(
                                  icon: Icons.error_outline_rounded,
                                  label: 'Errors',
                                  value: _fmtNum(_totalErrors),
                                  color: Colors.red.shade400,
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: _StatSummaryCard(
                                  icon: Icons.timer_outlined,
                                  label: 'Avg CPU',
                                  value: '${_totalCpu.toStringAsFixed(2)} ms',
                                  color: Colors.blueAccent.shade200,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),
                          if (_sorted.isEmpty)
                            _EmptyView(
                              icon: Icons.bar_chart_rounded,
                              title: 'No analytics data',
                              subtitle: 'Data appears after workers receive requests',
                            )
                          else ...[
                            const Text(
                              'Workers by Requests',
                              style: TextStyle(
                                color: _textMid,
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 0.5,
                              ),
                            ),
                            const SizedBox(height: 8),
                            ..._sorted.take(50).map((entry) {
                              final name = entry.key;
                              final data = entry.value;
                              final reqs = data['requests'] as int? ?? 0;
                              final errs = data['errors'] as int? ?? 0;
                              final cpu = (data['cpu'] as double?) ?? 0.0;
                              final pct = _totalRequests > 0
                                  ? reqs / _totalRequests
                                  : 0.0;
                              return _WorkerStatRow(
                                name: name,
                                requests: reqs,
                                errors: errs,
                                cpu: cpu,
                                pct: pct,
                              );
                            }),
                          ],
                        ],
                      ),
                    ),
        ),
      ],
    );
  }

  void _setDays(int d) {
    if (_days == d) return;
    setState(() => _days = d);
    _load();
  }

  String _fmtNum(int n) {
    if (n >= 1000000) return '${(n / 1000000).toStringAsFixed(1)}M';
    if (n >= 1000) return '${(n / 1000).toStringAsFixed(1)}K';
    return n.toString();
  }
}

class _TimeRangeBtn extends StatelessWidget {
  final int days;
  final String label;
  final int value;
  final ValueChanged<int> onTap;
  const _TimeRangeBtn({
    required this.days,
    required this.label,
    required this.value,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final sel = days == value;
    return GestureDetector(
      onTap: () => onTap(value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: sel ? _cfOrange.withOpacity(0.15) : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: sel ? _cfOrange : ThemeProvider().current.surfaceColor),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: sel ? _cfOrange : _textDim,
            fontSize: 12,
            fontWeight: sel ? FontWeight.w700 : FontWeight.w400,
          ),
        ),
      ),
    );
  }
}

class _StatSummaryCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;
  const _StatSummaryCard({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _cardBg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.25)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 18),
          const SizedBox(height: 6),
          Text(value,
              style: TextStyle(
                  color: color,
                  fontSize: 16,
                  fontWeight: FontWeight.w800)),
          Text(label,
              style: const TextStyle(color: _textDim, fontSize: 10.5)),
        ],
      ),
    );
  }
}

class _WorkerStatRow extends StatelessWidget {
  final String name;
  final int requests;
  final int errors;
  final double cpu;
  final double pct;
  const _WorkerStatRow({
    required this.name,
    required this.requests,
    required this.errors,
    required this.cpu,
    required this.pct,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 8),
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _cardBg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: ThemeProvider().current.surfaceColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.bolt_rounded,
                  color: _cfOrange, size: 14),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Text(
                '${(pct * 100).toStringAsFixed(1)}%',
                style: const TextStyle(
                    color: _cfOrange,
                    fontSize: 11,
                    fontWeight: FontWeight.w700),
              ),
            ],
          ),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: pct.clamp(0.0, 1.0),
              backgroundColor: _cfOrange.withOpacity(0.1),
              valueColor: const AlwaysStoppedAnimation(_cfOrange),
              minHeight: 3,
            ),
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              _StatPill(
                  label: '${_fmt(requests)} req',
                  color: _cfOrange),
              const SizedBox(width: 6),
              if (errors > 0)
                _StatPill(
                    label: '${_fmt(errors)} err',
                    color: Colors.red.shade400),
              if (cpu > 0) ...[
                const SizedBox(width: 6),
                _StatPill(
                    label: '${cpu.toStringAsFixed(1)} ms cpu',
                    color: Colors.blueAccent.shade200),
              ],
            ],
          ),
        ],
      ),
    );
  }

  String _fmt(int n) {
    if (n >= 1000000) return '${(n / 1000000).toStringAsFixed(1)}M';
    if (n >= 1000) return '${(n / 1000).toStringAsFixed(1)}K';
    return n.toString();
  }
}

class _StatPill extends StatelessWidget {
  final String label;
  final Color color;
  const _StatPill({required this.label, required this.color});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding:
          const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(label,
          style: TextStyle(
              color: color, fontSize: 10.5, fontWeight: FontWeight.w600)),
    );
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// STORAGE TAB  (KV / D1 / R2 / Queues)
// ═════════════════════════════════════════════════════════════════════════════

const _kvBlue    = Color(0xFF3b82f6);
const _d1Purple  = Color(0xFFa855f7);
const _r2Teal    = Color(0xFF14b8a6);
const _qAmber    = Color(0xFFf59e0b);

Widget _stErrView(String err, Color color, VoidCallback onRetry, {String? scope}) {
  final isAuth = err.toLowerCase().contains('auth') ||
      err.toLowerCase().contains('unauthorized') ||
      err.toLowerCase().contains('forbidden') ||
      err.toLowerCase().contains('10000');
  return Center(
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(isAuth ? Icons.lock_outline_rounded : Icons.error_outline_rounded,
              color: Colors.red, size: 40),
          const SizedBox(height: 12),
          Text(err,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.red, fontSize: 13)),
          if (isAuth) ...[
            const SizedBox(height: 10),
            Text(
              scope != null
                  ? 'Your API token needs the "$scope" permission.\nGo to Cloudflare → My Profile → API Tokens and add this scope.'
                  : 'Your API token may be missing storage permissions.\nGo to Cloudflare → My Profile → API Tokens and add the required scopes.',
              textAlign: TextAlign.center,
              style: const TextStyle(color: Color(0xFF9ca3af), fontSize: 12, height: 1.5),
            ),
          ],
          const SizedBox(height: 16),
          TextButton.icon(
            onPressed: onRetry,
            icon: Icon(Icons.refresh_rounded, color: color, size: 16),
            label: Text('Retry', style: TextStyle(color: color)),
          ),
        ],
      ),
    ),
  );
}

class _StorageTab extends StatefulWidget {
  final CfApi api;
  final String accountId;
  const _StorageTab({required this.api, required this.accountId});
  @override
  State<_StorageTab> createState() => _StorageTabState();
}

class _StorageTabState extends State<_StorageTab> {
  int _cat = 0; // 0=KV 1=D1 2=R2 3=Queues

  static const _cats = [
    (Icons.storage_rounded,       'KV',     _kvBlue),
    (Icons.table_chart_rounded,   'D1',     _d1Purple),
    (Icons.cloud_queue_rounded,   'R2',     _r2Teal),
    (Icons.queue_rounded,         'Queues', _qAmber),
  ];

  @override
  Widget build(BuildContext context) {
    final api = widget.api;
    final acct = widget.accountId;
    return Column(
      children: [
        Container(
          color: _cardBg,
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
          child: Row(
            children: List.generate(_cats.length, (i) {
              final (icon, label, color) = _cats[i];
              final sel = _cat == i;
              return Expanded(
                child: GestureDetector(
                  onTap: () => setState(() => _cat = i),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    margin: EdgeInsets.only(right: i < _cats.length - 1 ? 8 : 0),
                    padding: EdgeInsets.symmetric(vertical: 8),
                    decoration: BoxDecoration(
                      color: sel ? color.withOpacity(0.15) : Colors.transparent,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                          color: sel ? color.withOpacity(0.6) : ThemeProvider().current.surfaceColor),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(icon,
                            color: sel ? color : _textDim, size: 20),
                        const SizedBox(height: 3),
                        Text(label,
                            style: TextStyle(
                                color: sel ? color : _textDim,
                                fontSize: 10,
                                fontWeight: sel
                                    ? FontWeight.w700
                                    : FontWeight.w400)),
                      ],
                    ),
                  ),
                ),
              );
            }),
          ),
        ),
        Expanded(
          child: IndexedStack(
            index: _cat,
            children: [
              _KvView(api: api, accountId: acct),
              _D1View(api: api, accountId: acct),
              _R2View(api: api, accountId: acct),
              _QueueView(api: api, accountId: acct),
            ],
          ),
        ),
      ],
    );
  }
}

// ─── KV ──────────────────────────────────────────────────────────────────────

class _KvView extends StatefulWidget {
  final CfApi api;
  final String accountId;
  const _KvView({required this.api, required this.accountId});
  @override
  State<_KvView> createState() => _KvViewState();
}

class _KvViewState extends State<_KvView> {
  List<dynamic> _ns = [];
  bool _loading = true;
  String? _err;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.listKvNamespaces(widget.accountId);
    if (!mounted) return;
    setState(() {
      _loading = false;
      if (r.ok) {
        _ns = (r.data['result'] as List?) ?? [];
      } else {
        _err = r.error;
      }
    });
  }

  Future<void> _create() async {
    final title = await _inputDialog(context, 'New KV Namespace', 'Title', color: _kvBlue);
    if (title == null || title.isEmpty) return;
    final r = await widget.api.createKvNamespace(widget.accountId, title);
    if (!mounted) return;
    _stSnack(context, r.ok ? 'Namespace created' : (r.error ?? 'Failed'), !r.ok, _kvBlue);
    if (r.ok) _load();
  }

  Future<void> _rename(Map ns) async {
    final title = await _inputDialog(context, 'Rename Namespace', 'New title',
        initial: ns['title'] as String? ?? '', color: _kvBlue);
    if (title == null || title.isEmpty) return;
    final r = await widget.api.renameKvNamespace(widget.accountId, ns['id'] as String, title);
    if (!mounted) return;
    _stSnack(context, r.ok ? 'Renamed' : (r.error ?? 'Failed'), !r.ok, _kvBlue);
    if (r.ok) _load();
  }

  Future<void> _delete(Map ns) async {
    final ok = await _confirmDialog(
        context, 'Delete Namespace',
        'Delete "${ns['title']}"? All keys inside will be permanently removed.');
    if (!ok) return;
    final r = await widget.api.deleteKvNamespace(widget.accountId, ns['id'] as String);
    if (!mounted) return;
    _stSnack(context, r.ok ? 'Deleted' : (r.error ?? 'Failed'), !r.ok, _kvBlue);
    if (r.ok) _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeProvider().current.scaffoldBg,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _create,
        backgroundColor: _kvBlue,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add_rounded),
        label: const Text('New Namespace'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: _kvBlue))
          : _err != null
              ? _stErrView(_err!, _kvBlue, _load, scope: 'Workers KV Storage:Edit')
              : _ns.isEmpty
                  ? const Center(child: Text('No KV namespaces', style: TextStyle(color: _textDim)))
                  : RefreshIndicator(
                      onRefresh: _load,
                      color: _kvBlue,
                      child: ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
                        itemCount: _ns.length,
                        itemBuilder: (_, i) {
                          final ns = _ns[i] as Map;
                          final title = ns['title'] as String? ?? '—';
                          final id = ns['id'] as String? ?? '';
                          return _stCard(
                            color: _kvBlue,
                            icon: Icons.storage_rounded,
                            title: title,
                            subtitle: id,
                            trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                              IconButton(icon: const Icon(Icons.drive_file_rename_outline_rounded, color: _kvBlue, size: 20),
                                  onPressed: () => _rename(ns)),
                              IconButton(icon: const Icon(Icons.delete_rounded, color: Colors.red, size: 20),
                                  onPressed: () => _delete(ns)),
                            ]),
                            onTap: () => Navigator.push(context,
                                MaterialPageRoute(builder: (_) => _KvKeysScreen(
                                    api: widget.api,
                                    accountId: widget.accountId,
                                    namespaceId: id,
                                    title: title))),
                          );
                        },
                      ),
                    ),
    );
  }
}

class _KvKeysScreen extends StatefulWidget {
  final CfApi api;
  final String accountId;
  final String namespaceId;
  final String title;
  const _KvKeysScreen({required this.api, required this.accountId,
      required this.namespaceId, required this.title});
  @override
  State<_KvKeysScreen> createState() => _KvKeysScreenState();
}

class _KvKeysScreenState extends State<_KvKeysScreen> {
  List<dynamic> _keys = [];
  bool _loading = true;
  bool _loadingMore = false;
  String? _err;
  String? _cursor;
  bool _hasMore = false;
  final _prefixCtrl = TextEditingController();
  final Set<String> _selected = {};
  bool _selectMode = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _prefixCtrl.dispose();
    super.dispose();
  }

  Future<void> _load({bool append = false}) async {
    if (!append) setState(() { _loading = true; _err = null; _cursor = null; _keys = []; });
    final r = await widget.api.listKvKeys(widget.accountId, widget.namespaceId,
        prefix: _prefixCtrl.text.trim().isEmpty ? null : _prefixCtrl.text.trim(),
        cursor: append ? _cursor : null);
    if (!mounted) return;
    setState(() {
      _loading = false;
      _loadingMore = false;
      if (r.ok) {
        final result = r.data['result'] as List? ?? [];
        if (append) {
          _keys.addAll(result);
        } else {
          _keys = result;
        }
        final ci = r.data['result_info'];
        _cursor = ci?['cursor'] as String?;
        _hasMore = _cursor != null && _cursor!.isNotEmpty;
      } else {
        _err = r.error;
      }
    });
  }

  Future<void> _loadMore() async {
    if (_loadingMore || !_hasMore) return;
    setState(() => _loadingMore = true);
    await _load(append: true);
  }

  Future<void> _viewKey(String key) async {
    final r = await widget.api.getKvValue(widget.accountId, widget.namespaceId, key);
    if (!mounted) return;
    final value = r.ok ? (r.data as String? ?? '') : ('Error: ${r.error}');
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: _cardBg,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(18))),
      builder: (_) => _KvValueSheet(
          api: widget.api,
          accountId: widget.accountId,
          namespaceId: widget.namespaceId,
          keyName: key,
          initialValue: value,
          onSaved: () { setState(() {}); _load(); }),
    );
  }

  Future<void> _addKey() async {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: _cardBg,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(18))),
      builder: (_) => _KvWriteSheet(
          api: widget.api,
          accountId: widget.accountId,
          namespaceId: widget.namespaceId,
          onSaved: _load),
    );
  }

  Future<void> _deleteKey(String key) async {
    final ok = await _confirmDialog(context, 'Delete Key', 'Delete "$key"?');
    if (!ok || !mounted) return;
    final r = await widget.api.deleteKvValue(widget.accountId, widget.namespaceId, key);
    if (!mounted) return;
    _stSnack(context, r.ok ? 'Deleted' : (r.error ?? 'Failed'), !r.ok, _kvBlue);
    if (r.ok) _load();
  }

  Future<void> _bulkDelete() async {
    final keys = _selected.toList();
    final ok = await _confirmDialog(context, 'Delete Keys', 'Delete ${keys.length} selected keys?');
    if (!ok || !mounted) return;
    final r = await widget.api.deleteKvKeys(widget.accountId, widget.namespaceId, keys);
    if (!mounted) return;
    _stSnack(context, r.ok ? 'Deleted ${keys.length} keys' : (r.error ?? 'Failed'), !r.ok, _kvBlue);
    if (r.ok) { setState(() { _selected.clear(); _selectMode = false; }); _load(); }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeProvider().current.scaffoldBg,
      appBar: AppBar(
        backgroundColor: _cardBg,
        foregroundColor: Colors.white,
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          const Text('Keys', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
          Text(widget.title, style: const TextStyle(color: _kvBlue, fontSize: 11)),
        ]),
        actions: [
          if (_selectMode && _selected.isNotEmpty)
            IconButton(icon: const Icon(Icons.delete_sweep_rounded, color: Colors.red),
                tooltip: 'Delete selected', onPressed: _bulkDelete),
          IconButton(icon: Icon(_selectMode ? Icons.check_box_rounded : Icons.checklist_rounded,
              color: _selectMode ? _kvBlue : _textDim),
              tooltip: 'Select mode', onPressed: () => setState(() { _selectMode = !_selectMode; _selected.clear(); })),
          IconButton(icon: const Icon(Icons.refresh_rounded, color: _kvBlue),
              onPressed: _load),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addKey,
        backgroundColor: _kvBlue,
        foregroundColor: Colors.white,
        child: const Icon(Icons.add_rounded),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: TextField(
              controller: _prefixCtrl,
              style: const TextStyle(color: Colors.white, fontSize: 13),
              decoration: InputDecoration(
                hintText: 'Filter by prefix...',
                hintStyle: const TextStyle(color: _textDim),
                prefixIcon: const Icon(Icons.search_rounded, color: _textDim, size: 20),
                suffixIcon: _prefixCtrl.text.isNotEmpty
                    ? IconButton(icon: const Icon(Icons.clear_rounded, color: _textDim, size: 18),
                        onPressed: () { _prefixCtrl.clear(); _load(); })
                    : null,
                filled: true,
                fillColor: _cardBg,
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(color: _kvBlue)),
              ),
              onSubmitted: (_) => _load(),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator(color: _kvBlue))
                : _err != null
                    ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Text(_err!, style: const TextStyle(color: Colors.red, fontSize: 13)),
                        TextButton(onPressed: _load, child: const Text('Retry', style: TextStyle(color: _kvBlue))),
                      ]))
                    : _keys.isEmpty
                        ? const Center(child: Text('No keys', style: TextStyle(color: _textDim)))
                        : ListView.builder(
                            padding: const EdgeInsets.fromLTRB(16, 4, 16, 100),
                            itemCount: _keys.length + (_hasMore ? 1 : 0),
                            itemBuilder: (_, i) {
                              if (i == _keys.length) {
                                return Center(
                                  child: TextButton(
                                    onPressed: _loadingMore ? null : _loadMore,
                                    child: _loadingMore
                                        ? const SizedBox(width: 18, height: 18,
                                            child: CircularProgressIndicator(color: _kvBlue, strokeWidth: 2))
                                        : const Text('Load more', style: TextStyle(color: _kvBlue)),
                                  ),
                                );
                              }
                              final k = _keys[i] as Map;
                              final keyName = k['name'] as String? ?? '';
                              final exp = k['expiration'];
                              final sel = _selected.contains(keyName);
                              return InkWell(
                                onTap: _selectMode
                                    ? () => setState(() => sel ? _selected.remove(keyName) : _selected.add(keyName))
                                    : () => _viewKey(keyName),
                                onLongPress: () {
                                  setState(() { _selectMode = true; _selected.add(keyName); });
                                },
                                borderRadius: BorderRadius.circular(10),
                                child: Container(
                                  margin: const EdgeInsets.symmetric(vertical: 4),
                                  padding: EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                                  decoration: BoxDecoration(
                                    color: sel ? _kvBlue.withOpacity(0.12) : _cardBg,
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(
                                        color: sel ? _kvBlue.withOpacity(0.6) : ThemeProvider().current.surfaceColor),
                                  ),
                                  child: Row(
                                    children: [
                                      if (_selectMode)
                                        Padding(
                                          padding: const EdgeInsets.only(right: 10),
                                          child: Icon(
                                              sel ? Icons.check_box_rounded : Icons.check_box_outline_blank_rounded,
                                              color: _kvBlue, size: 20),
                                        ),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(keyName,
                                                style: const TextStyle(color: Colors.white, fontSize: 13),
                                                overflow: TextOverflow.ellipsis),
                                            if (exp != null)
                                              Text('Expires: ${DateTime.fromMillisecondsSinceEpoch((exp as num).toInt() * 1000).toLocal()}',
                                                  style: const TextStyle(color: _textDim, fontSize: 10.5)),
                                          ],
                                        ),
                                      ),
                                      if (!_selectMode)
                                        IconButton(icon: const Icon(Icons.delete_rounded, color: Colors.red, size: 18),
                                            onPressed: () => _deleteKey(keyName)),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
          ),
        ],
      ),
    );
  }
}

class _KvValueSheet extends StatefulWidget {
  final CfApi api;
  final String accountId;
  final String namespaceId;
  final String keyName;
  final String initialValue;
  final VoidCallback onSaved;
  const _KvValueSheet({required this.api, required this.accountId,
      required this.namespaceId, required this.keyName,
      required this.initialValue, required this.onSaved});
  @override
  State<_KvValueSheet> createState() => _KvValueSheetState();
}

class _KvValueSheetState extends State<_KvValueSheet> {
  late final TextEditingController _ctrl;
  bool _saving = false;
  final _ttlCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _ctrl = TextEditingController(text: widget.initialValue);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    _ttlCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    final ttl = int.tryParse(_ttlCtrl.text.trim());
    final r = await widget.api.putKvValue(
        widget.accountId, widget.namespaceId, widget.keyName, _ctrl.text,
        expirationTtl: ttl);
    if (!mounted) return;
    setState(() => _saving = false);
    _stSnack(context, r.ok ? 'Saved' : (r.error ?? 'Failed'), !r.ok, _kvBlue);
    if (r.ok) { widget.onSaved(); Navigator.pop(context); }
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 16, 16, bottom + 16),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Expanded(child: Text(widget.keyName,
                  style: const TextStyle(color: _kvBlue, fontSize: 14,
                      fontWeight: FontWeight.w700),
                  overflow: TextOverflow.ellipsis)),
              IconButton(icon: const Icon(Icons.close_rounded, color: _textDim),
                  onPressed: () => Navigator.pop(context)),
            ]),
            const SizedBox(height: 12),
            TextField(
              controller: _ctrl,
              maxLines: 8,
              style: TextStyle(color: Colors.white, fontSize: 12.5, fontFamily: 'monospace'),
              decoration: InputDecoration(
                filled: true, fillColor: ThemeProvider().current.scaffoldBg,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: _kvBlue)),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _ttlCtrl,
              keyboardType: TextInputType.number,
              style: TextStyle(color: Colors.white, fontSize: 13),
              decoration: InputDecoration(
                hintText: 'Expiration TTL (seconds, leave empty for no expiry)',
                hintStyle: TextStyle(color: _textDim, fontSize: 12),
                filled: true, fillColor: ThemeProvider().current.scaffoldBg,
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: _kvBlue)),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
              ),
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _saving ? null : _save,
                style: ElevatedButton.styleFrom(
                    backgroundColor: _kvBlue, foregroundColor: Colors.white),
                child: _saving
                    ? const SizedBox(width: 18, height: 18,
                        child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : const Text('Save Value'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _KvWriteSheet extends StatefulWidget {
  final CfApi api;
  final String accountId;
  final String namespaceId;
  final VoidCallback onSaved;
  const _KvWriteSheet({required this.api, required this.accountId,
      required this.namespaceId, required this.onSaved});
  @override
  State<_KvWriteSheet> createState() => _KvWriteSheetState();
}

class _KvWriteSheetState extends State<_KvWriteSheet> {
  final _keyCtrl   = TextEditingController();
  final _valCtrl   = TextEditingController();
  final _ttlCtrl   = TextEditingController();
  bool _saving = false;

  @override
  void dispose() {
    _keyCtrl.dispose();
    _valCtrl.dispose();
    _ttlCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_keyCtrl.text.trim().isEmpty) return;
    setState(() => _saving = true);
    final ttl = int.tryParse(_ttlCtrl.text.trim());
    final r = await widget.api.putKvValue(
        widget.accountId, widget.namespaceId, _keyCtrl.text.trim(), _valCtrl.text,
        expirationTtl: ttl);
    if (!mounted) return;
    setState(() => _saving = false);
    _stSnack(context, r.ok ? 'Key written' : (r.error ?? 'Failed'), !r.ok, _kvBlue);
    if (r.ok) { widget.onSaved(); Navigator.pop(context); }
  }

  InputDecoration _dec(String hint) => InputDecoration(
    hintText: hint, hintStyle: TextStyle(color: _textDim, fontSize: 12),
    filled: true, fillColor: ThemeProvider().current.scaffoldBg,
    contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(color: _kvBlue)),
    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
  );

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 16, 16, bottom + 16),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              const Expanded(child: Text('Write Key',
                  style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w700))),
              IconButton(icon: const Icon(Icons.close_rounded, color: _textDim),
                  onPressed: () => Navigator.pop(context)),
            ]),
            const SizedBox(height: 12),
            TextField(controller: _keyCtrl, style: const TextStyle(color: Colors.white, fontSize: 13),
                decoration: _dec('Key name')),
            const SizedBox(height: 8),
            TextField(controller: _valCtrl, maxLines: 5,
                style: const TextStyle(color: Colors.white, fontSize: 12.5, fontFamily: 'monospace'),
                decoration: _dec('Value')),
            const SizedBox(height: 8),
            TextField(controller: _ttlCtrl, keyboardType: TextInputType.number,
                style: const TextStyle(color: Colors.white, fontSize: 13),
                decoration: _dec('Expiration TTL in seconds (leave empty for none)')),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _saving ? null : _save,
                style: ElevatedButton.styleFrom(
                    backgroundColor: _kvBlue, foregroundColor: Colors.white),
                child: _saving
                    ? const SizedBox(width: 18, height: 18,
                        child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : const Text('Write Key'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── D1 ──────────────────────────────────────────────────────────────────────

class _D1View extends StatefulWidget {
  final CfApi api;
  final String accountId;
  const _D1View({required this.api, required this.accountId});
  @override
  State<_D1View> createState() => _D1ViewState();
}

class _D1ViewState extends State<_D1View> {
  List<dynamic> _dbs = [];
  bool _loading = true;
  String? _err;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.listD1Databases(widget.accountId);
    if (!mounted) return;
    setState(() {
      _loading = false;
      if (r.ok) _dbs = (r.data['result'] as List?) ?? [];
      else _err = r.error;
    });
  }

  Future<void> _create() async {
    final name = await _inputDialog(context, 'New D1 Database', 'Database name', color: _d1Purple);
    if (name == null || name.isEmpty) return;
    final r = await widget.api.createD1Database(widget.accountId, name);
    if (!mounted) return;
    _stSnack(context, r.ok ? 'Database created' : (r.error ?? 'Failed'), !r.ok, _d1Purple);
    if (r.ok) _load();
  }

  Future<void> _delete(Map db) async {
    final ok = await _confirmDialog(context, 'Delete Database',
        'Delete "${db['name']}"? This is irreversible.');
    if (!ok) return;
    final r = await widget.api.deleteD1Database(widget.accountId, db['uuid'] as String);
    if (!mounted) return;
    _stSnack(context, r.ok ? 'Deleted' : (r.error ?? 'Failed'), !r.ok, _d1Purple);
    if (r.ok) _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeProvider().current.scaffoldBg,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _create,
        backgroundColor: _d1Purple,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add_rounded),
        label: const Text('New Database'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: _d1Purple))
          : _err != null
              ? _stErrView(_err!, _d1Purple, _load, scope: 'D1:Edit')
              : _dbs.isEmpty
                  ? const Center(child: Text('No D1 databases', style: TextStyle(color: _textDim)))
                  : RefreshIndicator(
                      onRefresh: _load,
                      color: _d1Purple,
                      child: ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
                        itemCount: _dbs.length,
                        itemBuilder: (_, i) {
                          final db = _dbs[i] as Map;
                          final name = db['name'] as String? ?? '—';
                          final id = db['uuid'] as String? ?? '';
                          final version = db['version'] as String? ?? '';
                          final fileSize = db['file_size'];
                          String sub = id;
                          if (version.isNotEmpty) sub += '  •  v$version';
                          if (fileSize != null) {
                            final kb = (fileSize as num).toInt();
                            sub += '  •  ${(kb / 1024).toStringAsFixed(1)} KB';
                          }
                          return _stCard(
                            color: _d1Purple,
                            icon: Icons.table_chart_rounded,
                            title: name,
                            subtitle: sub,
                            trailing: IconButton(
                                icon: const Icon(Icons.delete_rounded, color: Colors.red, size: 20),
                                onPressed: () => _delete(db)),
                            onTap: () => Navigator.push(context,
                                MaterialPageRoute(builder: (_) => _D1QueryScreen(
                                    api: widget.api,
                                    accountId: widget.accountId,
                                    databaseId: id,
                                    name: name))),
                          );
                        },
                      ),
                    ),
    );
  }
}

class _D1QueryScreen extends StatefulWidget {
  final CfApi api;
  final String accountId;
  final String databaseId;
  final String name;
  const _D1QueryScreen({required this.api, required this.accountId,
      required this.databaseId, required this.name});
  @override
  State<_D1QueryScreen> createState() => _D1QueryScreenState();
}

class _D1QueryScreenState extends State<_D1QueryScreen> {
  final _sqlCtrl = TextEditingController();
  bool _running = false;
  List<Map<String, dynamic>>? _rows;
  List<String>? _cols;
  String? _err;
  Map<String, dynamic>? _meta;

  Future<void> _run(String sql) async {
    if (sql.trim().isEmpty) return;
    setState(() { _running = true; _err = null; _rows = null; _cols = null; _meta = null; });
    final r = await widget.api.queryD1(widget.accountId, widget.databaseId, sql.trim());
    if (!mounted) return;
    setState(() {
      _running = false;
      if (r.ok) {
        final results = (r.data['result'] as List?)?.first as Map?;
        if (results != null) {
          _meta = results['meta'] as Map<String, dynamic>?;
          final rawRows = results['results'] as List? ?? [];
          if (rawRows.isNotEmpty) {
            _cols = (rawRows.first as Map).keys.cast<String>().toList();
            _rows = rawRows.map((row) => Map<String, dynamic>.from(row as Map)).toList();
          } else {
            _cols = [];
            _rows = [];
          }
        }
      } else {
        _err = r.error;
      }
    });
  }

  Future<void> _listTables() => _run("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name");

  @override
  void dispose() { _sqlCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeProvider().current.scaffoldBg,
      appBar: AppBar(
        backgroundColor: _cardBg,
        foregroundColor: Colors.white,
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          const Text('SQL Query', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
          Text(widget.name, style: const TextStyle(color: _d1Purple, fontSize: 11)),
        ]),
        actions: [
          TextButton.icon(
            onPressed: _listTables,
            icon: const Icon(Icons.list_alt_rounded, color: _d1Purple, size: 18),
            label: const Text('Tables', style: TextStyle(color: _d1Purple, fontSize: 12)),
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            color: _cardBg,
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
            child: Column(
              children: [
                TextField(
                  controller: _sqlCtrl,
                  maxLines: 5,
                  style: TextStyle(color: Colors.white, fontSize: 13, fontFamily: 'monospace'),
                  decoration: InputDecoration(
                    hintText: 'SELECT * FROM my_table LIMIT 100',
                    hintStyle: TextStyle(color: _textDim, fontSize: 12),
                    filled: true, fillColor: ThemeProvider().current.scaffoldBg,
                    contentPadding: EdgeInsets.all(12),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
                    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide(color: _d1Purple)),
                    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
                  ),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _running ? null : () => _run(_sqlCtrl.text),
                    icon: _running
                        ? const SizedBox(width: 16, height: 16,
                            child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                        : const Icon(Icons.play_arrow_rounded),
                    label: Text(_running ? 'Running...' : 'Run Query'),
                    style: ElevatedButton.styleFrom(
                        backgroundColor: _d1Purple, foregroundColor: Colors.white),
                  ),
                ),
              ],
            ),
          ),
          if (_meta != null)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              color: _d1Purple.withOpacity(0.08),
              child: Text(
                'Rows: ${_meta!['rows_read'] ?? 0} read, '
                '${_meta!['rows_written'] ?? 0} written  •  '
                '${_meta!['duration']?.toStringAsFixed(2) ?? '?'} ms',
                style: const TextStyle(color: _d1Purple, fontSize: 11),
              ),
            ),
          if (_err != null)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              margin: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.red.withOpacity(0.08),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.red.withOpacity(0.4)),
              ),
              child: Text(_err!, style: const TextStyle(color: Colors.red, fontSize: 12.5)),
            ),
          if (_rows != null && _cols != null)
            Expanded(
              child: _rows!.isEmpty
                  ? const Center(child: Text('Query returned no rows',
                      style: TextStyle(color: _textDim)))
                  : SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: SingleChildScrollView(
                        padding: EdgeInsets.all(16),
                        child: DataTable(
                          headingRowColor: WidgetStateProperty.all(_cardBg),
                          dataRowColor: WidgetStateProperty.all(ThemeProvider().current.scaffoldBg),
                          headingTextStyle: TextStyle(
                              color: _d1Purple, fontWeight: FontWeight.w700, fontSize: 12),
                          dataTextStyle: TextStyle(color: Colors.white, fontSize: 12),
                          border: TableBorder.all(color: ThemeProvider().current.surfaceColor, width: 0.5),
                          columns: _cols!.map((c) => DataColumn(label: Text(c))).toList(),
                          rows: _rows!.map((row) => DataRow(
                            cells: _cols!.map((c) => DataCell(
                              Text(row[c]?.toString() ?? 'null',
                                  style: row[c] == null
                                      ? const TextStyle(color: _textDim, fontStyle: FontStyle.italic)
                                      : null),
                            )).toList(),
                          )).toList(),
                        ),
                      ),
                    ),
            ),
          if (_rows == null && !_running && _err == null)
            Expanded(
              child: Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.table_chart_rounded, color: _d1Purple.withOpacity(0.3), size: 56),
                  const SizedBox(height: 12),
                  const Text('Enter a SQL query and press Run',
                      style: TextStyle(color: _textDim, fontSize: 13)),
                ]),
              ),
            ),
        ],
      ),
    );
  }
}

// ─── R2 ──────────────────────────────────────────────────────────────────────

class _R2View extends StatefulWidget {
  final CfApi api;
  final String accountId;
  const _R2View({required this.api, required this.accountId});
  @override
  State<_R2View> createState() => _R2ViewState();
}

class _R2ViewState extends State<_R2View> {
  List<dynamic> _buckets = [];
  bool _loading = true;
  String? _err;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.listR2Buckets(widget.accountId);
    if (!mounted) return;
    setState(() {
      _loading = false;
      if (r.ok) _buckets = (r.data['result']?['buckets'] as List?) ?? (r.data['result'] as List?) ?? [];
      else _err = r.error;
    });
  }

  Future<void> _create() async {
    final name = await _inputDialog(context, 'New R2 Bucket', 'Bucket name', color: _r2Teal);
    if (name == null || name.isEmpty) return;
    final r = await widget.api.createR2Bucket(widget.accountId, name);
    if (!mounted) return;
    _stSnack(context, r.ok ? 'Bucket created' : (r.error ?? 'Failed'), !r.ok, _r2Teal);
    if (r.ok) _load();
  }

  Future<void> _delete(Map bucket) async {
    final ok = await _confirmDialog(context, 'Delete Bucket',
        'Delete "${bucket['name']}"? This is irreversible.');
    if (!ok) return;
    final r = await widget.api.deleteR2Bucket(widget.accountId, bucket['name'] as String);
    if (!mounted) return;
    _stSnack(context, r.ok ? 'Deleted' : (r.error ?? 'Failed'), !r.ok, _r2Teal);
    if (r.ok) _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeProvider().current.scaffoldBg,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _create,
        backgroundColor: _r2Teal,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add_rounded),
        label: const Text('New Bucket'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: _r2Teal))
          : _err != null
              ? _stErrView(_err!, _r2Teal, _load, scope: 'R2 Storage:Edit')
              : _buckets.isEmpty
                  ? const Center(child: Text('No R2 buckets', style: TextStyle(color: _textDim)))
                  : RefreshIndicator(
                      onRefresh: _load,
                      color: _r2Teal,
                      child: ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
                        itemCount: _buckets.length,
                        itemBuilder: (_, i) {
                          final b = _buckets[i] as Map;
                          final name = b['name'] as String? ?? '—';
                          final location = b['location'] as String? ?? '';
                          final created = b['creation_date'] as String? ?? '';
                          return _stCard(
                            color: _r2Teal,
                            icon: Icons.cloud_queue_rounded,
                            title: name,
                            subtitle: [if (location.isNotEmpty) location, if (created.isNotEmpty) created].join('  •  '),
                            trailing: IconButton(
                                icon: const Icon(Icons.delete_rounded, color: Colors.red, size: 20),
                                onPressed: () => _delete(b)),
                            onTap: () => Navigator.push(context,
                                MaterialPageRoute(builder: (_) => _R2BucketScreen(
                                    api: widget.api,
                                    accountId: widget.accountId,
                                    name: name))),
                          );
                        },
                      ),
                    ),
    );
  }
}

class _R2BucketScreen extends StatefulWidget {
  final CfApi api;
  final String accountId;
  final String name;
  const _R2BucketScreen({required this.api, required this.accountId, required this.name});
  @override
  State<_R2BucketScreen> createState() => _R2BucketScreenState();
}

class _R2BucketScreenState extends State<_R2BucketScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tab;
  @override
  void initState() { super.initState(); _tab = TabController(length: 2, vsync: this); }
  @override
  void dispose() { _tab.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeProvider().current.scaffoldBg,
      appBar: AppBar(
        backgroundColor: _cardBg,
        foregroundColor: Colors.white,
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          const Text('Bucket Settings', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
          Text(widget.name, style: const TextStyle(color: _r2Teal, fontSize: 11)),
        ]),
        bottom: TabBar(
          controller: _tab,
          labelColor: _r2Teal,
          unselectedLabelColor: _textDim,
          indicatorColor: _r2Teal,
          tabs: const [
            Tab(icon: Icon(Icons.security_rounded, size: 18), text: 'CORS Rules'),
            Tab(icon: Icon(Icons.recycling_rounded, size: 18), text: 'Lifecycle'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tab,
        children: [
          _R2CorsTab(api: widget.api, accountId: widget.accountId, bucketName: widget.name),
          _R2LifecycleTab(api: widget.api, accountId: widget.accountId, bucketName: widget.name),
        ],
      ),
    );
  }
}

class _R2CorsTab extends StatefulWidget {
  final CfApi api;
  final String accountId;
  final String bucketName;
  const _R2CorsTab({required this.api, required this.accountId, required this.bucketName});
  @override
  State<_R2CorsTab> createState() => _R2CorsTabState();
}

class _R2CorsTabState extends State<_R2CorsTab> {
  List<dynamic> _rules = [];
  bool _loading = true;
  bool _saving = false;
  String? _err;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.getR2BucketCors(widget.accountId, widget.bucketName);
    if (!mounted) return;
    setState(() {
      _loading = false;
      if (r.ok) _rules = (r.data['result'] as List?) ?? [];
      else if ((r.error ?? '').contains('404') || (r.error ?? '').contains('not found')) _rules = [];
      else _err = r.error;
    });
  }

  Future<void> _addRule() async {
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (_) => const _R2CorsDialog(),
    );
    if (result == null) return;
    final newRules = [..._rules, result];
    setState(() => _saving = true);
    final r = await widget.api.putR2BucketCors(widget.accountId, widget.bucketName, newRules);
    if (!mounted) return;
    setState(() => _saving = false);
    _stSnack(context, r.ok ? 'CORS rule added' : (r.error ?? 'Failed'), !r.ok, _r2Teal);
    if (r.ok) _load();
  }

  Future<void> _deleteAll() async {
    final ok = await _confirmDialog(context, 'Delete All CORS Rules', 'Remove all CORS rules for this bucket?');
    if (!ok) return;
    setState(() => _saving = true);
    final r = await widget.api.deleteR2BucketCors(widget.accountId, widget.bucketName);
    if (!mounted) return;
    setState(() => _saving = false);
    _stSnack(context, r.ok ? 'CORS rules cleared' : (r.error ?? 'Failed'), !r.ok, _r2Teal);
    if (r.ok) _load();
  }

  Future<void> _deleteRule(int index) async {
    final newRules = [..._rules]..removeAt(index);
    setState(() => _saving = true);
    final r = await widget.api.putR2BucketCors(widget.accountId, widget.bucketName, newRules);
    if (!mounted) return;
    setState(() => _saving = false);
    _stSnack(context, r.ok ? 'Rule deleted' : (r.error ?? 'Failed'), !r.ok, _r2Teal);
    if (r.ok) _load();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: _r2Teal));
    if (_err != null) return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      Text(_err!, style: const TextStyle(color: Colors.red, fontSize: 13)),
      TextButton(onPressed: _load, child: const Text('Retry', style: TextStyle(color: _r2Teal))),
    ]));
    return Stack(children: [
      _rules.isEmpty
          ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.security_rounded, color: _r2Teal.withOpacity(0.3), size: 52),
              const SizedBox(height: 12),
              const Text('No CORS rules', style: TextStyle(color: _textDim)),
            ]))
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
              itemCount: _rules.length,
              itemBuilder: (_, i) {
                final rule = _rules[i] as Map;
                final origins = (rule['AllowedOrigins'] as List?)?.join(', ') ?? '*';
                final methods = (rule['AllowedMethods'] as List?)?.join(', ') ?? '';
                final maxAge = rule['MaxAgeSeconds'];
                final corsHeaders = (rule['AllowedHeaders'] as List?)?.join(', ') ?? '';
                return Container(
                  margin: EdgeInsets.symmetric(vertical: 5),
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _cardBg,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: ThemeProvider().current.surfaceColor),
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      const Icon(Icons.security_rounded, color: _r2Teal, size: 16),
                      const SizedBox(width: 6),
                      const Text('Rule', style: TextStyle(color: _r2Teal, fontWeight: FontWeight.w700, fontSize: 12)),
                      const Spacer(),
                      IconButton(icon: const Icon(Icons.delete_rounded, color: Colors.red, size: 18),
                          onPressed: _saving ? null : () => _deleteRule(i), padding: EdgeInsets.zero,
                          constraints: const BoxConstraints()),
                    ]),
                    const SizedBox(height: 6),
                    _r2InfoRow('Origins', origins),
                    _r2InfoRow('Methods', methods),
                    if (maxAge != null) _r2InfoRow('Max Age', '$maxAge s'),
                    if (corsHeaders.isNotEmpty) _r2InfoRow('Allowed Headers', corsHeaders),
                  ]),
                );
              }),
      Positioned(
        right: 16, bottom: 16,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (_rules.isNotEmpty)
              FloatingActionButton.small(
                heroTag: 'cors_del',
                onPressed: _saving ? null : _deleteAll,
                backgroundColor: Colors.red.shade700,
                foregroundColor: Colors.white,
                child: const Icon(Icons.delete_sweep_rounded),
              ),
            const SizedBox(height: 8),
            FloatingActionButton(
              heroTag: 'cors_add',
              onPressed: _saving ? null : _addRule,
              backgroundColor: _r2Teal,
              foregroundColor: Colors.white,
              child: const Icon(Icons.add_rounded),
            ),
          ],
        ),
      ),
      if (_saving)
        const Positioned.fill(
          child: ColoredBox(color: Color(0x44000000),
              child: Center(child: CircularProgressIndicator(color: _r2Teal)))),
    ]);
  }

  Widget _r2InfoRow(String label, String value) => Padding(
    padding: const EdgeInsets.only(bottom: 3),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      SizedBox(width: 110,
          child: Text('$label:', style: const TextStyle(color: _textDim, fontSize: 11.5))),
      Expanded(child: Text(value, style: const TextStyle(color: Colors.white, fontSize: 11.5))),
    ]),
  );
}

class _R2CorsDialog extends StatefulWidget {
  const _R2CorsDialog();
  @override
  State<_R2CorsDialog> createState() => _R2CorsDialogState();
}

class _R2CorsDialogState extends State<_R2CorsDialog> {
  final _originsCtrl = TextEditingController(text: '*');
  final _headersCtrl = TextEditingController(text: '*');
  final _exposeCtrl  = TextEditingController();
  final _maxAgeCtrl  = TextEditingController(text: '3600');
  final Set<String> _methods = {'GET', 'HEAD'};

  @override
  void dispose() {
    _originsCtrl.dispose(); _headersCtrl.dispose();
    _exposeCtrl.dispose(); _maxAgeCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: _cardBg,
      title: const Text('Add CORS Rule', style: TextStyle(color: Colors.white, fontSize: 15)),
      content: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          _corsField(_originsCtrl, 'Allowed Origins (comma-separated)'),
          const SizedBox(height: 8),
          const Text('Methods', style: TextStyle(color: _textDim, fontSize: 12)),
          const SizedBox(height: 4),
          Wrap(spacing: 6, children: ['GET','HEAD','PUT','POST','DELETE','PATCH'].map((m) {
            final sel = _methods.contains(m);
            return FilterChip(
              label: Text(m, style: TextStyle(color: sel ? Colors.white : _textDim, fontSize: 11)),
              selected: sel,
              onSelected: (_) => setState(() => sel ? _methods.remove(m) : _methods.add(m)),
              selectedColor: _r2Teal.withOpacity(0.3),
              backgroundColor: ThemeProvider().current.scaffoldBg,
              side: BorderSide(color: sel ? _r2Teal : ThemeProvider().current.surfaceColor),
              checkmarkColor: _r2Teal,
              padding: const EdgeInsets.symmetric(horizontal: 4),
            );
          }).toList()),
          const SizedBox(height: 8),
          _corsField(_headersCtrl, 'Allowed Headers'),
          const SizedBox(height: 8),
          _corsField(_exposeCtrl, 'Expose Headers (comma-separated, optional)'),
          const SizedBox(height: 8),
          _corsField(_maxAgeCtrl, 'Max Age (seconds)'),
        ]),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel', style: TextStyle(color: _textDim))),
        ElevatedButton(
          onPressed: () {
            final origins = _originsCtrl.text.trim().split(',').map((s) => s.trim()).where((s) => s.isNotEmpty).toList();
            final headers = _headersCtrl.text.trim().split(',').map((s) => s.trim()).where((s) => s.isNotEmpty).toList();
            final expose  = _exposeCtrl.text.trim().split(',').map((s) => s.trim()).where((s) => s.isNotEmpty).toList();
            final maxAge  = int.tryParse(_maxAgeCtrl.text.trim()) ?? 3600;
            final rule = <String, dynamic>{
              'AllowedOrigins': origins,
              'AllowedMethods': _methods.toList(),
              if (headers.isNotEmpty) 'AllowedHeaders': headers,
              if (expose.isNotEmpty) 'ExposeHeaders': expose,
              'MaxAgeSeconds': maxAge,
            };
            Navigator.pop(context, rule);
          },
          style: ElevatedButton.styleFrom(backgroundColor: _r2Teal, foregroundColor: Colors.white),
          child: const Text('Add'),
        ),
      ],
    );
  }

  Widget _corsField(TextEditingController ctrl, String hint) => TextField(
    controller: ctrl,
    style: TextStyle(color: Colors.white, fontSize: 12.5),
    decoration: InputDecoration(
      hintText: hint, hintStyle: TextStyle(color: _textDim, fontSize: 11.5),
      filled: true, fillColor: ThemeProvider().current.scaffoldBg,
      contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: _r2Teal)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
    ),
  );
}

class _R2LifecycleTab extends StatefulWidget {
  final CfApi api;
  final String accountId;
  final String bucketName;
  const _R2LifecycleTab({required this.api, required this.accountId, required this.bucketName});
  @override
  State<_R2LifecycleTab> createState() => _R2LifecycleTabState();
}

class _R2LifecycleTabState extends State<_R2LifecycleTab> {
  List<dynamic> _rules = [];
  bool _loading = true;
  bool _saving = false;
  String? _err;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.getR2BucketLifecycle(widget.accountId, widget.bucketName);
    if (!mounted) return;
    setState(() {
      _loading = false;
      if (r.ok) _rules = (r.data['result'] as List?) ?? [];
      else if ((r.error ?? '').contains('404') || (r.error ?? '').contains('not found')) _rules = [];
      else _err = r.error;
    });
  }

  Future<void> _addRule() async {
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (_) => const _R2LifecycleDialog(),
    );
    if (result == null) return;
    final newRules = [..._rules, result];
    setState(() => _saving = true);
    final r = await widget.api.putR2BucketLifecycle(widget.accountId, widget.bucketName, newRules);
    if (!mounted) return;
    setState(() => _saving = false);
    _stSnack(context, r.ok ? 'Lifecycle rule added' : (r.error ?? 'Failed'), !r.ok, _r2Teal);
    if (r.ok) _load();
  }

  Future<void> _deleteRule(int index) async {
    final newRules = [..._rules]..removeAt(index);
    setState(() => _saving = true);
    final r = newRules.isEmpty
        ? await widget.api.deleteR2BucketLifecycle(widget.accountId, widget.bucketName)
        : await widget.api.putR2BucketLifecycle(widget.accountId, widget.bucketName, newRules);
    if (!mounted) return;
    setState(() => _saving = false);
    _stSnack(context, r.ok ? 'Rule deleted' : (r.error ?? 'Failed'), !r.ok, _r2Teal);
    if (r.ok) _load();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: _r2Teal));
    if (_err != null) return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      Text(_err!, style: const TextStyle(color: Colors.red, fontSize: 13)),
      TextButton(onPressed: _load, child: const Text('Retry', style: TextStyle(color: _r2Teal))),
    ]));
    return Stack(children: [
      _rules.isEmpty
          ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.recycling_rounded, color: _r2Teal.withOpacity(0.3), size: 52),
              const SizedBox(height: 12),
              const Text('No lifecycle rules', style: TextStyle(color: _textDim)),
            ]))
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
              itemCount: _rules.length,
              itemBuilder: (_, i) {
                final rule = _rules[i] as Map;
                final id = rule['id'] as String? ?? 'Rule ${i + 1}';
                final prefix = rule['prefix'] as String? ?? '';
                final exp = rule['expiration'] as Map?;
                final days = exp?['days'];
                final date = exp?['date'];
                final abortIncompleteDays = rule['abort_incomplete_multipart_upload']?['days_after_initiation'];
                return Container(
                  margin: EdgeInsets.symmetric(vertical: 5),
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _cardBg, borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: ThemeProvider().current.surfaceColor),
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      const Icon(Icons.recycling_rounded, color: _r2Teal, size: 16),
                      const SizedBox(width: 6),
                      Expanded(child: Text(id,
                          style: const TextStyle(color: _r2Teal, fontWeight: FontWeight.w700, fontSize: 12))),
                      IconButton(icon: const Icon(Icons.delete_rounded, color: Colors.red, size: 18),
                          onPressed: _saving ? null : () => _deleteRule(i), padding: EdgeInsets.zero,
                          constraints: const BoxConstraints()),
                    ]),
                    const SizedBox(height: 6),
                    if (prefix.isNotEmpty) _lcRow('Prefix', prefix),
                    if (days != null) _lcRow('Expire after', '$days days'),
                    if (date != null) _lcRow('Expire on', '$date'),
                    if (abortIncompleteDays != null) _lcRow('Abort incomplete after', '$abortIncompleteDays days'),
                  ]),
                );
              }),
      Positioned(
        right: 16, bottom: 16,
        child: FloatingActionButton(
          heroTag: 'lc_add',
          onPressed: _saving ? null : _addRule,
          backgroundColor: _r2Teal, foregroundColor: Colors.white,
          child: const Icon(Icons.add_rounded),
        ),
      ),
      if (_saving)
        const Positioned.fill(
          child: ColoredBox(color: Color(0x44000000),
              child: Center(child: CircularProgressIndicator(color: _r2Teal)))),
    ]);
  }

  Widget _lcRow(String label, String value) => Padding(
    padding: const EdgeInsets.only(bottom: 3),
    child: Row(children: [
      SizedBox(width: 130, child: Text('$label:', style: const TextStyle(color: _textDim, fontSize: 11.5))),
      Expanded(child: Text(value, style: const TextStyle(color: Colors.white, fontSize: 11.5))),
    ]),
  );
}

class _R2LifecycleDialog extends StatefulWidget {
  const _R2LifecycleDialog();
  @override
  State<_R2LifecycleDialog> createState() => _R2LifecycleDialogState();
}

class _R2LifecycleDialogState extends State<_R2LifecycleDialog> {
  final _idCtrl     = TextEditingController();
  final _prefixCtrl = TextEditingController();
  final _daysCtrl   = TextEditingController();
  final _abortCtrl  = TextEditingController();

  @override
  void dispose() {
    _idCtrl.dispose(); _prefixCtrl.dispose();
    _daysCtrl.dispose(); _abortCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: _cardBg,
      title: const Text('Add Lifecycle Rule', style: TextStyle(color: Colors.white, fontSize: 15)),
      content: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          _lcField(_idCtrl, 'Rule ID'),
          const SizedBox(height: 8),
          _lcField(_prefixCtrl, 'Prefix (empty = all objects)'),
          const SizedBox(height: 8),
          _lcField(_daysCtrl, 'Expire after N days', keyboard: TextInputType.number),
          const SizedBox(height: 8),
          _lcField(_abortCtrl, 'Abort incomplete uploads after N days', keyboard: TextInputType.number),
        ]),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel', style: TextStyle(color: _textDim))),
        ElevatedButton(
          onPressed: () {
            final days = int.tryParse(_daysCtrl.text.trim());
            final abortDays = int.tryParse(_abortCtrl.text.trim());
            final rule = <String, dynamic>{
              'id': _idCtrl.text.trim().isEmpty ? 'rule-${DateTime.now().millisecondsSinceEpoch}' : _idCtrl.text.trim(),
              'status': 'enabled',
              if (_prefixCtrl.text.trim().isNotEmpty) 'prefix': _prefixCtrl.text.trim(),
              if (days != null) 'expiration': {'days': days},
              if (abortDays != null) 'abort_incomplete_multipart_upload': {'days_after_initiation': abortDays},
            };
            Navigator.pop(context, rule);
          },
          style: ElevatedButton.styleFrom(backgroundColor: _r2Teal, foregroundColor: Colors.white),
          child: const Text('Add'),
        ),
      ],
    );
  }

  Widget _lcField(TextEditingController ctrl, String hint, {TextInputType? keyboard}) => TextField(
    controller: ctrl,
    keyboardType: keyboard,
    style: TextStyle(color: Colors.white, fontSize: 12.5),
    decoration: InputDecoration(
      hintText: hint, hintStyle: TextStyle(color: _textDim, fontSize: 11.5),
      filled: true, fillColor: ThemeProvider().current.scaffoldBg,
      contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: _r2Teal)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
    ),
  );
}

// ─── Queues ───────────────────────────────────────────────────────────────────

class _QueueView extends StatefulWidget {
  final CfApi api;
  final String accountId;
  const _QueueView({required this.api, required this.accountId});
  @override
  State<_QueueView> createState() => _QueueViewState();
}

class _QueueViewState extends State<_QueueView> {
  List<dynamic> _queues = [];
  bool _loading = true;
  String? _err;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.listQueues(widget.accountId);
    if (!mounted) return;
    setState(() {
      _loading = false;
      if (r.ok) _queues = (r.data['result'] as List?) ?? [];
      else _err = r.error;
    });
  }

  Future<void> _create() async {
    final name = await _inputDialog(context, 'New Queue', 'Queue name', color: _qAmber);
    if (name == null || name.isEmpty) return;
    final r = await widget.api.createQueue(widget.accountId, name);
    if (!mounted) return;
    _stSnack(context, r.ok ? 'Queue created' : (r.error ?? 'Failed'), !r.ok, _qAmber);
    if (r.ok) _load();
  }

  Future<void> _delete(Map q) async {
    final ok = await _confirmDialog(context, 'Delete Queue', 'Delete "${q['queue_name']}"?');
    if (!ok) return;
    final r = await widget.api.deleteQueue(widget.accountId, q['queue_id'] as String);
    if (!mounted) return;
    _stSnack(context, r.ok ? 'Deleted' : (r.error ?? 'Failed'), !r.ok, _qAmber);
    if (r.ok) _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeProvider().current.scaffoldBg,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _create,
        backgroundColor: _qAmber,
        foregroundColor: Colors.black,
        icon: const Icon(Icons.add_rounded),
        label: const Text('New Queue'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: _qAmber))
          : _err != null
              ? _stErrView(_err!, _qAmber, _load, scope: 'Queues:Edit')
              : _queues.isEmpty
                  ? const Center(child: Text('No queues', style: TextStyle(color: _textDim)))
                  : RefreshIndicator(
                      onRefresh: _load,
                      color: _qAmber,
                      child: ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
                        itemCount: _queues.length,
                        itemBuilder: (_, i) {
                          final q = _queues[i] as Map;
                          final name = q['queue_name'] as String? ?? '—';
                          final id = q['queue_id'] as String? ?? '';
                          final producers = q['producers_total_count'] ?? q['producers']?.length ?? 0;
                          final consumers = q['consumers_total_count'] ?? q['consumers']?.length ?? 0;
                          return _stCard(
                            color: _qAmber,
                            icon: Icons.queue_rounded,
                            title: name,
                            subtitle: '$producers producers  •  $consumers consumers',
                            trailing: IconButton(
                                icon: const Icon(Icons.delete_rounded, color: Colors.red, size: 20),
                                onPressed: () => _delete(q)),
                            onTap: () => Navigator.push(context,
                                MaterialPageRoute(builder: (_) => _QueueDetailScreen(
                                    api: widget.api,
                                    accountId: widget.accountId,
                                    queueId: id,
                                    queueName: name))),
                          );
                        },
                      ),
                    ),
    );
  }
}

class _QueueDetailScreen extends StatefulWidget {
  final CfApi api;
  final String accountId;
  final String queueId;
  final String queueName;
  const _QueueDetailScreen({required this.api, required this.accountId,
      required this.queueId, required this.queueName});
  @override
  State<_QueueDetailScreen> createState() => _QueueDetailScreenState();
}

class _QueueDetailScreenState extends State<_QueueDetailScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tab;
  @override
  void initState() { super.initState(); _tab = TabController(length: 3, vsync: this); }
  @override
  void dispose() { _tab.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeProvider().current.scaffoldBg,
      appBar: AppBar(
        backgroundColor: _cardBg,
        foregroundColor: Colors.white,
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          const Text('Queue', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
          Text(widget.queueName, style: const TextStyle(color: _qAmber, fontSize: 11)),
        ]),
        bottom: TabBar(
          controller: _tab,
          labelColor: _qAmber,
          unselectedLabelColor: _textDim,
          indicatorColor: _qAmber,
          tabs: const [
            Tab(icon: Icon(Icons.people_rounded, size: 18), text: 'Consumers'),
            Tab(icon: Icon(Icons.send_rounded, size: 18), text: 'Send'),
            Tab(icon: Icon(Icons.inbox_rounded, size: 18), text: 'Pull'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tab,
        children: [
          _QueueConsumersTab(api: widget.api, accountId: widget.accountId, queueId: widget.queueId, queueName: widget.queueName),
          _QueueSendTab(api: widget.api, accountId: widget.accountId, queueId: widget.queueId),
          _QueuePullTab(api: widget.api, accountId: widget.accountId, queueId: widget.queueId),
        ],
      ),
    );
  }
}

class _QueueConsumersTab extends StatefulWidget {
  final CfApi api;
  final String accountId;
  final String queueId;
  final String queueName;
  const _QueueConsumersTab({required this.api, required this.accountId,
      required this.queueId, required this.queueName});
  @override
  State<_QueueConsumersTab> createState() => _QueueConsumersTabState();
}

class _QueueConsumersTabState extends State<_QueueConsumersTab> {
  List<dynamic> _consumers = [];
  bool _loading = true;
  String? _err;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.listQueueConsumers(widget.accountId, widget.queueId);
    if (!mounted) return;
    setState(() {
      _loading = false;
      if (r.ok) _consumers = (r.data['result'] as List?) ?? [];
      else _err = r.error;
    });
  }

  Future<void> _addConsumer() async {
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (_) => _QueueConsumerDialog(queueName: widget.queueName),
    );
    if (result == null || !mounted) return;
    final r = await widget.api.createQueueConsumer(widget.accountId, widget.queueId, result);
    if (!mounted) return;
    _stSnack(context, r.ok ? 'Consumer added' : (r.error ?? 'Failed'), !r.ok, _qAmber);
    if (r.ok) _load();
  }

  Future<void> _deleteConsumer(Map c) async {
    final consumerId = c['consumer_id'] as String? ?? c['service'] as String? ?? '';
    final ok = await _confirmDialog(context, 'Delete Consumer', 'Remove this consumer from the queue?');
    if (!ok || !mounted) return;
    final r = await widget.api.deleteQueueConsumer(widget.accountId, widget.queueId, consumerId);
    if (!mounted) return;
    _stSnack(context, r.ok ? 'Consumer removed' : (r.error ?? 'Failed'), !r.ok, _qAmber);
    if (r.ok) _load();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: _qAmber));
    if (_err != null) return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      Text(_err!, style: const TextStyle(color: Colors.red, fontSize: 13)),
      TextButton(onPressed: _load, child: const Text('Retry', style: TextStyle(color: _qAmber))),
    ]));
    return Stack(children: [
      _consumers.isEmpty
          ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.people_rounded, color: _qAmber.withOpacity(0.3), size: 52),
              const SizedBox(height: 12),
              const Text('No consumers', style: TextStyle(color: _textDim)),
            ]))
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
              itemCount: _consumers.length,
              itemBuilder: (_, i) {
                final c = _consumers[i] as Map;
                final type = c['type'] as String? ?? 'worker';
                final service = c['service'] as String? ?? c['script'] as String? ?? '';
                final env = c['environment'] as String? ?? '';
                final batchSize = c['settings']?['batch_size'];
                final maxRetries = c['settings']?['max_retries'];
                final maxWait = c['settings']?['max_wait_time_ms'];
                return Container(
                  margin: EdgeInsets.symmetric(vertical: 5),
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _cardBg, borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: ThemeProvider().current.surfaceColor),
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                        decoration: BoxDecoration(color: _qAmber.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(5)),
                        child: Text(type, style: const TextStyle(color: _qAmber, fontSize: 10.5, fontWeight: FontWeight.w700)),
                      ),
                      const SizedBox(width: 8),
                      Expanded(child: Text(service,
                          style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600))),
                      IconButton(icon: const Icon(Icons.delete_rounded, color: Colors.red, size: 18),
                          onPressed: () => _deleteConsumer(c), padding: EdgeInsets.zero,
                          constraints: const BoxConstraints()),
                    ]),
                    if (env.isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text('Environment: $env', style: const TextStyle(color: _textDim, fontSize: 11.5)),
                    ],
                    const SizedBox(height: 6),
                    Wrap(spacing: 12, children: [
                      if (batchSize != null) _qBadge('Batch: $batchSize'),
                      if (maxRetries != null) _qBadge('Retries: $maxRetries'),
                      if (maxWait != null) _qBadge('Max wait: ${maxWait}ms'),
                    ]),
                  ]),
                );
              }),
      Positioned(
        right: 16, bottom: 16,
        child: FloatingActionButton(
          heroTag: 'q_cons_add',
          onPressed: _addConsumer,
          backgroundColor: _qAmber, foregroundColor: Colors.black,
          child: const Icon(Icons.add_rounded),
        ),
      ),
    ]);
  }

  Widget _qBadge(String text) => Container(
    padding: EdgeInsets.symmetric(horizontal: 7, vertical: 2),
    decoration: BoxDecoration(color: ThemeProvider().current.scaffoldBg, borderRadius: BorderRadius.circular(5),
        border: Border.all(color: ThemeProvider().current.surfaceColor)),
    child: Text(text, style: const TextStyle(color: _textMid, fontSize: 11)),
  );
}

class _QueueConsumerDialog extends StatefulWidget {
  final String queueName;
  const _QueueConsumerDialog({required this.queueName});
  @override
  State<_QueueConsumerDialog> createState() => _QueueConsumerDialogState();
}

class _QueueConsumerDialogState extends State<_QueueConsumerDialog> {
  String _type = 'worker';
  final _serviceCtrl = TextEditingController();
  final _envCtrl = TextEditingController(text: 'production');
  final _batchCtrl = TextEditingController(text: '10');
  final _retriesCtrl = TextEditingController(text: '3');
  final _waitCtrl = TextEditingController(text: '5000');

  @override
  void dispose() {
    _serviceCtrl.dispose(); _envCtrl.dispose();
    _batchCtrl.dispose(); _retriesCtrl.dispose(); _waitCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: _cardBg,
      title: const Text('Add Consumer', style: TextStyle(color: Colors.white, fontSize: 15)),
      content: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Type', style: TextStyle(color: _textDim, fontSize: 12)),
          const SizedBox(height: 4),
          Row(children: ['worker', 'http_pull'].map((t) {
            final sel = _type == t;
            return Expanded(
              child: GestureDetector(
                onTap: () => setState(() => _type = t),
                child: Container(
                  margin: EdgeInsets.only(right: t == 'worker' ? 6 : 0),
                  padding: EdgeInsets.symmetric(vertical: 8),
                  decoration: BoxDecoration(
                    color: sel ? _qAmber.withOpacity(0.15) : ThemeProvider().current.scaffoldBg,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: sel ? _qAmber : ThemeProvider().current.surfaceColor),
                  ),
                  child: Text(t, textAlign: TextAlign.center,
                      style: TextStyle(color: sel ? _qAmber : _textDim, fontSize: 12, fontWeight: FontWeight.w600)),
                ),
              ),
            );
          }).toList()),
          const SizedBox(height: 10),
          if (_type == 'worker') ...[
            _qField(_serviceCtrl, 'Worker script name'),
            const SizedBox(height: 8),
            _qField(_envCtrl, 'Environment'),
          ],
          const SizedBox(height: 8),
          _qField(_batchCtrl, 'Batch size', keyboard: TextInputType.number),
          const SizedBox(height: 8),
          _qField(_retriesCtrl, 'Max retries', keyboard: TextInputType.number),
          const SizedBox(height: 8),
          _qField(_waitCtrl, 'Max wait (ms)', keyboard: TextInputType.number),
        ]),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel', style: TextStyle(color: _textDim))),
        ElevatedButton(
          onPressed: () {
            final consumer = <String, dynamic>{
              'type': _type,
              if (_type == 'worker') 'script_name': _serviceCtrl.text.trim(),
              if (_type == 'worker') 'environment': _envCtrl.text.trim(),
              'settings': {
                'batch_size': int.tryParse(_batchCtrl.text.trim()) ?? 10,
                'max_retries': int.tryParse(_retriesCtrl.text.trim()) ?? 3,
                'max_wait_time_ms': int.tryParse(_waitCtrl.text.trim()) ?? 5000,
              },
            };
            Navigator.pop(context, consumer);
          },
          style: ElevatedButton.styleFrom(backgroundColor: _qAmber, foregroundColor: Colors.black),
          child: const Text('Add'),
        ),
      ],
    );
  }

  Widget _qField(TextEditingController ctrl, String hint, {TextInputType? keyboard}) => TextField(
    controller: ctrl,
    keyboardType: keyboard,
    style: TextStyle(color: Colors.white, fontSize: 12.5),
    decoration: InputDecoration(
      hintText: hint, hintStyle: TextStyle(color: _textDim, fontSize: 11.5),
      filled: true, fillColor: ThemeProvider().current.scaffoldBg,
      contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: _qAmber)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
    ),
  );
}

class _QueueSendTab extends StatefulWidget {
  final CfApi api;
  final String accountId;
  final String queueId;
  const _QueueSendTab({required this.api, required this.accountId, required this.queueId});
  @override
  State<_QueueSendTab> createState() => _QueueSendTabState();
}

class _QueueSendTabState extends State<_QueueSendTab> {
  final _bodyCtrl = TextEditingController();
  String _contentType = 'text';
  final _delayCtrl = TextEditingController(text: '0');
  bool _sending = false;

  @override
  void dispose() { _bodyCtrl.dispose(); _delayCtrl.dispose(); super.dispose(); }

  Future<void> _send() async {
    if (_bodyCtrl.text.trim().isEmpty) return;
    setState(() => _sending = true);
    dynamic body = _bodyCtrl.text.trim();
    if (_contentType == 'json') {
      try { body = jsonDecode(body); } catch (_) {}
    }
    final delay = int.tryParse(_delayCtrl.text.trim()) ?? 0;
    final r = await widget.api.sendQueueMessages(widget.accountId, widget.queueId, [{
      'body': body,
      'content_type': _contentType,
      if (delay > 0) 'delay_seconds': delay,
    }]);
    if (!mounted) return;
    setState(() => _sending = false);
    _stSnack(context, r.ok ? 'Message sent' : (r.error ?? 'Failed'), !r.ok, _qAmber);
    if (r.ok) _bodyCtrl.clear();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Content Type', style: TextStyle(color: _textDim, fontSize: 12)),
          const SizedBox(height: 6),
          Row(children: ['text', 'json', 'bytes'].map((t) {
            final sel = _contentType == t;
            return Expanded(
              child: GestureDetector(
                onTap: () => setState(() => _contentType = t),
                child: Container(
                  margin: EdgeInsets.only(right: t != 'bytes' ? 6 : 0),
                  padding: EdgeInsets.symmetric(vertical: 7),
                  decoration: BoxDecoration(
                    color: sel ? _qAmber.withOpacity(0.15) : _cardBg,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: sel ? _qAmber : ThemeProvider().current.surfaceColor),
                  ),
                  child: Text(t, textAlign: TextAlign.center,
                      style: TextStyle(color: sel ? _qAmber : _textDim, fontSize: 12)),
                ),
              ),
            );
          }).toList()),
          const SizedBox(height: 14),
          TextField(
            controller: _bodyCtrl,
            maxLines: 8,
            style: const TextStyle(color: Colors.white, fontSize: 13, fontFamily: 'monospace'),
            decoration: InputDecoration(
              hintText: _contentType == 'json' ? '{"key": "value"}' : 'Message body...',
              hintStyle: TextStyle(color: _textDim, fontSize: 12),
              filled: true, fillColor: _cardBg,
              contentPadding: EdgeInsets.all(12),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: _qAmber)),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _delayCtrl,
            keyboardType: TextInputType.number,
            style: const TextStyle(color: Colors.white, fontSize: 13),
            decoration: InputDecoration(
              hintText: 'Delay (seconds, 0 = immediate)',
              hintStyle: TextStyle(color: _textDim, fontSize: 12),
              filled: true, fillColor: _cardBg,
              contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: _qAmber)),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _sending ? null : _send,
              icon: _sending
                  ? const SizedBox(width: 16, height: 16,
                      child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2))
                  : const Icon(Icons.send_rounded),
              label: Text(_sending ? 'Sending...' : 'Send Message'),
              style: ElevatedButton.styleFrom(
                  backgroundColor: _qAmber, foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 14)),
            ),
          ),
        ],
      ),
    );
  }
}

class _QueuePullTab extends StatefulWidget {
  final CfApi api;
  final String accountId;
  final String queueId;
  const _QueuePullTab({required this.api, required this.accountId, required this.queueId});
  @override
  State<_QueuePullTab> createState() => _QueuePullTabState();
}

class _QueuePullTabState extends State<_QueuePullTab> {
  int _batchSize = 10;
  bool _pulling = false;
  bool _acking = false;
  List<Map<String, dynamic>> _messages = [];
  final Set<String> _toAck = {};
  final Set<String> _toRetry = {};

  Future<void> _pull() async {
    setState(() { _pulling = true; _messages = []; _toAck.clear(); _toRetry.clear(); });
    final r = await widget.api.pullQueueMessages(widget.accountId, widget.queueId, batchSize: _batchSize);
    if (!mounted) return;
    setState(() {
      _pulling = false;
      if (r.ok) {
        _messages = ((r.data['result']?['messages'] ?? r.data['result']) as List? ?? [])
            .map((m) => Map<String, dynamic>.from(m as Map)).toList();
      } else {
        _stSnack(context, r.error ?? 'Failed', true, _qAmber);
      }
    });
  }

  Future<void> _ack() async {
    if (_toAck.isEmpty && _toRetry.isEmpty) return;
    setState(() => _acking = true);
    final r = await widget.api.ackQueueMessages(
        widget.accountId, widget.queueId, _toAck.toList(), _toRetry.toList());
    if (!mounted) return;
    setState(() => _acking = false);
    _stSnack(context, r.ok
        ? 'Acked ${_toAck.length}, retried ${_toRetry.length}'
        : (r.error ?? 'Failed'), !r.ok, _qAmber);
    if (r.ok) setState(() { _messages.clear(); _toAck.clear(); _toRetry.clear(); });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          color: _cardBg,
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                const Text('Batch size: ', style: TextStyle(color: _textDim, fontSize: 12)),
                Text('$_batchSize', style: const TextStyle(color: _qAmber, fontSize: 13, fontWeight: FontWeight.w700)),
              ]),
              Slider(
                value: _batchSize.toDouble(),
                min: 1, max: 100, divisions: 99,
                activeColor: _qAmber,
                inactiveColor: ThemeProvider().current.surfaceColor,
                onChanged: (v) => setState(() => _batchSize = v.round()),
              ),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _pulling ? null : _pull,
                  icon: _pulling
                      ? const SizedBox(width: 16, height: 16,
                          child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2))
                      : const Icon(Icons.inbox_rounded),
                  label: Text(_pulling ? 'Pulling...' : 'Pull Messages'),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: _qAmber, foregroundColor: Colors.black),
                ),
              ),
            ],
          ),
        ),
        if (_messages.isNotEmpty) ...[
          Container(
            color: _qAmber.withOpacity(0.08),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(children: [
              Text('${_messages.length} messages pulled',
                  style: const TextStyle(color: _qAmber, fontSize: 12)),
              const Spacer(),
              TextButton(
                onPressed: () => setState(() { _toAck.addAll(_messages.map((m) => m['lease_id'] as String? ?? '')); }),
                child: const Text('Select All Ack', style: TextStyle(color: _qAmber, fontSize: 11)),
              ),
              const SizedBox(width: 8),
              ElevatedButton(
                onPressed: (_toAck.isEmpty && _toRetry.isEmpty) || _acking ? null : _ack,
                style: ElevatedButton.styleFrom(
                    backgroundColor: _qAmber, foregroundColor: Colors.black,
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6)),
                child: _acking
                    ? const SizedBox(width: 14, height: 14,
                        child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2))
                    : const Text('Ack / Retry', style: TextStyle(fontSize: 11)),
              ),
            ]),
          ),
        ],
        Expanded(
          child: _messages.isEmpty && !_pulling
              ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.inbox_rounded, color: _qAmber.withOpacity(0.3), size: 52),
                  const SizedBox(height: 12),
                  const Text('Pull messages from the queue above',
                      style: TextStyle(color: _textDim, fontSize: 13)),
                ]))
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                  itemCount: _messages.length,
                  itemBuilder: (_, i) {
                    final m = _messages[i];
                    final leaseId = m['lease_id'] as String? ?? '';
                    final body = m['body'];
                    final isAck = _toAck.contains(leaseId);
                    final isRetry = _toRetry.contains(leaseId);
                    return Container(
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      padding: EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: isAck ? _qAmber.withOpacity(0.08) : isRetry ? Colors.red.withOpacity(0.08) : _cardBg,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                            color: isAck ? _qAmber.withOpacity(0.5) : isRetry ? Colors.red.withOpacity(0.5) : ThemeProvider().current.surfaceColor),
                      ),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(body is String ? body : const JsonEncoder.withIndent('  ').convert(body),
                            style: const TextStyle(color: Colors.white, fontSize: 12.5, fontFamily: 'monospace'),
                            maxLines: 8, overflow: TextOverflow.ellipsis),
                        const SizedBox(height: 8),
                        Row(children: [
                          _qMsgBtn('Ack', isAck, _qAmber, () => setState(() {
                            if (isAck) _toAck.remove(leaseId); else { _toAck.add(leaseId); _toRetry.remove(leaseId); }
                          })),
                          const SizedBox(width: 8),
                          _qMsgBtn('Retry', isRetry, Colors.orange, () => setState(() {
                            if (isRetry) _toRetry.remove(leaseId); else { _toRetry.add(leaseId); _toAck.remove(leaseId); }
                          })),
                        ]),
                      ]),
                    );
                  }),
        ),
      ],
    );
  }

  Widget _qMsgBtn(String label, bool active, Color color, VoidCallback onTap) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: active ? color.withOpacity(0.2) : ThemeProvider().current.scaffoldBg,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: active ? color : ThemeProvider().current.surfaceColor),
      ),
      child: Text(label, style: TextStyle(color: active ? color : _textDim, fontSize: 11.5, fontWeight: FontWeight.w600)),
    ),
  );
}

// ─── Storage shared helpers ────────────────────────────────────────────────

Widget _stCard({
  required Color color,
  required IconData icon,
  required String title,
  required String subtitle,
  Widget? trailing,
  VoidCallback? onTap,
}) {
  return InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(12),
    child: Container(
      margin: EdgeInsets.symmetric(vertical: 5),
      padding: EdgeInsets.fromLTRB(14, 12, 10, 12),
      decoration: BoxDecoration(
        color: _cardBg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: ThemeProvider().current.surfaceColor),
      ),
      child: Row(children: [
        Container(
          width: 38, height: 38,
          decoration: BoxDecoration(
              color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(9)),
          child: Icon(icon, color: color, size: 20),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title,
                style: const TextStyle(color: Colors.white, fontSize: 13.5, fontWeight: FontWeight.w600),
                overflow: TextOverflow.ellipsis),
            if (subtitle.isNotEmpty)
              Text(subtitle, style: const TextStyle(color: _textDim, fontSize: 11), overflow: TextOverflow.ellipsis),
          ]),
        ),
        if (onTap != null && trailing == null)
          const Icon(Icons.chevron_right_rounded, color: _textDim, size: 22),
        if (trailing != null) trailing,
      ]),
    ),
  );
}

void _stSnack(BuildContext context, String msg, bool isErr, Color color) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    content: Text(msg, style: const TextStyle(color: Colors.white)),
    backgroundColor: isErr ? Colors.red.shade800 : color,
    behavior: SnackBarBehavior.floating,
    duration: const Duration(seconds: 3),
  ));
}

Future<String?> _inputDialog(BuildContext context, String title, String hint,
    {String? initial, required Color color}) async {
  final ctrl = TextEditingController(text: initial ?? '');
  final result = await showDialog<String>(
    context: context,
    builder: (_) => AlertDialog(
      backgroundColor: _cardBg,
      title: Text(title, style: const TextStyle(color: Colors.white, fontSize: 15)),
      content: TextField(
        controller: ctrl,
        autofocus: true,
        style: TextStyle(color: Colors.white, fontSize: 13),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(color: _textDim),
          filled: true, fillColor: ThemeProvider().current.scaffoldBg,
          contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
              borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
              borderSide: BorderSide(color: color)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
              borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
        ),
        onSubmitted: (v) => Navigator.pop(context, v),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel', style: TextStyle(color: _textDim))),
        ElevatedButton(
          onPressed: () => Navigator.pop(context, ctrl.text),
          style: ElevatedButton.styleFrom(backgroundColor: color, foregroundColor: Colors.white),
          child: const Text('OK'),
        ),
      ],
    ),
  );
  ctrl.dispose();
  return result;
}

Future<bool> _confirmDialog(BuildContext context, String title, String body) async {
  final result = await showDialog<bool>(
    context: context,
    builder: (_) => AlertDialog(
      backgroundColor: _cardBg,
      title: Text(title, style: const TextStyle(color: Colors.white, fontSize: 15)),
      content: Text(body, style: const TextStyle(color: _textMid, fontSize: 13)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel', style: TextStyle(color: _textDim))),
        ElevatedButton(
          onPressed: () => Navigator.pop(context, true),
          style: ElevatedButton.styleFrom(backgroundColor: Colors.red.shade700, foregroundColor: Colors.white),
          child: const Text('Confirm'),
        ),
      ],
    ),
  );
  return result ?? false;
}

// ═════════════════════════════════════════════════════════════════════════════
// SHARED WIDGETS
// ═════════════════════════════════════════════════════════════════════════════

class _CfButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onTap;
  final bool loading;
  const _CfButton({
    required this.label,
    this.icon,
    this.onTap,
    this.loading = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: EdgeInsets.symmetric(vertical: 15),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: onTap == null
                ? [ThemeProvider().current.surfaceColor, ThemeProvider().current.surfaceColor]
                : [_cfOrange, const Color(0xFFE8720A)],
          ),
          borderRadius: BorderRadius.circular(14),
          boxShadow: onTap != null
              ? [
                  BoxShadow(
                    color: _cfOrange.withOpacity(0.35),
                    blurRadius: 16,
                    spreadRadius: 0,
                    offset: const Offset(0, 4),
                  )
                ]
              : [],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (loading)
              const SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(
                    strokeWidth: 2, color: Colors.white),
              )
            else if (icon != null)
              Icon(icon, color: Colors.white, size: 20),
            if ((loading || icon != null)) const SizedBox(width: 10),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 15,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CfSearchField extends StatelessWidget {
  final String hint;
  final ValueChanged<String> onChanged;
  final TextEditingController? controller;
  const _CfSearchField({
    required this.hint,
    required this.onChanged,
    this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      decoration: BoxDecoration(
        color: _cardBg,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: ThemeProvider().current.surfaceColor),
      ),
      child: TextField(
        controller: controller,
        onChanged: onChanged,
        style: const TextStyle(color: Colors.white, fontSize: 13.5),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle:
              TextStyle(color: _textDim.withOpacity(0.6), fontSize: 13),
          prefixIcon: const Icon(Icons.search_rounded,
              color: _textDim, size: 18),
          border: InputBorder.none,
          contentPadding: EdgeInsets.zero,
          isDense: true,
        ),
      ),
    );
  }
}

class _CfIconBtn extends StatelessWidget {
  final IconData icon;
  final String tooltip;
  final VoidCallback? onTap;
  const _CfIconBtn(
      {required this.icon, required this.tooltip, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            color: _cardBg,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: ThemeProvider().current.surfaceColor),
          ),
          child: Icon(icon,
              color: onTap != null ? _cfOrange : _textDim, size: 20),
        ),
      ),
    );
  }
}

class _CfField extends StatelessWidget {
  final String label;
  final String hint;
  final TextEditingController controller;
  const _CfField({
    required this.label,
    required this.hint,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: const TextStyle(color: _textMid, fontSize: 12)),
        SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(
            color: _cardBg,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: ThemeProvider().current.surfaceColor),
          ),
          child: TextField(
            controller: controller,
            style: const TextStyle(color: Colors.white, fontSize: 14),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: TextStyle(
                  color: _textDim.withOpacity(0.5), fontSize: 13),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 13),
            ),
          ),
        ),
      ],
    );
  }
}

class _ActionChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color? color;
  const _ActionChip({
    required this.icon,
    required this.label,
    required this.onTap,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final c = color ?? _cfOrange;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding:
            const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: c.withOpacity(0.10),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: c.withOpacity(0.35)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 14, color: c),
            const SizedBox(width: 5),
            Text(label,
                style: TextStyle(
                    color: c,
                    fontSize: 12,
                    fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}

class _InfoBox extends StatelessWidget {
  final List<String> items;
  const _InfoBox({required this.items});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _cfOrange.withOpacity(0.06),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _cfOrange.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: items
            .map((item) => Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Text(
                    item,
                    style: const TextStyle(
                        color: _textMid,
                        fontSize: 12,
                        height: 1.5),
                  ),
                ))
            .toList(),
      ),
    );
  }
}

// ── Loading / Error / Empty ────────────────────────────────────────────────────

class _LoadingView extends StatelessWidget {
  const _LoadingView();
  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          CircularProgressIndicator(color: _cfOrange, strokeWidth: 2.5),
          SizedBox(height: 14),
          Text('Loading...', style: TextStyle(color: _textDim, fontSize: 13)),
        ],
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  final String error;
  final VoidCallback onRetry;
  const _ErrorView({required this.error, required this.onRetry});
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.error_outline_rounded,
                color: Colors.red.shade400, size: 48),
            const SizedBox(height: 12),
            Text(error,
                textAlign: TextAlign.center,
                style: const TextStyle(color: _textDim, fontSize: 13)),
            const SizedBox(height: 16),
            _CfButton(
                label: 'Retry', icon: Icons.refresh_rounded, onTap: onRetry),
          ],
        ),
      ),
    );
  }
}

class _EmptyView extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const _EmptyView(
      {required this.icon, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: _cfOrange.withOpacity(0.4), size: 52),
          const SizedBox(height: 14),
          Text(title,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          Text(subtitle,
              style: const TextStyle(color: _textDim, fontSize: 12.5)),
        ],
      ),
    );
  }
}

// ── Dialogs ────────────────────────────────────────────────────────────────────

class _BusyDialog extends StatelessWidget {
  final String message;
  const _BusyDialog({required this.message});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: _cardBg,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      content: Row(
        children: [
          const CircularProgressIndicator(color: _cfOrange, strokeWidth: 2.5),
          const SizedBox(width: 16),
          Expanded(
            child: Text(message,
                style: const TextStyle(color: Colors.white, fontSize: 14)),
          ),
        ],
      ),
    );
  }
}

class _CfConfirmDialog extends StatelessWidget {
  final String title;
  final String message;
  final String confirmLabel;
  final Color confirmColor;
  const _CfConfirmDialog({
    required this.title,
    required this.message,
    required this.confirmLabel,
    required this.confirmColor,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: _cardBg,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: Text(title,
          style: const TextStyle(
              color: Colors.white, fontWeight: FontWeight.w700)),
      content: Text(message,
          style: const TextStyle(color: _textDim, fontSize: 13.5)),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, false),
          child: const Text('Cancel', style: TextStyle(color: _textDim)),
        ),
        TextButton(
          onPressed: () => Navigator.pop(context, true),
          child: Text(confirmLabel,
              style: TextStyle(
                  color: confirmColor, fontWeight: FontWeight.w700)),
        ),
      ],
    );
  }
}

// ── Shared helpers for Worker sub-screens ─────────────────────────────────────
Widget _workerScaffold({
  required BuildContext context,
  required String title,
  required String workerName,
  required Widget body,
  List<Widget> actions = const [],
  Widget? floatingActionButton,
}) =>
    Scaffold(
      backgroundColor: ThemeProvider().current.scaffoldBg,
      floatingActionButton: floatingActionButton,
      appBar: AppBar(
        backgroundColor: _cardBg,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _textDim, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          Text(title, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
          Text(workerName, style: const TextStyle(color: _workerGreen, fontSize: 11)),
        ]),
        actions: actions,
      ),
      body: body,
    );

// ── Worker Secrets Screen ─────────────────────────────────────────────────────
class _WorkerSecretsScreen extends StatefulWidget {
  final CfApi api;
  final String accountId;
  final String workerName;
  const _WorkerSecretsScreen({required this.api, required this.accountId, required this.workerName});
  @override
  State<_WorkerSecretsScreen> createState() => _WorkerSecretsScreenState();
}

class _WorkerSecretsScreenState extends State<_WorkerSecretsScreen> {
  bool _loading = true;
  String? _err;
  List<Map> _secrets = [];

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.listWorkerSecrets(widget.accountId, widget.workerName);
    if (!mounted) return;
    setState(() {
      _loading = false;
      if (r.ok) _secrets = List<Map>.from(r.data['result'] ?? []);
      else _err = r.error;
    });
  }

  Future<void> _add() async {
    final nameCtrl  = TextEditingController();
    final valueCtrl = TextEditingController();
    bool obscure = true;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(builder: (ctx, ss) => AlertDialog(
        backgroundColor: _cardBg,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: ThemeProvider().current.surfaceColor)),
        title: const Text('Add Secret', style: TextStyle(color: Colors.white, fontSize: 15)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          _CfTextField(ctrl: nameCtrl, hint: 'Variable name  e.g. API_KEY'),
          const SizedBox(height: 10),
          TextField(
            controller: valueCtrl,
            obscureText: obscure,
            style: TextStyle(color: Colors.white, fontSize: 13),
            decoration: InputDecoration(
              hintText: 'Secret value',
              hintStyle: TextStyle(color: _textDim),
              filled: true, fillColor: ThemeProvider().current.scaffoldBg,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _workerGreen)),
              suffixIcon: IconButton(
                icon: Icon(obscure ? Icons.visibility_off_rounded : Icons.visibility_rounded, color: _textDim, size: 18),
                onPressed: () => ss(() => obscure = !obscure),
              ),
            ),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel', style: TextStyle(color: _textDim))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: _workerGreen, foregroundColor: Colors.white, elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Save'),
          ),
        ],
      )),
    );
    if (ok != true || !mounted) return;
    final sName = nameCtrl.text.trim();
    final sVal  = valueCtrl.text;
    if (sName.isEmpty || sVal.isEmpty) return;
    final r = await widget.api.putWorkerSecret(widget.accountId, widget.workerName, sName, sVal);
    if (!mounted) return;
    if (r.ok) { _load(); _snack('Secret "$sName" saved'); }
    else _snack('${r.error}', err: true);
  }

  Future<void> _delete(String name) async {
    final ok = await showDialog<bool>(context: context,
      builder: (_) => _CfConfirmDialog(title: 'Delete Secret', message: 'Remove secret "$name"?', confirmLabel: 'Delete', confirmColor: Colors.red));
    if (ok != true || !mounted) return;
    final r = await widget.api.deleteWorkerSecret(widget.accountId, widget.workerName, name);
    if (!mounted) return;
    if (r.ok) { _load(); _snack('Deleted "$name"'); }
    else _snack('${r.error}', err: true);
  }

  void _snack(String msg, {bool err = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(color: Colors.white)),
      backgroundColor: err ? Colors.red.shade800 : _workerGreen,
    ));
  }

  @override
  Widget build(BuildContext context) => _workerScaffold(
    context: context, title: 'Secrets & Env Vars', workerName: widget.workerName,
    actions: [IconButton(icon: const Icon(Icons.refresh_rounded, color: _textDim), onPressed: _load)],
    floatingActionButton: FloatingActionButton.extended(
      backgroundColor: _workerGreen,
      icon: const Icon(Icons.add_rounded, color: Colors.white),
      label: const Text('Add Secret', style: TextStyle(color: Colors.white)),
      onPressed: _add,
    ),
    body: _loading
      ? const Center(child: CircularProgressIndicator(color: _workerGreen))
      : _err != null
        ? _ErrRetry(message: _err!, onRetry: _load)
        : _secrets.isEmpty
          ? const _EmptyState(icon: Icons.lock_outline_rounded, message: 'No secrets configured.\nAdd encrypted variables your Worker can access.')
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: _secrets.length,
              itemBuilder: (_, i) {
                final s = _secrets[i];
                final name = s['name'] as String? ?? '';
                final type = s['type'] as String? ?? 'secret_text';
                return Container(
                  margin: EdgeInsets.only(bottom: 8),
                  padding: EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                  decoration: BoxDecoration(color: _cardBg, borderRadius: BorderRadius.circular(12), border: Border.all(color: ThemeProvider().current.surfaceColor)),
                  child: Row(children: [
                    const Icon(Icons.lock_rounded, color: _workerGreen, size: 18),
                    const SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(name, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
                      Text(type, style: const TextStyle(color: _textDim, fontSize: 11)),
                    ])),
                    IconButton(icon: Icon(Icons.delete_outline_rounded, color: Colors.red.shade400, size: 20),
                        padding: EdgeInsets.zero, constraints: const BoxConstraints(), onPressed: () => _delete(name)),
                  ]),
                );
              },
            ),
  );
}

// ── Worker Bindings Screen ────────────────────────────────────────────────────
class _WorkerBindingsScreen extends StatefulWidget {
  final CfApi api;
  final String accountId;
  final String workerName;
  const _WorkerBindingsScreen({required this.api, required this.accountId, required this.workerName});
  @override
  State<_WorkerBindingsScreen> createState() => _WorkerBindingsScreenState();
}

class _WorkerBindingsScreenState extends State<_WorkerBindingsScreen> {
  bool _loading = true;
  String? _err;
  List<Map<String, dynamic>> _bindings = [];

  static const _bindingTypes = [
    ('kv_namespace',      'KV Namespace',        Icons.storage_rounded),
    ('r2_bucket',         'R2 Bucket',           Icons.cloud_rounded),
    ('d1',                'D1 Database',          Icons.table_chart_rounded),
    ('queue',             'Queue',               Icons.queue_rounded),
    ('plain_text',        'Plain Text Var',      Icons.text_fields_rounded),
    ('json',              'JSON Var',            Icons.data_object_rounded),
    ('ai',                'Workers AI',          Icons.psychology_rounded),
    ('service',           'Service Binding',     Icons.miscellaneous_services_rounded),
    ('dispatch_namespace','Dispatch Namespace',  Icons.hub_rounded),
  ];

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.getWorkerSettings(widget.accountId, widget.workerName);
    if (!mounted) return;
    setState(() {
      _loading = false;
      if (r.ok) {
        final res = r.data['result'] as Map? ?? {};
        _bindings = List<Map<String, dynamic>>.from(res['bindings'] ?? []);
      } else {
        _err = r.error;
      }
    });
  }

  String _bindingLabel((String, String, IconData) t) => t.$2;
  IconData _bindingIcon(String type) =>
      _bindingTypes.firstWhere((t) => t.$1 == type, orElse: () => ('', type, Icons.extension_rounded)).$3;

  Future<void> _addBinding() async {
    String selectedType = 'kv_namespace';
    final nameCtrl = TextEditingController();
    final val1Ctrl = TextEditingController();
    final val2Ctrl = TextEditingController();

    final ok = await showDialog<bool>(context: context,
      builder: (ctx) => StatefulBuilder(builder: (ctx, ss) {
        final type = selectedType;
        return AlertDialog(
          backgroundColor: _cardBg,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: ThemeProvider().current.surfaceColor)),
          title: const Text('Add Binding', style: TextStyle(color: Colors.white, fontSize: 15)),
          content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
            DropdownButtonFormField<String>(
              value: selectedType,
              dropdownColor: _cardBg,
              style: TextStyle(color: Colors.white, fontSize: 13),
              decoration: InputDecoration(labelText: 'Binding Type', labelStyle: TextStyle(color: _textDim),
                  filled: true, fillColor: ThemeProvider().current.scaffoldBg,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: ThemeProvider().current.surfaceColor))),
              items: _bindingTypes.map((t) => DropdownMenuItem(value: t.$1,
                  child: Row(children: [Icon(t.$3, color: _workerGreen, size: 16), const SizedBox(width: 8), Text(t.$2)]))).toList(),
              onChanged: (v) { if (v != null) ss(() => selectedType = v); },
            ),
            const SizedBox(height: 10),
            _CfTextField(ctrl: nameCtrl, hint: 'Binding name  e.g. MY_KV'),
            const SizedBox(height: 10),
            if (type == 'kv_namespace') _CfTextField(ctrl: val1Ctrl, hint: 'KV Namespace ID'),
            if (type == 'r2_bucket')    _CfTextField(ctrl: val1Ctrl, hint: 'R2 Bucket name'),
            if (type == 'd1')           _CfTextField(ctrl: val1Ctrl, hint: 'D1 Database ID'),
            if (type == 'queue')        _CfTextField(ctrl: val1Ctrl, hint: 'Queue name'),
            if (type == 'plain_text')   _CfTextField(ctrl: val1Ctrl, hint: 'Text value'),
            if (type == 'json')         _CfTextField(ctrl: val1Ctrl, hint: 'JSON value  e.g. {"key":"value"}'),
            if (type == 'service') ...[
              _CfTextField(ctrl: val1Ctrl, hint: 'Service worker name'),
              const SizedBox(height: 10),
              _CfTextField(ctrl: val2Ctrl, hint: 'Environment  (default: production)'),
            ],
            if (type == 'dispatch_namespace') _CfTextField(ctrl: val1Ctrl, hint: 'Dispatch Namespace ID'),
          ])),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel', style: TextStyle(color: _textDim))),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: _workerGreen, foregroundColor: Colors.white, elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Add'),
            ),
          ],
        );
      }),
    );
    if (ok != true || !mounted) return;
    final bName = nameCtrl.text.trim();
    if (bName.isEmpty) return;

    Map<String, dynamic> entry = {'type': selectedType, 'name': bName};
    switch (selectedType) {
      case 'kv_namespace':       entry['namespace_id'] = val1Ctrl.text.trim(); break;
      case 'r2_bucket':          entry['bucket_name']  = val1Ctrl.text.trim(); break;
      case 'd1':                 entry['id']           = val1Ctrl.text.trim(); break;
      case 'queue':              entry['queue_name']   = val1Ctrl.text.trim(); break;
      case 'plain_text':         entry['text']         = val1Ctrl.text; break;
      case 'json':
        try { entry['json'] = jsonDecode(val1Ctrl.text.trim()); } catch (_) { entry['json'] = val1Ctrl.text.trim(); }
        break;
      case 'service':
        entry['service']     = val1Ctrl.text.trim();
        entry['environment'] = val2Ctrl.text.trim().isEmpty ? 'production' : val2Ctrl.text.trim();
        break;
      case 'dispatch_namespace': entry['namespace'] = val1Ctrl.text.trim(); break;
    }

    final newBindings = [..._bindings, entry];
    final r = await widget.api.patchWorkerSettings(widget.accountId, widget.workerName, {'bindings': newBindings});
    if (!mounted) return;
    if (r.ok) { _load(); _snack('Binding "$bName" added'); }
    else _snack('${r.error}', err: true);
  }

  Future<void> _removeBinding(int idx) async {
    final b = _bindings[idx];
    final ok = await showDialog<bool>(context: context,
      builder: (_) => _CfConfirmDialog(
        title: 'Remove Binding',
        message: 'Remove binding "${b['name']}"?',
        confirmLabel: 'Remove', confirmColor: Colors.red));
    if (ok != true || !mounted) return;
    final newBindings = [..._bindings]..removeAt(idx);
    final r = await widget.api.patchWorkerSettings(widget.accountId, widget.workerName, {'bindings': newBindings});
    if (!mounted) return;
    if (r.ok) { _load(); _snack('Binding removed'); }
    else _snack('${r.error}', err: true);
  }

  void _snack(String msg, {bool err = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(color: Colors.white)),
      backgroundColor: err ? Colors.red.shade800 : _workerGreen,
    ));
  }

  String _bindingDetail(Map b) {
    switch (b['type']) {
      case 'kv_namespace':       return b['namespace_id'] ?? '';
      case 'r2_bucket':          return b['bucket_name'] ?? '';
      case 'd1':                 return b['id'] ?? '';
      case 'queue':              return b['queue_name'] ?? '';
      case 'plain_text':         return b['text'] ?? '';
      case 'json':               return jsonEncode(b['json'] ?? {});
      case 'service':            return '${b['service']} (${b['environment'] ?? 'production'})';
      case 'dispatch_namespace': return b['namespace'] ?? '';
      case 'ai':                 return 'Workers AI';
      default:                   return '';
    }
  }

  @override
  Widget build(BuildContext context) => _workerScaffold(
    context: context, title: 'Bindings', workerName: widget.workerName,
    actions: [IconButton(icon: const Icon(Icons.refresh_rounded, color: _textDim), onPressed: _load)],
    floatingActionButton: FloatingActionButton.extended(
      backgroundColor: _workerGreen,
      icon: const Icon(Icons.add_rounded, color: Colors.white),
      label: const Text('Add Binding', style: TextStyle(color: Colors.white)),
      onPressed: _addBinding,
    ),
    body: _loading
      ? const Center(child: CircularProgressIndicator(color: _workerGreen))
      : _err != null
        ? _ErrRetry(message: _err!, onRetry: _load)
        : _bindings.isEmpty
          ? const _EmptyState(icon: Icons.link_off_rounded, message: 'No bindings configured.\nAdd KV, R2, D1, Queue, AI and other bindings.')
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: _bindings.length,
              itemBuilder: (_, i) {
                final b = _bindings[i];
                final type = b['type'] as String? ?? '';
                final detail = _bindingDetail(b);
                return Container(
                  margin: EdgeInsets.only(bottom: 8),
                  padding: EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                  decoration: BoxDecoration(color: _cardBg, borderRadius: BorderRadius.circular(12), border: Border.all(color: ThemeProvider().current.surfaceColor)),
                  child: Row(children: [
                    Icon(_bindingIcon(type), color: _workerGreen, size: 20),
                    const SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(b['name'] as String? ?? '', style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
                      Text(type.replaceAll('_', ' '), style: const TextStyle(color: _workerGreen, fontSize: 10.5)),
                      if (detail.isNotEmpty) Text(detail, style: const TextStyle(color: _textDim, fontSize: 11), overflow: TextOverflow.ellipsis),
                    ])),
                    IconButton(icon: Icon(Icons.delete_outline_rounded, color: Colors.red.shade400, size: 20),
                        padding: EdgeInsets.zero, constraints: const BoxConstraints(), onPressed: () => _removeBinding(i)),
                  ]),
                );
              },
            ),
  );
}

// ── Worker Cron Triggers Screen ───────────────────────────────────────────────
class _WorkerCronsScreen extends StatefulWidget {
  final CfApi api;
  final String accountId;
  final String workerName;
  const _WorkerCronsScreen({required this.api, required this.accountId, required this.workerName});
  @override
  State<_WorkerCronsScreen> createState() => _WorkerCronsScreenState();
}

class _WorkerCronsScreenState extends State<_WorkerCronsScreen> {
  bool _loading = true;
  String? _err;
  List<Map<String, dynamic>> _crons = [];

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.getWorkerCrons(widget.accountId, widget.workerName);
    if (!mounted) return;
    setState(() {
      _loading = false;
      if (r.ok) _crons = List<Map<String, dynamic>>.from(r.data['result']?['schedules'] ?? r.data['result'] ?? []);
      else _err = r.error;
    });
  }

  Future<void> _add() async {
    final ctrl = TextEditingController();
    final examples = ['*/5 * * * *', '0 * * * *', '0 9 * * 1', '0 0 * * *'];
    final ok = await showDialog<bool>(context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: _cardBg,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: ThemeProvider().current.surfaceColor)),
        title: const Text('Add Cron Trigger', style: TextStyle(color: Colors.white, fontSize: 15)),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          _CfTextField(ctrl: ctrl, hint: '*/5 * * * *'),
          const SizedBox(height: 12),
          const Text('EXAMPLES', style: TextStyle(color: _textDim, fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1)),
          const SizedBox(height: 6),
          ...examples.map((e) => GestureDetector(
            onTap: () => ctrl.text = e,
            child: Padding(padding: const EdgeInsets.only(bottom: 4),
              child: Text(e, style: const TextStyle(color: _workerGreen, fontSize: 12, fontFamily: 'monospace'))),
          )),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel', style: TextStyle(color: _textDim))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: _workerGreen, foregroundColor: Colors.white, elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Add'),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    final cron = ctrl.text.trim();
    if (cron.isEmpty) return;
    final newCrons = [..._crons, {'cron': cron}];
    final r = await widget.api.putWorkerCrons(widget.accountId, widget.workerName, newCrons);
    if (!mounted) return;
    if (r.ok) { _load(); _snack('Cron trigger added'); }
    else _snack('${r.error}', err: true);
  }

  Future<void> _delete(int idx) async {
    final cron = _crons[idx]['cron'] as String? ?? '';
    final ok = await showDialog<bool>(context: context,
      builder: (_) => _CfConfirmDialog(title: 'Remove Cron', message: 'Remove trigger "$cron"?',
          confirmLabel: 'Remove', confirmColor: Colors.red));
    if (ok != true || !mounted) return;
    final newCrons = [..._crons]..removeAt(idx);
    final r = await widget.api.putWorkerCrons(widget.accountId, widget.workerName, newCrons);
    if (!mounted) return;
    if (r.ok) { _load(); _snack('Cron trigger removed'); }
    else _snack('${r.error}', err: true);
  }

  void _snack(String msg, {bool err = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(color: Colors.white)),
      backgroundColor: err ? Colors.red.shade800 : _workerGreen,
    ));
  }

  @override
  Widget build(BuildContext context) => _workerScaffold(
    context: context, title: 'Cron Triggers', workerName: widget.workerName,
    actions: [IconButton(icon: const Icon(Icons.refresh_rounded, color: _textDim), onPressed: _load)],
    floatingActionButton: FloatingActionButton.extended(
      backgroundColor: _workerGreen,
      icon: const Icon(Icons.add_rounded, color: Colors.white),
      label: const Text('Add Cron', style: TextStyle(color: Colors.white)),
      onPressed: _add,
    ),
    body: _loading
      ? const Center(child: CircularProgressIndicator(color: _workerGreen))
      : _err != null
        ? _ErrRetry(message: _err!, onRetry: _load)
        : _crons.isEmpty
          ? const _EmptyState(icon: Icons.schedule_rounded, message: 'No cron triggers.\nSchedule your Worker to run automatically.')
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: _crons.length,
              itemBuilder: (_, i) {
                final c = _crons[i];
                final cron = c['cron'] as String? ?? '';
                return Container(
                  margin: EdgeInsets.only(bottom: 8),
                  padding: EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                  decoration: BoxDecoration(color: _cardBg, borderRadius: BorderRadius.circular(12), border: Border.all(color: ThemeProvider().current.surfaceColor)),
                  child: Row(children: [
                    const Icon(Icons.schedule_rounded, color: _workerGreen, size: 20),
                    const SizedBox(width: 12),
                    Expanded(child: Text(cron,
                        style: const TextStyle(color: Colors.white, fontSize: 13, fontFamily: 'monospace'))),
                    IconButton(icon: Icon(Icons.delete_outline_rounded, color: Colors.red.shade400, size: 20),
                        padding: EdgeInsets.zero, constraints: const BoxConstraints(), onPressed: () => _delete(i)),
                  ]),
                );
              },
            ),
  );
}

// ── Worker Domains Screen (subdomain + custom domains) ────────────────────────
class _WorkerDomainsScreen extends StatefulWidget {
  final CfApi api;
  final String accountId;
  final String workerName;
  const _WorkerDomainsScreen({required this.api, required this.accountId, required this.workerName});
  @override
  State<_WorkerDomainsScreen> createState() => _WorkerDomainsScreenState();
}

class _WorkerDomainsScreenState extends State<_WorkerDomainsScreen> {
  bool _loading = true;
  bool _busy    = false;
  String? _err;
  List<Map> _domains = [];
  bool _subdomainEnabled = false;
  String _subdomainName  = '';

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final results = await Future.wait([
      widget.api.getWorkerSubdomain(widget.accountId),
      widget.api.listWorkerCustomDomains(widget.accountId, widget.workerName),
    ]);
    if (!mounted) return;
    final subdomain = results[0];
    final customDomains = results[1];
    setState(() {
      _loading = false;
      if (subdomain.ok) {
        final res = subdomain.data['result'] as Map? ?? {};
        _subdomainEnabled = res['enabled'] as bool? ?? false;
        _subdomainName    = res['subdomain'] as String? ?? '';
      }
      if (customDomains.ok) {
        _domains = List<Map>.from(customDomains.data['result'] ?? []);
      } else {
        _err = customDomains.error;
      }
    });
  }

  Future<void> _toggleSubdomain(bool val) async {
    setState(() => _busy = true);
    final r = await widget.api.setWorkerSubdomainEnabled(widget.accountId, widget.workerName, val);
    if (!mounted) return;
    setState(() => _busy = false);
    if (r.ok) { setState(() => _subdomainEnabled = val); _snack(val ? 'Subdomain URL enabled' : 'Subdomain URL disabled'); }
    else _snack('${r.error}', err: true);
  }

  Future<void> _addDomain() async {
    final hostCtrl = TextEditingController();
    final zoneCtrl = TextEditingController();
    final ok = await showDialog<bool>(context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: _cardBg,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: ThemeProvider().current.surfaceColor)),
        title: const Text('Add Custom Domain', style: TextStyle(color: Colors.white, fontSize: 15)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          _CfTextField(ctrl: hostCtrl, hint: 'Hostname  e.g. api.example.com'),
          const SizedBox(height: 10),
          _CfTextField(ctrl: zoneCtrl, hint: 'Zone ID of that domain'),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel', style: TextStyle(color: _textDim))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: _workerGreen, foregroundColor: Colors.white, elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Add'),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    final hostname = hostCtrl.text.trim();
    final zoneId   = zoneCtrl.text.trim();
    if (hostname.isEmpty || zoneId.isEmpty) return;
    final r = await widget.api.addWorkerCustomDomain(widget.accountId, widget.workerName, hostname, zoneId);
    if (!mounted) return;
    if (r.ok) { _load(); _snack('Domain "$hostname" added'); }
    else _snack('${r.error}', err: true);
  }

  Future<void> _deleteDomain(Map d) async {
    final hostname = d['hostname'] as String? ?? '';
    final id = d['id'] as String? ?? '';
    final ok = await showDialog<bool>(context: context,
      builder: (_) => _CfConfirmDialog(title: 'Remove Domain', message: 'Remove "$hostname"?',
          confirmLabel: 'Remove', confirmColor: Colors.red));
    if (ok != true || !mounted) return;
    final r = await widget.api.deleteWorkerCustomDomain(widget.accountId, widget.workerName, id);
    if (!mounted) return;
    if (r.ok) { _load(); _snack('Domain removed'); }
    else _snack('${r.error}', err: true);
  }

  void _snack(String msg, {bool err = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(color: Colors.white)),
      backgroundColor: err ? Colors.red.shade800 : _workerGreen,
    ));
  }

  @override
  Widget build(BuildContext context) => _workerScaffold(
    context: context, title: 'Domains', workerName: widget.workerName,
    actions: [IconButton(icon: const Icon(Icons.refresh_rounded, color: _textDim), onPressed: _load)],
    floatingActionButton: FloatingActionButton.extended(
      backgroundColor: _workerGreen,
      icon: const Icon(Icons.add_rounded, color: Colors.white),
      label: const Text('Add Domain', style: TextStyle(color: Colors.white)),
      onPressed: _addDomain,
    ),
    body: _loading
      ? const Center(child: CircularProgressIndicator(color: _workerGreen))
      : _err != null
        ? _ErrRetry(message: _err!, onRetry: _load)
        : ListView(padding: EdgeInsets.all(12), children: [
            // Subdomain card
            Container(
              padding: EdgeInsets.all(16),
              margin: EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(color: _cardBg, borderRadius: BorderRadius.circular(14), border: Border.all(color: ThemeProvider().current.surfaceColor)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('workers.dev Subdomain', style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                if (_subdomainName.isNotEmpty)
                  Text('${widget.workerName}.$_subdomainName.workers.dev',
                      style: const TextStyle(color: _workerGreen, fontSize: 11.5)),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(child: Text(_subdomainEnabled ? 'Enabled — your Worker is publicly accessible via workers.dev' : 'Disabled',
                      style: const TextStyle(color: _textDim, fontSize: 12))),
                  if (_busy)
                    const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: _workerGreen, strokeWidth: 2))
                  else
                    Switch(value: _subdomainEnabled, activeColor: _workerGreen,
                        onChanged: _toggleSubdomain),
                ]),
              ]),
            ),
            // Custom domains
            const Padding(
              padding: EdgeInsets.only(bottom: 8, left: 2),
              child: Text('CUSTOM DOMAINS', style: TextStyle(color: _textDim, fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1.2)),
            ),
            if (_domains.isEmpty)
              Container(
                padding: EdgeInsets.all(20),
                decoration: BoxDecoration(color: _cardBg, borderRadius: BorderRadius.circular(12), border: Border.all(color: ThemeProvider().current.surfaceColor)),
                child: const Text('No custom domains.\nUse the button below to attach a domain from your CF account.',
                    style: TextStyle(color: _textDim, fontSize: 12, height: 1.6), textAlign: TextAlign.center),
              )
            else
              ..._domains.asMap().entries.map((e) {
                final d = e.value;
                final hostname = d['hostname'] as String? ?? '';
                final status   = d['status'] as String? ?? '';
                return Container(
                  margin: EdgeInsets.only(bottom: 8),
                  padding: EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                  decoration: BoxDecoration(color: _cardBg, borderRadius: BorderRadius.circular(12), border: Border.all(color: ThemeProvider().current.surfaceColor)),
                  child: Row(children: [
                    const Icon(Icons.language_rounded, color: _workerGreen, size: 20),
                    const SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(hostname, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
                      if (status.isNotEmpty) Text(status, style: TextStyle(color: status == 'active' ? Colors.green.shade400 : _textDim, fontSize: 11)),
                    ])),
                    IconButton(icon: Icon(Icons.delete_outline_rounded, color: Colors.red.shade400, size: 20),
                        padding: EdgeInsets.zero, constraints: const BoxConstraints(), onPressed: () => _deleteDomain(d)),
                  ]),
                );
              }),
          ]),
  );
}

// ── Worker Settings Screen ────────────────────────────────────────────────────
class _WorkerSettingsScreen extends StatefulWidget {
  final CfApi api;
  final String accountId;
  final String workerName;
  const _WorkerSettingsScreen({required this.api, required this.accountId, required this.workerName});
  @override
  State<_WorkerSettingsScreen> createState() => _WorkerSettingsScreenState();
}

class _WorkerSettingsScreenState extends State<_WorkerSettingsScreen> {
  bool _loading = true;
  bool _busy    = false;
  String? _err;
  Map<String, dynamic> _settings = {};
  final _compatDateCtrl = TextEditingController();

  static const _usageModels = ['standard', 'bundled', 'unbound'];
  static const _placementModes = ['off', 'smart'];

  @override
  void initState() { super.initState(); _load(); }

  @override
  void dispose() { _compatDateCtrl.dispose(); super.dispose(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.getWorkerSettings(widget.accountId, widget.workerName);
    if (!mounted) return;
    setState(() {
      _loading = false;
      if (r.ok) {
        _settings = Map<String, dynamic>.from(r.data['result'] ?? {});
        _compatDateCtrl.text = _settings['compatibility_date'] as String? ?? '';
      } else {
        _err = r.error;
      }
    });
  }

  Future<void> _save() async {
    setState(() => _busy = true);
    final patch = Map<String, dynamic>.from(_settings);
    patch['compatibility_date'] = _compatDateCtrl.text.trim();
    final r = await widget.api.patchWorkerSettings(widget.accountId, widget.workerName, patch);
    if (!mounted) return;
    setState(() => _busy = false);
    if (r.ok) _snack('Settings saved');
    else _snack('${r.error}', err: true);
  }

  void _snack(String msg, {bool err = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(color: Colors.white)),
      backgroundColor: err ? Colors.red.shade800 : _workerGreen,
    ));
  }

  Widget _section(String label) => Padding(
    padding: const EdgeInsets.only(top: 20, bottom: 8, left: 2),
    child: Text(label, style: const TextStyle(color: _textDim, fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1.2)),
  );

  Widget _card(Widget child) => Container(
    padding: EdgeInsets.all(14),
    margin: EdgeInsets.only(bottom: 8),
    decoration: BoxDecoration(color: _cardBg, borderRadius: BorderRadius.circular(12), border: Border.all(color: ThemeProvider().current.surfaceColor)),
    child: child,
  );

  @override
  Widget build(BuildContext context) {
    final usageModel    = _settings['usage_model']    as String? ?? 'standard';
    final placementMode = (_settings['placement'] as Map?)?['mode'] as String? ?? 'off';
    final flags         = List<String>.from(_settings['compatibility_flags'] ?? []);
    final logpush       = _settings['logpush'] as bool? ?? false;

    return _workerScaffold(
      context: context, title: 'Settings', workerName: widget.workerName,
      actions: [
        IconButton(icon: const Icon(Icons.refresh_rounded, color: _textDim), onPressed: _load),
        if (_busy)
          const Padding(padding: EdgeInsets.symmetric(horizontal: 12), child: Center(
              child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: _workerGreen, strokeWidth: 2))))
        else
          IconButton(icon: const Icon(Icons.save_rounded, color: _workerGreen), tooltip: 'Save', onPressed: _save),
      ],
      body: _loading
        ? const Center(child: CircularProgressIndicator(color: _workerGreen))
        : _err != null
          ? _ErrRetry(message: _err!, onRetry: _load)
          : ListView(padding: const EdgeInsets.fromLTRB(12, 4, 12, 80), children: [
              _section('RUNTIME'),
              _card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Compatibility Date', style: TextStyle(color: _textMid, fontSize: 12, fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                TextField(
                  controller: _compatDateCtrl,
                  style: TextStyle(color: Colors.white, fontSize: 13),
                  decoration: InputDecoration(
                    hintText: 'YYYY-MM-DD  e.g. 2024-01-01',
                    hintStyle: TextStyle(color: _textDim),
                    filled: true, fillColor: ThemeProvider().current.scaffoldBg,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
                    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
                    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _workerGreen)),
                  ),
                ),
              ])),
              _section('USAGE MODEL'),
              _card(Column(
                children: _usageModels.map((m) => RadioListTile<String>(
                  title: Text(m, style: const TextStyle(color: Colors.white, fontSize: 13)),
                  subtitle: Text({
                    'standard': 'Pay per request — recommended',
                    'bundled':  'Fixed CPU limits',
                    'unbound':  'Extended CPU time',
                  }[m] ?? '', style: const TextStyle(color: _textDim, fontSize: 11)),
                  value: m, groupValue: usageModel,
                  activeColor: _workerGreen, contentPadding: EdgeInsets.zero,
                  onChanged: (v) { if (v != null) setState(() => _settings['usage_model'] = v); },
                )).toList(),
              )),
              _section('SMART PLACEMENT'),
              _card(Column(
                children: _placementModes.map((m) => RadioListTile<String>(
                  title: Text(m == 'smart' ? 'Smart Placement' : 'Off', style: const TextStyle(color: Colors.white, fontSize: 13)),
                  subtitle: Text({
                    'off':   'Worker runs in the datacenter closest to the origin server',
                    'smart': 'Cloudflare automatically places the Worker closest to your dependencies',
                  }[m] ?? '', style: const TextStyle(color: _textDim, fontSize: 11)),
                  value: m, groupValue: placementMode,
                  activeColor: _workerGreen, contentPadding: EdgeInsets.zero,
                  onChanged: (v) { if (v != null) setState(() => _settings['placement'] = {'mode': v}); },
                )).toList(),
              )),
              _section('OBSERVABILITY'),
              _card(SwitchListTile(
                title: const Text('Logpush', style: TextStyle(color: Colors.white, fontSize: 13)),
                subtitle: const Text('Stream Worker logs to Cloudflare Logpush', style: TextStyle(color: _textDim, fontSize: 11)),
                value: logpush, activeColor: _workerGreen, contentPadding: EdgeInsets.zero,
                onChanged: (v) => setState(() => _settings['logpush'] = v),
              )),
              if (flags.isNotEmpty) ...[
                _section('COMPATIBILITY FLAGS'),
                _card(Wrap(
                  spacing: 6, runSpacing: 6,
                  children: flags.map((f) => Chip(
                    label: Text(f, style: TextStyle(color: Colors.white, fontSize: 11)),
                    backgroundColor: ThemeProvider().current.scaffoldBg,
                    side: BorderSide(color: ThemeProvider().current.surfaceColor),
                    deleteIconColor: Colors.red.shade400,
                    onDeleted: () => setState(() => (_settings['compatibility_flags'] as List).remove(f)),
                  )).toList(),
                )),
              ],
            ]),
    );
  }
}

// ── Reusable small widgets for Worker sub-screens ─────────────────────────────
class _ErrRetry extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const _ErrRetry({required this.message, required this.onRetry});
  @override
  Widget build(BuildContext context) => Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
    const Icon(Icons.error_outline_rounded, color: _textDim, size: 48),
    const SizedBox(height: 12),
    Text(message, style: const TextStyle(color: _textDim, fontSize: 13), textAlign: TextAlign.center),
    const SizedBox(height: 16),
    TextButton(onPressed: onRetry, child: const Text('Retry', style: TextStyle(color: _workerGreen))),
  ]));
}

class _EmptyState extends StatelessWidget {
  final IconData icon;
  final String message;
  const _EmptyState({required this.icon, required this.message});
  @override
  Widget build(BuildContext context) => Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
    Icon(icon, color: _textDim, size: 52),
    const SizedBox(height: 14),
    Text(message, style: const TextStyle(color: _textDim, fontSize: 13, height: 1.6), textAlign: TextAlign.center),
  ]));
}

class _CfTextField extends StatelessWidget {
  final TextEditingController ctrl;
  final String hint;
  const _CfTextField({required this.ctrl, required this.hint});
  @override
  Widget build(BuildContext context) => TextField(
    controller: ctrl,
    style: TextStyle(color: Colors.white, fontSize: 13),
    decoration: InputDecoration(
      hintText: hint, hintStyle: TextStyle(color: _textDim),
      filled: true, fillColor: ThemeProvider().current.scaffoldBg,
      border:        OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: ThemeProvider().current.surfaceColor)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _workerGreen)),
    ),
  );
}

// ── File-system entry ─────────────────────────────────────────────────────────
class _FsEntry {
  final String name;
  final String fullPath;
  final bool isDir;
  const _FsEntry({required this.name, required this.fullPath, required this.isDir});
}

// ── Pages File Browser ────────────────────────────────────────────────────────
class _PageFileBrowserScreen extends StatefulWidget {
  final CfApi api;
  final String accountId;
  final String projectName;
  const _PageFileBrowserScreen({
    required this.api,
    required this.accountId,
    required this.projectName,
  });

  @override
  State<_PageFileBrowserScreen> createState() => _PageFileBrowserScreenState();
}

class _PageFileBrowserScreenState extends State<_PageFileBrowserScreen> {
  bool _loading  = true;
  bool _busy     = false;
  String? _err;
  String _deploymentId  = '';
  String _deploymentUrl = '';
  Map<String, String> _manifest = {};
  String _currentPath = '/';

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.getLatestPagesDeployment(widget.accountId, widget.projectName);
    if (!mounted) return;
    if (!r.ok) { setState(() { _loading = false; _err = r.error; }); return; }
    final res = (r.data['result'] as Map?) ?? {};
    final rawManifest = res['manifest'] as Map?;
    setState(() {
      _loading = false;
      _deploymentId  = res['id']  as String? ?? '';
      _deploymentUrl = (res['url'] as String?)?.replaceAll(RegExp(r'/$'), '')
          ?? 'https://${widget.projectName}.pages.dev';
      _manifest = rawManifest?.cast<String, String>() ?? {};
    });
  }

  List<_FsEntry> _entriesFor(String path) {
    final prefix = path == '/' ? '/' : '$path/';
    final seen = <String>{};
    final entries = <_FsEntry>[];
    for (final filePath in _manifest.keys) {
      String? rel;
      if (path == '/') {
        if (filePath.startsWith('/')) rel = filePath.substring(1);
      } else {
        if (filePath.startsWith(prefix)) rel = filePath.substring(prefix.length);
      }
      if (rel == null || rel.isEmpty) continue;
      final slash = rel.indexOf('/');
      if (slash == -1) {
        if (seen.add(rel)) entries.add(_FsEntry(name: rel, fullPath: filePath, isDir: false));
      } else {
        final dir = rel.substring(0, slash);
        if (seen.add(dir)) {
          final dPath = path == '/' ? '/$dir' : '$path/$dir';
          entries.add(_FsEntry(name: dir, fullPath: dPath, isDir: true));
        }
      }
    }
    entries.sort((a, b) {
      if (a.isDir != b.isDir) return a.isDir ? -1 : 1;
      return a.name.compareTo(b.name);
    });
    return entries;
  }

  void _navigateTo(String path) => setState(() => _currentPath = path);

  void _navigateUp() {
    if (_currentPath == '/') return;
    final parts = _currentPath.split('/')..removeLast();
    _navigateTo(parts.length <= 1 ? '/' : parts.join('/'));
  }

  Future<Directory?> _cfDir() async {
    try {
      final root = await StorageHelper.getRootDir();
      final d = Directory('$root/${StorageHelper.appFolder}/cloudflare');
      await d.create(recursive: true);
      return d;
    } catch (_) { return null; }
  }

  void _snack(String msg, {bool err = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(err ? Icons.error_rounded : Icons.check_circle_rounded, color: Colors.white, size: 18),
        const SizedBox(width: 8),
        Expanded(child: Text(msg, style: const TextStyle(color: Colors.white))),
      ]),
      backgroundColor: err ? Colors.red.shade800 : _cfOrange,
      duration: const Duration(seconds: 5),
    ));
  }

  Future<void> _downloadFile(_FsEntry entry) async {
    final hasAccess = await PermissionHelper.ensureStorage(context, accent: _cfOrange);
    if (!hasAccess || !mounted) return;
    setState(() => _busy = true);
    try {
      final url = '$_deploymentUrl${entry.fullPath}';
      final resp = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 30));
      if (resp.statusCode != 200) { _snack('HTTP ${resp.statusCode}', err: true); return; }
      final dir = await _cfDir();
      if (dir == null) { _snack('Cannot access storage', err: true); return; }
      final path = '${dir.path}/${entry.name}';
      await File(path).writeAsBytes(resp.bodyBytes);
      _snack('Saved → Taurus-Shield/cloudflare/${entry.name}');
    } catch (e) {
      _snack('$e', err: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _downloadAll() async {
    if (_manifest.isEmpty) { _snack('No files in manifest', err: true); return; }
    final hasAccess = await PermissionHelper.ensureStorage(context, accent: _cfOrange);
    if (!hasAccess || !mounted) return;
    setState(() => _busy = true);
    try {
      final archive = Archive();
      var count = 0;
      for (final filePath in _manifest.keys) {
        try {
          final resp = await http.get(Uri.parse('$_deploymentUrl$filePath'))
              .timeout(const Duration(seconds: 30));
          if (resp.statusCode == 200) {
            final name = filePath.startsWith('/') ? filePath.substring(1) : filePath;
            archive.addFile(ArchiveFile(name, resp.bodyBytes.length, resp.bodyBytes));
            count++;
          }
        } catch (_) {}
      }
      if (count == 0) { _snack('Could not download any files', err: true); return; }
      final dir = await _cfDir();
      if (dir == null) { _snack('Cannot access storage', err: true); return; }
      final zipBytes = ZipEncoder().encode(archive)!;
      final zipPath = '${dir.path}/${widget.projectName}.zip';
      await File(zipPath).writeAsBytes(zipBytes);
      _snack('$count files → Taurus-Shield/cloudflare/${widget.projectName}.zip');
    } catch (e) {
      _snack('$e', err: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _deleteDeployment() async {
    if (_deploymentId.isEmpty) { _snack('No deployment ID available', err: true); return; }
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => _CfConfirmDialog(
        title: 'Delete Deployment',
        message: 'Delete deployment "$_deploymentId"?\nThe project will remain but this deployment will be removed.',
        confirmLabel: 'Delete',
        confirmColor: Colors.red,
      ),
    );
    if (ok != true || !mounted) return;
    setState(() => _busy = true);
    final r = await widget.api.deletePagesDeployment(widget.accountId, widget.projectName, _deploymentId);
    if (!mounted) return;
    setState(() => _busy = false);
    if (r.ok) { _snack('Deployment deleted'); Navigator.pop(context); }
    else _snack('${r.error}', err: true);
  }

  void _showFileOptions(_FsEntry entry) {
    showModalBottomSheet(
      context: context,
      backgroundColor: _cardBg,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 36, height: 4, margin: EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(color: ThemeProvider().current.surfaceColor, borderRadius: BorderRadius.circular(2)),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: Row(children: [
                const Icon(Icons.insert_drive_file_rounded, color: _cfOrange, size: 18),
                SizedBox(width: 10),
                Expanded(child: Text(entry.name,
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 14))),
              ]),
            ),
            Divider(color: ThemeProvider().current.surfaceColor),
            ListTile(
              leading: const Icon(Icons.download_rounded, color: _cfOrange),
              title: const Text('Download', style: TextStyle(color: Colors.white)),
              onTap: () { Navigator.pop(context); _downloadFile(entry); },
            ),
            ListTile(
              leading: const Icon(Icons.copy_rounded, color: _textDim),
              title: const Text('Copy path', style: TextStyle(color: Colors.white)),
              onTap: () {
                Clipboard.setData(ClipboardData(text: entry.fullPath));
                Navigator.pop(context);
                _snack('Path copied');
              },
            ),
            ListTile(
              leading: const Icon(Icons.open_in_browser_rounded, color: _textDim),
              title: const Text('Open in browser', style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pop(context);
                launchUrl(Uri.parse('$_deploymentUrl${entry.fullPath}'),
                    mode: LaunchMode.externalApplication);
              },
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final breadcrumbs = _currentPath == '/'
        ? ['root']
        : ['root', ..._currentPath.substring(1).split('/')];
    final entries = _entriesFor(_currentPath);

    return Scaffold(
      backgroundColor: ThemeProvider().current.scaffoldBg,
      appBar: AppBar(
        backgroundColor: _cardBg,
        title: Text(widget.projectName,
            style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w700)),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _textDim, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          if (!_loading && _err == null && _manifest.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.download_for_offline_rounded, color: _cfOrange),
              tooltip: 'Download all as ZIP',
              onPressed: _busy ? null : _downloadAll,
            ),
          if (!_loading && _err == null && _deploymentId.isNotEmpty)
            IconButton(
              icon: Icon(Icons.delete_sweep_rounded, color: Colors.red.shade400),
              tooltip: 'Delete deployment',
              onPressed: _busy ? null : _deleteDeployment,
            ),
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: _textDim),
            tooltip: 'Refresh',
            onPressed: _busy ? null : _load,
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: _cfOrange))
          : _err != null
              ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.error_outline_rounded, color: _textDim, size: 48),
                  const SizedBox(height: 12),
                  Text(_err!, style: const TextStyle(color: _textDim, fontSize: 14), textAlign: TextAlign.center),
                  const SizedBox(height: 16),
                  TextButton(onPressed: _load, child: const Text('Retry', style: TextStyle(color: _cfOrange))),
                ]))
              : Column(children: [
                  // ── Breadcrumb bar ──────────────────────────────────────────
                  Container(
                    color: _cardBg,
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    child: Row(children: [
                      const Icon(Icons.folder_rounded, color: _cfOrange, size: 16),
                      const SizedBox(width: 6),
                      Expanded(
                        child: SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            children: breadcrumbs.asMap().entries.map((e) {
                              final isLast = e.key == breadcrumbs.length - 1;
                              return Row(children: [
                                if (e.key > 0)
                                  const Text(' / ', style: TextStyle(color: _textDim, fontSize: 12)),
                                GestureDetector(
                                  onTap: isLast ? null : () {
                                    if (e.key == 0) { _navigateTo('/'); return; }
                                    final parts = _currentPath.split('/');
                                    final target = parts.take(e.key + 1).join('/');
                                    _navigateTo(target.isEmpty ? '/' : target);
                                  },
                                  child: Text(e.value,
                                    style: TextStyle(
                                      color: isLast ? Colors.white : _cfOrange,
                                      fontSize: 12,
                                      fontWeight: isLast ? FontWeight.w600 : FontWeight.normal,
                                    ),
                                  ),
                                ),
                              ]);
                            }).toList(),
                          ),
                        ),
                      ),
                    ]),
                  ),
                  // ── Back row ────────────────────────────────────────────────
                  if (_currentPath != '/')
                    InkWell(
                      onTap: _navigateUp,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
                        child: Row(children: [
                          const Icon(Icons.arrow_upward_rounded, color: _cfOrange, size: 20),
                          const SizedBox(width: 12),
                          const Text('..', style: TextStyle(color: _cfOrange, fontSize: 14)),
                        ]),
                      ),
                    ),
                  // ── File/folder list ────────────────────────────────────────
                  if (_manifest.isEmpty)
                    Expanded(child: Center(child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 28),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 68, height: 68,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: _cfOrange.withOpacity(0.1),
                              border: Border.all(color: _cfOrange.withOpacity(0.35)),
                            ),
                            child: const Icon(Icons.cloud_sync_rounded,
                                color: _cfOrange, size: 32),
                          ),
                          const SizedBox(height: 16),
                          const Text('Git-Connected Deployment',
                              style: TextStyle(color: Colors.white,
                                  fontSize: 15, fontWeight: FontWeight.w700)),
                          const SizedBox(height: 8),
                          const Text(
                            'File browsing is only available for direct ZIP uploads. '
                            'This project is deployed via Git — its files live in your repository.',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: _textDim, fontSize: 12, height: 1.5),
                          ),
                          const SizedBox(height: 20),
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton.icon(
                              onPressed: () => Navigator.push(context,
                                  MaterialPageRoute(builder: (_) =>
                                      _WorkerBrowserScreen(
                                        url: _deploymentUrl.isNotEmpty
                                            ? _deploymentUrl
                                            : 'https://${widget.projectName}.pages.dev',
                                        title: widget.projectName,
                                      ))),
                              icon: const Icon(Icons.open_in_browser_rounded, size: 18),
                              label: const Text('Open Live Site',
                                  style: TextStyle(fontWeight: FontWeight.w700)),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: _cfOrange,
                                foregroundColor: Colors.white,
                                padding: const EdgeInsets.symmetric(vertical: 13),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12)),
                                elevation: 0,
                              ),
                            ),
                          ),
                          const SizedBox(height: 10),
                          OutlinedButton.icon(
                            onPressed: () async {
                              final url = Uri.parse(_deploymentUrl.isNotEmpty
                                  ? _deploymentUrl
                                  : 'https://${widget.projectName}.pages.dev');
                              await launchUrl(url, mode: LaunchMode.externalApplication);
                            },
                            icon: const Icon(Icons.launch_rounded,
                                color: _cfOrange, size: 16),
                            label: const Text('Open in System Browser',
                                style: TextStyle(color: _cfOrange, fontSize: 13)),
                            style: OutlinedButton.styleFrom(
                              side: BorderSide(color: _cfOrange.withOpacity(0.4)),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12)),
                            ),
                          ),
                        ],
                      ),
                    )))
                  else if (entries.isEmpty)
                    const Expanded(child: Center(child: Text(
                      'Empty folder',
                      style: TextStyle(color: _textDim, fontSize: 13),
                    )))
                  else
                    Expanded(
                      child: ListView.builder(
                        itemCount: entries.length,
                        itemBuilder: (ctx, i) {
                          final e = entries[i];
                          return InkWell(
                            onTap: () {
                              if (e.isDir) {
                                _navigateTo(e.fullPath);
                              } else {
                                _showFileOptions(e);
                              }
                            },
                            onLongPress: () => _showFileOptions(e),
                            child: Container(
                              margin: EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                              padding: EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                              decoration: BoxDecoration(
                                color: _cardBg,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: ThemeProvider().current.surfaceColor),
                              ),
                              child: Row(children: [
                                Icon(
                                  e.isDir ? Icons.folder_rounded : _iconForFile(e.name),
                                  color: e.isDir ? _cfOrange : _textMid,
                                  size: 22,
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Text(e.name,
                                      style: const TextStyle(color: Colors.white, fontSize: 13.5)),
                                ),
                                if (e.isDir)
                                  const Icon(Icons.chevron_right_rounded, color: _textDim, size: 20)
                                else
                                  IconButton(
                                    icon: const Icon(Icons.download_rounded, color: _cfOrange, size: 20),
                                    padding: EdgeInsets.zero,
                                    constraints: const BoxConstraints(),
                                    onPressed: _busy ? null : () => _downloadFile(e),
                                  ),
                              ]),
                            ),
                          );
                        },
                      ),
                    ),
                  // ── Bottom bar ──────────────────────────────────────────────
                  if (_deploymentUrl.isNotEmpty)
                    Container(
                      color: _cardBg,
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      child: Row(children: [
                        const Icon(Icons.link_rounded, color: _textDim, size: 14),
                        const SizedBox(width: 6),
                        Expanded(child: Text(
                          _deploymentUrl,
                          style: const TextStyle(color: _textDim, fontSize: 11),
                          overflow: TextOverflow.ellipsis,
                        )),
                      ]),
                    ),
                  if (_busy)
                    const LinearProgressIndicator(color: _cfOrange, backgroundColor: _cardBg),
                ]),
    );
  }

  IconData _iconForFile(String name) {
    final ext = name.split('.').last.toLowerCase();
    switch (ext) {
      case 'js': case 'ts': case 'mjs': return Icons.javascript_rounded;
      case 'html': case 'htm': return Icons.html_rounded;
      case 'css': return Icons.css_rounded;
      case 'json': return Icons.data_object_rounded;
      case 'png': case 'jpg': case 'jpeg': case 'gif':
      case 'webp': case 'svg': case 'ico': return Icons.image_rounded;
      case 'pdf': return Icons.picture_as_pdf_rounded;
      case 'zip': case 'gz': case 'tar': return Icons.archive_rounded;
      case 'mp4': case 'webm': case 'mov': return Icons.videocam_rounded;
      case 'mp3': case 'wav': case 'ogg': return Icons.audio_file_rounded;
      case 'woff': case 'woff2': case 'ttf': return Icons.font_download_rounded;
      default: return Icons.insert_drive_file_rounded;
    }
  }
}

class _WorkerNameDialog extends StatefulWidget {
  final TextEditingController controller;
  final String subdomain;
  const _WorkerNameDialog({required this.controller, required this.subdomain});

  @override
  State<_WorkerNameDialog> createState() => _WorkerNameDialogState();
}

class _WorkerNameDialogState extends State<_WorkerNameDialog> {
  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_onChanged);
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onChanged);
    super.dispose();
  }

  void _onChanged() {
    setState(() {});
  }

  String _slugify(String raw) {
    return raw.toLowerCase()
        .replaceAll(RegExp(r'[^a-z0-9\-]'), '-')
        .replaceAll(RegExp(r'-{2,}'), '-')
        .replaceAll(RegExp(r'^-+|-+$'), '');
  }

  @override
  Widget build(BuildContext context) {
    final slug = _slugify(widget.controller.text);
    final sub = widget.subdomain.isNotEmpty ? widget.subdomain : 'your-subdomain';
    final previewUrl = slug.isEmpty
        ? 'https://<name>.$sub.workers.dev'
        : 'https://$slug.$sub.workers.dev';

    return AlertDialog(
      backgroundColor: _cardBg,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: const Text('Worker Name',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Enter name for this worker',
              style: TextStyle(color: _textDim, fontSize: 12.5)),
          SizedBox(height: 8),
          Container(
            decoration: BoxDecoration(
              color: ThemeProvider().current.scaffoldBg,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _workerGreen.withOpacity(0.4)),
            ),
            child: TextField(
              controller: widget.controller,
              autofocus: true,
              style: const TextStyle(color: Colors.white, fontSize: 14),
              decoration: InputDecoration(
                hintText: 'my-worker',
                hintStyle: TextStyle(color: _textDim.withOpacity(0.5), fontSize: 13),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
              ),
            ),
          ),
          SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: ThemeProvider().current.scaffoldBg,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _workerGreen.withOpacity(0.2)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Worker URL', style: TextStyle(color: _textDim, fontSize: 11)),
                const SizedBox(height: 4),
                Text(
                  previewUrl,
                  style: TextStyle(
                    color: slug.isEmpty ? _textDim : _workerGreen,
                    fontSize: 12.5,
                    fontFamily: 'monospace',
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel', style: TextStyle(color: _textDim)),
        ),
        TextButton(
          onPressed: slug.isEmpty ? null : () => Navigator.pop(context, slug),
          child: Text('OK',
              style: TextStyle(
                color: slug.isEmpty ? _textDim : _workerGreen,
                fontWeight: FontWeight.w700,
              )),
        ),
      ],
    );
  }
}

class _TextInputDialog extends StatelessWidget {
  final String title;
  final String hint;
  final String label;
  final TextEditingController controller;
  const _TextInputDialog({
    required this.title,
    required this.hint,
    required this.label,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: _cardBg,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: Text(title,
          style: const TextStyle(
              color: Colors.white, fontWeight: FontWeight.w700)),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: TextStyle(color: _textDim, fontSize: 12.5)),
          SizedBox(height: 8),
          Container(
            decoration: BoxDecoration(
              color: ThemeProvider().current.scaffoldBg,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _workerGreen.withOpacity(0.4)),
            ),
            child: TextField(
              controller: controller,
              autofocus: true,
              style: const TextStyle(color: Colors.white, fontSize: 14),
              decoration: InputDecoration(
                hintText: hint,
                hintStyle: TextStyle(
                    color: _textDim.withOpacity(0.5), fontSize: 13),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(
                    horizontal: 12, vertical: 12),
              ),
            ),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel', style: TextStyle(color: _textDim)),
        ),
        TextButton(
          onPressed: () => Navigator.pop(context, controller.text.trim()),
          child: const Text('OK',
              style: TextStyle(
                  color: _cfOrange, fontWeight: FontWeight.w700)),
        ),
      ],
    );
  }
}

class _AccountPickerDialog extends StatelessWidget {
  final List accounts;
  const _AccountPickerDialog({required this.accounts});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: _cardBg,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: const Text('Select Account',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
      content: SizedBox(
        width: double.maxFinite,
        child: ListView.builder(
          shrinkWrap: true,
          itemCount: accounts.length,
          itemBuilder: (_, i) {
            final a = accounts[i] as Map;
            return ListTile(
              leading: const Icon(Icons.business_rounded,
                  color: _cfOrange),
              title: Text(a['name'] ?? '',
                  style: const TextStyle(color: Colors.white)),
              subtitle: Text(a['id'] ?? '',
                  style: const TextStyle(
                      color: _textDim, fontSize: 11,
                      fontFamily: 'monospace')),
              onTap: () => Navigator.pop(context, a),
            );
          },
        ),
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// TOKEN GUIDE — step-by-step how to create a Cloudflare API token
// ═════════════════════════════════════════════════════════════════════════════
class _TokenGuide extends StatefulWidget {
  const _TokenGuide();
  @override
  State<_TokenGuide> createState() => _TokenGuideState();
}

class _TokenGuideState extends State<_TokenGuide>
    with SingleTickerProviderStateMixin {
  bool _open = false;
  late final AnimationController _ctrl;
  late final Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 300),
    );
    _anim = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _toggle() {
    setState(() => _open = !_open);
    _open ? _ctrl.forward() : _ctrl.reverse();
  }

  Future<void> _openDash() async {
    const url = 'https://dash.cloudflare.com/profile/api-tokens';
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // ── Security note ──────────────────────────────────────────────────
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: _cfOrange.withOpacity(0.06),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _cfOrange.withOpacity(0.18)),
          ),
          child: Row(
            children: [
              const Icon(Icons.lock_outline_rounded,
                  color: _cfOrange, size: 16),
              const SizedBox(width: 8),
              const Expanded(
                child: Text(
                  'Token is stored only on your device and only sent to api.cloudflare.com',
                  style: TextStyle(color: _textMid, fontSize: 11.5, height: 1.4),
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 10),

        // ── Expandable guide ───────────────────────────────────────────────
        Container(
          decoration: BoxDecoration(
            color: _cardBg,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: _open
                  ? _cfOrange.withOpacity(0.35)
                  : ThemeProvider().current.surfaceColor,
            ),
          ),
          child: Column(
            children: [
              // header tap row
              InkWell(
                onTap: _toggle,
                borderRadius: BorderRadius.circular(12),
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 12),
                  child: Row(
                    children: [
                      Container(
                        width: 28,
                        height: 28,
                        decoration: BoxDecoration(
                          color: _cfOrange.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(Icons.help_outline_rounded,
                            color: _cfOrange, size: 16),
                      ),
                      const SizedBox(width: 10),
                      const Expanded(
                        child: Text(
                          'How to get your API Token',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 13.5,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      AnimatedRotation(
                        turns: _open ? 0.5 : 0,
                        duration: const Duration(milliseconds: 280),
                        child: const Icon(
                          Icons.keyboard_arrow_down_rounded,
                          color: _textDim,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // expandable steps
              SizeTransition(
                sizeFactor: _anim,
                child: Column(
                  children: [
                    Container(
                      height: 1,
                      margin: EdgeInsets.symmetric(horizontal: 12),
                      color: ThemeProvider().current.surfaceColor,
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(14, 14, 14, 6),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _GuideStep(
                            number: '1',
                            text: 'Open the Cloudflare dashboard and log in to your account.',
                            action: GestureDetector(
                              onTap: _openDash,
                              child: const Text(
                                'dash.cloudflare.com',
                                style: TextStyle(
                                  color: _cfOrange,
                                  fontSize: 12,
                                  decoration: TextDecoration.underline,
                                  decorationColor: _cfOrange,
                                ),
                              ),
                            ),
                          ),
                          _GuideStep(
                            number: '2',
                            text: 'Tap your profile icon (top-right corner) → My Profile.',
                          ),
                          _GuideStep(
                            number: '3',
                            text: 'Go to the API Tokens tab → tap Create Token.',
                          ),
                          _GuideStep(
                            number: '4',
                            text: 'Scroll down and choose Create Custom Token.',
                          ),
                          _GuideStep(
                            number: '5',
                            text: 'Give it a name (e.g. "Taurus Shield") then add these permissions:',
                            extra: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                _PermRow(resource: 'Account', perm: 'Workers Scripts', access: 'Edit'),
                                _PermRow(resource: 'Account', perm: 'Pages', access: 'Edit'),
                                _PermRow(resource: 'Zone', perm: 'DNS', access: 'Edit'),
                                _PermRow(resource: 'Zone', perm: 'Workers Routes', access: 'Edit'),
                              ],
                            ),
                          ),
                          _GuideStep(
                            number: '6',
                            text: 'Under Account Resources, select your account. Under Zone Resources, select All Zones (or specific zones).',
                          ),
                          _GuideStep(
                            number: '7',
                            text: 'Tap Continue to Summary → Create Token.',
                          ),
                          const _GuideStep(
                            number: '8',
                            text: 'Copy the token — it is only shown once. Paste it into the field above.',
                            isLast: true,
                          ),
                          const SizedBox(height: 10),

                          // open button
                          SizedBox(
                            width: double.infinity,
                            child: OutlinedButton.icon(
                              onPressed: _openDash,
                              icon: const Icon(Icons.open_in_new_rounded,
                                  size: 16, color: _cfOrange),
                              label: const Text(
                                'Open Cloudflare API Tokens',
                                style: TextStyle(
                                    color: _cfOrange, fontSize: 13),
                              ),
                              style: OutlinedButton.styleFrom(
                                side: const BorderSide(color: _cfOrange),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                padding: const EdgeInsets.symmetric(
                                    vertical: 12),
                              ),
                            ),
                          ),
                          const SizedBox(height: 10),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _GuideStep extends StatelessWidget {
  final String number;
  final String text;
  final Widget? action;
  final Widget? extra;
  final bool isLast;

  const _GuideStep({
    required this.number,
    required this.text,
    this.action,
    this.extra,
    this.isLast = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // step circle
          Container(
            width: 22,
            height: 22,
            margin: const EdgeInsets.only(top: 1),
            decoration: BoxDecoration(
              color: _cfOrange.withOpacity(0.15),
              shape: BoxShape.circle,
              border: Border.all(color: _cfOrange.withOpacity(0.5)),
            ),
            child: Center(
              child: Text(
                number,
                style: const TextStyle(
                  color: _cfOrange,
                  fontSize: 10.5,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  text,
                  style: const TextStyle(
                    color: _textMid,
                    fontSize: 12.5,
                    height: 1.45,
                  ),
                ),
                if (action != null) ...[
                  const SizedBox(height: 3),
                  action!,
                ],
                if (extra != null) ...[
                  const SizedBox(height: 8),
                  extra!,
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PermRow extends StatelessWidget {
  final String resource;
  final String perm;
  final String access;
  const _PermRow({
    required this.resource,
    required this.perm,
    required this.access,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 5),
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: ThemeProvider().current.scaffoldBg,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: ThemeProvider().current.surfaceColor),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              color: Colors.blueAccent.withOpacity(0.12),
              borderRadius: BorderRadius.circular(5),
            ),
            child: Text(
              resource,
              style: const TextStyle(
                  color: Colors.blueAccent,
                  fontSize: 9.5,
                  fontWeight: FontWeight.w700),
            ),
          ),
          const SizedBox(width: 7),
          Expanded(
            child: Text(
              perm,
              style: const TextStyle(color: Colors.white, fontSize: 11.5),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              color: Colors.green.withOpacity(0.12),
              borderRadius: BorderRadius.circular(5),
            ),
            child: Text(
              access,
              style: const TextStyle(
                  color: Colors.greenAccent,
                  fontSize: 9.5,
                  fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }
}
