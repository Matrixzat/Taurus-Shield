import '../utils/theme_provider.dart';
import 'package:flutter/material.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ABOUT')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _HeroCard(),
            const SizedBox(height: 20),
            _InfoCard(
              icon: Icons.shield_rounded,
              title: 'What is Taurus Shield?',
              content:
                  'Taurus Shield is a professional-grade mobile security and reverse engineering toolkit built for security researchers, APK analysts, and developers.\n\nIt bundles a growing suite of cloud-powered tools — from bytecode analysis to APK obfuscation — all without root access.',
            ),
            const SizedBox(height: 12),
            _InfoCard(
              icon: Icons.build_circle_rounded,
              title: 'Toolkit Features',
              content:
                  '• SSL Unpinner — Bypass certificate pinning on any Android APK without root\n\n• VM Protect — Protect native libraries using NMMP virtualisation\n\n• Blutter Analyzer — Reverse-engineer Flutter APKs and dump Dart symbols\n\n• Dex2C — Transpile Dalvik bytecode to native C for deeper obfuscation\n\n• DPT Shell — Pack or unpack DPT-Shell protection layers\n\n• APK Tool — Decompile, patch and recompile any APK\n\n• Ads Removal — Strip ad SDKs from APKs automatically\n\n• Matrix Killer — Remove anti-debug and anti-tamper checks\n\n• Black Forge — Encrypt, decrypt and archive sensitive files on-device\n\n• Pine Hook (HBC) — Disassemble and reassemble Hermes bytecode bundles',
            ),
            const SizedBox(height: 12),
            _InfoCard(
              icon: Icons.info_outline_rounded,
              title: 'Technical Notes',
              content: 'All cloud-powered tools run on Cloudflare Workers — no data is stored after processing.\n\nNo root access required. Works on any Android device running Android 8.0+.\n\nHermes bytecode support spans v59 through v98, covering React Native 0.60 to latest.',
            ),
            const SizedBox(height: 12),
            _InfoCard(
              icon: Icons.info_rounded,
              title: 'Version Info',
              content: 'Taurus Shield v1.0.0\nBuild: 1\nPlatform: Android (arm64-v8a)',
            ),
          ],
        ),
      ),
    );
  }
}

class _HeroCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(28),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: LinearGradient(
          colors: [ThemeProvider().current.headerBg1, ThemeProvider().current.headerBg2],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        border: Border.all(color: ThemeProvider().current.primary.withOpacity(0.4)),
      ),
      child: Column(
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: LinearGradient(
                colors: [ThemeProvider().current.primary, Color(0xFF4f1fa0)],
              ),
              boxShadow: [BoxShadow(color: ThemeProvider().current.primary.withOpacity(0.5), blurRadius: 24)],
            ),
            child: Icon(Icons.memory_rounded, color: Colors.white, size: 42),
          ),
          SizedBox(height: 16),
          Text('TAURUS SHIELD', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: 4, color: Colors.white)),
          SizedBox(height: 6),
          Text('Mobile Security Toolkit', style: TextStyle(color: ThemeProvider().current.secondary, fontSize: 14)),
          SizedBox(height: 8),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 12, vertical: 5),
            decoration: BoxDecoration(
              color: ThemeProvider().current.primary.withOpacity(0.2),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: ThemeProvider().current.primary.withOpacity(0.5)),
            ),
            child: Text('v1.0.0 • by Matrix Dev', style: TextStyle(color: ThemeProvider().current.secondary, fontSize: 12)),
          ),
        ],
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String content;

  const _InfoCard({required this.icon, required this.title, required this.content});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: ThemeProvider().current.surfaceColor,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: ThemeProvider().current.borderColor, width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: ThemeProvider().current.primary, size: 20),
              const SizedBox(width: 10),
              Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15)),
            ],
          ),
          const SizedBox(height: 12),
          Text(content, style: const TextStyle(color: Color(0xFFa0a0b8), fontSize: 13, height: 1.7)),
        ],
      ),
    );
  }
}
