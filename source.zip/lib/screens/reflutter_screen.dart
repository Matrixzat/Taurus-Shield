import '../utils/theme_provider.dart';
import '../widgets/guide_modal.dart';
import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import '../utils/hbc_channel.dart';
import '../utils/storage_helper.dart';
import '../utils/permission_helper.dart';

const _kRfAccent      = Color(0xFFf97316);
const _kRfAccentLight = Color(0xFFfb923c);

class ReFlutterScreen extends StatefulWidget {
  const ReFlutterScreen({super.key});
  @override
  State<ReFlutterScreen> createState() => _ReFlutterScreenState();
}

class _ReFlutterScreenState extends State<ReFlutterScreen>
    with TickerProviderStateMixin {
  String? _selectedFilePath;
  String? _selectedFileName;
  bool    _isProcessing     = false;
  bool    _logVisible       = false;
  String  _logs             = '';
  String? _outputDir;
  int     _downloadProgress = -1;
  bool    _autoScroll       = true;
  String? _fileStatus;
  bool    _fileValid        = false;
  StreamSubscription<String>? _streamSub;
  final Stopwatch _stopwatch  = Stopwatch();
  Timer?  _tickTimer;
  String  _elapsed           = '00:00';
  Timer?  _pollTimer;
  final ScrollController _logScrollCtrl  = ScrollController();
  final ScrollController _pageScrollCtrl = ScrollController();

  late final AnimationController _pulseCtrl;
  late final AnimationController _orbitCtrl;
  late final AnimationController _logCtrl;
  late final Animation<double>   _pulseAnim;
  late final Animation<double>   _logFade;

  static const _accent      = _kRfAccent;
  static const _accentLight = _kRfAccentLight;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);
    _orbitCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 5000),
    )..repeat();
    _logCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 400),
    );
    _pulseAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
    _logFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _logCtrl, curve: Curves.easeOut),
    );
    _checkCloudState();
  }

  Future<void> _checkCloudState() async {
    try {
      final state     = await HbcChannel.reflutterCloudState();
      final running   = state['running'] == true;
      final status    = (state['status'] as String?) ?? '';
      final logs      = (state['logs']   as String?) ?? '';
      final filePath  = (state['filePath']  as String?) ?? '';
      final outputDir = (state['outputDir'] as String?) ?? '';

      if (running && mounted) {
        setState(() {
          _isProcessing     = true;
          _logVisible       = true;
          _logs             = logs;
          _selectedFilePath = filePath.isNotEmpty ? filePath : _selectedFilePath;
          _selectedFileName = filePath.isNotEmpty ? filePath.split('/').last : _selectedFileName;
        });
        _logCtrl.forward(from: 0);
        if (!_stopwatch.isRunning) _startTimer();
        _startPolling();
      } else if (status == 'success' && mounted) {
        setState(() {
          _isProcessing = false;
          _logVisible   = true;
          _logs         = logs;
          _outputDir    = outputDir.isNotEmpty ? outputDir : null;
          _selectedFilePath = filePath.isNotEmpty ? filePath : _selectedFilePath;
          _selectedFileName = filePath.isNotEmpty ? filePath.split('/').last : _selectedFileName;
        });
        _logCtrl.forward(from: 0);
        _showSnack('Patch complete', icon: Icons.check_circle_rounded, color: const Color(0xFF22c55e));
      } else if (status == 'cancelled' && mounted) {
        setState(() { _isProcessing = false; _logVisible = true; _logs = logs; });
        _logCtrl.forward(from: 0);
        _showSnack('Operation cancelled', icon: Icons.cancel_outlined, color: const Color(0xFFf59e0b));
      } else if (status == 'error' && logs.isNotEmpty && mounted) {
        final error = (state['error'] as String?) ?? 'Operation failed';
        setState(() { _isProcessing = false; _logVisible = true; _logs = logs; });
        _logCtrl.forward(from: 0);
        _showSnack(error, icon: Icons.error_rounded, color: _accent);
      }
    } catch (_) {}
  }

  void _startPolling() {
    _pollTimer?.cancel();
    _streamSub?.cancel();

    _streamSub = HbcChannel.logStream.listen((line) {
      if (!mounted) return;
      if (line.startsWith('DOWNLOAD_PROGRESS:')) {
        final pct = int.tryParse(line.substring('DOWNLOAD_PROGRESS:'.length)) ?? -1;
        setState(() { _downloadProgress = pct; });
        return;
      }
      if (line == '__TAURUS_DONE__') {
        _pollTimer?.cancel();
        _checkCloudState();
        return;
      }
      setState(() { _logs += '$line\n'; });
      if (_autoScroll) _scrollLogToBottom();
    });

    int consecutiveErrors = 0;
    _pollTimer = Timer.periodic(const Duration(seconds: 25), (_) async {
      try {
        final state     = await HbcChannel.reflutterCloudState();
        final running   = state['running'] == true;
        final status    = (state['status'] as String?) ?? '';
        final logs      = (state['logs']   as String?) ?? '';
        final outputDir = (state['outputDir'] as String?) ?? '';
        consecutiveErrors = 0;

        if (logs.isNotEmpty && mounted) {
          setState(() { _logs = logs; });
          if (_autoScroll) _scrollLogToBottom();
        }

        if (!running) {
          _pollTimer?.cancel();
          _streamSub?.cancel();
          final success   = status == 'success';
          final cancelled = status == 'cancelled';
          final totalTime = _stopTimer();

          if (mounted) {
            setState(() {
              _isProcessing     = false;
              _logs             = logs;
              _outputDir        = outputDir.isNotEmpty ? outputDir : null;
              _downloadProgress = -1;
              _logs += '\n${cancelled ? "Cancelled" : success ? "Completed" : "Failed"} in $totalTime\n';
            });
            _showSnack(
              cancelled ? 'Operation cancelled' : success ? 'Patch complete — $totalTime' : 'Operation failed',
              icon: success && !cancelled ? Icons.check_circle_rounded : (cancelled ? Icons.cancel_outlined : Icons.error_rounded),
              color: success && !cancelled ? const Color(0xFF22c55e) : (cancelled ? const Color(0xFFf59e0b) : _accent),
            );
          }
        }
      } catch (_) {
        consecutiveErrors++;
        if (consecutiveErrors >= 5 && mounted) {
          _pollTimer?.cancel();
          _streamSub?.cancel();
          _stopTimer();
          setState(() { _isProcessing = false; _downloadProgress = -1; });
          _showSnack('Connection lost', icon: Icons.error_rounded, color: _accent);
        }
      }
    });
  }

  void _startTimer() {
    _stopwatch.reset(); _stopwatch.start(); _tickTimer?.cancel();
    _tickTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      final e = _stopwatch.elapsed;
      setState(() {
        _elapsed = '${e.inMinutes.toString().padLeft(2, '0')}:'
            '${(e.inSeconds % 60).toString().padLeft(2, '0')}';
      });
    });
  }

  String _stopTimer() {
    _tickTimer?.cancel(); _stopwatch.stop();
    final e = _stopwatch.elapsed;
    final t = e.inSeconds < 60 ? '${e.inSeconds}s' : '${e.inMinutes}m ${e.inSeconds % 60}s';
    setState(() { _elapsed = '00:00'; });
    return t;
  }

  void _scrollLogToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_logScrollCtrl.hasClients) {
        _logScrollCtrl.animateTo(
          _logScrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _showSnack(String msg, {required IconData icon, required Color color}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(icon, color: color, size: 18),
        const SizedBox(width: 10),
        Expanded(child: Text(msg, style: const TextStyle(color: Colors.white))),
      ]),
      backgroundColor: const Color(0xFF1a0a00),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: color.withOpacity(0.4)),
      ),
      behavior: SnackBarBehavior.floating,
      duration: const Duration(seconds: 4),
    ));
  }

  Future<void> _pickFile() async {
    final hasPermission = await PermissionHelper.ensureStorage(context, accent: _accent);
    if (!hasPermission) return;

    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['apk'],
      allowMultiple: false,
    );
    if (result == null || result.files.isEmpty) return;

    final picked = result.files.first;
    final path   = picked.path;
    if (path == null) return;

    final file   = File(path);
    final sizeMb = file.lengthSync() / 1048576.0;

    if (sizeMb > 300) {
      setState(() {
        _selectedFilePath = path;
        _selectedFileName = picked.name;
        _fileStatus  = 'File too large (${sizeMb.toStringAsFixed(1)} MB) — 300 MB limit';
        _fileValid   = false;
      });
      return;
    }

    setState(() {
      _selectedFilePath = path;
      _selectedFileName = picked.name;
      _fileStatus       = 'APK ready — ${sizeMb.toStringAsFixed(1)} MB';
      _fileValid        = true;
    });
  }

  Future<void> _runOperation() async {
    if (!_fileValid || _selectedFilePath == null) return;

    final hasPermission = await PermissionHelper.ensureStorage(context, accent: _accent);
    if (!hasPermission) return;

    final outputDir = await StorageHelper.buildOutputDir(prefix: 'reflutter');

    setState(() {
      _isProcessing     = true;
      _logVisible       = true;
      _logs             = '';
      _outputDir        = null;
      _downloadProgress = -1;
    });
    _logCtrl.forward(from: 0);
    _startTimer();

    try {
      final result = await HbcChannel.reflutterAnalyze(
        filePath:  _selectedFilePath!,
        fileName:  _selectedFileName ?? _selectedFilePath!.split('/').last,
        outputDir: outputDir,
      );

      if (result['started'] != true) {
        final msg = (result['error'] as String?) ?? 'Could not start operation';
        setState(() { _isProcessing = false; });
        _stopTimer();
        _showSnack(msg, icon: Icons.error_rounded, color: _accent);
        return;
      }

      _startPolling();
    } catch (e) {
      setState(() { _isProcessing = false; });
      _stopTimer();
      _showSnack('Failed to start: $e', icon: Icons.error_rounded, color: _accent);
    }
  }

  Future<void> _cancelOperation() async {
    _pollTimer?.cancel();
    _tickTimer?.cancel();
    _streamSub?.cancel();
    await HbcChannel.reflutterCancel();
    if (!mounted) return;
    setState(() { _isProcessing = false; });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Operation cancelled'),
        backgroundColor: Color(0xFF1a0a00),
        duration: Duration(seconds: 3),
      ),
    );
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _streamSub?.cancel();
    _tickTimer?.cancel();
    _pulseCtrl.dispose();
    _orbitCtrl.dispose();
    _logCtrl.dispose();
    _logScrollCtrl.dispose();
    _pageScrollCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => true,
      child: Scaffold(
        body: SafeArea(
          child: Column(
            children: [
              _buildTopBar(),
              Expanded(
                child: SingleChildScrollView(
                  controller: _pageScrollCtrl,
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const SizedBox(height: 12),
                      _buildHeader(),
                      const SizedBox(height: 18),
                      _buildFileSelector(),
                      const SizedBox(height: 14),
                      _buildActionRow(),
                      if (_logVisible) ...[
                        const SizedBox(height: 16),
                        _buildLogPanel(),
                      ],
                      if (_outputDir != null && !_isProcessing) ...[
                        const SizedBox(height: 16),
                        _buildOutputCard(),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 8, 16, 4),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 20),
            onPressed: () => Navigator.pop(context),
          ),
          const Expanded(
            child: Text('ReFlutter',
                style: TextStyle(color: Colors.white, fontSize: 18,
                    fontWeight: FontWeight.w800, letterSpacing: 0.5)),
          ),
          if (_isProcessing)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: _accent.withOpacity(0.15),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _accent.withOpacity(0.4)),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                SizedBox(
                  width: 10, height: 10,
                  child: CircularProgressIndicator(strokeWidth: 1.5, color: _accent),
                ),
                const SizedBox(width: 6),
                Text(_elapsed,
                    style: TextStyle(color: _accent, fontSize: 11, fontFamily: 'monospace')),
              ]),
            ),
          if (!_isProcessing && _outputDir != null)
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: _accent.withOpacity(0.15),
                foregroundColor: _accent,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                side: BorderSide(color: _accent.withOpacity(0.4)),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                elevation: 0,
              ),
              onPressed: () => Navigator.pop(context),
              child: const Text('Leave'),
            ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return AnimatedBuilder(
      animation: Listenable.merge([_pulseAnim, _orbitCtrl]),
      builder: (_, __) {
        final pulse = _pulseAnim.value;
        final orbit = _orbitCtrl.value;
        return Container(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(
              colors: [Color(0xFF1a0800), Color(0xFF1a0a04), Color(0xFF1a0800)],
              begin: Alignment.topLeft, end: Alignment.bottomRight,
            ),
            border: Border.all(
              color: Color.lerp(
                _accent.withOpacity(0.25), _accentLight.withOpacity(0.20), pulse)!),
            boxShadow: [
              BoxShadow(color: _accent.withOpacity(0.05 + pulse * 0.06),
                  blurRadius: 24, spreadRadius: 2),
            ],
          ),
          child: Row(children: [
            SizedBox(
              width: 80, height: 80,
              child: Stack(alignment: Alignment.center, children: [
                Transform.rotate(
                  angle: orbit * 2 * math.pi,
                  child: CustomPaint(
                    size: const Size(74, 74),
                    painter: _RfOrbitPainter(color: _accent, opacity: 0.4 + pulse * 0.25),
                  ),
                ),
                Transform.scale(
                  scale: 1.0 + pulse * 0.04,
                  child: Container(
                    width: 56, height: 56,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      gradient: LinearGradient(colors: [
                        Color.lerp(const Color(0xFF3a1200), const Color(0xFF4a1800), pulse)!,
                        const Color(0xFF1a0800),
                      ], begin: Alignment.topLeft, end: Alignment.bottomRight),
                      boxShadow: [BoxShadow(
                        color: _accent.withOpacity(0.3 + pulse * 0.2),
                        blurRadius: 16, spreadRadius: 1,
                      )],
                    ),
                    child: Icon(Icons.settings_ethernet_rounded, color: _accent, size: 28),
                  ),
                ),
              ]),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('ReFlutter',
                    style: TextStyle(
                      color: Color.lerp(_accent, _accentLight, pulse),
                      fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: 0.5,
                    )),
                const SizedBox(height: 4),
                Text('Patches Flutter\'s libflutter.so for HTTPS\ninterception. Install the patched APK then\nuse HTTP Canary, Proxy Pin or any proxy.',
                    style: TextStyle(color: Colors.white.withOpacity(0.55), fontSize: 11.5)),
              ]),
            ),
          ]),
        );
      },
    );
  }

  Widget _buildFileSelector() {
    final hasFile = _selectedFileName != null;
    return GestureDetector(
      onTap: _isProcessing ? null : _pickFile,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: const Color(0xFF111120),
          border: Border.all(
            color: hasFile && _fileValid
                ? _accent.withOpacity(0.5)
                : hasFile && !_fileValid
                    ? const Color(0xFFf59e0b).withOpacity(0.5)
                    : const Color(0xFF1e1e38),
          ),
        ),
        child: Row(children: [
          Container(
            width: 44, height: 44,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: hasFile && _fileValid
                  ? _accent.withOpacity(0.12)
                  : const Color(0xFF1a1a2e),
              border: Border.all(color: hasFile && _fileValid
                  ? _accent.withOpacity(0.4) : const Color(0xFF2a2a4a)),
            ),
            child: Icon(
              hasFile ? Icons.android_rounded : Icons.upload_file_rounded,
              color: hasFile && _fileValid ? _accent : const Color(0xFF4a4a6a),
              size: 22,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(
              hasFile ? _selectedFileName! : 'Tap to select Flutter APK',
              style: TextStyle(
                color: hasFile ? Colors.white : const Color(0xFF6b7280),
                fontSize: 13, fontWeight: FontWeight.w600,
              ),
              maxLines: 1, overflow: TextOverflow.ellipsis,
            ),
            if (_fileStatus != null) ...[
              const SizedBox(height: 2),
              Text(_fileStatus!,
                  style: TextStyle(
                    color: _fileValid
                        ? _accent.withOpacity(0.8)
                        : const Color(0xFFf59e0b),
                    fontSize: 10.5,
                  )),
            ],
          ])),
          if (_isProcessing)
            Icon(Icons.lock_rounded, color: const Color(0xFF4a4a6a), size: 18)
          else
            Icon(Icons.chevron_right_rounded,
                color: hasFile ? _accent.withOpacity(0.6) : const Color(0xFF4a4a6a), size: 20),
        ]),
      ),
    );
  }


  Widget _buildActionRow() {
    final canRun = _fileValid && !_isProcessing;
    return Row(children: [
      if (_isProcessing) ...[
        Expanded(
          child: OutlinedButton.icon(
            icon: const Icon(Icons.stop_rounded, size: 18),
            label: const Text('Cancel'),
            style: OutlinedButton.styleFrom(
              foregroundColor: const Color(0xFFf87171),
              side: const BorderSide(color: Color(0xFFf87171), width: 1.2),
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            onPressed: _cancelOperation,
          ),
        ),
      ] else ...[
        Expanded(
          child: ElevatedButton.icon(
            icon: const Icon(Icons.memory_rounded, size: 18),
            label: const Text('Patch Engine'),
            style: ElevatedButton.styleFrom(
              backgroundColor: canRun ? _accent : const Color(0xFF2a2a3e),
              foregroundColor: canRun ? Colors.white : const Color(0xFF4a4a6a),
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              elevation: canRun ? 2 : 0,
            ),
            onPressed: canRun ? _runOperation : null,
          ),
        ),
        if (_outputDir != null) ...[
          const SizedBox(width: 10),
          OutlinedButton(
            style: OutlinedButton.styleFrom(
              foregroundColor: const Color(0xFF94a3b8),
              side: const BorderSide(color: Color(0xFF2a2a4a)),
              padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            onPressed: () async {
              await HbcChannel.reflutterClearState();
              setState(() {
                _outputDir = null;
                _logVisible = false;
                _logs = '';
              });
            },
            child: const Text('Clear'),
          ),
        ],
      ],
    ]);
  }

  Widget _buildLogPanel() {
    return FadeTransition(
      opacity: _logFade,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: const Color(0xFF0a0a14),
          border: Border.all(color: _accent.withOpacity(0.15)),
        ),
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 10, 8, 6),
            child: Row(children: [
              Icon(Icons.terminal_rounded, color: _accent.withOpacity(0.7), size: 14),
              const SizedBox(width: 8),
              Text('Output',
                  style: TextStyle(color: _accent.withOpacity(0.8),
                      fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 0.5)),
              const Spacer(),
              if (_downloadProgress >= 0 && _downloadProgress < 100) ...[
                SizedBox(
                  width: 80,
                  child: LinearProgressIndicator(
                    value: _downloadProgress / 100,
                    color: _accent,
                    backgroundColor: _accent.withOpacity(0.15),
                    minHeight: 3,
                  ),
                ),
                const SizedBox(width: 6),
                Text('$_downloadProgress%',
                    style: TextStyle(color: _accent, fontSize: 10, fontFamily: 'monospace')),
                const SizedBox(width: 6),
              ],
              IconButton(
                icon: Icon(_autoScroll ? Icons.vertical_align_bottom_rounded : Icons.pause_rounded,
                    size: 16, color: Colors.white38),
                onPressed: () => setState(() => _autoScroll = !_autoScroll),
                padding: EdgeInsets.zero, constraints: const BoxConstraints(),
              ),
              const SizedBox(width: 8),
              IconButton(
                icon: const Icon(Icons.copy_rounded, size: 14, color: Colors.white38),
                onPressed: () => Clipboard.setData(ClipboardData(text: _logs)),
                padding: EdgeInsets.zero, constraints: const BoxConstraints(),
              ),
              const SizedBox(width: 8),
            ]),
          ),
          const Divider(height: 1, color: Color(0xFF1a1a2e)),
          SizedBox(
            height: 220,
            child: ListView.builder(
              controller: _logScrollCtrl,
              padding: const EdgeInsets.fromLTRB(14, 8, 14, 12),
              itemCount: _logs.split('\n').length,
              itemBuilder: (_, i) {
                final line = _logs.split('\n')[i];
                Color lineColor = Colors.white60;
                if (line.startsWith('⚙')) lineColor = _accent;
                else if (line.contains('ERROR') || line.contains('failed')) lineColor = const Color(0xFFf87171);
                else if (line.contains('complete') || line.contains('✓')) lineColor = const Color(0xFF4ade80);
                else if (line.startsWith('   ⏳')) lineColor = Colors.white38;
                return Text(line,
                    style: TextStyle(
                      color: lineColor,
                      fontSize: 10.5,
                      fontFamily: 'monospace',
                      height: 1.5,
                    ));
              },
            ),
          ),
        ]),
      ),
    );
  }

  Widget _buildOutputCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: const Color(0xFF0a140a),
        border: Border.all(color: const Color(0xFF22c55e).withOpacity(0.3)),
      ),
      child: Row(children: [
        Container(
          width: 44, height: 44,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            color: const Color(0xFF22c55e).withOpacity(0.12),
            border: Border.all(color: const Color(0xFF22c55e).withOpacity(0.4)),
          ),
          child: const Icon(Icons.check_circle_rounded, color: Color(0xFF22c55e), size: 22),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Engine Patched',
              style: TextStyle(color: Color(0xFF22c55e), fontSize: 13, fontWeight: FontWeight.w700)),
          const SizedBox(height: 2),
          Text(_outputDir ?? '',
              style: TextStyle(color: Colors.white.withOpacity(0.45), fontSize: 10.5),
              maxLines: 2, overflow: TextOverflow.ellipsis),
        ])),
      ]),
    );
  }
}

class _RfOrbitPainter extends CustomPainter {
  final Color color;
  final double opacity;
  const _RfOrbitPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withOpacity(opacity * 0.5)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;
    canvas.drawOval(
      Rect.fromCenter(center: Offset(size.width / 2, size.height / 2),
          width: size.width * 0.9, height: size.height * 0.55),
      paint,
    );
    canvas.drawOval(
      Rect.fromCenter(center: Offset(size.width / 2, size.height / 2),
          width: size.width * 0.55, height: size.height * 0.9),
      paint..color = color.withOpacity(opacity * 0.3),
    );
  }

  @override
  bool shouldRepaint(_RfOrbitPainter o) => o.opacity != opacity;
}
