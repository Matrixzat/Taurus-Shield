import 'package:flutter/material.dart';

import '../utils/theme_provider.dart';

class HowItWorksScreen extends StatelessWidget {
  const HowItWorksScreen({super.key});

  static const List<_Step> _steps = [
    _Step(
      icon: Icons.grid_view_rounded,
      title: 'Browse the toolbox',
      body:
          'The home screen shows every tool — Blutter, Dex2C, DPT Shell, VM Protect, APK Tool, SSL Unpinner, Black Forge, Pine Hook (HBC), the encryptor hub, and more. Use the search bar at the top to filter the grid.',
    ),
    _Step(
      icon: Icons.touch_app_rounded,
      title: 'Tap a tool to open it',
      body:
          'Each tile opens a dedicated screen. Read the short header inside that screen — it tells you what file types it accepts (APK, ZIP, HBC bundle, JS, PHP, …) and what the tool will do to them.',
    ),
    _Step(
      icon: Icons.upload_file_rounded,
      title: 'Pick a file & run',
      body:
          'For tools that process files: tap the picker, select your APK or bundle, then tap the action button. The progress and live logs appear in-screen. Most tools run on Cloudflare Workers — nothing is stored after processing.',
    ),
    _Step(
      icon: Icons.cloud_upload_rounded,
      title: 'Share results with File Uploader',
      body:
          'When you have a finished APK / file you want to send to someone, open File Uploader from the drawer. It uploads to a temporary host (Litterbox, filebin, qu.ax, x0.at, uguu.se, tmpfiles) and gives you back a one-tap shareable link.',
    ),
    _Step(
      icon: Icons.palette_rounded,
      title: 'Make it yours',
      body:
          'Open the drawer (top-left) → Themes to switch between the built-in colour schemes. The drawer also gets you to About, Developer, Credits, Privacy Policy, Report a Bug and the community links.',
    ),
    _Step(
      icon: Icons.update_rounded,
      title: 'Stay updated',
      body:
          'The app checks for updates on launch. When a new build is available you\'ll see a prompt — tap it to install. The Changelog screen shows what changed between versions.',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final t = ThemeProvider().current;
    return Scaffold(
      appBar: AppBar(
        title: const Text('HOW IT WORKS'),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [t.appBarBg, t.headerBg1],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _Hero(),
            const SizedBox(height: 18),
            for (int i = 0; i < _steps.length; i++) ...[
              _StepCard(index: i + 1, step: _steps[i]),
              if (i != _steps.length - 1) const SizedBox(height: 12),
            ],
            const SizedBox(height: 18),
            _OutroTip(),
          ],
        ),
      ),
    );
  }
}

class _Step {
  final IconData icon;
  final String title;
  final String body;
  const _Step({required this.icon, required this.title, required this.body});
}

class _Hero extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final t = ThemeProvider().current;
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: LinearGradient(
          colors: [t.headerBg1, t.headerBg2],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        border: Border.all(color: t.primary.withOpacity(0.4)),
        boxShadow: [
          BoxShadow(
            color: t.primary.withOpacity(0.15),
            blurRadius: 24,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              gradient: LinearGradient(
                colors: [t.primary, t.secondary],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: t.primary.withOpacity(0.5),
                  blurRadius: 18,
                ),
              ],
            ),
            child: const Icon(Icons.menu_book_rounded,
                color: Colors.white, size: 32),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('TAURUS SHIELD',
                    style: TextStyle(
                        color: t.textColor,
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2.5)),
                const SizedBox(height: 4),
                Text(
                    'A quick walk-through of how the toolbox is laid out and the easiest way to get something done.',
                    style: TextStyle(
                        color: t.subtextColor.withOpacity(0.85),
                        fontSize: 12,
                        height: 1.45)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _StepCard extends StatelessWidget {
  final int index;
  final _Step step;
  const _StepCard({required this.index, required this.step});

  @override
  Widget build(BuildContext context) {
    final t = ThemeProvider().current;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: t.surfaceColor,
        border: Border.all(color: t.primary.withOpacity(0.25)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            alignment: Alignment.center,
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  gradient: LinearGradient(
                    colors: [
                      t.primary.withOpacity(0.85),
                      t.secondary.withOpacity(0.85),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: Icon(step.icon, color: Colors.white, size: 22),
              ),
              Positioned(
                right: -4,
                top: -4,
                child: Container(
                  width: 22,
                  height: 22,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: t.surfaceColor,
                    border:
                        Border.all(color: t.secondary.withOpacity(0.8), width: 1.5),
                  ),
                  alignment: Alignment.center,
                  child: Text('$index',
                      style: TextStyle(
                          color: t.secondary,
                          fontSize: 11,
                          fontWeight: FontWeight.w900)),
                ),
              ),
            ],
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(step.title,
                    style: TextStyle(
                        color: t.textColor,
                        fontSize: 14.5,
                        fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text(step.body,
                    style: TextStyle(
                        color: t.subtextColor.withOpacity(0.85),
                        fontSize: 12.5,
                        height: 1.45)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _OutroTip extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final t = ThemeProvider().current;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: t.primary.withOpacity(0.10),
        border: Border.all(color: t.primary.withOpacity(0.30)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.lightbulb_outline_rounded,
              color: t.secondary, size: 22),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
                'Tip: long-press any tool tile on the home screen for a quick description.',
                style: TextStyle(
                    color: t.subtextColor.withOpacity(0.95),
                    fontSize: 12.5,
                    height: 1.4)),
          ),
        ],
      ),
    );
  }
}
