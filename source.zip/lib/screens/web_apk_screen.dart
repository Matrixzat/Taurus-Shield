import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../utils/hbc_channel.dart';
import '../utils/storage_helper.dart';

const _kChannel = MethodChannel('com.taurus.shield/webapk');

// ── Design tokens (from reference CSS) ────────────────────────────────────────
const _kPrimary     = Color(0xFFFF0A0A);
const _kPrimaryDark = Color(0xFFCC0000);
const _kPrimaryGlow = Color(0x66FF0A0A);
const _kBg          = Color(0xFF000000);
const _kCard        = Color(0xFF000000);
const _kBorder      = Color(0xFF1A1A1A);
const _kBorderRed   = Color(0x4DFF0A0A);
const _kTextPrim    = Color(0xFFFFFFFF);
const _kTextSec     = Color(0xFF888888);
const _kTextMuted   = Color(0xFF555555);
const _kSuccess     = Color(0xFF00FF88);
const _kError       = Color(0xFFFF4444);
const _kWarning     = Color(0xFFFFAA00);

class WebApkScreen extends StatefulWidget {
  const WebApkScreen({super.key});
  @override
  State<WebApkScreen> createState() => _WebApkScreenState();
}

class _WebApkScreenState extends State<WebApkScreen>
    with TickerProviderStateMixin {

  // ── Tabs ──────────────────────────────────────────────────────────────────
  late final TabController _tabs;

  // ── Form fields ───────────────────────────────────────────────────────────
  final _urlCtrl     = TextEditingController();
  final _nameCtrl    = TextEditingController(text: 'My App');
  final _pkgCtrl     = TextEditingController(text: 'com.example.myapp');
  String _iconBase64 = '';
  String _iconLabel  = 'No icon selected (default)';
  String _iconShape  = 'squircle';
  bool   _biometric  = false;
  int    _bioTimeoutMin = 5;
  String _bioType    = 'both';
  bool   _darkTheme  = true;
  bool   _edgeToEdge = false;
  bool   _pullRefresh= true;
  bool   _signApk    = true;
  String _lottieBase64 = '';
  String _lottieLabel  = 'No Lottie selected';

  // ── Advanced features (all default OFF) ───────────────────────────────────
  final _versionNameCtrl      = TextEditingController(text: '1.0.0');
  int    _versionCode          = 1;
  bool   _screenshotPrevention = false;
  bool   _zoomEnabled          = false;
  bool   _deepLinkEnabled      = false;
  final  _deepLinkSchemeCtrl   = TextEditingController();
  bool   _incognitoOnExit      = false;
  bool   _pipEnabled           = false;
  bool   _landscapeMode        = false;

  // ── Build state ───────────────────────────────────────────────────────────
  bool   _running    = false;
  String _phase      = '';
  int    _progress   = 0;
  String _status     = '';
  String _outputPath = '';
  String _error      = '';
  String _appName    = '';
  final  _logLines   = <String>[];
  final  _scrollCtrl = ScrollController();
  Timer? _pollTimer;
  StreamSubscription? _logSub;

  // ── Animation controllers ─────────────────────────────────────────────────
  late final AnimationController _pulseCtrl;      // card/border glow pulse
  late final AnimationController _shimmerCtrl;    // title text shimmer
  late final AnimationController _spin1;          // outer ring 1.2s
  late final AnimationController _spin2;          // middle ring 0.9s reverse
  late final AnimationController _spin3;          // inner ring 0.6s
  late final AnimationController _centerPulse;    // build icon pulse
  late final AnimationController _slideCtrl;      // entry slide-up

  // Timeout options matching reference CSS (minutes → display label)
  static const _kTimeouts = [
    {'value': 1,    'label': '1 min'},
    {'value': 5,    'label': '5 min'},
    {'value': 15,   'label': '15 min'},
    {'value': 30,   'label': '30 min'},
    {'value': 60,   'label': '1 hour'},
    {'value': 1440, 'label': '1 day'},
    {'value': 10080,'label': '1 week'},
    {'value': 0,    'label': 'Never'},
  ];

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 2, vsync: this);

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);

    _shimmerCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();

    _spin1 = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat();

    _spin2 = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat();

    _spin3 = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..repeat();

    _centerPulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _slideCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    )..forward();

    _urlCtrl.addListener(_saveForm);
    _nameCtrl.addListener(_saveForm);
    _pkgCtrl.addListener(_saveForm);
    _versionNameCtrl.addListener(_saveForm);
    _deepLinkSchemeCtrl.addListener(_saveForm);
    _loadForm();
    _loadState();
    _startLogStream();
  }

  void _startLogStream() {
    _logSub = HbcChannel.logStream.listen((line) {
      if (!mounted) return;
      if (line.contains('[WebApk]') || _running) {
        setState(() => _logLines.add(line));
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_scrollCtrl.hasClients) {
            _scrollCtrl.animateTo(
              _scrollCtrl.position.maxScrollExtent,
              duration: const Duration(milliseconds: 200),
              curve: Curves.easeOut,
            );
          }
        });
      }
    });
  }

  Future<void> _loadState() async {
    try {
      final raw = await _kChannel.invokeMapMethod<String, dynamic>('webapk_state') ?? {};
      if (!mounted) return;
      setState(() {
        _running    = raw['running']    as bool?   ?? false;
        _phase      = raw['phase']      as String? ?? '';
        _progress   = raw['progress']  as int?    ?? 0;
        _status     = raw['status']    as String? ?? '';
        _outputPath = raw['outputPath']as String? ?? '';
        _error      = raw['error']     as String? ?? '';
        _appName    = raw['appName']   as String? ?? '';
        final logs  = raw['logs']      as String? ?? '';
        if (logs.isNotEmpty) {
          _logLines.clear();
          _logLines.addAll(logs.split('\n').where((l) => l.isNotEmpty));
        }
      });
      if (_running) {
        _startPolling();
      } else if (_status.isNotEmpty) {
        _stopPolling();
      }
    } catch (_) {}
  }

  // ── Form persistence ──────────────────────────────────────────────────────
  Future<void> _loadForm() async {
    try {
      final p = await SharedPreferences.getInstance();
      if (!mounted) return;
      setState(() {
        final url  = p.getString('wa_url')  ?? '';
        final name = p.getString('wa_name') ?? 'My App';
        final pkg  = p.getString('wa_pkg')  ?? 'com.example.myapp';
        if (_urlCtrl.text  != url)  _urlCtrl.text  = url;
        if (_nameCtrl.text != name) _nameCtrl.text = name;
        if (_pkgCtrl.text  != pkg)  _pkgCtrl.text  = pkg;
        _iconBase64    = p.getString('wa_icon_b64')   ?? '';
        _iconLabel     = p.getString('wa_icon_label') ?? 'No icon selected (default)';
        _iconShape     = p.getString('wa_icon_shape') ?? 'squircle';
        _biometric     = p.getBool('wa_biometric')    ?? false;
        _bioTimeoutMin = p.getInt('wa_bio_mins')      ?? 5;
        _bioType       = p.getString('wa_bio_type')   ?? 'both';
        _darkTheme     = p.getBool('wa_dark_theme')   ?? true;
        _edgeToEdge    = p.getBool('wa_edge_to_edge') ?? false;
        _pullRefresh   = p.getBool('wa_pull_refresh') ?? true;
        _signApk       = p.getBool('wa_sign_apk')     ?? true;
        _lottieBase64  = p.getString('wa_lottie_b64')   ?? '';
        _lottieLabel   = p.getString('wa_lottie_label') ?? 'No Lottie selected';
        final vName = p.getString('wa_version_name') ?? '1.0.0';
        if (_versionNameCtrl.text != vName) _versionNameCtrl.text = vName;
        _versionCode          = p.getInt('wa_version_code')         ?? 1;
        _screenshotPrevention = p.getBool('wa_screenshot_prev')     ?? false;
        _zoomEnabled          = p.getBool('wa_zoom_enabled')        ?? false;
        _deepLinkEnabled      = p.getBool('wa_deep_link_enabled')   ?? false;
        final dScheme = p.getString('wa_deep_link_scheme') ?? '';
        if (_deepLinkSchemeCtrl.text != dScheme) _deepLinkSchemeCtrl.text = dScheme;
        _incognitoOnExit      = p.getBool('wa_incognito_on_exit')   ?? false;
        _pipEnabled           = p.getBool('wa_pip_enabled')         ?? false;
        _landscapeMode        = p.getBool('wa_landscape_mode')      ?? false;
      });
    } catch (_) {}
  }

  Future<void> _saveForm() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString('wa_url',         _urlCtrl.text);
      await p.setString('wa_name',        _nameCtrl.text);
      await p.setString('wa_pkg',         _pkgCtrl.text);
      await p.setString('wa_icon_b64',    _iconBase64);
      await p.setString('wa_icon_label',  _iconLabel);
      await p.setString('wa_icon_shape',  _iconShape);
      await p.setBool('wa_biometric',     _biometric);
      await p.setInt('wa_bio_mins',       _bioTimeoutMin);
      await p.setString('wa_bio_type',    _bioType);
      await p.setBool('wa_dark_theme',    _darkTheme);
      await p.setBool('wa_edge_to_edge',  _edgeToEdge);
      await p.setBool('wa_pull_refresh',  _pullRefresh);
      await p.setBool('wa_sign_apk',       _signApk);
      await p.setString('wa_lottie_b64',   _lottieBase64);
      await p.setString('wa_lottie_label', _lottieLabel);
      await p.setString('wa_version_name',     _versionNameCtrl.text);
      await p.setInt('wa_version_code',        _versionCode);
      await p.setBool('wa_screenshot_prev',    _screenshotPrevention);
      await p.setBool('wa_zoom_enabled',       _zoomEnabled);
      await p.setBool('wa_deep_link_enabled',  _deepLinkEnabled);
      await p.setString('wa_deep_link_scheme', _deepLinkSchemeCtrl.text);
      await p.setBool('wa_incognito_on_exit',  _incognitoOnExit);
      await p.setBool('wa_pip_enabled',        _pipEnabled);
      await p.setBool('wa_landscape_mode',     _landscapeMode);
    } catch (_) {}
  }

  void _startPolling() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 1), (_) => _loadState());
  }

  void _stopPolling() => _pollTimer?.cancel();

  @override
  void dispose() {
    _tabs.dispose();
    _urlCtrl.dispose();
    _nameCtrl.dispose();
    _pkgCtrl.dispose();
    _versionNameCtrl.dispose();
    _deepLinkSchemeCtrl.dispose();
    _scrollCtrl.dispose();
    _pollTimer?.cancel();
    _logSub?.cancel();
    _pulseCtrl.dispose();
    _shimmerCtrl.dispose();
    _spin1.dispose();
    _spin2.dispose();
    _spin3.dispose();
    _centerPulse.dispose();
    _slideCtrl.dispose();
    super.dispose();
  }

  // ── Icon picker ───────────────────────────────────────────────────────────
  Future<void> _pickIcon() async {
    final res = await FilePicker.platform.pickFiles(
      type: FileType.image,
      allowMultiple: false,
    );
    if (res == null || res.files.isEmpty || res.files.first.path == null) return;
    if (!mounted) return;

    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.88),
      builder: (_) => _IconCropDialog(imagePath: res.files.first.path!),
    );

    if (result == null || !mounted) return;
    final Uint8List maskedBytes = result['bytes'] as Uint8List;
    final String   shape       = result['shape']  as String;
    setState(() {
      _iconBase64 = base64Encode(maskedBytes);
      _iconShape  = shape;
      _iconLabel  = res.files.first.name;
    });
    _saveForm();
  }

  // ── Lottie picker ─────────────────────────────────────────────────────────
  Future<void> _pickLottie() async {
    final res = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['json'],
      allowMultiple: false,
    );
    if (res == null || res.files.isEmpty || res.files.first.path == null) return;
    if (!mounted) return;
    final file = File(res.files.first.path!);
    final bytes = await file.readAsBytes();
    // Validate it looks like JSON
    try { jsonDecode(utf8.decode(bytes)); } catch (_) {
      _showSnack('Invalid JSON file — please select a Lottie .json', isError: true);
      return;
    }
    setState(() {
      _lottieBase64 = base64Encode(bytes);
      _lottieLabel  = res.files.first.name;
    });
    _saveForm();
  }

  Future<void> _openLottieFiles() async {
    final uri = Uri.parse('https://lottiefiles.com');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  // ── Build ─────────────────────────────────────────────────────────────────
  bool _isValidPackage(String pkg) {
    if (pkg.isEmpty) return false;
    final parts = pkg.split('.');
    if (parts.length < 2) return false;
    final valid = RegExp(r'^[a-zA-Z][a-zA-Z0-9_]*$');
    return parts.every((p) => p.isNotEmpty && valid.hasMatch(p));
  }

  Future<void> _startBuild() async {
    final url = _urlCtrl.text.trim();
    if (url.isEmpty) {
      _showSnack('Please enter a target URL.', isError: true);
      return;
    }
    final parsed = Uri.tryParse(url);
    if (parsed == null || !parsed.isAbsolute) {
      _showSnack('URL must start with https://', isError: true);
      return;
    }
    final pkg = _pkgCtrl.text.trim().toLowerCase();
    if (!_isValidPackage(pkg)) {
      _showSnack('Invalid package name — use format: com.company.app', isError: true);
      return;
    }
    setState(() {
      _running = true; _phase = 'initialising'; _progress = 0;
      _status = ''; _outputPath = ''; _error = ''; _logLines.clear();
    });
    _tabs.animateTo(1);
    _startPolling();
    final appName = _nameCtrl.text.trim().isEmpty ? 'My App' : _nameCtrl.text.trim();
    try {
      final configJson = jsonEncode({
        'mainURL':              url,
        'appName':              appName,
        'packageId':            pkg,
        'biometric':            _biometric,
        'bioTimeoutMin':        _bioTimeoutMin,
        'bioType':              _bioType,
        'edgeToEdge':           _edgeToEdge,
        'darkTheme':            _darkTheme,
        'pullRefresh':          _pullRefresh,
        'signApk':              _signApk,
        'versionName':          _versionNameCtrl.text.trim().isEmpty ? '1.0.0' : _versionNameCtrl.text.trim(),
        'versionCode':          _versionCode,
        'screenshotPrevention': _screenshotPrevention,
        'zoomEnabled':          _zoomEnabled,
        'deepLinkEnabled':      _deepLinkEnabled,
        'deepLinkScheme':       _deepLinkSchemeCtrl.text.trim(),
        'incognitoOnExit':      _incognitoOnExit,
        'pipEnabled':           _pipEnabled,
        'forceLandscapeMode':   _landscapeMode,
      });
      final outputDir = await StorageHelper.buildOutputDir(prefix: 'web2apk');
      await _kChannel.invokeMethod('webapk_cloud_build', {
        'configJson':   configJson,
        'iconBase64':   _iconBase64,
        'lottieBase64': _lottieBase64,
        'appName':      appName,
        'outputDir':    outputDir,
      });
    } catch (e) {
      if (!mounted) return;
      setState(() { _running = false; _error = e.toString(); _status = 'error'; });
      _stopPolling();
    }
  }

  Future<void> _cancelBuild() async {
    try { await _kChannel.invokeMethod('webapk_cancel'); } catch (_) {}
    setState(() { _running = false; _status = 'cancelled'; });
    _stopPolling();
  }

  Future<void> _clearState() async {
    try { await _kChannel.invokeMethod('webapk_clear'); } catch (_) {}
    setState(() {
      _running = false; _phase = ''; _progress = 0;
      _status = ''; _outputPath = ''; _error = ''; _logLines.clear();
    });
  }

  Future<void> _resetToDefaults() async {
    if (_running) {
      _showSnack('Cancel the running build first', isError: true);
      return;
    }
    await _clearState();
    final p = await SharedPreferences.getInstance();
    await p.remove('wa_url');
    await p.remove('wa_name');
    await p.remove('wa_pkg');
    await p.remove('wa_icon_b64');
    await p.remove('wa_icon_label');
    await p.remove('wa_icon_shape');
    await p.remove('wa_biometric');
    await p.remove('wa_bio_timeout_min');
    await p.remove('wa_bio_type');
    await p.remove('wa_dark_theme');
    await p.remove('wa_edge_to_edge');
    await p.remove('wa_pull_refresh');
    await p.remove('wa_sign_apk');
    await p.remove('wa_lottie_b64');
    await p.remove('wa_lottie_label');
    await p.remove('wa_version_name');
    await p.remove('wa_version_code');
    await p.remove('wa_screenshot_prev');
    await p.remove('wa_zoom_enabled');
    await p.remove('wa_deep_link_enabled');
    await p.remove('wa_deep_link_scheme');
    await p.remove('wa_incognito_on_exit');
    await p.remove('wa_pip_enabled');
    await p.remove('wa_landscape_mode');
    setState(() {
      _urlCtrl.text   = '';
      _nameCtrl.text  = 'My App';
      _pkgCtrl.text   = 'com.example.myapp';
      _iconBase64     = '';
      _iconLabel      = 'No icon selected (default)';
      _iconShape      = 'squircle';
      _biometric      = false;
      _bioTimeoutMin  = 5;
      _bioType        = 'both';
      _darkTheme      = true;
      _edgeToEdge     = false;
      _pullRefresh    = true;
      _signApk        = true;
      _lottieBase64   = '';
      _lottieLabel    = 'No Lottie selected';
      _versionNameCtrl.text = '1.0.0';
      _versionCode          = 1;
      _screenshotPrevention = false;
      _zoomEnabled          = false;
      _deepLinkEnabled      = false;
      _deepLinkSchemeCtrl.text = '';
      _incognitoOnExit      = false;
      _pipEnabled           = false;
      _landscapeMode        = false;
    });
    _showSnack('Builder reset to defaults');
  }

  Future<void> _installApk() async {
    try {
      await _kChannel.invokeMethod('webapk_install', {'path': _outputPath});
    } catch (e) {
      if (!mounted) return;
      _showSnack('Install failed: $e', isError: true);
    }
  }

  void _shareApk() {
    if (_outputPath.isEmpty) return;
    Share.shareXFiles([XFile(_outputPath)], subject: 'Web2Apk: $_appName');
  }

  void _showSnack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(color: _kTextPrim)),
      backgroundColor: isError ? const Color(0xFF1A0000) : const Color(0xFF001A00),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
        side: BorderSide(
          color: isError ? _kError.withOpacity(0.4) : _kSuccess.withOpacity(0.4),
        ),
      ),
      behavior: SnackBarBehavior.floating,
    ));
  }

  // ══════════════════════════════════════════════════════════════════════════
  // ── BUILD ─────────────────────────────────────────────────────────────────
  // ══════════════════════════════════════════════════════════════════════════

  // ── Back confirmation ─────────────────────────────────────────────────────
  Future<void> _onBackPressed() async {
    final leave = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF0F0F0F),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: const BorderSide(color: _kPrimary, width: 1),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: _kPrimary.withOpacity(0.12),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.android_rounded,
                  color: Colors.white, size: 20),
            ),
            const SizedBox(width: 12),
            const Expanded(
              child: Text(
                'Leave Web2Apk Builder?',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w700),
              ),
            ),
          ],
        ),
        content: const Text(
          'Are you sure you want to go back? Any active build will continue running in the background.',
          style: TextStyle(
              color: Color(0xFF9ca3af), fontSize: 13, height: 1.6),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Stay',
                style: TextStyle(color: Color(0xFF6b7280))),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: _kPrimary,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
            ),
            child: const Text('Go Back',
                style: TextStyle(fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
    if (leave == true && mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _onBackPressed();
      },
      child: Scaffold(
        backgroundColor: _kBg,
        appBar: _buildAppBar(),
        body: TabBarView(
          controller: _tabs,
          children: [
            _buildSetupTab(),
            _buildBuildTab(),
          ],
        ),
      ),
    );
  }

  // ── AppBar ────────────────────────────────────────────────────────────────
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: _kBg,
      elevation: 0,
      centerTitle: true,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios_new_rounded,
            color: Colors.white, size: 20),
        onPressed: _onBackPressed,
      ),
      actions: [
        Tooltip(
          message: 'Reset to defaults',
          child: IconButton(
            icon: const Icon(Icons.restart_alt_rounded,
                color: Colors.white70, size: 22),
            onPressed: _resetToDefaults,
          ),
        ),
      ],
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Red gradient Android icon box
          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, __) => Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                gradient: const LinearGradient(
                  colors: [_kPrimary, Color(0xFFFF4444), _kPrimaryDark],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: _kPrimary.withOpacity(0.25 + _pulseCtrl.value * 0.25),
                    blurRadius: 10 + _pulseCtrl.value * 10,
                  ),
                ],
              ),
              child: const Icon(Icons.android_rounded, color: Colors.white, size: 20),
            ),
          ),
          const SizedBox(width: 10),
          // Shimmer title text
          AnimatedBuilder(
            animation: _shimmerCtrl,
            builder: (_, __) {
              final offset = _shimmerCtrl.value * 2 - 1;
              return ShaderMask(
                shaderCallback: (rect) => LinearGradient(
                  begin: Alignment(offset - 1, 0),
                  end: Alignment(offset + 1, 0),
                  colors: const [
                    Color(0xFFFFFFFF),
                    Color(0xFFFF6666),
                    Color(0xFFFFFFFF),
                  ],
                  stops: const [0.0, 0.5, 1.0],
                ).createShader(rect),
                child: const Text(
                  'Web2Apk Builder',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 18,
                    letterSpacing: 0.5,
                  ),
                ),
              );
            },
          ),
        ],
      ),
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(49),
        child: Column(
          children: [
            Container(height: 1, color: _kBorder),
            TabBar(
              controller: _tabs,
              indicatorColor: _kPrimary,
              indicatorWeight: 3,
              labelColor: _kPrimary,
              unselectedLabelColor: _kTextSec,
              tabs: const [
                Tab(icon: Icon(Icons.settings_rounded, size: 18), text: 'Setup'),
                Tab(icon: Icon(Icons.build_circle_outlined, size: 18), text: 'Build'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // ── SETUP TAB ─────────────────────────────────────────────────────────────
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildSetupTab() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
      children: [
        // ── Hero orbit animation ─────────────────────────────────────────────
        SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0, 0.35),
            end: Offset.zero,
          ).animate(CurvedAnimation(parent: _slideCtrl, curve: Curves.easeOutCubic)),
          child: FadeTransition(
            opacity: _slideCtrl,
            child: Center(
              child: AnimatedBuilder(
                animation: Listenable.merge([_pulseCtrl, _spin1, _spin2, _centerPulse, _shimmerCtrl]),
                builder: (_, __) {
                  final pulse  = _pulseCtrl.value;
                  final orbit  = _spin1.value * 0.22;   // slow forward orbit
                  final orbitR = 1.0 - _spin2.value * 0.14; // slow reverse
                  final cp     = _centerPulse.value;
                  final scan   = _shimmerCtrl.value;
                  final scanY  = scan * 74.0;
                  final scanOp = scan < 0.5
                      ? (scan * 2).clamp(0.0, 1.0)
                      : ((1.0 - scan) * 2).clamp(0.0, 1.0);

                  return SizedBox(
                    width: 134,
                    height: 134,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        // Outermost pulsing halo
                        Container(
                          width: 130 + pulse * 4,
                          height: 130 + pulse * 4,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: _kPrimary.withOpacity(0.06 + pulse * 0.07),
                              width: 1,
                            ),
                          ),
                        ),
                        // Outer arc orbit ring (3 dashed arcs + dot tips)
                        Transform.rotate(
                          angle: orbit * 2 * math.pi,
                          child: CustomPaint(
                            size: const Size(114, 114),
                            painter: _Web2ApkOrbitPainter(
                              color: Color.lerp(_kPrimary, Colors.white, pulse * 0.18)!,
                              opacity: 0.48 + pulse * 0.28,
                            ),
                          ),
                        ),
                        // Inner dot orbit ring (counter-rotating)
                        Transform.rotate(
                          angle: orbitR * 2 * math.pi,
                          child: CustomPaint(
                            size: const Size(94, 94),
                            painter: _Web2ApkDotOrbitPainter(
                              color: _kPrimary,
                              opacity: 0.28 + pulse * 0.22,
                            ),
                          ),
                        ),
                        // Centre icon box with glow + scan line
                        Transform.scale(
                          scale: 1.0 + cp * 0.05,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(22),
                            child: Stack(
                              children: [
                                Container(
                                  width: 78,
                                  height: 78,
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [
                                        Color.lerp(_kPrimary, _kPrimaryDark, pulse * 0.5)!,
                                        Colors.black,
                                      ],
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                    ),
                                    boxShadow: [
                                      BoxShadow(
                                        color: _kPrimary.withOpacity(0.30 + cp * 0.30),
                                        blurRadius: 28,
                                        spreadRadius: 4,
                                      ),
                                    ],
                                  ),
                                  child: const Icon(
                                    Icons.web_rounded,
                                    color: Colors.white,
                                    size: 40,
                                  ),
                                ),
                                // Scan line
                                Positioned(
                                  top: scanY - 2,
                                  left: 0,
                                  right: 0,
                                  child: Opacity(
                                    opacity: scanOp * 0.72,
                                    child: Container(
                                      height: 2,
                                      decoration: const BoxDecoration(
                                        gradient: LinearGradient(
                                          colors: [
                                            Colors.transparent,
                                            _kPrimary,
                                            Colors.transparent,
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        // Build badge corner
                        Positioned(
                          right: 22,
                          bottom: 20,
                          child: Container(
                            width: 24,
                            height: 24,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: _kPrimary.withOpacity(0.85 + pulse * 0.15),
                              boxShadow: [
                                BoxShadow(
                                  color: _kPrimary.withOpacity(0.5),
                                  blurRadius: 6,
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.build_rounded,
                              color: Colors.white,
                              size: 13,
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ),
        ),

        const SizedBox(height: 20),

        // ── Main title ──────────────────────────────────────────────────────
        SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0, 0.25),
            end: Offset.zero,
          ).animate(CurvedAnimation(parent: _slideCtrl, curve: const Interval(0.1, 1.0, curve: Curves.easeOut))),
          child: FadeTransition(
            opacity: CurvedAnimation(parent: _slideCtrl, curve: const Interval(0.1, 1.0)),
            child: Column(
              children: [
                RichText(
                  textAlign: TextAlign.center,
                  text: const TextSpan(
                    style: TextStyle(
                      color: _kTextPrim,
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      height: 1.2,
                    ),
                    children: [
                      TextSpan(text: 'Transform Any Website\nInto a '),
                      TextSpan(
                        text: 'Native Android App',
                        style: TextStyle(color: _kPrimary),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Build professional Android APKs from your website in minutes.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: _kTextSec,
                    fontSize: 12.5,
                    height: 1.5,
                  ),
                ),
              ],
            ),
          ),
        ),

        const SizedBox(height: 20),

        // ── Stats row ───────────────────────────────────────────────────────
        SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0, 0.2),
            end: Offset.zero,
          ).animate(CurvedAnimation(parent: _slideCtrl, curve: const Interval(0.2, 1.0, curve: Curves.easeOut))),
          child: FadeTransition(
            opacity: CurvedAnimation(parent: _slideCtrl, curve: const Interval(0.2, 1.0)),
            child: Row(
              children: [
                Expanded(child: _statItem('5K+', 'Apps Built', 0.0)),
                const SizedBox(width: 10),
                Expanded(child: _statItem('<3min', 'Build Time', 0.5)),
                const SizedBox(width: 10),
                Expanded(child: _statItem('100%', 'Free', 1.0)),
              ],
            ),
          ),
        ),

        const SizedBox(height: 24),

        // ── Section tag ─────────────────────────────────────────────────────
        _sectionTag('Builder'),
        const SizedBox(height: 6),
        _sectionTitle('Create Your APK'),
        const SizedBox(height: 4),
        const Text(
          'Fill in the details below to generate your Android app',
          style: TextStyle(color: _kTextSec, fontSize: 12),
        ),
        const SizedBox(height: 16),

        // ── Form card ───────────────────────────────────────────────────────
        _glowCard(children: [
          // App Name
          _formGroup(
            icon: Icons.label_rounded,
            label: 'App Name',
            child: _redTextField(
              ctrl: _nameCtrl,
              hint: 'e.g., My Awesome App',
            ),
          ),
          const SizedBox(height: 16),
          // URL
          _formGroup(
            icon: Icons.language_rounded,
            label: 'Website URL',
            child: _redTextField(
              ctrl: _urlCtrl,
              hint: 'https://example.com',
              inputType: TextInputType.url,
            ),
          ),
          const SizedBox(height: 16),
          // Package name — user editable
          _formGroup(
            icon: Icons.inventory_2_rounded,
            label: 'Package Name',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _redTextField(
                  ctrl: _pkgCtrl,
                  hint: 'com.company.appname',
                ),
                const SizedBox(height: 6),
                Row(
                  children: const [
                    Icon(Icons.info_outline_rounded, size: 12, color: _kTextMuted),
                    SizedBox(width: 5),
                    Expanded(
                      child: Text(
                        'Format: com.company.app · min 2 segments · lowercase',
                        style: TextStyle(color: _kTextMuted, fontSize: 10.5),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          // Version Name + Version Code
          _formGroup(
            icon: Icons.tag_rounded,
            label: 'Version',
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _redTextField(
                        ctrl: _versionNameCtrl,
                        hint: '1.0.0',
                      ),
                      const SizedBox(height: 5),
                      Row(
                        children: const [
                          Icon(Icons.info_outline_rounded, size: 12, color: _kTextMuted),
                          SizedBox(width: 4),
                          Text('Version name (e.g. 1.0.0)', style: TextStyle(color: _kTextMuted, fontSize: 10.5)),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Column(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        color: _kPrimary.withOpacity(0.13),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: _kPrimary.withOpacity(0.30)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          GestureDetector(
                            onTap: _versionCode > 1
                                ? () { setState(() => _versionCode--); _saveForm(); }
                                : null,
                            child: Container(
                              width: 36,
                              height: 46,
                              alignment: Alignment.center,
                              child: Icon(Icons.remove, size: 16, color: _versionCode > 1 ? _kTextPrim : _kTextMuted),
                            ),
                          ),
                          Container(
                            width: 44,
                            height: 46,
                            alignment: Alignment.center,
                            child: Text(
                              '$_versionCode',
                              style: const TextStyle(color: _kTextPrim, fontSize: 15, fontWeight: FontWeight.w700),
                            ),
                          ),
                          GestureDetector(
                            onTap: () { setState(() => _versionCode++); _saveForm(); },
                            child: Container(
                              width: 36,
                              height: 46,
                              alignment: Alignment.center,
                              child: const Icon(Icons.add, size: 16, color: _kTextPrim),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 5),
                    const Text('Build code', style: TextStyle(color: _kTextMuted, fontSize: 10.5)),
                  ],
                ),
              ],
            ),
          ),
        ]),

        const SizedBox(height: 14),

        // ── Icon picker card ─────────────────────────────────────────────────
        _glowCard(children: [
          _formGroup(
            icon: Icons.image_rounded,
            label: 'App Icon (Optional)',
            child: _iconBase64.isNotEmpty
                // ── Icon set: preview + shape badge + change/remove ──────────
                ? Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: _kBg,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _kSuccess.withOpacity(0.55), width: 1.5),
                    ),
                    child: Row(
                      children: [
                        // shaped preview
                        ClipPath(
                          clipper: _ShapeClipper(_iconShape),
                          child: Image.memory(
                            base64Decode(_iconBase64),
                            width: 56,
                            height: 56,
                            fit: BoxFit.cover,
                            gaplessPlayback: true,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  const Icon(Icons.check_circle_rounded, color: _kSuccess, size: 14),
                                  const SizedBox(width: 5),
                                  Expanded(
                                    child: Text(
                                      _iconLabel,
                                      style: const TextStyle(color: _kSuccess, fontSize: 12, fontWeight: FontWeight.w600),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 4),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                                decoration: BoxDecoration(
                                  color: _kPrimary.withOpacity(0.12),
                                  borderRadius: BorderRadius.circular(4),
                                  border: Border.all(color: _kPrimary.withOpacity(0.3)),
                                ),
                                child: Text(
                                  _iconShape == 'circle' ? '● Circle' : '■ Squircle',
                                  style: const TextStyle(color: _kPrimary, fontSize: 10, fontWeight: FontWeight.w700),
                                ),
                              ),
                              const SizedBox(height: 8),
                              Row(
                                children: [
                                  GestureDetector(
                                    onTap: _pickIcon,
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(6),
                                        border: Border.all(color: _kBorderRed),
                                      ),
                                      child: const Text('Change', style: TextStyle(color: _kPrimary, fontSize: 11)),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  GestureDetector(
                                    onTap: () {
                                      setState(() {
                                        _iconBase64 = '';
                                        _iconShape  = 'squircle';
                                        _iconLabel  = 'No icon selected (default)';
                                      });
                                      _saveForm();
                                    },
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(6),
                                        border: Border.all(color: _kError.withOpacity(0.4)),
                                      ),
                                      child: const Text('Remove', style: TextStyle(color: _kError, fontSize: 11)),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  )
                // ── No icon: upload box ──────────────────────────────────────
                : GestureDetector(
                    onTap: _pickIcon,
                    child: AnimatedBuilder(
                      animation: _pulseCtrl,
                      builder: (_, __) => Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: _kBg,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: _kBorderRed.withOpacity(0.3 + _pulseCtrl.value * 0.15),
                            width: 1.5,
                          ),
                        ),
                        child: Column(
                          children: [
                            const Icon(Icons.add_photo_alternate_rounded, color: _kPrimary, size: 30),
                            const SizedBox(height: 8),
                            const Text(
                              'Tap to select & crop your icon',
                              style: TextStyle(color: _kTextPrim, fontSize: 13, fontWeight: FontWeight.w500),
                            ),
                            const SizedBox(height: 4),
                            const Text(
                              'PNG, JPG · Choose Squircle or Circle shape · 512×512px recommended',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: _kTextMuted, fontSize: 11),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
          ),
        ]),

        const SizedBox(height: 14),

        // ── Lottie splash card ───────────────────────────────────────────────
        _glowCard(children: [
          _formGroup(
            icon: Icons.animation_rounded,
            label: 'Splash Animation (Optional)',
            child: _lottieBase64.isNotEmpty
                ? Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: _kBg,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _kSuccess.withOpacity(0.55), width: 1.5),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.check_circle_rounded, color: _kSuccess, size: 22),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            _lottieLabel,
                            style: const TextStyle(color: _kTextPrim, fontSize: 13, fontWeight: FontWeight.w500),
                            maxLines: 1, overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        const SizedBox(width: 8),
                        GestureDetector(
                          onTap: _pickLottie,
                          child: const Icon(Icons.refresh_rounded, color: _kTextSec, size: 18),
                        ),
                        const SizedBox(width: 8),
                        GestureDetector(
                          onTap: () {
                            setState(() { _lottieBase64 = ''; _lottieLabel = 'No Lottie selected'; });
                            _saveForm();
                          },
                          child: const Icon(Icons.close_rounded, color: _kTextSec, size: 18),
                        ),
                      ],
                    ),
                  )
                : GestureDetector(
                    onTap: _pickLottie,
                    child: CustomPaint(
                      painter: _DashedRoundBorder(
                        color: _kPrimary.withOpacity(0.65),
                        radius: 12,
                        dashLength: 8,
                        gapLength: 5,
                        strokeWidth: 1.8,
                      ),
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 24),
                        decoration: BoxDecoration(
                          color: _kBg,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Column(
                          children: [
                            // ── Pencil icon in red circle ──────────────────
                            Container(
                              width: 76,
                              height: 76,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: _kPrimary.withOpacity(0.14),
                              ),
                              child: const Icon(Icons.edit_rounded, color: _kPrimary, size: 34),
                            ),
                            const SizedBox(height: 20),
                            // ── Main label ────────────────────────────────
                            const Text(
                              'Upload Lottie JSON or use default',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: _kTextPrim,
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                                height: 1.35,
                              ),
                            ),
                            const SizedBox(height: 14),
                            // ── LottieFiles.com link ──────────────────────
                            const Text(
                              'Get free animations from',
                              style: TextStyle(color: _kTextMuted, fontSize: 13),
                            ),
                            const SizedBox(height: 4),
                            GestureDetector(
                              onTap: _openLottieFiles,
                              behavior: HitTestBehavior.opaque,
                              child: const Text(
                                'LottieFiles.com',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  decoration: TextDecoration.underline,
                                  decorationColor: Colors.white,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
          ),
        ]),

        const SizedBox(height: 14),

        // ── Behaviour card ───────────────────────────────────────────────────
        _glowCard(children: [
          _sectionLabel('Behaviour'),
          const SizedBox(height: 12),
          _redToggle(
            icon: Icons.dark_mode_rounded,
            label: 'Dark Theme',
            sub: 'Force dark WebView theme',
            value: _darkTheme,
            onChanged: (v) { setState(() => _darkTheme = v); _saveForm(); },
          ),
          _redDivider(),
          _redToggle(
            icon: Icons.fullscreen_rounded,
            label: 'Edge to Edge',
            sub: 'Fullscreen immersive mode',
            value: _edgeToEdge,
            onChanged: (v) { setState(() => _edgeToEdge = v); _saveForm(); },
          ),
          _redDivider(),
          _redToggle(
            icon: Icons.refresh_rounded,
            label: 'Pull to Refresh',
            sub: 'Swipe down to reload page',
            value: _pullRefresh,
            onChanged: (v) { setState(() => _pullRefresh = v); _saveForm(); },
          ),
        ]),

        const SizedBox(height: 14),

        // ── Biometric card ────────────────────────────────────────────────────
        _glowCard(children: [
          _sectionLabel('Security'),
          const SizedBox(height: 12),
          _redToggle(
            icon: Icons.fingerprint_rounded,
            label: 'Biometric Lock',
            sub: 'Require fingerprint to open app',
            value: _biometric,
            onChanged: (v) { setState(() => _biometric = v); _saveForm(); },
          ),
          if (_biometric) ...[
            const SizedBox(height: 16),
            // Re-auth timeout grid (matches CSS timeout-grid)
            Row(
              children: [
                const Icon(Icons.timer_rounded, color: _kPrimary, size: 16),
                const SizedBox(width: 8),
                const Text(
                  'Re-authentication Timeout',
                  style: TextStyle(
                    color: _kTextPrim,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 4,
              mainAxisSpacing: 8,
              crossAxisSpacing: 8,
              childAspectRatio: 1.5,
              children: _kTimeouts.map((t) {
                final val = t['value'] as int;
                final selected = val == _bioTimeoutMin;
                return GestureDetector(
                  onTap: () { setState(() => _bioTimeoutMin = val); _saveForm(); },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      gradient: selected
                          ? const LinearGradient(
                              colors: [_kPrimary, Color(0xFFFF4444), _kPrimaryDark],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            )
                          : null,
                      color: selected ? null : _kBorder,
                      border: Border.all(
                        color: selected ? _kPrimary : _kBorder,
                      ),
                    ),
                    child: Center(
                      child: Text(
                        t['label'] as String,
                        style: TextStyle(
                          color: selected ? Colors.white : _kTextSec,
                          fontSize: 10,
                          fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: _kPrimary.withOpacity(0.08),
                borderRadius: const BorderRadius.only(
                  topRight: Radius.circular(8),
                  bottomRight: Radius.circular(8),
                ),
                border: const Border(
                  left: BorderSide(color: _kPrimary, width: 3),
                ),
              ),
              child: Text(
                _bioTimeoutMin == 0
                    ? 'App will always ask for authentication on open'
                    : 'App will ask for authentication every $_bioTimeoutMin minute${_bioTimeoutMin == 1 ? '' : 's'}',
                style: const TextStyle(color: _kTextSec, fontSize: 12),
              ),
            ),
            _redDivider(),
            // Auth type dropdown
            Row(
              children: [
                const Icon(Icons.security_rounded, color: _kPrimary, size: 16),
                const SizedBox(width: 8),
                const Text(
                  'Auth type:',
                  style: TextStyle(color: _kTextPrim, fontSize: 13),
                ),
                const SizedBox(width: 12),
                DropdownButton<String>(
                  value: _bioType,
                  dropdownColor: const Color(0xFF111111),
                  underline: const SizedBox(),
                  style: const TextStyle(color: _kTextPrim, fontSize: 13),
                  items: const [
                    DropdownMenuItem(value: 'both',        child: Text('Biometric + PIN')),
                    DropdownMenuItem(value: 'biometric',   child: Text('Biometric only')),
                    DropdownMenuItem(value: 'device_cred', child: Text('PIN / Pattern')),
                  ],
                  onChanged: (v) { setState(() => _bioType = v ?? 'both'); _saveForm(); },
                ),
              ],
            ),
          ],
          _redDivider(),
          // ── Sign APK toggle ────────────────────────────────────────────────
          _redToggle(
            icon: Icons.verified_rounded,
            label: 'Sign APK',
            sub: _signApk
                ? 'Signed with built-in keystore (installable)'
                : 'Output is unsigned — install manually after signing',
            value: _signApk,
            onChanged: (v) { setState(() => _signApk = v); _saveForm(); },
          ),
          if (!_signApk) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: _kWarning.withOpacity(0.07),
                borderRadius: const BorderRadius.only(
                  topRight: Radius.circular(8),
                  bottomRight: Radius.circular(8),
                ),
                border: const Border(
                  left: BorderSide(color: _kWarning, width: 3),
                ),
              ),
              child: Row(
                children: const [
                  Icon(Icons.warning_amber_rounded, color: _kWarning, size: 15),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Unsigned APK cannot be installed directly. '
                      'You will need to sign it with your own keystore.',
                      style: TextStyle(color: _kWarning, fontSize: 11, height: 1.5),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ]),

        const SizedBox(height: 14),

        // ── Advanced card ──────────────────────────────────────────────────────
        _glowCard(children: [
          _sectionLabel('Advanced'),
          const SizedBox(height: 12),
          _redToggle(
            icon: Icons.screenshot_monitor_rounded,
            label: 'Screenshot Prevention',
            sub: 'Block screen capture & recent apps preview',
            value: _screenshotPrevention,
            onChanged: (v) { setState(() => _screenshotPrevention = v); _saveForm(); },
            onInfo: () => _showFeatureInfo(
              'Screenshot Prevention',
              'Blocks the app from being captured in screenshots or screen recordings, '
              'and also hides its content in the recent apps switcher.\n\n'
              'Ideal for apps that handle private or sensitive information.',
            ),
          ),
          _redDivider(),
          _redToggle(
            icon: Icons.zoom_in_rounded,
            label: 'Zoom Control',
            sub: 'Allow pinch-to-zoom inside the WebView',
            value: _zoomEnabled,
            onChanged: (v) { setState(() => _zoomEnabled = v); _saveForm(); },
            onInfo: () => _showFeatureInfo(
              'Zoom Control',
              'Allows users to pinch-to-zoom inside the WebView, just like a regular mobile browser.\n\n'
              'By default, WebView apps disable zoom. Turn this on if your website\'s content '
              'benefits from being explored at different zoom levels.',
            ),
          ),
          _redDivider(),
          _redToggle(
            icon: Icons.link_rounded,
            label: 'Deep Linking',
            sub: 'Open this app via a custom URL scheme',
            value: _deepLinkEnabled,
            onChanged: (v) { setState(() => _deepLinkEnabled = v); _saveForm(); },
            onInfo: () => _showFeatureInfo(
              'Deep Linking',
              'Lets other apps or clickable links open this app directly using a custom URL scheme '
              '(e.g. myapp://).\n\n'
              'For example, a link like myapp://profile/123 in a message or browser '
              'will launch this app automatically and land on the right page.',
            ),
          ),
          if (_deepLinkEnabled) ...[
            const SizedBox(height: 12),
            _formGroup(
              icon: Icons.open_in_new_rounded,
              label: 'URL Scheme',
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _redTextField(
                    ctrl: _deepLinkSchemeCtrl,
                    hint: 'myapp',
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: const [
                      Icon(Icons.info_outline_rounded, size: 12, color: _kTextMuted),
                      SizedBox(width: 5),
                      Expanded(
                        child: Text(
                          'Links like myapp:// will open this app directly',
                          style: TextStyle(color: _kTextMuted, fontSize: 10.5),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
          _redDivider(),
          _redToggle(
            icon: Icons.cleaning_services_rounded,
            label: 'Incognito Mode',
            sub: 'Clear cookies, cache & storage on app exit',
            value: _incognitoOnExit,
            onChanged: (v) { setState(() => _incognitoOnExit = v); _saveForm(); },
            onInfo: () => _showFeatureInfo(
              'Incognito Mode',
              'When enabled, all cookies, cached files, and local storage are completely '
              'wiped every time the user closes the app — similar to using a private browser tab.\n\n'
              'Great for privacy-sensitive tools or apps used on shared devices.',
            ),
          ),
          _redDivider(),
          _redToggle(
            icon: Icons.picture_in_picture_rounded,
            label: 'Picture-in-Picture',
            sub: 'Float WebView as overlay when leaving app',
            value: _pipEnabled,
            onChanged: (v) { setState(() => _pipEnabled = v); _saveForm(); },
            onInfo: () => _showFeatureInfo(
              'Picture-in-Picture',
              'Shrinks the app into a small floating window when the user holds '
              'the Home button for 3 seconds and then releases.\n\n'
              'The floating window stays on top of other apps so users can keep '
              'watching or monitoring content while multitasking. '
              'Tapping the window returns to fullscreen.\n\n'
              'Best for video streaming, live dashboards, or chat-based web apps.\n\n'
              'Requires Android 8.0 (Oreo) or newer.',
            ),
          ),
          _redDivider(),
          _redToggle(
            icon: Icons.screen_rotation_rounded,
            label: 'Landscape Mode',
            sub: 'Force app to always display in landscape orientation',
            value: _landscapeMode,
            onChanged: (v) { setState(() => _landscapeMode = v); _saveForm(); },
            onInfo: () => _showFeatureInfo(
              'Landscape Mode',
              'Forces the app to lock its orientation to landscape (horizontal) at all times.\n\n'
              'Useful for games, video players, dashboards, or any web app that is '
              'designed for wide-screen layouts.\n\n'
              'When disabled (default), the app follows the device rotation normally.',
            ),
          ),
        ]),

        const SizedBox(height: 14),

        // ── Privacy notice ────────────────────────────────────────────────────
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: _kPrimary.withOpacity(0.05),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _kPrimary.withOpacity(0.2)),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Icon(Icons.shield_rounded, color: _kPrimary, size: 20),
              SizedBox(width: 12),
              Expanded(
                child: Text(
                  'Config + icon are securely uploaded to the cloud and auto-deleted after the build. '
                  'APK is signed with your fixed release keystore.',
                  style: TextStyle(color: _kTextSec, fontSize: 12, height: 1.6),
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 20),

        // ── Build / Cancel button ─────────────────────────────────────────────
        _buildActionButton(),

        const SizedBox(height: 24),
      ],
    );
  }

  // ── Stats item (matches .stat-item) ────────────────────────────────────────
  Widget _statItem(String number, String label, double delay) {
    return AnimatedBuilder(
      animation: _pulseCtrl,
      builder: (_, __) {
        final phase = (_pulseCtrl.value + delay).clamp(0.0, 1.0);
        return Container(
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            color: _kPrimary.withOpacity(0.08),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: _kPrimary.withOpacity(0.3 + phase * 0.4),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: _kPrimary.withOpacity(0.10 + phase * 0.15),
                blurRadius: 12 + phase * 20,
                spreadRadius: 1,
              ),
            ],
          ),
          child: Column(
            children: [
              Text(
                number,
                style: const TextStyle(
                  color: _kTextPrim,
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  fontFamily: 'monospace',
                ),
              ),
              const SizedBox(height: 4),
              Text(
                label.toUpperCase(),
                style: const TextStyle(
                  color: _kPrimary,
                  fontSize: 9,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.8,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ── Glowing card (matches .feature-card / .builder-card) ──────────────────
  Widget _glowCard({required List<Widget> children}) {
    return AnimatedBuilder(
      animation: _pulseCtrl,
      builder: (_, __) => Container(
        decoration: BoxDecoration(
          color: _kCard,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: _kPrimary.withOpacity(0.2 + _pulseCtrl.value * 0.25),
          ),
          boxShadow: [
            BoxShadow(
              color: _kPrimary.withOpacity(0.08 + _pulseCtrl.value * 0.10),
              blurRadius: 15 + _pulseCtrl.value * 20,
              spreadRadius: 1,
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Red top border accent (matches .feature-card::before)
              Container(
                height: 3,
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [_kPrimary, Color(0xFFFF4444), _kPrimaryDark],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: children,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Build / Cancel button ───────────────────────────────────────────────────
  Widget _buildActionButton() {
    if (_running) {
      return SizedBox(
        width: double.infinity,
        height: 54,
        child: OutlinedButton.icon(
          onPressed: _cancelBuild,
          icon: const Icon(Icons.stop_circle_outlined, color: _kError),
          label: const Text(
            'Cancel Build',
            style: TextStyle(color: _kError, fontWeight: FontWeight.w700, fontSize: 15),
          ),
          style: OutlinedButton.styleFrom(
            side: const BorderSide(color: _kError),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),
      );
    }
    return AnimatedBuilder(
      animation: _pulseCtrl,
      builder: (_, __) => Container(
        width: double.infinity,
        height: 54,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [_kPrimary, Color(0xFFFF4444), _kPrimaryDark],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: _kPrimary.withOpacity(0.3 + _pulseCtrl.value * 0.2),
              blurRadius: 15 + _pulseCtrl.value * 15,
              spreadRadius: 1,
            ),
          ],
        ),
        child: ElevatedButton.icon(
          onPressed: _startBuild,
          icon: const Icon(Icons.rocket_launch_rounded, color: Colors.white, size: 20),
          label: const Text(
            'Build APK Now',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w800,
              fontSize: 16,
              letterSpacing: 0.5,
            ),
          ),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.transparent,
            shadowColor: Colors.transparent,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // ── BUILD TAB ─────────────────────────────────────────────────────────────
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildBuildTab() {
    final success  = _status == 'success';
    final failed   = _status == 'error';
    final cancelled= _status == 'cancelled';
    final done     = success || failed || cancelled;

    return Column(
      children: [
        // ── Progress header ──────────────────────────────────────────────────
        Container(
          color: _kBg,
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  _phaseIcon(),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      _phaseLabel(),
                      style: const TextStyle(
                        color: _kTextPrim,
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                      ),
                    ),
                  ),
                  if (_running)
                    TextButton(
                      onPressed: _cancelBuild,
                      child: const Text(
                        'Cancel',
                        style: TextStyle(color: _kError, fontWeight: FontWeight.w600),
                      ),
                    ),
                  if (done && !_running)
                    IconButton(
                      icon: const Icon(Icons.refresh_rounded, size: 20, color: _kTextSec),
                      tooltip: 'Clear',
                      onPressed: _clearState,
                    ),
                ],
              ),
              const SizedBox(height: 10),
              // Red gradient progress bar
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: _running ? (_progress / 100) : (success ? 1.0 : 0.0),
                  minHeight: 6,
                  backgroundColor: _kBorder,
                  valueColor: AlwaysStoppedAnimation(
                    failed ? _kError : _kPrimary,
                  ),
                ),
              ),
              if (_running) ...[
                const SizedBox(height: 4),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      _phaseDetail(),
                      style: const TextStyle(color: _kTextSec, fontSize: 11),
                    ),
                    Text(
                      '$_progress%',
                      style: const TextStyle(
                        color: _kPrimary,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        fontFamily: 'monospace',
                      ),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),

        Container(height: 1, color: _kBorder),

        // ── Triple ring loader (when running) ─────────────────────────────────
        if (_running) _buildTripleRingLoader(),

        // ── Result cards ────────────────────────────────────────────────────
        if (success && _outputPath.isNotEmpty) _buildSuccessCard(),
        if (failed && _error.isNotEmpty)       _buildErrorCard(),
        if (cancelled)                         _buildCancelledCard(),

        // ── Log terminal ────────────────────────────────────────────────────
        Expanded(
          child: Column(
            children: [
              // Header bar with copy button
              Container(
                height: 32,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                color: const Color(0xFF0D0D0D),
                child: Row(
                  children: [
                    const Icon(Icons.terminal_rounded, color: _kTextMuted, size: 13),
                    const SizedBox(width: 6),
                    const Text(
                      'Build Log',
                      style: TextStyle(
                        color: _kTextMuted,
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const Spacer(),
                    if (_logLines.isNotEmpty)
                      GestureDetector(
                        onTap: () {
                          Clipboard.setData(
                            ClipboardData(text: _logLines.join('\n')),
                          );
                          _showSnack('Build log copied');
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: _kPrimary.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(color: _kPrimary.withOpacity(0.25)),
                          ),
                          child: const Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.copy_rounded, color: _kPrimary, size: 12),
                              SizedBox(width: 4),
                              Text(
                                'Copy',
                                style: TextStyle(
                                  color: _kPrimary,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              Container(height: 1, color: _kBorder),
              // Log content
              Expanded(
                child: Container(
                  color: const Color(0xFF050505),
                  child: _logLines.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.terminal_rounded,
                                color: _kPrimary.withOpacity(0.3),
                                size: 40,
                              ),
                              const SizedBox(height: 12),
                              Text(
                                _running ? 'Waiting for build output…' : 'No build output yet.',
                                style: const TextStyle(color: _kTextMuted, fontSize: 13),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          controller: _scrollCtrl,
                          padding: const EdgeInsets.all(10),
                          itemCount: _logLines.length,
                          itemBuilder: (_, i) => Text(
                            _logLines[i],
                            style: TextStyle(
                              fontSize: 11.5,
                              fontFamily: 'monospace',
                              color: _logColor(_logLines[i]),
                              height: 1.55,
                            ),
                          ),
                        ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ── Triple ring build loader (from CSS .build-loader) ─────────────────────
  Widget _buildTripleRingLoader() {
    return Container(
      color: _kBg,
      padding: const EdgeInsets.symmetric(vertical: 20),
      child: Center(
        child: SizedBox(
          width: 72,
          height: 72,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Outer ring - 1.2s clockwise - red
              RotationTransition(
                turns: _spin1,
                child: _buildRing(size: 72, color: _kPrimary, width: 3),
              ),
              // Middle ring - 0.9s counter-clockwise - light red
              RotationTransition(
                turns: Tween(begin: 1.0, end: 0.0).animate(_spin2),
                child: _buildRing(size: 52, color: const Color(0xFFFF6666), width: 3),
              ),
              // Inner ring - 0.6s clockwise - white
              RotationTransition(
                turns: _spin3,
                child: _buildRing(size: 32, color: Colors.white, width: 3),
              ),
              // Center icon - pulsing red
              AnimatedBuilder(
                animation: _centerPulse,
                builder: (_, __) => Opacity(
                  opacity: 0.6 + _centerPulse.value * 0.4,
                  child: Transform.scale(
                    scale: 0.9 + _centerPulse.value * 0.1,
                    child: const Icon(Icons.android_rounded, color: _kPrimary, size: 18),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRing({required double size, required Color color, required double width}) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _RingPainter(color: color, strokeWidth: width),
      ),
    );
  }

  // ── Success card ────────────────────────────────────────────────────────────
  Widget _buildSuccessCard() => Container(
    margin: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      color: _kSuccess.withOpacity(0.06),
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: _kSuccess.withOpacity(0.3)),
    ),
    child: ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 3,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [_kSuccess, _kSuccess.withOpacity(0.5)],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.check_circle_rounded, color: _kSuccess, size: 20),
                    const SizedBox(width: 8),
                    Text(
                      'APK built — $_appName',
                      style: const TextStyle(
                        color: _kSuccess,
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
                if (_outputPath.isNotEmpty) ...[
                  const SizedBox(height: 6),
                  Text(
                    _outputPath,
                    style: const TextStyle(color: _kTextSec, fontSize: 10),
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          height: 42,
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [_kSuccess, Color(0xFF00CC66)],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: ElevatedButton.icon(
                            onPressed: _installApk,
                            icon: const Icon(Icons.install_mobile_rounded, size: 16, color: Colors.black),
                            label: const Text(
                              'Install',
                              style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.w800,
                                fontSize: 13,
                              ),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.transparent,
                              shadowColor: Colors.transparent,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10)),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _shareApk,
                          icon: const Icon(Icons.share_rounded, size: 16, color: _kSuccess),
                          label: const Text(
                            'Share',
                            style: TextStyle(
                              color: _kSuccess,
                              fontWeight: FontWeight.w700,
                              fontSize: 13,
                            ),
                          ),
                          style: OutlinedButton.styleFrom(
                            side: const BorderSide(color: _kSuccess),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10)),
                            padding: const EdgeInsets.symmetric(vertical: 11),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    ),
  );

  // ── Error card ─────────────────────────────────────────────────────────────
  Widget _buildErrorCard() => Container(
    margin: const EdgeInsets.all(12),
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: _kError.withOpacity(0.06),
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: _kError.withOpacity(0.3)),
    ),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Icon(Icons.error_rounded, color: _kError, size: 20),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Build failed',
                style: TextStyle(
                    color: _kError, fontWeight: FontWeight.w700, fontSize: 13),
              ),
              const SizedBox(height: 4),
              Text(
                _error,
                style: const TextStyle(color: _kTextSec, fontSize: 11.5),
              ),
            ],
          ),
        ),
      ],
    ),
  );

  // ── Cancelled card ─────────────────────────────────────────────────────────
  Widget _buildCancelledCard() => Container(
    margin: const EdgeInsets.all(12),
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
    decoration: BoxDecoration(
      color: _kTextSec.withOpacity(0.06),
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: _kTextSec.withOpacity(0.2)),
    ),
    child: Row(
      children: const [
        Icon(Icons.cancel_rounded, color: _kTextSec, size: 18),
        SizedBox(width: 8),
        Text(
          'Build was cancelled',
          style: TextStyle(color: _kTextSec, fontSize: 13),
        ),
      ],
    ),
  );

  // ══════════════════════════════════════════════════════════════════════════
  // ── HELPERS ───────────────────────────────────────────────────────────────
  // ══════════════════════════════════════════════════════════════════════════

  Widget _phaseIcon() {
    if (_status == 'success')
      return const Icon(Icons.check_circle_rounded, color: _kSuccess, size: 22);
    if (_status == 'error')
      return const Icon(Icons.error_rounded, color: _kError, size: 22);
    if (_status == 'cancelled')
      return const Icon(Icons.cancel_rounded, color: _kTextSec, size: 22);
    if (_running) {
      return SizedBox(
        width: 20,
        height: 20,
        child: CircularProgressIndicator(
          strokeWidth: 2.5,
          color: _kPrimary,
        ),
      );
    }
    return const Icon(Icons.pending_rounded, color: _kTextSec, size: 22);
  }

  String _phaseLabel() {
    switch (_phase) {
      case 'initialising':         return 'Initialising…';
      case 'preparing':            return 'Preparing workspace…';
      case 'downloading_template': return 'Downloading template APK…';
      case 'patching':             return 'Patching APK assets…';
      case 'signing':              return 'Signing APK…';
      case 'saving':               return 'Saving output…';
      case 'done':
        if (_status == 'success')  return 'Build complete';
        if (_status == 'error')    return 'Build failed';
        if (_status == 'cancelled')return 'Build cancelled';
        return 'Done';
      default:
        if (_running)              return 'Building…';
        return 'Idle — configure in Setup tab';
    }
  }

  String _phaseDetail() {
    switch (_phase) {
      case 'downloading_template': return 'Fetching template from server…';
      case 'patching':             return 'Injecting URL, name and icon…';
      case 'signing':              return 'V1 JAR signing in progress…';
      default:                     return _phaseLabel();
    }
  }

  Color _logColor(String line) {
    final l = line.toLowerCase();
    if (l.contains('error') || l.contains('fail')) return _kError;
    if (l.contains('warn'))  return _kWarning;
    if (l.contains('done') || l.contains('success') || l.contains('complete')) return _kSuccess;
    if (l.contains('[webapk]')) return const Color(0xFFFF6666);
    return _kTextSec;
  }

  // ── Section tag (matches .section-tag) ─────────────────────────────────────
  Widget _sectionTag(String label) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
    decoration: BoxDecoration(
      color: _kPrimary.withOpacity(0.10),
      borderRadius: BorderRadius.circular(50),
      border: Border.all(color: _kPrimary.withOpacity(0.2)),
    ),
    child: Text(
      label.toUpperCase(),
      style: const TextStyle(
        color: _kPrimary,
        fontSize: 10,
        fontWeight: FontWeight.w700,
        letterSpacing: 2,
      ),
    ),
  );

  Widget _sectionTitle(String t) => Text(
    t,
    style: const TextStyle(
      color: _kTextPrim,
      fontSize: 20,
      fontWeight: FontWeight.w800,
    ),
  );

  Widget _sectionLabel(String t) => Text(
    t.toUpperCase(),
    style: const TextStyle(
      color: _kPrimary,
      fontSize: 10,
      fontWeight: FontWeight.w700,
      letterSpacing: 1.5,
    ),
  );

  // ── Form group label ────────────────────────────────────────────────────────
  Widget _formGroup({
    required IconData icon,
    required String label,
    required Widget child,
  }) =>
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: Colors.white, size: 14),
              const SizedBox(width: 6),
              Text(
                label,
                style: const TextStyle(
                  color: _kTextPrim,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.3,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          child,
        ],
      );

  // ── Red-themed text field ────────────────────────────────────────────────
  Widget _redTextField({
    required TextEditingController ctrl,
    required String hint,
    TextInputType inputType = TextInputType.text,
  }) =>
      TextField(
        controller: ctrl,
        keyboardType: inputType,
        autocorrect: false,
        enableSuggestions: false,
        autofillHints: const [],
        style: const TextStyle(color: _kTextPrim, fontSize: 14),
        cursorColor: _kPrimary,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(color: _kTextMuted, fontSize: 13),
          filled: true,
          fillColor: _kPrimary.withOpacity(0.13),
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: _kPrimary.withOpacity(0.30), width: 1),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: _kPrimary, width: 1.5),
          ),
        ),
      );

  // ── Red toggle (matches CSS .toggle-container) ──────────────────────────────
  Widget _redToggle({
    required IconData icon,
    required String label,
    required String sub,
    required bool value,
    required ValueChanged<bool> onChanged,
    VoidCallback? onInfo,
  }) =>
      Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: _kPrimary.withOpacity(0.10),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _kPrimary.withOpacity(0.25)),
            ),
            child: Icon(icon, color: Colors.white, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      label,
                      style: const TextStyle(
                        color: _kTextPrim,
                        fontSize: 13.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    if (onInfo != null) ...[
                      const SizedBox(width: 6),
                      GestureDetector(
                        onTap: onInfo,
                        child: Container(
                          width: 16,
                          height: 16,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _kTextSec.withOpacity(0.12),
                            border: Border.all(color: _kTextSec.withOpacity(0.35), width: 1),
                          ),
                          child: const Center(
                            child: Text(
                              '?',
                              style: TextStyle(
                                color: _kTextSec,
                                fontSize: 9,
                                fontWeight: FontWeight.w800,
                                height: 1,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
                Text(
                  sub,
                  style: const TextStyle(color: _kTextSec, fontSize: 11),
                ),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeColor: _kPrimary,
            activeTrackColor: _kPrimary.withOpacity(0.3),
            inactiveThumbColor: _kTextSec,
            inactiveTrackColor: _kBorder,
          ),
        ],
      );

  // ── Feature info modal ───────────────────────────────────────────────────────
  void _showFeatureInfo(String title, String body) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.80),
      builder: (_) => Dialog(
        backgroundColor: const Color(0xFF0D0D0D),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: _kPrimary.withOpacity(0.25), width: 1),
        ),
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.info_outline_rounded, color: _kPrimary, size: 18),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      title,
                      style: const TextStyle(
                        color: _kTextPrim,
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              const Divider(color: _kBorder, height: 1),
              const SizedBox(height: 14),
              Text(
                body,
                style: const TextStyle(
                  color: _kTextSec,
                  fontSize: 13,
                  height: 1.7,
                ),
              ),
              const SizedBox(height: 22),
              Align(
                alignment: Alignment.centerRight,
                child: GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 10),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [_kPrimary, _kPrimaryDark],
                      ),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text(
                      'Got it',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _redDivider() => Divider(
    height: 20,
    thickness: 0.5,
    color: _kBorder,
  );
}

// ── Ring painter (for triple build loader) ────────────────────────────────────
class _RingPainter extends CustomPainter {
  final Color color;
  final double strokeWidth;
  const _RingPainter({required this.color, required this.strokeWidth});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round
      ..color = Colors.transparent;

    // Draw the background ring (faded)
    paint.color = color.withOpacity(0.15);
    canvas.drawCircle(
      Offset(size.width / 2, size.height / 2),
      (size.width - strokeWidth) / 2,
      paint,
    );

    // Draw the visible arc (~120 degrees / 1/3 of circle)
    final arcPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round
      ..color = color;

    canvas.drawArc(
      Rect.fromCircle(
        center: Offset(size.width / 2, size.height / 2),
        radius: (size.width - strokeWidth) / 2,
      ),
      -math.pi / 2,    // start at top
      2 * math.pi / 3, // 120 degrees
      false,
      arcPaint,
    );
  }

  @override
  bool shouldRepaint(_RingPainter old) =>
      old.color != color || old.strokeWidth != strokeWidth;
}

// ── Orbit arc painter (3 arcs + dot tips, for hero animation) ─────────────────
class _Web2ApkOrbitPainter extends CustomPainter {
  final Color color;
  final double opacity;
  const _Web2ApkOrbitPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r  = (size.width / 2) - 2;

    final paint = Paint()
      ..color = color.withOpacity(opacity)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.8
      ..strokeCap = StrokeCap.round;

    const gapRad = math.pi / 3;
    const arcRad = math.pi / 3;
    for (int i = 0; i < 3; i++) {
      final start = i * (arcRad + gapRad);
      canvas.drawArc(
        Rect.fromCircle(center: Offset(cx, cy), radius: r),
        start, arcRad, false, paint,
      );
    }

    final dotPaint = Paint()
      ..color = color.withOpacity(opacity * 0.9)
      ..style = PaintingStyle.fill;
    for (int i = 0; i < 3; i++) {
      final angle = i * (arcRad + gapRad) + arcRad / 2;
      canvas.drawCircle(
        Offset(cx + r * math.cos(angle), cy + r * math.sin(angle)),
        2.6, dotPaint,
      );
    }
  }

  @override
  bool shouldRepaint(_Web2ApkOrbitPainter old) =>
      old.color != color || old.opacity != opacity;
}

// ── Dot orbit painter (6 alternating dots, counter-rotating) ─────────────────
class _Web2ApkDotOrbitPainter extends CustomPainter {
  final Color color;
  final double opacity;
  const _Web2ApkDotOrbitPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r  = (size.width / 2) - 1;

    for (int i = 0; i < 6; i++) {
      final angle  = i * (math.pi / 3);
      final radius = i % 2 == 0 ? 2.2 : 1.2;
      canvas.drawCircle(
        Offset(cx + r * math.cos(angle), cy + r * math.sin(angle)),
        radius,
        Paint()
          ..color = color.withOpacity(opacity * (i % 2 == 0 ? 1.0 : 0.5))
          ..style = PaintingStyle.fill,
      );
    }
  }

  @override
  bool shouldRepaint(_Web2ApkDotOrbitPainter old) =>
      old.color != color || old.opacity != opacity;
}

// ═══════════════════════════════════════════════════════════════════════════════
// ── Icon Crop + Shape Dialog ──────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════════
class _IconCropDialog extends StatefulWidget {
  final String imagePath;
  const _IconCropDialog({required this.imagePath});
  @override
  State<_IconCropDialog> createState() => _IconCropDialogState();
}

class _IconCropDialogState extends State<_IconCropDialog> {
  String _shape = 'squircle';
  bool   _processing = false;
  final GlobalKey _captureKey = GlobalKey();
  final TransformationController _transformCtrl = TransformationController();

  @override
  void dispose() {
    _transformCtrl.dispose();
    super.dispose();
  }

  Future<void> _confirm() async {
    if (_processing) return;
    setState(() => _processing = true);
    try {
      final boundary = _captureKey.currentContext
          ?.findRenderObject() as RenderRepaintBoundary?;
      if (boundary == null) { Navigator.of(context).pop(null); return; }
      // Capture at 512 × 512 px
      final img  = await boundary.toImage(pixelRatio: 512.0 / 300.0);
      final data = await img.toByteData(format: ui.ImageByteFormat.png);
      if (!mounted) return;
      Navigator.of(context).pop({
        'bytes': data!.buffer.asUint8List(),
        'shape': _shape,
      });
    } catch (_) {
      if (mounted) Navigator.of(context).pop(null);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 36),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.black,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF2A0000), width: 1.5),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // ── Header ─────────────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 16, 10, 0),
              child: Row(
                children: [
                  const Icon(Icons.crop_rounded, color: _kPrimary, size: 18),
                  const SizedBox(width: 10),
                  const Expanded(
                    child: Text(
                      'Crop Your Icon',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.3,
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(null),
                    icon: const Icon(Icons.close_rounded, color: Colors.white38, size: 20),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),

            // ── Shape selector ─────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18),
              child: Row(
                children: [
                  _shapeBtn('squircle', Icons.crop_square_rounded, 'Squircle'),
                  const SizedBox(width: 10),
                  _shapeBtn('circle', Icons.circle_outlined, 'Circle'),
                ],
              ),
            ),
            const SizedBox(height: 14),

            // ── Crop frame ─────────────────────────────────────────────────
            Center(
              child: Stack(
                children: [
                  // Background (shown in dialog, not captured)
                  Container(
                    width: 300,
                    height: 300,
                    color: const Color(0xFF111111),
                  ),
                  // RepaintBoundary wraps ONLY the clipped image (transparent bg)
                  RepaintBoundary(
                    key: _captureKey,
                    child: SizedBox(
                      width: 300,
                      height: 300,
                      child: ClipPath(
                        clipper: _ShapeClipper(_shape),
                        child: InteractiveViewer(
                          transformationController: _transformCtrl,
                          minScale: 0.8,
                          maxScale: 6.0,
                          constrained: true,
                          child: Image.file(
                            File(widget.imagePath),
                            width: 300,
                            height: 300,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ),
                  // Shape outline overlay (non-interactive)
                  IgnorePointer(
                    child: CustomPaint(
                      size: const Size(300, 300),
                      painter: _ShapeOutlinePainter(_shape),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 5, bottom: 2),
              child: const Text(
                'Pinch to zoom  ·  Drag to reposition',
                style: TextStyle(color: Colors.white24, fontSize: 10.5),
              ),
            ),

            // ── Actions ────────────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 10, 18, 20),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.of(context).pop(null),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Colors.white24),
                        foregroundColor: Colors.white54,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                      child: const Text('Cancel', style: TextStyle(fontWeight: FontWeight.w600)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _processing ? null : _confirm,
                      icon: _processing
                          ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                          : const Icon(Icons.check_rounded, size: 16),
                      label: Text(_processing ? 'Applying…' : 'Apply', style: const TextStyle(fontWeight: FontWeight.w700)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _kPrimary,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        elevation: 0,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _shapeBtn(String shape, IconData icon, String label) {
    final active = _shape == shape;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _shape = shape),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: active ? _kPrimary.withOpacity(0.14) : const Color(0xFF0D0D0D),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: active ? _kPrimary : const Color(0xFF2A2A2A),
              width: active ? 1.5 : 1,
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: active ? _kPrimary : Colors.white30, size: 15),
              const SizedBox(width: 6),
              Text(
                label,
                style: TextStyle(
                  color: active ? _kPrimary : Colors.white30,
                  fontWeight: active ? FontWeight.w700 : FontWeight.w400,
                  fontSize: 13,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ── Shape clipper (used in crop dialog + icon preview card) ───────────────────
class _ShapeClipper extends CustomClipper<Path> {
  final String shape;
  const _ShapeClipper(this.shape);

  @override
  Path getClip(Size size) {
    if (shape == 'circle') {
      return Path()
        ..addOval(Rect.fromCircle(
          center: Offset(size.width / 2, size.height / 2),
          radius: size.width / 2,
        ));
    }
    // Squircle — 22% corner radius (matches reference)
    return Path()
      ..addRRect(RRect.fromRectAndRadius(
        Rect.fromLTWH(0, 0, size.width, size.height),
        Radius.circular(size.width * 0.22),
      ));
  }

  @override
  bool shouldReclip(_ShapeClipper old) => old.shape != shape;
}

// ── Shape outline painter (decorative border in crop frame) ──────────────────
class _ShapeOutlinePainter extends CustomPainter {
  final String shape;
  const _ShapeOutlinePainter(this.shape);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = _kPrimary.withOpacity(0.75)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    if (shape == 'circle') {
      canvas.drawCircle(
        Offset(size.width / 2, size.height / 2),
        size.width / 2 - 1,
        paint,
      );
    } else {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(1, 1, size.width - 2, size.height - 2),
          Radius.circular(size.width * 0.22),
        ),
        paint,
      );
    }

    // Corner tick marks for visual crop guide
    final tick = Paint()
      ..color = Colors.white.withOpacity(0.4)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round;
    const tl = 14.0;
    if (shape != 'circle') {
      final r = size.width * 0.22;
      // top-left
      canvas.drawLine(Offset(r, 4), Offset(r + tl, 4), tick);
      canvas.drawLine(Offset(4, r), Offset(4, r + tl), tick);
      // top-right
      canvas.drawLine(Offset(size.width - r - tl, 4), Offset(size.width - r, 4), tick);
      canvas.drawLine(Offset(size.width - 4, r), Offset(size.width - 4, r + tl), tick);
      // bottom-left
      canvas.drawLine(Offset(r, size.height - 4), Offset(r + tl, size.height - 4), tick);
      canvas.drawLine(Offset(4, size.height - r - tl), Offset(4, size.height - r), tick);
      // bottom-right
      canvas.drawLine(Offset(size.width - r - tl, size.height - 4), Offset(size.width - r, size.height - 4), tick);
      canvas.drawLine(Offset(size.width - 4, size.height - r - tl), Offset(size.width - 4, size.height - r), tick);
    }
  }

  @override
  bool shouldRepaint(_ShapeOutlinePainter old) => old.shape != shape;
}

// ── Dashed rounded-rectangle border painter ───────────────────────────────────

class _DashedRoundBorder extends CustomPainter {
  final Color  color;
  final double radius;
  final double dashLength;
  final double gapLength;
  final double strokeWidth;

  const _DashedRoundBorder({
    required this.color,
    this.radius     = 12,
    this.dashLength = 8,
    this.gapLength  = 5,
    this.strokeWidth = 1.5,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = strokeWidth
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final rrect = RRect.fromRectAndRadius(
      Rect.fromLTWH(strokeWidth / 2, strokeWidth / 2,
          size.width - strokeWidth, size.height - strokeWidth),
      Radius.circular(radius),
    );

    final path = Path()..addRRect(rrect);

    for (final metric in path.computeMetrics()) {
      double distance = 0;
      bool   drawing  = true;
      while (distance < metric.length) {
        final segLen = drawing ? dashLength : gapLength;
        if (drawing) {
          final end = (distance + segLen).clamp(0.0, metric.length);
          canvas.drawPath(metric.extractPath(distance, end), paint);
        }
        distance += segLen;
        drawing   = !drawing;
      }
    }
  }

  @override
  bool shouldRepaint(_DashedRoundBorder o) =>
      o.color != color || o.dashLength != dashLength || o.gapLength != gapLength;
}
