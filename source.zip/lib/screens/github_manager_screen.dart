import '../utils/theme_provider.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:file_picker/file_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../utils/storage_helper.dart';
import '../utils/permission_helper.dart';

// ─────────────────────────────────────────────────────────────────────────────
// COLOURS
// ─────────────────────────────────────────────────────────────────────────────
const _card     = Color(0xFF0d1117);
const _border   = Color(0xFF21262d);
const _dimText  = Color(0xFF8b949e);
const _ghBlue   = Color(0xFF58a6ff);
const _ghGreen  = Color(0xFF3fb950);
const _ghRed    = Color(0xFFf85149);
const _ghOrange = Color(0xFFffa657);
const _ghPurple = Color(0xFFd2a8ff);
const _ghYellow = Color(0xFFe3b341);

// ─────────────────────────────────────────────────────────────────────────────
// GITHUB API CLIENT
// ─────────────────────────────────────────────────────────────────────────────
class _GhApi {
  final String token;
  const _GhApi(this.token);

  Map<String, String> get _headers => {
    'Authorization': 'token $token',
    'Accept': 'application/vnd.github.v3+json',
    'User-Agent': 'Taurus-Shield-App',
  };

  Uri _uri(String path, [Map<String, String>? params]) {
    final uri = Uri.parse('https://api.github.com$path');
    return params != null ? uri.replace(queryParameters: params) : uri;
  }

  Future<Map<String, dynamic>> get(String path, [Map<String, String>? params]) async {
    try {
      final r = await http.get(_uri(path, params), headers: _headers).timeout(const Duration(seconds: 20));
      return {'ok': r.statusCode < 300, 'status': r.statusCode, 'data': r.statusCode == 204 ? {} : jsonDecode(r.body)};
    } catch (e) { return {'ok': false, 'error': e.toString()}; }
  }

  Future<Map<String, dynamic>> post(String path, Map body) async {
    try {
      final r = await http.post(_uri(path), headers: {..._headers, 'Content-Type': 'application/json'}, body: jsonEncode(body)).timeout(const Duration(seconds: 20));
      return {'ok': r.statusCode < 300, 'status': r.statusCode, 'data': r.statusCode == 204 ? {} : (r.body.isEmpty ? {} : jsonDecode(r.body))};
    } catch (e) { return {'ok': false, 'error': e.toString()}; }
  }

  Future<Map<String, dynamic>> put(String path, [Map? body]) async {
    try {
      final r = await http.put(_uri(path), headers: {..._headers, 'Content-Type': 'application/json'}, body: body != null ? jsonEncode(body) : null).timeout(const Duration(seconds: 20));
      return {'ok': r.statusCode < 300, 'status': r.statusCode, 'data': r.statusCode == 204 ? {} : (r.body.isEmpty ? {} : jsonDecode(r.body))};
    } catch (e) { return {'ok': false, 'error': e.toString()}; }
  }

  Future<Map<String, dynamic>> patch(String path, Map body) async {
    try {
      final r = await http.patch(_uri(path), headers: {..._headers, 'Content-Type': 'application/json'}, body: jsonEncode(body)).timeout(const Duration(seconds: 20));
      return {'ok': r.statusCode < 300, 'status': r.statusCode, 'data': r.statusCode == 204 ? {} : jsonDecode(r.body)};
    } catch (e) { return {'ok': false, 'error': e.toString()}; }
  }

  Future<Map<String, dynamic>> delete(String path, [Map? body]) async {
    try {
      final req = http.Request('DELETE', _uri(path));
      req.headers.addAll({..._headers, 'Content-Type': 'application/json'});
      if (body != null) req.body = jsonEncode(body);
      final r = await http.Client().send(req).timeout(const Duration(seconds: 20));
      final bytes = await r.stream.toBytes();
      final s = utf8.decode(bytes);
      return {'ok': r.statusCode < 300, 'status': r.statusCode, 'data': s.isEmpty ? {} : jsonDecode(s)};
    } catch (e) { return {'ok': false, 'error': e.toString()}; }
  }

  Future<Map<String, dynamic>> getUser() => get('/user');
  Future<Map<String, dynamic>> patchUser(Map body) => patch('/user', body);
  Future<Map<String, dynamic>> listRepos() => get('/user/repos', {'per_page': '100', 'sort': 'updated', 'type': 'all'});
  Future<Map<String, dynamic>> listStarred() => get('/user/starred', {'per_page': '50', 'sort': 'updated'});
  Future<Map<String, dynamic>> listContents(String owner, String repo, String path) =>
      get('/repos/$owner/$repo/contents/$path');
  Future<Map<String, dynamic>> getFile(String owner, String repo, String path) =>
      get('/repos/$owner/$repo/contents/$path');
  Future<Map<String, dynamic>> createOrUpdateFile(String owner, String repo, String path, Map body) =>
      put('/repos/$owner/$repo/contents/$path', body);
  Future<Map<String, dynamic>> deleteFile(String owner, String repo, String path, Map body) =>
      delete('/repos/$owner/$repo/contents/$path', body);
  Future<Map<String, dynamic>> createRepo(Map body) => post('/user/repos', body);
  Future<Map<String, dynamic>> deleteRepo(String owner, String repo) => delete('/repos/$owner/$repo');
  Future<Map<String, dynamic>> renameRepo(String owner, String repo, String name) =>
      patch('/repos/$owner/$repo', {'name': name});
  Future<Map<String, dynamic>> listBranches(String owner, String repo) =>
      get('/repos/$owner/$repo/branches', {'per_page': '100'});
  Future<Map<String, dynamic>> getRef(String owner, String repo, String branch) =>
      get('/repos/$owner/$repo/git/ref/heads/$branch');
  Future<Map<String, dynamic>> createRef(String owner, String repo, Map body) =>
      post('/repos/$owner/$repo/git/refs', body);
  Future<Map<String, dynamic>> deleteRef(String owner, String repo, String branch) =>
      delete('/repos/$owner/$repo/git/refs/heads/$branch');
  Future<Map<String, dynamic>> setDefaultBranch(String owner, String repo, String branch) =>
      patch('/repos/$owner/$repo', {'default_branch': branch});
  Future<Map<String, dynamic>> listCommits(String owner, String repo, {int perPage = 15}) =>
      get('/repos/$owner/$repo/commits', {'per_page': '$perPage'});
  Future<Map<String, dynamic>> compareCommits(String owner, String repo, String base, String head) =>
      get('/repos/$owner/$repo/compare/${Uri.encodeComponent(base)}...${Uri.encodeComponent(head)}');
  Future<Map<String, dynamic>> getRepoStats(String owner, String repo) => get('/repos/$owner/$repo');
  Future<Map<String, dynamic>> getLanguages(String owner, String repo) => get('/repos/$owner/$repo/languages');
  Future<Map<String, dynamic>> getTrafficViews(String owner, String repo) => get('/repos/$owner/$repo/traffic/views');
  Future<Map<String, dynamic>> getTrafficClones(String owner, String repo) => get('/repos/$owner/$repo/traffic/clones');
  Future<Map<String, dynamic>> checkStarred(String owner, String repo) => get('/user/starred/$owner/$repo');
  Future<Map<String, dynamic>> starRepo(String owner, String repo) => put('/user/starred/$owner/$repo');
  Future<Map<String, dynamic>> unstarRepo(String owner, String repo) => delete('/user/starred/$owner/$repo');
  Future<Map<String, dynamic>> checkWatch(String owner, String repo) => get('/repos/$owner/$repo/subscription');
  Future<Map<String, dynamic>> watchRepo(String owner, String repo) => put('/repos/$owner/$repo/subscription', {'subscribed': true});
  Future<Map<String, dynamic>> unwatchRepo(String owner, String repo) => delete('/repos/$owner/$repo/subscription');
  Future<Map<String, dynamic>> listPRs(String owner, String repo, String state) =>
      get('/repos/$owner/$repo/pulls', {'state': state, 'per_page': '20'});
  Future<Map<String, dynamic>> getPR(String owner, String repo, int number) =>
      get('/repos/$owner/$repo/pulls/$number');
  Future<Map<String, dynamic>> createPR(String owner, String repo, Map body) =>
      post('/repos/$owner/$repo/pulls', body);
  Future<Map<String, dynamic>> mergePR(String owner, String repo, int number) =>
      put('/repos/$owner/$repo/pulls/$number/merge');
  Future<Map<String, dynamic>> closePR(String owner, String repo, int number) =>
      patch('/repos/$owner/$repo/pulls/$number', {'state': 'closed'});
  Future<Map<String, dynamic>> listIssues(String owner, String repo, String state) =>
      get('/repos/$owner/$repo/issues', {'state': state, 'per_page': '20'});
  Future<Map<String, dynamic>> getIssue(String owner, String repo, int number) =>
      get('/repos/$owner/$repo/issues/$number');
  Future<Map<String, dynamic>> createIssue(String owner, String repo, String title) =>
      post('/repos/$owner/$repo/issues', {'title': title});
  Future<Map<String, dynamic>> closeIssue(String owner, String repo, int number) =>
      patch('/repos/$owner/$repo/issues/$number', {'state': 'closed'});
  Future<Map<String, dynamic>> reopenIssue(String owner, String repo, int number) =>
      patch('/repos/$owner/$repo/issues/$number', {'state': 'open'});
  Future<Map<String, dynamic>> commentIssue(String owner, String repo, int number, String body) =>
      post('/repos/$owner/$repo/issues/$number/comments', {'body': body});
  Future<Map<String, dynamic>> listReleases(String owner, String repo) =>
      get('/repos/$owner/$repo/releases', {'per_page': '15'});
  Future<Map<String, dynamic>> getRelease(String owner, String repo, int id) =>
      get('/repos/$owner/$repo/releases/$id');
  Future<Map<String, dynamic>> createRelease(String owner, String repo, Map body) =>
      post('/repos/$owner/$repo/releases', body);
  Future<Map<String, dynamic>> deleteRelease(String owner, String repo, int id) =>
      delete('/repos/$owner/$repo/releases/$id');
  Future<Map<String, dynamic>> listWorkflows(String owner, String repo) =>
      get('/repos/$owner/$repo/actions/workflows');
  Future<Map<String, dynamic>> listWorkflowRuns(String owner, String repo) =>
      get('/repos/$owner/$repo/actions/runs', {'per_page': '10'});
  Future<Map<String, dynamic>> getWorkflowRun(String owner, String repo, int id) =>
      get('/repos/$owner/$repo/actions/runs/$id');
  Future<Map<String, dynamic>> cancelRun(String owner, String repo, int id) =>
      post('/repos/$owner/$repo/actions/runs/$id/cancel', {});
  Future<Map<String, dynamic>> rerunWorkflow(String owner, String repo, int id) =>
      post('/repos/$owner/$repo/actions/runs/$id/rerun', {});
  Future<Map<String, dynamic>> triggerWorkflow(String owner, String repo, int id, String ref) =>
      post('/repos/$owner/$repo/actions/workflows/$id/dispatches', {'ref': ref});
  Future<Map<String, dynamic>> listCollaborators(String owner, String repo) =>
      get('/repos/$owner/$repo/collaborators');
  Future<Map<String, dynamic>> addCollaborator(String owner, String repo, String user) =>
      put('/repos/$owner/$repo/collaborators/$user', {'permission': 'push'});
  Future<Map<String, dynamic>> removeCollaborator(String owner, String repo, String user) =>
      delete('/repos/$owner/$repo/collaborators/$user');
  Future<Map<String, dynamic>> updateVisibility(String owner, String repo, bool priv) =>
      patch('/repos/$owner/$repo', {'private': priv});
  Future<Map<String, dynamic>> updateDescription(String owner, String repo, String desc) =>
      patch('/repos/$owner/$repo', {'description': desc});
  Future<Map<String, dynamic>> archiveRepo(String owner, String repo, bool archive) =>
      patch('/repos/$owner/$repo', {'archived': archive});
  Future<Map<String, dynamic>> listGists() => get('/gists', {'per_page': '20'});
  Future<Map<String, dynamic>> getGist(String id) => get('/gists/$id');
  Future<Map<String, dynamic>> createGist(String filename, String content) =>
      post('/gists', {'description': 'Created via Taurus Shield', 'public': false, 'files': {filename: {'content': content}}});
  Future<Map<String, dynamic>> deleteGist(String id) => delete('/gists/$id');
}

// ─────────────────────────────────────────────────────────────────────────────
// TOKEN STORAGE
// ─────────────────────────────────────────────────────────────────────────────
class _TokenStore {
  static const _key = 'gh_pat_token';
  static Future<String?> load() async {
    final p = await SharedPreferences.getInstance();
    return p.getString(_key);
  }
  static Future<void> save(String token) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_key, token);
  }
  static Future<void> clear() async {
    final p = await SharedPreferences.getInstance();
    await p.remove(_key);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// GITHUB LOGO PAINTER
// ─────────────────────────────────────────────────────────────────────────────
class _GhLogoPainter extends CustomPainter {
  final Color color;
  const _GhLogoPainter(this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color..style = PaintingStyle.fill;
    final s = size.width / 16.0;
    canvas.save();
    canvas.scale(s, s);
    final circlePath = Path();
    circlePath.addOval(Rect.fromCircle(center: const Offset(8, 8), radius: 8));
    canvas.drawPath(circlePath, paint);

    final octo = Path();
    octo.moveTo(8, 1.6);
    octo.cubicTo(4.46, 1.6, 1.6, 4.46, 1.6, 8);
    octo.cubicTo(1.6, 10.82, 3.37, 13.21, 5.87, 14.08);
    octo.cubicTo(6.19, 14.14, 6.31, 13.94, 6.31, 13.77);
    octo.cubicTo(6.31, 13.62, 6.30, 13.11, 6.30, 12.57);
    octo.cubicTo(4.71, 12.92, 4.34, 12.0, 4.34, 12.0);
    octo.cubicTo(4.05, 11.26, 3.63, 11.06, 3.63, 11.06);
    octo.cubicTo(3.06, 10.65, 3.67, 10.66, 3.67, 10.66);
    octo.cubicTo(4.29, 10.70, 4.62, 11.30, 4.62, 11.30);
    octo.cubicTo(5.18, 12.27, 6.08, 11.98, 6.34, 11.82);
    octo.cubicTo(6.40, 11.43, 6.56, 11.14, 6.73, 10.97);
    octo.cubicTo(5.46, 10.80, 4.13, 10.30, 4.13, 8.15);
    octo.cubicTo(4.13, 7.44, 4.38, 6.86, 4.64, 6.41);
    octo.cubicTo(4.57, 6.24, 4.34, 5.58, 4.71, 4.69);
    octo.cubicTo(4.71, 4.69, 5.23, 4.51, 6.30, 5.35);
    octo.cubicTo(6.76, 5.21, 7.23, 5.14, 7.71, 5.14);
    octo.cubicTo(8.19, 5.14, 8.66, 5.21, 9.12, 5.35);
    octo.cubicTo(10.19, 4.51, 10.71, 4.69, 10.71, 4.69);
    octo.cubicTo(11.08, 5.58, 10.85, 6.24, 10.78, 6.41);
    octo.cubicTo(11.04, 6.86, 11.29, 7.44, 11.29, 8.15);
    octo.cubicTo(11.29, 10.31, 9.95, 10.80, 8.68, 10.97);
    octo.cubicTo(8.89, 11.17, 9.08, 11.56, 9.08, 12.17);
    octo.cubicTo(9.08, 13.03, 9.07, 13.73, 9.07, 13.77);
    octo.cubicTo(9.07, 13.94, 9.19, 14.14, 9.52, 14.08);
    octo.cubicTo(12.02, 13.21, 13.79, 10.82, 13.79, 8.0);
    octo.cubicTo(13.79, 4.46, 10.93, 1.6, 7.39, 1.6);
    octo.close();

    final fg = Paint()..color = Colors.white..style = PaintingStyle.fill;
    canvas.drawPath(octo, fg);
    canvas.restore();
  }

  @override
  bool shouldRepaint(_GhLogoPainter old) => old.color != color;
}

class _GhLogo extends StatelessWidget {
  final double size;
  final Color color;
  const _GhLogo({this.size = 40, this.color = Colors.white});

  @override
  Widget build(BuildContext context) => CustomPaint(
    size: Size(size, size),
    painter: _GhLogoPainter(color),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// UTILITIES
// ─────────────────────────────────────────────────────────────────────────────
IconData _fileIcon(String name) {
  final ext = name.contains('.') ? name.split('.').last.toLowerCase() : '';
  const m = <String, IconData>{
    'js':      Icons.javascript_rounded,
    'ts':      Icons.code_rounded,
    'py':      Icons.code_rounded,
    'java':    Icons.coffee_rounded,
    'kt':      Icons.code_rounded,
    'html':    Icons.html_rounded,
    'css':     Icons.css_rounded,
    'json':    Icons.data_object_rounded,
    'xml':     Icons.code_rounded,
    'md':      Icons.article_rounded,
    'txt':     Icons.text_snippet_rounded,
    'yml':     Icons.settings_rounded,
    'yaml':    Icons.settings_rounded,
    'dart':    Icons.code_rounded,
    'swift':   Icons.code_rounded,
    'c':       Icons.memory_rounded,
    'cpp':     Icons.memory_rounded,
    'h':       Icons.memory_rounded,
    'go':      Icons.code_rounded,
    'rs':      Icons.code_rounded,
    'rb':      Icons.code_rounded,
    'php':     Icons.php_rounded,
    'sh':      Icons.terminal_rounded,
    'bat':     Icons.terminal_rounded,
    'exe':     Icons.bolt_rounded,
    'apk':     Icons.android_rounded,
    'png':     Icons.image_rounded,
    'jpg':     Icons.image_rounded,
    'jpeg':    Icons.image_rounded,
    'gif':     Icons.gif_rounded,
    'svg':     Icons.image_rounded,
    'mp3':     Icons.music_note_rounded,
    'mp4':     Icons.movie_rounded,
    'pdf':     Icons.picture_as_pdf_rounded,
    'zip':     Icons.folder_zip_rounded,
    'gradle':  Icons.build_rounded,
  };
  return m[ext] ?? Icons.insert_drive_file_rounded;
}

String _fmtSize(int bytes) {
  if (bytes < 1024) return '$bytes B';
  if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
  return '${(bytes / (1024 * 1024)).toStringAsFixed(2)} MB';
}

String _fmtDate(String? iso) {
  if (iso == null) return '';
  try {
    final d = DateTime.parse(iso);
    return '${d.day}/${d.month}/${d.year}';
  } catch (_) { return iso; }
}

String _prErr(Map r) => r['error'] ?? (r['data'] is Map ? (r['data']['message'] ?? 'Unknown error') : 'Unknown error');

// ─────────────────────────────────────────────────────────────────────────────
// SHARED WIDGETS
// ─────────────────────────────────────────────────────────────────────────────
class _GhCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets? padding;
  const _GhCard({required this.child, this.padding});
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
    padding: padding ?? const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: _card,
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: _border),
    ),
    child: child,
  );
}

class _GhBtn extends StatelessWidget {
  final String label;
  final Color? color;
  final IconData? icon;
  final VoidCallback onTap;
  final bool outline;
  const _GhBtn({required this.label, required this.onTap, this.color, this.icon, this.outline = false});
  @override
  Widget build(BuildContext context) {
    final c = color ?? _ghBlue;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: outline ? Colors.transparent : c.withOpacity(0.15),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: c.withOpacity(0.5)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) ...[Icon(icon, color: c, size: 15), const SizedBox(width: 6)],
            Text(label, style: TextStyle(color: c, fontSize: 13, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}

class _LoadingView extends StatelessWidget {
  final String msg;
  const _LoadingView({this.msg = 'Loading...'});
  @override
  Widget build(BuildContext context) => Center(
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      const CircularProgressIndicator(color: _ghBlue, strokeWidth: 2),
      const SizedBox(height: 14),
      Text(msg, style: const TextStyle(color: _dimText, fontSize: 13)),
    ]),
  );
}

class _ErrView extends StatelessWidget {
  final String err;
  final VoidCallback? onRetry;
  const _ErrView({required this.err, this.onRetry});
  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.error_outline_rounded, color: _ghRed, size: 40),
        const SizedBox(height: 12),
        Text(err, style: const TextStyle(color: _ghRed, fontSize: 13), textAlign: TextAlign.center),
        if (onRetry != null) ...[
          const SizedBox(height: 14),
          _GhBtn(label: 'Retry', icon: Icons.refresh_rounded, color: _ghBlue, onTap: onRetry!),
        ],
      ]),
    ),
  );
}

class _SectionHeader extends StatelessWidget {
  final String title;
  final Widget? trailing;
  const _SectionHeader({required this.title, this.trailing});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(14, 12, 14, 6),
    child: Row(children: [
      Expanded(child: Text(title, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w700))),
      if (trailing != null) trailing!,
    ]),
  );
}

Widget _infoRow(String label, String value, {Color? valueColor}) => Padding(
  padding: const EdgeInsets.symmetric(vertical: 3),
  child: Row(children: [
    Text('$label: ', style: const TextStyle(color: _dimText, fontSize: 12.5)),
    Expanded(child: Text(value, style: TextStyle(color: valueColor ?? Colors.white, fontSize: 12.5, fontWeight: FontWeight.w600))),
  ]),
);

// ─────────────────────────────────────────────────────────────────────────────
// GITHUB MANAGER – MAIN SCREEN
// ─────────────────────────────────────────────────────────────────────────────
class GitHubManagerScreen extends StatefulWidget {
  const GitHubManagerScreen({super.key});
  @override
  State<GitHubManagerScreen> createState() => _GitHubManagerScreenState();
}

class _GitHubManagerScreenState extends State<GitHubManagerScreen>
    with TickerProviderStateMixin {
  String? _token;
  Map? _user;
  bool _loading = true;
  bool _connecting = false;
  String _err = '';

  late final AnimationController _logoCtrl;
  late final AnimationController _pulseCtrl;
  late final Animation<double> _logoSpin;
  late final Animation<double> _logoPulse;
  late final Animation<double> _cardFade;
  late final AnimationController _cardCtrl;

  @override
  void initState() {
    super.initState();
    _logoCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 4))..repeat();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))..repeat(reverse: true);
    _cardCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600))..forward();
    _logoSpin = Tween<double>(begin: 0, end: 2 * math.pi).animate(
      CurvedAnimation(parent: _logoCtrl, curve: Curves.linear));
    _logoPulse = Tween<double>(begin: 0.85, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
    _cardFade = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _cardCtrl, curve: Curves.easeOut));
    _loadToken();
  }

  @override
  void dispose() {
    _logoCtrl.dispose();
    _pulseCtrl.dispose();
    _cardCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadToken() async {
    final t = await _TokenStore.load();
    if (t != null) {
      await _validateAndSet(t, quiet: true);
    } else {
      setState(() => _loading = false);
    }
  }

  Future<void> _validateAndSet(String token, {bool quiet = false}) async {
    if (!quiet) setState(() => _connecting = true);
    final api = _GhApi(token);
    final r = await api.getUser();
    if (!mounted) return;
    if (r['ok'] == true) {
      await _TokenStore.save(token);
      setState(() {
        _token = token;
        _user = r['data'];
        _loading = false;
        _connecting = false;
        _err = '';
      });
    } else {
      setState(() {
        _loading = false;
        _connecting = false;
        _err = _prErr(r);
      });
    }
  }

  Future<void> _showConnectDialog() async {
    final ctrl = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => _ConnectDialog(ctrl: ctrl),
    );
    if (confirmed == true && ctrl.text.trim().isNotEmpty) {
      await _validateAndSet(ctrl.text.trim());
    }
  }

  Future<void> _disconnect() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _card,
        title: const Text('Disconnect GitHub?', style: TextStyle(color: Colors.white, fontSize: 16)),
        content: const Text('Your stored token will be removed.', style: TextStyle(color: _dimText)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(context, true),
            child: const Text('Disconnect', style: TextStyle(color: _ghRed))),
        ],
      ),
    );
    if (ok == true) {
      await _TokenStore.clear();
      setState(() { _token = null; _user = null; });
    }
  }

  _GhApi get _api => _GhApi(_token!);

  void _push(Widget screen) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => screen));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeProvider().current.scaffoldBg,
      appBar: AppBar(
        backgroundColor: const Color(0xFF0d1117),
        title: Row(mainAxisSize: MainAxisSize.min, children: [
          _GhLogo(size: 24, color: _ghBlue),
          const SizedBox(width: 10),
          const Text('GitHub Manager', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700)),
        ]),
        actions: [
          if (_token != null)
            IconButton(
              icon: const Icon(Icons.logout_rounded, color: _ghRed, size: 20),
              tooltip: 'Disconnect',
              onPressed: _disconnect,
            ),
        ],
      ),
      body: _loading
          ? const _LoadingView(msg: 'Loading...')
          : _buildBody(),
    );
  }

  Widget _buildBody() {
    return FadeTransition(
      opacity: _cardFade,
      child: Column(children: [
        _buildHeader(),
        if (_err.isNotEmpty)
          Padding(
            padding: const EdgeInsets.all(12),
            child: Text(_err, style: const TextStyle(color: _ghRed, fontSize: 13)),
          ),
        Expanded(child: _token == null ? _buildNotConnected() : _buildMenu()),
      ]),
    );
  }

  Widget _buildHeader() {
    return AnimatedBuilder(
      animation: Listenable.merge([_logoPulse, _pulseCtrl]),
      builder: (_, __) => Container(
        margin: const EdgeInsets.fromLTRB(14, 14, 14, 0),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF0d1117), Color(0xFF161b22)],
            begin: Alignment.topLeft, end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Color.lerp(const Color(0xFF21262d), _ghBlue.withOpacity(0.4), _logoPulse.value)!),
          boxShadow: [BoxShadow(color: _ghBlue.withOpacity(0.05 + _logoPulse.value * 0.08), blurRadius: 20)],
        ),
        child: Column(children: [
          AnimatedBuilder(
            animation: _logoCtrl,
            builder: (_, __) => Transform.scale(
              scale: _logoPulse.value,
              child: Container(
                width: 64, height: 64,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFF161b22),
                  border: Border.all(color: _ghBlue.withOpacity(0.3 + _logoPulse.value * 0.3), width: 2),
                  boxShadow: [BoxShadow(color: _ghBlue.withOpacity(0.2), blurRadius: 16)],
                ),
                child: const Center(child: _GhLogo(size: 38, color: _ghBlue)),
              ),
            ),
          ),
          const SizedBox(height: 14),
          if (_token == null) ...[
            const Text('GitHub Manager', style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            const Text('Manage repos, gists, branches and more — all from your device.', style: TextStyle(color: _dimText, fontSize: 12.5), textAlign: TextAlign.center),
          ] else ...[
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Container(width: 8, height: 8, decoration: const BoxDecoration(shape: BoxShape.circle, color: _ghGreen)),
              const SizedBox(width: 6),
              Text('@${_user?['login'] ?? ''}',
                style: const TextStyle(color: _ghGreen, fontSize: 15, fontWeight: FontWeight.w700)),
            ]),
            const SizedBox(height: 4),
            Text(_user?['name'] ?? _user?['login'] ?? '',
              style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w500)),
            const SizedBox(height: 3),
            Text('${_user?['public_repos'] ?? 0} public repos  •  ${_user?['followers'] ?? 0} followers',
              style: const TextStyle(color: _dimText, fontSize: 12)),
            if (_user?['bio'] != null && _user!['bio'] != '') ...[
              const SizedBox(height: 6),
              Text(_user!['bio'], style: const TextStyle(color: _dimText, fontSize: 11.5), textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis),
            ],
          ],
        ]),
      ),
    );
  }

  Widget _buildNotConnected() => Center(
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      _GhLogo(size: 64, color: _ghBlue.withOpacity(0.4)),
      const SizedBox(height: 20),
      const Text('Connect your GitHub account', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      const Text('Use a Personal Access Token (PAT)', style: TextStyle(color: _dimText, fontSize: 13)),
      const SizedBox(height: 24),
      _GhBtn(label: 'Connect GitHub', icon: Icons.link_rounded, color: _ghGreen,
        onTap: _connecting ? () {} : _showConnectDialog),
      if (_connecting) ...[
        const SizedBox(height: 16),
        const CircularProgressIndicator(color: _ghBlue, strokeWidth: 2),
      ],
    ]),
  );

  Widget _buildMenu() {
    final items = [
      _MenuItem(icon: Icons.person_rounded, color: _ghBlue, label: 'My Profile',
        sub: 'View & edit your GitHub profile', onTap: () => _push(_GhProfileScreen(api: _api, user: _user ?? {}))),
      _MenuItem(icon: Icons.folder_rounded, color: _ghGreen, label: 'My Repositories',
        sub: 'Browse & manage all repos', onTap: () => _push(_GhReposScreen(api: _api))),
      _MenuItem(icon: Icons.star_rounded, color: _ghYellow, label: 'Starred Repos',
        sub: 'View your starred repositories', onTap: () => _push(_GhStarredScreen(api: _api))),
      _MenuItem(icon: Icons.code_rounded, color: _ghGreen, label: 'My Gists',
        sub: 'Create and manage code snippets', onTap: () => _push(_GhGistsScreen(api: _api))),
      _MenuItem(icon: Icons.upload_rounded, color: _ghOrange, label: 'Push New Project',
        sub: 'Upload a ZIP file to a new repo', onTap: () => _push(_GhPushScreen(api: _api, username: _user?['login'] ?? ''))),
      _MenuItem(icon: Icons.refresh_rounded, color: _dimText, label: 'Refresh Token',
        sub: 'Replace your stored PAT', onTap: _showConnectDialog),
    ];
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 80),
      itemCount: items.length,
      itemBuilder: (_, i) {
        final item = items[i];
        return GestureDetector(
          onTap: item.onTap,
          child: Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _border),
            ),
            child: Row(children: [
              Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                  color: item.color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: item.color.withOpacity(0.3)),
                ),
                child: Icon(item.icon, color: item.color, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(item.label, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(item.sub, style: const TextStyle(color: _dimText, fontSize: 12)),
              ])),
              const Icon(Icons.chevron_right_rounded, color: _dimText, size: 18),
            ]),
          ),
        );
      },
    );
  }
}

class _MenuItem {
  final IconData icon;
  final Color color;
  final String label;
  final String sub;
  final VoidCallback onTap;
  const _MenuItem({required this.icon, required this.color, required this.label, required this.sub, required this.onTap});
}

// ─────────────────────────────────────────────────────────────────────────────
// CONNECT DIALOG
// ─────────────────────────────────────────────────────────────────────────────
class _ConnectDialog extends StatelessWidget {
  final TextEditingController ctrl;
  const _ConnectDialog({required this.ctrl});

  @override
  Widget build(BuildContext context) => AlertDialog(
    backgroundColor: _card,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: const BorderSide(color: _border)),
    title: Row(children: [
      const _GhLogo(size: 22, color: _ghBlue),
      const SizedBox(width: 10),
      const Text('Connect GitHub', style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w700)),
    ]),
    content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Paste your Personal Access Token (PAT):', style: TextStyle(color: _dimText, fontSize: 12.5)),
      const SizedBox(height: 4),
      const Text('Required scopes: repo, delete_repo (optional)', style: TextStyle(color: _dimText, fontSize: 11)),
      const SizedBox(height: 12),
      TextField(
        controller: ctrl,
        obscureText: true,
        style: const TextStyle(color: Colors.white, fontSize: 13, fontFamily: 'monospace'),
        decoration: InputDecoration(
          hintText: 'ghp_xxxxxxxxxxxxxxxxxxxx',
          hintStyle: const TextStyle(color: _dimText),
          filled: true,
          fillColor: const Color(0xFF161b22),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: _border)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: _border)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: _ghBlue)),
        ),
      ),
      const SizedBox(height: 10),
      GestureDetector(
        onTap: () => launchUrl(Uri.parse('https://github.com/settings/tokens/new'), mode: LaunchMode.externalApplication),
        child: const Text('Create a token on github.com →', style: TextStyle(color: _ghBlue, fontSize: 12, decoration: TextDecoration.underline)),
      ),
    ]),
    actions: [
      TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel', style: TextStyle(color: _dimText))),
      ElevatedButton(
        style: ElevatedButton.styleFrom(backgroundColor: _ghGreen, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
        onPressed: () => Navigator.pop(context, true),
        child: const Text('Connect'),
      ),
    ],
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// REPOS LIST SCREEN
// ─────────────────────────────────────────────────────────────────────────────
class _GhReposScreen extends StatefulWidget {
  final _GhApi api;
  const _GhReposScreen({required this.api});
  @override
  State<_GhReposScreen> createState() => _GhReposScreenState();
}

class _GhReposScreenState extends State<_GhReposScreen> {
  List _repos = [];
  bool _loading = true;
  String? _err;
  int _page = 0;
  static const _perPage = 8;
  final _searchCtrl = TextEditingController();
  String _query = '';

  @override
  void initState() {
    super.initState();
    _load();
    _searchCtrl.addListener(() {
      setState(() { _query = _searchCtrl.text.trim().toLowerCase(); _page = 0; });
    });
  }

  @override
  void dispose() { _searchCtrl.dispose(); super.dispose(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.listRepos();
    if (!mounted) return;
    if (r['ok'] == true) {
      setState(() { _repos = r['data'] is List ? r['data'] : []; _loading = false; });
    } else {
      setState(() { _loading = false; _err = _prErr(r); });
    }
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _query.isEmpty
        ? _repos
        : _repos.where((r) {
            final name = (r['name'] ?? '').toString().toLowerCase();
            final desc = (r['description'] ?? '').toString().toLowerCase();
            return name.contains(_query) || desc.contains(_query);
          }).toList();
    final totalPages = _query.isEmpty ? (filtered.length / _perPage).ceil() : 1;
    final pageRepos = _query.isEmpty
        ? filtered.skip(_page * _perPage).take(_perPage).toList()
        : filtered;
    return Scaffold(
      backgroundColor: ThemeProvider().current.scaffoldBg,
      appBar: AppBar(
        backgroundColor: const Color(0xFF0d1117),
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('My Repositories', style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w700)),
          if (!_loading && _err == null)
            Text(_query.isEmpty ? '${_repos.length} total' : '${filtered.length} of ${_repos.length}',
              style: const TextStyle(color: _dimText, fontSize: 11)),
        ]),
        actions: [
          IconButton(icon: const Icon(Icons.refresh_rounded, color: _ghBlue, size: 20), onPressed: _load),
        ],
      ),
      body: _loading ? const _LoadingView(msg: 'Loading repositories...')
          : _err != null ? _ErrView(err: _err!, onRetry: _load)
          : _repos.isEmpty ? const Center(child: Text('No repositories found', style: TextStyle(color: _dimText)))
          : Column(children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(14, 10, 14, 4),
                child: TextField(
                  controller: _searchCtrl,
                  style: const TextStyle(color: Colors.white, fontSize: 13),
                  decoration: InputDecoration(
                    hintText: 'Search repositories...',
                    hintStyle: const TextStyle(color: _dimText, fontSize: 13),
                    prefixIcon: const Icon(Icons.search_rounded, color: _dimText, size: 18),
                    suffixIcon: _query.isNotEmpty
                        ? IconButton(icon: const Icon(Icons.clear_rounded, color: _dimText, size: 16),
                            onPressed: () { _searchCtrl.clear(); })
                        : null,
                    filled: true,
                    fillColor: const Color(0xFF161b22),
                    contentPadding: const EdgeInsets.symmetric(vertical: 10),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _border)),
                    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _border)),
                    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _ghBlue)),
                  ),
                ),
              ),
              if (pageRepos.isEmpty)
                const Expanded(child: Center(child: Text('No matches found', style: TextStyle(color: _dimText))))
              else
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.fromLTRB(14, 6, 14, 10),
                    itemCount: pageRepos.length,
                    itemBuilder: (_, i) {
                      final repo = pageRepos[i];
                      return _RepoCard(repo: repo, onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (_) =>
                          _GhRepoBrowserScreen(api: widget.api, owner: repo['owner']['login'], repo: repo['name'], isPrivate: repo['private'] == true)));
                      });
                    },
                  ),
                ),
              if (totalPages > 1) _Pagination(page: _page, total: totalPages,
                onPrev: () => setState(() => _page--),
                onNext: () => setState(() => _page++)),
            ]),
    );
  }
}

class _RepoCard extends StatelessWidget {
  final Map repo;
  final VoidCallback onTap;
  const _RepoCard({required this.repo, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(12), border: Border.all(color: _border)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(repo['private'] == true ? Icons.lock_rounded : Icons.folder_rounded,
            color: repo['private'] == true ? _ghOrange : _ghBlue, size: 16),
          const SizedBox(width: 6),
          Expanded(child: Text(repo['name'] ?? '', style: const TextStyle(color: _ghBlue, fontSize: 14, fontWeight: FontWeight.w700))),
          const SizedBox(width: 6),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              color: (repo['private'] == true ? _ghOrange : _ghGreen).withOpacity(0.12),
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: (repo['private'] == true ? _ghOrange : _ghGreen).withOpacity(0.4)),
            ),
            child: Text(
              repo['private'] == true ? 'Private' : 'Public',
              style: TextStyle(color: repo['private'] == true ? _ghOrange : _ghGreen, fontSize: 10, fontWeight: FontWeight.w600),
            ),
          ),
          if (repo['archived'] == true) ...[
            const SizedBox(width: 4),
            Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(color: _ghYellow.withOpacity(0.15), borderRadius: BorderRadius.circular(4), border: Border.all(color: _ghYellow.withOpacity(0.4))),
              child: const Text('archived', style: TextStyle(color: _ghYellow, fontSize: 10))),
          ],
        ]),
        if (repo['description'] != null && repo['description'] != '') ...[
          const SizedBox(height: 6),
          Text(repo['description'], style: const TextStyle(color: _dimText, fontSize: 12), maxLines: 2, overflow: TextOverflow.ellipsis),
        ],
        const SizedBox(height: 8),
        Row(children: [
          if (repo['language'] != null) ...[
            Container(width: 10, height: 10, decoration: const BoxDecoration(shape: BoxShape.circle, color: _ghPurple)),
            const SizedBox(width: 4),
            Text(repo['language'], style: const TextStyle(color: _dimText, fontSize: 11)),
            const SizedBox(width: 12),
          ],
          const Icon(Icons.star_rounded, color: _ghYellow, size: 12),
          const SizedBox(width: 2),
          Text('${repo['stargazers_count'] ?? 0}', style: const TextStyle(color: _dimText, fontSize: 11)),
          const SizedBox(width: 8),
          const Icon(Icons.fork_right_rounded, color: _dimText, size: 12),
          const SizedBox(width: 2),
          Text('${repo['forks_count'] ?? 0}', style: const TextStyle(color: _dimText, fontSize: 11)),
          const Spacer(),
          Text('Updated ${_fmtDate(repo['updated_at'])}', style: const TextStyle(color: _dimText, fontSize: 10.5)),
        ]),
        if (repo['html_url'] != null) ...[
          const SizedBox(height: 6),
          GestureDetector(
            onTap: () {
              Clipboard.setData(ClipboardData(text: repo['html_url']));
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                content: Text('URL copied to clipboard'),
                duration: Duration(seconds: 2),
                backgroundColor: _ghGreen,
              ));
            },
            child: Row(children: [
              const Icon(Icons.link_rounded, size: 12, color: _ghBlue),
              const SizedBox(width: 4),
              Expanded(child: Text(repo['html_url'], style: const TextStyle(color: _ghBlue, fontSize: 11), overflow: TextOverflow.ellipsis)),
              const Icon(Icons.copy_rounded, size: 12, color: _dimText),
            ]),
          ),
        ],
      ]),
    ),
  );
}

class _Pagination extends StatelessWidget {
  final int page, total;
  final VoidCallback onPrev, onNext;
  const _Pagination({required this.page, required this.total, required this.onPrev, required this.onNext});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(12),
    child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
      if (page > 0) _GhBtn(label: '← Prev', onTap: onPrev, color: _ghBlue),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 12),
        child: Text('${page + 1} / $total', style: const TextStyle(color: _dimText, fontSize: 13))),
      if (page < total - 1) _GhBtn(label: 'Next →', onTap: onNext, color: _ghBlue),
    ]),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// SEARCH SCREEN
// ─────────────────────────────────────────────────────────────────────────────
class _GhSearchScreen extends StatefulWidget {
  final _GhApi api;
  const _GhSearchScreen({required this.api});
  @override
  State<_GhSearchScreen> createState() => _GhSearchScreenState();
}

class _GhSearchScreenState extends State<_GhSearchScreen> {
  final _ctrl = TextEditingController();
  List _results = [];
  bool _searching = false;
  bool _searched = false;

  Future<void> _search() async {
    final q = _ctrl.text.trim().toLowerCase();
    if (q.isEmpty) return;
    setState(() { _searching = true; });
    final r = await widget.api.listRepos();
    if (!mounted) return;
    if (r['ok'] == true) {
      final all = r['data'] as List;
      setState(() {
        _results = all.where((repo) =>
          (repo['name'] as String).toLowerCase().contains(q) ||
          (repo['description'] ?? '').toLowerCase().contains(q)).toList();
        _searching = false;
        _searched = true;
      });
    } else {
      setState(() { _searching = false; });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: ThemeProvider().current.scaffoldBg,
    appBar: AppBar(
      backgroundColor: const Color(0xFF0d1117),
      title: TextField(
        controller: _ctrl,
        style: const TextStyle(color: Colors.white),
        decoration: const InputDecoration(
          hintText: 'Search repositories...', hintStyle: TextStyle(color: _dimText),
          border: InputBorder.none),
        onSubmitted: (_) => _search(),
      ),
      actions: [
        IconButton(icon: const Icon(Icons.search_rounded, color: _ghBlue), onPressed: _search),
      ],
    ),
    body: _searching ? const _LoadingView(msg: 'Searching...')
        : !_searched ? const Center(child: Text('Type to search your repositories', style: TextStyle(color: _dimText)))
        : _results.isEmpty ? const Center(child: Text('No repositories found', style: TextStyle(color: _dimText)))
        : ListView.builder(
            padding: const EdgeInsets.all(14),
            itemCount: _results.length,
            itemBuilder: (_, i) => _RepoCard(repo: _results[i], onTap: () {
              final repo = _results[i];
              Navigator.push(context, MaterialPageRoute(builder: (_) =>
                _GhRepoBrowserScreen(api: widget.api, owner: repo['owner']['login'], repo: repo['name'], isPrivate: repo['private'] == true)));
            }),
          ),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// REPO BROWSER SCREEN (file explorer + all repo actions)
// ─────────────────────────────────────────────────────────────────────────────
class _GhRepoBrowserScreen extends StatefulWidget {
  final _GhApi api;
  final String owner, repo;
  final String currentPath;
  final bool? isPrivate;
  const _GhRepoBrowserScreen({required this.api, required this.owner, required this.repo, this.currentPath = '', this.isPrivate});
  @override
  State<_GhRepoBrowserScreen> createState() => _GhRepoBrowserScreenState();
}

class _GhRepoBrowserScreenState extends State<_GhRepoBrowserScreen> {
  List _items = [];
  bool _loading = true;
  String? _err;
  int _page = 0;
  static const _perPage = 12;
  bool? _isPrivate;
  Map? _repoStats;
  List _branches = [];
  bool _statsLoading = true;

  @override
  void initState() {
    super.initState();
    _isPrivate = widget.isPrivate;
    _load();
    _loadStats();
  }

  Future<void> _loadStats() async {
    final results = await Future.wait([
      widget.api.getRepoStats(widget.owner, widget.repo),
      widget.api.listBranches(widget.owner, widget.repo),
    ]);
    if (!mounted) return;
    final statsR = results[0]; final branchR = results[1];
    setState(() {
      _statsLoading = false;
      if (statsR['ok'] == true) _repoStats = statsR['data'] as Map?;
      if (branchR['ok'] == true && branchR['data'] is List) _branches = branchR['data'];
      if (_repoStats != null && _isPrivate == null) _isPrivate = _repoStats!['private'] == true;
    });
  }

  Future<void> _quickToggleVisibility() async {
    final cur = _isPrivate ?? false;
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      backgroundColor: _card,
      title: Text('Make ${cur ? 'Public' : 'Private'}?', style: const TextStyle(color: Colors.white, fontSize: 15)),
      content: Text(
        cur ? 'This repo will become publicly visible to everyone.' : 'Only you and collaborators will see this repo.',
        style: const TextStyle(color: _dimText, fontSize: 13),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel', style: TextStyle(color: _dimText))),
        TextButton(
          onPressed: () => Navigator.pop(context, true),
          child: Text(cur ? 'Make Public' : 'Make Private', style: TextStyle(color: cur ? _ghGreen : _ghOrange, fontWeight: FontWeight.w700)),
        ),
      ],
    ));
    if (ok != true || !mounted) return;
    _showBusy(cur ? 'Making public...' : 'Making private...');
    final r = await widget.api.updateVisibility(widget.owner, widget.repo, !cur);
    if (!mounted) return;
    Navigator.pop(context);
    if (r['ok'] == true) {
      setState(() { _isPrivate = !cur; });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Repo is now ${!cur ? 'private' : 'public'}'),
        backgroundColor: _ghGreen,
      ));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_prErr(r)), backgroundColor: _ghRed));
    }
  }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.listContents(widget.owner, widget.repo, widget.currentPath);
    if (!mounted) return;
    if (r['ok'] == true) {
      List raw = r['data'] is List ? r['data'] : [r['data']];
      raw.sort((a, b) {
        if (a['type'] == 'dir' && b['type'] != 'dir') return -1;
        if (a['type'] != 'dir' && b['type'] == 'dir') return 1;
        return (a['name'] as String).compareTo(b['name']);
      });
      setState(() { _items = raw; _loading = false; });
    } else {
      setState(() { _loading = false; _err = _prErr(r); });
    }
  }

  Future<void> _uploadFile() async {
    final res = await FilePicker.platform.pickFiles(allowMultiple: false);
    if (res == null || res.files.isEmpty) return;
    final file = res.files.first;
    if (file.path == null) return;
    _showBusy('Uploading ${file.name}...');
    try {
      final bytes = await File(file.path!).readAsBytes();
      final b64 = base64.encode(bytes);
      final path = widget.currentPath.isEmpty ? file.name : '${widget.currentPath}/${file.name}';
      final r = await widget.api.createOrUpdateFile(widget.owner, widget.repo, path, {
        'message': 'Upload ${file.name} via Taurus Shield',
        'content': b64,
      });
      if (!mounted) return;
      Navigator.pop(context);
      if (r['ok'] == true) {
        _toast('Uploaded ${file.name} ✓');
        _load();
      } else {
        _toast(_prErr(r), error: true);
      }
    } catch (e) {
      if (mounted) Navigator.pop(context);
      _toast(e.toString(), error: true);
    }
  }

  Future<void> _downloadRepoZip() async {
    final hasAccess = await PermissionHelper.ensureStorage(context, accent: _ghBlue);
    if (!hasAccess || !mounted) return;
    _showBusy('Downloading ${widget.repo}.zip…');
    try {
      // GitHub API returns a redirect (302) to the actual S3 download URL.
      // http.get follows redirects automatically and returns the final response.
      final resp = await http.get(
        Uri.parse('https://api.github.com/repos/${widget.owner}/${widget.repo}/zipball/main'),
        headers: {
          'Authorization': 'token ${widget.api.token}',
          'User-Agent': 'Taurus-Shield-App',
        },
      ).timeout(const Duration(seconds: 120));
      if (resp.statusCode != 200) {
        if (!mounted) return;
        Navigator.pop(context);
        _toast('Download failed: HTTP ${resp.statusCode}', error: true);
        return;
      }
      final root = await StorageHelper.getRootDir();
      final dir  = Directory('$root/${StorageHelper.appFolder}/github');
      await dir.create(recursive: true);
      final path = '${dir.path}/${widget.repo}.zip';
      await File(path).writeAsBytes(resp.bodyBytes);
      if (!mounted) return;
      Navigator.pop(context);
      _toast('Saved → Taurus-Shield/github/${widget.repo}.zip');
    } catch (e) {
      if (mounted) { Navigator.pop(context); _toast('Download failed: $e', error: true); }
    }
  }

  void _showBusy(String msg) {
    showDialog(context: context, barrierDismissible: false, builder: (_) => AlertDialog(
      backgroundColor: _card,
      content: Row(children: [
        const CircularProgressIndicator(color: _ghBlue, strokeWidth: 2),
        const SizedBox(width: 16),
        Expanded(child: Text(msg, style: const TextStyle(color: Colors.white))),
      ]),
    ));
  }

  void _toast(String msg, {bool error = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: error ? _ghRed : _ghGreen,
      duration: const Duration(seconds: 3),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final pageItems = _items.skip(_page * _perPage).take(_perPage).toList();
    final totalPages = (_items.length / _perPage).ceil();
    final defaultBranch = (_repoStats?['default_branch'] ?? 'main') as String;
    return Scaffold(
      backgroundColor: ThemeProvider().current.scaffoldBg,
      appBar: AppBar(
        backgroundColor: const Color(0xFF0d1117),
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.chevron_right_rounded, color: _dimText, size: 14),
            const SizedBox(width: 2),
            Flexible(child: Text('${widget.owner} / ${widget.repo}', style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700), overflow: TextOverflow.ellipsis)),
          ]),
          if (widget.currentPath.isNotEmpty)
            Text(widget.currentPath, style: const TextStyle(color: _dimText, fontSize: 10.5)),
        ]),
        actions: [
          IconButton(icon: const Icon(Icons.refresh_rounded, color: _ghBlue, size: 20), onPressed: () { _load(); _loadStats(); }),
          IconButton(icon: const Icon(Icons.more_vert_rounded, color: _dimText, size: 20), onPressed: _showRepoMenu),
        ],
      ),
      body: Column(children: [
        // ── Stats strip ──────────────────────────────────────────────────────
        if (!_statsLoading && _repoStats != null)
          Container(
            color: const Color(0xFF161b22),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              // Row 1: stars / forks / watching
              Row(children: [
                _MiniStat(icon: Icons.star_rounded, color: _ghYellow, label: '${_repoStats!['stargazers_count'] ?? 0} stars'),
                const SizedBox(width: 16),
                _MiniStat(icon: Icons.fork_right_rounded, color: _dimText, label: '${_repoStats!['forks_count'] ?? 0} forks'),
                const SizedBox(width: 16),
                _MiniStat(icon: Icons.remove_red_eye_rounded, color: _dimText, label: '${_repoStats!['watchers_count'] ?? 0} watching'),
              ]),
              const SizedBox(height: 6),
              // Row 2: branches / visibility
              Row(children: [
                _MiniStat(icon: Icons.account_tree_rounded, color: _ghGreen, label: '${_branches.length} branch${_branches.length == 1 ? '' : 'es'}'),
                const SizedBox(width: 16),
                _MiniStat(
                  icon: _isPrivate == true ? Icons.lock_rounded : Icons.public_rounded,
                  color: _isPrivate == true ? _ghOrange : _ghGreen,
                  label: _isPrivate == true ? 'Private repository' : 'Public repository',
                ),
              ]),
            ]),
          ),
        // ── Branch bar + Code button ─────────────────────────────────────────
        Container(
          color: _card,
          padding: const EdgeInsets.fromLTRB(14, 8, 14, 8),
          child: Row(children: [
            // Branch chip
            GestureDetector(
              onTap: () => _showBranchPicker(defaultBranch),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: const Color(0xFF21262d),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: _border),
                ),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.account_tree_rounded, size: 14, color: _dimText),
                  const SizedBox(width: 6),
                  Text(defaultBranch, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w500)),
                  const SizedBox(width: 4),
                  const Icon(Icons.keyboard_arrow_down_rounded, size: 16, color: _dimText),
                ]),
              ),
            ),
            const Spacer(),
            // Green Code button
            GestureDetector(
              onTap: _showCodeMenu,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  color: const Color(0xFF238636),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: const Color(0xFF2ea043)),
                ),
                child: const Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.code_rounded, size: 15, color: Colors.white),
                  SizedBox(width: 6),
                  Text('Code', style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700)),
                  SizedBox(width: 4),
                  Icon(Icons.keyboard_arrow_down_rounded, size: 16, color: Colors.white),
                ]),
              ),
            ),
          ]),
        ),
        const Divider(height: 1, color: _border),
        // ── File list ────────────────────────────────────────────────────────
        if (_loading)
          const Expanded(child: _LoadingView(msg: 'Loading files...'))
        else if (_err != null)
          Expanded(child: _ErrView(err: _err!, onRetry: _load))
        else if (_items.isEmpty)
          const Expanded(child: Center(child: Text('Empty repository', style: TextStyle(color: _dimText))))
        else
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(0, 0, 0, 80),
              children: [
                if (widget.currentPath.isNotEmpty)
                  _FileTile(
                    icon: Icons.subdirectory_arrow_left_rounded, name: '..', isDir: true,
                    onTap: () {
                      final parent = widget.currentPath.contains('/')
                        ? widget.currentPath.split('/').sublist(0, widget.currentPath.split('/').length - 1).join('/')
                        : '';
                      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) =>
                        _GhRepoBrowserScreen(api: widget.api, owner: widget.owner, repo: widget.repo, currentPath: parent)));
                    },
                  ),
                ...pageItems.map((item) => _FileTile(
                  icon: item['type'] == 'dir' ? Icons.folder_rounded : _fileIcon(item['name']),
                  name: item['name'],
                  isDir: item['type'] == 'dir',
                  size: item['type'] != 'dir' && item['size'] != null ? _fmtSize(item['size']) : null,
                  onTap: () {
                    if (item['type'] == 'dir') {
                      final newPath = widget.currentPath.isEmpty ? item['name'] : '${widget.currentPath}/${item['name']}';
                      Navigator.push(context, MaterialPageRoute(builder: (_) =>
                        _GhRepoBrowserScreen(api: widget.api, owner: widget.owner, repo: widget.repo, currentPath: newPath)));
                    } else {
                      final path = widget.currentPath.isEmpty ? item['name'] : '${widget.currentPath}/${item['name']}';
                      Navigator.push(context, MaterialPageRoute(builder: (_) =>
                        _GhFileActionScreen(api: widget.api, owner: widget.owner, repo: widget.repo, filePath: path)));
                    }
                  },
                )),
              ],
            ),
          ),
        if (totalPages > 1) _Pagination(page: _page, total: totalPages, onPrev: () => setState(() => _page--), onNext: () => setState(() => _page++)),
      ]),
    );
  }

  void _showCodeMenu() {
    final httpsUrl = 'https://github.com/${widget.owner}/${widget.repo}.git';
    final sshUrl   = 'git@github.com:${widget.owner}/${widget.repo}.git';
    showModalBottomSheet(
      context: context,
      backgroundColor: _card,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 32),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.code_rounded, color: _ghGreen, size: 18),
            const SizedBox(width: 8),
            const Text('Clone', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700)),
          ]),
          const SizedBox(height: 16),
          const Text('HTTPS', style: TextStyle(color: _dimText, fontSize: 11, fontWeight: FontWeight.w600)),
          const SizedBox(height: 4),
          _CloneUrlRow(url: httpsUrl),
          const SizedBox(height: 12),
          const Text('SSH', style: TextStyle(color: _dimText, fontSize: 11, fontWeight: FontWeight.w600)),
          const SizedBox(height: 4),
          _CloneUrlRow(url: sshUrl),
          const SizedBox(height: 20),
          const Divider(color: _border),
          const SizedBox(height: 12),
          GestureDetector(
            onTap: () { Navigator.pop(context); _downloadRepoZip(); },
            child: Row(children: [
              const Icon(Icons.folder_zip_rounded, color: _ghGreen, size: 20),
              const SizedBox(width: 12),
              const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Download ZIP', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600)),
                Text('Download the full repository as a ZIP file', style: TextStyle(color: _dimText, fontSize: 12)),
              ])),
              const Icon(Icons.chevron_right_rounded, color: _dimText, size: 18),
            ]),
          ),
        ]),
      ),
    );
  }

  void _showBranchPicker(String current) {
    showModalBottomSheet(
      context: context,
      backgroundColor: _card,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (_) => DraggableScrollableSheet(
        expand: false, initialChildSize: 0.5, maxChildSize: 0.85,
        builder: (_, ctrl) => Column(children: [
          Container(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
            child: Row(children: [
              const Text('Switch branches / tags', style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w700)),
              const Spacer(),
              IconButton(icon: const Icon(Icons.close_rounded, color: _dimText, size: 20), onPressed: () => Navigator.pop(_)),
            ]),
          ),
          const Divider(color: _border, height: 1),
          Expanded(
            child: _branches.isEmpty
              ? const Center(child: Text('No branches found', style: TextStyle(color: _dimText)))
              : ListView.builder(
                  controller: ctrl,
                  itemCount: _branches.length,
                  itemBuilder: (_, i) {
                    final b = _branches[i]['name'] as String;
                    final isCurrent = b == current;
                    return ListTile(
                      leading: Icon(Icons.account_tree_rounded, size: 16, color: isCurrent ? _ghGreen : _dimText),
                      title: Text(b, style: TextStyle(color: isCurrent ? _ghGreen : Colors.white, fontSize: 13)),
                      trailing: isCurrent ? const Icon(Icons.check_rounded, color: _ghGreen, size: 16) : null,
                      dense: true,
                    );
                  },
                ),
          ),
        ]),
      ),
    );
  }

  void _showRepoMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: _card,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (_) => _RepoMenuSheet(api: widget.api, owner: widget.owner, repo: widget.repo, isPrivate: _isPrivate, onVisibilityToggled: (val) => setState(() => _isPrivate = val)),
    );
  }
}

class _FileTile extends StatelessWidget {
  final IconData icon;
  final String name;
  final bool isDir;
  final VoidCallback onTap;
  final String? size;
  const _FileTile({required this.icon, required this.name, required this.isDir, required this.onTap, this.size});
  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _border))),
      child: Row(children: [
        Icon(icon, size: 16, color: isDir ? _ghBlue : _dimText),
        const SizedBox(width: 10),
        Expanded(child: Text(name, style: TextStyle(color: isDir ? _ghBlue : Colors.white, fontSize: 13, fontWeight: isDir ? FontWeight.w500 : FontWeight.normal))),
        if (size != null) Text(size!, style: const TextStyle(color: _dimText, fontSize: 11)),
        const SizedBox(width: 6),
        Icon(isDir ? Icons.chevron_right_rounded : Icons.chevron_right_rounded, color: _dimText, size: 14),
      ]),
    ),
  );
}

class _MiniStat extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String label;
  const _MiniStat({required this.icon, required this.color, required this.label});
  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [
    Icon(icon, size: 13, color: color),
    const SizedBox(width: 4),
    Text(label, style: const TextStyle(color: _dimText, fontSize: 12)),
  ]);
}

class _CloneUrlRow extends StatelessWidget {
  final String url;
  const _CloneUrlRow({required this.url});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
    decoration: BoxDecoration(color: const Color(0xFF161b22), borderRadius: BorderRadius.circular(6), border: Border.all(color: _border)),
    child: Row(children: [
      Expanded(child: Text(url, style: const TextStyle(color: Colors.white, fontSize: 12, fontFamily: 'monospace'), overflow: TextOverflow.ellipsis)),
      const SizedBox(width: 8),
      GestureDetector(
        onTap: () {
          Clipboard.setData(ClipboardData(text: url));
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Copied to clipboard'), duration: Duration(seconds: 2), backgroundColor: _ghGreen));
        },
        child: const Icon(Icons.copy_rounded, size: 16, color: _dimText),
      ),
    ]),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// REPO MENU SHEET (all repo-level features)
// ─────────────────────────────────────────────────────────────────────────────
class _RepoMenuSheet extends StatefulWidget {
  final _GhApi api;
  final String owner, repo;
  final bool? isPrivate;
  final void Function(bool)? onVisibilityToggled;
  const _RepoMenuSheet({required this.api, required this.owner, required this.repo, this.isPrivate, this.onVisibilityToggled});
  @override
  State<_RepoMenuSheet> createState() => _RepoMenuSheetState();
}

class _RepoMenuSheetState extends State<_RepoMenuSheet> {
  bool? _isPrivate;
  bool _toggling = false;

  @override
  void initState() { super.initState(); _isPrivate = widget.isPrivate; }

  Future<void> _doToggle() async {
    final cur = _isPrivate ?? false;
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      backgroundColor: _card,
      title: Text('Make ${cur ? 'Public' : 'Private'}?', style: const TextStyle(color: Colors.white, fontSize: 15)),
      content: Text(
        cur ? 'This repo will be visible to everyone.' : 'Only you and collaborators will see it.',
        style: const TextStyle(color: _dimText, fontSize: 13),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel', style: TextStyle(color: _dimText))),
        TextButton(
          onPressed: () => Navigator.pop(context, true),
          child: Text(cur ? 'Make Public' : 'Make Private', style: TextStyle(color: cur ? _ghGreen : _ghOrange, fontWeight: FontWeight.w700)),
        ),
      ],
    ));
    if (ok != true || !mounted) return;
    setState(() => _toggling = true);
    final r = await widget.api.updateVisibility(widget.owner, widget.repo, !cur);
    if (!mounted) return;
    setState(() => _toggling = false);
    if (r['ok'] == true) {
      setState(() => _isPrivate = !cur);
      widget.onVisibilityToggled?.call(!cur);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Repo is now ${!cur ? 'private' : 'public'}'),
        backgroundColor: _ghGreen,
      ));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_prErr(r)), backgroundColor: _ghRed));
    }
  }

  @override
  Widget build(BuildContext context) {
    void push(Widget w) { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => w)); }
    final api = widget.api; final owner = widget.owner; final repo = widget.repo;
    final items = [
      (Icons.account_tree_rounded,              'Branches',        _ghGreen,  () => push(_GhBranchesScreen(api: api, owner: owner, repo: repo))),
      (Icons.history_rounded,                   'Commit History',  _ghBlue,   () => push(_GhCommitsScreen(api: api, owner: owner, repo: repo))),
      (Icons.bar_chart_rounded,                 'Stats & Traffic', _ghPurple, () => push(_GhStatsScreen(api: api, owner: owner, repo: repo))),
      (Icons.star_rounded,                      'Star & Watch',    _ghYellow, () => push(_GhStarWatchScreen(api: api, owner: owner, repo: repo))),
      (Icons.call_merge_rounded,                'Pull Requests',   _ghBlue,   () => push(_GhPRsScreen(api: api, owner: owner, repo: repo))),
      (Icons.bug_report_rounded,                'Issues',          _ghRed,    () => push(_GhIssuesScreen(api: api, owner: owner, repo: repo))),
      (Icons.label_rounded,                     'Releases',        _ghOrange, () => push(_GhReleasesScreen(api: api, owner: owner, repo: repo))),
      (Icons.play_circle_outline_rounded,       'GitHub Actions',  _ghGreen,  () => push(_GhActionsScreen(api: api, owner: owner, repo: repo))),
      (Icons.people_rounded,                    'Collaborators',   _ghPurple, () => push(_GhCollabsScreen(api: api, owner: owner, repo: repo))),
      (Icons.settings_rounded,                  'Settings',        _dimText,  () => push(_GhRepoSettingsScreen(api: api, owner: owner, repo: repo))),
      (Icons.drive_file_rename_outline_rounded, 'Rename Repo',     _ghYellow, () { Navigator.pop(context); _renameRepo(context); }),
      (Icons.delete_rounded,                    'Delete Repo',     _ghRed,    () { Navigator.pop(context); _deleteRepo(context); }),
      (Icons.open_in_browser_rounded,           'Open on GitHub',  _ghBlue,   () { Navigator.pop(context); launchUrl(Uri.parse('https://github.com/$owner/$repo'), mode: LaunchMode.externalApplication); }),
    ];
    return Column(mainAxisSize: MainAxisSize.min, children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 6),
        child: Row(children: [
          Expanded(child: Text('$owner/$repo', style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w700))),
          if (_isPrivate != null)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: (_isPrivate! ? _ghOrange : _ghGreen).withOpacity(0.12),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: (_isPrivate! ? _ghOrange : _ghGreen).withOpacity(0.4)),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(_isPrivate! ? Icons.lock_rounded : Icons.public_rounded, color: _isPrivate! ? _ghOrange : _ghGreen, size: 11),
                const SizedBox(width: 4),
                Text(_isPrivate! ? 'Private' : 'Public',
                  style: TextStyle(color: _isPrivate! ? _ghOrange : _ghGreen, fontSize: 11, fontWeight: FontWeight.w700)),
              ]),
            ),
        ]),
      ),
      if (_isPrivate != null)
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 4, 14, 8),
          child: _toggling
            ? const LinearProgressIndicator(color: _ghBlue, backgroundColor: _border)
            : GestureDetector(
                onTap: _doToggle,
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: (_isPrivate! ? _ghGreen : _ghOrange).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: (_isPrivate! ? _ghGreen : _ghOrange).withOpacity(0.35)),
                  ),
                  child: Row(children: [
                    Icon(_isPrivate! ? Icons.lock_open_rounded : Icons.lock_rounded,
                      color: _isPrivate! ? _ghGreen : _ghOrange, size: 15),
                    const SizedBox(width: 8),
                    Text(_isPrivate! ? 'Make Public' : 'Make Private',
                      style: TextStyle(color: _isPrivate! ? _ghGreen : _ghOrange, fontSize: 13, fontWeight: FontWeight.w700)),
                    const Spacer(),
                    Icon(Icons.swap_horiz_rounded, color: (_isPrivate! ? _ghGreen : _ghOrange).withOpacity(0.6), size: 16),
                  ]),
                ),
              ),
        ),
      const Divider(color: _border, height: 1),
      Flexible(
        child: ListView(
          shrinkWrap: true,
          children: items.map((e) => ListTile(
            leading: Icon(e.$1, color: e.$3, size: 20),
            title: Text(e.$2, style: TextStyle(color: e.$3, fontSize: 13, fontWeight: FontWeight.w600)),
            trailing: const Icon(Icons.chevron_right_rounded, color: _dimText, size: 16),
            onTap: e.$4,
          )).toList(),
        ),
      ),
    ]);
  }

  Future<void> _renameRepo(BuildContext context) async {
    final ctrl = TextEditingController();
    final name = await showDialog<String>(context: context, builder: (_) => _InputDialog(
      title: 'Rename Repository', hint: 'new-repo-name', ctrl: ctrl, confirmLabel: 'Rename',
    ));
    if (name == null || name.trim().isEmpty) return;
    final clean = name.trim().replaceAll(RegExp(r'[^a-zA-Z0-9\-_.]'), '-');
    final r = await widget.api.renameRepo(widget.owner, widget.repo, clean);
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(r['ok'] == true ? 'Repo renamed to $clean' : _prErr(r)),
      backgroundColor: r['ok'] == true ? _ghGreen : _ghRed,
    ));
  }

  Future<void> _deleteRepo(BuildContext context) async {
    final ctrl = TextEditingController();
    final typed = await showDialog<String>(context: context, builder: (_) => _InputDialog(
      title: 'Delete Repository', hint: widget.repo, ctrl: ctrl, confirmLabel: 'Delete',
      subtitle: 'Type "${widget.repo}" to confirm permanent deletion',
      confirmColor: _ghRed,
    ));
    if (typed == null || typed.trim() != widget.repo) {
      if (context.mounted && typed != null) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Name did not match. Deletion cancelled.'), backgroundColor: _ghRed));
      }
      return;
    }
    final r = await widget.api.deleteRepo(widget.owner, widget.repo);
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(r['ok'] == true || r['status'] == 204 ? 'Repository deleted' : _prErr(r)),
      backgroundColor: r['ok'] == true || r['status'] == 204 ? _ghGreen : _ghRed,
    ));
    if (r['ok'] == true || r['status'] == 204) {
      Navigator.pop(context);
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// FILE ACTION SCREEN
// ─────────────────────────────────────────────────────────────────────────────
class _GhFileActionScreen extends StatefulWidget {
  final _GhApi api;
  final String owner, repo, filePath;
  const _GhFileActionScreen({required this.api, required this.owner, required this.repo, required this.filePath});
  @override
  State<_GhFileActionScreen> createState() => _GhFileActionScreenState();
}

class _GhFileActionScreenState extends State<_GhFileActionScreen> {
  Map? _fileData;
  bool _loading = true;
  String? _err;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.getFile(widget.owner, widget.repo, widget.filePath);
    if (!mounted) return;
    if (r['ok'] == true) {
      setState(() { _fileData = r['data']; _loading = false; });
    } else {
      setState(() { _loading = false; _err = _prErr(r); });
    }
  }

  String get _fileName => widget.filePath.split('/').last;

  Future<void> _editContent() async {
    if (_fileData == null) return;
    final original = utf8.decode(base64.decode(_fileData!['content'].toString().replaceAll('\n', '')));
    final ctrl = TextEditingController(text: original);
    final saved = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => _GhFileEditorScreen(
      fileName: _fileName,
      controller: ctrl,
      onSave: (newText, commitMsg) async {
        final b64 = base64.encode(utf8.encode(newText));
        final r = await widget.api.createOrUpdateFile(widget.owner, widget.repo, widget.filePath, {
          'message': commitMsg,
          'content': b64,
          'sha': _fileData!['sha'],
        });
        return r['ok'] == true;
      },
    )));
    if (saved == true && mounted) {
      _toast('File saved ✓');
      _load();
    }
  }

  Future<void> _viewContent() async {
    if (_fileData == null) return;
    final content = utf8.decode(base64.decode(_fileData!['content'].toString().replaceAll('\n', '')));
    final lines = content.split('\n').length;
    final sizeKb = (content.length / 1024).toStringAsFixed(2);
    if (!mounted) return;
    showModalBottomSheet(
      context: context, isScrollControlled: true, backgroundColor: _card,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (_) => DraggableScrollableSheet(
        expand: false, initialChildSize: 0.85, maxChildSize: 0.95, minChildSize: 0.4,
        builder: (_, scrollCtrl) => Column(children: [
          Padding(padding: const EdgeInsets.all(14), child: Column(children: [
            Text(_fileName, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
            Text('$sizeKb KB • $lines lines', style: const TextStyle(color: _dimText, fontSize: 11.5)),
          ])),
          Expanded(child: SingleChildScrollView(
            controller: scrollCtrl,
            padding: const EdgeInsets.all(14),
            child: Text(content, style: const TextStyle(color: Colors.white70, fontSize: 11.5, fontFamily: 'monospace')),
          )),
          Padding(padding: const EdgeInsets.all(10), child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            _GhBtn(label: 'Copy', icon: Icons.copy_rounded, onTap: () {
              Clipboard.setData(ClipboardData(text: content));
              Navigator.pop(context);
            }),
            _GhBtn(label: 'Save', icon: Icons.download_rounded, color: _ghPurple, onTap: () {
              Navigator.pop(context);
              _downloadFile();
            }),
            _GhBtn(label: 'Open in GitHub', icon: Icons.open_in_browser_rounded, color: _ghGreen, onTap: () {
              launchUrl(Uri.parse(_fileData!['html_url'] ?? 'https://github.com/${widget.owner}/${widget.repo}/blob/main/${widget.filePath}'), mode: LaunchMode.externalApplication);
              Navigator.pop(context);
            }),
          ])),
        ]),
      ),
    );
  }

  Future<void> _rename() async {
    if (_fileData == null) return;
    final ctrl = TextEditingController(text: _fileName);
    final newName = await showDialog<String>(context: context, builder: (_) => _InputDialog(
      title: 'Rename File', hint: _fileName, ctrl: ctrl, confirmLabel: 'Rename',
    ));
    if (newName == null || newName.trim().isEmpty || newName.trim() == _fileName) return;
    _showBusy('Renaming...');
    try {
      final content = _fileData!['content'].toString().replaceAll('\n', '');
      final parent = widget.filePath.contains('/') ? widget.filePath.split('/').sublist(0, widget.filePath.split('/').length - 1).join('/') : '';
      final newPath = parent.isEmpty ? newName.trim() : '$parent/${newName.trim()}';
      final cr = await widget.api.createOrUpdateFile(widget.owner, widget.repo, newPath, {
        'message': 'Rename ${widget.filePath} to $newPath',
        'content': content,
      });
      if (cr['ok'] == true) {
        await widget.api.deleteFile(widget.owner, widget.repo, widget.filePath, {
          'message': 'Delete old file ${widget.filePath}',
          'sha': _fileData!['sha'],
        });
      }
      if (!mounted) return;
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(cr['ok'] == true ? 'Renamed to $newPath' : _prErr(cr)),
        backgroundColor: cr['ok'] == true ? _ghGreen : _ghRed,
      ));
      if (cr['ok'] == true) Navigator.pop(context);
    } catch (e) {
      if (mounted) { Navigator.pop(context); _toast(e.toString(), error: true); }
    }
  }

  Future<void> _update() async {
    final res = await FilePicker.platform.pickFiles(allowMultiple: false);
    if (res == null || res.files.isEmpty) return;
    final file = res.files.first;
    if (file.path == null) return;
    if (_fileData == null) return;
    _showBusy('Updating...');
    try {
      final bytes = await File(file.path!).readAsBytes();
      final b64 = base64.encode(bytes);
      final r = await widget.api.createOrUpdateFile(widget.owner, widget.repo, widget.filePath, {
        'message': 'Update ${widget.filePath} via Taurus Shield',
        'content': b64,
        'sha': _fileData!['sha'],
      });
      if (!mounted) return;
      Navigator.pop(context);
      _toast(r['ok'] == true ? 'File updated ✓' : _prErr(r), error: r['ok'] != true);
      if (r['ok'] == true) _load();
    } catch (e) {
      if (mounted) { Navigator.pop(context); _toast(e.toString(), error: true); }
    }
  }

  Future<void> _delete() async {
    if (_fileData == null) return;
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      backgroundColor: _card,
      title: const Text('Delete File?', style: TextStyle(color: Colors.white)),
      content: Text('Delete "${widget.filePath}"?\n\nThis cannot be undone!', style: const TextStyle(color: _dimText)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
        TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete', style: TextStyle(color: _ghRed))),
      ],
    ));
    if (ok != true) return;
    _showBusy('Deleting...');
    final r = await widget.api.deleteFile(widget.owner, widget.repo, widget.filePath, {
      'message': 'Delete ${widget.filePath} via Taurus Shield',
      'sha': _fileData!['sha'],
    });
    if (!mounted) return;
    Navigator.pop(context);
    _toast(r['ok'] == true || r['status'] == 200 ? 'File deleted ✓' : _prErr(r), error: r['ok'] != true && r['status'] != 200);
    if (r['ok'] == true || r['status'] == 200) Navigator.pop(context);
  }

  Future<void> _downloadFile() async {
    if (_fileData == null) return;
    final hasAccess = await PermissionHelper.ensureStorage(context, accent: _ghBlue);
    if (!hasAccess || !mounted) return;
    _showBusy('Saving to device...');
    try {
      final b64 = _fileData!['content'].toString().replaceAll('\n', '');
      final bytes = base64.decode(b64);
      final root  = await StorageHelper.getRootDir();
      final dir   = Directory('$root/${StorageHelper.appFolder}/github');
      await dir.create(recursive: true);
      final path  = '${dir.path}/$_fileName';
      await File(path).writeAsBytes(bytes);
      if (!mounted) return;
      Navigator.pop(context);
      _toast('Saved → Taurus-Shield/github/$_fileName');
    } catch (e) {
      if (mounted) { Navigator.pop(context); _toast('Save failed: $e', error: true); }
    }
  }

  void _showBusy(String msg) {
    showDialog(context: context, barrierDismissible: false, builder: (_) => AlertDialog(
      backgroundColor: _card,
      content: Row(children: [
        const CircularProgressIndicator(color: _ghBlue, strokeWidth: 2),
        const SizedBox(width: 16),
        Expanded(child: Text(msg, style: const TextStyle(color: Colors.white))),
      ]),
    ));
  }

  void _toast(String msg, {bool error = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg), backgroundColor: error ? _ghRed : _ghGreen));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeProvider().current.scaffoldBg,
      appBar: AppBar(
        backgroundColor: const Color(0xFF0d1117),
        title: Text(_fileName, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
      ),
      body: _loading ? const _LoadingView()
          : _err != null ? _ErrView(err: _err!, onRetry: _load)
          : ListView(
              padding: const EdgeInsets.all(14),
              children: [
                _GhCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(_fileName, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 6),
                  _infoRow('Path', '/${widget.filePath}'),
                  _infoRow('Repo', '${widget.owner}/${widget.repo}'),
                  if (_fileData != null) _infoRow('Size', _fmtSize(_fileData!['size'] ?? 0)),
                  if (_fileData != null && _fileData!['sha'] != null)
                    _infoRow('SHA', (_fileData!['sha'] as String).substring(0, 12)),
                ])),
                const SizedBox(height: 8),
                _ActionTile(icon: Icons.visibility_rounded, color: _ghBlue, label: 'View Content', sub: 'Preview file content', onTap: _viewContent),
                _ActionTile(icon: Icons.drive_file_rename_outline_rounded, color: _ghGreen, label: 'Edit & Save', sub: 'Edit content and commit to repo', onTap: _editContent),
                _ActionTile(icon: Icons.download_rounded, color: _ghPurple, label: 'Download to Device', sub: 'Save to Taurus-Shield/github/', onTap: _downloadFile),
                _ActionTile(icon: Icons.open_in_browser_rounded, color: _ghGreen, label: 'Open in GitHub', sub: 'View in browser', onTap: () {
                  launchUrl(Uri.parse('https://github.com/${widget.owner}/${widget.repo}/blob/main/${widget.filePath}'), mode: LaunchMode.externalApplication);
                }),
                _ActionTile(icon: Icons.edit_rounded, color: _ghYellow, label: 'Rename', sub: 'Rename this file', onTap: _rename),
                _ActionTile(icon: Icons.sync_rounded, color: _ghOrange, label: 'Update Content', sub: 'Replace with a file from your device', onTap: _update),
                _ActionTile(icon: Icons.delete_rounded, color: _ghRed, label: 'Delete File', sub: 'Permanently remove from repo', onTap: _delete),
              ],
            ),
    );
  }
}

class _ActionTile extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String label, sub;
  final VoidCallback onTap;
  const _ActionTile({required this.icon, required this.color, required this.label, required this.sub, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(12), border: Border.all(color: _border)),
      child: Row(children: [
        Container(width: 36, height: 36, decoration: BoxDecoration(color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(9)),
          child: Icon(icon, color: color, size: 18)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700)),
          Text(sub, style: const TextStyle(color: _dimText, fontSize: 11.5)),
        ])),
        Icon(Icons.chevron_right_rounded, color: color.withOpacity(0.5), size: 16),
      ]),
    ),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// FILE EDITOR SCREEN
// ─────────────────────────────────────────────────────────────────────────────
class _GhFileEditorScreen extends StatefulWidget {
  final String fileName;
  final TextEditingController controller;
  final Future<bool> Function(String newText, String commitMsg) onSave;
  const _GhFileEditorScreen({required this.fileName, required this.controller, required this.onSave});
  @override
  State<_GhFileEditorScreen> createState() => _GhFileEditorScreenState();
}

class _GhFileEditorScreenState extends State<_GhFileEditorScreen> {
  bool _saving = false;

  Future<void> _save() async {
    final msgCtrl = TextEditingController(text: 'Update ${widget.fileName} via Taurus Shield');
    final commitMsg = await showDialog<String>(context: context, builder: (_) => AlertDialog(
      backgroundColor: _card,
      title: const Text('Commit message', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
      content: TextField(
        controller: msgCtrl,
        style: TextStyle(color: Colors.white, fontSize: 13),
        decoration: InputDecoration(
          hintText: 'Describe your change',
          hintStyle: TextStyle(color: _dimText),
          filled: true,
          fillColor: ThemeProvider().current.scaffoldBg,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: _border)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: _border)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: _ghBlue)),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel', style: TextStyle(color: _dimText))),
        TextButton(onPressed: () => Navigator.pop(context, msgCtrl.text.trim().isEmpty ? 'Update ${widget.fileName} via Taurus Shield' : msgCtrl.text.trim()),
          child: const Text('Save', style: TextStyle(color: _ghGreen, fontWeight: FontWeight.w700))),
      ],
    ));
    if (commitMsg == null || !mounted) return;
    setState(() => _saving = true);
    final ok = await widget.onSave(widget.controller.text, commitMsg);
    if (!mounted) return;
    setState(() => _saving = false);
    if (ok) {
      Navigator.pop(context, true);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Save failed'), backgroundColor: _ghRed));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: ThemeProvider().current.scaffoldBg,
    appBar: AppBar(
      backgroundColor: const Color(0xFF0d1117),
      title: Text(widget.fileName, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
      actions: [
        if (_saving)
          const Padding(padding: EdgeInsets.only(right: 16), child: Center(child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: _ghGreen, strokeWidth: 2))))
        else
          TextButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.check_rounded, color: _ghGreen, size: 18),
            label: const Text('Save', style: TextStyle(color: _ghGreen, fontWeight: FontWeight.w700, fontSize: 13)),
          ),
      ],
    ),
    body: Padding(
      padding: const EdgeInsets.all(12),
      child: TextField(
        controller: widget.controller,
        maxLines: null,
        expands: true,
        keyboardType: TextInputType.multiline,
        textAlignVertical: TextAlignVertical.top,
        style: const TextStyle(color: Colors.white, fontSize: 12.5, fontFamily: 'monospace', height: 1.5),
        decoration: InputDecoration(
          filled: true,
          fillColor: _card,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _border)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _border)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _ghBlue, width: 1.5)),
          contentPadding: const EdgeInsets.all(12),
        ),
      ),
    ),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// BRANCHES SCREEN
// ─────────────────────────────────────────────────────────────────────────────
class _GhBranchesScreen extends StatefulWidget {
  final _GhApi api;
  final String owner, repo;
  const _GhBranchesScreen({required this.api, required this.owner, required this.repo});
  @override
  State<_GhBranchesScreen> createState() => _GhBranchesScreenState();
}

class _GhBranchesScreenState extends State<_GhBranchesScreen> {
  List _branches = [];
  String _default = 'main';
  bool _loading = true;
  String? _err;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final results = await Future.wait([
      widget.api.listBranches(widget.owner, widget.repo),
      widget.api.getRepoStats(widget.owner, widget.repo),
    ]);
    if (!mounted) return;
    if (results[0]['ok'] == true) {
      setState(() {
        _branches = results[0]['data'] is List ? results[0]['data'] : [];
        _default = results[1]['data']?['default_branch'] ?? 'main';
        _loading = false;
      });
    } else {
      setState(() { _loading = false; _err = _prErr(results[0]); });
    }
  }

  Future<void> _createBranch() async {
    if (_branches.isEmpty) return;
    final fromCtrl = TextEditingController();
    final nameCtrl = TextEditingController();

    final source = await showDialog<String>(context: context, builder: (_) => _PickerDialog(
      title: 'Create from branch', options: _branches.map((b) => b['name'] as String).toList(),
    ));
    if (source == null) return;

    final newName = await showDialog<String>(context: context, builder: (_) {
      fromCtrl.clear();
      return _InputDialog(title: 'New branch name', hint: 'feature-xyz', ctrl: fromCtrl, confirmLabel: 'Create',
        subtitle: 'From: $source');
    });
    if (newName == null || newName.trim().isEmpty) return;

    _showBusy('Creating branch...');
    final refResult = await widget.api.getRef(widget.owner, widget.repo, source);
    if (refResult['ok'] != true) {
      if (mounted) { Navigator.pop(context); _toast(_prErr(refResult), error: true); }
      return;
    }
    final sha = refResult['data']?['object']?['sha'];
    final r = await widget.api.createRef(widget.owner, widget.repo, {'ref': 'refs/heads/${newName.trim()}', 'sha': sha});
    if (!mounted) return;
    Navigator.pop(context);
    _toast(r['ok'] == true ? 'Branch ${newName.trim()} created ✓' : _prErr(r), error: r['ok'] != true);
    if (r['ok'] == true) _load();
  }

  Future<void> _setDefault() async {
    final chosen = await showDialog<String>(context: context, builder: (_) => _PickerDialog(
      title: 'Set default branch', options: _branches.map((b) => b['name'] as String).toList(),
    ));
    if (chosen == null) return;
    _showBusy('Updating...');
    final r = await widget.api.setDefaultBranch(widget.owner, widget.repo, chosen);
    if (!mounted) return;
    Navigator.pop(context);
    _toast(r['ok'] == true ? 'Default branch set to $chosen' : _prErr(r), error: r['ok'] != true);
    if (r['ok'] == true) _load();
  }

  Future<void> _deleteBranch() async {
    final deletable = _branches.where((b) => b['name'] != _default).toList();
    if (deletable.isEmpty) { _toast('No branches to delete (cannot delete default)', error: true); return; }
    final chosen = await showDialog<String>(context: context, builder: (_) => _PickerDialog(
      title: 'Delete branch', options: deletable.map((b) => b['name'] as String).toList(),
    ));
    if (chosen == null) return;
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      backgroundColor: _card,
      title: const Text('Delete Branch?', style: TextStyle(color: Colors.white)),
      content: Text('Delete branch "$chosen"?\nThis cannot be undone.', style: const TextStyle(color: _dimText)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
        TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete', style: TextStyle(color: _ghRed))),
      ],
    ));
    if (ok != true) return;
    _showBusy('Deleting...');
    final r = await widget.api.deleteRef(widget.owner, widget.repo, chosen);
    if (!mounted) return;
    Navigator.pop(context);
    _toast(r['ok'] == true || r['status'] == 204 ? 'Branch $chosen deleted' : _prErr(r), error: r['ok'] != true && r['status'] != 204);
    if (r['ok'] == true || r['status'] == 204) _load();
  }

  void _showBusy(String msg) => showDialog(context: context, barrierDismissible: false, builder: (_) => AlertDialog(
    backgroundColor: _card, content: Row(children: [const CircularProgressIndicator(color: _ghBlue, strokeWidth: 2), const SizedBox(width: 16), Text(msg, style: const TextStyle(color: Colors.white))])));

  void _toast(String msg, {bool error = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: error ? _ghRed : _ghGreen));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: ThemeProvider().current.scaffoldBg,
    appBar: AppBar(backgroundColor: const Color(0xFF0d1117), title: Text('Branches · ${widget.repo}', style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
      actions: [IconButton(icon: const Icon(Icons.refresh_rounded, color: _ghBlue, size: 20), onPressed: _load)]),
    body: _loading ? const _LoadingView(msg: 'Loading branches...') : _err != null ? _ErrView(err: _err!, onRetry: _load)
        : Column(children: [
            _GhCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${_branches.length} branches', style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              Text('Default: $_default', style: const TextStyle(color: _ghGreen, fontSize: 12)),
            ])),
            Expanded(child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(14, 6, 14, 80),
              itemCount: _branches.length,
              itemBuilder: (_, i) {
                final b = _branches[i];
                final isDef = b['name'] == _default;
                return Container(
                  margin: const EdgeInsets.only(bottom: 6),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(10), border: Border.all(color: isDef ? _ghGreen.withOpacity(0.4) : _border)),
                  child: Row(children: [
                    const Icon(Icons.account_tree_rounded, size: 14, color: _ghGreen),
                    const SizedBox(width: 10),
                    Expanded(child: Text(b['name'], style: TextStyle(color: isDef ? _ghGreen : Colors.white, fontSize: 13, fontWeight: isDef ? FontWeight.w700 : FontWeight.normal))),
                    if (isDef) Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: _ghGreen.withOpacity(0.15), borderRadius: BorderRadius.circular(4), border: Border.all(color: _ghGreen.withOpacity(0.4))),
                      child: const Text('default', style: TextStyle(color: _ghGreen, fontSize: 10, fontWeight: FontWeight.w700))),
                  ]),
                );
              },
            )),
            Padding(padding: const EdgeInsets.all(14), child: Row(children: [
              Expanded(child: _GhBtn(label: '+ Branch', icon: Icons.add_rounded, color: _ghGreen, onTap: _createBranch)),
              const SizedBox(width: 8),
              Expanded(child: _GhBtn(label: 'Default', icon: Icons.star_rounded, color: _ghYellow, onTap: _setDefault)),
              const SizedBox(width: 8),
              Expanded(child: _GhBtn(label: 'Delete', icon: Icons.delete_rounded, color: _ghRed, onTap: _deleteBranch)),
            ])),
          ]),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// COMMITS SCREEN
// ─────────────────────────────────────────────────────────────────────────────
class _GhCommitsScreen extends StatefulWidget {
  final _GhApi api;
  final String owner, repo;
  const _GhCommitsScreen({required this.api, required this.owner, required this.repo});
  @override
  State<_GhCommitsScreen> createState() => _GhCommitsScreenState();
}

class _GhCommitsScreenState extends State<_GhCommitsScreen> {
  List _commits = [];
  bool _loading = true;
  String? _err;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.listCommits(widget.owner, widget.repo);
    if (!mounted) return;
    if (r['ok'] == true) {
      setState(() { _commits = r['data'] is List ? r['data'] : []; _loading = false; });
    } else {
      setState(() { _loading = false; _err = _prErr(r); });
    }
  }

  Future<void> _compare() async {
    final ctrl = TextEditingController();
    final input = await showDialog<String>(context: context, builder: (_) => _InputDialog(
      title: 'Compare Commits', hint: 'main...develop', ctrl: ctrl,
      subtitle: 'Format: base...head (branches or SHAs)',
      confirmLabel: 'Compare',
    ));
    if (input == null || !input.contains('...')) return;
    final parts = input.split('...');
    if (parts.length != 2) return;
    _showBusy('Comparing...');
    final r = await widget.api.compareCommits(widget.owner, widget.repo, parts[0].trim(), parts[1].trim());
    if (!mounted) return;
    Navigator.pop(context);
    if (r['ok'] == true) {
      final d = r['data'];
      final files = (d['files'] as List? ?? []).take(10);
      final msg = '''Compare: ${parts[0]}...${parts[1]}
Status: ${d['status']}
Ahead by: ${d['ahead_by']}
Behind by: ${d['behind_by']}
Total commits: ${d['total_commits']}

Changed files:
${files.map((f) {
  final s = f['status'];
  final icon = s == 'added' ? '+' : s == 'removed' ? '-' : '~';
  return '$icon ${f['filename']}';
}).join('\n')}
${(d['files'] as List? ?? []).length > 10 ? '...and ${(d['files'] as List).length - 10} more' : ''}''';
      if (!mounted) return;
      showDialog(context: context, builder: (_) => AlertDialog(
        backgroundColor: _card,
        title: const Text('Compare Result', style: TextStyle(color: Colors.white)),
        content: SingleChildScrollView(child: Text(msg, style: const TextStyle(color: Colors.white70, fontSize: 12, fontFamily: 'monospace'))),
        actions: [
          TextButton(onPressed: () { Navigator.pop(context); launchUrl(Uri.parse(d['html_url'] ?? ''), mode: LaunchMode.externalApplication); },
            child: const Text('Open on GitHub', style: TextStyle(color: _ghBlue))),
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close')),
        ],
      ));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_prErr(r)), backgroundColor: _ghRed));
    }
  }

  void _showBusy(String msg) => showDialog(context: context, barrierDismissible: false, builder: (_) => AlertDialog(
    backgroundColor: _card, content: Row(children: [CircularProgressIndicator(color: _ghBlue, strokeWidth: 2), SizedBox(width: 16), Text(msg, style: TextStyle(color: Colors.white))])));

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: ThemeProvider().current.scaffoldBg,
    appBar: AppBar(
      backgroundColor: const Color(0xFF0d1117),
      title: Text('Commits · ${widget.repo}', style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
      actions: [
        IconButton(icon: const Icon(Icons.compare_arrows_rounded, color: _ghPurple, size: 20), tooltip: 'Compare', onPressed: _compare),
        IconButton(icon: const Icon(Icons.refresh_rounded, color: _ghBlue, size: 20), onPressed: _load),
      ],
    ),
    body: _loading ? const _LoadingView(msg: 'Loading commits...') : _err != null ? _ErrView(err: _err!, onRetry: _load)
        : ListView.builder(
            padding: const EdgeInsets.all(14),
            itemCount: _commits.length,
            itemBuilder: (_, i) {
              final c = _commits[i];
              final sha = (c['sha'] as String).substring(0, 7);
              final msg = (c['commit']['message'] as String).split('\n')[0];
              final author = c['commit']['author']['name'] ?? '';
              final date = _fmtDate(c['commit']['author']['date']);
              return Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(10), border: Border.all(color: _border)),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: _ghBlue.withOpacity(0.15), borderRadius: BorderRadius.circular(4), border: Border.all(color: _ghBlue.withOpacity(0.3))),
                      child: Text(sha, style: const TextStyle(color: _ghBlue, fontSize: 11, fontFamily: 'monospace', fontWeight: FontWeight.w700))),
                    const SizedBox(width: 8),
                    Expanded(child: Text(msg, style: const TextStyle(color: Colors.white, fontSize: 12.5, fontWeight: FontWeight.w600), maxLines: 2, overflow: TextOverflow.ellipsis)),
                  ]),
                  const SizedBox(height: 6),
                  Row(children: [
                    const Icon(Icons.person_rounded, color: _dimText, size: 12),
                    const SizedBox(width: 4),
                    Text(author, style: const TextStyle(color: _dimText, fontSize: 11)),
                    const Spacer(),
                    const Icon(Icons.calendar_today_rounded, color: _dimText, size: 11),
                    const SizedBox(width: 3),
                    Text(date, style: const TextStyle(color: _dimText, fontSize: 11)),
                    const SizedBox(width: 8),
                    GestureDetector(
                      onTap: () => launchUrl(Uri.parse('https://github.com/${widget.owner}/${widget.repo}/commit/${c['sha']}'), mode: LaunchMode.externalApplication),
                      child: const Text('View →', style: TextStyle(color: _ghBlue, fontSize: 11)),
                    ),
                  ]),
                ]),
              );
            },
          ),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// STATS SCREEN
// ─────────────────────────────────────────────────────────────────────────────
class _GhStatsScreen extends StatefulWidget {
  final _GhApi api;
  final String owner, repo;
  const _GhStatsScreen({required this.api, required this.owner, required this.repo});
  @override
  State<_GhStatsScreen> createState() => _GhStatsScreenState();
}

class _GhStatsScreenState extends State<_GhStatsScreen> {
  Map? _stats;
  Map? _langs;
  Map? _views;
  Map? _clones;
  bool _loading = true;
  String? _err;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final results = await Future.wait([
      widget.api.getRepoStats(widget.owner, widget.repo),
      widget.api.getLanguages(widget.owner, widget.repo),
      widget.api.getTrafficViews(widget.owner, widget.repo),
      widget.api.getTrafficClones(widget.owner, widget.repo),
    ]);
    if (!mounted) return;
    if (results[0]['ok'] == true) {
      setState(() {
        _stats = results[0]['data'];
        _langs = results[1]['ok'] == true ? results[1]['data'] : {};
        _views = results[2]['ok'] == true ? results[2]['data'] : null;
        _clones = results[3]['ok'] == true ? results[3]['data'] : null;
        _loading = false;
      });
    } else {
      setState(() { _loading = false; _err = _prErr(results[0]); });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: ThemeProvider().current.scaffoldBg,
    appBar: AppBar(backgroundColor: const Color(0xFF0d1117), title: Text('Stats · ${widget.repo}', style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
      actions: [IconButton(icon: const Icon(Icons.refresh_rounded, color: _ghBlue, size: 20), onPressed: _load)]),
    body: _loading ? const _LoadingView(msg: 'Loading stats...') : _err != null ? _ErrView(err: _err!, onRetry: _load)
        : ListView(padding: const EdgeInsets.all(14), children: [
            _GhCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${_stats!['full_name']}', style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w800)),
              if (_stats!['description'] != null && _stats!['description'] != '')
                Padding(padding: const EdgeInsets.only(top: 4), child: Text(_stats!['description'], style: const TextStyle(color: _dimText, fontSize: 12))),
            ])),
            _GhCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Engagement', style: TextStyle(color: _ghPurple, fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 0.8)),
              const SizedBox(height: 8),
              Row(children: [
                _StatChip(Icons.star_rounded,         '${_stats!['stargazers_count']}',  'Stars',    _ghYellow),
                const SizedBox(width: 8),
                _StatChip(Icons.call_split_rounded,   '${_stats!['forks_count']}',        'Forks',    _ghBlue),
                const SizedBox(width: 8),
                _StatChip(Icons.visibility_rounded,   '${_stats!['watchers_count']}',     'Watchers', _ghGreen),
                const SizedBox(width: 8),
                _StatChip(Icons.bug_report_rounded,   '${_stats!['open_issues_count']}',  'Issues',   _ghRed),
              ]),
            ])),
            _GhCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Timeline', style: TextStyle(color: _ghPurple, fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 0.8)),
              const SizedBox(height: 8),
              _infoRow('Created', _fmtDate(_stats!['created_at'])),
              _infoRow('Updated', _fmtDate(_stats!['updated_at'])),
              _infoRow('Pushed', _fmtDate(_stats!['pushed_at'])),
            ])),
            _GhCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Info', style: TextStyle(color: _ghPurple, fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 0.8)),
              const SizedBox(height: 8),
              _infoRow('Visibility', _stats!['private'] == true ? 'Private' : 'Public', valueColor: _stats!['private'] == true ? _ghOrange : _ghGreen),
              _infoRow('Default branch', _stats!['default_branch'] ?? 'main'),
              _infoRow('Size', _fmtSize((_stats!['size'] ?? 0) * 1024)),
              _infoRow('Archived', _stats!['archived'] == true ? 'Yes' : 'No', valueColor: _stats!['archived'] == true ? _ghYellow : null),
            ])),
            if (_langs != null && (_langs as Map).isNotEmpty) _buildLangs(),
            if (_views != null || _clones != null) _buildTraffic(),
            Padding(padding: const EdgeInsets.only(top: 4), child: _GhBtn(
              label: 'Open on GitHub', icon: Icons.open_in_browser_rounded, color: _ghBlue,
              onTap: () => launchUrl(Uri.parse(_stats!['html_url'] ?? ''), mode: LaunchMode.externalApplication),
            )),
          ]),
  );

  Widget _buildLangs() {
    final langs = _langs as Map;
    final total = langs.values.fold<int>(0, (a, b) => a + (b as int));
    return _GhCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Languages', style: TextStyle(color: _ghPurple, fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 0.8)),
      const SizedBox(height: 8),
      ...langs.entries.take(6).map((e) {
        final pct = total > 0 ? (e.value / total * 100).toStringAsFixed(1) : '0';
        return Padding(padding: const EdgeInsets.only(bottom: 4), child: Row(children: [
          Expanded(child: Text('${e.key}', style: const TextStyle(color: Colors.white, fontSize: 12))),
          Text('$pct%', style: const TextStyle(color: _dimText, fontSize: 12)),
          const SizedBox(width: 8),
          SizedBox(width: 80, child: LinearProgressIndicator(
            value: total > 0 ? e.value / total : 0,
            backgroundColor: _border, color: _ghPurple, minHeight: 4,
          )),
        ]));
      }),
    ]));
  }

  Widget _buildTraffic() => _GhCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const Text('Traffic (14 days)', style: TextStyle(color: _ghPurple, fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 0.8)),
    const SizedBox(height: 8),
    if (_views != null) _infoRow('Views', '${_views!['count'] ?? 0} (${_views!['uniques'] ?? 0} unique)', valueColor: _ghBlue),
    if (_clones != null) _infoRow('Clones', '${_clones!['count'] ?? 0} (${_clones!['uniques'] ?? 0} unique)', valueColor: _ghGreen),
  ]));
}

class _StatChip extends StatelessWidget {
  final IconData icon;
  final String value, label;
  final Color color;
  const _StatChip(this.icon, this.value, this.label, this.color);
  @override
  Widget build(BuildContext context) => Expanded(child: Container(
    padding: const EdgeInsets.all(8),
    decoration: BoxDecoration(color: color.withOpacity(0.08), borderRadius: BorderRadius.circular(8), border: Border.all(color: color.withOpacity(0.25))),
    child: Column(children: [
      Icon(icon, size: 16, color: color),
      const SizedBox(height: 2),
      Text(value, style: TextStyle(color: color, fontSize: 13, fontWeight: FontWeight.w800)),
      Text(label, style: const TextStyle(color: _dimText, fontSize: 10)),
    ]),
  ));
}

// ─────────────────────────────────────────────────────────────────────────────
// STAR & WATCH SCREEN
// ─────────────────────────────────────────────────────────────────────────────
class _GhStarWatchScreen extends StatefulWidget {
  final _GhApi api;
  final String owner, repo;
  const _GhStarWatchScreen({required this.api, required this.owner, required this.repo});
  @override
  State<_GhStarWatchScreen> createState() => _GhStarWatchScreenState();
}

class _GhStarWatchScreenState extends State<_GhStarWatchScreen> {
  bool _starred = false, _watching = false;
  Map? _repoData;
  bool _loading = true;
  String? _err;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final results = await Future.wait([
      widget.api.checkStarred(widget.owner, widget.repo),
      widget.api.checkWatch(widget.owner, widget.repo),
      widget.api.getRepoStats(widget.owner, widget.repo),
    ]);
    if (!mounted) return;
    setState(() {
      _starred = results[0]['status'] == 204;
      _watching = results[1]['ok'] == true && results[1]['data']?['subscribed'] == true;
      _repoData = results[2]['data'];
      _loading = false;
    });
  }

  Future<void> _toggleStar() async {
    final r = _starred ? await widget.api.unstarRepo(widget.owner, widget.repo) : await widget.api.starRepo(widget.owner, widget.repo);
    if (!mounted) return;
    if (r['ok'] == true || r['status'] == 204 || r['status'] == 204) {
      setState(() => _starred = !_starred);
      _toast(_starred ? 'Starred ⭐' : 'Unstarred');
    } else {
      _toast(_prErr(r), error: true);
    }
  }

  Future<void> _toggleWatch() async {
    final r = _watching ? await widget.api.unwatchRepo(widget.owner, widget.repo) : await widget.api.watchRepo(widget.owner, widget.repo);
    if (!mounted) return;
    if (r['ok'] == true || r['status'] == 204) {
      setState(() => _watching = !_watching);
      _toast(_watching ? 'Watching 👁️' : 'Unwatched');
    } else {
      _toast(_prErr(r), error: true);
    }
  }

  void _toast(String msg, {bool error = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: error ? _ghRed : _ghGreen));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: ThemeProvider().current.scaffoldBg,
    appBar: AppBar(backgroundColor: const Color(0xFF0d1117), title: Text('Star & Watch · ${widget.repo}', style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
      actions: [IconButton(icon: const Icon(Icons.refresh_rounded, color: _ghBlue, size: 20), onPressed: _load)]),
    body: _loading ? const _LoadingView() : _err != null ? _ErrView(err: _err!, onRetry: _load)
        : ListView(padding: const EdgeInsets.all(14), children: [
            _GhCard(child: Row(children: [
              _StatChip(Icons.star_rounded,       '${_repoData?['stargazers_count'] ?? 0}', 'Stars',    _ghYellow),
              const SizedBox(width: 8),
              _StatChip(Icons.visibility_rounded, '${_repoData?['watchers_count'] ?? 0}',    'Watchers', _ghBlue),
            ])),
            _GhCard(child: Column(children: [
              Row(children: [
                Expanded(child: Text('Your Status', style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700))),
              ]),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: _GhBtn(
                  label: _starred ? 'Unstar' : '⭐ Star',
                  color: _ghYellow,
                  onTap: _toggleStar,
                )),
                const SizedBox(width: 10),
                Expanded(child: _GhBtn(
                  label: _watching ? 'Unwatch' : '👁️ Watch',
                  color: _ghBlue,
                  onTap: _toggleWatch,
                )),
              ]),
              const SizedBox(height: 8),
              Row(children: [
                Icon(_starred ? Icons.star_rounded : Icons.star_border_rounded, color: _ghYellow, size: 14),
                const SizedBox(width: 4),
                Text(_starred ? 'You starred this repo' : 'Not starred', style: const TextStyle(color: _dimText, fontSize: 12)),
                const Spacer(),
                Icon(_watching ? Icons.visibility_rounded : Icons.visibility_off_rounded, color: _ghBlue, size: 14),
                const SizedBox(width: 4),
                Text(_watching ? 'Watching' : 'Not watching', style: const TextStyle(color: _dimText, fontSize: 12)),
              ]),
            ])),
            _GhBtn(label: 'View My Starred Repos', icon: Icons.star_rounded, color: _ghYellow,
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => _GhStarredScreen(api: widget.api)))),
          ]),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// STARRED REPOS SCREEN
// ─────────────────────────────────────────────────────────────────────────────
class _GhStarredScreen extends StatefulWidget {
  final _GhApi api;
  const _GhStarredScreen({required this.api});
  @override
  State<_GhStarredScreen> createState() => _GhStarredScreenState();
}

class _GhStarredScreenState extends State<_GhStarredScreen> {
  List _repos = [];
  bool _loading = true;
  String? _err;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.listStarred();
    if (!mounted) return;
    if (r['ok'] == true) {
      setState(() { _repos = r['data'] is List ? r['data'] : []; _loading = false; });
    } else {
      setState(() { _loading = false; _err = _prErr(r); });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: ThemeProvider().current.scaffoldBg,
    appBar: AppBar(backgroundColor: const Color(0xFF0d1117),
      title: Text('Starred Repos (${_repos.length})', style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
      actions: [IconButton(icon: const Icon(Icons.refresh_rounded, color: _ghBlue, size: 20), onPressed: _load)]),
    body: _loading ? const _LoadingView(msg: 'Loading starred repos...') : _err != null ? _ErrView(err: _err!, onRetry: _load)
        : _repos.isEmpty ? const Center(child: Text('No starred repositories', style: TextStyle(color: _dimText)))
        : ListView.builder(
            padding: const EdgeInsets.all(14),
            itemCount: _repos.length,
            itemBuilder: (_, i) => _RepoCard(repo: _repos[i], onTap: () {
              final r = _repos[i];
              Navigator.push(context, MaterialPageRoute(builder: (_) =>
                _GhRepoBrowserScreen(api: widget.api, owner: r['owner']['login'], repo: r['name'], isPrivate: r['private'] == true)));
            }),
          ),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// PULL REQUESTS SCREEN
// ─────────────────────────────────────────────────────────────────────────────
class _GhPRsScreen extends StatefulWidget {
  final _GhApi api;
  final String owner, repo;
  const _GhPRsScreen({required this.api, required this.owner, required this.repo});
  @override
  State<_GhPRsScreen> createState() => _GhPRsScreenState();
}

class _GhPRsScreenState extends State<_GhPRsScreen> {
  List _prs = [];
  bool _loading = true;
  String? _err;
  String _state = 'open';

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.listPRs(widget.owner, widget.repo, _state);
    if (!mounted) return;
    if (r['ok'] == true) {
      setState(() { _prs = r['data'] is List ? r['data'] : []; _loading = false; });
    } else {
      setState(() { _loading = false; _err = _prErr(r); });
    }
  }

  Future<void> _createPR() async {
    final branchesR = await widget.api.listBranches(widget.owner, widget.repo);
    if (!mounted) return;
    if (branchesR['ok'] != true) { _toast(_prErr(branchesR), error: true); return; }
    final branches = (branchesR['data'] as List).map((b) => b['name'] as String).toList();

    final head = await showDialog<String>(context: context, builder: (_) => _PickerDialog(title: 'Select source branch (head)', options: branches));
    if (head == null) return;
    final base = await showDialog<String>(context: context, builder: (_) => _PickerDialog(title: 'Select target branch (base)', options: branches.where((b) => b != head).toList()));
    if (base == null) return;
    final titleCtrl = TextEditingController();
    final title = await showDialog<String>(context: context, builder: (_) => _InputDialog(title: 'Pull Request Title', hint: 'feat: my awesome feature', ctrl: titleCtrl, confirmLabel: 'Create PR', subtitle: '$head → $base'));
    if (title == null || title.trim().isEmpty) return;

    _showBusy('Creating PR...');
    final r = await widget.api.createPR(widget.owner, widget.repo, {'title': title.trim(), 'head': head, 'base': base});
    if (!mounted) return;
    Navigator.pop(context);
    _toast(r['ok'] == true ? 'PR #${r['data']['number']} created ✓' : _prErr(r), error: r['ok'] != true);
    if (r['ok'] == true) _load();
  }

  void _showBusy(String msg) => showDialog(context: context, barrierDismissible: false, builder: (_) => AlertDialog(
    backgroundColor: _card, content: Row(children: [const CircularProgressIndicator(color: _ghBlue, strokeWidth: 2), const SizedBox(width: 16), Text(msg, style: const TextStyle(color: Colors.white))])));

  void _toast(String msg, {bool error = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: error ? _ghRed : _ghGreen));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: ThemeProvider().current.scaffoldBg,
    appBar: AppBar(
      backgroundColor: const Color(0xFF0d1117),
      title: Text('Pull Requests · ${widget.repo}', style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
      actions: [
        IconButton(icon: Icon(_state == 'open' ? Icons.check_circle_rounded : Icons.history_rounded, color: _ghBlue, size: 20), tooltip: 'Toggle state',
          onPressed: () { setState(() => _state = _state == 'open' ? 'closed' : 'open'); _load(); }),
        IconButton(icon: const Icon(Icons.add_rounded, color: _ghGreen, size: 22), tooltip: 'Create PR', onPressed: _createPR),
        IconButton(icon: const Icon(Icons.refresh_rounded, color: _ghBlue, size: 20), onPressed: _load),
      ],
    ),
    body: _loading ? const _LoadingView(msg: 'Loading pull requests...') : _err != null ? _ErrView(err: _err!, onRetry: _load)
        : _prs.isEmpty ? Center(child: Text('No $_state pull requests', style: const TextStyle(color: _dimText)))
        : ListView.builder(
            padding: const EdgeInsets.all(14),
            itemCount: _prs.length,
            itemBuilder: (_, i) {
              final pr = _prs[i];
              return GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => _GhPRDetailScreen(api: widget.api, owner: widget.owner, repo: widget.repo, prNumber: pr['number']))),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(10), border: Border.all(color: _border)),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Icon(Icons.merge_rounded, color: pr['state'] == 'open' ? _ghGreen : _ghPurple, size: 14),
                      const SizedBox(width: 6),
                      Expanded(child: Text('#${pr['number']} ${pr['title']}', style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600), maxLines: 1, overflow: TextOverflow.ellipsis)),
                    ]),
                    const SizedBox(height: 6),
                    Row(children: [
                      Text('${pr['head']['ref']} → ${pr['base']['ref']}', style: const TextStyle(color: _dimText, fontSize: 11)),
                      const Spacer(),
                      Text('by ${pr['user']['login']}', style: const TextStyle(color: _dimText, fontSize: 11)),
                    ]),
                  ]),
                ),
              );
            },
          ),
  );
}

class _GhPRDetailScreen extends StatefulWidget {
  final _GhApi api;
  final String owner, repo;
  final int prNumber;
  const _GhPRDetailScreen({required this.api, required this.owner, required this.repo, required this.prNumber});
  @override
  State<_GhPRDetailScreen> createState() => _GhPRDetailScreenState();
}

class _GhPRDetailScreenState extends State<_GhPRDetailScreen> {
  Map? _pr;
  bool _loading = true;
  String? _err;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.getPR(widget.owner, widget.repo, widget.prNumber);
    if (!mounted) return;
    if (r['ok'] == true) {
      setState(() { _pr = r['data']; _loading = false; });
    } else {
      setState(() { _loading = false; _err = _prErr(r); });
    }
  }

  Future<void> _merge() async {
    _busy('Merging...');
    final r = await widget.api.mergePR(widget.owner, widget.repo, widget.prNumber);
    if (!mounted) return;
    Navigator.pop(context);
    _toast(r['ok'] == true ? 'PR merged ✓' : _prErr(r), error: r['ok'] != true);
    if (r['ok'] == true) _load();
  }

  Future<void> _close() async {
    _busy('Closing...');
    final r = await widget.api.closePR(widget.owner, widget.repo, widget.prNumber);
    if (!mounted) return;
    Navigator.pop(context);
    _toast(r['ok'] == true ? 'PR closed' : _prErr(r), error: r['ok'] != true);
    if (r['ok'] == true) _load();
  }

  void _busy(String msg) => showDialog(context: context, barrierDismissible: false, builder: (_) => AlertDialog(
    backgroundColor: _card, content: Row(children: [const CircularProgressIndicator(color: _ghBlue, strokeWidth: 2), const SizedBox(width: 16), Text(msg, style: const TextStyle(color: Colors.white))])));

  void _toast(String msg, {bool error = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: error ? _ghRed : _ghGreen));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: ThemeProvider().current.scaffoldBg,
    appBar: AppBar(backgroundColor: const Color(0xFF0d1117), title: Text('PR #${widget.prNumber}', style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700))),
    body: _loading ? const _LoadingView() : _err != null ? _ErrView(err: _err!) : ListView(padding: const EdgeInsets.all(14), children: [
      _GhCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(_pr!['title'], style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        _infoRow('Author', _pr!['user']['login']),
        _infoRow('Branch', '${_pr!['head']['ref']} → ${_pr!['base']['ref']}'),
        _infoRow('State', _pr!['state'], valueColor: _pr!['state'] == 'open' ? _ghGreen : _ghPurple),
        _infoRow('Changes', '+${_pr!['additions']} -${_pr!['deletions']}  (${_pr!['changed_files']} files)', valueColor: _ghGreen),
        if (_pr!['body'] != null && _pr!['body'] != '') ...[
          const SizedBox(height: 8),
          Text(_pr!['body'].toString().substring(0, math.min(300, _pr!['body'].length)), style: const TextStyle(color: _dimText, fontSize: 12)),
        ],
      ])),
      const SizedBox(height: 8),
      if (_pr!['state'] == 'open') ...[
        if (_pr!['mergeable'] != false)
          _ActionTile(icon: Icons.merge_rounded, color: _ghPurple, label: 'Merge PR', sub: 'Merge into ${_pr!['base']['ref']}', onTap: _merge),
        _ActionTile(icon: Icons.close_rounded, color: _ghRed, label: 'Close PR', sub: 'Close without merging', onTap: _close),
      ],
      _ActionTile(icon: Icons.open_in_browser_rounded, color: _ghBlue, label: 'View on GitHub', sub: _pr!['html_url'] ?? '', onTap: () => launchUrl(Uri.parse(_pr!['html_url']), mode: LaunchMode.externalApplication)),
    ]),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// ISSUES SCREEN
// ─────────────────────────────────────────────────────────────────────────────
class _GhIssuesScreen extends StatefulWidget {
  final _GhApi api;
  final String owner, repo;
  const _GhIssuesScreen({required this.api, required this.owner, required this.repo});
  @override
  State<_GhIssuesScreen> createState() => _GhIssuesScreenState();
}

class _GhIssuesScreenState extends State<_GhIssuesScreen> {
  List _issues = [];
  bool _loading = true;
  String? _err;
  String _state = 'open';

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.listIssues(widget.owner, widget.repo, _state);
    if (!mounted) return;
    if (r['ok'] == true) {
      final all = r['data'] is List ? r['data'] : [];
      setState(() { _issues = (all as List).where((i) => i['pull_request'] == null).toList(); _loading = false; });
    } else {
      setState(() { _loading = false; _err = _prErr(r); });
    }
  }

  Future<void> _createIssue() async {
    final ctrl = TextEditingController();
    final title = await showDialog<String>(context: context, builder: (_) => _InputDialog(
      title: 'Create Issue', hint: 'Bug: something is wrong', ctrl: ctrl, confirmLabel: 'Create'));
    if (title == null || title.trim().isEmpty) return;
    _busy('Creating issue...');
    final r = await widget.api.createIssue(widget.owner, widget.repo, title.trim());
    if (!mounted) return;
    Navigator.pop(context);
    _toast(r['ok'] == true ? 'Issue #${r['data']['number']} created ✓' : _prErr(r), error: r['ok'] != true);
    if (r['ok'] == true) _load();
  }

  void _busy(String msg) => showDialog(context: context, barrierDismissible: false, builder: (_) => AlertDialog(
    backgroundColor: _card, content: Row(children: [const CircularProgressIndicator(color: _ghBlue, strokeWidth: 2), const SizedBox(width: 16), Text(msg, style: const TextStyle(color: Colors.white))])));

  void _toast(String msg, {bool error = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: error ? _ghRed : _ghGreen));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: ThemeProvider().current.scaffoldBg,
    appBar: AppBar(
      backgroundColor: const Color(0xFF0d1117),
      title: Text('Issues · ${widget.repo}', style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
      actions: [
        IconButton(icon: Icon(_state == 'open' ? Icons.check_circle_rounded : Icons.history_rounded, color: _ghBlue, size: 20),
          onPressed: () { setState(() => _state = _state == 'open' ? 'closed' : 'open'); _load(); }),
        IconButton(icon: const Icon(Icons.add_rounded, color: _ghGreen, size: 22), onPressed: _createIssue),
        IconButton(icon: const Icon(Icons.refresh_rounded, color: _ghBlue, size: 20), onPressed: _load),
      ],
    ),
    body: _loading ? const _LoadingView(msg: 'Loading issues...') : _err != null ? _ErrView(err: _err!, onRetry: _load)
        : _issues.isEmpty ? Center(child: Text('No $_state issues', style: const TextStyle(color: _dimText)))
        : ListView.builder(
            padding: const EdgeInsets.all(14),
            itemCount: _issues.length,
            itemBuilder: (_, i) {
              final issue = _issues[i];
              return GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => _GhIssueDetailScreen(api: widget.api, owner: widget.owner, repo: widget.repo, issueNumber: issue['number']))),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(10), border: Border.all(color: _border)),
                  child: Row(children: [
                    Icon(Icons.circle_rounded, color: issue['state'] == 'open' ? _ghGreen : _ghRed, size: 10),
                    const SizedBox(width: 10),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('#${issue['number']} ${issue['title']}', style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600), maxLines: 1, overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 3),
                      Row(children: [
                        Text('by ${issue['user']['login']}', style: const TextStyle(color: _dimText, fontSize: 11)),
                        const Spacer(),
                        const Icon(Icons.chat_bubble_rounded, color: _dimText, size: 11),
                        const SizedBox(width: 3),
                        Text('${issue['comments']}', style: const TextStyle(color: _dimText, fontSize: 11)),
                      ]),
                    ])),
                    const Icon(Icons.chevron_right_rounded, color: _dimText, size: 16),
                  ]),
                ),
              );
            },
          ),
  );
}

class _GhIssueDetailScreen extends StatefulWidget {
  final _GhApi api;
  final String owner, repo;
  final int issueNumber;
  const _GhIssueDetailScreen({required this.api, required this.owner, required this.repo, required this.issueNumber});
  @override
  State<_GhIssueDetailScreen> createState() => _GhIssueDetailScreenState();
}

class _GhIssueDetailScreenState extends State<_GhIssueDetailScreen> {
  Map? _issue;
  bool _loading = true;
  String? _err;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.getIssue(widget.owner, widget.repo, widget.issueNumber);
    if (!mounted) return;
    if (r['ok'] == true) { setState(() { _issue = r['data']; _loading = false; }); }
    else { setState(() { _loading = false; _err = _prErr(r); }); }
  }

  Future<void> _toggleState() async {
    final isOpen = _issue!['state'] == 'open';
    _busy(isOpen ? 'Closing...' : 'Reopening...');
    final r = isOpen ? await widget.api.closeIssue(widget.owner, widget.repo, widget.issueNumber) : await widget.api.reopenIssue(widget.owner, widget.repo, widget.issueNumber);
    if (!mounted) return;
    Navigator.pop(context);
    _toast(r['ok'] == true ? (isOpen ? 'Issue closed' : 'Issue reopened') : _prErr(r), error: r['ok'] != true);
    if (r['ok'] == true) _load();
  }

  Future<void> _addComment() async {
    final ctrl = TextEditingController();
    final body = await showDialog<String>(context: context, builder: (_) => _InputDialog(
      title: 'Add Comment', hint: 'Your comment...', ctrl: ctrl, confirmLabel: 'Post', multiline: true));
    if (body == null || body.trim().isEmpty) return;
    _busy('Posting comment...');
    final r = await widget.api.commentIssue(widget.owner, widget.repo, widget.issueNumber, body.trim());
    if (!mounted) return;
    Navigator.pop(context);
    _toast(r['ok'] == true ? 'Comment posted ✓' : _prErr(r), error: r['ok'] != true);
  }

  void _busy(String msg) => showDialog(context: context, barrierDismissible: false, builder: (_) => AlertDialog(
    backgroundColor: _card, content: Row(children: [const CircularProgressIndicator(color: _ghBlue, strokeWidth: 2), const SizedBox(width: 16), Text(msg, style: const TextStyle(color: Colors.white))])));

  void _toast(String msg, {bool error = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: error ? _ghRed : _ghGreen));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: ThemeProvider().current.scaffoldBg,
    appBar: AppBar(backgroundColor: const Color(0xFF0d1117), title: Text('Issue #${widget.issueNumber}', style: const TextStyle(color: Colors.white, fontSize: 14))),
    body: _loading ? const _LoadingView() : _err != null ? _ErrView(err: _err!)
        : ListView(padding: const EdgeInsets.all(14), children: [
            _GhCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Icon(Icons.circle_rounded, color: _issue!['state'] == 'open' ? _ghGreen : _ghRed, size: 10),
                const SizedBox(width: 8),
                Expanded(child: Text('#${_issue!['number']} ${_issue!['title']}', style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w800))),
              ]),
              const SizedBox(height: 8),
              _infoRow('Author', _issue!['user']['login']),
              _infoRow('State', _issue!['state'], valueColor: _issue!['state'] == 'open' ? _ghGreen : _ghRed),
              _infoRow('Comments', '${_issue!['comments']}'),
              if (_issue!['body'] != null && _issue!['body'] != '') ...[
                const SizedBox(height: 8),
                Text(_issue!['body'].toString().substring(0, math.min(400, _issue!['body'].length)), style: const TextStyle(color: _dimText, fontSize: 12)),
              ],
            ])),
            const SizedBox(height: 4),
            _ActionTile(
              icon: _issue!['state'] == 'open' ? Icons.close_rounded : Icons.refresh_rounded,
              color: _issue!['state'] == 'open' ? _ghRed : _ghGreen,
              label: _issue!['state'] == 'open' ? 'Close Issue' : 'Reopen Issue',
              sub: _issue!['state'] == 'open' ? 'Mark as closed' : 'Reopen this issue',
              onTap: _toggleState,
            ),
            _ActionTile(icon: Icons.chat_bubble_rounded, color: _ghBlue, label: 'Add Comment', sub: 'Post a comment', onTap: _addComment),
            _ActionTile(icon: Icons.open_in_browser_rounded, color: _ghBlue, label: 'View on GitHub', sub: _issue!['html_url'] ?? '', onTap: () => launchUrl(Uri.parse(_issue!['html_url']), mode: LaunchMode.externalApplication)),
          ]),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// RELEASES SCREEN
// ─────────────────────────────────────────────────────────────────────────────
class _GhReleasesScreen extends StatefulWidget {
  final _GhApi api;
  final String owner, repo;
  const _GhReleasesScreen({required this.api, required this.owner, required this.repo});
  @override
  State<_GhReleasesScreen> createState() => _GhReleasesScreenState();
}

class _GhReleasesScreenState extends State<_GhReleasesScreen> {
  List _releases = [];
  bool _loading = true;
  String? _err;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.listReleases(widget.owner, widget.repo);
    if (!mounted) return;
    if (r['ok'] == true) { setState(() { _releases = r['data'] is List ? r['data'] : []; _loading = false; }); }
    else { setState(() { _loading = false; _err = _prErr(r); }); }
  }

  Future<void> _createRelease() async {
    final tagCtrl = TextEditingController();
    final tag = await showDialog<String>(context: context, builder: (_) => _InputDialog(title: 'Tag Name', hint: 'v1.0.0', ctrl: tagCtrl, confirmLabel: 'Next'));
    if (tag == null || tag.trim().isEmpty) return;
    final nameCtrl = TextEditingController();
    final name = await showDialog<String>(context: context, builder: (_) => _InputDialog(title: 'Release Name', hint: 'Release v1.0.0', ctrl: nameCtrl, confirmLabel: 'Create', subtitle: 'Tag: ${tag.trim()}'));
    if (name == null) return;
    _busy('Creating release...');
    final r = await widget.api.createRelease(widget.owner, widget.repo, {'tag_name': tag.trim(), 'name': name.trim(), 'draft': false, 'prerelease': false});
    if (!mounted) return;
    Navigator.pop(context);
    _toast(r['ok'] == true ? 'Release ${tag.trim()} created ✓' : _prErr(r), error: r['ok'] != true);
    if (r['ok'] == true) _load();
  }

  void _busy(String msg) => showDialog(context: context, barrierDismissible: false, builder: (_) => AlertDialog(
    backgroundColor: _card, content: Row(children: [const CircularProgressIndicator(color: _ghBlue, strokeWidth: 2), const SizedBox(width: 16), Text(msg, style: const TextStyle(color: Colors.white))])));

  void _toast(String msg, {bool error = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: error ? _ghRed : _ghGreen));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: ThemeProvider().current.scaffoldBg,
    appBar: AppBar(
      backgroundColor: const Color(0xFF0d1117),
      title: Text('Releases · ${widget.repo}', style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
      actions: [
        IconButton(icon: const Icon(Icons.add_rounded, color: _ghGreen, size: 22), onPressed: _createRelease),
        IconButton(icon: const Icon(Icons.refresh_rounded, color: _ghBlue, size: 20), onPressed: _load),
      ],
    ),
    body: _loading ? const _LoadingView(msg: 'Loading releases...') : _err != null ? _ErrView(err: _err!, onRetry: _load)
        : _releases.isEmpty ? const Center(child: Text('No releases yet', style: TextStyle(color: _dimText)))
        : ListView.builder(
            padding: const EdgeInsets.all(14),
            itemCount: _releases.length,
            itemBuilder: (_, i) {
              final rel = _releases[i];
              return GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => _GhReleaseDetailScreen(api: widget.api, owner: widget.owner, repo: widget.repo, releaseId: rel['id']))),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(10), border: Border.all(color: _border)),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      const Icon(Icons.label_rounded, size: 14, color: _ghOrange),
                      const SizedBox(width: 8),
                      Text(rel['tag_name'] ?? '', style: const TextStyle(color: _ghOrange, fontSize: 14, fontWeight: FontWeight.w800)),
                      const SizedBox(width: 8),
                      if (rel['prerelease'] == true)
                        Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2), decoration: BoxDecoration(color: _ghYellow.withOpacity(0.15), borderRadius: BorderRadius.circular(4), border: Border.all(color: _ghYellow.withOpacity(0.4))), child: const Text('pre', style: TextStyle(color: _ghYellow, fontSize: 10))),
                      const Spacer(),
                      Text(_fmtDate(rel['published_at']), style: const TextStyle(color: _dimText, fontSize: 11)),
                    ]),
                    if (rel['name'] != null && rel['name'] != rel['tag_name'])
                      Text(rel['name'], style: const TextStyle(color: _dimText, fontSize: 12)),
                    const SizedBox(height: 4),
                    Text('${(rel['assets'] as List?)?.length ?? 0} assets', style: const TextStyle(color: _dimText, fontSize: 11)),
                  ]),
                ),
              );
            },
          ),
  );
}

class _GhReleaseDetailScreen extends StatefulWidget {
  final _GhApi api;
  final String owner, repo;
  final int releaseId;
  const _GhReleaseDetailScreen({required this.api, required this.owner, required this.repo, required this.releaseId});
  @override
  State<_GhReleaseDetailScreen> createState() => _GhReleaseDetailScreenState();
}

class _GhReleaseDetailScreenState extends State<_GhReleaseDetailScreen> {
  Map? _rel;
  bool _loading = true;
  String? _err;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.getRelease(widget.owner, widget.repo, widget.releaseId);
    if (!mounted) return;
    if (r['ok'] == true) { setState(() { _rel = r['data']; _loading = false; }); }
    else { setState(() { _loading = false; _err = _prErr(r); }); }
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      backgroundColor: _card,
      title: const Text('Delete Release?', style: TextStyle(color: Colors.white)),
      content: const Text('This cannot be undone!', style: TextStyle(color: _dimText)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
        TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete', style: TextStyle(color: _ghRed))),
      ],
    ));
    if (ok != true) return;
    showDialog(context: context, barrierDismissible: false, builder: (_) => const AlertDialog(backgroundColor: _card, content: Row(children: [CircularProgressIndicator(color: _ghBlue, strokeWidth: 2), SizedBox(width: 16), Text('Deleting...', style: TextStyle(color: Colors.white))])));
    final r = await widget.api.deleteRelease(widget.owner, widget.repo, widget.releaseId);
    if (!mounted) return;
    Navigator.pop(context);
    if (r['ok'] == true || r['status'] == 204) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Release deleted'), backgroundColor: _ghGreen));
      Navigator.pop(context);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_prErr(r)), backgroundColor: _ghRed));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: ThemeProvider().current.scaffoldBg,
    appBar: AppBar(backgroundColor: const Color(0xFF0d1117), title: Text(_rel?['tag_name'] ?? 'Release', style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700))),
    body: _loading ? const _LoadingView() : _err != null ? _ErrView(err: _err!)
        : ListView(padding: const EdgeInsets.all(14), children: [
            _GhCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('🏷️ ${_rel!['tag_name']}', style: const TextStyle(color: _ghOrange, fontSize: 16, fontWeight: FontWeight.w800)),
              if (_rel!['name'] != null) Text(_rel!['name'], style: const TextStyle(color: Colors.white, fontSize: 13)),
              const SizedBox(height: 8),
              _infoRow('Published', _fmtDate(_rel!['published_at'])),
              _infoRow('Author', _rel!['author']?['login'] ?? ''),
              if (_rel!['prerelease'] == true) _infoRow('Type', 'Pre-release ⚠️', valueColor: _ghYellow),
              if (_rel!['body'] != null && _rel!['body'] != '') ...[
                const SizedBox(height: 8),
                Text(_rel!['body'].toString().substring(0, math.min(500, _rel!['body'].length)), style: const TextStyle(color: _dimText, fontSize: 12)),
              ],
            ])),
            if ((_rel!['assets'] as List?)?.isNotEmpty == true) ...[
              const SizedBox(height: 4),
              _GhCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Assets (${(_rel!['assets'] as List).length})', style: const TextStyle(color: _ghOrange, fontSize: 13, fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                ...(_rel!['assets'] as List).take(8).map((a) => Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Row(children: [
                    const Icon(Icons.download_rounded, color: _ghGreen, size: 14),
                    const SizedBox(width: 6),
                    Expanded(child: Text(a['name'], style: const TextStyle(color: Colors.white, fontSize: 12))),
                    Text(_fmtSize(a['size'] ?? 0), style: const TextStyle(color: _dimText, fontSize: 11)),
                    const SizedBox(width: 6),
                    GestureDetector(
                      onTap: () => launchUrl(Uri.parse(a['browser_download_url']), mode: LaunchMode.externalApplication),
                      child: const Icon(Icons.download_rounded, color: _ghBlue, size: 16)),
                  ]),
                )),
              ])),
            ],
            const SizedBox(height: 4),
            _ActionTile(icon: Icons.download_rounded, color: _ghGreen, label: 'Download ZIP', sub: 'Download source code', onTap: () => launchUrl(Uri.parse(_rel!['zipball_url']), mode: LaunchMode.externalApplication)),
            _ActionTile(icon: Icons.open_in_browser_rounded, color: _ghBlue, label: 'View on GitHub', sub: _rel!['html_url'] ?? '', onTap: () => launchUrl(Uri.parse(_rel!['html_url']), mode: LaunchMode.externalApplication)),
            _ActionTile(icon: Icons.delete_rounded, color: _ghRed, label: 'Delete Release', sub: 'Permanently remove this release', onTap: _delete),
          ]),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// ACTIONS SCREEN
// ─────────────────────────────────────────────────────────────────────────────
class _GhActionsScreen extends StatefulWidget {
  final _GhApi api;
  final String owner, repo;
  const _GhActionsScreen({required this.api, required this.owner, required this.repo});
  @override
  State<_GhActionsScreen> createState() => _GhActionsScreenState();
}

class _GhActionsScreenState extends State<_GhActionsScreen> {
  List _runs = [];
  bool _loading = true;
  String? _err;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.listWorkflowRuns(widget.owner, widget.repo);
    if (!mounted) return;
    if (r['ok'] == true) {
      setState(() { _runs = List.from(r['data']?['workflow_runs'] ?? []); _loading = false; });
    } else {
      setState(() { _loading = false; _err = _prErr(r); });
    }
  }

  IconData _runIcon(Map run) {
    final c = run['conclusion'];
    final s = run['status'];
    if (c == 'success') return Icons.check_circle_rounded;
    if (c == 'failure') return Icons.cancel_rounded;
    if (s == 'in_progress') return Icons.sync_rounded;
    if (s == 'queued') return Icons.schedule_rounded;
    return Icons.radio_button_unchecked_rounded;
  }

  Color _runColor(Map run) {
    final c = run['conclusion'];
    final s = run['status'];
    if (c == 'success') return _ghGreen;
    if (c == 'failure') return _ghRed;
    if (s == 'in_progress' || s == 'queued') return _ghYellow;
    return _dimText;
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: ThemeProvider().current.scaffoldBg,
    appBar: AppBar(
      backgroundColor: const Color(0xFF0d1117),
      title: Text('Actions · ${widget.repo}', style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
      actions: [
        IconButton(icon: const Icon(Icons.list_alt_rounded, color: _ghPurple, size: 20), tooltip: 'All Workflows', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => _GhWorkflowsScreen(api: widget.api, owner: widget.owner, repo: widget.repo)))),
        IconButton(icon: const Icon(Icons.refresh_rounded, color: _ghBlue, size: 20), onPressed: _load),
      ],
    ),
    body: _loading ? const _LoadingView(msg: 'Loading workflow runs...') : _err != null ? _ErrView(err: _err!, onRetry: _load)
        : _runs.isEmpty ? const Center(child: Text('No workflow runs found', style: TextStyle(color: _dimText)))
        : ListView.builder(
            padding: const EdgeInsets.all(14),
            itemCount: _runs.length,
            itemBuilder: (_, i) {
              final run = _runs[i];
              return GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => _GhRunDetailScreen(api: widget.api, owner: widget.owner, repo: widget.repo, runId: run['id']))),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(10), border: Border.all(color: _runColor(run).withOpacity(0.3))),
                  child: Row(children: [
                    Icon(_runIcon(run), size: 18, color: _runColor(run)),
                    const SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(run['name'] ?? '', style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
                      Text('${run['head_branch']} • ${_fmtDate(run['created_at'])}', style: const TextStyle(color: _dimText, fontSize: 11)),
                    ])),
                    Icon(Icons.chevron_right_rounded, color: _runColor(run), size: 16),
                  ]),
                ),
              );
            },
          ),
  );
}

class _GhRunDetailScreen extends StatefulWidget {
  final _GhApi api;
  final String owner, repo;
  final int runId;
  const _GhRunDetailScreen({required this.api, required this.owner, required this.repo, required this.runId});
  @override
  State<_GhRunDetailScreen> createState() => _GhRunDetailScreenState();
}

class _GhRunDetailScreenState extends State<_GhRunDetailScreen> {
  Map? _run;
  bool _loading = true;
  String? _err;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.getWorkflowRun(widget.owner, widget.repo, widget.runId);
    if (!mounted) return;
    if (r['ok'] == true) { setState(() { _run = r['data']; _loading = false; }); }
    else { setState(() { _loading = false; _err = _prErr(r); }); }
  }

  Future<void> _cancel() async {
    final r = await widget.api.cancelRun(widget.owner, widget.repo, widget.runId);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(r['ok'] == true || r['status'] == 202 ? 'Run cancelled' : _prErr(r)), backgroundColor: r['ok'] == true || r['status'] == 202 ? _ghGreen : _ghRed));
    if (r['ok'] == true || r['status'] == 202) _load();
  }

  Future<void> _rerun() async {
    final r = await widget.api.rerunWorkflow(widget.owner, widget.repo, widget.runId);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(r['ok'] == true || r['status'] == 201 ? 'Re-run started ✓' : _prErr(r)), backgroundColor: r['ok'] == true || r['status'] == 201 ? _ghGreen : _ghRed));
    if (r['ok'] == true || r['status'] == 201) _load();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: ThemeProvider().current.scaffoldBg,
    appBar: AppBar(backgroundColor: const Color(0xFF0d1117), title: const Text('Workflow Run', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700))),
    body: _loading ? const _LoadingView() : _err != null ? _ErrView(err: _err!)
        : ListView(padding: const EdgeInsets.all(14), children: [
            _GhCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(_run!['name'] ?? '', style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              _infoRow('Branch', _run!['head_branch'] ?? ''),
              _infoRow('Status', _run!['status'] ?? '', valueColor: _ghYellow),
              _infoRow('Conclusion', _run!['conclusion'] ?? 'In progress', valueColor: _run!['conclusion'] == 'success' ? _ghGreen : _run!['conclusion'] == 'failure' ? _ghRed : _dimText),
              _infoRow('Started', _fmtDate(_run!['created_at'])),
            ])),
            const SizedBox(height: 4),
            if (_run!['status'] == 'in_progress' || _run!['status'] == 'queued')
              _ActionTile(icon: Icons.cancel_rounded, color: _ghRed, label: 'Cancel Run', sub: 'Stop this workflow run', onTap: _cancel),
            if (_run!['conclusion'] != null)
              _ActionTile(icon: Icons.replay_rounded, color: _ghGreen, label: 'Re-run', sub: 'Start a new run from this workflow', onTap: _rerun),
            _ActionTile(icon: Icons.open_in_browser_rounded, color: _ghBlue, label: 'View Logs on GitHub', sub: _run!['html_url'] ?? '', onTap: () => launchUrl(Uri.parse(_run!['html_url'] ?? ''), mode: LaunchMode.externalApplication)),
          ]),
  );
}

class _GhWorkflowsScreen extends StatefulWidget {
  final _GhApi api;
  final String owner, repo;
  const _GhWorkflowsScreen({required this.api, required this.owner, required this.repo});
  @override
  State<_GhWorkflowsScreen> createState() => _GhWorkflowsScreenState();
}

class _GhWorkflowsScreenState extends State<_GhWorkflowsScreen> {
  List _workflows = [];
  bool _loading = true;
  String? _err;
  String _defaultBranch = 'main';

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final results = await Future.wait([
      widget.api.listWorkflows(widget.owner, widget.repo),
      widget.api.getRepoStats(widget.owner, widget.repo),
    ]);
    if (!mounted) return;
    if (results[0]['ok'] == true) {
      setState(() {
        _workflows = List.from(results[0]['data']?['workflows'] ?? []);
        _defaultBranch = results[1]['data']?['default_branch'] ?? 'main';
        _loading = false;
      });
    } else {
      setState(() { _loading = false; _err = _prErr(results[0]); });
    }
  }

  Future<void> _trigger(int workflowId, String name) async {
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      backgroundColor: _card,
      title: Text('Trigger Workflow?', style: const TextStyle(color: Colors.white)),
      content: Text('Run "$name" on branch $_defaultBranch?', style: const TextStyle(color: _dimText)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
        TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Run', style: TextStyle(color: _ghGreen))),
      ],
    ));
    if (ok != true) return;
    showDialog(context: context, barrierDismissible: false, builder: (_) => const AlertDialog(backgroundColor: _card, content: Row(children: [CircularProgressIndicator(color: _ghBlue, strokeWidth: 2), SizedBox(width: 16), Text('Triggering...', style: TextStyle(color: Colors.white))])));
    final r = await widget.api.triggerWorkflow(widget.owner, widget.repo, workflowId, _defaultBranch);
    if (!mounted) return;
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(r['ok'] == true || r['status'] == 204 ? 'Workflow triggered ✓' : _prErr(r)),
      backgroundColor: r['ok'] == true || r['status'] == 204 ? _ghGreen : _ghRed));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: ThemeProvider().current.scaffoldBg,
    appBar: AppBar(backgroundColor: const Color(0xFF0d1117), title: Text('Workflows · ${widget.repo}', style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
      actions: [IconButton(icon: const Icon(Icons.refresh_rounded, color: _ghBlue, size: 20), onPressed: _load)]),
    body: _loading ? const _LoadingView(msg: 'Loading workflows...') : _err != null ? _ErrView(err: _err!, onRetry: _load)
        : _workflows.isEmpty ? const Center(child: Text('No workflows found', style: TextStyle(color: _dimText)))
        : ListView.builder(
            padding: const EdgeInsets.all(14),
            itemCount: _workflows.length,
            itemBuilder: (_, i) {
              final wf = _workflows[i];
              final active = wf['state'] == 'active';
              return Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(10), border: Border.all(color: _border)),
                child: Row(children: [
                  Icon(Icons.bolt_rounded, color: active ? _ghGreen : _dimText, size: 18),
                  const SizedBox(width: 10),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(wf['name'] ?? '', style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
                    Text(wf['path'] ?? '', style: const TextStyle(color: _dimText, fontSize: 11)),
                  ])),
                  if (active)
                    _GhBtn(label: '▶ Run', color: _ghGreen, onTap: () => _trigger(wf['id'], wf['name'])),
                ]),
              );
            },
          ),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// COLLABORATORS SCREEN
// ─────────────────────────────────────────────────────────────────────────────
class _GhCollabsScreen extends StatefulWidget {
  final _GhApi api;
  final String owner, repo;
  const _GhCollabsScreen({required this.api, required this.owner, required this.repo});
  @override
  State<_GhCollabsScreen> createState() => _GhCollabsScreenState();
}

class _GhCollabsScreenState extends State<_GhCollabsScreen> {
  List _collabs = [];
  bool _loading = true;
  String? _err;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.listCollaborators(widget.owner, widget.repo);
    if (!mounted) return;
    if (r['ok'] == true) { setState(() { _collabs = r['data'] is List ? r['data'] : []; _loading = false; }); }
    else { setState(() { _loading = false; _err = _prErr(r); }); }
  }

  Future<void> _add() async {
    final ctrl = TextEditingController();
    final user = await showDialog<String>(context: context, builder: (_) => _InputDialog(title: 'Add Collaborator', hint: 'github-username', ctrl: ctrl, confirmLabel: 'Invite'));
    if (user == null || user.trim().isEmpty) return;
    showDialog(context: context, barrierDismissible: false, builder: (_) => const AlertDialog(backgroundColor: _card, content: Row(children: [CircularProgressIndicator(color: _ghBlue, strokeWidth: 2), SizedBox(width: 16), Text('Sending invitation...', style: TextStyle(color: Colors.white))])));
    final r = await widget.api.addCollaborator(widget.owner, widget.repo, user.trim());
    if (!mounted) return;
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(r['ok'] == true || r['status'] == 201 ? 'Invitation sent to ${user.trim()} ✓' : _prErr(r)), backgroundColor: r['ok'] == true || r['status'] == 201 ? _ghGreen : _ghRed));
    if (r['ok'] == true || r['status'] == 201) _load();
  }

  Future<void> _remove(String username) async {
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      backgroundColor: _card,
      title: const Text('Remove Collaborator?', style: TextStyle(color: Colors.white)),
      content: Text('Remove @$username from this repo?', style: const TextStyle(color: _dimText)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
        TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Remove', style: TextStyle(color: _ghRed))),
      ],
    ));
    if (ok != true) return;
    showDialog(context: context, barrierDismissible: false, builder: (_) => const AlertDialog(backgroundColor: _card, content: Row(children: [CircularProgressIndicator(color: _ghBlue, strokeWidth: 2), SizedBox(width: 16), Text('Removing...', style: TextStyle(color: Colors.white))])));
    final r = await widget.api.removeCollaborator(widget.owner, widget.repo, username);
    if (!mounted) return;
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(r['ok'] == true || r['status'] == 204 ? '@$username removed' : _prErr(r)), backgroundColor: r['ok'] == true || r['status'] == 204 ? _ghGreen : _ghRed));
    if (r['ok'] == true || r['status'] == 204) _load();
  }

  String _role(Map c) {
    final p = c['permissions'] as Map?;
    if (p?['admin'] == true) return '👑 Admin';
    if (p?['push'] == true) return '✏️ Write';
    return '👁️ Read';
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: ThemeProvider().current.scaffoldBg,
    appBar: AppBar(
      backgroundColor: const Color(0xFF0d1117),
      title: Text('Collaborators · ${widget.repo}', style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
      actions: [
        IconButton(icon: const Icon(Icons.person_add_rounded, color: _ghGreen, size: 20), tooltip: 'Add', onPressed: _add),
        IconButton(icon: const Icon(Icons.refresh_rounded, color: _ghBlue, size: 20), onPressed: _load),
      ],
    ),
    body: _loading ? const _LoadingView(msg: 'Loading collaborators...') : _err != null ? _ErrView(err: _err!, onRetry: _load)
        : _collabs.isEmpty ? const Center(child: Text('No collaborators', style: TextStyle(color: _dimText)))
        : ListView.builder(
            padding: const EdgeInsets.all(14),
            itemCount: _collabs.length,
            itemBuilder: (_, i) {
              final c = _collabs[i];
              final role = _role(c);
              return Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(10), border: Border.all(color: _border)),
                child: Row(children: [
                  CircleAvatar(
                    radius: 18,
                    backgroundColor: _ghBlue.withOpacity(0.2),
                    backgroundImage: c['avatar_url'] != null ? NetworkImage(c['avatar_url']) : null,
                    child: c['avatar_url'] == null ? const Icon(Icons.person_rounded, color: _ghBlue, size: 18) : null,
                  ),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(c['login'] ?? '', style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700)),
                    Text(role, style: const TextStyle(color: _dimText, fontSize: 12)),
                  ])),
                  IconButton(icon: const Icon(Icons.remove_circle_rounded, color: _ghRed, size: 20), onPressed: () => _remove(c['login'])),
                ]),
              );
            },
          ),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// REPO SETTINGS SCREEN
// ─────────────────────────────────────────────────────────────────────────────
class _GhRepoSettingsScreen extends StatefulWidget {
  final _GhApi api;
  final String owner, repo;
  const _GhRepoSettingsScreen({required this.api, required this.owner, required this.repo});
  @override
  State<_GhRepoSettingsScreen> createState() => _GhRepoSettingsScreenState();
}

class _GhRepoSettingsScreenState extends State<_GhRepoSettingsScreen> {
  Map? _repoData;
  bool _loading = true;
  String? _err;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.getRepoStats(widget.owner, widget.repo);
    if (!mounted) return;
    if (r['ok'] == true) { setState(() { _repoData = r['data']; _loading = false; }); }
    else { setState(() { _loading = false; _err = _prErr(r); }); }
  }

  Future<void> _toggleVisibility() async {
    final isPrivate = _repoData!['private'] == true;
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      backgroundColor: _card,
      title: Text('Make ${isPrivate ? 'Public' : 'Private'}?', style: const TextStyle(color: Colors.white)),
      content: Text('This will change visibility to ${isPrivate ? 'public' : 'private'}', style: const TextStyle(color: _dimText)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
        TextButton(onPressed: () => Navigator.pop(context, true), child: Text('Confirm', style: TextStyle(color: isPrivate ? _ghGreen : _ghOrange))),
      ],
    ));
    if (ok != true) return;
    _busy('Updating visibility...');
    final r = await widget.api.updateVisibility(widget.owner, widget.repo, !isPrivate);
    if (!mounted) return;
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(r['ok'] == true ? 'Visibility updated ✓' : _prErr(r)), backgroundColor: r['ok'] == true ? _ghGreen : _ghRed));
    if (r['ok'] == true) _load();
  }

  Future<void> _editDescription() async {
    final ctrl = TextEditingController(text: _repoData!['description'] ?? '');
    final desc = await showDialog<String>(context: context, builder: (_) => _InputDialog(title: 'Edit Description', hint: 'Short description...', ctrl: ctrl, confirmLabel: 'Save', multiline: true));
    if (desc == null) return;
    _busy('Updating description...');
    final r = await widget.api.updateDescription(widget.owner, widget.repo, desc.trim());
    if (!mounted) return;
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(r['ok'] == true ? 'Description updated ✓' : _prErr(r)), backgroundColor: r['ok'] == true ? _ghGreen : _ghRed));
    if (r['ok'] == true) _load();
  }

  Future<void> _toggleArchive() async {
    final isArchived = _repoData!['archived'] == true;
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      backgroundColor: _card,
      title: Text('${isArchived ? 'Unarchive' : 'Archive'} Repository?', style: const TextStyle(color: Colors.white)),
      content: Text(isArchived ? 'This will unarchive the repository.' : 'Archived repos are read-only.', style: const TextStyle(color: _dimText)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
        TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Confirm', style: TextStyle(color: _ghYellow))),
      ],
    ));
    if (ok != true) return;
    _busy(isArchived ? 'Unarchiving...' : 'Archiving...');
    final r = await widget.api.archiveRepo(widget.owner, widget.repo, !isArchived);
    if (!mounted) return;
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(r['ok'] == true ? '${isArchived ? 'Unarchived' : 'Archived'} ✓' : _prErr(r)), backgroundColor: r['ok'] == true ? _ghGreen : _ghRed));
    if (r['ok'] == true) _load();
  }

  void _busy(String msg) => showDialog(context: context, barrierDismissible: false, builder: (_) => AlertDialog(
    backgroundColor: _card, content: Row(children: [CircularProgressIndicator(color: _ghBlue, strokeWidth: 2), SizedBox(width: 16), Text(msg, style: TextStyle(color: Colors.white))])));

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: ThemeProvider().current.scaffoldBg,
    appBar: AppBar(backgroundColor: const Color(0xFF0d1117), title: Text('Settings · ${widget.repo}', style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
      actions: [IconButton(icon: const Icon(Icons.refresh_rounded, color: _ghBlue, size: 20), onPressed: _load)]),
    body: _loading ? const _LoadingView() : _err != null ? _ErrView(err: _err!, onRetry: _load)
        : ListView(padding: const EdgeInsets.all(14), children: [
            _GhCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _infoRow('Description', _repoData!['description'] ?? 'None', valueColor: _repoData!['description'] != null ? Colors.white : _dimText),
              _infoRow('Visibility', _repoData!['private'] == true ? 'Private' : 'Public', valueColor: _repoData!['private'] == true ? _ghOrange : _ghGreen),
              _infoRow('Archived', _repoData!['archived'] == true ? 'Yes' : 'No', valueColor: _repoData!['archived'] == true ? _ghYellow : _dimText),
              _infoRow('Default branch', _repoData!['default_branch'] ?? 'main'),
            ])),
            const SizedBox(height: 4),
            _ActionTile(
              icon: _repoData!['private'] == true ? Icons.lock_open_rounded : Icons.lock_rounded,
              color: _repoData!['private'] == true ? _ghGreen : _ghOrange,
              label: _repoData!['private'] == true ? 'Make Public' : 'Make Private',
              sub: 'Change repository visibility',
              onTap: _toggleVisibility,
            ),
            _ActionTile(icon: Icons.edit_note_rounded, color: _ghBlue, label: 'Edit Description', sub: 'Update repository description', onTap: _editDescription),
            _ActionTile(
              icon: Icons.archive_rounded,
              color: _ghYellow,
              label: _repoData!['archived'] == true ? 'Unarchive' : 'Archive',
              sub: _repoData!['archived'] == true ? 'Unarchive this repository' : 'Make repository read-only',
              onTap: _toggleArchive,
            ),
          ]),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// GISTS SCREEN
// ─────────────────────────────────────────────────────────────────────────────
class _GhGistsScreen extends StatefulWidget {
  final _GhApi api;
  const _GhGistsScreen({required this.api});
  @override
  State<_GhGistsScreen> createState() => _GhGistsScreenState();
}

class _GhGistsScreenState extends State<_GhGistsScreen> {
  List _gists = [];
  bool _loading = true;
  String? _err;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.listGists();
    if (!mounted) return;
    if (r['ok'] == true) { setState(() { _gists = r['data'] is List ? r['data'] : []; _loading = false; }); }
    else { setState(() { _loading = false; _err = _prErr(r); }); }
  }

  Future<void> _create() async {
    final fnCtrl = TextEditingController();
    final filename = await showDialog<String>(context: context, builder: (_) => _InputDialog(title: 'Gist Filename', hint: 'script.js', ctrl: fnCtrl, confirmLabel: 'Next'));
    if (filename == null || filename.trim().isEmpty) return;
    final contentCtrl = TextEditingController();
    final content = await showDialog<String>(context: context, builder: (_) => _InputDialog(title: 'Gist Content', hint: 'Your code here...', ctrl: contentCtrl, confirmLabel: 'Create', multiline: true, subtitle: 'File: ${filename.trim()}'));
    if (content == null || content.trim().isEmpty) return;
    showDialog(context: context, barrierDismissible: false, builder: (_) => const AlertDialog(backgroundColor: _card, content: Row(children: [CircularProgressIndicator(color: _ghBlue, strokeWidth: 2), SizedBox(width: 16), Text('Creating gist...', style: TextStyle(color: Colors.white))])));
    final r = await widget.api.createGist(filename.trim(), content);
    if (!mounted) return;
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(r['ok'] == true ? 'Gist created ✓' : _prErr(r)), backgroundColor: r['ok'] == true ? _ghGreen : _ghRed));
    if (r['ok'] == true) _load();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: ThemeProvider().current.scaffoldBg,
    appBar: AppBar(
      backgroundColor: const Color(0xFF0d1117),
      title: Text('Gists (${_gists.length})', style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
      actions: [
        IconButton(icon: const Icon(Icons.add_rounded, color: _ghGreen, size: 22), onPressed: _create),
        IconButton(icon: const Icon(Icons.refresh_rounded, color: _ghBlue, size: 20), onPressed: _load),
      ],
    ),
    body: _loading ? const _LoadingView(msg: 'Loading gists...') : _err != null ? _ErrView(err: _err!, onRetry: _load)
        : _gists.isEmpty ? const Center(child: Text('No gists yet', style: TextStyle(color: _dimText)))
        : ListView.builder(
            padding: const EdgeInsets.all(14),
            itemCount: _gists.length,
            itemBuilder: (_, i) {
              final g = _gists[i];
              final files = (g['files'] as Map?)?.keys.toList() ?? [];
              final firstName = files.isNotEmpty ? files.first : 'Untitled';
              return GestureDetector(
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => _GhGistDetailScreen(api: widget.api, gistId: g['id']))),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(10), border: Border.all(color: _border)),
                  child: Row(children: [
                    Icon(g['public'] == true ? Icons.public_rounded : Icons.lock_rounded, size: 16, color: g['public'] == true ? _ghGreen : _ghOrange),
                    const SizedBox(width: 10),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(firstName, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700)),
                      if (g['description'] != null && g['description'] != '')
                        Text(g['description'], style: const TextStyle(color: _dimText, fontSize: 11.5), maxLines: 1, overflow: TextOverflow.ellipsis),
                      Text('${files.length} file${files.length == 1 ? '' : 's'} • ${_fmtDate(g['updated_at'])}', style: const TextStyle(color: _dimText, fontSize: 11)),
                    ])),
                    const Icon(Icons.chevron_right_rounded, color: _dimText, size: 16),
                  ]),
                ),
              );
            },
          ),
  );
}

class _GhGistDetailScreen extends StatefulWidget {
  final _GhApi api;
  final String gistId;
  const _GhGistDetailScreen({required this.api, required this.gistId});
  @override
  State<_GhGistDetailScreen> createState() => _GhGistDetailScreenState();
}

class _GhGistDetailScreenState extends State<_GhGistDetailScreen> {
  Map? _gist;
  bool _loading = true;
  String? _err;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.getGist(widget.gistId);
    if (!mounted) return;
    if (r['ok'] == true) { setState(() { _gist = r['data']; _loading = false; }); }
    else { setState(() { _loading = false; _err = _prErr(r); }); }
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      backgroundColor: _card,
      title: const Text('Delete Gist?', style: TextStyle(color: Colors.white)),
      content: const Text('This cannot be undone!', style: TextStyle(color: _dimText)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
        TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete', style: TextStyle(color: _ghRed))),
      ],
    ));
    if (ok != true) return;
    showDialog(context: context, barrierDismissible: false, builder: (_) => const AlertDialog(backgroundColor: _card, content: Row(children: [CircularProgressIndicator(color: _ghBlue, strokeWidth: 2), SizedBox(width: 16), Text('Deleting...', style: TextStyle(color: Colors.white))])));
    final r = await widget.api.deleteGist(widget.gistId);
    if (!mounted) return;
    Navigator.pop(context);
    if (r['ok'] == true || r['status'] == 204) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Gist deleted'), backgroundColor: _ghGreen));
      Navigator.pop(context);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_prErr(r)), backgroundColor: _ghRed));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: ThemeProvider().current.scaffoldBg,
    appBar: AppBar(backgroundColor: const Color(0xFF0d1117), title: const Text('Gist', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700))),
    body: _loading ? const _LoadingView() : _err != null ? _ErrView(err: _err!)
        : ListView(padding: const EdgeInsets.all(14), children: [
            _GhCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Row(children: [
                  Icon(_gist!['public'] == true ? Icons.public_rounded : Icons.lock_rounded, size: 12, color: _gist!['public'] == true ? _ghGreen : _ghOrange),
                  const SizedBox(width: 4),
                  Text(_gist!['public'] == true ? 'Public' : 'Private', style: const TextStyle(color: _dimText, fontSize: 12)),
                ]),
              ]),
              if (_gist!['description'] != null && _gist!['description'] != '') ...[
                const SizedBox(height: 6),
                Text(_gist!['description'], style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
              ],
              const SizedBox(height: 10),
              const Text('Files:', style: TextStyle(color: _ghGreen, fontSize: 12, fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              ...(_gist!['files'] as Map? ?? {}).keys.map((f) => Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Row(children: [
                  Icon(_fileIcon(f), size: 14, color: _dimText),
                  const SizedBox(width: 8),
                  Expanded(child: Text(f, style: const TextStyle(color: Colors.white, fontSize: 13))),
                ]),
              )),
            ])),
            const SizedBox(height: 4),
            _ActionTile(icon: Icons.open_in_browser_rounded, color: _ghBlue, label: 'View on GitHub', sub: _gist!['html_url'] ?? '', onTap: () => launchUrl(Uri.parse(_gist!['html_url']), mode: LaunchMode.externalApplication)),
            _ActionTile(icon: Icons.delete_rounded, color: _ghRed, label: 'Delete Gist', sub: 'Permanently remove this gist', onTap: _delete),
          ]),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MY PROFILE SCREEN
// ─────────────────────────────────────────────────────────────────────────────
class _GhProfileScreen extends StatefulWidget {
  final _GhApi api;
  final Map user;
  const _GhProfileScreen({required this.api, required this.user});
  @override
  State<_GhProfileScreen> createState() => _GhProfileScreenState();
}

class _GhProfileScreenState extends State<_GhProfileScreen> {
  Map _profile = {};
  bool _loading = true;
  String? _err;

  @override
  void initState() { super.initState(); _profile = Map.from(widget.user); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    final r = await widget.api.getUser();
    if (!mounted) return;
    if (r['ok'] == true) {
      setState(() { _profile = Map.from(r['data'] ?? {}); _loading = false; });
    } else {
      setState(() { _loading = false; _err = _prErr(r); });
    }
  }

  String _s(String key) => (_profile[key] ?? '').toString();
  int    _i(String key) => (_profile[key] ?? 0) as int;

  Future<void> _editField(String apiKey, String label, {bool multiline = false}) async {
    final ctrl = TextEditingController(text: _s(apiKey));
    final val = await showDialog<String>(context: context, builder: (_) => _InputDialog(
      title: 'Edit $label', hint: label, ctrl: ctrl, confirmLabel: 'Save', multiline: multiline,
    ));
    if (val == null) return;
    _showBusy('Saving...');
    final r = await widget.api.patchUser({apiKey: val.trim()});
    if (!mounted) return;
    Navigator.pop(context);
    if (r['ok'] == true) {
      setState(() => _profile[apiKey] = val.trim());
      _toast('$label updated ✓');
    } else {
      _toast(_prErr(r), error: true);
    }
  }

  void _showBusy(String msg) => showDialog(
    context: context, barrierDismissible: false,
    builder: (_) => AlertDialog(backgroundColor: _card, content: Row(children: [
      const CircularProgressIndicator(color: _ghBlue, strokeWidth: 2),
      const SizedBox(width: 16),
      Expanded(child: Text(msg, style: const TextStyle(color: Colors.white))),
    ])),
  );

  void _toast(String msg, {bool error = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: error ? _ghRed : _ghGreen));
  }

  Widget _statBox(String label, int value) => Expanded(child: Container(
    padding: EdgeInsets.symmetric(vertical: 12),
    decoration: BoxDecoration(color: ThemeProvider().current.scaffoldBg, borderRadius: BorderRadius.circular(10)),
    child: Column(children: [
      Text('$value', style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
      const SizedBox(height: 2),
      Text(label, style: const TextStyle(color: _dimText, fontSize: 11)),
    ]),
  ));

  Widget _editRow(String label, String value, String apiKey, IconData icon, Color color, {bool multiline = false}) =>
    GestureDetector(
      onTap: () => _editField(apiKey, label, multiline: multiline),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(12), border: Border.all(color: _border)),
        child: Row(children: [
          Container(width: 36, height: 36, decoration: BoxDecoration(color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(9)),
            child: Icon(icon, color: color, size: 18)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: const TextStyle(color: _dimText, fontSize: 11)),
            const SizedBox(height: 2),
            Text(value.isEmpty ? 'Tap to set...' : value,
              style: TextStyle(color: value.isEmpty ? _dimText : Colors.white, fontSize: 13.5, fontWeight: FontWeight.w600)),
          ])),
          const Icon(Icons.edit_rounded, color: _dimText, size: 16),
        ]),
      ),
    );

  @override
  Widget build(BuildContext context) {
    final avatarUrl = _s('avatar_url');
    final login     = _s('login');
    return Scaffold(
      backgroundColor: ThemeProvider().current.scaffoldBg,
      appBar: AppBar(
        backgroundColor: const Color(0xFF0d1117),
        title: const Text('My Profile', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
        actions: [
          IconButton(icon: const Icon(Icons.refresh_rounded, color: _ghBlue, size: 20), onPressed: _load),
          IconButton(
            icon: const Icon(Icons.open_in_browser_rounded, color: _ghGreen, size: 20),
            onPressed: () => launchUrl(Uri.parse('https://github.com/$login'), mode: LaunchMode.externalApplication),
          ),
        ],
      ),
      body: _loading ? const _LoadingView()
          : _err != null ? _ErrView(err: _err!, onRetry: _load)
          : RefreshIndicator(
              color: _ghBlue,
              onRefresh: _load,
              child: ListView(padding: const EdgeInsets.all(14), children: [
                // ── Avatar + identity ──────────────────────────────────────
                _GhCard(child: Column(children: [
                  Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    // Avatar
                    Stack(children: [
                      Container(
                        width: 72, height: 72,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: _ghBlue.withOpacity(0.4), width: 2),
                          color: _border,
                        ),
                        child: ClipOval(
                          child: avatarUrl.isNotEmpty
                              ? Image.network(avatarUrl, fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => const Icon(Icons.person_rounded, color: _dimText, size: 40))
                              : const Icon(Icons.person_rounded, color: _dimText, size: 40),
                        ),
                      ),
                      Positioned(
                        right: 0, bottom: 0,
                        child: GestureDetector(
                          onTap: () => showDialog(context: context, builder: (_) => AlertDialog(
                            backgroundColor: _card,
                            title: const Text('Change Profile Picture', style: TextStyle(color: Colors.white, fontSize: 14)),
                            content: const Text(
                              'GitHub does not allow changing your profile picture via the API.\n\nTo update your avatar, go to github.com → Settings → Profile.',
                              style: TextStyle(color: _dimText, fontSize: 13)),
                            actions: [
                              TextButton(
                                onPressed: () { Navigator.pop(context); launchUrl(Uri.parse('https://github.com/settings/profile'), mode: LaunchMode.externalApplication); },
                                child: const Text('Open GitHub Settings', style: TextStyle(color: _ghBlue)),
                              ),
                              TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
                            ],
                          )),
                          child: Container(
                            width: 22, height: 22,
                            decoration: const BoxDecoration(color: _ghBlue, shape: BoxShape.circle),
                            child: const Icon(Icons.camera_alt_rounded, color: Colors.white, size: 12),
                          ),
                        ),
                      ),
                    ]),
                    const SizedBox(width: 14),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(_s('name').isEmpty ? login : _s('name'),
                        style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 2),
                      Row(children: [
                        const Icon(Icons.alternate_email_rounded, color: _dimText, size: 13),
                        const SizedBox(width: 4),
                        Text(login, style: const TextStyle(color: _dimText, fontSize: 12.5)),
                      ]),
                      if (_s('location').isNotEmpty) ...[
                        const SizedBox(height: 4),
                        Row(children: [
                          const Icon(Icons.location_on_rounded, color: _dimText, size: 13),
                          const SizedBox(width: 4),
                          Text(_s('location'), style: const TextStyle(color: _dimText, fontSize: 12)),
                        ]),
                      ],
                    ])),
                  ]),
                  if (_s('bio').isNotEmpty) ...[
                    const SizedBox(height: 12),
                    Text(_s('bio'), style: const TextStyle(color: Colors.white70, fontSize: 12.5)),
                  ],
                  const SizedBox(height: 14),
                  // ── Stats row ─────────────────────────────────────────────
                  Row(children: [
                    _statBox('Repos', _i('public_repos')),
                    const SizedBox(width: 8),
                    _statBox('Followers', _i('followers')),
                    const SizedBox(width: 8),
                    _statBox('Following', _i('following')),
                  ]),
                  const SizedBox(height: 10),
                  // ── Username note ──────────────────────────────────────────
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: _ghYellow.withOpacity(0.08), borderRadius: BorderRadius.circular(8), border: Border.all(color: _ghYellow.withOpacity(0.2))),
                    child: Row(children: const [
                      Icon(Icons.info_outline_rounded, color: _ghYellow, size: 14),
                      SizedBox(width: 8),
                      Expanded(child: Text('Username (@login) can only be changed on github.com → Settings', style: TextStyle(color: _ghYellow, fontSize: 11.5))),
                    ]),
                  ),
                ])),
                const SizedBox(height: 14),
                // ── Editable fields ───────────────────────────────────────
                const Padding(
                  padding: EdgeInsets.only(left: 4, bottom: 8),
                  child: Text('Edit Profile', style: TextStyle(color: _dimText, fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 0.5)),
                ),
                _editRow('Display Name', _s('name'), 'name', Icons.badge_rounded, _ghBlue),
                _editRow('Bio', _s('bio'), 'bio', Icons.notes_rounded, _ghGreen, multiline: true),
                _editRow('Location', _s('location'), 'location', Icons.location_on_rounded, _ghOrange),
                _editRow('Website', _s('blog'), 'blog', Icons.link_rounded, _ghPurple),
                _editRow('Company', _s('company'), 'company', Icons.business_rounded, _dimText),
                _editRow('Twitter Username', _s('twitter_username'), 'twitter_username', Icons.tag_rounded, const Color(0xFF1DA1F2)),
              ]),
            ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// PUSH NEW PROJECT SCREEN
// ─────────────────────────────────────────────────────────────────────────────
class _GhPushScreen extends StatefulWidget {
  final _GhApi api;
  final String username;
  const _GhPushScreen({required this.api, required this.username});
  @override
  State<_GhPushScreen> createState() => _GhPushScreenState();
}

class _GhPushScreenState extends State<_GhPushScreen> with TickerProviderStateMixin {
  static const _prefKey = 'gh_push_zip_mode';   // 'ask' | 'extract' | 'zip'

  File? _zipFile;
  String _zipName = '';
  bool _pushing = false;
  int _pushed = 0;
  int _total = 0;
  String _statusMsg = '';
  String? _repoUrl;
  int _step = 0;   // 0=idle 1=create 2=read 3=upload 4=finalize
  int _elapsed = 0;
  Timer? _elapsedTimer;
  late AnimationController _spinCtrl;
  late AnimationController _pulseCtrl;
  String _zipMode = 'ask';   // default — always ask

  @override
  void initState() {
    super.initState();
    _spinCtrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400))..repeat(reverse: true);
    _loadMode();
  }

  Future<void> _loadMode() async {
    final p = await SharedPreferences.getInstance();
    if (mounted) setState(() => _zipMode = p.getString(_prefKey) ?? 'ask');
  }

  Future<void> _saveMode(String mode) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_prefKey, mode);
    if (mounted) setState(() => _zipMode = mode);
  }

  @override
  void dispose() {
    _spinCtrl.dispose();
    _pulseCtrl.dispose();
    _elapsedTimer?.cancel();
    super.dispose();
  }

  Future<void> _pickZip() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['zip']);
    if (res == null || res.files.isEmpty || res.files.first.path == null) return;
    setState(() { _zipFile = File(res.files.first.path!); _zipName = res.files.first.name; _repoUrl = null; });
  }

  Future<void> _push() async {
    if (_zipFile == null) { _toast('Select a ZIP file first', error: true); return; }
    final nameCtrl = TextEditingController();
    final repoName = await showDialog<String>(context: context, builder: (_) => _InputDialog(title: 'Repository Name', hint: 'my-project', ctrl: nameCtrl, confirmLabel: 'Next'));
    if (repoName == null || repoName.trim().isEmpty) return;
    final clean = repoName.trim().replaceAll(RegExp(r'[^a-zA-Z0-9\-_.]'), '-');

    final isPrivate = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      backgroundColor: _card,
      title: const Text('Repository Visibility', style: TextStyle(color: Colors.white)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Public', style: TextStyle(color: _ghGreen, fontWeight: FontWeight.w700))),
        TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Private', style: TextStyle(color: _ghOrange, fontWeight: FontWeight.w700))),
      ],
    ));
    if (isPrivate == null) return;

    // ── Resolve ZIP mode ─────────────────────────────────────────────────────
    String resolvedMode = _zipMode;
    if (_zipMode == 'ask') {
      bool remember = false;
      final choice = await showDialog<String>(context: context, builder: (ctx) =>
        StatefulBuilder(builder: (ctx, setSt) => AlertDialog(
          backgroundColor: _card,
          title: const Text('How to push the ZIP?', style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w700)),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('Choose how to upload your project:', style: TextStyle(color: _dimText, fontSize: 13)),
            const SizedBox(height: 14),
            _ZipModeOption(icon: Icons.folder_zip_rounded, color: _ghGreen, title: 'Extract & push files',
              sub: 'Unzip and commit each file individually', onTap: () => Navigator.pop(ctx, 'extract')),
            const SizedBox(height: 8),
            _ZipModeOption(icon: Icons.archive_rounded, color: _ghOrange, title: 'Send ZIP as-is',
              sub: 'Upload the ZIP file as a single file', onTap: () => Navigator.pop(ctx, 'zip')),
            const SizedBox(height: 12),
            GestureDetector(
              onTap: () => setSt(() => remember = !remember),
              child: Row(children: [
                Icon(remember ? Icons.check_box_rounded : Icons.check_box_outline_blank_rounded,
                  color: remember ? _ghBlue : _dimText, size: 20),
                const SizedBox(width: 8),
                const Text('Remember my choice', style: TextStyle(color: _dimText, fontSize: 12.5)),
              ]),
            ),
          ]),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel'))],
        )),
      );
      if (choice == null || !mounted) return;
      resolvedMode = choice;
      if (remember) await _saveMode(choice);
    }

    _elapsed = 0;
    _elapsedTimer?.cancel();
    _elapsedTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _elapsed++);
    });
    setState(() { _pushing = true; _step = 1; _repoUrl = null; _pushed = 0; _total = 0; });

    try {
      final cr = await widget.api.createRepo({'name': clean, 'private': isPrivate, 'auto_init': false});
      if (cr['ok'] != true) throw Exception(_prErr(cr));

      if (mounted) setState(() => _step = 2);
      final bytes = await _zipFile!.readAsBytes();

      if (resolvedMode == 'zip') {
        // ── Upload the whole ZIP as one file ──────────────────────────────
        if (mounted) setState(() { _step = 3; _total = 1; _pushed = 0; });
        final b64 = base64.encode(bytes);
        final r = await widget.api.createOrUpdateFile(widget.username, clean, _zipName, {
          'message': 'Upload $_zipName via Taurus Shield',
          'content': b64,
        });
        if (r['ok'] != true) throw Exception(_prErr(r));
        if (mounted) setState(() => _pushed = 1);
        if (mounted) setState(() => _step = 4);
        await Future.delayed(const Duration(milliseconds: 600));
        _elapsedTimer?.cancel();
        final url = 'https://github.com/${widget.username}/$clean';
        if (mounted) setState(() { _pushing = false; _step = 0; _repoUrl = url; });
        _toast('ZIP uploaded to $clean ✓');
      } else {
        // ── Extract & push each file ──────────────────────────────────────
        final archive = _extractZip(bytes);
        if (archive == null || archive.isEmpty) throw Exception('Could not read ZIP file');
        if (mounted) setState(() { _step = 3; _total = archive.length; _pushed = 0; });
        for (final entry in archive.entries) {
          final b64 = base64.encode(entry.value);
          await widget.api.createOrUpdateFile(widget.username, clean, entry.key, {
            'message': 'Initial commit via Taurus Shield',
            'content': b64,
          });
          if (mounted) setState(() => _pushed++);
        }
        if (mounted) setState(() => _step = 4);
        await Future.delayed(const Duration(milliseconds: 600));
        _elapsedTimer?.cancel();
        final url = 'https://github.com/${widget.username}/$clean';
        if (mounted) setState(() { _pushing = false; _step = 0; _repoUrl = url; });
        _toast('Pushed $_pushed files to $clean ✓');
      }
    } catch (e) {
      _elapsedTimer?.cancel();
      if (mounted) setState(() { _pushing = false; _step = 0; });
      _toast(e.toString(), error: true);
    }
  }

  Map<String, List<int>>? _extractZip(List<int> bytes) {
    try {
      // Simple ZIP extraction without external deps - find file entries
      final result = <String, List<int>>{};
      var i = 0;
      while (i < bytes.length - 4) {
        if (bytes[i] == 0x50 && bytes[i+1] == 0x4B && bytes[i+2] == 0x03 && bytes[i+3] == 0x04) {
          if (i + 30 > bytes.length) break;
          final compression = bytes[i+8] | (bytes[i+9] << 8);
          final compSize = bytes[i+18] | (bytes[i+19] << 8) | (bytes[i+20] << 16) | (bytes[i+21] << 24);
          final uncompSize = bytes[i+22] | (bytes[i+23] << 8) | (bytes[i+24] << 16) | (bytes[i+25] << 24);
          final nameLen = bytes[i+26] | (bytes[i+27] << 8);
          final extraLen = bytes[i+28] | (bytes[i+29] << 8);
          if (i + 30 + nameLen + extraLen + compSize > bytes.length) break;
          final name = utf8.decode(bytes.sublist(i + 30, i + 30 + nameLen), allowMalformed: true);
          final dataStart = i + 30 + nameLen + extraLen;
          if (!name.endsWith('/') && compSize > 0 && !name.contains('node_modules') && !name.contains('/__pycache__/')) {
            final parts = name.split('/');
            final relName = parts.length > 1 ? parts.sublist(1).join('/') : name;
            if (relName.isNotEmpty && !relName.endsWith('/')) {
              final data = bytes.sublist(dataStart, dataStart + (compression == 0 ? uncompSize : compSize));
              if (compression == 0) {
                result[relName] = data;
              } else {
                result[relName] = data;
              }
            }
          }
          i = dataStart + compSize;
        } else { i++; }
      }
      return result.isEmpty ? null : result;
    } catch (_) { return null; }
  }

  void _toast(String msg, {bool error = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: error ? _ghRed : _ghGreen));
  }

  String _fmtElapsed() {
    final m = _elapsed ~/ 60;
    final s = _elapsed % 60;
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  Widget _buildStepRow(int stepNum, String label, String sub) {
    final done    = _step > stepNum;
    final active  = _step == stepNum;
    Color iconBg;
    Widget iconWidget;
    Color textColor;
    if (done) {
      iconBg     = _ghGreen.withOpacity(0.18);
      iconWidget = const Icon(Icons.check_rounded, color: _ghGreen, size: 16);
      textColor  = _ghGreen;
    } else if (active) {
      iconBg     = _ghBlue.withOpacity(0.18);
      iconWidget = RotationTransition(turns: _spinCtrl, child: const Icon(Icons.sync_rounded, color: _ghBlue, size: 16));
      textColor  = Colors.white;
    } else {
      iconBg     = _border;
      iconWidget = Text('$stepNum', style: const TextStyle(color: _dimText, fontSize: 11, fontWeight: FontWeight.w700));
      textColor  = _dimText;
    }
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(children: [
        AnimatedContainer(
          duration: const Duration(milliseconds: 350),
          width: 28, height: 28,
          decoration: BoxDecoration(color: iconBg, shape: BoxShape.circle),
          child: Center(child: iconWidget),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          AnimatedDefaultTextStyle(
            duration: const Duration(milliseconds: 300),
            style: TextStyle(color: textColor, fontSize: 13, fontWeight: active ? FontWeight.w700 : FontWeight.w500),
            child: Text(label),
          ),
          if (active && sub.isNotEmpty)
            Text(sub, style: const TextStyle(color: _dimText, fontSize: 11.5)),
        ])),
        if (done)   const Icon(Icons.check_circle_outline_rounded, color: _ghGreen, size: 15),
        if (!done && !active) const Icon(Icons.radio_button_unchecked_rounded, color: _dimText, size: 15),
      ]),
    );
  }

  Widget _buildPushProgress() {
    final pct    = _total > 0 ? _pushed / _total : 0.0;
    final pctInt = (pct * 100).toInt();
    return AnimatedBuilder(
      animation: _pulseCtrl,
      builder: (_, __) {
        final borderColor = _ghBlue.withOpacity(0.25 + _pulseCtrl.value * 0.30);
        final glowColor   = _ghBlue.withOpacity(0.06 + _pulseCtrl.value * 0.10);
        return Container(
          decoration: BoxDecoration(
            color: _card,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: borderColor, width: 1.5),
            boxShadow: [BoxShadow(color: glowColor, blurRadius: 14, spreadRadius: 3)],
          ),
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            // ── Header ─────────────────────────────────────────────────────
            Row(children: [
              RotationTransition(
                turns: _spinCtrl,
                child: Container(
                  width: 36, height: 36,
                  decoration: BoxDecoration(color: _ghBlue.withOpacity(0.15), shape: BoxShape.circle),
                  child: const Icon(Icons.cloud_upload_rounded, color: _ghBlue, size: 18),
                ),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Text('Pushing to GitHub...', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
              ),
              Text(_fmtElapsed(), style: const TextStyle(color: _dimText, fontSize: 12, fontFamily: 'monospace')),
            ]),
            const Divider(color: _border, height: 20),
            // ── Steps ──────────────────────────────────────────────────────
            _buildStepRow(1, 'Creating repository', ''),
            _buildStepRow(2, 'Reading ZIP', ''),
            _buildStepRow(3, 'Uploading files',
              _total > 0 ? '$_pushed of $_total files  •  $pctInt%' : 'Preparing...'),
            _buildStepRow(4, 'Finalizing', ''),
            // ── Progress bar (upload step only) ────────────────────────────
            if (_step == 3 && _total > 0) ...[
              const SizedBox(height: 14),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text('$_pushed / $_total files', style: const TextStyle(color: _dimText, fontSize: 11.5)),
                Text('$pctInt%', style: const TextStyle(color: _ghBlue, fontSize: 12, fontWeight: FontWeight.w700)),
              ]),
              const SizedBox(height: 6),
              TweenAnimationBuilder<double>(
                duration: const Duration(milliseconds: 350),
                tween: Tween(begin: 0, end: pct),
                builder: (_, v, __) => Stack(children: [
                  Container(height: 8, decoration: BoxDecoration(color: _border, borderRadius: BorderRadius.circular(4))),
                  FractionallySizedBox(
                    widthFactor: v.clamp(0.0, 1.0),
                    child: Container(
                      height: 8,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(colors: [_ghBlue, _ghGreen]),
                        borderRadius: BorderRadius.circular(4),
                        boxShadow: [BoxShadow(color: _ghGreen.withOpacity(0.5), blurRadius: 6)],
                      ),
                    ),
                  ),
                ]),
              ),
            ],
          ]),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: ThemeProvider().current.scaffoldBg,
    appBar: AppBar(backgroundColor: const Color(0xFF0d1117), title: const Text('Push New Project', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700))),
    body: Padding(
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _GhCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Upload a ZIP project to GitHub', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          const Text('What is included:', style: TextStyle(color: _ghGreen, fontSize: 12, fontWeight: FontWeight.w700)),
          const Text('• .github/ workflows, .gitignore, .env files', style: TextStyle(color: _dimText, fontSize: 11.5)),
          const Text('• All source files and hidden dot-files', style: TextStyle(color: _dimText, fontSize: 11.5)),
          const SizedBox(height: 6),
          const Text('What is excluded:', style: TextStyle(color: _ghRed, fontSize: 12, fontWeight: FontWeight.w700)),
          const Text('• node_modules/ and __pycache__/', style: TextStyle(color: _dimText, fontSize: 11.5)),
          const Text('• Max recommended size: 50 MB', style: TextStyle(color: _dimText, fontSize: 11.5)),
        ])),
        const SizedBox(height: 8),
        // ── ZIP mode settings row ─────────────────────────────────────────────
        GestureDetector(
          onTap: _pushing ? null : () async {
            final choice = await showDialog<String>(context: context, builder: (_) => AlertDialog(
              backgroundColor: _card,
              title: const Text('Upload Mode', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
              content: Column(mainAxisSize: MainAxisSize.min, children: [
                _ZipModeOption(icon: Icons.help_outline_rounded, color: _ghBlue, title: 'Always ask me',
                  sub: 'Show a choice dialog each time', onTap: () => Navigator.pop(context, 'ask')),
                const SizedBox(height: 8),
                _ZipModeOption(icon: Icons.folder_zip_rounded, color: _ghGreen, title: 'Always extract files',
                  sub: 'Unzip and commit each file individually', onTap: () => Navigator.pop(context, 'extract')),
                const SizedBox(height: 8),
                _ZipModeOption(icon: Icons.archive_rounded, color: _ghOrange, title: 'Always send ZIP',
                  sub: 'Upload the ZIP file as a single file', onTap: () => Navigator.pop(context, 'zip')),
              ]),
              actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel'))],
            ));
            if (choice != null) _saveMode(choice);
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(10), border: Border.all(color: _border)),
            child: Row(children: [
              Icon(
                _zipMode == 'extract' ? Icons.folder_zip_rounded
                  : _zipMode == 'zip' ? Icons.archive_rounded
                  : Icons.help_outline_rounded,
                color: _zipMode == 'extract' ? _ghGreen : _zipMode == 'zip' ? _ghOrange : _ghBlue,
                size: 16,
              ),
              const SizedBox(width: 8),
              Text(
                'Upload mode: ${_zipMode == 'extract' ? 'Always extract' : _zipMode == 'zip' ? 'Always send ZIP' : 'Ask each time'}',
                style: const TextStyle(color: _dimText, fontSize: 12),
              ),
              const Spacer(),
              const Text('Change', style: TextStyle(color: _ghBlue, fontSize: 12, fontWeight: FontWeight.w600)),
            ]),
          ),
        ),
        const SizedBox(height: 10),
        GestureDetector(
          onTap: _pushing ? null : _pickZip,
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: _card, borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _zipFile != null ? _ghGreen.withOpacity(0.5) : _ghBlue.withOpacity(0.3), width: _zipFile != null ? 1.5 : 1),
            ),
            child: Row(children: [
              Icon(_zipFile != null ? Icons.folder_zip_rounded : Icons.upload_file_rounded,
                color: _zipFile != null ? _ghGreen : _ghBlue, size: 36),
              const SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(_zipFile != null ? _zipName : 'Tap to select ZIP file',
                  style: TextStyle(color: _zipFile != null ? Colors.white : _dimText, fontSize: 14, fontWeight: FontWeight.w700)),
                if (_zipFile != null)
                  Text(_fmtSize(_zipFile!.lengthSync()), style: const TextStyle(color: _dimText, fontSize: 12)),
              ])),
              if (_zipFile != null) const Icon(Icons.check_circle_rounded, color: _ghGreen, size: 20),
            ]),
          ),
        ),
        const SizedBox(height: 12),
        if (_pushing) _buildPushProgress(),
        if (!_pushing && _repoUrl != null) ...[
          _GhCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Row(children: [Icon(Icons.check_circle_rounded, color: _ghGreen, size: 18), SizedBox(width: 8), Text('Pushed Successfully!', style: TextStyle(color: _ghGreen, fontSize: 14, fontWeight: FontWeight.w700))]),
            const SizedBox(height: 8),
            GestureDetector(
              onTap: () => launchUrl(Uri.parse(_repoUrl!), mode: LaunchMode.externalApplication),
              child: Text(_repoUrl!, style: const TextStyle(color: _ghBlue, fontSize: 12.5, decoration: TextDecoration.underline)),
            ),
          ])),
        ],
        const Spacer(),
        SizedBox(width: double.infinity, child: ElevatedButton.icon(
          icon: _pushing
              ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
              : const Icon(Icons.upload_rounded, size: 18),
          label: Text(_pushing ? 'Pushing...' : 'Push to GitHub'),
          style: ElevatedButton.styleFrom(
            backgroundColor: _ghGreen, foregroundColor: Colors.white, disabledBackgroundColor: _ghGreen.withOpacity(0.4),
            padding: const EdgeInsets.symmetric(vertical: 14),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          ),
          onPressed: _pushing || _zipFile == null ? null : _push,
        )),
      ]),
    ),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// ZIP MODE OPTION TILE
// ─────────────────────────────────────────────────────────────────────────────
class _ZipModeOption extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title, sub;
  final VoidCallback onTap;
  const _ZipModeOption({required this.icon, required this.color, required this.title, required this.sub, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: color.withOpacity(0.08), borderRadius: BorderRadius.circular(10), border: Border.all(color: color.withOpacity(0.25))),
      child: Row(children: [
        Container(width: 32, height: 32, decoration: BoxDecoration(color: color.withOpacity(0.15), shape: BoxShape.circle),
          child: Icon(icon, color: color, size: 16)),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700)),
          Text(sub, style: const TextStyle(color: _dimText, fontSize: 11.5)),
        ])),
        Icon(Icons.chevron_right_rounded, color: color, size: 18),
      ]),
    ),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// SHARED DIALOG HELPERS
// ─────────────────────────────────────────────────────────────────────────────
class _InputDialog extends StatelessWidget {
  final String title;
  final String hint;
  final TextEditingController ctrl;
  final String confirmLabel;
  final String? subtitle;
  final Color? confirmColor;
  final bool multiline;

  const _InputDialog({
    required this.title, required this.hint, required this.ctrl,
    required this.confirmLabel, this.subtitle, this.confirmColor, this.multiline = false,
  });

  @override
  Widget build(BuildContext context) => AlertDialog(
    backgroundColor: _card,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: const BorderSide(color: _border)),
    title: Text(title, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w700)),
    content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
      if (subtitle != null) Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(subtitle!, style: const TextStyle(color: _dimText, fontSize: 12))),
      TextField(
        controller: ctrl,
        style: const TextStyle(color: Colors.white, fontSize: 13),
        maxLines: multiline ? 5 : 1,
        decoration: InputDecoration(
          hintText: hint, hintStyle: const TextStyle(color: _dimText),
          filled: true, fillColor: const Color(0xFF161b22),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: _border)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: _border)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: _ghBlue)),
        ),
      ),
    ]),
    actions: [
      TextButton(onPressed: () => Navigator.pop(context, null), child: const Text('Cancel', style: TextStyle(color: _dimText))),
      ElevatedButton(
        style: ElevatedButton.styleFrom(backgroundColor: confirmColor ?? _ghBlue, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
        onPressed: () => Navigator.pop(context, ctrl.text),
        child: Text(confirmLabel),
      ),
    ],
  );
}

class _PickerDialog extends StatelessWidget {
  final String title;
  final List<String> options;
  const _PickerDialog({required this.title, required this.options});

  @override
  Widget build(BuildContext context) => AlertDialog(
    backgroundColor: _card,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: const BorderSide(color: _border)),
    title: Text(title, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w700)),
    content: SizedBox(
      width: double.maxFinite,
      height: math.min(options.length * 48.0, 300),
      child: ListView.builder(
        itemCount: options.length,
        itemBuilder: (_, i) => ListTile(
          dense: true,
          leading: const Icon(Icons.arrow_right_rounded, color: _ghBlue, size: 16),
          title: Text(options[i], style: const TextStyle(color: Colors.white, fontSize: 13)),
          onTap: () => Navigator.pop(context, options[i]),
        ),
      ),
    ),
    actions: [
      TextButton(onPressed: () => Navigator.pop(context, null), child: const Text('Cancel', style: TextStyle(color: _dimText))),
    ],
  );
}
