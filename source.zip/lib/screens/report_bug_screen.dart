import '../utils/theme_provider.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../utils/app_links.dart';

class ReportBugScreen extends StatelessWidget {
  const ReportBugScreen({super.key});

  Future<void> _openBot(BuildContext context) async {
    final uri = Uri.parse(AppLinks.reportBot);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not open Telegram')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      appBar: AppBar(
        
        title: const Text(
          'Report a Bug',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.2,
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        elevation: 0,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            color: ThemeProvider().current.primary.withOpacity(0.25),
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 28, 16, 40),
        children: [
          // Intro
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFFf59e0b).withOpacity(0.07),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                  color: const Color(0xFFf59e0b).withOpacity(0.25)),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Icon(Icons.bug_report_rounded,
                    color: Color(0xFFf59e0b), size: 22),
                SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Found a bug or something not working as expected? '
                    'Send a message to our support bot. Please include your '
                    'file type, Android version, and what happened.',
                    style: TextStyle(
                      color: Color(0xFFd1d5db),
                      fontSize: 13,
                      height: 1.5,
                    ),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 28),

          // Bot card
          Container(
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Color(0xFF12102a),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                  color: ThemeProvider().current.highlightColor.withOpacity(0.30)),
              boxShadow: [
                BoxShadow(
                  color: ThemeProvider().current.highlightColor.withOpacity(0.06),
                  blurRadius: 20,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              children: [
                // Icon
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: ThemeProvider().current.highlightColor.withOpacity(0.10),
                    border: Border.all(
                        color: ThemeProvider().current.highlightColor.withOpacity(0.30)),
                  ),
                  child: Icon(Icons.send_rounded,
                      color: ThemeProvider().current.highlightColor, size: 28),
                ),
                const SizedBox(height: 14),
                const Text(
                  'Taurus Support Bot',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 20),
                // Open button
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () => _openBot(context),
                    icon: const Icon(Icons.open_in_new_rounded, size: 18),
                    label: const Text(
                      'Open in Telegram',
                      style: TextStyle(
                          fontWeight: FontWeight.w700, fontSize: 14),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: ThemeProvider().current.highlightColor,
                      foregroundColor: ThemeProvider().current.appBarBg,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 28),

          // Tips
          const _SectionLabel(label: 'TIPS FOR A GOOD BUG REPORT'),
          const SizedBox(height: 10),
          const _TipRow(
              icon: Icons.attach_file_rounded,
              text: 'Mention the file type (.bundle, .hbc, .hasm, .zip)'),
          const _TipRow(
              icon: Icons.phone_android_rounded,
              text: 'Include your Android version and device model'),
          const _TipRow(
              icon: Icons.article_outlined,
              text: 'Copy and paste the log output from the processing panel'),
          const _TipRow(
              icon: Icons.repeat_rounded,
              text: 'Tell us if it happens every time or only sometimes'),
        ],
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String label;
  const _SectionLabel({required this.label});

  @override
  Widget build(BuildContext context) {
    return Text(
      label,
      style: const TextStyle(
        color: Color(0xFF6b7280),
        fontSize: 10,
        fontWeight: FontWeight.w700,
        letterSpacing: 1.5,
      ),
    );
  }
}

class _TipRow extends StatelessWidget {
  final IconData icon;
  final String text;
  const _TipRow({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: ThemeProvider().current.primary, size: 16),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(
                color: Color(0xFF9ca3af),
                fontSize: 13,
                height: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
