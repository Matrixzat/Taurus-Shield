import '../utils/theme_provider.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../utils/hbc_channel.dart';
import '../utils/search_history.dart';

// ─────────────────────────────────────────────────────────────────────────────
//  AsmEditorTab — embedded in the Blutter screen PageView (page 2)
// ─────────────────────────────────────────────────────────────────────────────
class AsmEditorTab extends StatefulWidget {
  final String outputDir;
  final String? libappSoPath;
  final void Function(bool isFullScreen, VoidCallback exitFn)? onFullScreenChanged;
  /// Called once after init; the parent stores the returned handler
  /// and calls it on system-back. Returns true if this widget consumed the back.
  final void Function(bool Function() handler)? onRegisterBackHandler;

  const AsmEditorTab({
    super.key,
    required this.outputDir,
    required this.libappSoPath,
    this.onFullScreenChanged,
    this.onRegisterBackHandler,
  });

  @override
  State<AsmEditorTab> createState() => _AsmEditorTabState();
}

class _AsmEditorTabState extends State<AsmEditorTab> {
  // ── Init state ─────────────────────────────────────────────────────────────
  bool   _initializing = false;
  String? _editRootDir;
  String? _initError;

  // ── Navigation stack: list of dir paths ───────────────────────────────────
  final List<String> _dirStack = [];
  List<Map<String, dynamic>> _entries = [];
  bool _loadingDir = false;

  // ── File editor ───────────────────────────────────────────────────────────
  String? _openFilePath;        // path in asm_edit/
  String? _openFileOrigPath;    // same relative path in asm/
  List<String> _origLines  = [];
  List<String> _editLines  = [];
  final Set<int> _changedIdx = {};
  bool  _saving        = false;
  bool  _reverting     = false;

  // edit inline
  int?   _editingLineIdx;
  bool   _inlineEditMode = false;   // true = tap-to-edit inline; false = bottom-sheet editor
  final TextEditingController _lineCtrl = TextEditingController();
  final ScrollController      _editorScroll = ScrollController();

  // ── Global search ─────────────────────────────────────────────────────────
  bool   _searchMode       = false;
  bool   _searching        = false;
  bool   _openedFromSearch = false;   // true when file was opened from search results
  int    _searchProgress   = 0;       // files scanned so far (streaming progress)
  final TextEditingController _searchCtrl = TextEditingController();
  List<Map<String, dynamic>> _searchHits  = [];

  // ── In-file keyword highlight (opened from search) ─────────────────────
  String? _inFileKeyword;
  List<int> _matchLines = [];
  int _matchIdx = 0;

  // ── Editor display settings ───────────────────────────────────────────────
  double _fontSize     = 11.0;
  double _baseFontSize = 11.0;
  bool   _wordWrap     = false;
  String _syntaxMode   = 'Text';
  int    _pointerCount = 0;
  bool   _fullScreen        = false;
  int    _lastScalePtCount  = 0;

  void _setFullScreen(bool value) {
    setState(() => _fullScreen = value);
    widget.onFullScreenChanged?.call(value, () => _setFullScreen(false));
    if (value) {
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    } else {
      SystemChrome.setEnabledSystemUIMode(
        SystemUiMode.manual,
        overlays: SystemUiOverlay.values,
      );
    }
  }

  // ── Find/Replace bar ──────────────────────────────────────────────────────
  bool   _findBarOpen      = false;
  bool   _replaceVisible   = false;
  bool   _searchRegex      = false;
  bool   _searchWholeWords = false;
  bool   _searchMatchCase  = false;
  final TextEditingController _findCtrl    = TextEditingController();
  final TextEditingController _replaceCtrl = TextEditingController();

  // ── Patch result banner ───────────────────────────────────────────────────
  String? _patchBanner;
  Timer?  _bannerTimer;

  // ── Jump-to-line highlight ─────────────────────────────────────────────────
  int?   _jumpedLine;
  Timer? _jumpTimer;

  // ── Horizontal pan (no-wrap mode) ─────────────────────────────────────────
  final ValueNotifier<double> _hOffsetNotifier = ValueNotifier(0.0);
  static const double _kHMaxOffset = 1600.0;

  // ── Find history ──────────────────────────────────────────────────────────
  late FocusNode    _findFocusNode;
  List<String>      _findHistory      = [];
  bool              _showFindHistory  = false;

  // ─────────────────────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    _initEdit();
    _findCtrl.addListener(_runFindSearch);
    // Register back-press handler with parent (blutter_screen)
    widget.onRegisterBackHandler?.call(_handleBack);

    _findFocusNode = FocusNode();
    _findFocusNode.addListener(() async {
      if (_findFocusNode.hasFocus) {
        final hist = await SearchHistory.load(SearchHistory.keyAsmFind);
        if (mounted) setState(() { _findHistory = hist; _showFindHistory = true; });
      } else {
        Future.delayed(const Duration(milliseconds: 200), () {
          if (mounted && !_findFocusNode.hasFocus) {
            setState(() => _showFindHistory = false);
          }
        });
      }
    });
  }

  @override
  void didUpdateWidget(AsmEditorTab old) {
    super.didUpdateWidget(old);
    if (old.outputDir != widget.outputDir) {
      _editRootDir = null;
      _initError   = null;
      _dirStack.clear();
      _entries = [];
      _closeFile();
      _initEdit();
    }
  }

  @override
  void dispose() {
    _findCtrl.removeListener(_runFindSearch);
    _findCtrl.dispose();
    _replaceCtrl.dispose();
    _lineCtrl.dispose();
    _editorScroll.dispose();
    _searchCtrl.dispose();
    _bannerTimer?.cancel();
    _jumpTimer?.cancel();
    _hOffsetNotifier.dispose();
    _findFocusNode.dispose();
    super.dispose();
  }

  // ── Initialise edit copy ───────────────────────────────────────────────────
  Future<void> _initEdit() async {
    setState(() { _initializing = true; _initError = null; });
    try {
      final path = await HbcChannel.asmInitEdit(outputDir: widget.outputDir);
      if (path == null) throw Exception('Could not create edit copy');
      setState(() {
        _editRootDir = path;
        _initializing = false;
      });
      // Start navigation at the root output folder, not directly inside asm_edit
      await _loadDir(widget.outputDir);
    } catch (e) {
      setState(() { _initError = e.toString(); _initializing = false; });
    }
  }

  // ── Directory navigation ───────────────────────────────────────────────────
  Future<void> _loadDir(String path) async {
    setState(() { _loadingDir = true; });
    try {
      final entries = await HbcChannel.asmListDir(dir: path);
      setState(() { _entries = entries; _loadingDir = false; });
    } catch (e) {
      setState(() { _loadingDir = false; });
      _showSnack('Error: $e');
    }
  }

  void _pushDir(String path) {
    _dirStack.add(path);
    _closeFile();
    setState(() { _searchMode = false; });
    _loadDir(path);
  }

  void _popDir() {
    if (_dirStack.isEmpty) return;
    _dirStack.removeLast();
    _closeFile();
    final target = _dirStack.isEmpty ? widget.outputDir : _dirStack.last;
    _loadDir(target);
  }

  String get _currentDir => _dirStack.isEmpty ? widget.outputDir : _dirStack.last;

  // ── File open / close ──────────────────────────────────────────────────────
  Future<void> _openFile(Map<String, dynamic> entry) async {
    final editPath = entry['path'] as String;
    // Only allow editing if file is inside asm_edit — otherwise read-only
    final isEditable = _editRootDir != null && editPath.startsWith(_editRootDir!);
    final origPath = isEditable
        ? '${widget.outputDir}/asm${editPath.replaceFirst(_editRootDir!, '')}'
        : null;

    setState(() { _saving = false; _reverting = false; });
    try {
      final text = await HbcChannel.asmReadFile(path: editPath);
      if (text == null) { _showSnack('Cannot read file'); return; }
      final lines = text.split('\n');
      setState(() {
        _openFilePath     = editPath;
        _openFileOrigPath = origPath;
        _origLines        = List.from(lines);
        _editLines        = List.from(lines);
        _changedIdx.clear();
        _editingLineIdx   = null;
        _searchMode       = false;
      });
    } catch (e) {
      _showSnack('Error: $e');
    }
  }

  void _closeFile() {
    setState(() {
      _openFilePath     = null;
      _openFileOrigPath = null;
      _origLines        = [];
      _editLines        = [];
      _changedIdx.clear();
      _editingLineIdx   = null;
      _inFileKeyword    = null;
      _matchLines       = [];
      _matchIdx         = 0;
      _findBarOpen      = false;
      _replaceVisible   = false;
    });
    if (_fullScreen) _setFullScreen(false);
    _findCtrl.clear();
    _replaceCtrl.clear();
  }

  /// Back button pressed while a file is open.
  /// If the file was opened from search results, returns to those results.
  /// Otherwise falls through to the directory tree.
  void _backFromFile() {
    final fromSearch = _openedFromSearch;
    _closeFile();
    if (fromSearch) {
      setState(() {
        _openedFromSearch = false;
        _searchMode       = true;   // re-show search results
      });
    } else {
      setState(() { _openedFromSearch = false; });
    }
  }

  /// System-back handler registered with blutter_screen.
  /// Steps back through editor state; returns true if handled, false if
  /// the parent should pop the route.
  bool _handleBack() {
    // 1. Close find bar
    if (_findBarOpen) {
      setState(() => _findBarOpen = false);
      return true;
    }
    // 2. Commit any open inline edit then close file (no dialog)
    if (_openFilePath != null) {
      if (_editingLineIdx != null) _commitLineEdit(_editingLineIdx!);
      _backFromFile();
      return true;
    }
    // 3. Dismiss global search results
    if (_searchMode) {
      setState(() => _searchMode = false);
      return true;
    }
    // 4. Navigate up one directory level
    if (_dirStack.isNotEmpty) {
      _popDir();
      return true;
    }
    // Nothing left to step back from — let parent pop the route
    return false;
  }

  // ── Open file with in-file keyword highlight (from global search) ──────────
  Future<void> _openFileWithKeyword(Map<String, dynamic> entry, String keyword) async {
    await _openFile(entry);
    if (keyword.isEmpty || _editLines.isEmpty) return;
    // Open find bar with keyword pre-filled
    _findCtrl.text = keyword;
    setState(() { _findBarOpen = true; });
  }

  void _scrollToMatch(int idx) {
    if (idx >= _matchLines.length) return;
    if (!_editorScroll.hasClients) return;
    final lineIdx = _matchLines[idx];
    final viewH   = _editorScroll.position.viewportDimension;
    final double offset;
    if (!_wordWrap) {
      // itemExtent is set on the ListView — exact pixel position
      final lineH = _fontSize + 10.0;
      offset = (lineIdx * lineH) - (viewH / 2) + (lineH / 2);
    } else {
      // Variable-height lines: proportional position through document
      final total = _editorScroll.position.maxScrollExtent + viewH;
      offset = (total * lineIdx / _editLines.length.clamp(1, 1 << 20)) - (viewH / 2);
    }
    _editorScroll.animateTo(
      offset.clamp(0.0, _editorScroll.position.maxScrollExtent),
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOut,
    );
  }

  void _navigateMatch(int delta) {
    if (_matchLines.isEmpty) return;
    final kw = _findCtrl.text.trim();
    if (kw.isNotEmpty) SearchHistory.add(SearchHistory.keyAsmFind, kw);
    final newIdx = (_matchIdx + delta).clamp(0, _matchLines.length - 1);
    setState(() => _matchIdx = newIdx);
    // Fire AFTER the rebuild so the highlight + scroll are in sync
    WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToMatch(newIdx));
  }

  // ── Line editing ──────────────────────────────────────────────────────────
  void _startEditLine(int idx) {
    // Commit any previously open inline edit first
    if (_editingLineIdx != null && _editingLineIdx != idx) {
      _commitLineEdit(_editingLineIdx!);
    }
    // Prep the controller so inline mode has the right text ready
    _lineCtrl.text = _editLines[idx];
    setState(() => _editingLineIdx = idx);

    // ── Inline mode: just show the TextField directly in the list ──
    if (_inlineEditMode) return;

    // ── Sheet mode (default) ───────────────────────────────────────
    final origLine = (_origLines.isNotEmpty && idx < _origLines.length)
        ? _origLines[idx]
        : _editLines[idx];

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Padding(
        // Keep the sheet above the keyboard
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: _LineEditSheet(
          lineNumber: idx + 1,
          originalLine: origLine,
          initialText: _editLines[idx],
          onSave: (newText) {
            if (mounted) {
              setState(() {
                _editLines[idx] = newText;
                if (newText == _origLines[idx]) {
                  _changedIdx.remove(idx);
                } else {
                  _changedIdx.add(idx);
                }
                _editingLineIdx = null;
              });
            }
            Navigator.pop(ctx);
          },
          onCancel: () => Navigator.pop(ctx),
        ),
      ),
    ).whenComplete(() {
      if (mounted && _editingLineIdx == idx) {
        setState(() => _editingLineIdx = null);
      }
    });
  }

  void _commitLineEdit(int idx) {
    final newVal = _lineCtrl.text;
    setState(() {
      _editLines[idx] = newVal;
      if (newVal == _origLines[idx]) {
        _changedIdx.remove(idx);
      } else {
        _changedIdx.add(idx);
      }
      _editingLineIdx = null;
    });
  }

  void _cancelLineEdit() {
    setState(() { _editingLineIdx = null; });
  }

  // ── Save & Patch ───────────────────────────────────────────────────────────
  Future<void> _saveAndPatch() async {
    if (_openFilePath == null || widget.libappSoPath == null) {
      _showSnack('No file open or no libapp.so selected');
      return;
    }
    // Commit any in-progress inline line edit first
    if (_editingLineIdx != null) _commitLineEdit(_editingLineIdx!);
    if (_changedIdx.isEmpty) {
      _showSnack('No changes to save');
      return;
    }
    setState(() { _saving = true; });
    try {
      final result = await HbcChannel.asmSaveAndPatch(
        editPath:  _openFilePath!,
        soPath:    widget.libappSoPath!,
        origLines: _origLines,
        newLines:  _editLines,
      );
      final patched = result['patchCount'] as int? ?? 0;
      final errors  = result['errorCount'] as int? ?? 0;
      // Refresh origLines so future saves are relative to new content
      setState(() {
        _origLines = List.from(_editLines);
        _changedIdx.clear();
        _saving = false;
      });
      _showBanner(
        errors == 0
          ? '$patched instruction${patched == 1 ? '' : 's'} patched to libapp.so'
          : '$patched patched, $errors failed — tap for details',
        isError: errors > 0,
      );
      if (errors > 0) _showPatchDetails(result);
    } catch (e) {
      setState(() { _saving = false; });
      _showSnack('Patch error: $e', isError: true);
    }
  }

  // ── Revert — choice dialog ─────────────────────────────────────────────────
  void _showRevertChoice() {
    if (_openFilePath == null) return;
    if (_changedIdx.isEmpty) { _showSnack('No changes to revert'); return; }

    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF1e293b),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const SizedBox(height: 8),
          Container(width: 36, height: 4, decoration: BoxDecoration(
              color: Colors.white24, borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 16),
          const Text('Revert Changes',
              style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text('${_changedIdx.length} line${_changedIdx.length == 1 ? '' : 's'} modified',
              style: TextStyle(color: Colors.white38, fontSize: 12)),
          SizedBox(height: 16),
          Divider(height: 1, color: Color(0xFF334155)),
          // Option 1 – specific line
          ListTile(
            leading: Icon(Icons.undo_rounded, color: ThemeProvider().current.highlightColor),
            title: const Text('Revert a specific line',
                style: TextStyle(color: Colors.white, fontSize: 14)),
            subtitle: const Text('Choose one changed line to restore',
                style: TextStyle(color: Colors.white38, fontSize: 11)),
            onTap: () { Navigator.pop(ctx); _showRevertLinePicker(); },
          ),
          const Divider(height: 1, color: Color(0xFF334155)),
          // Option 2 – whole file
          ListTile(
            leading: const Icon(Icons.restore_page_rounded, color: Color(0xFFef4444)),
            title: const Text('Revert entire file',
                style: TextStyle(color: Color(0xFFef4444), fontSize: 14)),
            subtitle: const Text('Restore all lines to the original copy',
                style: TextStyle(color: Colors.white38, fontSize: 11)),
            onTap: () { Navigator.pop(ctx); _revertWholeFile(); },
          ),
          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  // ── Revert single line picker ──────────────────────────────────────────────
  void _showRevertLinePicker() {
    final sorted = _changedIdx.toList()..sort();
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1e293b),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Pick a Line to Revert',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        contentPadding: const EdgeInsets.fromLTRB(0, 12, 0, 0),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: sorted.length,
            itemBuilder: (_, i) {
              final idx = sorted[i];
              final orig = idx < _origLines.length ? _origLines[idx] : '';
              final curr = idx < _editLines.length ? _editLines[idx] : '';
              return InkWell(
                onTap: () {
                  Navigator.pop(ctx);
                  _revertSingleLine(idx);
                },
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                      border: Border(bottom: BorderSide(color: Color(0xFF334155)))),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Icon(Icons.undo_rounded, color: ThemeProvider().current.highlightColor, size: 13),
                      SizedBox(width: 6),
                      Text('Line ${idx + 1}',
                          style: TextStyle(color: ThemeProvider().current.highlightColor, fontSize: 12,
                              fontWeight: FontWeight.bold)),
                    ]),
                    const SizedBox(height: 4),
                    // Current (what they changed it to)
                    Text('Now:  ${curr.trim()}',
                        style: const TextStyle(color: Color(0xFFfbbf24), fontSize: 10,
                            fontFamily: 'monospace'),
                        maxLines: 1, overflow: TextOverflow.ellipsis),
                    // Original
                    Text('Was:  ${orig.trim()}',
                        style: const TextStyle(color: Colors.white54, fontSize: 10,
                            fontFamily: 'monospace'),
                        maxLines: 1, overflow: TextOverflow.ellipsis),
                  ]),
                ),
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text('Cancel', style: TextStyle(color: Colors.white.withOpacity(0.5))),
          ),
        ],
      ),
    );
  }

  // ── Revert a single line in memory (no file I/O needed) ───────────────────
  void _revertSingleLine(int idx) {
    if (idx >= _origLines.length) return;
    setState(() {
      _editLines[idx] = _origLines[idx];
      _changedIdx.remove(idx);
      if (_editingLineIdx == idx) _editingLineIdx = null;
    });
    _showBanner('Line ${idx + 1} reverted');
  }

  // ── Revert entire file via Kotlin (copies original over edit copy) ─────────
  Future<void> _revertWholeFile() async {
    if (_openFilePath == null || _openFileOrigPath == null) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1e293b),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Revert Entire File',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        content: const Text(
          'Restore all lines to the original copy?\n\nNote: This does NOT undo patches already written to libapp.so.',
          style: TextStyle(color: Colors.white70, fontSize: 13),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false),
              child: Text('Cancel', style: TextStyle(color: Colors.white.withOpacity(0.5)))),
          TextButton(onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Revert All', style: TextStyle(
                  color: Color(0xFFef4444), fontWeight: FontWeight.bold))),
        ],
      ),
    );
    if (confirmed != true) return;
    setState(() { _reverting = true; });
    try {
      final text = await HbcChannel.asmRevertFile(
        editPath: _openFilePath!,
        origPath: _openFileOrigPath!,
      );
      if (text == null) throw Exception('Revert returned null');
      final lines = text.split('\n');
      setState(() {
        _origLines = List.from(lines);
        _editLines = List.from(lines);
        _changedIdx.clear();
        _editingLineIdx = null;
        _reverting = false;
      });
      _showBanner('Entire file reverted to original');
    } catch (e) {
      setState(() { _reverting = false; });
      _showSnack('Revert error: $e', isError: true);
    }
  }

  // ── Copy to clipboard ──────────────────────────────────────────────────────
  void _copyFile() {
    Clipboard.setData(ClipboardData(text: _editLines.join('\n')));
    _showSnack('File content copied to clipboard');
  }

  void _copyLine(int idx) {
    Clipboard.setData(ClipboardData(text: _editLines[idx]));
    _showSnack('Line copied');
  }

  // ── Search ─────────────────────────────────────────────────────────────────
  Future<void> _runSearch() async {
    final kw = _searchCtrl.text.trim();
    if (kw.isEmpty || _editRootDir == null) return;
    setState(() { _searching = true; _searchHits = []; _openedFromSearch = false; });
    try {
      final hits = await HbcChannel.asmSearchAll(rootDir: _editRootDir!, keyword: kw);
      setState(() { _searchHits = hits; _searching = false; });
    } catch (e) {
      setState(() { _searching = false; });
      _showSnack('Search error: $e');
    }
  }

  // ── UI helpers ─────────────────────────────────────────────────────────────
  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(color: Colors.white, fontSize: 13)),
      backgroundColor: isError ? const Color(0xFFef4444) : const Color(0xFF1e293b),
      behavior: SnackBarBehavior.floating,
      duration: const Duration(seconds: 3),
    ));
  }

  void _showBanner(String msg, {bool isError = false}) {
    _bannerTimer?.cancel();
    setState(() { _patchBanner = msg; });
    _bannerTimer = Timer(const Duration(seconds: 4), () {
      if (mounted) setState(() { _patchBanner = null; });
    });
  }

  void _showPatchDetails(Map<String, dynamic> result) {
    final results = result['results'] as List? ?? [];
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1e293b),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Patch Details', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView(shrinkWrap: true, children: results.map<Widget>((r) {
            final ok  = r['success'] == true;
            final off = r['offset'] ?? '';
            final err = r['error'] ?? '';
            final to  = r['to'] ?? '';
            return Padding(
              padding: EdgeInsets.symmetric(vertical: 4),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Icon(ok ? Icons.check_circle_rounded : Icons.error_rounded,
                    color: ok ? ThemeProvider().current.highlightColor : Color(0xFFef4444), size: 16),
                const SizedBox(width: 8),
                Expanded(child: Text(
                  ok ? '$off → $to' : err,
                  style: TextStyle(color: ok ? Colors.white : Colors.white70, fontSize: 11, fontFamily: 'monospace'),
                )),
              ]),
            );
          }).toList()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx),
              child: Text('OK', style: TextStyle(color: ThemeProvider().current.highlightColor))),
        ],
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    if (_initializing) return _buildLoading('Preparing edit copy…');
    if (_initError != null) return _buildError(_initError!);

    if (_openFilePath != null) return _buildFileEditor();
    if (_searchMode)           return _buildSearchView();
    return _buildFileTree();
  }

  // ── Loading / Error ────────────────────────────────────────────────────────
  Widget _buildLoading(String msg) => Center(child: Column(
    mainAxisSize: MainAxisSize.min, children: [
      CircularProgressIndicator(color: ThemeProvider().current.highlightColor, strokeWidth: 2),
      const SizedBox(height: 14),
      Text(msg, style: const TextStyle(color: Colors.white54, fontSize: 13)),
    ],
  ));

  Widget _buildError(String msg) => Center(child: Padding(
    padding: const EdgeInsets.all(24),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(Icons.error_outline_rounded, color: Color(0xFFef4444), size: 40),
      SizedBox(height: 12),
      Text(msg, style: TextStyle(color: Colors.white70, fontSize: 13), textAlign: TextAlign.center),
      SizedBox(height: 16),
      ElevatedButton(onPressed: _initEdit,
          style: ElevatedButton.styleFrom(backgroundColor: ThemeProvider().current.highlightColor),
          child: const Text('Retry', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold))),
    ]),
  ));

  // ── File tree ──────────────────────────────────────────────────────────────
  Widget _buildFileTree() {
    final isRoot = _dirStack.isEmpty;
    final String dirName;
    if (isRoot) {
      dirName = widget.outputDir.split('/').last;
    } else if (_editRootDir != null && _dirStack.last == _editRootDir) {
      dirName = 'asm (edit copy)';
    } else {
      dirName = _dirStack.last.split('/').last;
    }
    return Column(children: [
      // ── Toolbar ──
      Container(
        color: const Color(0xFF0f172a),
        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: Row(children: [
          if (!isRoot)
            GestureDetector(
              onTap: _popDir,
              child: Icon(Icons.arrow_back_ios_new_rounded, color: ThemeProvider().current.highlightColor, size: 18),
            ),
          if (!isRoot) SizedBox(width: 8),
          Icon(Icons.folder_open_rounded, color: ThemeProvider().current.highlightColor, size: 16),
          const SizedBox(width: 6),
          Expanded(child: Text(dirName,
              style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600),
              overflow: TextOverflow.ellipsis)),
          IconButton(
            icon: const Icon(Icons.search_rounded, color: Colors.white54, size: 20),
            onPressed: () => setState(() { _searchMode = true; }),
            tooltip: 'Search all files',
            padding: EdgeInsets.zero, constraints: const BoxConstraints(),
          ),
        ]),
      ),
      Divider(height: 1, color: Color(0xFF1e293b)),
      // ── Entries ──
      Expanded(child: _loadingDir
          ? Center(child: CircularProgressIndicator(color: ThemeProvider().current.highlightColor, strokeWidth: 2))
          : _entries.isEmpty
              ? const Center(child: Text('Empty folder', style: TextStyle(color: Colors.white38)))
              : ListView.builder(
                  itemCount: _entries.length,
                  itemBuilder: (ctx, i) {
                    final e = _entries[i];
                    final isDir = e['isDir'] as bool? ?? false;
                    return _FileEntryTile(
                      entry: e,
                      onTap: () => isDir ? _pushDir(e['path'] as String) : _openFile(e),
                    );
                  },
                )),
    ]);
  }

  // ── Search view ────────────────────────────────────────────────────────────
  Widget _buildSearchView() {
    // Group hits by filePath
    final Map<String, List<Map<String, dynamic>>> grouped = {};
    for (final h in _searchHits) {
      final fp = h['filePath'] as String? ?? '';
      grouped.putIfAbsent(fp, () => []).add(h);
    }
    final files = grouped.keys.toList();

    return Column(children: [
      // ── Search bar ──
      Container(
        color: Color(0xFF0f172a),
        padding: EdgeInsets.fromLTRB(12, 8, 12, 8),
        child: Row(children: [
          GestureDetector(
            onTap: () => setState(() { _searchMode = false; _searchHits = []; }),
            child: Icon(Icons.arrow_back_ios_new_rounded, color: ThemeProvider().current.highlightColor, size: 18),
          ),
          const SizedBox(width: 8),
          Expanded(child: TextField(
            controller: _searchCtrl,
            autofocus: true,
            style: const TextStyle(color: Colors.white, fontSize: 13),
            decoration: InputDecoration(
              hintText: 'Search keyword in all files…',
              hintStyle: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 13),
              border: InputBorder.none,
            ),
            onSubmitted: (_) => _runSearch(),
          )),
          if (_searching)
            SizedBox(width: 18, height: 18,
                child: CircularProgressIndicator(strokeWidth: 2, color: ThemeProvider().current.highlightColor))
          else
            GestureDetector(
              onTap: _runSearch,
              child: Icon(Icons.search_rounded, color: ThemeProvider().current.highlightColor, size: 22),
            ),
        ]),
      ),
      // ── Results count header ──
      if (_searchHits.isNotEmpty)
        Container(
          color: Color(0xFF0d1220),
          padding: EdgeInsets.symmetric(horizontal: 14, vertical: 6),
          child: Row(children: [
            Icon(Icons.find_in_page_rounded, color: ThemeProvider().current.highlightColor, size: 14),
            SizedBox(width: 6),
            Text(
              '${files.length} file${files.length == 1 ? '' : 's'}  ·  ${_searchHits.length} match${_searchHits.length == 1 ? '' : 'es'}',
              style: TextStyle(color: ThemeProvider().current.highlightColor, fontSize: 11, fontWeight: FontWeight.w600),
            ),
          ]),
        ),
      Divider(height: 1, color: Color(0xFF1e293b)),
      // ── File-level result cards ──
      Expanded(child: _searchHits.isEmpty
          ? Center(child: _searching
              ? Column(mainAxisSize: MainAxisSize.min, children: [
                  CircularProgressIndicator(color: ThemeProvider().current.highlightColor, strokeWidth: 2.5),
                  SizedBox(height: 16),
                  Text('Scanning all dart files…',
                      style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 13)),
                  SizedBox(height: 6),
                  Text('Looking for "${_searchCtrl.text.trim()}"',
                      style: TextStyle(color: ThemeProvider().current.highlightColor, fontSize: 11, fontFamily: 'monospace')),
                ])
              : const Text('Enter a keyword and tap search',
                  style: TextStyle(color: Colors.white38, fontSize: 13)))
          : ListView.builder(
              itemCount: files.length,
              itemBuilder: (ctx, i) {
                final fp   = files[i];
                final hits = grouped[fp]!;
                final fileName = hits.first['fileName'] as String? ?? fp.split('/').last;
                // Compute a readable relative path
                final rel = (_editRootDir != null && fp.startsWith(_editRootDir!))
                    ? '.${fp.replaceFirst(_editRootDir!, '')}'.replaceAll('/$fileName', '/')
                    : fp.replaceAll('/$fileName', '/');
                final count = hits.length;
                return InkWell(
                  onTap: () async {
                    final kw = _searchCtrl.text.trim();
                    // keep _searchHits so Back can restore results
                    setState(() { _searchMode = false; _openedFromSearch = true; });
                    await _openFileWithKeyword(
                      {'path': fp, 'isDir': false, 'name': fileName},
                      kw,
                    );
                  },
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                    decoration: BoxDecoration(
                      border: Border(bottom: BorderSide(color: Color(0xFF1e293b))),
                    ),
                    child: Row(children: [
                      Icon(Icons.description_outlined, color: ThemeProvider().current.highlightColor, size: 20),
                      const SizedBox(width: 12),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(fileName,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                            )),
                        const SizedBox(height: 2),
                        Text(rel,
                            style: const TextStyle(
                              color: Colors.white38,
                              fontSize: 11,
                              fontFamily: 'monospace',
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis),
                      ])),
                      SizedBox(width: 8),
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: ThemeProvider().current.highlightColor.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: ThemeProvider().current.highlightColor.withOpacity(0.4)),
                        ),
                        child: Text(
                          '$count',
                          style: TextStyle(
                            color: ThemeProvider().current.highlightColor,
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      const SizedBox(width: 4),
                      const Icon(Icons.chevron_right_rounded, color: Colors.white24, size: 18),
                    ]),
                  ),
                );
              },
            )),
    ]);
  }

  // ── File editor ────────────────────────────────────────────────────────────
  Widget _buildFileEditor() {
    final fileName = _openFilePath!.split('/').last;
    // hasChanges = committed edits OR a line still open in the inline editor
    final hasChanges = _changedIdx.isNotEmpty || _editingLineIdx != null;
    final isEditable = _openFileOrigPath != null;

    return Stack(children: [
      Column(children: [
      // ── Editor toolbar ──
      if (!_fullScreen) Container(
        color: const Color(0xFF0f172a),
        padding: const EdgeInsets.fromLTRB(12, 6, 8, 6),
        child: Row(children: [
          GestureDetector(
            onTap: () {
              if (hasChanges) {
                showDialog<bool>(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    backgroundColor: const Color(0xFF1e293b),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    title: const Text('Unsaved Changes', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                    content: const Text('You have unsaved changes. Close anyway?',
                        style: TextStyle(color: Colors.white70, fontSize: 13)),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(ctx, false),
                          child: Text('Stay', style: TextStyle(color: Colors.white.withOpacity(0.5)))),
                      TextButton(onPressed: () => Navigator.pop(ctx, true),
                          child: const Text('Close', style: TextStyle(color: Color(0xFFef4444), fontWeight: FontWeight.bold))),
                    ],
                  ),
                ).then((ok) { if (ok == true) _backFromFile(); });
              } else {
                _backFromFile();
              }
            },
            child: Icon(Icons.arrow_back_ios_new_rounded, color: ThemeProvider().current.highlightColor, size: 18),
          ),
          const SizedBox(width: 8),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(fileName, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600),
                overflow: TextOverflow.ellipsis),
            if (!isEditable)
              const Text('read-only', style: TextStyle(color: Colors.white38, fontSize: 10))
            else if (hasChanges) ...[
              () {
                // Count committed changes + the open inline edit (if not already counted)
                final inlineExtra = (_editingLineIdx != null &&
                    !_changedIdx.contains(_editingLineIdx)) ? 1 : 0;
                final total = _changedIdx.length + inlineExtra;
                return Text('$total line${total == 1 ? '' : 's'} modified',
                    style: const TextStyle(color: Color(0xFFfbbf24), fontSize: 10));
              }(),
            ],
          ])),
          // Match count badge
          if (_matchLines.isNotEmpty)
            Padding(
              padding: EdgeInsets.only(right: 6),
              child: Text(
                '(${_matchIdx + 1}/${_matchLines.length})',
                style: TextStyle(color: ThemeProvider().current.highlightColor, fontSize: 11, fontWeight: FontWeight.w600),
              ),
            ),
          // Copy file
          IconButton(
            icon: const Icon(Icons.copy_rounded, color: Colors.white38, size: 18),
            tooltip: 'Copy file content',
            onPressed: _copyFile,
            padding: const EdgeInsets.all(6),
            constraints: const BoxConstraints(),
          ),
          // Revert (only for editable files)
          if (isEditable) IconButton(
            icon: _reverting
                ? const SizedBox(width: 16, height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFFef4444)))
                : const Icon(Icons.history_rounded, color: Color(0xFFef4444), size: 20),
            tooltip: 'Revert changes',
            onPressed: _reverting ? null : _showRevertChoice,
            padding: const EdgeInsets.all(6),
            constraints: const BoxConstraints(),
          ),
          // Save & Patch (only for editable files)
          if (isEditable) ...[
            const SizedBox(width: 4),
            GestureDetector(
              onTap: (_saving || !hasChanges) ? null : _saveAndPatch,
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: hasChanges && !_saving
                      ? ThemeProvider().current.highlightColor
                      : Colors.white.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: _saving
                    ? const SizedBox(width: 14, height: 14,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                    : Text(
                        hasChanges ? 'PATCH' : 'SAVED',
                        style: TextStyle(
                          color: hasChanges ? Colors.black : Colors.white38,
                          fontSize: 11, fontWeight: FontWeight.bold,
                        ),
                      ),
              ),
            ),
          ],
          // Full-screen toggle
          IconButton(
            icon: Icon(
              _fullScreen ? Icons.fullscreen_exit_rounded : Icons.fullscreen_rounded,
              color: Colors.white60,
              size: 20,
            ),
            tooltip: _fullScreen ? 'Exit full screen' : 'Full screen',
            onPressed: () => _setFullScreen(!_fullScreen),
            padding: const EdgeInsets.all(6),
            constraints: const BoxConstraints(),
          ),
          // Three-dot options menu
          IconButton(
            icon: const Icon(Icons.more_vert_rounded, color: Colors.white60, size: 20),
            tooltip: 'Editor options',
            onPressed: _showEditorMenu,
            padding: const EdgeInsets.all(6),
            constraints: const BoxConstraints(),
          ),
        ]),
      ),
      // ── Patch banner ──
      if (_patchBanner != null)
        Container(
          width: double.infinity,
          color: Color(0xFF1e293b),
          padding: EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          child: Text(_patchBanner!,
              style: TextStyle(color: ThemeProvider().current.highlightColor, fontSize: 12),
              textAlign: TextAlign.center),
        ),
      const Divider(height: 1, color: Color(0xFF1e293b)),
      // ── Line list (white bg + pinch-to-zoom) ──
      Expanded(child: Container(
        color: Colors.white,
        child: Listener(
          onPointerDown:   (_) => setState(() => _pointerCount++),
          onPointerUp:     (_) => setState(() => _pointerCount = (_pointerCount - 1).clamp(0, 10)),
          onPointerCancel: (_) => setState(() => _pointerCount = (_pointerCount - 1).clamp(0, 10)),
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onScaleStart: (d) {
              _baseFontSize = _fontSize;
              _lastScalePtCount = d.pointerCount;
            },
            onScaleUpdate: (d) {
              if (d.pointerCount >= 2) {
                // Re-anchor when the second finger just landed
                if (_lastScalePtCount < 2) {
                  _baseFontSize = _fontSize;
                }
                _lastScalePtCount = d.pointerCount;
                setState(() {
                  _fontSize = (_baseFontSize * d.scale).clamp(3.0, 26.0);
                });
              } else {
                // Single finger: horizontal pan in no-wrap mode
                if (!_wordWrap) {
                  _hOffsetNotifier.value =
                      (_hOffsetNotifier.value - d.focalPointDelta.dx)
                          .clamp(0.0, _kHMaxOffset);
                }
                _lastScalePtCount = d.pointerCount;
              }
            },
            onScaleEnd: (_) { _lastScalePtCount = 0; },
            child: _wordWrap
                ? ListView.builder(
                    controller: _editorScroll,
                    physics: _pointerCount >= 2
                        ? const NeverScrollableScrollPhysics()
                        : const ClampingScrollPhysics(),
                    itemCount: _editLines.length,
                    itemBuilder: (ctx, i) => _buildLine(i),
                  )
                : ListView.builder(
                    controller: _editorScroll,
                    physics: _pointerCount >= 2
                        ? const NeverScrollableScrollPhysics()
                        : const ClampingScrollPhysics(),
                    itemCount: _editLines.length,
                    itemExtent: _fontSize + 10.0,
                    itemBuilder: (ctx, i) => _buildLine(i),
                  ),
          ),
        ),
      )),
      // ── Inline edit bar (slides in above keyboard when inline-editing) ──
      if (_inlineEditMode && _editingLineIdx != null) _buildInlineEditBar(),
      // ── Find/Replace bar (slides in at bottom) ──
      if (_findBarOpen) _buildFindBar(),
    ]),
    // ── Fullscreen exit overlay ──
    if (_fullScreen) Positioned(
      top: 8, right: 8,
      child: GestureDetector(
        onTap: () => _setFullScreen(false),
        child: Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: Colors.black54,
            borderRadius: BorderRadius.circular(20),
          ),
          child: const Icon(Icons.fullscreen_exit_rounded, color: Colors.white70, size: 20),
        ),
      ),
    ),
    ]);
  }

  Widget _buildLine(int idx) {
    final line      = _editLines[idx];
    final isChanged = _changedIdx.contains(idx);
    // Keyword match state
    final isCurrentMatch = _matchLines.isNotEmpty && _matchLines[_matchIdx] == idx;
    final isAnyMatch     = !isCurrentMatch && _matchLines.contains(idx);
    final isJumped       = _jumpedLine == idx;

    // Detect type for syntax colouring
    final trimmed = line.trimLeft();
    final isAddr  = trimmed.startsWith('0x') && trimmed.contains(':');
    final isCmt   = trimmed.startsWith('//');
    final isHdr   = !isAddr && !isCmt && trimmed.isNotEmpty;

    final isInlineEditing = _inlineEditMode && _editingLineIdx == idx;

    Color lineColor;
    if (isInlineEditing)  lineColor = const Color(0xFFFFF3CD); // warm amber — active inline edit
    else if (isJumped)    lineColor = const Color(0xFFB2EBF2); // cyan — jump target
    else if (isCurrentMatch) lineColor = const Color(0xFFFFD600);
    else if (isAnyMatch)  lineColor = const Color(0xFFFFF9C4);
    else if (isChanged)   lineColor = const Color(0xFFFFF8E1);
    else if (isHdr)       lineColor = const Color(0xFFF5F5F5);
    else                  lineColor = Colors.white;

    return GestureDetector(
      onTap: () {
        if (_openFileOrigPath == null) return; // read-only file
        if (_editingLineIdx != null && _editingLineIdx != idx) {
          _commitLineEdit(_editingLineIdx!);
        }
        _startEditLine(idx);
      },
      onLongPress: () => _copyLine(idx),
      child: Container(
        color: lineColor,
        padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 1),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Line number gutter
          Container(
            width: 46,
            color: isJumped
                ? const Color(0xFF00BCD4) // cyan gutter on jump target
                : isCurrentMatch
                    ? const Color(0xFFFFAB00)
                    : isAnyMatch
                        ? const Color(0xFFFFF8E1)
                        : const Color(0xFFF0F0F0),
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
            child: Text('${idx + 1}',
                style: TextStyle(
                  color: (isJumped || isCurrentMatch)
                      ? const Color(0xFF212121)
                      : const Color(0xFF9E9E9E),
                  fontSize: (_fontSize * 0.85).clamp(3.0, 20.0),
                  fontFamily: 'monospace',
                  fontWeight: isCurrentMatch ? FontWeight.bold : FontWeight.normal,
                ),
                textAlign: TextAlign.right),
          ),
          // Side indicator bar
          Container(
            width: (isJumped || isCurrentMatch) ? 5 : 3,
            color: isJumped
                ? const Color(0xFF00ACC1) // cyan — jump target
                : isCurrentMatch
                    ? const Color(0xFFFF6F00)
                    : isAnyMatch
                        ? const Color(0xFFFBC02D)
                        : isChanged
                            ? const Color(0xFFFF8F00)
                            : Colors.transparent,
          ),
          const SizedBox(width: 4),
          // Content — gutter stays fixed; only this section translates horizontally
          if (isInlineEditing)
            Expanded(child: _buildLineEditor(idx))
          else if (_wordWrap)
            Expanded(child: _buildLineText(line, isAddr, isCmt, isChanged))
          else
            Expanded(
              child: ClipRect(
                child: ValueListenableBuilder<double>(
                  valueListenable: _hOffsetNotifier,
                  builder: (ctx, hOff, _) => Transform.translate(
                    offset: Offset(-hOff, 0),
                    child: SizedBox(
                      width: _kHMaxOffset + 200,
                      child: _buildLineText(line, isAddr, isCmt, isChanged),
                    ),
                  ),
                ),
              ),
            ),
        ]),
      ),
    );
  }

  Widget _buildLineText(String line, bool isAddr, bool isCmt, bool isChanged) {
    // ── ASM mode keeps original per-token styling ──────────────────────────
    if (_syntaxMode == 'ASM') {
      if (isAddr) {
        final colonIdx = line.indexOf(':');
        if (colonIdx > 0) {
          final addr  = line.substring(0, colonIdx + 1);
          final instr = line.substring(colonIdx + 1);
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 3),
            child: RichText(
              softWrap: _wordWrap,
              overflow: _wordWrap ? TextOverflow.clip : TextOverflow.visible,
              text: TextSpan(children: [
                TextSpan(text: addr, style: TextStyle(
                  color: const Color(0xFF0D47A1),
                  fontSize: _fontSize, fontFamily: 'monospace',
                )),
                TextSpan(text: instr, style: TextStyle(
                  color: isChanged ? const Color(0xFFE65100) : const Color(0xFF212121),
                  fontSize: _fontSize, fontFamily: 'monospace',
                )),
              ]),
            ),
          );
        }
      }
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Text(
          line,
          style: TextStyle(
            color: isCmt ? const Color(0xFF404040) : const Color(0xFF212121),
            fontSize: _fontSize, fontFamily: 'monospace',
            fontWeight: (!isAddr && !isCmt && line.trimLeft().isNotEmpty)
                ? FontWeight.w600 : FontWeight.normal,
          ),
          softWrap: _wordWrap,
          overflow: _wordWrap ? TextOverflow.clip : TextOverflow.visible,
        ),
      );
    }

    // ── All other modes: full syntax highlighting ──────────────────────────
    final spans = _syntaxSpans(line, isChanged);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: RichText(
        softWrap: _wordWrap,
        overflow: _wordWrap ? TextOverflow.clip : TextOverflow.visible,
        text: TextSpan(children: spans),
      ),
    );
  }

  // ── Syntax colour palette ─────────────────────────────────────────────────
  static const _cDef = Color(0xFF212121); // near-black — default text
  static const _cChg = Color(0xFFE65100); // deep orange — changed line
  static const _cKw  = Color(0xFF1976D2); // blue        — keywords
  static const _cStr = Color(0xFF388E3C); // green       — strings
  static const _cCmt = Color(0xFF404040); // dark grey   — comments
  static const _cNum = Color(0xFF8E24AA); // purple      — numbers
  static const _cTag = Color(0xFF00897B); // teal        — HTML tags
  static const _cAtt = Color(0xFF039BE5); // light blue  — HTML attributes
  static const _cPre = Color(0xFFE64A19); // deep orange — preprocessor
  static const _cKey = Color(0xFFAD1457); // pink        — special keys

  // ── CSS 3-red palette ─────────────────────────────────────────────────────
  static const _cCssR1 = Color(0xFFB71C1C); // darkest red  — selectors, @rules, { }
  static const _cCssR2 = Color(0xFFD32F2F); // medium red   — property names
  static const _cCssR3 = Color(0xFFEF5350); // light red    — values, units

  // ── Line-comment prefix per mode ─────────────────────────────────────────
  static String? _lineCommentOf(String mode) {
    switch (mode) {
      case 'C': case 'C++': case 'Java': case 'Kotlin':
      case 'JavaScript': case 'Rust': case 'PHP': return '//';
      case 'Python': case 'Shell': case 'Prop': case 'YAML':
      case 'Smali': return '#';
      case 'Lua': return '--';
      case 'Bat': return 'REM ';
      default: return null;
    }
  }

  // ── Keyword sets per mode ─────────────────────────────────────────────────
  static Set<String> _keywordsOf(String mode) {
    switch (mode) {
      case 'C': case 'C++': return {
        'if','else','for','while','do','return','void','int','char','float',
        'double','bool','true','false','null','nullptr','const','static',
        'struct','class','new','delete','include','define','typedef','enum',
        'union','switch','case','break','continue','public','private',
        'protected','virtual','override','namespace','using','auto','long',
        'unsigned','signed','short','extern','inline','template','typename',
        'sizeof','typeof','volatile',
      };
      case 'Java': return {
        'if','else','for','while','do','return','void','int','char','float',
        'double','boolean','true','false','null','class','interface','extends',
        'implements','new','static','final','public','private','protected',
        'abstract','this','super','import','package','try','catch','throw',
        'throws','finally','synchronized','native','enum','switch','case',
        'break','continue','instanceof','long','short','byte',
      };
      case 'Kotlin': return {
        'if','else','for','while','do','return','fun','val','var','class',
        'object','interface','companion','data','sealed','enum','when','is',
        'as','in','by','init','constructor','override','open','final',
        'abstract','public','private','protected','internal','null','true',
        'false','new','try','catch','throw','finally','import','package',
        'this','super','typealias','suspend','coroutine','inline','reified',
        'crossinline','noinline','it','Unit','Any','Nothing','String',
        'Boolean','Int','Long','Double','Float','List','Map','Set',
      };
      case 'JavaScript': return {
        'if','else','for','while','do','return','function','var','let',
        'const','class','new','this','true','false','null','undefined',
        'import','export','from','default','async','await','try','catch',
        'throw','finally','switch','case','break','continue','typeof',
        'instanceof','delete','void','in','of','extends','super','static',
        'yield','get','set','Promise','console','window','document',
      };
      case 'Python': return {
        'if','elif','else','for','while','def','class','return','import',
        'from','as','True','False','None','not','and','or','in','is',
        'lambda','try','except','finally','raise','with','pass','break',
        'continue','yield','global','nonlocal','del','assert','async','await',
        'print','len','range','type','str','int','float','list','dict',
        'tuple','set','bool','open','super','self',
      };
      case 'Shell': return {
        'if','then','else','elif','fi','for','in','do','done','while',
        'until','case','esac','function','return','local','export','echo',
        'exit','set','unset','readonly','shift','source','true','false',
        'test','read','printf','cd','ls','mkdir','rm','cp','mv','grep',
        'sed','awk','cut','sort','uniq','cat','head','tail','wc','find',
      };
      case 'Rust': return {
        'fn','let','mut','const','if','else','for','while','loop','return',
        'struct','enum','impl','trait','use','mod','pub','crate','super',
        'self','type','where','match','move','ref','in','as','dyn','unsafe',
        'async','await','true','false','Some','None','Ok','Err','u8','u16',
        'u32','u64','u128','i8','i16','i32','i64','i128','f32','f64','bool',
        'str','String','Vec','Box','Option','Result','usize','isize',
      };
      case 'Lua': return {
        'if','then','else','elseif','end','for','while','do','function',
        'return','local','not','and','or','in','true','false','nil',
        'repeat','until','break','require','print','tostring','tonumber',
        'type','pairs','ipairs','next','select','pcall','xpcall','error',
        'assert','rawget','rawset','setmetatable','getmetatable',
      };
      case 'PHP': return {
        'if','else','elseif','for','foreach','while','do','function','class',
        'return','echo','print','new','this','public','private','protected',
        'static','final','abstract','interface','extends','implements','use',
        'namespace','true','false','null','try','catch','throw','finally',
        'switch','case','break','continue','array','string','int','float',
        'bool','void','match','fn','readonly',
      };
      case 'Smali': return {
        '.class','.super','.implements','.field','.method','.end',
        'invoke-virtual','invoke-static','invoke-direct','invoke-super',
        'invoke-interface','iget','iput','sget','sput','const','const-string',
        'const/4','const/16','move','move-result','move-result-object',
        'return-void','return','return-object','if-eqz','if-nez','if-eq',
        'if-ne','if-lt','if-gt','if-le','if-ge','goto','new-instance',
        'check-cast','instance-of','array-length','new-array',
      };
      default: return {};
    }
  }

  // ── Char helpers ──────────────────────────────────────────────────────────
  static bool _isDigit(String c) {
    final code = c.codeUnitAt(0);
    return code >= 48 && code <= 57;
  }
  static bool _isHexDigit(String c) {
    final code = c.codeUnitAt(0);
    return (code >= 48 && code <= 57) ||
           (code >= 65 && code <= 70)  ||
           (code >= 97 && code <= 102);
  }
  static bool _isIdStart(String c) {
    final code = c.codeUnitAt(0);
    return (code >= 65 && code <= 90) ||
           (code >= 97 && code <= 122) || code == 95;
  }
  static bool _isIdChar(String c) => _isIdStart(c) || _isDigit(c);

  // ── General tokenizer → spans ─────────────────────────────────────────────
  // ── Dart (Blutter) syntax spans ──────────────────────────────────────────
  //
  // Line types recognised in Blutter .hasm output (light/white background):
  //   1.  //     0x...  (4+ spaces) → ARM64 raw instruction  → dark grey
  //   2.  // ** addr:              → function address header → purple
  //   3.  // 0x...: [Uppercase]   → Dart IR annotation       → blue
  //   4.  // 0x...: bl ... ; Tgt  → branch + call target     → grey + cyan
  //   5.  // ...                  → other comment            → medium grey
  //   6.  (no //)                 → Dart signature line       → tokenised
  static const _dArm64  = Color(0xFF424242); // dark grey  ("black, increased a bit")
  static const _dAddr   = Color(0xFF6A1B9A); // purple     — address header
  static const _dIR     = Color(0xFF0277BD); // blue       — Dart IR annotation
  static const _dBranch = Color(0xFF505050); // grey       — bl instruction part
  static const _dTarget = Color(0xFF00838F); // teal/cyan  — ; ClassName::method
  static const _dCmt    = Color(0xFF404040); // dark grey   — generic comment
  static const _dKw     = Color(0xFFBF360C); // deep orange — Dart keywords
  static const _dType   = Color(0xFF1565C0); // dark blue  — types / PascalCase
  static const _dHex    = Color(0xFF2E7D32); // dark green  — 0x values
  static const _dPunct  = Color(0xFF880E4F); // dark pink   — { } ( ) , ;
  static const _dStr    = Color(0xFF00695C); // teal        — string literals
  static const _dDef    = Color(0xFF212121); // near-black  — identifiers

  static const _dartKeywords = {
    'class','abstract','extends','implements','mixin','with',
    'static','final','const','late','var',
    'void','bool','int','double','String','num','dynamic','Object',
    'List','Map','Set','Iterable','Future','Stream',
    'null','true','false',
    'if','else','for','while','do','return','switch','case','break',
    'continue','try','catch','on','finally','throw','rethrow',
    'new','this','super','import','export','part','library',
    'async','await','sync','yield','in','is','as','of',
    'operator','get','set','covariant','external','factory',
    'typedef','enum','required','override','pragma',
    'Never','Null','Function',
  };

  List<TextSpan> _dartSpans(String line, bool isChanged) {
    final fs = _fontSize;
    const fm = 'monospace';
    TextStyle s(Color c, {bool bold = false}) => TextStyle(
      color: c, fontSize: fs, fontFamily: fm,
      fontWeight: bold ? FontWeight.bold : FontWeight.normal,
    );

    final trimmed = line.trimLeft();

    // 1. ARM64 raw instruction: //     0x... (4+ leading spaces inside //)
    if (RegExp(r'^//\s{4,}0x').hasMatch(trimmed)) {
      return [TextSpan(text: line, style: s(_dArm64))];
    }

    // 2. Address header: // ** addr: ...
    if (trimmed.startsWith('// **')) {
      return [TextSpan(text: line, style: s(_dAddr, bold: true))];
    }

    // 3+4. // 0x...: <something>
    if (RegExp(r'^// 0x[0-9a-fA-F]+:').hasMatch(trimmed)) {
      // Is it a branch with a call target after ';'?
      final semiIdx = line.indexOf('; ');
      if (semiIdx > 0 && RegExp(r'\bbl\b').hasMatch(line.substring(0, semiIdx))) {
        return [
          TextSpan(text: line.substring(0, semiIdx), style: s(_dBranch)),
          TextSpan(text: line.substring(semiIdx), style: s(_dTarget, bold: true)),
        ];
      }
      // Dart IR: keyword after colon starts with uppercase
      final colonIdx = line.indexOf(':');
      final afterColon = colonIdx >= 0 ? line.substring(colonIdx + 1).trimLeft() : '';
      if (afterColon.isNotEmpty && afterColon[0].toUpperCase() == afterColon[0] &&
          afterColon[0] != afterColon[0].toLowerCase()) {
        return [TextSpan(text: line, style: s(_dIR))];
      }
      // Fallback: generic ARM/IR annotation
      return [TextSpan(text: line, style: s(_dCmt))];
    }

    // 5. Generic comment
    if (trimmed.startsWith('//') || trimmed.startsWith('/*') || trimmed.startsWith('*')) {
      return [TextSpan(text: line, style: s(_dCmt))];
    }

    // 6. Dart signature / code line — tokenise
    final tokens = <TextSpan>[];
    final src    = line;
    int   i      = 0;
    while (i < src.length) {
      final ch = src[i];

      // String literal " or '
      if (ch == '"' || ch == "'") {
        final q   = ch;
        final st  = i++;
        while (i < src.length && src[i] != q) {
          if (src[i] == r'\') i++; // skip escape
          i++;
        }
        if (i < src.length) i++; // closing quote
        tokens.add(TextSpan(text: src.substring(st, i), style: s(_dStr)));
        continue;
      }

      // Hex literal 0x...
      if (ch == '0' && i + 1 < src.length && src[i + 1] == 'x') {
        final st = i; i += 2;
        while (i < src.length && _isHexDigit(src[i])) i++;
        tokens.add(TextSpan(text: src.substring(st, i), style: s(_dHex)));
        continue;
      }

      // Decimal number
      if (_isDigit(ch)) {
        final st = i;
        while (i < src.length && _isDigit(src[i])) i++;
        tokens.add(TextSpan(text: src.substring(st, i), style: s(_dHex)));
        continue;
      }

      // Identifier / keyword / type
      if (_isIdStart(ch)) {
        final st  = i;
        while (i < src.length && _isIdChar(src[i])) i++;
        final word = src.substring(st, i);
        if (_dartKeywords.contains(word)) {
          tokens.add(TextSpan(text: word, style: s(_dKw, bold: true)));
        } else if (word[0] == word[0].toUpperCase() && word[0] != word[0].toLowerCase()) {
          // PascalCase → type/class name
          tokens.add(TextSpan(text: word, style: s(_dType)));
        } else {
          tokens.add(TextSpan(text: word, style: s(_dDef)));
        }
        continue;
      }

      // Punctuation { } ( ) , ; < >
      if ('{}(),;<>'.contains(ch)) {
        tokens.add(TextSpan(text: ch, style: s(_dPunct, bold: true)));
        i++;
        continue;
      }

      // Annotation @
      if (ch == '@') {
        final st = i++;
        while (i < src.length && _isIdChar(src[i])) i++;
        tokens.add(TextSpan(text: src.substring(st, i), style: s(_dKw, bold: true)));
        continue;
      }

      tokens.add(TextSpan(text: ch, style: s(_dDef)));
      i++;
    }

    return tokens.isEmpty
        ? [TextSpan(text: line, style: s(_dDef))]
        : tokens;
  }

  // ── CSS span builder (3-red palette) ────────────────────────────────────
  //
  //   Red 1 (darkest)  #B71C1C — selectors, @rules, { }
  //   Red 2 (medium)   #D32F2F — property names
  //   Red 3 (light)    #EF5350 — values, units, strings, hex colours
  List<TextSpan> _cssSpans(String line, bool isChanged) {
    final fs = _fontSize;
    const fm = 'monospace';
    TextStyle s(Color c, {bool bold = false}) => TextStyle(
      color: c, fontSize: fs, fontFamily: fm,
      fontWeight: bold ? FontWeight.bold : FontWeight.normal,
    );

    final trimmed = line.trimLeft();

    // /* comment */ — whole-line or inline
    if (trimmed.startsWith('/*') || trimmed.startsWith('*')) {
      return [TextSpan(text: line, style: s(_cCmt))];
    }

    // @rule — @media, @keyframes, @import, @font-face …
    if (trimmed.startsWith('@')) {
      // split: @word → red1 bold, rest → red3
      final spaceIdx = trimmed.indexOf(RegExp(r'\s'));
      if (spaceIdx > 0) {
        final indent   = line.length - line.trimLeft().length;
        final pfx      = line.substring(0, indent);
        final atWord   = trimmed.substring(0, spaceIdx);
        final rest     = trimmed.substring(spaceIdx);
        return [
          TextSpan(text: pfx + atWord, style: s(_cCssR1, bold: true)),
          TextSpan(text: rest,          style: s(_cCssR3)),
        ];
      }
      return [TextSpan(text: line, style: s(_cCssR1, bold: true))];
    }

    // Closing brace } alone
    if (trimmed == '}' || trimmed == '};') {
      return [TextSpan(text: line, style: s(_cCssR1, bold: true))];
    }

    // Selector line — ends with { or is just a selector
    if (trimmed.endsWith('{') || (trimmed.isNotEmpty && !trimmed.contains(':') && !trimmed.endsWith(';'))) {
      // colour the { in red1, selector in red1
      return [TextSpan(text: line, style: s(_cCssR1, bold: true))];
    }

    // Property: value; line
    final colonIdx = trimmed.indexOf(':');
    if (colonIdx > 0) {
      final indent   = line.length - line.trimLeft().length;
      final pfx      = line.substring(0, indent);
      final prop     = trimmed.substring(0, colonIdx);      // e.g. "background-color"
      final rest     = trimmed.substring(colonIdx);         // ": value;"

      // Tokenise value for hex colours and numbers-with-units
      final tokens = <TextSpan>[
        TextSpan(text: pfx,   style: s(_cDef)),
        TextSpan(text: prop,  style: s(_cCssR2, bold: true)),
        TextSpan(text: ':',   style: s(_cCssR1)),
      ];

      // Walk through value part after the colon
      final val = rest.substring(1); // strip leading ':'
      int j = 0;
      while (j < val.length) {
        // inline comment /* */
        if (val.startsWith('/*', j)) {
          final end    = val.indexOf('*/', j + 2);
          final endIdx = end < 0 ? val.length : end + 2;
          tokens.add(TextSpan(text: val.substring(j, endIdx), style: s(_cCmt)));
          j = endIdx;
          continue;
        }
        // CSS hex colour #rrggbb or #rgb
        if (val[j] == '#') {
          final st = j++; while (j < val.length && _isHexDigit(val[j])) j++;
          tokens.add(TextSpan(text: val.substring(st, j), style: s(_cCssR1, bold: true)));
          continue;
        }
        // Number possibly followed by units (px em rem % vh vw s ms etc.)
        if (_isDigit(val[j]) || (val[j] == '.' && j + 1 < val.length && _isDigit(val[j + 1]))) {
          final st = j;
          while (j < val.length && (_isDigit(val[j]) || val[j] == '.')) j++;
          // consume unit suffix
          final unitSt = j;
          while (j < val.length && _isIdStart(val[j])) j++;
          tokens.add(TextSpan(text: val.substring(st, j), style: s(_cCssR3)));
          if (j > unitSt) {} // already included
          continue;
        }
        // string " or '
        if (val[j] == '"' || val[j] == "'") {
          final q = val[j]; final st = j++;
          while (j < val.length && val[j] != q) j++;
          if (j < val.length) j++;
          tokens.add(TextSpan(text: val.substring(st, j), style: s(_cCssR3)));
          continue;
        }
        // identifier (keyword value like "solid", "none", "flex", var names)
        if (_isIdStart(val[j]) || val[j] == '-') {
          final st = j++;
          while (j < val.length && (_isIdChar(val[j]) || val[j] == '-')) j++;
          tokens.add(TextSpan(text: val.substring(st, j), style: s(_cCssR3)));
          continue;
        }
        // punctuation / whitespace
        tokens.add(TextSpan(text: val[j], style: s(_cCssR2)));
        j++;
      }
      return tokens;
    }

    // Fallback
    return [TextSpan(text: line, style: s(_cCssR3))];
  }

  List<TextSpan> _syntaxSpans(String line, bool isChanged) {
    final defCol = isChanged ? _cChg : _cDef;
    final fs     = _fontSize;
    const fm     = 'monospace';

    TextStyle s(Color c, {bool bold = false}) => TextStyle(
      color: c, fontSize: fs, fontFamily: fm,
      fontWeight: bold ? FontWeight.bold : FontWeight.normal,
    );

    // Plain text mode
    if (_syntaxMode == 'Text') {
      return [TextSpan(text: line,
          style: s(isChanged ? _cChg : _cDef))];
    }

    // Dart (Blutter) mode
    if (_syntaxMode == 'Dart') {
      return _dartSpans(line, isChanged);
    }

    // CSS mode (3-red palette)
    if (_syntaxMode == 'CSS') {
      return _cssSpans(line, isChanged);
    }

    // XML / HTML
    if (_syntaxMode == 'XML' || _syntaxMode == 'HTML') {
      return _xmlSpans(line, isChanged, s);
    }

    // JSON
    if (_syntaxMode == 'JSON') {
      return _jsonSpans(line, isChanged, s);
    }

    // ── Per-mode colour theme ─────────────────────────────────────────────
    Color kwCol  = _cKw;
    Color strCol = _cStr;
    Color numCol = _cNum;
    Color cmtCol = _cCmt;
    switch (_syntaxMode) {
      case 'Bat':
        kwCol  = const Color(0xFF1B5E20); // dark green   — commands
        strCol = const Color(0xFFF9A825); // amber        — strings / paths
        numCol = const Color(0xFFE65100); // deep orange  — numbers
        cmtCol = const Color(0xFF37474F); // dark blue-grey — REM / ::
        break;
      case 'C': case 'C++':
        kwCol  = const Color(0xFF0D47A1); // navy blue
        strCol = const Color(0xFF2E7D32); // dark green
        numCol = const Color(0xFF4A148C); // deep purple
        cmtCol = const Color(0xFF546E7A); // blue-grey
        break;
      case 'Java':
        kwCol  = const Color(0xFFBF360C); // deep orange   — Java vibes
        strCol = const Color(0xFF1B5E20); // dark green
        numCol = const Color(0xFF4527A0); // indigo
        cmtCol = const Color(0xFF546E7A);
        break;
      case 'JavaScript':
        kwCol  = const Color(0xFFF57F17); // amber/yellow  — JS brand
        strCol = const Color(0xFF1B5E20); // dark green
        numCol = const Color(0xFF0277BD); // blue
        cmtCol = const Color(0xFF546E7A);
        break;
      case 'Kotlin':
        kwCol  = const Color(0xFF6A1B9A); // purple        — Kotlin brand
        strCol = const Color(0xFF2E7D32); // green
        numCol = const Color(0xFFE65100); // deep orange
        cmtCol = const Color(0xFF546E7A);
        break;
      case 'Rust':
        kwCol  = const Color(0xFFBF360C); // rust orange   — Rust brand
        strCol = const Color(0xFF2E7D32); // green
        numCol = const Color(0xFF4527A0); // deep purple
        cmtCol = const Color(0xFF546E7A);
        break;
      case 'PHP':
        kwCol  = const Color(0xFF4A148C); // purple        — PHP brand
        strCol = const Color(0xFF2E7D32); // green
        numCol = const Color(0xFF0277BD); // blue
        cmtCol = const Color(0xFF546E7A);
        break;
      case 'Shell':
        kwCol  = const Color(0xFF00695C); // teal          — terminal feel
        strCol = const Color(0xFF827717); // olive yellow
        numCol = const Color(0xFFE65100); // deep orange
        cmtCol = const Color(0xFF546E7A);
        break;
      case 'Python':
        kwCol  = const Color(0xFF1565C0); // blue          — Python brand
        strCol = const Color(0xFF006064); // dark teal
        numCol = const Color(0xFF558B2F); // light green
        cmtCol = const Color(0xFF546E7A);
        break;
      case 'Lua':
        kwCol  = const Color(0xFF0D47A1); // navy blue
        strCol = const Color(0xFF33691E); // dark green
        numCol = const Color(0xFF6A1B9A); // purple
        cmtCol = const Color(0xFF546E7A);
        break;
      case 'Smali':
        kwCol  = const Color(0xFF558B2F); // Android green
        strCol = const Color(0xFFBF360C); // deep orange
        numCol = const Color(0xFF0277BD); // blue
        cmtCol = const Color(0xFF546E7A);
        break;
      case 'YAML':
        kwCol  = const Color(0xFF0288D1); // light blue
        strCol = const Color(0xFF558B2F); // green
        numCol = const Color(0xFFE65100); // orange
        cmtCol = const Color(0xFF546E7A);
        break;
      case 'Prop':
        kwCol  = const Color(0xFF0277BD); // blue
        strCol = const Color(0xFF2E7D32); // green
        numCol = const Color(0xFF7B1FA2); // purple
        cmtCol = const Color(0xFF546E7A);
        break;
    }

    final tokens   = <TextSpan>[];
    final src      = line;
    int   i        = 0;
    final cmtPfx   = _lineCommentOf(_syntaxMode);
    final keywords = _keywordsOf(_syntaxMode);

    // Whole-line comment check
    final trimmed = src.trimLeft();
    if (cmtPfx != null && trimmed.startsWith(cmtPfx)) {
      return [TextSpan(text: line, style: s(cmtCol))];
    }
    // Bat REM comment
    if (_syntaxMode == 'Bat' &&
        (trimmed.toUpperCase().startsWith('REM ') || trimmed.startsWith('::'))) {
      return [TextSpan(text: line, style: s(cmtCol))];
    }

    while (i < src.length) {
      final ch = src[i];

      // ── Inline line comment ──────────────────────────────────────────────
      if (cmtPfx != null && src.startsWith(cmtPfx, i)) {
        tokens.add(TextSpan(text: src.substring(i), style: s(cmtCol)));
        break;
      }

      // ── C-style block comment /*...*/ ────────────────────────────────────
      if (src.startsWith('/*', i) &&
          const {'C','C++','Java','Kotlin','JavaScript','Rust','PHP','CSS'}
              .contains(_syntaxMode)) {
        final end    = src.indexOf('*/', i + 2);
        final endIdx = end < 0 ? src.length : end + 2;
        tokens.add(TextSpan(text: src.substring(i, endIdx), style: s(cmtCol)));
        i = endIdx;
        continue;
      }

      // ── Preprocessor / C #define etc ────────────────────────────────────
      if (ch == '#' &&
          const {'C','C++'}.contains(_syntaxMode) &&
          (i == 0 || src[i-1] == ' ' || src[i-1] == '\t')) {
        tokens.add(TextSpan(text: src.substring(i), style: s(_cPre)));
        break;
      }

      // ── @ annotation (Java / Kotlin) ─────────────────────────────────────
      if (ch == '@' &&
          const {'Java','Kotlin','JavaScript'}.contains(_syntaxMode)) {
        final start = i++;
        while (i < src.length && _isIdChar(src[i])) i++;
        tokens.add(TextSpan(text: src.substring(start, i), style: s(_cPre)));
        continue;
      }

      // ── String literals (double or single quote) ─────────────────────────
      if (ch == '"' || ch == "'") {
        final quote = ch;
        final start = i++;
        while (i < src.length && src[i] != quote) {
          if (src[i] == '\\') i++;
          i++;
        }
        if (i < src.length) i++;
        tokens.add(TextSpan(text: src.substring(start, i), style: s(strCol)));
        continue;
      }

      // ── Hex number 0x... ─────────────────────────────────────────────────
      if (ch == '0' && i + 1 < src.length &&
          (src[i+1] == 'x' || src[i+1] == 'X')) {
        final start = i; i += 2;
        while (i < src.length && _isHexDigit(src[i])) i++;
        tokens.add(TextSpan(text: src.substring(start, i), style: s(numCol)));
        continue;
      }

      // ── Decimal / float number ───────────────────────────────────────────
      if (_isDigit(ch)) {
        final start = i++;
        while (i < src.length &&
               (_isDigit(src[i]) || src[i] == '.' ||
                src[i] == 'f' || src[i] == 'L' || src[i] == '_')) i++;
        tokens.add(TextSpan(text: src.substring(start, i), style: s(numCol)));
        continue;
      }

      // ── Identifier / keyword ─────────────────────────────────────────────
      if (_isIdStart(ch)) {
        final start = i++;
        while (i < src.length && _isIdChar(src[i])) i++;
        final word = src.substring(start, i);
        final isKw = keywords.contains(word);
        tokens.add(TextSpan(text: word, style: s(isKw ? kwCol : defCol, bold: isKw)));
        continue;
      }

      // ── Default: single char ─────────────────────────────────────────────
      tokens.add(TextSpan(text: ch, style: s(defCol)));
      i++;
    }

    return tokens.isEmpty ? [TextSpan(text: line, style: s(defCol))] : tokens;
  }

  // ── XML / HTML span builder ───────────────────────────────────────────────
  List<TextSpan> _xmlSpans(String line, bool isChanged,
      TextStyle Function(Color, {bool bold}) s) {
    final defCol = isChanged ? _cChg : _cDef;
    final tokens = <TextSpan>[];
    int i = 0;

    while (i < line.length) {
      if (line.startsWith('<!--', i)) {
        // comment
        final end    = line.indexOf('-->', i + 4);
        final endIdx = end < 0 ? line.length : end + 3;
        tokens.add(TextSpan(text: line.substring(i, endIdx), style: s(_cCmt)));
        i = endIdx;
      } else if (line[i] == '<') {
        // tag open
        final end = line.indexOf('>', i);
        if (end < 0) {
          tokens.add(TextSpan(text: line.substring(i), style: s(_cTag)));
          break;
        }
        final tagBody = line.substring(i + 1, end);
        tokens.add(TextSpan(text: '<', style: s(_cCmt)));
        // split tagBody into name + attributes
        final spaceIdx = tagBody.indexOf(' ');
        final tagName = spaceIdx < 0 ? tagBody : tagBody.substring(0, spaceIdx);
        tokens.add(TextSpan(text: tagName, style: s(_cTag, bold: true)));
        if (spaceIdx >= 0) {
          final attrs = tagBody.substring(spaceIdx);
          // highlight attribute names
          final attrRe = RegExp(r'(\s+)([\w:-]+)(=)("([^"]*)")?');
          int last = 0;
          for (final m in attrRe.allMatches(attrs)) {
            if (m.start > last)
              tokens.add(TextSpan(text: attrs.substring(last, m.start), style: s(defCol)));
            tokens.add(TextSpan(text: m.group(1)!, style: s(defCol)));
            tokens.add(TextSpan(text: m.group(2)!, style: s(_cAtt)));
            tokens.add(TextSpan(text: m.group(3)!, style: s(defCol)));
            if (m.group(4) != null)
              tokens.add(TextSpan(text: m.group(4)!, style: s(_cStr)));
            last = m.end;
          }
          if (last < attrs.length)
            tokens.add(TextSpan(text: attrs.substring(last), style: s(defCol)));
        }
        tokens.add(TextSpan(text: '>', style: s(_cCmt)));
        i = end + 1;
      } else {
        // text content
        final next = line.indexOf('<', i);
        final endIdx = next < 0 ? line.length : next;
        tokens.add(TextSpan(text: line.substring(i, endIdx), style: s(defCol)));
        i = endIdx;
      }
    }
    return tokens.isEmpty ? [TextSpan(text: line, style: s(defCol))] : tokens;
  }

  // ── JSON span builder ─────────────────────────────────────────────────────
  List<TextSpan> _jsonSpans(String line, bool isChanged,
      TextStyle Function(Color, {bool bold}) s) {
    final defCol = isChanged ? _cChg : _cDef;
    final tokens = <TextSpan>[];
    int i = 0;

    // Capture leading whitespace
    while (i < line.length && (line[i] == ' ' || line[i] == '\t')) i++;
    if (i > 0) tokens.add(TextSpan(text: line.substring(0, i), style: s(defCol)));

    // JSON key: "key":
    if (i < line.length && line[i] == '"') {
      final start = i++;
      while (i < line.length && line[i] != '"') {
        if (line[i] == '\\') i++;
        i++;
      }
      if (i < line.length) i++;
      final word = line.substring(start, i);
      // peek for colon → key
      int j = i;
      while (j < line.length && (line[j] == ' ' || line[j] == '\t')) j++;
      final isKey = j < line.length && line[j] == ':';
      tokens.add(TextSpan(text: word, style: s(isKey ? _cKey : _cStr)));
    }

    // rest of line
    while (i < line.length) {
      final ch = line[i];
      if (ch == '"') {
        final start = i++;
        while (i < line.length && line[i] != '"') {
          if (line[i] == '\\') i++;
          i++;
        }
        if (i < line.length) i++;
        tokens.add(TextSpan(text: line.substring(start, i), style: s(_cStr)));
      } else if (_isDigit(ch) || (ch == '-' && i + 1 < line.length && _isDigit(line[i+1]))) {
        final start = i++;
        while (i < line.length && (_isDigit(line[i]) || line[i] == '.' || line[i] == 'e' || line[i] == 'E')) i++;
        tokens.add(TextSpan(text: line.substring(start, i), style: s(_cNum)));
      } else if (line.startsWith('true', i) || line.startsWith('false', i) || line.startsWith('null', i)) {
        final end = i + (line.startsWith('true', i) ? 4 : line.startsWith('false', i) ? 5 : 4);
        tokens.add(TextSpan(text: line.substring(i, end), style: s(_cKw, bold: true)));
        i = end;
      } else {
        tokens.add(TextSpan(text: ch, style: s(defCol)));
        i++;
      }
    }
    return tokens.isEmpty ? [TextSpan(text: line, style: s(defCol))] : tokens;
  }

  // ── Inline line editor — bare cursor, no box ──────────────────────────────
  Widget _buildLineEditor(int idx) {
    return TextField(
      controller: _lineCtrl,
      autofocus: true,
      maxLines: 1,
      style: TextStyle(
        color: const Color(0xFFBF360C),
        fontSize: _fontSize,
        fontFamily: 'monospace',
      ),
      decoration: const InputDecoration(
        isDense: true,
        contentPadding: EdgeInsets.symmetric(vertical: 3),
        border: InputBorder.none,
        enabledBorder: InputBorder.none,
        focusedBorder: InputBorder.none,
      ),
      onSubmitted: (_) => _commitLineEdit(idx),
    );
  }

  // ── Inline edit bar — shown above the keyboard ─────────────────────────────
  Widget _buildInlineEditBar() {
    final idx = _editingLineIdx!;
    return Container(
      color: const Color(0xFF0f172a),
      padding: const EdgeInsets.fromLTRB(16, 6, 12, 6),
      child: Row(children: [
        Text(
          'Line ${idx + 1}',
          style: const TextStyle(color: Colors.white38, fontSize: 11, fontFamily: 'monospace'),
        ),
        const Spacer(),
        GestureDetector(
          onTap: _cancelLineEdit,
          child: const Padding(
            padding: EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            child: Text('Cancel', style: TextStyle(color: Colors.white54, fontSize: 13)),
          ),
        ),
        GestureDetector(
          onTap: () => _commitLineEdit(idx),
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            decoration: BoxDecoration(
              color: ThemeProvider().current.highlightColor,
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Text('Save', style: TextStyle(
              color: Colors.black, fontSize: 13, fontWeight: FontWeight.bold)),
          ),
        ),
      ]),
    );
  }

  // ── Editor options bottom sheet ─────────────────────────────────────────────
  void _showEditorMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      builder: (_) => StatefulBuilder(builder: (ctx, setLocal) {
        // Re-read on every rebuild so the toggle reflects live state
        final isEditable = _openFileOrigPath != null;
        return SafeArea(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            // Handle bar
            Container(
              margin: const EdgeInsets.symmetric(vertical: 10),
              width: 36, height: 4,
              decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(2)),
            ),
            // Search in file
            _menuItem(Icons.search_rounded, 'Search in file', () {
              Navigator.pop(ctx);
              setState(() { _findBarOpen = true; _replaceVisible = false; });
            }),
            // Syntax
            _menuItem(Icons.code_rounded, 'Syntax  ($_syntaxMode)', () async {
              Navigator.pop(ctx);
              await _showSyntaxDialog();
            }),
            const Divider(height: 1),
            // Jump to line
            _menuItem(Icons.format_list_numbered_rounded, 'Jump to line', () {
              Navigator.pop(ctx);
              _showJumpToLineDialog();
            }),
            const Divider(height: 1),
            // Word wrap
            _menuItemToggle(Icons.wrap_text_rounded, 'Word wrap', _wordWrap, () {
              setState(() => _wordWrap = !_wordWrap);
              if (_wordWrap) _hOffsetNotifier.value = 0.0;
              setLocal(() {});
            }),
            // Inline edit mode
            if (isEditable)
              _menuItemToggle(Icons.edit_rounded, 'Inline edit', _inlineEditMode, () {
                if (_editingLineIdx != null) _cancelLineEdit();
                setState(() => _inlineEditMode = !_inlineEditMode);
                setLocal(() {});
              }),
            // Read-only — only shown for edit-copy files
            if (_editRootDir != null &&
                _openFilePath != null &&
                _openFilePath!.startsWith(_editRootDir!))
              _menuItemToggle(Icons.edit_off_rounded, 'Read-only mode', !isEditable, () {
                setState(() {
                  if (_openFileOrigPath != null) {
                    // Currently editable → lock to read-only
                    _openFileOrigPath = null;
                  } else {
                    // Currently read-only → restore original path to re-enable editing
                    _openFileOrigPath =
                        '${widget.outputDir}/asm'
                        '${_openFilePath!.replaceFirst(_editRootDir!, '')}';
                  }
                });
                setLocal(() {});
              }),
            const Divider(height: 1),
            // Font size controls
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              child: Row(children: [
                const Icon(Icons.format_size_rounded, color: Color(0xFF607D8B), size: 20),
                const SizedBox(width: 14),
                const Text('Font size', style: TextStyle(color: Color(0xFF212121), fontSize: 14)),
                const Spacer(),
                GestureDetector(
                  onTap: () { setState(() => _fontSize = (_fontSize - 1).clamp(3.0, 26.0)); setLocal(() {}); },
                  child: Container(
                    width: 32, height: 32,
                    decoration: BoxDecoration(color: Colors.grey.shade200, borderRadius: BorderRadius.circular(6)),
                    child: const Icon(Icons.remove_rounded, size: 18, color: Color(0xFF212121)),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: StatefulBuilder(builder: (_, ss) => Text(
                    _fontSize.toStringAsFixed(0),
                    style: const TextStyle(color: Color(0xFF212121), fontSize: 14, fontWeight: FontWeight.bold),
                  )),
                ),
                GestureDetector(
                  onTap: () { setState(() => _fontSize = (_fontSize + 1).clamp(3.0, 26.0)); setLocal(() {}); },
                  child: Container(
                    width: 32, height: 32,
                    decoration: BoxDecoration(color: Colors.grey.shade200, borderRadius: BorderRadius.circular(6)),
                    child: const Icon(Icons.add_rounded, size: 18, color: Color(0xFF212121)),
                  ),
                ),
              ]),
            ),
            const Divider(height: 1),
            // Close file
            _menuItem(Icons.close_rounded, 'Close file', () {
              Navigator.pop(ctx);
              _backFromFile();
            }, color: const Color(0xFFD32F2F)),
            const SizedBox(height: 8),
          ]),
        );
      }),
    );
  }

  Widget _menuItem(IconData icon, String label, VoidCallback onTap, {Color? color}) {
    final c = color ?? const Color(0xFF212121);
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
        child: Row(children: [
          Icon(icon, color: color ?? const Color(0xFF607D8B), size: 20),
          const SizedBox(width: 14),
          Text(label, style: TextStyle(color: c, fontSize: 14)),
        ]),
      ),
    );
  }

  Widget _menuItemToggle(IconData icon, String label, bool value, VoidCallback onToggle) {
    return InkWell(
      onTap: onToggle,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: Row(children: [
          Icon(icon, color: const Color(0xFF607D8B), size: 20),
          const SizedBox(width: 14),
          Text(label, style: const TextStyle(color: Color(0xFF212121), fontSize: 14)),
          const Spacer(),
          Container(
            width: 42, height: 24,
            decoration: BoxDecoration(
              color: value ? const Color(0xFF1976D2) : Colors.grey.shade300,
              borderRadius: BorderRadius.circular(12),
            ),
            child: AnimatedAlign(
              duration: const Duration(milliseconds: 160),
              alignment: value ? Alignment.centerRight : Alignment.centerLeft,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 2),
                child: Container(width: 20, height: 20, decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle)),
              ),
            ),
          ),
        ]),
      ),
    );
  }

  // ── Syntax picker dialog ────────────────────────────────────────────────────
  Future<void> _showSyntaxDialog() async {
    const modes = [
      'ASM', 'Text', 'Bat', 'C', 'C++', 'CSS', 'Dart', 'HTML', 'JSON',
      'Java', 'JavaScript', 'Kotlin', 'Lua', 'PHP', 'Prop',
      'Python', 'Rust', 'Shell', 'Smali', 'XML', 'YAML',
    ];
    String selected = _syntaxMode;
    await showDialog(
      context: context,
      builder: (_) => StatefulBuilder(builder: (ctx, ss) => AlertDialog(
        backgroundColor: Colors.white,
        title: const Text('Syntax', style: TextStyle(color: Color(0xFF212121), fontSize: 18, fontWeight: FontWeight.bold)),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: modes.length,
            itemBuilder: (_, i) => RadioListTile<String>(
              value: modes[i],
              groupValue: selected,
              title: Text(modes[i], style: const TextStyle(color: Color(0xFF212121), fontSize: 14)),
              activeColor: const Color(0xFF1976D2),
              dense: true,
              onChanged: (v) { ss(() => selected = v!); },
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('CLOSE', style: TextStyle(color: Color(0xFF1976D2))),
          ),
        ],
      )),
    );
    if (selected != _syntaxMode) setState(() => _syntaxMode = selected);
  }

  // ── Jump to line dialog ─────────────────────────────────────────────────────
  void _showJumpToLineDialog() {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.white,
        title: const Text('Jump to line', style: TextStyle(color: Color(0xFF212121), fontSize: 16, fontWeight: FontWeight.bold)),
        content: TextField(
          controller: ctrl,
          keyboardType: TextInputType.number,
          autofocus: true,
          style: const TextStyle(color: Color(0xFF212121)),
          decoration: InputDecoration(
            hintText: '1 – ${_editLines.length}',
            hintStyle: const TextStyle(color: Color(0xFF9E9E9E)),
            border: const OutlineInputBorder(),
            focusedBorder: const OutlineInputBorder(
              borderSide: BorderSide(color: Color(0xFF1976D2)),
            ),
          ),
          onSubmitted: (_) => _doJump(ctrl.text),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('CANCEL', style: TextStyle(color: Color(0xFF9E9E9E))),
          ),
          TextButton(
            onPressed: () => _doJump(ctrl.text),
            child: const Text('GO', style: TextStyle(color: Color(0xFF1976D2))),
          ),
        ],
      ),
    );
  }

  void _doJump(String text) {
    Navigator.pop(context);
    final n = int.tryParse(text.trim());
    if (n == null || n < 1 || n > _editLines.length) {
      _showSnack('Invalid line number');
      return;
    }
    final lineIdx = n - 1; // 0-based

    // Highlight the target line and auto-clear after 2.5 s
    _jumpTimer?.cancel();
    setState(() => _jumpedLine = lineIdx);
    _jumpTimer = Timer(const Duration(milliseconds: 2500), () {
      if (mounted) setState(() => _jumpedLine = null);
    });

    // Scroll to center the line in the viewport
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_editorScroll.hasClients) return;
      final lineH  = _fontSize + 14.0;
      final viewH  = _editorScroll.position.viewportDimension;
      final offset = (lineIdx * lineH) - (viewH / 2) + (lineH / 2);
      _editorScroll.animateTo(
        offset.clamp(0.0, _editorScroll.position.maxScrollExtent),
        duration: const Duration(milliseconds: 350),
        curve: Curves.easeOut,
      );
    });
  }

  // ── Inline option toggle (Aa / .* / \b) ───────────────────────────────────
  Widget _optToggle(String label, bool active, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 26,
        height: 24,
        margin: const EdgeInsets.only(left: 4),
        decoration: BoxDecoration(
          color: active ? const Color(0xFF1976D2) : Colors.transparent,
          borderRadius: BorderRadius.circular(4),
          border: Border.all(color: active ? const Color(0xFF1976D2) : Colors.grey.shade400),
        ),
        child: Center(child: Text(label, style: TextStyle(
          color: active ? Colors.white : Colors.grey.shade600,
          fontSize: 10,
          fontWeight: FontWeight.bold,
        ))),
      ),
    );
  }

  // ── Find/Replace bar widget ────────────────────────────────────────────────
  Widget _buildFindBar() {
    final canReplace = _openFileOrigPath != null;
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Colors.grey.shade300)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 8, offset: const Offset(0, -2))],
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        // ── History dropdown — only shown while typing, filtered to current input ──
        if (_showFindHistory && _findCtrl.text.isNotEmpty) ...[
          () {
            final filtered = _findHistory
                .where((h) => h.toLowerCase().contains(_findCtrl.text.toLowerCase()))
                .toList();
            if (filtered.isEmpty) return const SizedBox.shrink();
            return ConstrainedBox(
              constraints: const BoxConstraints(maxHeight: 220),
              child: Container(
                decoration: BoxDecoration(
                  color: const Color(0xFFF9F9F9),
                  border: Border(bottom: BorderSide(color: Colors.grey.shade200)),
                ),
                child: ListView(
                  shrinkWrap: true,
                  padding: EdgeInsets.zero,
                  children: filtered.map((item) => InkWell(
                  onTap: () {
                    _findCtrl.text = item;
                    _findCtrl.selection = TextSelection.collapsed(offset: item.length);
                    setState(() => _showFindHistory = false);
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    child: Row(children: [
                      Icon(Icons.history_rounded, color: Colors.grey.shade500, size: 17),
                      const SizedBox(width: 10),
                      Expanded(child: Text(item,
                          style: const TextStyle(color: Color(0xFF212121), fontSize: 13),
                          overflow: TextOverflow.ellipsis)),
                      GestureDetector(
                        onTap: () async {
                          await SearchHistory.remove(SearchHistory.keyAsmFind, item);
                          final updated = await SearchHistory.load(SearchHistory.keyAsmFind);
                          if (mounted) setState(() => _findHistory = updated);
                        },
                        child: Icon(Icons.close_rounded, color: Colors.red.shade400, size: 17),
                      ),
                    ]),
                  ),
                )).toList(),
                ),
              ),
            );
          }(),
        ],
        // ── Find row ──
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 8, 4),
          child: Row(children: [
            Text('Find', style: TextStyle(color: Colors.grey.shade500, fontSize: 12, fontWeight: FontWeight.w600)),
            const SizedBox(width: 10),
            Expanded(child: TextField(
              controller: _findCtrl,
              focusNode: _findFocusNode,
              autofocus: !_replaceVisible,
              style: const TextStyle(color: Color(0xFF212121), fontSize: 13),
              decoration: InputDecoration(
                hintText: 'Search…',
                hintStyle: TextStyle(color: Colors.grey.shade400),
                isDense: true,
                contentPadding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
                enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.grey.shade400)),
                focusedBorder: const UnderlineInputBorder(borderSide: BorderSide(color: Color(0xFF1976D2), width: 2)),
              ),
              onSubmitted: (_) => _navigateMatch(1),
            )),
            const SizedBox(width: 6),
            _optToggle('Aa', _searchMatchCase, () {
              setState(() => _searchMatchCase = !_searchMatchCase);
              _runFindSearch();
            }),
            _optToggle('.*', _searchRegex, () {
              setState(() => _searchRegex = !_searchRegex);
              _runFindSearch();
            }),
            _optToggle(r'\b', _searchWholeWords, () {
              setState(() => _searchWholeWords = !_searchWholeWords);
              _runFindSearch();
            }),
            const SizedBox(width: 4),
            GestureDetector(
              onTap: () => setState(() => _replaceVisible = !_replaceVisible),
              child: Icon(_replaceVisible ? Icons.arrow_drop_up_rounded : Icons.arrow_drop_down_rounded,
                  color: Colors.grey.shade500, size: 22),
            ),
          ]),
        ),
        // ── Replace row ──
        if (_replaceVisible)
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 8, 4),
            child: Row(children: [
              Text('Rep ', style: TextStyle(color: Colors.grey.shade500, fontSize: 12, fontWeight: FontWeight.w600)),
              const SizedBox(width: 10),
              Expanded(child: TextField(
                controller: _replaceCtrl,
                autofocus: _replaceVisible,
                style: const TextStyle(color: Color(0xFF212121), fontSize: 13),
                decoration: InputDecoration(
                  hintText: 'Replace with…',
                  hintStyle: TextStyle(color: Colors.grey.shade400),
                  isDense: true,
                  contentPadding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
                  enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.grey.shade400)),
                  focusedBorder: const UnderlineInputBorder(borderSide: BorderSide(color: Color(0xFF1976D2), width: 2)),
                  suffixIcon: GestureDetector(
                    onTap: () => setState(() => _replaceVisible = false),
                    child: Icon(Icons.arrow_drop_up_rounded, color: Colors.grey.shade500, size: 22),
                  ),
                ),
                onSubmitted: (_) => _replaceCurrentMatch(),
              )),
            ]),
          ),
        // ── Action buttons ──
        Container(
          color: Colors.grey.shade100,
          child: Row(children: [
            _findBtn('PREV', _matchLines.isNotEmpty ? () => _navigateMatch(-1) : null),
            _findBtn('NEXT', _matchLines.isNotEmpty ? () => _navigateMatch(1) : null),
            _findBtn('REP', canReplace && _matchLines.isNotEmpty ? () {
              if (!_replaceVisible) setState(() => _replaceVisible = true);
              else _replaceCurrentMatch();
            } : null),
            _findBtn('ALL', canReplace && _matchLines.isNotEmpty ? () {
              if (!_replaceVisible) setState(() => _replaceVisible = true);
              else _replaceAllMatches();
            } : null),
            const Spacer(),
            // ⋮ options
            IconButton(
              icon: Icon(Icons.more_vert_rounded, color: Colors.grey.shade600, size: 20),
              tooltip: 'Options',
              padding: const EdgeInsets.all(8),
              constraints: const BoxConstraints(),
              onPressed: _showFindOptions,
            ),
            const SizedBox(width: 4),
          ]),
        ),
      ]),
    );
  }

  Widget _findBtn(String label, VoidCallback? onTap) {
    final active = onTap != null;
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Text(label, style: TextStyle(
          color: active ? const Color(0xFF1976D2) : Colors.grey.shade400,
          fontSize: 13,
          fontWeight: FontWeight.bold,
        )),
      ),
    );
  }

  // ── Live-search engine ─────────────────────────────────────────────────────
  void _runFindSearch() {
    if (!_findBarOpen) return;
    final kw = _findCtrl.text;
    if (kw.isEmpty || _editLines.isEmpty) {
      setState(() { _inFileKeyword = null; _matchLines = []; _matchIdx = 0; });
      return;
    }
    try {
      final re = _buildSearchPattern(kw);
      final matches = <int>[];
      for (int i = 0; i < _editLines.length; i++) {
        if (re.hasMatch(_editLines[i])) matches.add(i);
      }
      setState(() {
        _inFileKeyword = matches.isNotEmpty ? kw : null;
        _matchLines    = matches;
        _matchIdx      = 0;
      });
      if (matches.isNotEmpty) {
        WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToMatch(0));
      }
    } catch (_) {
      setState(() { _inFileKeyword = null; _matchLines = []; _matchIdx = 0; });
    }
  }

  RegExp _buildSearchPattern(String kw) {
    String pattern = _searchRegex ? kw : RegExp.escape(kw);
    if (_searchWholeWords) pattern = r'\b' + pattern + r'\b';
    return RegExp(pattern, caseSensitive: _searchMatchCase);
  }

  // ── Replace operations ─────────────────────────────────────────────────────
  void _replaceCurrentMatch() {
    if (_matchLines.isEmpty) return;
    final lineIdx = _matchLines[_matchIdx];
    final re = _buildSearchPattern(_findCtrl.text);
    final newLine = _editLines[lineIdx].replaceFirst(re, _replaceCtrl.text);
    setState(() { _editLines[lineIdx] = newLine; _changedIdx.add(lineIdx); });
    _runFindSearch();
  }

  void _replaceAllMatches() {
    if (_matchLines.isEmpty) return;
    final re = _buildSearchPattern(_findCtrl.text);
    for (final lineIdx in List<int>.from(_matchLines)) {
      final newLine = _editLines[lineIdx].replaceAll(re, _replaceCtrl.text);
      _editLines[lineIdx] = newLine;
      _changedIdx.add(lineIdx);
    }
    _runFindSearch();
    _showSnack('Replaced ${_changedIdx.length} line(s)');
  }

  // ── Find options sheet (Regex / Words / Match case / Close) ───────────────
  void _showFindOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (_) => StatefulBuilder(builder: (ctx, ss) {
        Widget optRow(String label, bool val, VoidCallback onTap) {
          return InkWell(
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
              child: Row(children: [
                Expanded(child: Text(label, style: const TextStyle(color: Color(0xFF212121), fontSize: 15))),
                SizedBox(
                  width: 24, height: 24,
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      border: Border.all(color: val ? const Color(0xFF1976D2) : Colors.grey.shade400, width: 2),
                      borderRadius: BorderRadius.circular(4),
                      color: val ? const Color(0xFF1976D2) : Colors.transparent,
                    ),
                    child: val ? const Icon(Icons.check_rounded, color: Colors.white, size: 16) : null,
                  ),
                ),
              ]),
            ),
          );
        }
        return SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(margin: const EdgeInsets.symmetric(vertical: 10), width: 36, height: 4,
              decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(2))),
          optRow('Regex', _searchRegex, () {
            setState(() => _searchRegex = !_searchRegex);
            ss(() {});
            _runFindSearch();
          }),
          const Divider(height: 1),
          optRow('Words', _searchWholeWords, () {
            setState(() => _searchWholeWords = !_searchWholeWords);
            ss(() {});
            _runFindSearch();
          }),
          const Divider(height: 1),
          optRow('Match case', _searchMatchCase, () {
            setState(() => _searchMatchCase = !_searchMatchCase);
            ss(() {});
            _runFindSearch();
          }),
          const Divider(height: 1),
          InkWell(
            onTap: () {
              Navigator.pop(ctx);
              setState(() {
                _findBarOpen    = false;
                _replaceVisible = false;
                _inFileKeyword  = null;
                _matchLines     = [];
                _matchIdx       = 0;
              });
              _findCtrl.clear();
              _replaceCtrl.clear();
            },
            child: const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 14),
              child: Row(children: [
                Expanded(child: Text('Close', style: TextStyle(color: Color(0xFFD32F2F), fontSize: 15))),
              ]),
            ),
          ),
          const SizedBox(height: 4),
        ]));
      }),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  File entry tile in the tree
// ─────────────────────────────────────────────────────────────────────────────
class _FileEntryTile extends StatelessWidget {
  final Map<String, dynamic> entry;
  final VoidCallback onTap;

  const _FileEntryTile({required this.entry, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final isDir     = entry['isDir'] as bool? ?? false;
    final name      = entry['name'] as String? ?? '';
    final size      = entry['size'] as int? ?? 0;
    final childCount = entry['childCount'] as int? ?? 0;

    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: const BoxDecoration(
          border: Border(bottom: BorderSide(color: Color(0xFF1e293b))),
        ),
        child: Row(children: [
          Icon(
            isDir ? Icons.folder_rounded : Icons.article_outlined,
            color: isDir ? ThemeProvider().current.highlightColor : Colors.white38,
            size: 18,
          ),
          const SizedBox(width: 10),
          Expanded(child: Text(name,
              style: TextStyle(
                color: isDir ? Colors.white : Colors.white70,
                fontSize: 13,
                fontWeight: isDir ? FontWeight.w600 : FontWeight.normal,
              ))),
          if (!isDir)
            Text(_fmtSize(size), style: const TextStyle(color: Colors.white24, fontSize: 11)),
          if (isDir) ...[
            Text(
              '$childCount ${childCount == 1 ? 'item' : 'items'}',
              style: const TextStyle(color: Colors.white24, fontSize: 11),
            ),
            const SizedBox(width: 4),
            const Icon(Icons.chevron_right_rounded, color: Colors.white24, size: 18),
          ],
        ]),
      ),
    );
  }

  String _fmtSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }
}

// ── Line-edit bottom sheet ─────────────────────────────────────────────────────

class _LineEditSheet extends StatefulWidget {
  final int lineNumber;
  final String originalLine;
  final String initialText;
  final void Function(String newText) onSave;
  final VoidCallback onCancel;

  const _LineEditSheet({
    required this.lineNumber,
    required this.originalLine,
    required this.initialText,
    required this.onSave,
    required this.onCancel,
  });

  @override
  State<_LineEditSheet> createState() => _LineEditSheetState();
}

class _LineEditSheetState extends State<_LineEditSheet> {
  late final TextEditingController _ctrl;
  late final FocusNode _focusNode;

  @override
  void initState() {
    super.initState();
    _ctrl = TextEditingController(text: widget.initialText);
    _focusNode = FocusNode();
    // Auto-focus + select all so the user can start typing immediately
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _focusNode.requestFocus();
      _ctrl.selection = TextSelection(
          baseOffset: 0, extentOffset: _ctrl.text.length);
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF0d1117),
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        border: Border(top: BorderSide(color: Color(0xFF1976D2), width: 1.5)),
      ),
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Drag handle
          Center(
            child: Container(
              width: 36, height: 4,
              decoration: BoxDecoration(
                color: const Color(0xFF374151),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          const SizedBox(height: 14),
          // ── Header row
          Row(children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: const Color(0xFF1976D2).withOpacity(0.15),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: const Color(0xFF1976D2).withOpacity(0.4)),
              ),
              child: Text(
                'Line ${widget.lineNumber}',
                style: const TextStyle(
                  color: Color(0xFF60a5fa),
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  fontFamily: 'monospace',
                ),
              ),
            ),
            const SizedBox(width: 10),
            const Text('Edit instruction',
                style: TextStyle(color: Color(0xFF9ca3af), fontSize: 12)),
          ]),
          const SizedBox(height: 10),
          // ── Original line (reference)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            decoration: BoxDecoration(
              color: const Color(0xFF0a0a18),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: const Color(0xFF1e293b)),
            ),
            child: Text(
              widget.originalLine.trimLeft(),
              style: const TextStyle(
                color: Color(0xFF6b7280),
                fontSize: 12,
                fontFamily: 'monospace',
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          const SizedBox(height: 4),
          const Padding(
            padding: EdgeInsets.only(left: 2),
            child: Text('original',
                style: TextStyle(color: Color(0xFF4b5563), fontSize: 10)),
          ),
          const SizedBox(height: 10),
          // ── Edit field
          TextField(
            controller: _ctrl,
            focusNode: _focusNode,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 13,
              fontFamily: 'monospace',
            ),
            maxLines: null,
            textInputAction: TextInputAction.done,
            onSubmitted: (_) => widget.onSave(_ctrl.text.trim().isEmpty
                ? widget.initialText
                : _ctrl.text),
            decoration: InputDecoration(
              filled: true,
              fillColor: const Color(0xFF1a1a2e),
              hintText: 'Type replacement instruction…',
              hintStyle: const TextStyle(
                  color: Color(0xFF4b5563), fontSize: 12, fontFamily: 'monospace'),
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide:
                    const BorderSide(color: Color(0xFF1976D2), width: 1.5),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide:
                    const BorderSide(color: Color(0xFF1976D2), width: 2),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: const BorderSide(color: Color(0xFF374151)),
              ),
            ),
          ),
          const SizedBox(height: 14),
          // ── Action buttons
          Row(children: [
            Expanded(
              child: OutlinedButton(
                onPressed: widget.onCancel,
                style: OutlinedButton.styleFrom(
                  foregroundColor: const Color(0xFF9ca3af),
                  side: const BorderSide(color: Color(0xFF374151)),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
                child: const Text('Cancel',
                    style:
                        TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              flex: 2,
              child: ElevatedButton(
                onPressed: () {
                  final text = _ctrl.text;
                  widget.onSave(text.trim().isEmpty ? widget.initialText : text);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1976D2),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  elevation: 0,
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.check_rounded, size: 16),
                    SizedBox(width: 6),
                    Text('Save',
                        style: TextStyle(
                            fontWeight: FontWeight.w700, fontSize: 13)),
                  ],
                ),
              ),
            ),
          ]),
        ],
      ),
    );
  }
}
