import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:share_plus/share_plus.dart';
import 'package:archive/archive.dart';
import '../utils/hbc_channel.dart';
import '../utils/storage_helper.dart';
import '../utils/permission_helper.dart';
import '../utils/session_state.dart';

// ── Theme ─────────────────────────────────────────────────────────────────────
const _kAccent    = Color(0xFFE44D26);
const _kAccentDim = Color(0xFFBF360C);
const _kAccentGlow= Color(0xFFFF7043);
const _kBg        = Color(0xFF060606);
const _kCard      = Color(0xFF0e0e0e);
const _kBorder    = Color(0xFF1e1e1e);

// ── ZIP tree node (HTML manual mode) ─────────────────────────────────────────
class _HtmlZipNode {
  final String path;
  final bool   isDir;
  final int    depth;
  bool expanded;
  bool visible;
  _HtmlZipNode({required this.path, required this.isDir, required this.depth,
                this.expanded = true, this.visible = true});
  String get name {
    final p = path.endsWith('/') ? path.substring(0, path.length - 1) : path;
    return p.contains('/') ? p.substring(p.lastIndexOf('/') + 1) : p;
  }
  bool get isHtmlFile => !isDir &&
      (path.toLowerCase().endsWith('.html') ||
       path.toLowerCase().endsWith('.htm'));
  bool get selectable => isHtmlFile;
}

class HtmlEncryptorScreen extends StatefulWidget {
  const HtmlEncryptorScreen({super.key});

  @override
  State<HtmlEncryptorScreen> createState() => _HtmlEncryptorScreenState();
}

class _HtmlEncryptorScreenState extends State<HtmlEncryptorScreen>
    with TickerProviderStateMixin {

  // ── Animation controllers ────────────────────────────────────────────────
  late final AnimationController _orbitCtrl;
  late final AnimationController _scanCtrl;
  late final AnimationController _cardCtrl;
  late final AnimationController _logCtrl;

  late final Animation<double> _cardFade;
  late final Animation<Offset> _cardSlide;
  late final Animation<double> _logFade;

  // ── State ────────────────────────────────────────────────────────────────
  String? _filePath;
  String? _fileName;
  String? _outputDir;
  String? _outputFile;
  String  _log          = '';
  bool    _processing   = false;
  bool    _logVisible   = false;
  bool    _autoScroll   = true;
  Timer?  _pollTimer;

  // ── Manual mode state ────────────────────────────────────────────────────
  bool                 _manualMode   = false;
  String?              _mZipPath;
  String?              _mZipName;
  List<_HtmlZipNode>   _mNodes       = [];
  Set<String>          _mSelected    = {};
  bool                 _mProcessing  = false;
  String               _mLog         = '';
  bool                 _mLogVisible  = false;
  bool                 _mAutoScroll  = true;
  String?              _mOutputDir;
  String?              _mOutputFile;
  Timer?               _mPollTimer;

  final _keyCtrl    = TextEditingController();
  final _logScroll  = ScrollController();
  final _mLogScroll = ScrollController();

  @override
  void initState() {
    super.initState();

    _orbitCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 8))..repeat();
    _scanCtrl  = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat();
    _cardCtrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 700));

    _logCtrl   = AnimationController(vsync: this, duration: const Duration(milliseconds: 400));
    _logFade   = CurvedAnimation(parent: _logCtrl, curve: Curves.easeIn);

    _cardFade  = CurvedAnimation(parent: _cardCtrl, curve: Curves.easeIn);
    _cardSlide = Tween<Offset>(begin: const Offset(0, 0.04), end: Offset.zero)
        .animate(CurvedAnimation(parent: _cardCtrl, curve: Curves.easeOutCubic));

    _cardCtrl.forward();

    _resumeIfRunning();
  }

  Future<void> _resumeIfRunning() async {
    final state = await HbcChannel.jsEncryptorState();
    if (!mounted) return;
    if (state['running'] == true) {
      setState(() { _processing = true; _logVisible = true; });
      _startPoll();
    } else {
      // No active job — clear any stale session so the screen won't
      // auto-reopen on the next app launch.
      await SessionState.clear();
      await SessionState.clearLastTool();
    }
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _mPollTimer?.cancel();
    _orbitCtrl.dispose();
    _scanCtrl.dispose();
    _cardCtrl.dispose();
    _logCtrl.dispose();
    _keyCtrl.dispose();
    _logScroll.dispose();
    _mLogScroll.dispose();
    super.dispose();
  }

  // ── File pick ─────────────────────────────────────────────────────────────
  Future<void> _pickFile() async {
    final hasPerms = await PermissionHelper.ensureStorage(context, accent: _kAccent);
    if (!hasPerms) return;

    FilePickerResult? res;
    try {
      res = await FilePicker.platform.pickFiles(dialogTitle: 'Select .html / .htm / .zip');
    } catch (_) {
      res = await FilePicker.platform.pickFiles(dialogTitle: 'Select HTML file');
    }
    if (res == null || res.files.isEmpty) return;
    final f = res.files.first;
    if (f.path == null) return;

    final ext = f.path!.split('.').last.toLowerCase();
    if (!['html', 'htm', 'zip'].contains(ext)) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(_snack(
          'Unsupported — use .html  .htm  .zip', isError: true));
      }
      return;
    }

    setState(() {
      _filePath  = f.path;
      _fileName  = f.name;
      _outputDir = null;
      _outputFile= null;
      _log       = '';
      _logVisible= false;
    });
    _logCtrl.reset();
  }

  // ── Encrypt ───────────────────────────────────────────────────────────────
  Future<void> _encrypt() async {
    if (_filePath == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        _snack('Pick a file first', isError: true));
      return;
    }
    if (_keyCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        _snack('Enter a SubZero key', isError: true));
      return;
    }
    if (_processing) return;

    final isRunning = (await HbcChannel.jsEncryptorState())['running'] == true;
    if (isRunning) {
      ScaffoldMessenger.of(context).showSnackBar(
        _snack('Already processing — please wait', isError: true));
      return;
    }

    final outDir = await StorageHelper.buildOutputDir(prefix: 'htmlenc');
    await HbcChannel.jsEncryptorClearState();

    await HbcChannel.jsEncryptorAnalyze(
      filePath:   _filePath!,
      fileName:   _fileName ?? _filePath!.split('/').last,
      outputDir:  outDir,
      method:     'subzero',
      subzeroKey: _keyCtrl.text.trim(),
    );

    setState(() {
      _processing  = true;
      _logVisible  = true;
      _log         = '';
      _outputDir   = outDir;
      _outputFile  = null;
    });
    _logCtrl.forward();
    _startPoll();

    // Persist session so the screen restores if the app is killed mid-job.
    await SessionState.saveLastTool('htmlencryptor');
    await SessionState.save(
      filePath: _filePath,
      outputDir: outDir,
      isProcessing: true,
    );
  }

  // ── Poll ─────────────────────────────────────────────────────────────────
  void _startPoll() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 2), (_) async {
      final state = await HbcChannel.jsEncryptorState();
      if (!mounted) return;
      final log = (state['log'] as String?) ?? '';
      setState(() { _log = log; });
      _scrollLog();
      if (state['running'] != true) {
        _pollTimer?.cancel();
        setState(() {
          _processing  = false;
          _log         = (state['log'] as String?) ?? '';
          _outputDir   = state['outputDir'] as String?;
          _outputFile  = state['outputFile'] as String?;
          _logVisible  = _log.isNotEmpty;
        });
        if (_logVisible) _logCtrl.forward();
        // Job finished — clear session so the screen won't auto-reopen next launch.
        SessionState.clear();
        SessionState.clearLastTool();
      }
    });
  }

  void _scrollLog() {
    if (_autoScroll && _logScroll.hasClients) {
      _logScroll.animateTo(
        _logScroll.position.maxScrollExtent,
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeOut,
      );
    }
  }

  // ── Open output folder ────────────────────────────────────────────────────
  Future<void> _openOutput() async {
    final dir = _outputFile != null
        ? File(_outputFile!).parent.path
        : _outputDir;
    if (dir == null) return;
    try {
      await const MethodChannel('com.taurus.shield/storage')
          .invokeMethod('openFolder', {'path': dir});
    } catch (_) {}
  }

  // ── Share output ─────────────────────────────────────────────────────────
  Future<void> _shareOutput() async {
    final path = _outputFile ?? _outputDir;
    if (path == null) return;
    try {
      if (_outputFile != null) {
        await Share.shareXFiles([XFile(_outputFile!)]);
      } else {
        await Share.share('Output folder: $_outputDir');
      }
    } catch (_) {}
  }

  // ── Snack ─────────────────────────────────────────────────────────────────
  SnackBar _snack(String msg, {bool isError = false}) => SnackBar(
    content: Text(msg, style: const TextStyle(color: Colors.white)),
    backgroundColor: isError ? const Color(0xFFDC2626) : _kAccent,
    behavior: SnackBarBehavior.floating,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
  );

  // ── Build ─────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      appBar: AppBar(
        backgroundColor: _kBg,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded, color: Colors.white, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'HTML Obfuscator',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 18),
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 14, top: 10, bottom: 10),
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              color: _kAccent.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _kAccent.withOpacity(0.35), width: 1),
            ),
            alignment: Alignment.center,
            child: const Text(
              'ADVANCED',
              style: TextStyle(
                fontSize: 9.5,
                color: _kAccent,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.5,
              ),
            ),
          ),
        ],
      ),
      body: FadeTransition(
        opacity: _cardFade,
        child: SlideTransition(
          position: _cardSlide,
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildHeroBanner(),
                const SizedBox(height: 20),
                _buildModeToggle(),
                const SizedBox(height: 16),
                if (!_manualMode) ...[
                  _buildSectionLabel('1', 'PICK FILE'),
                  const SizedBox(height: 10),
                  _buildFilePicker(),
                  const SizedBox(height: 20),
                  _buildSectionLabel('2', 'SUBZERO KEY'),
                  const SizedBox(height: 10),
                  _buildKeyField(),
                  const SizedBox(height: 24),
                  _buildEncryptButton(),
                  if (_logVisible) ...[
                    const SizedBox(height: 20),
                    FadeTransition(
                      opacity: _logFade,
                      child: _buildLog(),
                    ),
                  ],
                  if (!_processing && (_outputDir != null || _outputFile != null)) ...[
                    const SizedBox(height: 16),
                    _buildOutputActions(),
                  ],
                ] else ...[
                  _buildManualBody(),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ── Hero banner ───────────────────────────────────────────────────────────
  Widget _buildHeroBanner() {
    return AnimatedBuilder(
      animation: Listenable.merge([_orbitCtrl, _scanCtrl]),
      builder: (_, child) {
        final orbit = _orbitCtrl.value;
        final scan  = _scanCtrl.value;
        final pulse = (math.sin(orbit * 2 * math.pi) + 1) / 2;
        return Container(
          height: 180,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                _kAccent.withOpacity(0.18 + 0.08 * pulse),
                _kAccentDim.withOpacity(0.08),
                Colors.black,
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(
              color: _kAccent.withOpacity(0.30 + 0.15 * pulse),
              width: 1.2,
            ),
            boxShadow: [
              BoxShadow(
                color: _kAccent.withOpacity(0.12 + 0.08 * pulse),
                blurRadius: 24,
                spreadRadius: 2,
              ),
            ],
          ),
          clipBehavior: Clip.hardEdge,
          child: Stack(
            children: [
              // scan line sweep
              Positioned(
                top: -20,
                left: -20,
                right: -20,
                child: Transform.translate(
                  offset: Offset(0, 220 * scan),
                  child: Container(
                    height: 2,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.transparent,
                          _kAccent.withOpacity(0.35),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              // content
              Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // orbit rings + HTML5 icon
                    SizedBox(
                      width: 96,
                      height: 96,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          CustomPaint(
                            size: const Size(92, 92),
                            painter: _HtmlOrbitPainter(
                              color: _kAccent,
                              opacity: 0.55 + 0.25 * pulse,
                              angle: orbit * 2 * math.pi,
                            ),
                          ),
                          CustomPaint(
                            size: const Size(70, 70),
                            painter: _HtmlDotPainter(
                              color: _kAccentGlow,
                              opacity: 0.45,
                              angle: -orbit * 2 * math.pi,
                            ),
                          ),
                          Container(
                            width: 52,
                            height: 52,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(14),
                              gradient: LinearGradient(
                                colors: [
                                  _kAccent.withOpacity(0.35),
                                  _kAccentDim.withOpacity(0.18),
                                ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              border: Border.all(
                                color: _kAccent.withOpacity(0.55 + 0.25 * pulse),
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: _kAccent.withOpacity(0.30 + 0.18 * pulse),
                                  blurRadius: 18,
                                  spreadRadius: 2,
                                ),
                              ],
                            ),
                            child: Center(
                              child: Text(
                                'HTML',
                                style: TextStyle(
                                  color: Color.lerp(_kAccent, _kAccentGlow, pulse),
                                  fontWeight: FontWeight.w900,
                                  fontSize: 11,
                                  letterSpacing: 1,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'SubZero HTML Obfuscator',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 15,
                        letterSpacing: 0.3,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Wraps HTML inside a self-decrypting shell · Advanced · Air-gapped',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.38),
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ── Section label ─────────────────────────────────────────────────────────
  Widget _buildSectionLabel(String num, String text) {
    return Row(
      children: [
        Container(
          width: 22,
          height: 22,
          decoration: BoxDecoration(
            color: _kAccent.withOpacity(0.15),
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: _kAccent.withOpacity(0.35)),
          ),
          alignment: Alignment.center,
          child: Text(num,
            style: TextStyle(color: _kAccent, fontWeight: FontWeight.w900, fontSize: 11)),
        ),
        const SizedBox(width: 8),
        Text(
          text,
          style: const TextStyle(
            color: Colors.white54,
            fontWeight: FontWeight.w700,
            fontSize: 11,
            letterSpacing: 2,
          ),
        ),
      ],
    );
  }

  // ── File picker ───────────────────────────────────────────────────────────
  Widget _buildFilePicker() {
    final hasFile = _filePath != null;
    return GestureDetector(
      onTap: _processing ? null : _pickFile,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: hasFile
              ? _kAccent.withOpacity(0.07)
              : _kCard,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: hasFile
                ? _kAccent.withOpacity(0.45)
                : _kBorder,
            width: 1.3,
          ),
          boxShadow: hasFile
              ? [BoxShadow(color: _kAccent.withOpacity(0.12), blurRadius: 16)]
              : [],
        ),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: _kAccent.withOpacity(0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                hasFile ? Icons.html_rounded : Icons.upload_file_rounded,
                color: _kAccent,
                size: 22,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    hasFile ? (_fileName ?? 'File selected') : 'Tap to pick file',
                    style: TextStyle(
                      color: hasFile ? Colors.white : Colors.white38,
                      fontWeight: FontWeight.w700,
                      fontSize: 13.5,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 3),
                  Text(
                    hasFile
                        ? _filePath!.split('/').last
                        : 'Supported: .html  .htm  .zip',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.35),
                      fontSize: 11,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            Icon(
              Icons.chevron_right_rounded,
              color: Colors.white.withOpacity(0.25),
              size: 20,
            ),
          ],
        ),
      ),
    );
  }

  // ── Key field ─────────────────────────────────────────────────────────────
  Widget _buildKeyField() {
    return Container(
      decoration: BoxDecoration(
        color: _kCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _kBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextField(
            controller: _keyCtrl,
            enabled: !_processing,
            keyboardType: TextInputType.number,
            onChanged: (_) => setState(() {}),
            style: const TextStyle(color: Colors.white, fontSize: 13.5,
                fontFamily: 'monospace', letterSpacing: 2),
            decoration: InputDecoration(
              hintText: 'Any number — e.g. 5437, 1234, 9823',
              hintStyle: TextStyle(color: Colors.white.withOpacity(0.28), fontSize: 12.5),
              prefixIcon: Icon(Icons.vpn_key_rounded, color: _kAccent, size: 18),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
            child: Text(
              'Type any number as your SubZero key (e.g. 5437, 1234, 9823). It seeds the kanji XOR encoding — the output HTML will auto-decrypt in any browser, with the key embedded and obfuscated inside.',
              style: TextStyle(color: Colors.white.withOpacity(0.32), fontSize: 11, height: 1.5),
            ),
          ),
        ],
      ),
    );
  }

  // ── Encrypt button ────────────────────────────────────────────────────────
  Widget _buildEncryptButton() {
    final canRun = _filePath != null && !_processing;
    return GestureDetector(
      onTap: canRun ? _encrypt : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        height: 52,
        decoration: BoxDecoration(
          gradient: canRun
              ? LinearGradient(colors: [_kAccentGlow, _kAccent, _kAccentDim])
              : null,
          color: canRun ? null : Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: canRun ? _kAccent.withOpacity(0.6) : Colors.white12,
          ),
          boxShadow: canRun
              ? [BoxShadow(color: _kAccent.withOpacity(0.35), blurRadius: 18)]
              : [],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (_processing)
              SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(
                  color: _kAccent,
                  strokeWidth: 2.2,
                ),
              )
            else
              Icon(Icons.security_rounded,
                  color: canRun ? Colors.white : Colors.white24, size: 18),
            const SizedBox(width: 10),
            Text(
              _processing
                  ? 'Obfuscating…'
                  : _filePath == null
                      ? 'Pick a file first'
                      : 'Obfuscate HTML',
              style: TextStyle(
                color: canRun ? Colors.white : Colors.white30,
                fontWeight: FontWeight.w800,
                fontSize: 14.5,
                letterSpacing: 0.3,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Log ───────────────────────────────────────────────────────────────────
  Widget _buildLog() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Icon(Icons.terminal_rounded, color: _kAccent, size: 15),
            const SizedBox(width: 6),
            const Text(
              'TERMINAL',
              style: TextStyle(
                color: _kAccent,
                fontSize: 11,
                fontWeight: FontWeight.w700,
                letterSpacing: 2,
              ),
            ),
            const Spacer(),
            GestureDetector(
              onTap: () => Clipboard.setData(ClipboardData(text: _log)),
              child: const Icon(Icons.copy_all_rounded, color: Colors.white38, size: 16),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          height: 200,
          decoration: BoxDecoration(
            color: const Color(0xFF060606),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _kAccent.withOpacity(0.18), width: 1),
          ),
          child: NotificationListener<ScrollNotification>(
            onNotification: (n) {
              if (n is ScrollUpdateNotification) {
                final atBottom = _logScroll.position.pixels >=
                    _logScroll.position.maxScrollExtent - 30;
                if (_autoScroll != atBottom) setState(() => _autoScroll = atBottom);
              }
              return false;
            },
            child: SingleChildScrollView(
              controller: _logScroll,
              padding: const EdgeInsets.all(12),
              child: SelectableText(
                _log.isEmpty ? 'Waiting for output…' : _log,
                style: TextStyle(
                  fontFamily: 'monospace',
                  fontSize: 11,
                  color: _log.isEmpty
                      ? Colors.white24
                      : Colors.white.withOpacity(0.72),
                  height: 1.5,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ── Output actions ────────────────────────────────────────────────────────
  Widget _buildOutputActions() {
    return Row(
      children: [
        Expanded(
          child: _OutButton(
            label: 'Open Folder',
            icon: Icons.folder_open_rounded,
            color: _kAccent,
            onTap: _openOutput,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _OutButton(
            label: 'Share',
            icon: Icons.share_rounded,
            color: _kAccentGlow,
            onTap: _shareOutput,
          ),
        ),
      ],
    );
  }

  // ── Mode toggle ───────────────────────────────────────────────────────────

  Widget _buildModeToggle() {
    return Container(
      height: 42,
      decoration: BoxDecoration(
        color: const Color(0xFF0a0a0a),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _kBorder, width: 1),
      ),
      child: Row(
        children: [
          _modeBtn('Auto', !_manualMode, Icons.auto_awesome_rounded,
              () { if (_manualMode) setState(() => _manualMode = false); }),
          _modeBtn('Manual ZIP', _manualMode, Icons.account_tree_rounded,
              () { if (!_manualMode) setState(() => _manualMode = true); }),
        ],
      ),
    );
  }

  Widget _modeBtn(String label, bool active, IconData icon, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          margin: const EdgeInsets.all(3),
          decoration: BoxDecoration(
            color: active ? _kAccent.withOpacity(0.16) : Colors.transparent,
            borderRadius: BorderRadius.circular(9),
            border: active ? Border.all(color: _kAccent.withOpacity(0.45)) : null,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 14, color: active ? _kAccent : Colors.white30),
              const SizedBox(width: 6),
              Text(label,
                style: TextStyle(
                  color: active ? _kAccent : Colors.white30,
                  fontWeight: FontWeight.w700,
                  fontSize: 12.5,
                )),
            ],
          ),
        ),
      ),
    );
  }

  // ── Manual body ───────────────────────────────────────────────────────────

  Widget _buildManualBody() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _buildSectionLabel('1', 'UPLOAD ZIP'),
        const SizedBox(height: 10),
        GestureDetector(
          onTap: _mProcessing ? null : _pickManualZip,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: _mZipPath != null ? _kAccent.withOpacity(0.07) : _kCard,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: _mZipPath != null ? _kAccent.withOpacity(0.45) : _kBorder,
                width: 1.3,
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: _kAccent.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    _mZipPath != null
                        ? Icons.folder_zip_rounded
                        : Icons.upload_file_rounded,
                    color: _kAccent,
                    size: 22,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _mZipPath != null
                            ? (_mZipName ?? 'ZIP selected')
                            : 'Tap to pick a .zip file',
                        style: TextStyle(
                          color: _mZipPath != null ? Colors.white : Colors.white38,
                          fontWeight: FontWeight.w700,
                          fontSize: 13.5,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      if (_mZipPath != null)
                        Text(
                          '${_mNodes.where((n) => n.isHtmlFile).length} HTML files found',
                          style: TextStyle(
                            color: _kAccent.withOpacity(0.65),
                            fontSize: 11.5,
                          ),
                        ),
                    ],
                  ),
                ),
                Icon(Icons.chevron_right_rounded,
                    color: Colors.white.withOpacity(0.25)),
              ],
            ),
          ),
        ),

        if (_mNodes.isNotEmpty) ...[
          const SizedBox(height: 16),
          _buildSectionLabel('2', 'SELECT HTML FILES'),
          const SizedBox(height: 10),
          _buildSelectAllRow(),
          const SizedBox(height: 6),
          Container(
            decoration: BoxDecoration(
              color: _kCard,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _kBorder),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: Column(
                children: _mNodes
                    .where((n) => n.visible)
                    .map((n) => _buildTreeRow(n))
                    .toList(),
              ),
            ),
          ),
        ],

        if (_mZipPath != null) ...[
          const SizedBox(height: 16),
          _buildSectionLabel('3', 'SUBZERO KEY'),
          const SizedBox(height: 10),
          _buildKeyField(),
          const SizedBox(height: 16),
          _buildManualRunButton(),
        ],

        if (_mLogVisible) ...[
          const SizedBox(height: 16),
          _buildManualLog(),
        ],
        if (!_mProcessing && (_mOutputDir != null || _mOutputFile != null)) ...[
          const SizedBox(height: 16),
          _buildManualOutputActions(),
        ],
      ],
    );
  }

  Widget _buildSelectAllRow() {
    final allHtml = _mNodes.where((n) => n.isHtmlFile).toList();
    final allSelected = allHtml.isNotEmpty &&
        allHtml.every((n) => _mSelected.contains(n.path));
    return Row(
      children: [
        GestureDetector(
          onTap: () => setState(() {
            if (allSelected) {
              _mSelected.clear();
            } else {
              for (final n in allHtml) _mSelected.add(n.path);
            }
          }),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: _kAccent.withOpacity(0.10),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _kAccent.withOpacity(0.30)),
            ),
            child: Text(
              allSelected ? 'Deselect All' : 'Select All',
              style: TextStyle(
                color: _kAccent, fontWeight: FontWeight.w700, fontSize: 12),
            ),
          ),
        ),
        const SizedBox(width: 10),
        Text(
          '${_mSelected.length} of ${allHtml.length} selected',
          style: const TextStyle(color: Colors.white38, fontSize: 12),
        ),
      ],
    );
  }

  Widget _buildTreeRow(_HtmlZipNode node) {
    final sel    = _mSelected.contains(node.path);
    final indent = 12.0 + node.depth * 18.0;
    if (node.isDir) {
      return GestureDetector(
        onTap: () => _toggleFolder(node),
        child: Container(
          padding: EdgeInsets.only(left: indent, right: 12, top: 10, bottom: 10),
          decoration: BoxDecoration(
            border: Border(bottom: BorderSide(color: Colors.white.withOpacity(0.04))),
          ),
          child: Row(
            children: [
              Icon(
                node.expanded
                    ? Icons.folder_open_rounded
                    : Icons.folder_rounded,
                color: _kAccent.withOpacity(0.55),
                size: 16,
              ),
              const SizedBox(width: 8),
              Text(node.name,
                style: const TextStyle(
                  color: Colors.white60,
                  fontSize: 12.5,
                  fontWeight: FontWeight.w600,
                )),
            ],
          ),
        ),
      );
    }
    return GestureDetector(
      onTap: node.selectable ? () => _toggleHtmlFile(node) : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: EdgeInsets.only(left: indent, right: 12, top: 9, bottom: 9),
        decoration: BoxDecoration(
          color: sel ? _kAccent.withOpacity(0.10) : Colors.transparent,
          border: Border(bottom: BorderSide(color: Colors.white.withOpacity(0.04))),
        ),
        child: Row(
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              width: 18,
              height: 18,
              decoration: BoxDecoration(
                color: sel ? _kAccent : Colors.transparent,
                borderRadius: BorderRadius.circular(5),
                border: Border.all(
                  color: node.selectable
                      ? _kAccent.withOpacity(sel ? 1.0 : 0.35)
                      : Colors.white12,
                  width: 1.5,
                ),
              ),
              child: sel
                  ? const Icon(Icons.check_rounded, size: 12, color: Colors.white)
                  : null,
            ),
            const SizedBox(width: 10),
            Icon(
              node.isHtmlFile
                  ? Icons.html_rounded
                  : Icons.insert_drive_file_rounded,
              size: 14,
              color: node.isHtmlFile
                  ? _kAccent.withOpacity(0.75)
                  : Colors.white.withOpacity(0.20),
            ),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                node.name,
                style: TextStyle(
                  color: node.selectable ? Colors.white : Colors.white30,
                  fontSize: 12.5,
                  fontFamily: 'monospace',
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            if (node.isHtmlFile)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: _kAccent.withOpacity(0.10),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: const Text('HTML',
                  style: TextStyle(
                    color: _kAccent, fontSize: 9, fontWeight: FontWeight.w800)),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildManualRunButton() {
    final canRun = _mZipPath != null &&
        _mSelected.isNotEmpty &&
        _keyCtrl.text.trim().isNotEmpty &&
        !_mProcessing;
    return GestureDetector(
      onTap: canRun ? _startManualBatch : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        height: 52,
        decoration: BoxDecoration(
          gradient: canRun
              ? LinearGradient(colors: [_kAccentGlow, _kAccent, _kAccentDim])
              : null,
          color: canRun ? null : Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: canRun ? _kAccent.withOpacity(0.6) : Colors.white12,
          ),
          boxShadow: canRun
              ? [BoxShadow(color: _kAccent.withOpacity(0.30), blurRadius: 16)]
              : [],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (_mProcessing)
              const SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(
                    color: Colors.white, strokeWidth: 2.2),
              )
            else
              Icon(Icons.security_rounded,
                  color: canRun ? Colors.white : Colors.white24, size: 18),
            const SizedBox(width: 10),
            Text(
              _mProcessing
                  ? 'Obfuscating…'
                  : _mSelected.isEmpty
                      ? 'Select at least one file'
                      : 'Obfuscate ${_mSelected.length} HTML file${_mSelected.length == 1 ? "" : "s"}',
              style: TextStyle(
                color: canRun ? Colors.white : Colors.white30,
                fontWeight: FontWeight.w800,
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildManualLog() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Icon(Icons.terminal_rounded, color: _kAccent, size: 15),
            const SizedBox(width: 6),
            const Text('TERMINAL',
              style: TextStyle(
                color: _kAccent, fontSize: 11,
                fontWeight: FontWeight.w700, letterSpacing: 2)),
            const Spacer(),
            GestureDetector(
              onTap: () => Clipboard.setData(ClipboardData(text: _mLog)),
              child: const Icon(Icons.copy_all_rounded,
                  color: Colors.white38, size: 16),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          height: 200,
          decoration: BoxDecoration(
            color: const Color(0xFF060606),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _kAccent.withOpacity(0.18), width: 1),
          ),
          child: NotificationListener<ScrollNotification>(
            onNotification: (n) {
              if (n is ScrollUpdateNotification) {
                final atBottom = _mLogScroll.position.pixels >=
                    _mLogScroll.position.maxScrollExtent - 30;
                if (_mAutoScroll != atBottom) setState(() => _mAutoScroll = atBottom);
              }
              return false;
            },
            child: SingleChildScrollView(
              controller: _mLogScroll,
              padding: const EdgeInsets.all(12),
              child: SelectableText(
                _mLog.isEmpty ? 'Waiting for output…' : _mLog,
                style: TextStyle(
                  fontFamily: 'monospace',
                  fontSize: 11,
                  color: _mLog.isEmpty
                      ? Colors.white24
                      : Colors.white.withOpacity(0.72),
                  height: 1.5,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildManualOutputActions() {
    return Row(
      children: [
        Expanded(
          child: _OutButton(
            label: 'Open Folder',
            icon: Icons.folder_open_rounded,
            color: _kAccent,
            onTap: () async {
              final dir = _mOutputFile != null
                  ? File(_mOutputFile!).parent.path
                  : _mOutputDir;
              if (dir == null) return;
              try {
                await const MethodChannel('com.taurus.shield/storage')
                    .invokeMethod('openFolder', {'path': dir});
              } catch (_) {}
            },
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _OutButton(
            label: 'Share',
            icon: Icons.share_rounded,
            color: _kAccentGlow,
            onTap: () async {
              if (_mOutputFile != null) {
                await Share.shareXFiles([XFile(_mOutputFile!)]);
              }
            },
          ),
        ),
      ],
    );
  }

  // ── Manual mode actions ───────────────────────────────────────────────────

  Future<void> _pickManualZip() async {
    final hasPerms =
        await PermissionHelper.ensureStorage(context, accent: _kAccent);
    if (!hasPerms) return;
    FilePickerResult? res;
    try {
      res = await FilePicker.platform.pickFiles(
        dialogTitle: 'Select ZIP file',
        type: FileType.custom,
        allowedExtensions: ['zip'],
      );
    } catch (_) {
      res = await FilePicker.platform.pickFiles(dialogTitle: 'Select ZIP file');
    }
    if (res == null || res.files.isEmpty) return;
    final f = res.files.first;
    if (f.path == null) return;
    if (!f.path!.toLowerCase().endsWith('.zip')) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(_snack('Please select a .zip file', isError: true));
      }
      return;
    }
    setState(() {
      _mZipPath    = f.path;
      _mZipName    = f.name;
      _mNodes      = [];
      _mSelected   = {};
      _mLog        = '';
      _mLogVisible = false;
      _mOutputDir  = null;
      _mOutputFile = null;
    });
    await _buildHtmlZipTree(f.path!);
  }

  Future<void> _buildHtmlZipTree(String zipPath) async {
    try {
      final bytes   = await File(zipPath).readAsBytes();
      final archive = ZipDecoder().decodeBytes(bytes);
      final dirPaths  = <String>{};
      final filePaths = <String>[];
      for (final entry in archive.files) {
        if (!entry.isFile) continue;
        filePaths.add(entry.name);
        final parts = entry.name.split('/');
        for (int i = 1; i < parts.length; i++) {
          dirPaths.add(parts.sublist(0, i).join('/'));
        }
      }
      final all = <String, bool>{};
      for (final d in dirPaths)  all[d] = true;
      for (final f in filePaths) all[f] = false;
      final sorted = all.keys.toList()..sort();
      final nodes = sorted.map((path) {
        final isDir = all[path]!;
        final depth = path.split('/').length - 1;
        return _HtmlZipNode(path: path, isDir: isDir, depth: depth);
      }).toList();
      if (mounted) setState(() { _mNodes = nodes; });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(_snack('Cannot read ZIP: $e', isError: true));
      }
    }
  }

  void _toggleFolder(_HtmlZipNode node) {
    final idx = _mNodes.indexOf(node);
    node.expanded = !node.expanded;
    final prefix = '${node.path}/';
    for (int i = idx + 1; i < _mNodes.length; i++) {
      final n = _mNodes[i];
      if (!n.path.startsWith(prefix)) break;
      if (n.depth == node.depth + 1) n.visible = node.expanded;
      else if (!node.expanded) n.visible = false;
      else {
        final parentPath = n.path.contains('/')
            ? n.path.substring(0, n.path.lastIndexOf('/'))
            : '';
        final parent =
            _mNodes.firstWhere((x) => x.path == parentPath, orElse: () => node);
        n.visible = parent.expanded;
      }
    }
    setState(() {});
  }

  void _toggleHtmlFile(_HtmlZipNode node) {
    if (!node.selectable) return;
    setState(() {
      if (_mSelected.contains(node.path)) {
        _mSelected.remove(node.path);
      } else {
        _mSelected.add(node.path);
      }
    });
  }

  Future<void> _startManualBatch() async {
    if (_mZipPath == null || _mSelected.isEmpty) return;
    final key = _keyCtrl.text.trim();
    if (key.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(_snack('Enter a SubZero key first', isError: true));
      return;
    }
    if (_mProcessing) return;

    final isRunning = (await HbcChannel.jsEncryptorBatchState())['running'] == true;
    if (isRunning) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(_snack('Already processing — please wait', isError: true));
      }
      return;
    }

    final outDir = await StorageHelper.buildOutputDir(prefix: 'htmlenc_batch');
    await HbcChannel.jsEncryptorBatchClearState();

    final tasks = _mSelected.map((path) => {
      'path':   path,
      'method': 'subzero',
      'szKey':  key,
    }).toList();

    await HbcChannel.jsEncryptorBatchAnalyze(
      zipPath:   _mZipPath!,
      zipName:   _mZipName ?? 'batch.zip',
      outputDir: outDir,
      tasksJson: jsonEncode(tasks),
    );

    setState(() {
      _mProcessing = true;
      _mLogVisible = true;
      _mLog        = '';
      _mOutputDir  = outDir;
      _mOutputFile = null;
    });
    _startManualPoll();

    // Persist session so the screen restores if the app is killed mid-job.
    await SessionState.saveLastTool('htmlencryptor');
    await SessionState.save(
      filePath: _mZipPath,
      outputDir: outDir,
      isProcessing: true,
    );
  }

  void _startManualPoll() {
    _mPollTimer?.cancel();
    _mPollTimer = Timer.periodic(const Duration(seconds: 2), (_) async {
      final state = await HbcChannel.jsEncryptorBatchState();
      if (!mounted) return;
      final log = (state['log'] as String?) ?? '';
      setState(() { _mLog = log; });
      if (_mAutoScroll && _mLogScroll.hasClients) {
        _mLogScroll.animateTo(
          _mLogScroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
      if (state['running'] != true) {
        _mPollTimer?.cancel();
        setState(() {
          _mProcessing = false;
          _mLog        = (state['log'] as String?) ?? '';
          _mOutputDir  = state['outputDir'] as String?;
          _mOutputFile = state['outputFile'] as String?;
          _mLogVisible = _mLog.isNotEmpty;
        });
        // Job finished — clear session so the screen won't auto-reopen next launch.
        SessionState.clear();
        SessionState.clearLastTool();
      }
    });
  }
}

// ── Output button ─────────────────────────────────────────────────────────────
class _OutButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _OutButton({required this.label, required this.icon,
      required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 44,
        decoration: BoxDecoration(
          color: color.withOpacity(0.10),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.30), width: 1),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 16),
            const SizedBox(width: 6),
            Text(label,
                style: TextStyle(
                    color: color,
                    fontWeight: FontWeight.w700,
                    fontSize: 13)),
          ],
        ),
      ),
    );
  }
}

// ── Orbit arc painter ─────────────────────────────────────────────────────────
class _HtmlOrbitPainter extends CustomPainter {
  final Color  color;
  final double opacity;
  final double angle;
  const _HtmlOrbitPainter({required this.color, required this.opacity, required this.angle});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r  = size.width / 2 - 2;
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4
      ..strokeCap = StrokeCap.round;

    const offsets = [0.0, 0.38, 0.70];
    for (int i = 0; i < offsets.length; i++) {
      final start = offsets[i] * 2 * math.pi + angle;
      paint.color = color.withOpacity(opacity * (1.0 - i * 0.2));
      canvas.drawArc(
        Rect.fromCircle(center: Offset(cx, cy), radius: r),
        start,
        0.22 * 2 * math.pi,
        false,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(_HtmlOrbitPainter o) =>
      o.color != color || o.opacity != opacity || o.angle != angle;
}

// ── Dot ring painter ──────────────────────────────────────────────────────────
class _HtmlDotPainter extends CustomPainter {
  final Color  color;
  final double opacity;
  final double angle;
  const _HtmlDotPainter({required this.color, required this.opacity, required this.angle});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r  = size.width / 2 - 2;
    final paint = Paint()
      ..style = PaintingStyle.fill
      ..color = color.withOpacity(opacity);

    const count = 6;
    for (int i = 0; i < count; i++) {
      final a = (i / count) * 2 * math.pi + angle;
      canvas.drawCircle(
        Offset(cx + r * math.cos(a), cy + r * math.sin(a)),
        1.8,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(_HtmlDotPainter o) =>
      o.color != color || o.opacity != opacity || o.angle != angle;
}
