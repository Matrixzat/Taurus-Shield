import '../utils/theme_provider.dart';
import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import '../data/changelog_data.dart';

class ChangelogScreen extends StatefulWidget {
  const ChangelogScreen({super.key});

  @override
  State<ChangelogScreen> createState() => _ChangelogScreenState();
}

class _ChangelogScreenState extends State<ChangelogScreen> {
  String _version = '';
  String _build   = '';

  @override
  void initState() {
    super.initState();
    PackageInfo.fromPlatform().then((info) {
      if (mounted) {
        setState(() {
          _version = info.version;
          _build   = info.buildNumber;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      appBar: AppBar(
        
        title: const Text(
          'Changelog',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.2,
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        elevation: 0,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            color: ThemeProvider().current.primary.withOpacity(0.25),
          ),
        ),
      ),
      body: ListView.separated(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
        itemCount: kChangelog.length,
        separatorBuilder: (_, __) => const SizedBox(height: 16),
        itemBuilder: (context, index) {
          final entry    = kChangelog[index];
          final isLatest = index == 0;

          // Replace 'current' sentinel with the real version from pubspec
          final displayVersion = (entry.version == 'current' && _version.isNotEmpty)
              ? _version
              : entry.version == 'current'
                  ? '...'
                  : entry.version;

          final displayBuild = isLatest && _build.isNotEmpty ? _build : '';

          return _VersionCard(
            entry: entry,
            displayVersion: displayVersion,
            displayBuild: displayBuild,
            isLatest: isLatest,
          );
        },
      ),
    );
  }
}

// ── Version card ───────────────────────────────────────────────────────────────

class _VersionCard extends StatelessWidget {
  final ChangelogEntry entry;
  final String displayVersion;
  final String displayBuild;
  final bool isLatest;

  const _VersionCard({
    required this.entry,
    required this.displayVersion,
    required this.displayBuild,
    required this.isLatest,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Color(0xFF12102a),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isLatest
              ? ThemeProvider().current.primary.withOpacity(0.50)
              : ThemeProvider().current.borderColor,
          width: isLatest ? 1.5 : 1,
        ),
        boxShadow: isLatest
            ? [
                BoxShadow(
                  color: ThemeProvider().current.primary.withOpacity(0.10),
                  blurRadius: 16,
                  offset: const Offset(0, 4),
                ),
              ]
            : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header row
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
            child: Row(
              children: [
                // Version pill
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    gradient: isLatest
                        ? LinearGradient(
                            colors: [ThemeProvider().current.primary, Color(0xFF4f1fa0)])
                        : null,
                    color: isLatest ? null : const Color(0xFF1e1a3a),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    'v$displayVersion',
                    style: TextStyle(
                      color: isLatest ? Colors.white : ThemeProvider().current.secondary,
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
                // Build number badge
                if (displayBuild.isNotEmpty) ...[
                  const SizedBox(width: 6),
                  Text(
                    'build $displayBuild',
                    style: const TextStyle(
                      color: Color(0xFF6b7280),
                      fontSize: 10,
                    ),
                  ),
                ],
                // Latest badge
                if (isLatest) ...[
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                    decoration: BoxDecoration(
                      color: const Color(0xFF22c55e).withOpacity(0.15),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(
                          color: const Color(0xFF22c55e).withOpacity(0.40)),
                    ),
                    child: const Text(
                      'LATEST',
                      style: TextStyle(
                        color: Color(0xFF22c55e),
                        fontSize: 9,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                ],
                const Spacer(),
                Text(
                  entry.date,
                  style: const TextStyle(color: Color(0xFF6b7280), fontSize: 11),
                ),
              ],
            ),
          ),
          const Divider(
              height: 1, color: Color(0xFF1e1a3a), indent: 16, endIndent: 16),
          // Items
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: entry.items.map((item) => _ChangelogRow(item: item)).toList(),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Changelog row ──────────────────────────────────────────────────────────────

class _ChangelogRow extends StatelessWidget {
  final ChangelogItem item;
  const _ChangelogRow({required this.item});

  @override
  Widget build(BuildContext context) {
    final (color, label) = switch (item.tag) {
      ChangelogTag.added    => (Color(0xFF22c55e), 'NEW'),
      ChangelogTag.improved => (ThemeProvider().current.highlightColor, 'IMP'),
      ChangelogTag.fixed    => (const Color(0xFFf59e0b), 'FIX'),
      ChangelogTag.removed  => (const Color(0xFFef4444), 'REM'),
    };

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 34,
            padding: const EdgeInsets.symmetric(vertical: 2),
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(5),
              border: Border.all(color: color.withOpacity(0.30)),
            ),
            alignment: Alignment.center,
            child: Text(
              label,
              style: TextStyle(
                color: color,
                fontSize: 8,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.5,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              item.text,
              style: const TextStyle(
                color: Color(0xFFd1d5db),
                fontSize: 13,
                height: 1.4,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
