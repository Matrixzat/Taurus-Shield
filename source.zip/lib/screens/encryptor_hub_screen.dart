import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../utils/session_state.dart';
import 'html_encryptor_screen.dart';
import 'js_encryptor_screen.dart';
import 'php_method_hub_screen.dart';

// ── Change this one constant when the user picks a name ──────────────────────
const _kHubName = 'ACM Files Encryptor';

const _kRed = Color(0xFFFF0A0A);

// ── Real official brand icon asset paths (devicons, downloaded) ───────────────
const _assetHtml5 = 'assets/icon/html5.svg';
const _assetJs    = 'assets/icon/javascript.svg';
const _assetPhp   = 'assets/icon/php.svg';

// ── Animated count-up badge ───────────────────────────────────────────────────

class _CountUp extends StatefulWidget {
  final int target;
  final Color color;
  final Duration delay;
  const _CountUp({required this.target, required this.color, required this.delay});

  @override
  State<_CountUp> createState() => _CountUpState();
}

class _CountUpState extends State<_CountUp> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400));
    _anim = CurvedAnimation(parent: _ctrl, curve: Curves.easeOutExpo);
    Future.delayed(widget.delay, () { if (mounted) _ctrl.forward(); });
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _anim,
      builder: (_, __) {
        final v = (_anim.value * widget.target).round();
        return Text(
          '$v',
          style: TextStyle(
            fontSize: 52,
            fontWeight: FontWeight.w900,
            color: widget.color,
            letterSpacing: -2,
            height: 1,
          ),
        );
      },
    );
  }
}

// ── Pulsing glow icon ─────────────────────────────────────────────────────────

class _GlowIcon extends StatefulWidget {
  final String assetPath;
  final Color glow;
  const _GlowIcon({required this.assetPath, required this.glow});

  @override
  State<_GlowIcon> createState() => _GlowIconState();
}

class _GlowIconState extends State<_GlowIcon> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 2200))
      ..repeat(reverse: true);
    _anim = CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut);
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _anim,
      builder: (_, child) => Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: widget.glow.withOpacity(0.15 + 0.35 * _anim.value),
              blurRadius:  24 + 24 * _anim.value,
              spreadRadius: 2 + 6 * _anim.value,
            ),
          ],
        ),
        child: child,
      ),
      child: SvgPicture.asset(widget.assetPath, width: 88, height: 88),
    );
  }
}

// ── Rotating orbit ring (decorative) ─────────────────────────────────────────

class _OrbitRing extends StatefulWidget {
  final Color color;
  final double size;
  final Duration period;
  final bool reverse;
  const _OrbitRing({required this.color, required this.size, required this.period, this.reverse = false});

  @override
  State<_OrbitRing> createState() => _OrbitRingState();
}

class _OrbitRingState extends State<_OrbitRing> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: widget.period)..repeat();
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) {
        final angle = (widget.reverse ? -_ctrl.value : _ctrl.value) * 2 * math.pi;
        return SizedBox.square(
          dimension: widget.size,
          child: CustomPaint(
            painter: _RingPainter(angle: angle, color: widget.color),
          ),
        );
      },
    );
  }
}

class _RingPainter extends CustomPainter {
  final double angle;
  final Color color;
  const _RingPainter({required this.angle, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r  = size.width / 2 - 4;

    final paint = Paint()
      ..color = color.withOpacity(0.15)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    canvas.drawCircle(Offset(cx, cy), r, paint);

    final dotPaint = Paint()..color = color.withOpacity(0.9);
    canvas.drawCircle(
      Offset(cx + r * math.cos(angle), cy + r * math.sin(angle)),
      3.5,
      dotPaint,
    );
  }

  @override
  bool shouldRepaint(_RingPainter o) => o.angle != angle;
}

// ── Single language card ──────────────────────────────────────────────────────

class _LangCard extends StatefulWidget {
  final String name;
  final String tagline;
  final String description;
  final Color accent;
  final int methodCount;
  final String assetPath;
  final List<String> chips;
  final int delayMs;
  final VoidCallback onTap;
  const _LangCard({
    required this.name,
    required this.tagline,
    required this.description,
    required this.accent,
    required this.methodCount,
    required this.assetPath,
    required this.chips,
    required this.delayMs,
    required this.onTap,
  });

  @override
  State<_LangCard> createState() => _LangCardState();
}

class _LangCardState extends State<_LangCard> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<Offset> _slide;
  late final Animation<double>  _fade;
  bool _pressed = false;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 650));
    _slide = Tween<Offset>(begin: const Offset(0, 0.25), end: Offset.zero)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    _fade  = CurvedAnimation(parent: _ctrl, curve: Curves.easeIn);
    Future.delayed(Duration(milliseconds: widget.delayMs), () {
      if (mounted) _ctrl.forward();
    });
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(
        position: _slide,
        child: GestureDetector(
          onTapDown:   (_) => setState(() => _pressed = true),
          onTapUp:     (_) => setState(() => _pressed = false),
          onTapCancel: ()  => setState(() => _pressed = false),
          onTap:       widget.onTap,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 120),
            transform: Matrix4.identity()..scale(_pressed ? 0.975 : 1.0),
            transformAlignment: Alignment.center,
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: const Color(0xFF080808),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(
                color: widget.accent.withOpacity(_pressed ? 0.7 : 0.28),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: widget.accent.withOpacity(_pressed ? 0.25 : 0.08),
                  blurRadius: 28,
                  spreadRadius: _pressed ? 3 : 0,
                ),
              ],
            ),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 16),
              child: Column(
                children: [
                  // ── Icon + orbit rings ────────────────────────────────────
                  SizedBox(
                    width: 108,
                    height: 108,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        _OrbitRing(color: widget.accent, size: 100, period: const Duration(seconds: 6)),
                        _OrbitRing(color: widget.accent, size: 82, period: const Duration(seconds: 4), reverse: true),
                        _GlowIcon(assetPath: widget.assetPath, glow: widget.accent),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  // ── Count ─────────────────────────────────────────────────
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      _CountUp(
                        target: widget.methodCount,
                        color: widget.accent,
                        delay: Duration(milliseconds: widget.delayMs + 300),
                      ),
                      const SizedBox(width: 8),
                      Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Text(
                          widget.methodCount == 1 ? 'METHOD' : 'METHODS',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                            color: widget.accent.withOpacity(0.65),
                            letterSpacing: 2,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  // ── Language name ─────────────────────────────────────────
                  Text(
                    widget.name,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(height: 4),
                  // ── Tagline ───────────────────────────────────────────────
                  Text(
                    widget.tagline,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 12.5,
                      color: Colors.white.withOpacity(0.45),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 8),
                  // ── Description ───────────────────────────────────────────
                  Text(
                    widget.description,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 12,
                      color: Colors.white,
                      height: 1.6,
                    ),
                  ),
                  const SizedBox(height: 10),
                  // ── Chips ─────────────────────────────────────────────────
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    alignment: WrapAlignment.center,
                    children: widget.chips.map((chip) => Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: widget.accent.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: widget.accent.withOpacity(0.25), width: 1),
                      ),
                      child: Text(
                        chip,
                        style: TextStyle(
                          fontSize: 11,
                          color: widget.accent.withOpacity(0.85),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    )).toList(),
                  ),
                  const SizedBox(height: 10),
                  Divider(color: widget.accent.withOpacity(0.15), height: 1),
                  const SizedBox(height: 10),
                  // ── Explore CTA ───────────────────────────────────────────
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'TAP TO EXPLORE',
                        style: TextStyle(
                          fontSize: 10.5,
                          color: widget.accent,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 2.5,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Icon(Icons.arrow_forward_ios_rounded, size: 10, color: widget.accent),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ── Hub screen ────────────────────────────────────────────────────────────────

class EncryptorHubScreen extends StatelessWidget {
  const EncryptorHubScreen({super.key});

  Future<void> _go(BuildContext ctx, Widget screen, String key) async {
    await SessionState.saveLastTool(key);
    if (!ctx.mounted) return;
    Navigator.push(ctx, MaterialPageRoute(builder: (_) => screen));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded, color: Colors.white, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          _kHubName,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w800,
            fontSize: 18,
            letterSpacing: 0.5,
          ),
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 14, top: 10, bottom: 10),
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              color: _kRed.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _kRed.withOpacity(0.35), width: 1),
            ),
            alignment: Alignment.center,
            child: const Text(
              'MULTI-LANG',
              style: TextStyle(
                fontSize: 9.5,
                color: Colors.white,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.5,
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Header ────────────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'CODE OBFUSCATION',
                    style: TextStyle(
                      fontSize: 11,
                      color: _kRed.withOpacity(0.9),
                      fontWeight: FontWeight.w700,
                      letterSpacing: 2.5,
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'Multi-Language\nProtection Engine',
                    style: TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      height: 1.15,
                      letterSpacing: -0.5,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'HTML · JavaScript · PHP — three languages, one unified obfuscation suite.',
                    style: TextStyle(
                      fontSize: 12.5,
                      color: Colors.white.withOpacity(0.38),
                      height: 1.5,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),

            // ── Language cards ────────────────────────────────────────────
            _LangCard(
              name: 'HTML',
              tagline: 'Self-decrypting HTML shell obfuscation',
              description:
                  'Wraps your HTML inside a password-protected self-decrypting shell. '
                  'Source code is fully hidden from static analysis and devtools inspection.',
              accent: const Color(0xFFE44D26),
              methodCount: 1,
              assetPath: _assetHtml5,
              chips: const ['.html', '.htm', '.zip', 'subzero', 'self-decrypt'],
              delayMs: 80,
              onTap: () => _go(context, const HtmlEncryptorScreen(), 'htmlencryptor'),
            ),

            _LangCard(
              name: 'JavaScript',
              tagline: 'Fortress multi-method JS obfuscation engine',
              description:
                  'Fifteen hardened obfuscation methods — identifier mangling, control-flow '
                  'flattening, string encryption, Unicode identifiers, and built-in decrypt.',
              accent: const Color(0xFFF0DB4F),
              methodCount: 15,
              assetPath: _assetJs,
              chips: const ['.js', '.html', '.zip', 'CFF', 'string-enc', 'decrypt'],
              delayMs: 230,
              onTap: () => _go(context, const JsEncryptorScreen(), 'jsencryptor'),
            ),

            _LangCard(
              name: 'PHP',
              tagline: 'Two cloud PHP obfuscation engines',
              description:
                  'Cloud eval+base64 obfuscation and Alom CI cluster obfuscation — '
                  'two distinct PHP engines. Supports single .php files and full .zip projects.',
              accent: const Color(0xFF7C9FD4),
              methodCount: 2,
              assetPath: _assetPhp,
              chips: const ['.php', '.zip', 'eval', 'base64', 'alom', 'cloud'],
              delayMs: 380,
              onTap: () => _go(context, const PhpMethodHubScreen(), 'phpencryptor'),
            ),

            const SizedBox(height: 36),
          ],
        ),
      ),
    );
  }
}
