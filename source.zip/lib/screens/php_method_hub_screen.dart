import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../utils/session_state.dart';
import 'php_encryptor_screen.dart';

const _assetPhp = 'assets/icon/php.svg';

// ── Pulsing glow icon ─────────────────────────────────────────────────────────

class _GlowIcon extends StatefulWidget {
  final String assetPath;
  final Color glow;
  const _GlowIcon({required this.assetPath, required this.glow});

  @override
  State<_GlowIcon> createState() => _GlowIconState();
}

class _GlowIconState extends State<_GlowIcon>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2200))
      ..repeat(reverse: true);
    _anim = CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _anim,
      builder: (_, __) => Container(
        width: 64,
        height: 64,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: widget.glow.withOpacity(0.15 + 0.25 * _anim.value),
              blurRadius: 22 + 16 * _anim.value,
              spreadRadius: 2 + 4 * _anim.value,
            ),
          ],
        ),
        child: SvgPicture.asset(widget.assetPath, width: 64, height: 64),
      ),
    );
  }
}

// ── Orbit ring ────────────────────────────────────────────────────────────────

class _OrbitRing extends StatefulWidget {
  final Color color;
  final double size;
  final Duration period;
  final bool reverse;
  const _OrbitRing(
      {required this.color,
      required this.size,
      required this.period,
      this.reverse = false});

  @override
  State<_OrbitRing> createState() => _OrbitRingState();
}

class _OrbitRingState extends State<_OrbitRing>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl =
        AnimationController(vsync: this, duration: widget.period)..repeat();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, child) {
        final angle =
            (widget.reverse ? -1 : 1) * _ctrl.value * 2 * math.pi;
        return Transform.rotate(
          angle: angle,
          child: child,
        );
      },
      child: SizedBox(
        width: widget.size,
        height: widget.size,
        child: CustomPaint(
          painter: _RingPainter(color: widget.color),
        ),
      ),
    );
  }
}

class _RingPainter extends CustomPainter {
  final Color color;
  const _RingPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withOpacity(0.22)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;
    canvas.drawOval(
      Rect.fromLTWH(0, size.height * 0.28, size.width, size.height * 0.44),
      paint,
    );
    final dotPaint = Paint()..color = color.withOpacity(0.7);
    canvas.drawCircle(Offset(size.width, size.height * 0.5), 2.5, dotPaint);
  }

  @override
  bool shouldRepaint(_RingPainter old) => false;
}

// ── Method card ───────────────────────────────────────────────────────────────

class _MethodCard extends StatefulWidget {
  final int index;
  final String name;
  final String tagline;
  final String description;
  final Color accent;
  final List<String> chips;
  final int delayMs;
  final VoidCallback onTap;

  const _MethodCard({
    required this.index,
    required this.name,
    required this.tagline,
    required this.description,
    required this.accent,
    required this.chips,
    required this.delayMs,
    required this.onTap,
  });

  @override
  State<_MethodCard> createState() => _MethodCardState();
}

class _MethodCardState extends State<_MethodCard>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<Offset> _slide;
  late final Animation<double> _fade;
  bool _pressed = false;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 650));
    _slide = Tween<Offset>(begin: const Offset(0, 0.25), end: Offset.zero)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeIn);
    Future.delayed(Duration(milliseconds: widget.delayMs), () {
      if (mounted) _ctrl.forward();
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(
        position: _slide,
        child: GestureDetector(
          onTapDown: (_) => setState(() => _pressed = true),
          onTapUp: (_) => setState(() => _pressed = false),
          onTapCancel: () => setState(() => _pressed = false),
          onTap: widget.onTap,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 120),
            transform: Matrix4.identity()..scale(_pressed ? 0.975 : 1.0),
            transformAlignment: Alignment.center,
            margin:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: const Color(0xFF080808),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(
                color: widget.accent.withOpacity(_pressed ? 0.7 : 0.28),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color:
                      widget.accent.withOpacity(_pressed ? 0.25 : 0.08),
                  blurRadius: 28,
                  spreadRadius: _pressed ? 3 : 0,
                ),
              ],
            ),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 16),
              child: Column(
                children: [
                  // ── Icon + orbit rings ──────────────────────────────────
                  SizedBox(
                    width: 108,
                    height: 108,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        _OrbitRing(
                            color: widget.accent,
                            size: 100,
                            period: const Duration(seconds: 6)),
                        _OrbitRing(
                            color: widget.accent,
                            size: 82,
                            period: const Duration(seconds: 4),
                            reverse: true),
                        _GlowIcon(
                            assetPath: _assetPhp, glow: widget.accent),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  // ── Method number badge ─────────────────────────────────
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        '${widget.index}',
                        style: TextStyle(
                          fontSize: 52,
                          fontWeight: FontWeight.w900,
                          color: widget.accent,
                          letterSpacing: -2,
                          height: 1,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Text(
                          'METHOD',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                            color: widget.accent.withOpacity(0.65),
                            letterSpacing: 2,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  // ── Name ────────────────────────────────────────────────
                  Text(
                    widget.name,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(height: 4),
                  // ── Tagline ─────────────────────────────────────────────
                  Text(
                    widget.tagline,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 12.5,
                      color: Colors.white.withOpacity(0.45),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 8),
                  // ── Description ─────────────────────────────────────────
                  Text(
                    widget.description,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 12,
                      color: Colors.white,
                      height: 1.6,
                    ),
                  ),
                  const SizedBox(height: 10),
                  // ── Chips ────────────────────────────────────────────────
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    alignment: WrapAlignment.center,
                    children: widget.chips
                        .map((chip) => Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: widget.accent.withOpacity(0.08),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                    color: widget.accent.withOpacity(0.25),
                                    width: 1),
                              ),
                              child: Text(
                                chip,
                                style: TextStyle(
                                  fontSize: 11,
                                  color: widget.accent.withOpacity(0.85),
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ))
                        .toList(),
                  ),
                  const SizedBox(height: 10),
                  Divider(
                      color: widget.accent.withOpacity(0.15), height: 1),
                  const SizedBox(height: 10),
                  // ── CTA ──────────────────────────────────────────────────
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'TAP TO USE',
                        style: TextStyle(
                          fontSize: 10.5,
                          color: widget.accent,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 2.5,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Icon(Icons.arrow_forward_ios_rounded,
                          size: 10, color: widget.accent),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ── PHP Method Hub Screen ─────────────────────────────────────────────────────

class PhpMethodHubScreen extends StatelessWidget {
  const PhpMethodHubScreen({super.key});

  Future<void> _go(BuildContext ctx, Widget screen, String key) async {
    await SessionState.saveLastTool(key);
    if (!ctx.mounted) return;
    Navigator.push(ctx, MaterialPageRoute(builder: (_) => screen));
  }

  @override
  Widget build(BuildContext context) {
    const kBlue   = Color(0xFF7C9FD4);
    const kPurple = Color(0xFF9B59B6);
    const kRed    = Color(0xFFFF0A0A);

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded,
              color: Colors.white, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'PHP Obfuscator',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w800,
            fontSize: 18,
            letterSpacing: 0.5,
          ),
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 14, top: 10, bottom: 10),
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              color: kRed.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: kRed.withOpacity(0.35), width: 1),
            ),
            alignment: Alignment.center,
            child: const Text(
              '2 METHODS',
              style: TextStyle(
                fontSize: 9.5,
                color: Colors.white,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.5,
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'PHP OBFUSCATION',
                    style: TextStyle(
                      fontSize: 11,
                      color: kRed.withOpacity(0.9),
                      fontWeight: FontWeight.w700,
                      letterSpacing: 2.5,
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'Choose Your\nPHP Method',
                    style: TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      height: 1.15,
                      letterSpacing: -0.5,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Two distinct PHP obfuscation engines — cloud eval+base64 or Alom CI cluster.',
                    style: TextStyle(
                      fontSize: 12.5,
                      color: Colors.white.withOpacity(0.38),
                      height: 1.5,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),

            // ── Method 1: Standard PHP ──────────────────────────────────────
            _MethodCard(
              index: 1,
              name: 'PHP Cloud',
              tagline: 'eval(base64_decode) cloud obfuscation',
              description:
                  'Obfuscates PHP source via a secure cloud session. '
                  'Produces eval+base64 payloads. Supports single .php files '
                  'and full .zip projects.',
              accent: kBlue,
              chips: const ['.php', '.zip', 'eval', 'base64', 'cloud'],
              delayMs: 80,
              onTap: () => _go(
                  context, const PhpEncryptorScreen(), 'phpencryptor'),
            ),

            // ── Method 2: Alom ──────────────────────────────────────────────
            _MethodCard(
              index: 2,
              name: 'PHP Alom',
              tagline: 'Secure cloud Alom cluster obfuscation',
              description:
                  'Runs your PHP files through the Alom obfuscator on a '
                  'dedicated secure cloud cluster. Configurable depth (1–3). '
                  'Supports single .php files and full .zip projects. '
                  'Runs fully in the background.',
              accent: kPurple,
              chips: const ['.php', '.zip', 'alom', 'depth', 'CI', 'background'],
              delayMs: 230,
              onTap: () => _go(context,
                  const PhpEncryptorScreen(initialAlomMode: true),
                  'phpencryptor'),
            ),

            const SizedBox(height: 36),
          ],
        ),
      ),
    );
  }
}
