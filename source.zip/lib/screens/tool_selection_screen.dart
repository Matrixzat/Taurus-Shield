import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../widgets/app_drawer.dart';
import '../utils/session_state.dart';
import '../utils/permission_helper.dart';
import '../utils/theme_provider.dart';
import '../services/update_service.dart';
import 'home_screen.dart';
import 'blutter_screen.dart';
import 'dex2c_screen.dart';
import 'dptshell_screen.dart';
import 'vm_protect_screen.dart';
import 'apktool_screen.dart';
import 'apks_convert_screen.dart';
import 'html_encryptor_screen.dart';
import 'js_encryptor_screen.dart';
import 'encryptor_hub_screen.dart';
import 'php_encryptor_screen.dart';
import 'ads_patch_screen.dart';

import 'reflutter_screen.dart';
import 'anti_dialog_screen.dart';
import 'cloudflare_screen.dart';
import 'github_manager_screen.dart';
import 'logcat_screen.dart';
import 'black_forge_screen.dart';
import 'web_apk_screen.dart';
import 'pinehook_screen.dart';
import 'ssl_unpinner_screen.dart';
import 'admin_panel_screen.dart';
import 'dex_tools_hub_screen.dart';
import 'how_it_works_screen.dart';
import 'upload_screen.dart';
import 'mod_engine_screen.dart';
import 'cocos_screen.dart';

enum _IconAnim { pulse, spin, glow }

class ToolSelectionScreen extends StatefulWidget {
  const ToolSelectionScreen({super.key});

  @override
  State<ToolSelectionScreen> createState() => _ToolSelectionScreenState();
}

class _ToolSelectionScreenState extends State<ToolSelectionScreen>
    with TickerProviderStateMixin {
  late final AnimationController _pulseCtrl;
  late final AnimationController _cardCtrl;
  late final Animation<double> _pulse;
  late final Animation<double> _cardFade;
  late final Animation<Offset> _cardSlide;

  final ScrollController _scrollCtrl = ScrollController();
  final TextEditingController _searchCtrl = TextEditingController();
  String _searchQuery = '';
  bool _showScrollDown = false;
  bool _showScrollUp = false;
  bool _hasScrolled = false;

  DateTime? _lastBackPress;

  @override
  void initState() {
    super.initState();
    _scrollCtrl.addListener(_onScroll);
    _searchCtrl.addListener(() {
      setState(() => _searchQuery = _searchCtrl.text.toLowerCase().trim());
    });

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _cardCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    )..forward();

    _pulse = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );

    _cardFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _cardCtrl, curve: Curves.easeOut),
    );

    _cardSlide = Tween<Offset>(
      begin: const Offset(0, 0.12),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _cardCtrl, curve: Curves.easeOutCubic));

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await PermissionHelper.checkStartup(context);
      if (mounted) {
        await UpdateService.checkAndPrompt(context);
        if (mounted) UpdateService.showPendingNotification(context);
      }
      // If the user was mid-session in a tool when the app was killed,
      // restore them to that tool automatically.
      if (mounted) await _restoreActiveSession();
      if (mounted) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_scrollCtrl.hasClients) _onScroll();
        });
      }
    });
  }

  /// Stateless tools have no file/outputDir session but should still be
  /// restored — they persist purely via the lastTool key.
  static const _kStatelessTools = {
    'blackforge', 'cloudflare', 'github', 'webapk',
    'encryptorhub', 'phpencryptor', 'videocompressor',
  };

  static const _kWebApkChannel = MethodChannel('com.taurus.shield/webapk');

  /// Restore the last-open screen on app launch.
  /// • Stateless tools (no file session) are always restored.
  /// • Web2Apk is always restored (stateless — user always returns to it).
  /// • File-based tools are only restored when a session exists.
  Future<void> _restoreActiveSession() async {
    final last = await SessionState.loadLastTool();

    // Always restore stateless utility tools
    if (last != null && _kStatelessTools.contains(last)) {
      if (!mounted) return;
      await _restoreLastTool();
      return;
    }

    // Logcat: never auto-redirect — always clear and stay on home.
    if (last == 'logcat') {
      await SessionState.clearLastTool();
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('lc_session_active', false);
      return;
    }

    // File-based tools: only restore when an active session exists
    final session = await SessionState.load();
    final outputDir = session['outputDir'] as String?;
    final filePath  = session['filePath']  as String?;
    final hasSession = (outputDir != null && outputDir.isNotEmpty) ||
                       (filePath  != null && filePath.isNotEmpty);
    if (!hasSession) return;
    if (!mounted) return;
    await _restoreLastTool();
  }

  Future<void> _restoreLastTool() async {
    final last = await SessionState.loadLastTool();
    if (!mounted) return;
    if (last == 'hbc') {
      Navigator.push(
          context, MaterialPageRoute(builder: (_) => const HomeScreen()));
    } else if (last == 'blutter') {
      Navigator.push(
          context, MaterialPageRoute(builder: (_) => const BlutterScreen()));
    } else if (last == 'dex2c') {
      Navigator.push(
          context, MaterialPageRoute(builder: (_) => const Dex2CScreen()));
    } else if (last == 'upload') {
      Navigator.push(
          context, MaterialPageRoute(builder: (_) => const UploadScreen()));
    } else if (last == 'dptshell') {
      Navigator.push(
          context, MaterialPageRoute(builder: (_) => const DptShellScreen()));
    } else if (last == 'vmprotect') {
      Navigator.push(
          context, MaterialPageRoute(builder: (_) => const VmProtectScreen()));
    } else if (last == 'apktool') {
      Navigator.push(
          context, MaterialPageRoute(builder: (_) => const ApkToolScreen()));
    } else if (last == 'jsencryptor') {
      Navigator.push(
          context, MaterialPageRoute(builder: (_) => const JsEncryptorScreen()));
    } else if (last == 'adspatch') {
      Navigator.push(
          context, MaterialPageRoute(builder: (_) => const AdsPatchScreen()));
    } else if (last == 'reflutter') {
      Navigator.push(
          context, MaterialPageRoute(builder: (_) => const ReFlutterScreen()));
    } else if (last == 'cloudflare') {
      Navigator.push(
          context, MaterialPageRoute(builder: (_) => const CloudflareScreen()));
    } else if (last == 'github') {
      Navigator.push(
          context, MaterialPageRoute(builder: (_) => const GitHubManagerScreen()));
    } else if (last == 'logcat') {
      Navigator.push(
          context, MaterialPageRoute(builder: (_) => const LogcatScreen()));
    } else if (last == 'blackforge') {
      Navigator.push(
          context, MaterialPageRoute(builder: (_) => const BlackForgeScreen()));
    } else if (last == 'webapk') {
      Navigator.push(
          context, MaterialPageRoute(builder: (_) => const WebApkScreen()));
    } else if (last == 'encryptorhub') {
      Navigator.push(
          context, MaterialPageRoute(builder: (_) => const EncryptorHubScreen()));
    } else if (last == 'phpencryptor') {
      Navigator.push(
          context, MaterialPageRoute(builder: (_) => const PhpEncryptorScreen()));
    } else if (last == 'htmlencryptor') {
      Navigator.push(
          context, MaterialPageRoute(builder: (_) => const HtmlEncryptorScreen()));
    } else if (last == 'sslunpin') {
      Navigator.push(
          context, MaterialPageRoute(builder: (_) => const SslUnpinnerScreen()));
    } else if (last == 'modengine') {
      Navigator.push(
          context, MaterialPageRoute(builder: (_) => const ModEngineScreen()));
    }
  }

  Future<void> _navigateTo(Widget screen, String toolKey) async {
    await SessionState.saveLastTool(toolKey);
    if (!mounted) return;
    await Navigator.push(
        context, MaterialPageRoute(builder: (_) => screen));
  }

  void _onScroll() {
    final pos = _scrollCtrl.position;
    if (!_hasScrolled && pos.pixels > 5) {
      _hasScrolled = true;
    }
    if (!_hasScrolled) return;

    final atTop = pos.pixels <= 50;
    final atBottom = pos.pixels >= pos.maxScrollExtent - 50;
    final newUp = !atTop;
    final newDown = !atBottom;
    if (newDown != _showScrollDown || newUp != _showScrollUp) {
      setState(() {
        _showScrollDown = newDown;
        _showScrollUp = newUp;
      });
    }
  }

  @override
  void dispose() {
    _scrollCtrl.dispose();
    _searchCtrl.dispose();
    _pulseCtrl.dispose();
    _cardCtrl.dispose();
    super.dispose();
  }

  Future<bool> _onWillPop() async {
    final now = DateTime.now();
    if (_lastBackPress == null ||
        now.difference(_lastBackPress!) > const Duration(seconds: 2)) {
      _lastBackPress = now;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Row(
            children: [
              Icon(Icons.exit_to_app_rounded, color: Colors.white, size: 18),
              SizedBox(width: 10),
              Text('Press back again to exit',
                  style: TextStyle(color: Colors.white, fontSize: 13)),
            ],
          ),
          backgroundColor: ThemeProvider().current.headerBg1,
          behavior: SnackBarBehavior.floating,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          margin: const EdgeInsets.all(12),
          duration: const Duration(seconds: 2),
        ),
      );
      return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    final t = ThemeProvider().current;
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        final shouldExit = await _onWillPop();
        if (shouldExit && mounted) {
          Navigator.of(context).pop();
        }
      },
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              _AppBarShield(),
              const SizedBox(width: 10),
              const Text('TAURUS SHIELD'),
              const SizedBox(width: 10),
              _AppBarShield(mirrored: true),
            ],
          ),
          actions: [
            IconButton(
              tooltip: 'Device Manager',
              icon: const Icon(Icons.admin_panel_settings_rounded, size: 22),
              color: const Color(0xFF7c3aed),
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => const AdminPanelScreen(),
                ),
              ),
            ),
          ],
          flexibleSpace: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [t.appBarBg, t.headerBg1],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
            ),
          ),
        ),
        drawer: const AppDrawer(),
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 14),

              AnimatedBuilder(
                animation: _pulse,
                builder: (_, __) {
                  final totalTools = _allTools.length;
                  return Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 14),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(18),
                      gradient: LinearGradient(
                        colors: [
                          t.headerBg1,
                          t.headerBg2,
                          t.headerBg1,
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      border: Border.all(
                        color: Color.lerp(
                          t.primary.withOpacity(0.30),
                          t.highlightColor.withOpacity(0.25),
                          _pulse.value,
                        )!,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: t.primary
                              .withOpacity(0.05 + _pulse.value * 0.05),
                          blurRadius: 20,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 42,
                          height: 42,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            color: Color.lerp(
                              t.primary.withOpacity(0.15),
                              t.secondary.withOpacity(0.20),
                              _pulse.value,
                            ),
                            border: Border.all(
                              color: t.primary
                                  .withOpacity(0.3 + _pulse.value * 0.2),
                            ),
                          ),
                          child: Icon(
                            Icons.security_rounded,
                            size: 22,
                            color: Color.lerp(
                              t.primary,
                              t.secondary,
                              _pulse.value,
                            ),
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Text(
                                    'Select a Tool',
                                    style: TextStyle(
                                      color: t.textColor,
                                      fontSize: 17,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 1.5,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 2),
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(8),
                                      color: t.primary
                                          .withOpacity(0.25),
                                      border: Border.all(
                                        color: t.primary
                                            .withOpacity(0.5),
                                        width: 1,
                                      ),
                                    ),
                                    child: Text(
                                      '$totalTools',
                                      style: TextStyle(
                                        color: t.secondary,
                                        fontSize: 13,
                                        fontWeight: FontWeight.w900,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 2),
                              Text(
                                'Tap a tool below to get started',
                                style: TextStyle(
                                  color: t.subtextColor.withOpacity(0.6),
                                  fontSize: 11.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),

              const SizedBox(height: 10),

              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  color: t.surfaceColor,
                  border: Border.all(
                    color: t.primary.withOpacity(0.2),
                  ),
                ),
                child: TextField(
                  controller: _searchCtrl,
                  style: TextStyle(color: t.textColor, fontSize: 14),
                  decoration: InputDecoration(
                    hintText: 'Search tools...',
                    hintStyle: TextStyle(
                      color: t.textColor.withOpacity(0.25),
                      fontSize: 14,
                    ),
                    prefixIcon: Icon(
                      Icons.search_rounded,
                      color: t.primary.withOpacity(0.6),
                      size: 20,
                    ),
                    suffixIcon: _searchQuery.isNotEmpty
                        ? IconButton(
                            icon: Icon(Icons.close_rounded,
                                color: t.textColor.withOpacity(0.4), size: 18),
                            onPressed: () => _searchCtrl.clear(),
                          )
                        : null,
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 12),
                  ),
                ),
              ),

              const SizedBox(height: 10),

              // ── Tool cards — scrollable list with scroll arrows ─────────
              Expanded(
                child: Stack(
                  children: [
                    FadeTransition(
                      opacity: _cardFade,
                      child: SlideTransition(
                        position: _cardSlide,
                        child: Builder(
                          builder: (_) {
                            final filtered = _filteredTools;
                            if (filtered.isEmpty) {
                              return Center(
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(Icons.search_off_rounded,
                                        color: Colors.white.withOpacity(0.15),
                                        size: 48),
                                    const SizedBox(height: 12),
                                    Text(
                                      'No tools match "$_searchQuery"',
                                      style: TextStyle(
                                        color: Colors.white.withOpacity(0.3),
                                        fontSize: 14,
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            }
                            return ListView.separated(
                              controller: _scrollCtrl,
                              padding: EdgeInsets.zero,
                              itemCount: filtered.length + 1,
                              separatorBuilder: (_, __) =>
                                  const SizedBox(height: 10),
                              itemBuilder: (_, i) {
                                if (i == filtered.length) {
                                  return Padding(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 14),
                                    child: Center(
                                      child: Text(
                                        _searchQuery.isEmpty
                                            ? 'More tools coming soon...'
                                            : '${filtered.length} tool${filtered.length == 1 ? '' : 's'} found',
                                        style: TextStyle(
                                          color: Colors.white.withOpacity(0.28),
                                          fontSize: 12,
                                          letterSpacing: 1.2,
                                        ),
                                      ),
                                    ),
                                  );
                                }
                                return filtered[i];
                              },
                            );
                          },
                        ),
                      ),
                    ),

                    Positioned(
                      top: 8,
                      right: 4,
                      child: AnimatedOpacity(
                        opacity: _showScrollUp ? 1.0 : 0.0,
                        duration: const Duration(milliseconds: 250),
                        child: IgnorePointer(
                          ignoring: !_showScrollUp,
                          child: GestureDetector(
                            onTap: () => _scrollCtrl.animateTo(
                              0,
                              duration: const Duration(milliseconds: 400),
                              curve: Curves.easeOutCubic,
                            ),
                            child: Container(
                              width: 38,
                              height: 38,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: t.primary.withOpacity(0.85),
                                boxShadow: [
                                  BoxShadow(
                                    color: t.primary.withOpacity(0.4),
                                    blurRadius: 12,
                                    spreadRadius: 2,
                                  ),
                                ],
                              ),
                              child: Icon(
                                Icons.keyboard_arrow_up_rounded,
                                color: t.textColor,
                                size: 24,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),

                    Positioned(
                      bottom: 8,
                      right: 4,
                      child: AnimatedOpacity(
                        opacity: _showScrollDown ? 1.0 : 0.0,
                        duration: const Duration(milliseconds: 250),
                        child: IgnorePointer(
                          ignoring: !_showScrollDown,
                          child: GestureDetector(
                            onTap: () => _scrollCtrl.animateTo(
                              _scrollCtrl.position.maxScrollExtent,
                              duration: const Duration(milliseconds: 400),
                              curve: Curves.easeOutCubic,
                            ),
                            child: Container(
                              width: 38,
                              height: 38,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: t.primary.withOpacity(0.85),
                                boxShadow: [
                                  BoxShadow(
                                    color: t.primary.withOpacity(0.4),
                                    blurRadius: 12,
                                    spreadRadius: 2,
                                  ),
                                ],
                              ),
                              child: Icon(
                                Icons.keyboard_arrow_down_rounded,
                                color: t.textColor,
                                size: 24,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  List<_ToolCard> get _allTools => [
    _ToolCard(
      icon: Icons.memory_rounded,
      iconColor: const Color(0xFF7c3aed),
      glowColor: const Color(0xFF7c3aed),
      iconAnim: _IconAnim.pulse,
      title: 'HBC Tool',
      subtitle: 'Hermes Bytecode DSM & ASM',
      description: 'Disassemble & reassemble Hermes bytecode files.',
      chips: const ['.bundle', '.hbc', '.hasm', '.zip'],
      badgeLabel: 'ACTIVE',
      badgeColor: const Color(0xFF22c55e),
      onTap: () => _navigateTo(const HomeScreen(), 'hbc'),
    ),
    _ToolCard(
      icon: Icons.flutter_dash_rounded,
      iconColor: const Color(0xFF22d3ee),
      glowColor: const Color(0xFF22d3ee),
      iconAnim: _IconAnim.spin,
      title: 'Blutter',
      subtitle: 'Flutter App Reverse Engineering',
      description: 'Extract Dart symbols and ARM64 code from Flutter APKs.',
      chips: const ['.apk', 'libapp.so'],
      badgeLabel: 'BETA',
      badgeColor: const Color(0xFFf59e0b),
      onTap: () => _navigateTo(const BlutterScreen(), 'blutter'),
    ),
    _ToolCard(
      icon: Icons.enhanced_encryption_rounded,
      iconColor: const Color(0xFF10b981),
      glowColor: const Color(0xFF10b981),
      iconAnim: _IconAnim.glow,
      title: 'Dex2C',
      subtitle: 'APK Native Protection',
      description: 'Convert DEX bytecode to native C/C++ for protection.',
      chips: const ['.apk', 'filter.txt'],
      badgeLabel: 'CLOUD',
      badgeColor: const Color(0xFF10b981),
      iconBuilder: (color, t) => CustomPaint(
        size: const Size(26, 26),
        painter: _ChipPainter(color: color, t: t),
      ),
      onTap: () => _navigateTo(const Dex2CScreen(), 'dex2c'),
    ),
    _ToolCard(
      icon: Icons.cloud_upload_rounded,
      iconColor: const Color(0xFF0ea5e9),
      glowColor: const Color(0xFF0ea5e9),
      iconAnim: _IconAnim.pulse,
      title: 'Temp Host',
      subtitle: 'Free Temporary File Hosting',
      description: 'Upload any file to a free temp host. Tries Litterbox, filebin, qu.ax, x0.at, uguu.se and tmpfiles.org in order.',
      chips: const ['any file', 'free', 'temp link'],
      badgeLabel: 'FREE',
      badgeColor: const Color(0xFF0ea5e9),
      onTap: () => _navigateTo(const UploadScreen(), 'upload'),
    ),
    _ToolCard(
      icon: Icons.code_rounded,
      iconColor: const Color(0xFF6366f1),
      glowColor: const Color(0xFF6366f1),
      iconAnim: _IconAnim.glow,
      title: 'DEX Tools',
      subtitle: 'DEX · Smali · Java · JAR',
      description: 'Disassemble, decompile & recompile Android bytecode. 4 tools: Smali→Java, Java→Smali, Dex→Jar, Dex→Java.',
      chips: const ['.dex', '.apk', '.smali', '.java', '.jar', 'core'],
      badgeLabel: 'CORE',
      badgeColor: const Color(0xFF6366f1),
      iconBuilder: (color, t) => SvgPicture.asset(
        'assets/icon/android_os.svg',
        colorFilter: ColorFilter.mode(
          Color.lerp(const Color(0xFF3730a3), const Color(0xFFFFFFFF), t)!,
          BlendMode.srcIn,
        ),
      ),
      onTap: () => _navigateTo(const DexToolsHubScreen(), 'dextools'),
    ),
    _ToolCard(
      icon: Icons.layers_rounded,
      iconColor: const Color(0xFFf97316),
      glowColor: const Color(0xFFf97316),
      iconAnim: _IconAnim.pulse,
      title: 'DPT Shell',
      subtitle: 'DEX Hollowing Protection',
      description: 'Protect APKs with DEX hollowing shell injection.',
      chips: const ['.apk', 'rules.txt?'],
      badgeLabel: 'CLOUD',
      badgeColor: const Color(0xFFf97316),
      onTap: () => _navigateTo(const DptShellScreen(), 'dptshell'),
    ),
    _ToolCard(
      icon: Icons.memory_rounded,
      iconColor: const Color(0xFF8B5CF6),
      glowColor: const Color(0xFF8B5CF6),
      iconAnim: _IconAnim.glow,
      title: 'VM Protect',
      subtitle: 'DEX → Native VM Obfuscation',
      description: 'Convert DEX bytecode into a custom native VM for maximum protection.',
      chips: const ['.apk', 'rules.txt?', 'mapping.txt?'],
      badgeLabel: 'CLOUD',
      badgeColor: const Color(0xFF8B5CF6),
      onTap: () => _navigateTo(const VmProtectScreen(), 'vmprotect'),
    ),
    _ToolCard(
      icon: Icons.android_rounded,
      iconColor: const Color(0xFF3b82f6),
      glowColor: const Color(0xFF3b82f6),
      iconAnim: _IconAnim.glow,
      title: 'APK Tool',
      subtitle: 'Decompile / Recompile APK',
      description: 'Decompile, modify and recompile any Android APK.',
      chips: const ['.apk', '.zip'],
      badgeLabel: 'CLOUD',
      badgeColor: const Color(0xFF3b82f6),
      onTap: () => _navigateTo(const ApkToolScreen(), 'apktool'),
    ),
    _ToolCard(
      icon: Icons.compress_rounded,
      iconColor: const Color(0xFF06b6d4),
      glowColor: const Color(0xFF06b6d4),
      iconAnim: _IconAnim.pulse,
      title: 'APKS Converter',
      subtitle: 'Split APK Set → Single APK',
      description: 'Convert Google Play .apks bundles into a single installable APK on-device. '
          'Extract base.apk (signed) or merge all splits into one universal APK.',
      chips: const ['.apks', 'extract', 'merge', 'on-device'],
      badgeLabel: 'ON-DEVICE',
      badgeColor: const Color(0xFF06b6d4),
      onTap: () => _navigateTo(const ApksConvertScreen(), 'apks_convert'),
    ),
    _ToolCard(
      icon: Icons.security_rounded,
      iconColor: const Color(0xFF7C9FD4),
      glowColor: const Color(0xFF7C9FD4),
      iconAnim: _IconAnim.glow,
      title: 'ACM Files Encryptor',
      subtitle: 'Multi-Language Code Obfuscation',
      description: 'HTML, JavaScript & PHP — 18 obfuscation methods across three languages, including eval+base64 PHP cloud obfuscation.',
      chips: const ['.js', '.php', '.html', '.zip', '18 methods'],
      badgeLabel: 'MULTI-LANG',
      badgeColor: const Color(0xFF7C9FD4),
      onTap: () => _navigateTo(const EncryptorHubScreen(), 'encryptorhub'),
    ),
    _ToolCard(
      icon: Icons.block_rounded,
      iconColor: const Color(0xFF14b8a6),
      glowColor: const Color(0xFF14b8a6),
      iconAnim: _IconAnim.pulse,
      title: 'Ads Patch',
      subtitle: 'Remove Ads from APKs',
      description: 'Remove ad SDKs and block ad calls from APKs.',
      chips: const ['.apk', 'basic', 'advance', 'all'],
      badgeLabel: 'CLOUD',
      badgeColor: const Color(0xFF14b8a6),
      onTap: () => _navigateTo(const AdsPatchScreen(), 'adspatch'),
    ),
    _ToolCard(
      icon: Icons.settings_ethernet_rounded,
      iconColor: const Color(0xFFf97316),
      glowColor: const Color(0xFFf97316),
      iconAnim: _IconAnim.pulse,
      title: 'ReFlutter',
      subtitle: 'Flutter Engine Traffic Intercept',
      description: 'Patches Flutter\'s libflutter.so engine for HTTPS interception. Install the patched APK then intercept with Proxy Pin, Reqable or any proxy — no root required.',
      chips: const ['.apk', 'flutter', 'MITM', 'Reqable'],
      badgeLabel: 'CLOUD',
      badgeColor: const Color(0xFFf97316),
      onTap: () => _navigateTo(const ReFlutterScreen(), 'reflutter'),
    ),
    _ToolCard(
      icon: Icons.webhook_rounded,
      iconColor: const Color(0xFF16a34a),
      glowColor: const Color(0xFF16a34a),
      iconAnim: _IconAnim.pulse,
      title: 'Pine Hook Injector',
      subtitle: 'Runtime Hook · Xposed · Hook',
      description: 'Inject the Pine hooking framework and Xposed modules into any APK — no root, no setup required.',
      chips: const ['.apk', '.apks', '.xapk', '.apkm', 'xposed'],
      badgeLabel: 'ACTIVE',
      badgeColor: const Color(0xFF16a34a),
      onTap: () => _navigateTo(const PineHookScreen(), 'pinehook'),
    ),
    _ToolCard(
      icon: Icons.lock_open_rounded,
      iconColor: const Color(0xFF06b6d4),
      glowColor: const Color(0xFF06b6d4),
      iconAnim: _IconAnim.pulse,
      title: 'SSL Unpinner',
      subtitle: 'DEX Patch · NSC Inject · SSL Patcher',
      description: 'Forces any APK to accept all SSL certificates — no root, no setup.',
      chips: const ['.apk', '.apks', 'SSL', 'bypass'],
      badgeLabel: 'ACTIVE',
      badgeColor: const Color(0xFF06b6d4),
      onTap: () => _navigateTo(const SslUnpinnerScreen(), 'sslunpin'),
    ),
    _ToolCard(
      icon: Icons.shield_rounded,
      iconColor: const Color(0xFF8B5CF6),
      glowColor: const Color(0xFF8B5CF6),
      iconAnim: _IconAnim.pulse,
      title: 'Matrix Killer',
      subtitle: 'App Protection · Dialog Lock',
      description: 'Injects protection into any APK that prevents users from dismissing security dialogs.',
      chips: const ['.apk', 'smali', 'inject', 'cloud'],
      badgeLabel: 'CLOUD',
      badgeColor: const Color(0xFF8B5CF6),
      onTap: () => _navigateTo(const AntiDialogScreen(), 'antidialog'),
    ),
    _ToolCard(
      icon: Icons.list_alt_rounded,
      iconColor: const Color(0xFF22d3ee),
      glowColor: const Color(0xFF22d3ee),
      iconAnim: _IconAnim.pulse,
      title: 'LogCat',
      subtitle: 'Logs · Crashes · Record · ADB Pair',
      description: 'Java/JNI crash catcher, ANR detector, live log stream and wireless ADB pairing — no PC needed.',
      chips: const ['logs', 'crashes', 'record', 'ADB'],
      badgeLabel: 'LIVE',
      badgeColor: const Color(0xFF22d3ee),
      iconBuilder: (color, t) => Image.asset(
        'assets/icon/logcat_cat.png',
        width: 36,
        height: 36,
      ),
      onTap: () => _navigateTo(const LogcatScreen(), 'logcat'),
    ),
    _ToolCard(
      icon: Icons.local_fire_department_rounded,
      iconColor: const Color(0xFFFF6B35),
      glowColor: const Color(0xFFFF6B35),
      iconAnim: _IconAnim.glow,
      title: 'Black Forge',
      subtitle: 'AES-256-GCM · Archive · Compress · Split',
      description: 'Military-grade AES-256-GCM file encryption with PBKDF2 key derivation, multi-format archive support (7z/zip/tar/xz/zstd…), and on-the-fly volume splitting from 5 MB up to 4 GB chunks for easy transfer over size-limited channels.',
      chips: const ['encrypt', 'decrypt', '7z', 'AES-256', 'split'],
      badgeLabel: 'FORTRESS',
      badgeColor: const Color(0xFFFF6B35),
      onTap: () => _navigateTo(const BlackForgeScreen(), 'blackforge'),
    ),
    _ToolCard(
      icon: Icons.android_rounded,
      iconColor: const Color(0xFFFF0A0A),
      glowColor: const Color(0xFFFF0A0A),
      iconAnim: _IconAnim.pulse,
      title: 'Web2Apk Builder',
      subtitle: 'Website → APK · Local · V1 Signed',
      description: 'Convert any website into a signed Android APK locally — no cloud, no apktool. Supports biometric lock, custom icon and dark-theme WebView.',
      chips: const ['webview', 'apk', 'sign', 'local'],
      badgeLabel: 'BUILDER',
      badgeColor: const Color(0xFFFF0A0A),
      whiteAccents: true,
      onTap: () => _navigateTo(const WebApkScreen(), 'webapk'),
    ),
    _ToolCard(
      icon: Icons.cloud_rounded,
      iconColor: const Color(0xFFF6821F),
      glowColor: const Color(0xFFF6821F),
      iconAnim: _IconAnim.glow,
      title: 'Cloudflare Manager',
      subtitle: 'Workers · DNS · Pages · Analytics',
      description: 'Manage Workers, DNS, Pages and analytics directly.',
      chips: const ['workers', 'dns', 'pages', 'stats'],
      badgeLabel: 'DIRECT',
      badgeColor: const Color(0xFFF6821F),
      iconBuilder: (color, t) => Padding(
        padding: const EdgeInsets.all(3),
        child: SvgPicture.asset(
          'assets/icon/cloudflare.svg',
          colorFilter: ColorFilter.mode(
            Color.lerp(
              const Color(0xFF7A3300),
              const Color(0xFFFFFFFF),
              t,
            )!,
            BlendMode.srcIn,
          ),
        ),
      ),
      onTap: () => _navigateTo(const CloudflareScreen(), 'cloudflare'),
    ),
    _ToolCard(
      icon: Icons.code_rounded,
      iconColor: const Color(0xFF238636),
      glowColor: const Color(0xFF238636),
      iconAnim: _IconAnim.pulse,
      title: 'GitHub Manager',
      subtitle: 'Repos · Branches · PRs · Actions',
      description: 'Full GitHub management: files, commits, issues, releases, workflows and more.',
      chips: const ['repos', 'PRs', 'issues', 'gists'],
      badgeLabel: 'DIRECT',
      badgeColor: const Color(0xFF238636),
      iconBuilder: (color, t) => CustomPaint(
        size: const Size(26, 26),
        painter: _GhIconPainter(color: color, t: t),
      ),
      onTap: () => _navigateTo(const GitHubManagerScreen(), 'github'),
    ),
    _ToolCard(
      icon: Icons.terminal_rounded,
      iconColor: const Color(0xFF8B5CF6),
      glowColor: const Color(0xFF8B5CF6),
      iconAnim: _IconAnim.pulse,
      title: 'Il2CppDumper + Mod',
      subtitle: 'Unity IL2CPP Dump · Symbol Patch · Mod APK',
      description: 'Full Il2CppDumper pipeline — extracts every C# method offset from the game binary, lets you pick & configure exactly which functions to patch (coins, speed, unlocks…), then builds a signed modded APK via the cloud. No root needed.',
      chips: const ['IL2CPP', 'arm64', 'dump', 'patch', 'mod'],
      badgeLabel: 'CLOUD',
      badgeColor: const Color(0xFF8B5CF6),
      onTap: () => _navigateTo(const ModEngineScreen(), 'modengine'),
    ),
    _ToolCard(
      icon: Icons.gamepad_rounded,
      iconColor: const Color(0xFFF97316),
      glowColor: const Color(0xFFF97316),
      iconAnim: _IconAnim.pulse,
      title: 'Cocos2d-x Analyser',
      subtitle: 'Lua Decrypt · JS Patch · Native ARM64 · Repack',
      description: 'On-device Cocos2d-x game analyser — auto-detects Lua, JS, or Native C++ game type. Extracts XXTEA key, decrypts scripts, finds patchable values, lets you edit them and repacks the APK entirely on-device. No cloud, no internet needed.',
      chips: const ['Cocos2d-x', 'Lua', 'JS', 'ARM64', 'on-device'],
      badgeLabel: 'ON-DEVICE',
      badgeColor: const Color(0xFFF97316),
      onTap: () => _navigateTo(const CocosScreen(), 'cocos'),
    ),
  ];

  List<_ToolCard> get _filteredTools {
    if (_searchQuery.isEmpty) return _allTools;
    return _allTools.where((t) {
      final q = _searchQuery;
      return t.title.toLowerCase().contains(q) ||
          t.subtitle.toLowerCase().contains(q) ||
          t.description.toLowerCase().contains(q) ||
          t.badgeLabel.toLowerCase().contains(q) ||
          t.chips.any((c) => c.toLowerCase().contains(q));
    }).toList();
  }
}

// ── Tool card ──────────────────────────────────────────────────────────────────

class _ToolCard extends StatefulWidget {
  final IconData icon;
  final Color iconColor;
  final Color glowColor;
  final _IconAnim iconAnim;
  final String title;
  final String subtitle;
  final String description;
  final List<String> chips;
  final String badgeLabel;
  final Color badgeColor;
  final VoidCallback onTap;
  // Optional custom icon builder; receives animation value t ∈ [0,1]
  final Widget Function(Color color, double t)? iconBuilder;
  // When true: icon, subtitle, badge text, chip text all render white
  // while their backgrounds/borders keep using iconColor/badgeColor
  final bool whiteAccents;

  const _ToolCard({
    required this.icon,
    required this.iconColor,
    required this.glowColor,
    required this.iconAnim,
    required this.title,
    required this.subtitle,
    required this.description,
    required this.chips,
    required this.badgeLabel,
    required this.badgeColor,
    required this.onTap,
    this.iconBuilder,
    this.whiteAccents = false,
  });

  @override
  State<_ToolCard> createState() => _ToolCardState();
}

class _ToolCardState extends State<_ToolCard> with TickerProviderStateMixin {
  late final AnimationController _tapCtrl;
  late final AnimationController _iconCtrl;
  late final Animation<double> _tapAnim;
  late final Animation<double> _iconAnim;

  @override
  void initState() {
    super.initState();

    // Tap / press animation
    _tapCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 160),
    );
    _tapAnim = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _tapCtrl, curve: Curves.easeOut),
    );

    // Idle icon animation
    switch (widget.iconAnim) {
      case _IconAnim.pulse:
        _iconCtrl = AnimationController(
          vsync: this,
          duration: const Duration(milliseconds: 1800),
        )..repeat(reverse: true);
        _iconAnim = Tween<double>(begin: 0.82, end: 1.0).animate(
          CurvedAnimation(parent: _iconCtrl, curve: Curves.easeInOut),
        );
        break;
      case _IconAnim.spin:
        _iconCtrl = AnimationController(
          vsync: this,
          duration: const Duration(seconds: 7),
        )..repeat();
        _iconAnim = Tween<double>(begin: 0.0, end: 1.0).animate(_iconCtrl);
        break;
      case _IconAnim.glow:
        _iconCtrl = AnimationController(
          vsync: this,
          duration: const Duration(milliseconds: 850),
        )..repeat(reverse: true);
        _iconAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
          CurvedAnimation(parent: _iconCtrl, curve: Curves.easeInOut),
        );
        break;
    }
  }

  @override
  void dispose() {
    _tapCtrl.dispose();
    _iconCtrl.dispose();
    super.dispose();
  }

  Widget _buildAnimatedIcon() {
    final iconFg = widget.whiteAccents ? Colors.white : widget.iconColor;
    switch (widget.iconAnim) {
      case _IconAnim.pulse:
        return AnimatedBuilder(
          animation: _iconAnim,
          builder: (_, __) => Transform.scale(
            scale: _iconAnim.value,
            child: widget.iconBuilder != null
                ? widget.iconBuilder!(iconFg, _iconAnim.value)
                : Icon(widget.icon, color: iconFg, size: 26),
          ),
        );
      case _IconAnim.spin:
        return AnimatedBuilder(
          animation: _iconAnim,
          builder: (_, __) => Transform.rotate(
            angle: _iconAnim.value * 2 * math.pi,
            child: widget.iconBuilder != null
                ? widget.iconBuilder!(iconFg, _iconAnim.value)
                : Icon(widget.icon, color: iconFg, size: 26),
          ),
        );
      case _IconAnim.glow:
        return AnimatedBuilder(
          animation: _iconAnim,
          builder: (_, __) {
            final t = _iconAnim.value;
            return Transform.scale(
              scale: 0.80 + 0.28 * t,
              child: Opacity(
                opacity: 0.55 + 0.45 * t,
                child: widget.iconBuilder != null
                    ? widget.iconBuilder!(iconFg, t)
                    : Icon(widget.icon, color: iconFg, size: 26),
              ),
            );
          },
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _tapCtrl.forward(),
      onTapUp: (_) {
        _tapCtrl.reverse();
        widget.onTap();
      },
      onTapCancel: () => _tapCtrl.reverse(),
      child: AnimatedBuilder(
        animation: _tapAnim,
        builder: (_, child) => Transform.scale(
          scale: 1.0 - _tapAnim.value * 0.015,
          child: Container(
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
              color: ThemeProvider().current.surfaceColor,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: ThemeProvider().current.borderColor,
                width: 1,
              ),
            ),
            child: child,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ── Animated icon box
              widget.iconAnim == _IconAnim.glow
                  ? AnimatedBuilder(
                      animation: _iconAnim,
                      builder: (_, __) {
                        final t = _iconAnim.value;
                        return Container(
                          width: 52,
                          height: 52,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(14),
                            color: ThemeProvider().current.scaffoldBg,
                            border: Border.all(
                              color: Color.lerp(
                                ThemeProvider().current.borderColor,
                                widget.glowColor.withOpacity(0.55),
                                t,
                              )!,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: widget.glowColor.withOpacity(0.22 * t),
                                blurRadius: 14,
                                spreadRadius: 2,
                              ),
                            ],
                          ),
                          child: Center(child: _buildAnimatedIcon()),
                        );
                      },
                    )
                  : Container(
                      width: 52,
                      height: 52,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        color: ThemeProvider().current.scaffoldBg,
                        border: Border.all(color: ThemeProvider().current.borderColor),
                      ),
                      child: Center(child: _buildAnimatedIcon()),
                    ),
              const SizedBox(width: 14),
              // ── Text content
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      children: [
                        Text(
                          widget.title,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(width: 7),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: widget.badgeColor.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(5),
                            border: Border.all(
                                color: widget.badgeColor.withOpacity(0.35)),
                          ),
                          child: Text(
                            widget.badgeLabel,
                            style: TextStyle(
                              color: widget.whiteAccents ? Colors.white : widget.badgeColor,
                              fontSize: 8,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.8,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      widget.subtitle,
                      style: TextStyle(
                        color: widget.whiteAccents ? Colors.white : widget.iconColor,
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      widget.description,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Color(0xFF9ca3af),
                        fontSize: 11.5,
                        height: 1.45,
                      ),
                    ),
                    const SizedBox(height: 7),
                    Wrap(
                      spacing: 5,
                      runSpacing: 3,
                      children: widget.chips
                          .map((c) => _Chip(
                                label: c,
                                color: widget.iconColor,
                                textColor: widget.whiteAccents ? Colors.white : null,
                              ))
                          .toList(),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 6),
              Icon(Icons.arrow_forward_ios_rounded,
                  color: widget.iconColor.withOpacity(0.45), size: 14),
            ],
          ),
        ),
      ),
    );
  }
}

// ── Chip ───────────────────────────────────────────────────────────────────────

class _Chip extends StatelessWidget {
  final String label;
  final Color color;
  final Color? textColor;
  const _Chip({required this.label, required this.color, this.textColor});

  @override
  Widget build(BuildContext context) {
    final fg = textColor ?? color.withOpacity(0.85);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(5),
        border: Border.all(color: color.withOpacity(0.22)),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: fg,
          fontSize: 9.5,
          fontFamily: 'monospace',
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

// ── AppBar shield ──────────────────────────────────────────────────────────────

class _AppBarShield extends StatelessWidget {
  final bool mirrored;
  const _AppBarShield({this.mirrored = false});

  @override
  Widget build(BuildContext context) {
    return Transform.scale(
      scaleX: mirrored ? -1 : 1,
      child: CustomPaint(
        size: const Size(18, 20),
        painter: _ShieldPainter(),
      ),
    );
  }
}

class _ShieldPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final t = ThemeProvider().current;
    final w = size.width;
    final h = size.height;
    final path = Path()
      ..moveTo(w * 0.5, 0)
      ..lineTo(w, h * 0.18)
      ..lineTo(w, h * 0.52)
      ..quadraticBezierTo(w, h * 0.82, w * 0.5, h)
      ..quadraticBezierTo(0, h * 0.82, 0, h * 0.52)
      ..lineTo(0, h * 0.18)
      ..close();

    canvas.drawPath(
      path,
      Paint()
        ..shader = LinearGradient(
          colors: [
            t.secondary.withOpacity(0.22),
            t.primary.withOpacity(0.12),
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ).createShader(Rect.fromLTWH(0, 0, w, h))
        ..style = PaintingStyle.fill,
    );

    canvas.drawPath(
      path,
      Paint()
        ..color = t.secondary.withOpacity(0.85)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4
        ..strokeJoin = StrokeJoin.round,
    );

    final tp = Paint()
      ..color = t.secondary.withOpacity(0.9)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..strokeCap = StrokeCap.round;

    canvas.drawLine(Offset(w * 0.3, h * 0.40), Offset(w * 0.7, h * 0.40), tp);
    canvas.drawLine(Offset(w * 0.5, h * 0.40), Offset(w * 0.5, h * 0.68), tp);
  }

  @override
  bool shouldRepaint(_ShieldPainter _) => true;
}

// ── Dex2C chip icon ────────────────────────────────────────────────────────────
// Advanced IC-chip SVG drawn with CustomPainter. Replaces the generic padlock.
// t is the animation value (0→1) used to pulse the core and corner nodes.

class _ChipPainter extends CustomPainter {
  final Color color;
  final double t;
  const _ChipPainter({required this.color, required this.t});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final cx = w * .5;
    final cy = h * .5;

    final stroke = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 1.4;

    final fill = Paint()..style = PaintingStyle.fill;

    // ── Chip body ─────────────────────────────────────────────────────────────
    final bodyRect = RRect.fromRectAndRadius(
      Rect.fromLTWH(w * .20, h * .20, w * .60, h * .60),
      const Radius.circular(3),
    );
    canvas.drawRRect(bodyRect, fill..color = color.withOpacity(.13));
    canvas.drawRRect(bodyRect, stroke..color = color..strokeWidth = 1.4);

    // ── Pins (2 per side) ─────────────────────────────────────────────────────
    stroke.strokeWidth = 1.3;
    final pa = w * .33;
    final pb = w * .67;
    // top
    canvas.drawLine(Offset(pa, h * .06), Offset(pa, h * .20), stroke);
    canvas.drawLine(Offset(pb, h * .06), Offset(pb, h * .20), stroke);
    // bottom
    canvas.drawLine(Offset(pa, h * .80), Offset(pa, h * .94), stroke);
    canvas.drawLine(Offset(pb, h * .80), Offset(pb, h * .94), stroke);
    // left
    canvas.drawLine(Offset(w * .06, pa), Offset(w * .20, pa), stroke);
    canvas.drawLine(Offset(w * .06, pb), Offset(w * .20, pb), stroke);
    // right
    canvas.drawLine(Offset(w * .80, pa), Offset(w * .92, pa), stroke);
    canvas.drawLine(Offset(w * .80, pb), Offset(w * .92, pb), stroke);

    // ── Inner core circle (pulsing) ────────────────────────────────────────────
    final coreAlpha = .18 + .20 * t;
    canvas.drawCircle(Offset(cx, cy), w * .13,
        fill..color = color.withOpacity(coreAlpha));
    canvas.drawCircle(Offset(cx, cy), w * .13,
        stroke..color = color.withOpacity(.5 + .4 * t)..strokeWidth = 1.0);

    // ── Corner nodes with trace lines to core ─────────────────────────────────
    final nodes = [
      Offset(w * .32, h * .32),
      Offset(w * .68, h * .32),
      Offset(w * .32, h * .68),
      Offset(w * .68, h * .68),
    ];
    final traceStroke = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = .7
      ..color = color.withOpacity(.25);
    final dotFill = Paint()
      ..style = PaintingStyle.fill
      ..color = color.withOpacity(.50 + .45 * t);

    for (final n in nodes) {
      canvas.drawLine(n, Offset(cx, cy), traceStroke);
      canvas.drawCircle(n, 1.7, dotFill);
    }
  }

  @override
  bool shouldRepaint(_ChipPainter old) => old.t != t || old.color != color;
}

// ── GitHub icon painter ────────────────────────────────────────────────────────
class _GhIconPainter extends CustomPainter {
  final Color color;
  final double t;
  const _GhIconPainter({required this.color, required this.t});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final alpha = 0.5 + 0.5 * t;

    final fill = Paint()..style = PaintingStyle.fill..color = color.withOpacity(alpha);
    final stroke = Paint()..style = PaintingStyle.stroke..color = color.withOpacity(alpha)..strokeWidth = 1.4;

    // Outer circle (GitHub shape)
    canvas.drawCircle(Offset(w * .5, h * .5), w * .46, stroke);

    // Simplified octocat body
    final cx = w * .5;
    final cy = h * .45;
    canvas.drawCircle(Offset(cx, cy), w * .22, fill..color = color.withOpacity(0.12 + 0.08 * t));
    canvas.drawCircle(Offset(cx, cy), w * .22, stroke);

    // Head
    final headFill = Paint()..style = PaintingStyle.fill..color = color.withOpacity(0.6 + 0.3 * t);
    canvas.drawCircle(Offset(cx, cy - h * .06), w * .12, headFill);

    // Tail curve
    final path = Path();
    path.moveTo(cx - w * .06, cy + h * .16);
    path.cubicTo(cx - w * .18, cy + h * .26, cx - w * .18, cy + h * .38, cx, cy + h * .38);
    path.cubicTo(cx + w * .18, cy + h * .38, cx + w * .18, cy + h * .26, cx + w * .06, cy + h * .16);
    canvas.drawPath(path, stroke);
  }

  @override
  bool shouldRepaint(_GhIconPainter old) => old.t != t || old.color != color;
}

// ── How It Works callout (tappable card under the header) ────────────────────
class _HowItWorksCallout extends StatelessWidget {
  final AppThemeData t;
  const _HowItWorksCallout({required this.t});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const HowItWorksScreen()),
          );
        },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            gradient: LinearGradient(
              colors: [
                t.primary.withOpacity(0.18),
                t.secondary.withOpacity(0.10),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            border: Border.all(color: t.primary.withOpacity(0.35)),
          ),
          child: Row(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  gradient: LinearGradient(
                    colors: [t.primary, t.secondary],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: t.primary.withOpacity(0.45),
                      blurRadius: 10,
                    ),
                  ],
                ),
                child: const Icon(Icons.menu_book_rounded,
                    color: Colors.white, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('How does this work?',
                        style: TextStyle(
                            color: t.textColor,
                            fontSize: 13.5,
                            fontWeight: FontWeight.w800)),
                    const SizedBox(height: 2),
                    Text(
                        'New here? Read the quick walk-through.',
                        style: TextStyle(
                            color: t.subtextColor.withOpacity(0.85),
                            fontSize: 11.5)),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const UploadScreen()),
                  );
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: t.surfaceColor.withOpacity(0.7),
                    border: Border.all(color: t.primary.withOpacity(0.4)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.cloud_upload_rounded,
                          size: 14, color: t.secondary),
                      const SizedBox(width: 4),
                      Text('Upload',
                          style: TextStyle(
                              color: t.secondary,
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.4)),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 6),
              Icon(Icons.chevron_right_rounded,
                  color: t.subtextColor.withOpacity(0.7), size: 22),
            ],
          ),
        ),
      ),
    );
  }
}
