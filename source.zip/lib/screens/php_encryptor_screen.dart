import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:share_plus/share_plus.dart';
import 'package:archive/archive.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import '../utils/storage_helper.dart';
import '../utils/hbc_channel.dart';
import '../services/native_secrets.dart';

// ── Theme constants ───────────────────────────────────────────────────────────
const _kAccent    = Color(0xFF818CF8);
const _kAccentDim = Color(0xFF6366F1);
const _kRed       = Color(0xFFFF0A0A);
const _kBg        = Color(0xFF050505);
const _kCard      = Color(0xFF0C0C0C);
const _kBorder    = Color(0xFF1A1A2E);
const _kAccentGlow= Color(0xFFA5B4FC);

// ── ZIP tree node (PHP manual mode) ──────────────────────────────────────────
class _PhpZipNode {
  final String path;
  final bool   isDir;
  final int    depth;
  bool expanded;
  bool visible;
  _PhpZipNode({required this.path, required this.isDir, required this.depth,
               this.expanded = true, this.visible = true});
  String get name {
    final p = path.endsWith('/') ? path.substring(0, path.length - 1) : path;
    return p.contains('/') ? p.substring(p.lastIndexOf('/') + 1) : p;
  }
  bool get isPhp => !isDir && path.toLowerCase().endsWith('.php');
  bool get selectable => isPhp;
}

// ── Screen ────────────────────────────────────────────────────────────────────

class PhpEncryptorScreen extends StatefulWidget {
  final bool initialAlomMode;
  const PhpEncryptorScreen({super.key, this.initialAlomMode = false});

  @override
  State<PhpEncryptorScreen> createState() => _PhpEncryptorScreenState();
}

class _PhpEncryptorScreenState extends State<PhpEncryptorScreen>
    with TickerProviderStateMixin, WidgetsBindingObserver {

  // ── State ─────────────────────────────────────────────────────────────────
  String? _filePath;
  String? _fileName;
  bool    _isZip        = false;
  int     _phpFileCount = 0;
  String  _workerUrl    = '';
  bool    _evalMode     = false;
  bool    _compressMode = true;
  bool    _alomMode     = false;
  int     _alomDepth    = 3;
  bool    _processing   = false;
  String  _log          = '';
  bool    _done         = false;
  bool    _success      = false;
  String? _outputPath;
  bool    _autoScroll   = true;

  // ── Manual mode state ─────────────────────────────────────────────────────
  bool               _manualMode    = false;
  String?            _mZipPath;
  String?            _mZipName;
  List<_PhpZipNode>  _mNodes        = [];
  Set<String>        _mSelected     = {};
  bool               _mProcessing   = false;
  String             _mLog          = '';
  bool               _mDone         = false;
  bool               _mSuccess      = false;
  String?            _mOutputPath;
  bool               _mAutoScroll   = true;

  // ── Alom session poll ─────────────────────────────────────────────────────
  Timer? _alomPollTimer;

  // ── Controllers ───────────────────────────────────────────────────────────
  final _logCtrl    = ScrollController();
  final _mLogCtrl   = ScrollController();
  final _pageCtrl   = ScrollController();
  late final AnimationController _pulseCtrl;
  late final AnimationController _glowCtrl;
  late final AnimationController _orbitCtrl;
  late final AnimationController _scanCtrl;
  late final AnimationController _cardCtrl;
  late final Animation<double>   _pulseAnim;
  late final Animation<double>   _glowAnim;
  late final Animation<double>   _scanAnim;
  late final Animation<Offset>   _cardSlide;
  late final Animation<double>   _cardFade;

  @override
  void initState() {
    super.initState();
    NativeSecrets.workerUrl().then((u) { if (mounted) setState(() => _workerUrl = u); });

    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))
      ..repeat(reverse: true);
    _glowCtrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 2400))
      ..repeat(reverse: true);
    _orbitCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 5000))
      ..repeat();
    _scanCtrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 2800))
      ..repeat();
    _cardCtrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 650));

    _pulseAnim = CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut);
    _glowAnim  = CurvedAnimation(parent: _glowCtrl,  curve: Curves.easeInOut);
    _scanAnim  = CurvedAnimation(parent: _scanCtrl,  curve: Curves.linear);
    _cardFade  = Tween<double>(begin: 0.0, end: 1.0)
        .animate(CurvedAnimation(parent: _cardCtrl, curve: Curves.easeOut));
    _cardSlide = Tween<Offset>(begin: const Offset(0, 0.18), end: Offset.zero)
        .animate(CurvedAnimation(parent: _cardCtrl, curve: Curves.easeOutCubic));

    Future.delayed(const Duration(milliseconds: 80), () {
      if (mounted) _cardCtrl.forward();
    });

    _logCtrl.addListener(() {
      if (_logCtrl.hasClients) {
        final atBottom = _logCtrl.position.pixels >= _logCtrl.position.maxScrollExtent - 40;
        if (mounted && _autoScroll != atBottom) setState(() => _autoScroll = atBottom);
      }
    });

    if (widget.initialAlomMode) _alomMode = true;

    WidgetsBinding.instance.addObserver(this);
    _restoreAlomSession();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _checkAlomState();
  }

  @override
  void dispose() {
    _alomPollTimer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    _pulseCtrl.dispose();
    _glowCtrl.dispose();
    _orbitCtrl.dispose();
    _scanCtrl.dispose();
    _cardCtrl.dispose();
    _logCtrl.dispose();
    _mLogCtrl.dispose();
    _pageCtrl.dispose();
    super.dispose();
  }

  // ── File picking ──────────────────────────────────────────────────────────

  Future<void> _pickFile() async {
    if (_processing) return;
    final res = await FilePicker.platform.pickFiles(
      type: FileType.any,
      withData: false,
    );
    if (res == null || res.files.isEmpty) return;
    final file = res.files.first;
    final path = file.path;
    if (path == null) return;

    final ext = file.name.toLowerCase().split('.').last;
    if (ext != 'php' && ext != 'zip') {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Please select a .php or .zip file'),
            backgroundColor: const Color(0xFF1a1a2e),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        );
      }
      return;
    }

    final name = file.name;
    final isZip = name.toLowerCase().endsWith('.zip');
    int phpCount = 0;

    if (isZip) {
      try {
        final bytes = File(path).readAsBytesSync();
        final archive = ZipDecoder().decodeBytes(bytes);
        for (final e in archive.files) {
          if (!e.isFile) continue;
          if (e.name.toLowerCase().endsWith('.php')) phpCount++;
        }
      } catch (_) {
        phpCount = 0;
      }
    } else {
      phpCount = 1;
    }

    setState(() {
      _filePath     = path;
      _fileName     = name;
      _isZip        = isZip;
      _phpFileCount = phpCount;
      _log          = '';
      _done         = false;
      _success      = false;
      _outputPath   = null;
    });
  }

  // ── Logging ───────────────────────────────────────────────────────────────

  void _appendLog(String line) {
    if (!mounted) return;
    setState(() => _log += '$line\n');
    if (_autoScroll) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_logCtrl.hasClients) {
          _logCtrl.animateTo(
            _logCtrl.position.maxScrollExtent,
            duration: const Duration(milliseconds: 180),
            curve: Curves.easeOut,
          );
        }
      });
    }
  }

  // ── Obfuscate single PHP string via worker ────────────────────────────────

  /// Client-side PHP whitespace compression (mirrors the site's HTML-minifier step)
  String _compressPhpSource(String source) {
    // Strip single-line comments (//) outside strings
    // Strip multi-line comments (/* */)
    // Collapse multiple blank lines → single
    String out = source
        .replaceAll(RegExp(r'/\*.*?\*/', dotAll: true), ' ')  // block comments
        .replaceAll(RegExp(r'//[^\n]*'),                  '')  // line comments
        .replaceAll(RegExp(r'[ \t]+'),                    ' ') // spaces/tabs → single
        .replaceAll(RegExp(r'\n\s*\n+'),               '\n')   // blank lines
        .trim();
    return out;
  }

  /// Returns (result, errorMessage). On success errorMessage is null.
  Future<(String?, String?)> _obfuscatePhp(String source) async {
    if (_workerUrl.isEmpty) {
      return (null, 'Worker URL not loaded yet — try again in a moment');
    }
    try {
      final payload = _compressMode ? _compressPhpSource(source) : source;
      final uri = Uri.parse('$_workerUrl/php-obfuscate?evalMode=${_evalMode ? 1 : 0}');
      final resp = await http.post(
        uri,
        headers: {'Content-Type': 'text/plain; charset=UTF-8'},
        body: utf8.encode(payload),
      ).timeout(const Duration(seconds: 90));
      if (resp.statusCode == 429) {
        return (null, 'Rate-limited by upstream (429) — wait a moment and retry');
      }
      if (resp.statusCode != 200) {
        String detail = '';
        try {
          final body = resp.body;
          if (body.isNotEmpty && body.length < 300) detail = ' — $body';
        } catch (_) {}
        return (null, 'HTTP ${resp.statusCode}$detail');
      }
      final body = resp.body;
      if (body.isEmpty) {
        return (null, 'Upstream returned empty response');
      }
      return (body, null);
    } on TimeoutException {
      return (null, 'Request timed out (90 s)');
    } catch (e) {
      return (null, e.toString());
    }
  }

  // ── Alom session restore ──────────────────────────────────────────────────

  Future<void> _restoreAlomSession() async {
    final s = await HbcChannel.phpAlomState();
    if (!mounted) return;
    if (s['running'] == true) {
      setState(() {
        _processing = true;
        _alomMode   = true;
        _log        = (s['log'] as String?) ?? '';
        _done       = false;
        _success    = false;
      });
      _startAlomPoll();
    } else if (s['status'] == 'done' || s['status'] == 'error') {
      _applyAlomFinished(s);
    }
  }

  Future<void> _checkAlomState() async {
    if (_alomPollTimer == null) return;
    final s = await HbcChannel.phpAlomState();
    if (!mounted) return;
    if (s['running'] != true) {
      _alomPollTimer?.cancel();
      _applyAlomFinished(s);
    }
  }

  void _startAlomPoll() {
    _alomPollTimer?.cancel();
    _alomPollTimer = Timer.periodic(const Duration(seconds: 3), (_) async {
      final s = await HbcChannel.phpAlomState();
      if (!mounted) return;
      final newLog = (s['log'] as String?) ?? '';
      if (newLog != _log) setState(() => _log = newLog);
      if (s['running'] != true) {
        _alomPollTimer?.cancel();
        _applyAlomFinished(s);
      }
    });
  }

  void _applyAlomFinished(Map<String, dynamic> s) {
    final success    = s['success'] == true;
    final outputPath = s['outputPath'] as String?;
    final logText    = (s['log'] as String?) ?? _log;
    setState(() {
      _processing = false;
      _done       = true;
      _success    = success;
      _outputPath = outputPath;
      _log        = logText;
    });
  }

  // ── Main processing ───────────────────────────────────────────────────────

  Future<void> _run() async {
    if (_filePath == null || _processing) return;
    setState(() {
      _processing = true;
      _done       = false;
      _success    = false;
      _outputPath = null;
      _log        = '';
    });

    try {
      if (_alomMode) {
        await _runAlom();
        return;
      } else if (_isZip) {
        await _runZip();
      } else {
        await _runSingle();
      }
    } catch (e) {
      _appendLog('[ERROR] Unexpected: $e');
      setState(() { _done = true; _success = false; });
    } finally {
      if (mounted && !_alomMode) setState(() => _processing = false);
    }
  }

  Future<void> _runSingle() async {
    _appendLog('[INFO]  Reading $_fileName…');
    final source = await File(_filePath!).readAsString();
    _appendLog('[INFO]  Source: ${source.length} chars — sending to cloud…');
    _appendLog('[CLOUD] Establishing secure obfuscation session…');

    final (result, errMsg) = await _obfuscatePhp(source);
    if (result == null || result.isEmpty) {
      _appendLog('[ERROR] Obfuscation failed — ${errMsg ?? 'unknown error'}');
      setState(() { _done = true; _success = false; });
      return;
    }

    _appendLog('[OK]    Obfuscated: ${result.length} chars');
    final baseName = _fileName!.replaceAll(RegExp(r'\.php$', caseSensitive: false), '');
    final outPath  = await _saveBytes(utf8.encode(result), '${baseName}_obfuscated.php');
    if (outPath == null) {
      _appendLog('[ERROR] Could not save output file.');
      setState(() { _done = true; _success = false; });
      return;
    }

    _appendLog('[SAVED] → ${outPath.split('/').last}');
    setState(() { _done = true; _success = true; _outputPath = outPath; });
  }

  Future<void> _runZip() async {
    _appendLog('[INFO]  Reading ZIP: $_fileName…');
    final bytes   = await File(_filePath!).readAsBytes();
    final archive = ZipDecoder().decodeBytes(bytes);

    final phpEntries = archive.files.where((e) => e.isFile && e.name.toLowerCase().endsWith('.php')).toList();
    final total = phpEntries.length;
    _appendLog('[INFO]  Found $total PHP file${total == 1 ? "" : "s"} in ZIP.');

    final outArchive = Archive();
    int done = 0;
    int failed = 0;

    for (final entry in archive.files) {
      if (!entry.isFile) continue;
      if (entry.name.toLowerCase().endsWith('.php')) {
        done++;
        _appendLog('[${done.toString().padLeft(3)}/$total] ${entry.name}');
        try {
          final src = utf8.decode(entry.content as List<int>);
          _appendLog('         Sending to cloud…');
          final (result, errMsg) = await _obfuscatePhp(src);
          if (result == null || result.isEmpty) {
            _appendLog('[WARN]   Failed (${errMsg ?? 'unknown'}) — keeping original.');
            outArchive.addFile(ArchiveFile(entry.name, entry.size, entry.content));
            failed++;
          } else {
            final outBytes = utf8.encode(result);
            outArchive.addFile(ArchiveFile(entry.name, outBytes.length, outBytes));
            _appendLog('[OK]     ${result.length} chars');
          }
        } catch (e) {
          _appendLog('[WARN]   $e — keeping original.');
          outArchive.addFile(ArchiveFile(entry.name, entry.size, entry.content));
          failed++;
        }
        // Rate-limit: 1 req/sec to avoid 429 from cloud
        if (done < total) await Future.delayed(const Duration(milliseconds: 1100));
      } else {
        outArchive.addFile(ArchiveFile(entry.name, entry.size, entry.content));
      }
    }

    _appendLog('\n[INFO]  Repacking ZIP…');
    final outBytes = ZipEncoder().encode(outArchive);
    if (outBytes == null) {
      _appendLog('[ERROR] ZIP encoding failed.');
      setState(() { _done = true; _success = false; });
      return;
    }

    final baseName = _fileName!.replaceAll(RegExp(r'\.zip$', caseSensitive: false), '');
    final outPath  = await _saveBytes(outBytes, '${baseName}_obfuscated.zip');
    if (outPath == null) {
      _appendLog('[ERROR] Could not save output ZIP.');
      setState(() { _done = true; _success = false; });
      return;
    }

    _appendLog('[SAVED] → ${outPath.split('/').last}');
    if (failed > 0) _appendLog('[WARN]  $failed file${failed == 1 ? "" : "s"} could not be obfuscated and were kept as-is.');
    setState(() { _done = true; _success = failed < total; _outputPath = outPath; });
  }

  // ── Alom cloud workflow (delegates to PhpEncryptorService foreground service) ──

  Future<void> _runAlom() async {
    _appendLog('[INFO]  Preparing ZIP for Alom cloud service...');

    String zipPath;
    String baseName;

    if (_isZip) {
      zipPath  = _filePath!;
      baseName = _fileName!.replaceAll(RegExp(r'\.zip$', caseSensitive: false), '');
      _appendLog('[INFO]  ZIP: $_fileName');
    } else {
      final source  = await File(_filePath!).readAsBytes();
      final arc     = Archive();
      arc.addFile(ArchiveFile(_fileName!, source.length, source));
      final encoded = ZipEncoder().encode(arc);
      if (encoded == null) {
        _appendLog('[ERROR] Failed to wrap PHP file into ZIP');
        setState(() { _done = true; _success = false; _processing = false; });
        return;
      }
      final tmpDir  = Directory('${(await getTemporaryDirectory()).path}/alom_tmp');
      tmpDir.createSync(recursive: true);
      final tmpFile = File('${tmpDir.path}/${_fileName}.zip');
      await tmpFile.writeAsBytes(encoded);
      zipPath  = tmpFile.path;
      baseName = _fileName!.replaceAll(RegExp(r'\.php$', caseSensitive: false), '');
      _appendLog('[INFO]  Wrapped $_fileName into ZIP');
    }

    final outputDir = await StorageHelper.buildOutputDir(prefix: 'alom');
    await HbcChannel.phpAlomClearState();

    try {
      await HbcChannel.phpAlomStart(
        zipPath:   zipPath,
        baseName:  baseName,
        depth:     _alomDepth,
        outputDir: outputDir,
      );
    } catch (e) {
      _appendLog('[ERROR] Could not start Alom service: $e');
      setState(() { _done = true; _success = false; _processing = false; });
      return;
    }

    _appendLog('[CLOUD] Alom service started — running in background...');
    _startAlomPoll();
  }

  // ── File saving ───────────────────────────────────────────────────────────

  Future<String?> _saveBytes(List<int> bytes, String name) async {
    try {
      final dir  = await StorageHelper.buildOutputDir(prefix: 'phpobf');
      final file = File('$dir/$name');
      await file.writeAsBytes(bytes);
      return file.path;
    } catch (_) {
      return null;
    }
  }

  Future<String?> _saveBytesAlom(List<int> bytes, String name) async {
    try {
      final dir  = await StorageHelper.buildOutputDir(prefix: 'alom');
      final file = File('$dir/$name');
      await file.writeAsBytes(bytes);
      return file.path;
    } catch (_) {
      return null;
    }
  }

  // ── Share ─────────────────────────────────────────────────────────────────

  Future<void> _share() async {
    if (_outputPath == null) return;
    await Share.shareXFiles([XFile(_outputPath!)]);
  }

  // ── Copy path ─────────────────────────────────────────────────────────────

  void _copyPath() {
    if (_outputPath == null) return;
    Clipboard.setData(ClipboardData(text: _outputPath!));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Path copied', style: TextStyle(color: Colors.white)),
        backgroundColor: _kAccent.withOpacity(0.85),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  // ── UI ────────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      appBar: AppBar(
        backgroundColor: _kBg,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded, color: Colors.white, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          widget.initialAlomMode ? 'PHP Alom' : 'PHP Cloud',
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 18),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: Colors.white70, size: 22),
            tooltip: 'Reset',
            onPressed: _processing ? null : _resetScreen,
          ),
          Container(
            margin: const EdgeInsets.only(right: 14, top: 10, bottom: 10),
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              color: widget.initialAlomMode
                  ? const Color(0xFF9B59B6).withOpacity(0.12)
                  : _kAccent.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: widget.initialAlomMode
                    ? const Color(0xFF9B59B6).withOpacity(0.35)
                    : _kAccent.withOpacity(0.35),
                width: 1,
              ),
            ),
            alignment: Alignment.center,
            child: Text(
              widget.initialAlomMode ? 'ALOM' : 'CLOUD',
              style: TextStyle(
                fontSize: 9.5,
                color: widget.initialAlomMode ? const Color(0xFF9B59B6) : _kAccent,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.5,
              ),
            ),
          ),
        ],
      ),
      body: FadeTransition(
        opacity: _cardFade,
        child: SlideTransition(
          position: _cardSlide,
          child: SingleChildScrollView(
            controller: _pageCtrl,
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 30),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildHeroBanner(),
                const SizedBox(height: 16),
                _buildModeToggle(),
                const SizedBox(height: 14),
                if (!_manualMode) ...[
                  _buildFilePicker(),
                  const SizedBox(height: 12),
                  _buildSettings(),
                  const SizedBox(height: 14),
                  _buildRunButton(),
                  if (_log.isNotEmpty) ...[
                    const SizedBox(height: 14),
                    _buildLog(),
                  ],
                  if (_done) ...[
                    const SizedBox(height: 14),
                    _buildOutput(),
                  ],
                ] else ...[
                  _buildManualBody(),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ── Hero PHP brand banner ──────────────────────────────────────────────────

  Widget _buildHeroBanner() {
    return AnimatedBuilder(
      animation: Listenable.merge([_pulseAnim, _glowAnim, _orbitCtrl, _scanAnim]),
      builder: (_, __) {
        final pulse    = _pulseAnim.value;
        final glow     = _glowAnim.value;
        final scan     = _scanAnim.value;
        final scanY    = scan * 110.0;
        final scanOp   = scan < 0.5
            ? (scan * 2).clamp(0.0, 1.0)
            : ((1.0 - scan) * 2).clamp(0.0, 1.0);

        return ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(20, 22, 20, 22),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              gradient: LinearGradient(
                colors: [
                  Color.lerp(const Color(0xFF0d0d22), const Color(0xFF131330), pulse)!,
                  Color.lerp(const Color(0xFF0a0a1a), const Color(0xFF0e0e28), glow)!,
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              border: Border.all(
                color: Color.lerp(
                  _kAccent.withOpacity(0.28),
                  _kAccentGlow.withOpacity(0.52),
                  pulse,
                )!,
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: _kAccent.withOpacity(0.06 + glow * 0.12),
                  blurRadius: 28 + 18 * glow,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: Stack(
              children: [
                // Scan line sweep
                Positioned(
                  top: scanY, left: 0, right: 0,
                  child: Opacity(
                    opacity: scanOp * 0.38,
                    child: Container(
                      height: 1.5,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [
                          Colors.transparent,
                          _kAccentGlow.withOpacity(0.9),
                          Colors.transparent,
                        ]),
                      ),
                    ),
                  ),
                ),
                Row(
                  children: [
                    // PHP icon with orbit ring
                    SizedBox(
                      width: 80, height: 80,
                      child: Stack(alignment: Alignment.center, children: [
                        // Orbit arc
                        Transform.rotate(
                          angle: _orbitCtrl.value * 2 * math.pi,
                          child: CustomPaint(
                            size: const Size(80, 80),
                            painter: _PhpOrbitPainter(
                              color: Color.lerp(_kAccent, _kAccentGlow, pulse)!,
                              opacity: 0.38 + pulse * 0.22,
                            ),
                          ),
                        ),
                        // Counter orbit (slower, opposite)
                        Transform.rotate(
                          angle: -_orbitCtrl.value * 2 * math.pi * 0.45,
                          child: CustomPaint(
                            size: const Size(62, 62),
                            painter: _PhpDotPainter(
                              color: _kAccentGlow,
                              opacity: 0.25 + pulse * 0.18,
                            ),
                          ),
                        ),
                        // PHP icon box
                        Transform.scale(
                          scale: 1.0 + pulse * 0.04,
                          child: Container(
                            width: 58, height: 58,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15),
                              gradient: LinearGradient(
                                colors: [
                                  _kAccent.withOpacity(0.30 + pulse * 0.12),
                                  _kAccentDim.withOpacity(0.15 + pulse * 0.08),
                                ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: _kAccent.withOpacity(0.22 + glow * 0.20),
                                  blurRadius: 16, spreadRadius: 1,
                                ),
                              ],
                              border: Border.all(
                                color: _kAccent.withOpacity(0.35 + pulse * 0.22),
                                width: 1.2,
                              ),
                            ),
                            alignment: Alignment.center,
                            child: Text(
                              'PHP',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w900,
                                color: Color.lerp(_kAccent, _kAccentGlow, pulse),
                                letterSpacing: 1.5,
                              ),
                            ),
                          ),
                        ),
                      ]),
                    ),
                    const SizedBox(width: 18),
                    // Title and badges
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Text(
                                'PHP Obfuscator',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 19,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 0.4,
                                ),
                              ),
                              const SizedBox(width: 8),
                              _kBadge('CLOUD'),
                            ],
                          ),
                          const SizedBox(height: 6),
                          Text(
                            'goto-obfuscation · eval mode',
                            style: TextStyle(
                              color: _kAccent.withOpacity(0.72),
                              fontSize: 11.5,
                              fontWeight: FontWeight.w500,
                              letterSpacing: 0.2,
                            ),
                          ),
                          const SizedBox(height: 3),
                          const Text(
                            'Cloud-powered · .php & .zip support',
                            style: TextStyle(
                              color: Color(0xFF9ca3af),
                              fontSize: 10.5,
                              height: 1.4,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _kBadge(String text) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
    decoration: BoxDecoration(
      color: _kAccent.withOpacity(0.15),
      borderRadius: BorderRadius.circular(6),
      border: Border.all(color: _kAccent.withOpacity(0.40)),
    ),
    child: Text(
      text,
      style: const TextStyle(
        color: _kAccent,
        fontSize: 9.5,
        fontWeight: FontWeight.w800,
        letterSpacing: 1.4,
      ),
    ),
  );

  // ── File picker card ──────────────────────────────────────────────────────

  Widget _buildFilePicker() {
    final hasFile = _filePath != null;
    return GestureDetector(
      onTap: _processing ? null : _pickFile,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
        decoration: BoxDecoration(
          color: _kCard,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: hasFile ? _kAccent.withOpacity(0.5) : _kBorder,
            width: hasFile ? 1.5 : 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: _kAccent.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _kAccent.withOpacity(0.25)),
              ),
              child: Icon(
                hasFile ? Icons.description_rounded : Icons.file_open_rounded,
                color: _kAccent,
                size: 22,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: hasFile
                  ? Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _fileName!,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 14,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 3),
                        Text(
                          _isZip
                              ? '$_phpFileCount PHP file${_phpFileCount == 1 ? "" : "s"} found in ZIP'
                              : 'Single PHP file',
                          style: TextStyle(
                            color: _kAccent.withOpacity(0.7),
                            fontSize: 12,
                          ),
                        ),
                      ],
                    )
                  : const Text(
                      'Tap to pick a .php or .zip file',
                      style: TextStyle(color: Colors.white54, fontSize: 14),
                    ),
            ),
            Icon(
              Icons.chevron_right_rounded,
              color: Colors.white.withOpacity(0.25),
            ),
          ],
        ),
      ),
    );
  }

  // ── Settings card ─────────────────────────────────────────────────────────

  void _resetScreen() {
    setState(() {
      _filePath   = null;
      _fileName   = null;
      _log        = '';
      _done       = false;
      _success    = false;
      _processing = false;
      _outputPath = null;
      if (!widget.initialAlomMode) {
        _compressMode = true;
        _evalMode     = false;
      } else {
        _alomDepth = 3;
      }
    });
  }

  Widget _buildSettings() {
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF0f0f22), Color(0xFF0c0c1c)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFF252545), width: 1.2),
      ),
      child: widget.initialAlomMode
          ? _buildAlomSettings()
          : _buildCloudSettings(),
    );
  }

  // PHP Cloud settings: Compress + Mode Eval only
  Widget _buildCloudSettings() {
    return Column(
      children: [
        _buildToggleRow(
          icon: Icons.format_indent_decrease_rounded,
          title: 'Compress the HTML, CSS and Javascript',
          subtitle: 'Strips comments & whitespace from embedded HTML/CSS/JS before obfuscating',
          value: _compressMode,
          onChanged: _processing ? null : (v) => setState(() => _compressMode = v),
        ),
        Divider(color: Colors.white.withOpacity(0.06), height: 1, indent: 16, endIndent: 16),
        _buildToggleRow(
          icon: Icons.code_rounded,
          title: 'Mode Eval',
          subtitle: 'Wraps output in eval(base64_decode(…)) for maximum obfuscation depth',
          value: _evalMode,
          onChanged: _processing ? null : (v) => setState(() => _evalMode = v),
        ),
      ],
    );
  }

  // PHP Alom settings: depth selector only
  Widget _buildAlomSettings() {
    const kPurple    = Color(0xFF9B59B6);
    const kPurpleGlow = Color(0xFFBB7FD4);
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: kPurple.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(9),
                ),
                child: const Icon(Icons.tune_rounded, color: kPurpleGlow, size: 16),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Text(
                  'Obfuscation depth',
                  style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              _buildDepthChip(1, 'Fast'),
              const SizedBox(width: 6),
              _buildDepthChip(2, 'Balanced'),
              const SizedBox(width: 6),
              _buildDepthChip(3, 'Strong'),
            ],
          ),
        ),
        Divider(color: Colors.white.withOpacity(0.06), height: 1, indent: 16, endIndent: 16),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: kPurple.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(9),
                ),
                child: const Icon(Icons.info_outline_rounded, color: kPurpleGlow, size: 16),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Alom Cloud Obfuscator', style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 2),
                    Text(
                      'Structural rewrite via private cloud runner. Rewrites variable names, flattens control flow, encodes strings at bytecode level.',
                      style: TextStyle(color: Colors.white.withOpacity(0.45), fontSize: 11.5, height: 1.4),
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: _showAlomInfo,
                child: Container(
                  padding: const EdgeInsets.all(5),
                  decoration: BoxDecoration(
                    color: kPurple.withOpacity(0.12),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.help_outline_rounded, color: kPurpleGlow, size: 15),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildDepthChip(int depth, String label) {
    final selected = _alomDepth == depth;
    return GestureDetector(
      onTap: _processing ? null : () => setState(() => _alomDepth = depth),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: selected ? _kAccent.withOpacity(0.22) : Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: selected ? _kAccent.withOpacity(0.70) : Colors.white.withOpacity(0.10),
            width: 1.2,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: selected ? _kAccentGlow : Colors.white54,
            fontSize: 11,
            fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
          ),
        ),
      ),
    );
  }

  void _showAlomInfo() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Container(
        decoration: const BoxDecoration(
          color: Color(0xFF0f0f22),
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 36),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 38, height: 4,
                decoration: BoxDecoration(color: Colors.white12, borderRadius: BorderRadius.circular(2)),
              ),
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _kAccent.withOpacity(0.14),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _kAccent.withOpacity(0.35)),
                  ),
                  child: const Icon(Icons.cloud_sync_rounded, color: _kAccentGlow, size: 18),
                ),
                const SizedBox(width: 12),
                const Text(
                  'Alom Cloud Obfuscator',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 14),
                ),
              ],
            ),
            const SizedBox(height: 16),
            _evalInfoRow(
              Icons.info_outline_rounded,
              'What it does',
              'Uploads your PHP files to a private cloud runner which runs Alom — a proper AST-based PHP obfuscator. It rewrites variable names, flattens control flow, and encodes strings at the bytecode level. The result is returned as a ZIP.',
              _kAccentGlow,
            ),
            const SizedBox(height: 12),
            _evalInfoRow(
              Icons.speed_rounded,
              'How long it takes',
              'Typically 2–5 minutes total: upload, queue, obfuscate, download. The cloud worker is ephemeral and spun up fresh each time.',
              const Color(0xFF34D399),
            ),
            const SizedBox(height: 12),
            _evalInfoRow(
              Icons.tune_rounded,
              'Depth levels',
              'Fast (1) — minimal renaming, fastest output. Balanced (2) — default, good protection. Strong (3) — full structural rewrite, heaviest output.',
              const Color(0xFFFBBF24),
            ),
            const SizedBox(height: 12),
            _evalInfoRow(
              Icons.warning_amber_rounded,
              'Compatibility note',
              'Alom requires PHP ≤ 8.0. Files targeting PHP 8.1+ features (enums, fibers) may be kept as-is if Alom cannot parse them.',
              const Color(0xFFFC8181),
            ),
          ],
        ),
      ),
    );
  }

  Widget _evalInfoRow(IconData icon, String heading, String body, Color color) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 1),
          child: Icon(icon, color: color, size: 16),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                heading,
                style: TextStyle(
                  color: color,
                  fontWeight: FontWeight.w700,
                  fontSize: 12,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                body,
                style: const TextStyle(
                  color: Color(0xFF9ca3af),
                  fontSize: 11,
                  height: 1.5,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildToggleRow({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool>? onChanged,
    VoidCallback? onHelpTap,
  }) {
    final enabled = onChanged != null;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(11),
              gradient: LinearGradient(
                colors: [
                  _kAccent.withOpacity(value ? 0.28 : 0.10),
                  _kAccentDim.withOpacity(value ? 0.14 : 0.05),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              border: Border.all(
                color: _kAccent.withOpacity(value ? 0.55 : 0.20),
              ),
              boxShadow: value
                  ? [BoxShadow(color: _kAccent.withOpacity(0.22), blurRadius: 10)]
                  : [],
            ),
            child: Icon(icon, color: _kAccent.withOpacity(value ? 1.0 : 0.50), size: 18),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        title,
                        style: TextStyle(
                          color: enabled ? Colors.white : Colors.white38,
                          fontWeight: FontWeight.w700,
                          fontSize: 12.5,
                        ),
                      ),
                    ),
                    if (onHelpTap != null) ...[
                      const SizedBox(width: 6),
                      GestureDetector(
                        onTap: onHelpTap,
                        child: Container(
                          width: 18,
                          height: 18,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _kAccent.withOpacity(0.15),
                            border: Border.all(color: _kAccent.withOpacity(0.40)),
                          ),
                          child: const Center(
                            child: Text(
                              '?',
                              style: TextStyle(
                                color: _kAccentGlow,
                                fontSize: 10,
                                fontWeight: FontWeight.w800,
                                height: 1,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 3),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: Colors.white.withOpacity(enabled ? 0.42 : 0.22),
                    fontSize: 11,
                    height: 1.35,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          // Custom styled toggle
          GestureDetector(
            onTap: enabled ? () => onChanged(!value) : null,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 46,
              height: 26,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(13),
                gradient: value
                    ? LinearGradient(colors: [_kAccentGlow, _kAccent])
                    : null,
                color: value ? null : Colors.white.withOpacity(0.10),
                border: Border.all(
                  color: value ? _kAccent.withOpacity(0.6) : Colors.white.withOpacity(0.18),
                  width: 1,
                ),
                boxShadow: value
                    ? [BoxShadow(color: _kAccent.withOpacity(0.35), blurRadius: 8)]
                    : [],
              ),
              child: AnimatedAlign(
                duration: const Duration(milliseconds: 200),
                curve: Curves.easeInOut,
                alignment: value ? Alignment.centerRight : Alignment.centerLeft,
                child: Container(
                  width: 20,
                  height: 20,
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: value ? Colors.white : Colors.white.withOpacity(0.45),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.25),
                        blurRadius: 4,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Run button ────────────────────────────────────────────────────────────

  Widget _buildRunButton() {
    final canRun = _filePath != null && !_processing;
    return AnimatedBuilder(
      animation: _pulseAnim,
      builder: (_, child) => GestureDetector(
        onTap: canRun ? _run : null,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          height: 56,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: canRun
                ? LinearGradient(colors: [
                    _kAccent,
                    _kAccentDim,
                  ])
                : null,
            color: canRun ? null : Colors.white.withOpacity(0.06),
            boxShadow: canRun
                ? [
                    BoxShadow(
                      color: _kAccent.withOpacity(0.2 + 0.2 * _pulseAnim.value),
                      blurRadius: 16 + 12 * _pulseAnim.value,
                      spreadRadius: 1,
                    )
                  ]
                : [],
          ),
          child: child,
        ),
      ),
      child: Center(
        child: _processing
            ? Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: Colors.white.withOpacity(0.8),
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Text(
                    'Obfuscating…',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 15,
                    ),
                  ),
                ],
              )
            : Text(
                _filePath == null ? 'Pick a file first' : 'Obfuscate',
                style: TextStyle(
                  color: canRun ? Colors.white : Colors.white38,
                  fontWeight: FontWeight.w800,
                  fontSize: 15,
                  letterSpacing: 0.5,
                ),
              ),
      ),
    );
  }

  // ── Log terminal ──────────────────────────────────────────────────────────

  Widget _buildLog() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Icon(Icons.terminal_rounded, color: _kAccent, size: 15),
            const SizedBox(width: 6),
            const Text(
              'TERMINAL',
              style: TextStyle(
                color: _kAccent,
                fontSize: 11,
                fontWeight: FontWeight.w700,
                letterSpacing: 2,
              ),
            ),
            const Spacer(),
            GestureDetector(
              onTap: () => Clipboard.setData(ClipboardData(text: _log)),
              child: Icon(Icons.copy_rounded, color: Colors.white.withOpacity(0.3), size: 16),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          height: 220,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFF030303),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _kAccent.withOpacity(0.15), width: 1),
          ),
          child: SingleChildScrollView(
            controller: _logCtrl,
            child: Text(
              _log,
              style: const TextStyle(
                fontFamily: 'monospace',
                fontSize: 11.5,
                color: Color(0xFFB0C4DE),
                height: 1.6,
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ── Output section ────────────────────────────────────────────────────────

  Widget _buildOutput() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _kCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: (_success ? _kAccent : _kRed).withOpacity(0.35),
          width: 1.5,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                _success ? Icons.check_circle_rounded : Icons.error_rounded,
                color: _success ? _kAccent : _kRed,
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                _success ? 'Obfuscation complete' : 'Obfuscation failed',
                style: TextStyle(
                  color: _success ? _kAccent : _kRed,
                  fontWeight: FontWeight.w700,
                  fontSize: 14,
                ),
              ),
            ],
          ),
          if (_outputPath != null) ...[
            const SizedBox(height: 10),
            GestureDetector(
              onTap: _copyPath,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.04),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.white.withOpacity(0.08)),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        _outputPath!,
                        style: const TextStyle(
                          fontFamily: 'monospace',
                          fontSize: 11,
                          color: Colors.white60,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Icon(Icons.copy_rounded, size: 14, color: Colors.white.withOpacity(0.35)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _OutButton(
                    label: 'Share',
                    icon: Icons.share_rounded,
                    color: _kAccent,
                    onTap: _share,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _OutButton(
                    label: 'Run Again',
                    icon: Icons.refresh_rounded,
                    color: Colors.white38,
                    onTap: () => setState(() {
                      _done     = false;
                      _log      = '';
                      _outputPath = null;
                    }),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  // ── Mode toggle ───────────────────────────────────────────────────────────

  Widget _buildModeToggle() {
    return Container(
      height: 42,
      decoration: BoxDecoration(
        color: const Color(0xFF0a0a1a),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _kBorder, width: 1),
      ),
      child: Row(
        children: [
          _modeBtn('Auto', !_manualMode, Icons.auto_awesome_rounded, () {
            if (_manualMode) setState(() => _manualMode = false);
          }),
          _modeBtn('Manual ZIP', _manualMode, Icons.account_tree_rounded, () {
            if (!_manualMode) setState(() => _manualMode = true);
          }),
        ],
      ),
    );
  }

  Widget _modeBtn(String label, bool active, IconData icon, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          margin: const EdgeInsets.all(3),
          decoration: BoxDecoration(
            color: active ? _kAccent.withOpacity(0.18) : Colors.transparent,
            borderRadius: BorderRadius.circular(9),
            border: active ? Border.all(color: _kAccent.withOpacity(0.45)) : null,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 14, color: active ? _kAccent : Colors.white30),
              const SizedBox(width: 6),
              Text(
                label,
                style: TextStyle(
                  color: active ? _kAccent : Colors.white30,
                  fontWeight: FontWeight.w700,
                  fontSize: 12.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Manual body ───────────────────────────────────────────────────────────

  Widget _buildManualBody() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // ZIP picker
        _buildSectionLabel('1', 'UPLOAD ZIP'),
        const SizedBox(height: 10),
        GestureDetector(
          onTap: _mProcessing ? null : _pickManualZip,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: _mZipPath != null ? _kAccent.withOpacity(0.07) : _kCard,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: _mZipPath != null ? _kAccent.withOpacity(0.45) : _kBorder,
                width: 1.3,
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: _kAccent.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    _mZipPath != null ? Icons.folder_zip_rounded : Icons.upload_file_rounded,
                    color: _kAccent,
                    size: 22,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _mZipPath != null ? (_mZipName ?? 'ZIP selected') : 'Tap to pick a .zip file',
                        style: TextStyle(
                          color: _mZipPath != null ? Colors.white : Colors.white38,
                          fontWeight: FontWeight.w700,
                          fontSize: 13.5,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      if (_mZipPath != null)
                        Text(
                          '${_mNodes.where((n) => n.isPhp).length} PHP files found',
                          style: TextStyle(
                            color: _kAccent.withOpacity(0.65),
                            fontSize: 11.5,
                          ),
                        ),
                    ],
                  ),
                ),
                Icon(Icons.chevron_right_rounded,
                    color: Colors.white.withOpacity(0.25)),
              ],
            ),
          ),
        ),

        // File tree
        if (_mNodes.isNotEmpty) ...[
          const SizedBox(height: 16),
          _buildSectionLabel('2', 'SELECT PHP FILES'),
          const SizedBox(height: 10),
          _buildSelectAllRow(),
          const SizedBox(height: 6),
          Container(
            decoration: BoxDecoration(
              color: _kCard,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _kBorder),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: Column(
                children: _mNodes
                    .where((n) => n.visible)
                    .map((n) => _buildTreeRow(n))
                    .toList(),
              ),
            ),
          ),
        ],

        // Settings (shared)
        if (_mZipPath != null) ...[
          const SizedBox(height: 16),
          _buildSectionLabel('3', 'SETTINGS'),
          const SizedBox(height: 10),
          _buildSettings(),
          const SizedBox(height: 16),
          _buildManualRunButton(),
        ],

        // Manual log
        if (_mLog.isNotEmpty) ...[
          const SizedBox(height: 14),
          _buildManualLog(),
        ],
        if (_mDone) ...[
          const SizedBox(height: 14),
          _buildManualOutput(),
        ],
      ],
    );
  }

  Widget _buildSectionLabel(String num, String text) {
    return Row(
      children: [
        Container(
          width: 22,
          height: 22,
          decoration: BoxDecoration(
            color: _kAccent.withOpacity(0.15),
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: _kAccent.withOpacity(0.35)),
          ),
          alignment: Alignment.center,
          child: Text(num,
            style: TextStyle(
                color: _kAccent, fontWeight: FontWeight.w900, fontSize: 11)),
        ),
        const SizedBox(width: 8),
        Text(text,
          style: const TextStyle(
            color: Colors.white54,
            fontWeight: FontWeight.w700,
            fontSize: 11,
            letterSpacing: 2,
          )),
      ],
    );
  }

  Widget _buildSelectAllRow() {
    final allPhp = _mNodes.where((n) => n.isPhp).toList();
    final allSelected = allPhp.every((n) => _mSelected.contains(n.path));
    return Row(
      children: [
        GestureDetector(
          onTap: () => setState(() {
            if (allSelected) {
              _mSelected.clear();
            } else {
              for (final n in allPhp) _mSelected.add(n.path);
            }
          }),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: _kAccent.withOpacity(0.10),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _kAccent.withOpacity(0.30)),
            ),
            child: Text(
              allSelected ? 'Deselect All' : 'Select All',
              style: TextStyle(
                color: _kAccent,
                fontWeight: FontWeight.w700,
                fontSize: 12,
              ),
            ),
          ),
        ),
        const SizedBox(width: 10),
        Text(
          '${_mSelected.length} of ${allPhp.length} selected',
          style: TextStyle(color: Colors.white38, fontSize: 12),
        ),
      ],
    );
  }

  Widget _buildTreeRow(_PhpZipNode node) {
    final sel = _mSelected.contains(node.path);
    final indent = 12.0 + node.depth * 18.0;
    if (node.isDir) {
      return GestureDetector(
        onTap: () => _toggleFolder(node),
        child: Container(
          padding: EdgeInsets.only(left: indent, right: 12, top: 10, bottom: 10),
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(color: Colors.white.withOpacity(0.04)),
            ),
          ),
          child: Row(
            children: [
              Icon(
                node.expanded
                    ? Icons.folder_open_rounded
                    : Icons.folder_rounded,
                color: _kAccent.withOpacity(0.6),
                size: 16,
              ),
              const SizedBox(width: 8),
              Text(
                node.name,
                style: const TextStyle(
                  color: Colors.white60,
                  fontSize: 12.5,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      );
    }
    // File row
    return GestureDetector(
      onTap: node.selectable ? () => _toggleFile(node) : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: EdgeInsets.only(left: indent, right: 12, top: 9, bottom: 9),
        decoration: BoxDecoration(
          color: sel
              ? _kAccent.withOpacity(0.10)
              : Colors.transparent,
          border: Border(
            bottom: BorderSide(color: Colors.white.withOpacity(0.04)),
          ),
        ),
        child: Row(
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              width: 18,
              height: 18,
              decoration: BoxDecoration(
                color: sel ? _kAccent : Colors.transparent,
                borderRadius: BorderRadius.circular(5),
                border: Border.all(
                  color: node.selectable
                      ? _kAccent.withOpacity(sel ? 1.0 : 0.35)
                      : Colors.white12,
                  width: 1.5,
                ),
              ),
              child: sel
                  ? const Icon(Icons.check_rounded,
                      size: 12, color: Colors.white)
                  : null,
            ),
            const SizedBox(width: 10),
            Icon(
              node.isPhp
                  ? Icons.code_rounded
                  : Icons.insert_drive_file_rounded,
              size: 14,
              color: node.isPhp
                  ? _kAccent.withOpacity(0.75)
                  : Colors.white.withOpacity(0.20),
            ),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                node.name,
                style: TextStyle(
                  color: node.selectable ? Colors.white : Colors.white30,
                  fontSize: 12.5,
                  fontFamily: 'monospace',
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            if (node.isPhp && !node.selectable == false)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: _kAccent.withOpacity(0.10),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: const Text(
                  'PHP',
                  style: TextStyle(
                    color: _kAccent,
                    fontSize: 9,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildManualRunButton() {
    final canRun = _mZipPath != null && _mSelected.isNotEmpty && !_mProcessing;
    return GestureDetector(
      onTap: canRun ? _runManualBatch : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        height: 52,
        decoration: BoxDecoration(
          gradient: canRun
              ? LinearGradient(colors: [_kAccentGlow, _kAccent, _kAccentDim])
              : null,
          color: canRun ? null : Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: canRun ? _kAccent.withOpacity(0.6) : Colors.white12,
          ),
          boxShadow: canRun
              ? [BoxShadow(color: _kAccent.withOpacity(0.30), blurRadius: 16)]
              : [],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (_mProcessing)
              const SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(
                    color: Colors.white, strokeWidth: 2.2),
              )
            else
              Icon(Icons.play_arrow_rounded,
                  color: canRun ? Colors.white : Colors.white24, size: 20),
            const SizedBox(width: 10),
            Text(
              _mProcessing
                  ? 'Obfuscating…'
                  : _mSelected.isEmpty
                      ? 'Select at least one file'
                      : 'Obfuscate ${_mSelected.length} file${_mSelected.length == 1 ? "" : "s"}',
              style: TextStyle(
                color: canRun ? Colors.white : Colors.white30,
                fontWeight: FontWeight.w800,
                fontSize: 14.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildManualLog() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Icon(Icons.terminal_rounded, color: _kAccent, size: 15),
            const SizedBox(width: 6),
            const Text(
              'TERMINAL',
              style: TextStyle(
                color: _kAccent,
                fontSize: 11,
                fontWeight: FontWeight.w700,
                letterSpacing: 2,
              ),
            ),
            const Spacer(),
            GestureDetector(
              onTap: () => Clipboard.setData(ClipboardData(text: _mLog)),
              child: Icon(Icons.copy_rounded,
                  color: Colors.white.withOpacity(0.3), size: 16),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          height: 220,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFF030303),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _kAccent.withOpacity(0.15), width: 1),
          ),
          child: SingleChildScrollView(
            controller: _mLogCtrl,
            child: Text(
              _mLog,
              style: const TextStyle(
                fontFamily: 'monospace',
                fontSize: 11.5,
                color: Color(0xFFB0C4DE),
                height: 1.6,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildManualOutput() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _kCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: (_mSuccess ? _kAccent : _kRed).withOpacity(0.35),
          width: 1.5,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                _mSuccess
                    ? Icons.check_circle_rounded
                    : Icons.error_rounded,
                color: _mSuccess ? _kAccent : _kRed,
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                _mSuccess ? 'Batch complete' : 'Batch failed',
                style: TextStyle(
                  color: _mSuccess ? _kAccent : _kRed,
                  fontWeight: FontWeight.w700,
                  fontSize: 14,
                ),
              ),
            ],
          ),
          if (_mOutputPath != null) ...[
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _OutButton(
                    label: 'Share',
                    icon: Icons.share_rounded,
                    color: _kAccent,
                    onTap: () async {
                      await Share.shareXFiles([XFile(_mOutputPath!)]);
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _OutButton(
                    label: 'Run Again',
                    icon: Icons.refresh_rounded,
                    color: Colors.white38,
                    onTap: () => setState(() {
                      _mDone       = false;
                      _mLog        = '';
                      _mOutputPath = null;
                    }),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  // ── Manual mode actions ───────────────────────────────────────────────────

  Future<void> _pickManualZip() async {
    if (_mProcessing) return;
    FilePickerResult? res;
    try {
      res = await FilePicker.platform.pickFiles(
        dialogTitle: 'Select ZIP file',
        type: FileType.custom,
        allowedExtensions: ['zip'],
      );
    } catch (_) {
      res = await FilePicker.platform.pickFiles(dialogTitle: 'Select ZIP file');
    }
    if (res == null || res.files.isEmpty) return;
    final f = res.files.first;
    if (f.path == null) return;
    if (!f.path!.toLowerCase().endsWith('.zip')) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            _snack('Please select a .zip file', isError: true));
      }
      return;
    }
    setState(() {
      _mZipPath = f.path;
      _mZipName = f.name;
      _mNodes   = [];
      _mSelected = {};
      _mDone    = false;
      _mLog     = '';
      _mOutputPath = null;
    });
    await _buildPhpZipTree(f.path!);
  }

  Future<void> _buildPhpZipTree(String zipPath) async {
    try {
      final bytes   = await File(zipPath).readAsBytes();
      final archive = ZipDecoder().decodeBytes(bytes);
      final dirPaths  = <String>{};
      final filePaths = <String>[];
      for (final entry in archive.files) {
        if (!entry.isFile) continue;
        filePaths.add(entry.name);
        final parts = entry.name.split('/');
        for (int i = 1; i < parts.length; i++) {
          dirPaths.add(parts.sublist(0, i).join('/'));
        }
      }
      final all = <String, bool>{};
      for (final d in dirPaths)  all[d] = true;
      for (final f in filePaths) all[f] = false;
      final sorted = all.keys.toList()..sort();
      final nodes = sorted.map((path) {
        final isDir = all[path]!;
        final depth = path.split('/').length - 1;
        return _PhpZipNode(path: path, isDir: isDir, depth: depth);
      }).toList();
      if (mounted) setState(() { _mNodes = nodes; });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(_snack('Cannot read ZIP: $e', isError: true));
      }
    }
  }

  void _toggleFolder(_PhpZipNode node) {
    final idx = _mNodes.indexOf(node);
    node.expanded = !node.expanded;
    final prefix = '${node.path}/';
    for (int i = idx + 1; i < _mNodes.length; i++) {
      final n = _mNodes[i];
      if (!n.path.startsWith(prefix)) break;
      if (n.depth == node.depth + 1) n.visible = node.expanded;
      else if (!node.expanded) n.visible = false;
      else {
        final parentPath = n.path.contains('/')
            ? n.path.substring(0, n.path.lastIndexOf('/'))
            : '';
        final parent =
            _mNodes.firstWhere((x) => x.path == parentPath, orElse: () => node);
        n.visible = parent.expanded;
      }
    }
    setState(() {});
  }

  void _toggleFile(_PhpZipNode node) {
    if (!node.selectable) return;
    setState(() {
      if (_mSelected.contains(node.path)) {
        _mSelected.remove(node.path);
      } else {
        _mSelected.add(node.path);
      }
    });
  }

  void _mAppendLog(String line) {
    if (!mounted) return;
    setState(() => _mLog += '$line\n');
    if (_mAutoScroll) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_mLogCtrl.hasClients) {
          _mLogCtrl.animateTo(
            _mLogCtrl.position.maxScrollExtent,
            duration: const Duration(milliseconds: 180),
            curve: Curves.easeOut,
          );
        }
      });
    }
  }

  Future<void> _runManualBatch() async {
    if (_mZipPath == null || _mSelected.isEmpty || _mProcessing) return;
    setState(() {
      _mProcessing = true;
      _mDone       = false;
      _mLog        = '';
      _mOutputPath = null;
    });

    try {
      final bytes   = await File(_mZipPath!).readAsBytes();
      final archive = ZipDecoder().decodeBytes(bytes);
      final total   = _mSelected.length;
      _mAppendLog('[INFO]  Processing $total selected PHP file${total == 1 ? "" : "s"}…');

      final outArchive = Archive();
      int done   = 0;
      int failed = 0;

      for (final entry in archive.files) {
        if (!entry.isFile) { continue; }
        if (_mSelected.contains(entry.name)) {
          done++;
          _mAppendLog('[${done.toString().padLeft(3)}/$total] ${entry.name}');
          try {
            final src = utf8.decode(entry.content as List<int>);
            final toSend = _compressMode ? _compressPhpSource(src) : src;
            _mAppendLog('         Sending to cloud…');
            final (result, errMsg) = await _obfuscatePhp(toSend);
            if (result == null || result.isEmpty) {
              _mAppendLog('[WARN]   Failed (${errMsg ?? 'unknown'}) — keeping original.');
              outArchive.addFile(ArchiveFile(entry.name, entry.size, entry.content));
              failed++;
            } else {
              final outBytes = utf8.encode(result);
              outArchive.addFile(ArchiveFile(entry.name, outBytes.length, outBytes));
              _mAppendLog('[OK]     ${result.length} chars');
            }
          } catch (e) {
            _mAppendLog('[WARN]   $e — keeping original.');
            outArchive.addFile(ArchiveFile(entry.name, entry.size, entry.content));
            failed++;
          }
          if (done < total) {
            await Future.delayed(const Duration(milliseconds: 1100));
          }
        } else {
          outArchive.addFile(ArchiveFile(entry.name, entry.size, entry.content));
        }
      }

      _mAppendLog('\n[INFO]  Repacking ZIP…');
      final outBytes = ZipEncoder().encode(outArchive);
      if (outBytes == null) {
        _mAppendLog('[ERROR] ZIP encoding failed.');
        setState(() { _mDone = true; _mSuccess = false; _mProcessing = false; });
        return;
      }

      final baseName = _mZipName!.replaceAll(RegExp(r'\.zip$', caseSensitive: false), '');
      final outPath  = await _saveBytes(outBytes, '${baseName}_manual.zip');
      if (outPath == null) {
        _mAppendLog('[ERROR] Could not save output ZIP.');
        setState(() { _mDone = true; _mSuccess = false; _mProcessing = false; });
        return;
      }

      _mAppendLog('[SAVED] → ${outPath.split('/').last}');
      if (failed > 0) {
        _mAppendLog('[WARN]  $failed file${failed == 1 ? "" : "s"} could not be obfuscated.');
      }
      setState(() {
        _mDone       = true;
        _mSuccess    = failed < total;
        _mOutputPath = outPath;
        _mProcessing = false;
      });
    } catch (e) {
      _mAppendLog('[ERROR] $e');
      setState(() { _mDone = true; _mSuccess = false; _mProcessing = false; });
    }
  }

  SnackBar _snack(String msg, {bool isError = false}) => SnackBar(
    content: Text(msg, style: const TextStyle(color: Colors.white)),
    backgroundColor: isError ? const Color(0xFFDC2626) : _kAccent,
    behavior: SnackBarBehavior.floating,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
  );
}

// ── Output action button ──────────────────────────────────────────────────────

class _OutButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _OutButton({required this.label, required this.icon, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 44,
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3), width: 1),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 16),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Orbit arc painter (PHP hero) ───────────────────────────────────────────────
class _PhpOrbitPainter extends CustomPainter {
  final Color color;
  final double opacity;
  const _PhpOrbitPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r  = size.width / 2 - 2;
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4
      ..strokeCap = StrokeCap.round;

    // Draw three arc segments
    const starts = [0.0, 0.38, 0.70];
    for (int i = 0; i < starts.length; i++) {
      final startAngle = starts[i] * 2 * math.pi;
      final sweepAngle = (0.22) * 2 * math.pi;
      paint.color = color.withOpacity(opacity * (1.0 - i * 0.2));
      canvas.drawArc(
        Rect.fromCircle(center: Offset(cx, cy), radius: r),
        startAngle,
        sweepAngle,
        false,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(_PhpOrbitPainter o) => o.color != color || o.opacity != opacity;
}

// ── Dot ring painter (PHP hero counter-orbit) ─────────────────────────────────
class _PhpDotPainter extends CustomPainter {
  final Color color;
  final double opacity;
  const _PhpDotPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r  = size.width / 2 - 2;
    final paint = Paint()
      ..style = PaintingStyle.fill
      ..color = color.withOpacity(opacity);

    const count = 6;
    for (int i = 0; i < count; i++) {
      final angle = (i / count) * 2 * math.pi;
      final x = cx + r * math.cos(angle);
      final y = cy + r * math.sin(angle);
      canvas.drawCircle(Offset(x, y), 1.8, paint);
    }
  }

  @override
  bool shouldRepaint(_PhpDotPainter o) => o.color != color || o.opacity != opacity;
}
