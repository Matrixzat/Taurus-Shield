import '../utils/theme_provider.dart';
import 'package:flutter/material.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      appBar: AppBar(
        
        title: const Text(
          'Privacy Policy',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.2,
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        elevation: 0,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            color: ThemeProvider().current.primary.withOpacity(0.25),
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 24, 16, 40),
        children: const [
          _PolicyHeader(),
          SizedBox(height: 20),
          _Section(
            icon: Icons.folder_off_outlined,
            title: 'File Access',
            body:
                'The app reads only the files you explicitly select and writes output only to the '
                'designated output folder on your device storage. It does not scan, index, or '
                'access any other files or directories.',
          ),
          _Section(
            icon: Icons.bar_chart_outlined,
            title: 'No Analytics or Tracking',
            body:
                'We do not use any analytics SDKs, crash reporters, advertising identifiers, '
                'or tracking libraries. Your usage patterns and behaviour are never monitored.',
          ),
          _Section(
            icon: Icons.security_rounded,
            title: 'Permissions',
            body:
                'The app requests only the storage permission required to read your selected '
                'files and save output to your device. No other device permissions are used.',
          ),
          _Section(
            icon: Icons.update_rounded,
            title: 'Policy Updates',
            body:
                'If this policy changes in a future version, the update will be noted in the '
                'app and the effective date below will be revised.',
          ),
          SizedBox(height: 24),
          _EffectiveDate(),
        ],
      ),
    );
  }
}

class _PolicyHeader extends StatelessWidget {
  const _PolicyHeader();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: ThemeProvider().current.primary.withOpacity(0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: ThemeProvider().current.primary.withOpacity(0.25)),
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: ThemeProvider().current.primary.withOpacity(0.15),
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.verified_user_rounded,
                color: ThemeProvider().current.secondary, size: 24),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Text(
              'Taurus Shield is built with your privacy as a core principle. '
              'This app is a fully offline tool — your files stay on your device, always.',
              style: TextStyle(
                color: Color(0xFFd1d5db),
                fontSize: 13,
                height: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Section extends StatelessWidget {
  final IconData icon;
  final String title;
  final String body;
  const _Section(
      {required this.icon, required this.title, required this.body});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Container(
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Color(0xFF12102a),
          borderRadius: BorderRadius.circular(14),
          border:
              Border.all(color: ThemeProvider().current.borderColor),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: ThemeProvider().current.primary, size: 20),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    body,
                    style: const TextStyle(
                      color: Color(0xFF9ca3af),
                      fontSize: 13,
                      height: 1.55,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _EffectiveDate extends StatelessWidget {
  const _EffectiveDate();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Effective date: March 2026',
        style: TextStyle(
          color: const Color(0xFF6b7280),
          fontSize: 11,
        ),
      ),
    );
  }
}
