import '../utils/theme_provider.dart';
import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:archive/archive.dart';
import '../utils/hbc_channel.dart';
import '../utils/storage_helper.dart';
import '../utils/permission_helper.dart';

const _kVmAccent      = Color(0xFF8B5CF6);
const _kVmAccentLight = Color(0xFFa78bfa);

class VmProtectScreen extends StatefulWidget {
  const VmProtectScreen({super.key});

  @override
  State<VmProtectScreen> createState() => _VmProtectScreenState();
}

class _VmProtectScreenState extends State<VmProtectScreen>
    with TickerProviderStateMixin {
  String? _selectedFilePath;
  String? _selectedFileName;
  bool    _isProcessing    = false;
  bool    _logVisible      = false;
  String  _logs            = '';
  String? _outputDir;
  int     _downloadProgress = -1;
  bool    _autoScroll      = true;
  String? _zipStatus;
  bool    _fileValid       = false;
  bool    _signApk         = true;
  StreamSubscription<String>? _streamSub;
  final Stopwatch _stopwatch = Stopwatch();
  Timer? _tickTimer;
  String _elapsed = '00:00';
  final ScrollController _logScrollCtrl  = ScrollController();
  final ScrollController _pageScrollCtrl = ScrollController();
  final GlobalKey        _logPanelKey    = GlobalKey();

  late final AnimationController _pulseCtrl;
  late final AnimationController _orbitCtrl;
  late final AnimationController _scanCtrl;
  late final AnimationController _logCtrl;
  late final Animation<double> _pulseAnim;
  late final Animation<double> _logFade;
  late final Animation<double> _scanAnim;

  static const _accent = _kVmAccent;

  @override
  void initState() {
    super.initState();

    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _orbitCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 5000),
    )..repeat();

    _scanCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2200),
    )..repeat();

    _logCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 400),
    );

    _pulseAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );

    _logFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _logCtrl, curve: Curves.easeOut),
    );

    _scanAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _scanCtrl, curve: Curves.easeInOut),
    );

    _checkCloudState();
  }

  Timer? _pollTimer;

  Future<void> _checkCloudState() async {
    try {
      final state = await HbcChannel.vmProtectCloudState();
      final running   = state['running'] == true;
      final status    = (state['status'] as String?) ?? '';
      final logs      = (state['logs'] as String?) ?? '';
      final filePath  = (state['filePath'] as String?) ?? '';
      final outputDir = (state['outputDir'] as String?) ?? '';

      if (running && mounted) {
        setState(() {
          _isProcessing = true;
          _logVisible   = true;
          _logs         = logs;
          _selectedFilePath = filePath.isNotEmpty ? filePath : _selectedFilePath;
          _selectedFileName = filePath.isNotEmpty
              ? filePath.split('/').last
              : _selectedFileName;
        });
        _logCtrl.forward(from: 0);
        if (!_stopwatch.isRunning) _startTimer();
        _startPollingCloudState();
      } else if (status == 'success' && mounted) {
        setState(() {
          _isProcessing = false;
          _logVisible   = true;
          _logs         = logs;
          _outputDir    = outputDir.isNotEmpty ? outputDir : null;
          _selectedFilePath = filePath.isNotEmpty ? filePath : _selectedFilePath;
          _selectedFileName = filePath.isNotEmpty
              ? filePath.split('/').last
              : _selectedFileName;
        });
        _logCtrl.forward(from: 0);
        _showSnack('Protection complete',
            icon: Icons.check_circle_rounded, color: const Color(0xFF22c55e));
      } else if (status == 'cancelled' && mounted) {
        setState(() {
          _isProcessing = false;
          _logVisible   = true;
          _logs         = logs;
        });
        _logCtrl.forward(from: 0);
        _showSnack('Protection cancelled',
            icon: Icons.cancel_outlined, color: const Color(0xFFf59e0b));
      } else if (status == 'error' && logs.isNotEmpty && mounted) {
        final error = (state['error'] as String?) ?? 'Protection failed';
        setState(() {
          _isProcessing = false;
          _logVisible   = true;
          _logs         = logs;
        });
        _logCtrl.forward(from: 0);
        _showSnack(error,
            icon: Icons.error_rounded, color: const Color(0xFFef4444));
      }
    } catch (_) {}
  }

  void _startPollingCloudState() {
    _pollTimer?.cancel();
    _streamSub?.cancel();

    _streamSub = HbcChannel.logStream.listen((line) {
      if (!mounted) return;
      if (line.startsWith('DOWNLOAD_PROGRESS:')) {
        final pct = int.tryParse(line.split(':').last) ?? -1;
        setState(() => _downloadProgress = pct);
        return;
      }
      if (line == '__TAURUS_DONE__') {
        _pollTimer?.cancel();
        _checkCloudState();
        return;
      }
      setState(() {
        _logs += (_logs.isEmpty ? '' : '\n') + line;
      });
      if (_autoScroll) _scrollLogToBottom();
    }, onDone: () {}, onError: (_) {});

    var consecutiveErrors = 0;
    const maxErrors = 6;

    _pollTimer = Timer.periodic(const Duration(seconds: 25), (_) async {
      if (!mounted) { _pollTimer?.cancel(); return; }
      try {
        final state     = await HbcChannel.vmProtectCloudState();
        consecutiveErrors = 0;
        final running   = state['running'] == true;
        final logs      = (state['logs'] as String?) ?? '';
        final status    = (state['status'] as String?) ?? '';
        final outputDir = (state['outputDir'] as String?) ?? '';

        if (logs != _logs && mounted) {
          setState(() { _logs = logs; });
          if (_autoScroll) _scrollLogToBottom();
        }

        if (!running) {
          _pollTimer?.cancel();
          _streamSub?.cancel();
          final success   = status == 'success';
          final cancelled = status == 'cancelled';
          final totalTime = _stopTimer();

          if (mounted) {
            setState(() {
              _isProcessing     = false;
              _logs             = logs;
              _outputDir        = outputDir.isNotEmpty ? outputDir : null;
              _downloadProgress = -1;
              if (cancelled) {
                _logs += '\nCancelled by user.\n';
              } else {
                _logs += '\n${success ? "Completed" : "Failed"} in $totalTime\n';
              }
            });
            if (cancelled) {
              _showSnack('Protection cancelled',
                  icon: Icons.cancel_outlined,
                  color: const Color(0xFFf59e0b));
            } else {
              _showSnack(
                success
                    ? 'Protection complete — $totalTime'
                    : 'Protection failed',
                icon: success
                    ? Icons.check_circle_rounded
                    : Icons.error_rounded,
                color: success
                    ? const Color(0xFF22c55e)
                    : const Color(0xFFef4444),
              );
            }
          }
        }
      } catch (_) {
        consecutiveErrors++;
        if (consecutiveErrors >= maxErrors && mounted) {
          _pollTimer?.cancel();
          _streamSub?.cancel();
          _stopTimer();
          setState(() {
            _isProcessing     = false;
            _downloadProgress = -1;
            _logs += '\nLost connection to protection service after '
                '$maxErrors attempts.\n';
          });
          _showSnack('Connection lost — check service status',
              icon: Icons.error_rounded, color: const Color(0xFFef4444));
        }
      }
    });
  }

  void _scrollLogToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_logScrollCtrl.hasClients) {
        _logScrollCtrl.animateTo(
          _logScrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _streamSub?.cancel();
    _tickTimer?.cancel();
    _pulseCtrl.dispose();
    _orbitCtrl.dispose();
    _scanCtrl.dispose();
    _logCtrl.dispose();
    _logScrollCtrl.dispose();
    _pageScrollCtrl.dispose();
    super.dispose();
  }

  String _formatDuration(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  void _startTimer() {
    _stopwatch.reset();
    _stopwatch.start();
    _tickTimer?.cancel();
    _tickTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _elapsed = _formatDuration(_stopwatch.elapsed));
    });
  }

  void _reset() {
    if (_isProcessing) return;
    _tickTimer?.cancel();
    _stopwatch.reset();
    setState(() {
      _selectedFilePath  = null;
      _selectedFileName  = null;
      _logs              = '';
      _logVisible        = false;
      _isProcessing      = false;
      _downloadProgress  = -1;
      _elapsed           = '00:00';
    });
    _logCtrl.reset();
  }

  String _stopTimer() {
    _stopwatch.stop();
    _tickTimer?.cancel();
    _tickTimer = null;
    final result = _formatDuration(_stopwatch.elapsed);
    setState(() => _elapsed = result);
    return result;
  }

  // ── ZIP/APK validation ──────────────────────────────────────────────────────
  // Accepts: raw APK  OR  ZIP containing APK (+ optional rules.txt/mapping.txt)
  ({bool valid, String message}) _validateFile(String path) {
    try {
      final name = path.split('/').last.toLowerCase();

      if (name.endsWith('.apk')) {
        final size = File(path).lengthSync();
        if (size < 1024) {
          return (valid: false, message: 'File too small — not a valid APK');
        }
        return (valid: true, message: 'APK ready — all classes will be protected');
      }

      if (name.endsWith('.zip')) {
        final bytes   = File(path).readAsBytesSync();
        final archive = ZipDecoder().decodeBytes(bytes);
        final names   = archive.files
            .where((f) => f.isFile)
            .map((f) => f.name.split('/').last.toLowerCase())
            .toList();

        final apks    = names.where((n) => n.endsWith('.apk')).toList();
        final rules   = names.where((n) => n == 'rules.txt').toList();
        final mapping = names.where((n) => n == 'mapping.txt').toList();

        if (apks.isEmpty) {
          return (valid: false, message: 'ZIP must contain an .apk file');
        }
        if (apks.length > 1) {
          return (valid: false, message: 'ZIP must contain exactly one .apk file');
        }

        final extras = <String>[];
        if (rules.isNotEmpty)   extras.add('rules.txt');
        if (mapping.isNotEmpty) extras.add('mapping.txt');

        final detail = extras.isEmpty
            ? 'APK only — all classes will be protected'
            : 'APK + ${extras.join(' + ')}';
        return (valid: true, message: detail);
      }

      return (valid: false, message: 'Select a .apk or .zip file');
    } catch (e) {
      return (valid: false, message: 'Could not read file: $e');
    }
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['apk', 'zip'],
    );
    if (result == null || result.files.isEmpty) return;

    final file = result.files.single;
    if (file.path == null) return;

    final validation = _validateFile(file.path!);

    setState(() {
      _selectedFilePath = file.path;
      _selectedFileName = file.name;
      _zipStatus        = validation.message;
      _fileValid        = validation.valid;
      _logs             = '';
      _logVisible       = false;
      _outputDir        = null;
      _downloadProgress = -1;
      _isProcessing     = false;
      _stopwatch.reset();
      _tickTimer?.cancel();
      _elapsed = '00:00';
    });

    if (!validation.valid) {
      _showSnack(validation.message,
          icon: Icons.warning_rounded, color: const Color(0xFFf59e0b));
    }

    await HbcChannel.vmProtectClearState();
  }

  Future<void> _runProtection() async {
    if (_selectedFilePath == null) {
      _showSnack('Pick a file first',
          icon: Icons.folder_open_rounded, color: const Color(0xFFf59e0b));
      return;
    }

    if (!_fileValid) {
      _showSnack(_zipStatus ?? 'Invalid file',
          icon: Icons.warning_rounded, color: const Color(0xFFf59e0b));
      return;
    }

    final hasPermission = await PermissionHelper.ensureStorage(
      context,
      accent: _kVmAccent,
    );
    if (!hasPermission) {
      _showSnack('Storage permission is required',
          icon: Icons.lock_rounded, color: const Color(0xFFef4444));
      return;
    }

    final outputDir = await StorageHelper.buildOutputDir(prefix: 'vmprotect');

    setState(() {
      _isProcessing     = true;
      _logs             = '';
      _logVisible       = true;
      _downloadProgress = -1;
    });
    _logCtrl.forward(from: 0);
    _scrollToLogPanel();
    _startTimer();

    try {
      final result = await HbcChannel.vmProtectAnalyze(
        filePath:  _selectedFilePath!,
        fileName:  _selectedFileName ?? _selectedFilePath!.split('/').last,
        outputDir: outputDir,
        signApk:   _signApk,
      );

      if (result['started'] == true) {
        await Future.delayed(const Duration(seconds: 1));
        _startPollingCloudState();
      } else {
        _stopTimer();
        final errMsg = (result['error'] as String?) ?? 'Failed to start protection';
        if (mounted) {
          setState(() { _isProcessing = false; });
          _showSnack(errMsg,
              icon: Icons.error_rounded, color: const Color(0xFFef4444));
        }
      }
    } catch (e) {
      _stopTimer();
      if (mounted) {
        setState(() {
          _isProcessing     = false;
          _downloadProgress = -1;
          _logs += '\nError: $e\n';
        });
        _showSnack('Error: $e',
            icon: Icons.error_rounded, color: const Color(0xFFef4444));
      }
    }
  }

  void _scrollToLogPanel() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final ctx = _logPanelKey.currentContext;
      if (ctx == null) return;
      Scrollable.ensureVisible(
        ctx,
        duration: const Duration(milliseconds: 480),
        curve: Curves.easeInOut,
        alignment: 0.0,
      );
    });
  }

  void _showSnack(String msg, {required IconData icon, required Color color}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(icon, color: Colors.white, size: 18),
        const SizedBox(width: 10),
        Expanded(
            child: Text(msg,
                style: const TextStyle(color: Colors.white, fontSize: 13))),
      ]),
      backgroundColor: color.withOpacity(0.9),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      duration: const Duration(seconds: 3),
    ));
  }

  // ── Info dialogs (the ? buttons) ─────────────────────────────────────────────

  void _showInfoDialog({
    required String title,
    required List<_InfoSection> sections,
  }) {
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          constraints: const BoxConstraints(maxWidth: 420),
          decoration: BoxDecoration(
            color: const Color(0xFF12102a),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: _accent.withOpacity(0.30), width: 1),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                decoration: BoxDecoration(
                  color: _accent.withOpacity(0.08),
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
                ),
                child: Row(children: [
                  Container(
                    padding: const EdgeInsets.all(7),
                    decoration: BoxDecoration(
                      color: _accent.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(Icons.help_outline_rounded,
                        color: _kVmAccentLight, size: 18),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(title,
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 15)),
                  ),
                  GestureDetector(
                    onTap: () => Navigator.pop(ctx),
                    child: const Icon(Icons.close_rounded,
                        color: Color(0xFF6b7280), size: 20),
                  ),
                ]),
              ),
              Flexible(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: sections.map((s) => _InfoSectionWidget(s)).toList(),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _accent,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    onPressed: () => Navigator.pop(ctx),
                    child: const Text('Got it',
                        style: TextStyle(fontWeight: FontWeight.w700)),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showWhatIsVmProtect() => _showInfoDialog(
    title: 'What is VM Protect?',
    sections: [
      _InfoSection(
        heading: 'Overview',
        body: 'VM Protect (nmmp) converts your APK\'s DEX bytecode into native '
            'C code that runs inside a custom virtual machine compiled directly '
            'into your app as a .so shared library.',
      ),
      _InfoSection(
        heading: 'How it works',
        body: '1. Reads every DEX file inside your APK\n'
            '2. Converts each method\'s bytecode into randomised C structures\n'
            '3. Compiles those structures via Android NDK into a .so file\n'
            '4. Replaces the original DEX method bodies with tiny JNI stubs\n'
            '5. Packages the modified DEX + .so back into a new APK',
      ),
      _InfoSection(
        heading: 'Why use it?',
        body: 'DEX decompilers (jadx, ByteCode Viewer, etc.) can only see the '
            'empty JNI stubs — the real logic lives in the native .so, which is '
            'much harder to reverse engineer than plain DEX bytecode.',
      ),
      _InfoSection(
        heading: 'Cloud-only',
        body: 'Protection runs entirely in the cloud because it needs the Android '
            'NDK compiler toolchain (~700 MB). Results are downloaded to your '
            'device automatically when finished.',
      ),
    ],
  );

  void _showFileFormatInfo() => _showInfoDialog(
    title: 'File Format Guide',
    sections: [
      _InfoSection(
        heading: 'Option A — APK only',
        body: 'Pick your .apk directly.\n'
            'Every class in the APK will be protected.\n\n'
            '⚠️  For Native Android apps this can cause crashes. '
            'Use Option B with a rules.txt to limit which classes nmmp touches.',
      ),
      _InfoSection(
        heading: 'Option B — ZIP bundle (recommended)',
        body: 'Put these files in a .zip:\n\n'
            '  • yourapp.apk     ← required\n'
            '  • rules.txt       ← optional, class filter\n'
            '  • mapping.txt     ← optional, ProGuard map\n\n'
            'File names must be exactly rules.txt and mapping.txt.\n'
            'Files can be at the ZIP root or inside one subfolder.',
      ),
      _InfoSection(
        heading: 'How to create the ZIP on Android',
        body: 'Step 1 — Create rules.txt\n'
            'Open any text editor app (e.g. Simple Text). Write your rules '
            '(one per line, slash format). Save the file as rules.txt.\n\n'
            'Step 2 — Use a file manager with ZIP support\n'
            'Open a file manager (e.g. MT Manager, ZArchiver, MiXplorer):\n'
            '  1. Navigate to the folder with your APK\n'
            '  2. Copy rules.txt into the same folder\n'
            '  3. Long-press to select both files\n'
            '  4. Tap "Compress" or "Add to ZIP"\n'
            '  5. Name the output anything (e.g. bundle.zip)\n\n'
            'Step 3 — Upload the ZIP here instead of the APK.',
      ),
      _InfoSection(
        heading: 'Quick rules.txt example',
        isCode: true,
        body: 'class com.yourapp.network.*\n'
            'class com.yourapp.auth.*\n'
            'class com.yourapp.crypto.ProxyClient',
      ),
    ],
  );

  void _showRulesInfo() => _showInfoDialog(
    title: 'rules.txt — Class Filter',
    sections: [
      _InfoSection(
        heading: 'What it does',
        body: 'Tells nmmp which classes or methods to convert to native code. '
            'If omitted, every class in the APK is protected — which can crash '
            'apps that have UI or framework callbacks.',
      ),
      _InfoSection(
        heading: 'Format — EVERYTHING on one line',
        body: 'Each rule must be the word "class" followed by a space and the\n'
            'full class name — ALL ON ONE LINE:\n\n'
            '✅  class com.example.MyClass\n'
            '✅  class com.example.*\n'
            '✅  class *\n\n'
            '❌  class\n'
            '    com.example.MyClass   ← WRONG: split across two lines\n'
            '❌  com/example/MyClass   ← WRONG: slash format\n'
            '❌  com.example.MyClass   ← WRONG: missing "class" keyword',
      ),
      _InfoSection(
        heading: 'Example 1 — protect one method only',
        isCode: true,
        body:
            'class com.example.MainActivity {\n'
            '    onCreate;\n'
            '}',
      ),
      _InfoSection(
        heading: 'Example 2 — protect multiple methods',
        isCode: true,
        body:
            'class com.example.MainActivity {\n'
            '    onCreate;\n'
            '    onDestroy;\n'
            '    onResume;\n'
            '    onPause;\n'
            '}',
      ),
      _InfoSection(
        heading: 'Example 3 — protect a whole class (all methods)',
        isCode: true,
        body:
            'class com.example.MainActivity',
      ),
      _InfoSection(
        heading: 'Example 4 — protect an entire package (folder)',
        isCode: true,
        body:
            'class com.example.network.*',
      ),
      _InfoSection(
        heading: 'Example 5 — protect everything in the APK',
        isCode: true,
        body:
            'class *',
      ),
      _InfoSection(
        heading: 'What NOT to protect',
        body: '• Classes that extend Activity / Fragment / View\n'
            '• Methods named onCreate, onResume, onPause, onDestroy\n'
            '• Any class already obfuscated to short names (A1, D1, B3…)\n\n'
            'These have Android framework callbacks — if nmmp nativizes them '
            'and they call each other, you will get NoSuchMethodError crashes.',
      ),
      _InfoSection(
        heading: 'Safe to protect',
        body: '• Your network / proxy / API logic classes\n'
            '• Encryption / crypto utility classes\n'
            '• Auth / license validation classes\n'
            '• Pure logic methods (getters, calculators, validators)\n\n'
            'Note: # comments are NOT supported. Rules only, one per line.',
      ),
    ],
  );

  void _showMappingInfo() => _showInfoDialog(
    title: 'mapping.txt — ProGuard Map',
    sections: [
      _InfoSection(
        heading: 'What it does',
        body: 'If your APK was built with ProGuard or R8 minification, class '
            'names are obfuscated (e.g. com.example.MyClass → a.b.c). '
            'Supplying mapping.txt lets you write rules.txt using the original '
            'class names — nmmp maps them back automatically.',
      ),
      _InfoSection(
        heading: 'Where to get it',
        body: 'Android Studio generates it at:\n'
            'app/build/outputs/mapping/<variant>/mapping.txt\n\n'
            'Or in your CI build artifacts if you archive it.',
      ),
      _InfoSection(
        heading: 'Example snippet',
        isCode: true,
        body: 'com.example.MyClass -> a.b.c:\n'
            '    void doSecret() -> a\n'
            '    java.lang.String encode(byte[]) -> b',
      ),
      _InfoSection(
        heading: 'When to skip it',
        body: 'If your APK is NOT minified / not run through ProGuard, '
            'you do not need mapping.txt at all.',
      ),
    ],
  );

  Future<void> _onBackPressed() async {
    final leave = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF12102a),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: const BorderSide(color: _accent, width: 1),
        ),
        title: Row(children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: _accent.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.shield_rounded, color: _accent, size: 20),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Text('Leave VM Protect?',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w700)),
          ),
        ]),
        content: Text(
          _isProcessing
              ? 'Protection is running in the background.\nYou can return later to see results.'
              : 'Are you sure you want to go back?',
          style: const TextStyle(
              color: Color(0xFFa0a0b8), fontSize: 13, height: 1.6),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Stay',
                style: TextStyle(color: Color(0xFF6b7280))),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: _accent,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8)),
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(
                _isProcessing ? 'Leave (keeps running)' : 'Leave'),
          ),
        ],
      ),
    );
    if (leave == true && mounted) Navigator.of(context).pop();
  }

  // ── Build ─────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _onBackPressed();
      },
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              _VmAppBarIcon(animation: _pulseAnim),
              const SizedBox(width: 10),
              const Text('VM PROTECT'),
              const SizedBox(width: 10),
              _VmAppBarIcon(animation: _pulseAnim, mirrored: true),
            ],
          ),
          actions: [
            IconButton(
              tooltip: 'Reset',
              icon: const Icon(Icons.restart_alt_rounded),
              onPressed: _isProcessing ? null : _reset,
            ),
          ],
          iconTheme: const IconThemeData(color: Colors.white),
          flexibleSpace: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  ThemeProvider().current.appBarBg,
                  const Color(0xFF0e0a1e),
                ],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
            ),
          ),
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(1),
            child: Container(height: 1, color: _accent.withOpacity(0.25)),
          ),
        ),
        body: SingleChildScrollView(
          controller: _pageScrollCtrl,
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildHeader(),
              const SizedBox(height: 20),
              _buildFileSelector(),
              if (_selectedFileName != null) ...[
                const SizedBox(height: 12),
                _buildFileInfo(),
              ],
              const SizedBox(height: 14),
              _buildRulesHint(),
              const SizedBox(height: 10),
              _buildAppTypeGuide(),
              const SizedBox(height: 12),
              _buildSignToggle(),
              const SizedBox(height: 14),
              _buildActionRow(),
              if (_downloadProgress >= 0) ...[
                const SizedBox(height: 12),
                _buildProgressBar(),
              ],
              if (_logVisible) ...[
                const SizedBox(height: 16),
                _buildLogPanel(),
              ],
              if (_outputDir != null && !_isProcessing) ...[
                const SizedBox(height: 14),
                _buildOutputDir(),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return AnimatedBuilder(
      animation: Listenable.merge([_pulseAnim, _orbitCtrl, _scanAnim]),
      builder: (_, __) {
        final pulse = _pulseAnim.value;
        return Container(
          padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: RadialGradient(
              center: Alignment.center,
              radius: 1.2,
              colors: [
                _accent.withOpacity(0.06 + 0.04 * pulse),
                ThemeProvider().current.scaffoldBg,
              ],
            ),
            border: Border.all(
                color: _accent.withOpacity(0.10 + 0.08 * pulse)),
          ),
          child: Column(children: [
            SizedBox(
              width: 64,
              height: 64,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Transform.rotate(
                    angle: _orbitCtrl.value * math.pi * 2,
                    child: CustomPaint(
                      size: const Size(64, 64),
                      painter: _VmOrbitPainter(
                          color: _accent, opacity: 0.3 + 0.3 * pulse),
                    ),
                  ),
                  Transform.rotate(
                    angle: -_orbitCtrl.value * math.pi * 2 * 0.6,
                    child: CustomPaint(
                      size: const Size(40, 40),
                      painter: _VmDotPainter(
                          color: _accent, opacity: 0.4 + 0.3 * pulse),
                    ),
                  ),
                  Icon(Icons.memory_rounded,
                      color: _accent.withOpacity(0.7 + 0.3 * pulse),
                      size: 24),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _VmChip('DEX → Native VM'),
                const SizedBox(width: 8),
                _VmChip('APK Protection'),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: _showWhatIsVmProtect,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: _accent.withOpacity(0.12),
                      shape: BoxShape.circle,
                      border: Border.all(
                          color: _accent.withOpacity(0.30), width: 1),
                    ),
                    child: const Icon(Icons.help_outline_rounded,
                        color: _kVmAccentLight, size: 14),
                  ),
                ),
              ],
            ),
          ]),
        );
      },
    );
  }

  Widget _buildFileSelector() {
    final hasFile = _selectedFileName != null;
    return GestureDetector(
      onTap: _isProcessing ? null : _pickFile,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: const Color(0xFF111122),
          border: Border.all(
            color: hasFile
                ? (_fileValid
                    ? _accent.withOpacity(0.30)
                    : const Color(0xFFef4444).withOpacity(0.40))
                : ThemeProvider().current.surfaceColor,
          ),
        ),
        child: Row(children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: _accent.withOpacity(0.10),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              hasFile
                  ? Icons.insert_drive_file_rounded
                  : Icons.add_rounded,
              color: _accent,
              size: 22,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  hasFile ? _selectedFileName! : 'Select APK or ZIP',
                  style: TextStyle(
                    color: hasFile ? Colors.white : const Color(0xFF9ca3af),
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Text(
                  hasFile
                      ? (_fileValid ? '.apk or .zip' : 'invalid file')
                      : '.apk  or  .zip (APK + rules.txt + mapping.txt)',
                  style: TextStyle(
                    color: hasFile
                        ? (_fileValid
                            ? const Color(0xFF6b7280)
                            : const Color(0xFFf87171))
                        : const Color(0xFF6b7280),
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: _showFileFormatInfo,
            child: Padding(
              padding: const EdgeInsets.all(4),
              child: Icon(Icons.help_outline_rounded,
                  color: _accent.withOpacity(0.60), size: 18),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _buildFileInfo() {
    if (_zipStatus == null) return const SizedBox.shrink();
    final ok = _fileValid;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: ok
            ? _accent.withOpacity(0.07)
            : const Color(0xFFef4444).withOpacity(0.07),
        border: Border.all(
          color: ok
              ? _accent.withOpacity(0.20)
              : const Color(0xFFef4444).withOpacity(0.25),
        ),
      ),
      child: Row(children: [
        Icon(
          ok ? Icons.check_circle_outline_rounded : Icons.warning_amber_rounded,
          color: ok ? _accent : const Color(0xFFf87171),
          size: 16,
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            _zipStatus!,
            style: TextStyle(
              color: ok ? _kVmAccentLight : const Color(0xFFf87171),
              fontSize: 12,
            ),
          ),
        ),
      ]),
    );
  }

  // ── rules / mapping hint row ──────────────────────────────────────────────
  Widget _buildRulesHint() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: const Color(0xFF111122),
        border: Border.all(color: _accent.withOpacity(0.12)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Optional extras (include inside a ZIP)',
            style: TextStyle(
                color: Color(0xFF9ca3af),
                fontSize: 11,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.4),
          ),
          const SizedBox(height: 10),
          _buildHintRow(
            icon: Icons.filter_list_rounded,
            label: 'rules.txt',
            desc: 'Which classes/methods to protect',
            onInfo: _showRulesInfo,
          ),
          const SizedBox(height: 8),
          _buildHintRow(
            icon: Icons.map_outlined,
            label: 'mapping.txt',
            desc: 'ProGuard map for minified APKs',
            onInfo: _showMappingInfo,
          ),
          const SizedBox(height: 6),
          Text(
            'Skip both to protect ALL classes automatically.',
            style: TextStyle(
                color: _accent.withOpacity(0.55),
                fontSize: 10,
                fontStyle: FontStyle.italic),
          ),
        ],
      ),
    );
  }

  // ── app-type guide card ───────────────────────────────────────────────────
  Widget _buildAppTypeGuide() {
    return GestureDetector(
      onTap: _showAppTypeDialog,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: const Color(0xFF0d1117),
          border: Border.all(color: const Color(0xFF22c55e).withOpacity(0.18)),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF22c55e).withOpacity(0.12),
              ),
              child: const Icon(Icons.info_outline_rounded,
                  color: Color(0xFF4ade80), size: 15),
            ),
            const SizedBox(width: 10),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Which app type are you protecting?',
                    style: TextStyle(
                        color: Color(0xFFd1fae5),
                        fontSize: 12,
                        fontWeight: FontWeight.w600),
                  ),
                  SizedBox(height: 2),
                  Text(
                    'Flutter & React Native apps need a rules.txt — tap to learn more',
                    style: TextStyle(
                        color: Color(0xFF6b7280),
                        fontSize: 10),
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded,
                color: Color(0xFF4ade80), size: 18),
          ],
        ),
      ),
    );
  }

  void _showAppTypeDialog() {
    final screenH = MediaQuery.of(context).size.height;
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: const Color(0xFF0f0f1a),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: screenH * 0.82),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
              Row(children: [
                Container(
                  padding: const EdgeInsets.all(7),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFF22c55e).withOpacity(0.15),
                  ),
                  child: const Icon(Icons.auto_fix_high_rounded,
                      color: Color(0xFF4ade80), size: 17),
                ),
                const SizedBox(width: 10),
                const Text(
                  'App Type Guide',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold),
                ),
              ]),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(11),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: const Color(0xFF4ade80).withOpacity(0.08),
                  border: Border.all(color: const Color(0xFF4ade80).withOpacity(0.25)),
                ),
                child: const Text(
                  '💡 Tip: tap the ① icon next to rules.txt to see the exact format and examples.',
                  style: TextStyle(
                      color: Color(0xFF86efac), fontSize: 12,
                      fontStyle: FontStyle.italic),
                ),
              ),
              const SizedBox(height: 16),
              _buildAppTypeRow(
                icon: Icons.android_rounded,
                iconColor: const Color(0xFF4ade80),
                title: 'Native Android  (Java / Kotlin)',
                badge: 'Recommended rules',
                badgeColor: const Color(0xFF4ade80),
                lines: [
                  'All business logic lives in the DEX files.',
                  'You can try "class *" to protect everything.',
                  'If the app crashes after protection, add a\n  rules.txt with only the classes you want.',
                  'Tap ① for rules format and examples.',
                ],
              ),
              const SizedBox(height: 14),
              _buildAppTypeRow(
                icon: Icons.flutter_dash_rounded,
                iconColor: const Color(0xFF38bdf8),
                title: 'Flutter  (Dart)',
                badge: 'Needs rules.txt',
                badgeColor: const Color(0xFFf59e0b),
                lines: [
                  'Real code is already native inside libapp.so.',
                  'DEX only has small Java plugin bridges.',
                  'Protecting all classes WILL crash the app.',
                  'ZIP your APK + rules.txt targeting only\n  safe utility classes, not Activity/Application.',
                ],
              ),
              const SizedBox(height: 14),
              _buildAppTypeRow(
                icon: Icons.javascript_rounded,
                iconColor: const Color(0xFFfbbf24),
                title: 'React Native  (Hermes)',
                badge: 'Needs rules.txt',
                badgeColor: const Color(0xFFf59e0b),
                lines: [
                  'Real code lives in assets/index.android.bundle.',
                  'DEX only has React Native bridge code.',
                  'Protecting all classes WILL crash the app.',
                  'ZIP your APK + rules.txt targeting only\n  your own Java classes.',
                ],
              ),
              const SizedBox(height: 16),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Got it',
                      style: TextStyle(color: Color(0xFF4ade80))),
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
  }

  Widget _buildAppTypeRow({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String badge,
    required Color badgeColor,
    required List<String> lines,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(11),
        color: const Color(0xFF111122),
        border: Border.all(color: badgeColor.withOpacity(0.15)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Icon(icon, color: iconColor, size: 16),
            const SizedBox(width: 8),
            Expanded(
              child: Text(title,
                  style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 12,
                      fontWeight: FontWeight.w600)),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: badgeColor.withOpacity(0.12),
              ),
              child: Text(badge,
                  style: TextStyle(
                      color: badgeColor,
                      fontSize: 9,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.3)),
            ),
          ]),
          const SizedBox(height: 8),
          ...lines.map((l) => Padding(
            padding: const EdgeInsets.only(bottom: 3),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('• ',
                    style: TextStyle(color: iconColor.withOpacity(0.6),
                        fontSize: 11)),
                Expanded(
                  child: Text(l,
                      style: const TextStyle(
                          color: Color(0xFF6b7280), fontSize: 11)),
                ),
              ],
            ),
          )),
        ],
      ),
    );
  }

  Widget _buildHintRow({
    required IconData icon,
    required String label,
    required String desc,
    required VoidCallback onInfo,
  }) {
    return Row(children: [
      Icon(icon, color: _accent.withOpacity(0.55), size: 15),
      const SizedBox(width: 8),
      Expanded(
        child: RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text: label,
                style: const TextStyle(
                    color: Colors.white70,
                    fontWeight: FontWeight.w600,
                    fontSize: 12,
                    fontFamily: 'monospace'),
              ),
              TextSpan(
                text: '  $desc',
                style: const TextStyle(
                    color: Color(0xFF6b7280), fontSize: 11),
              ),
            ],
          ),
        ),
      ),
      GestureDetector(
        onTap: onInfo,
        child: Padding(
          padding: const EdgeInsets.all(4),
          child: Icon(Icons.help_outline_rounded,
              color: _accent.withOpacity(0.50), size: 16),
        ),
      ),
    ]);
  }

  Widget _buildSignToggle() {
    return GestureDetector(
      onTap: _isProcessing
          ? null
          : () => setState(() => _signApk = !_signApk),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: const Color(0xFF111122),
          border: Border.all(
            color: _signApk
                ? _accent.withOpacity(0.25)
                : ThemeProvider().current.surfaceColor,
          ),
        ),
        child: Row(children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: 36,
            height: 20,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: _signApk
                  ? _accent.withOpacity(0.80)
                  : const Color(0xFF374151),
            ),
            child: Stack(children: [
              AnimatedPositioned(
                duration: const Duration(milliseconds: 200),
                left: _signApk ? 18 : 2,
                top: 2,
                child: Container(
                  width: 16,
                  height: 16,
                  decoration: const BoxDecoration(
                      color: Colors.white, shape: BoxShape.circle),
                ),
              ),
            ]),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Sign APK',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        fontSize: 13)),
                Text(
                  _signApk
                      ? 'Protected APK will be signed and ready to install'
                      : 'Skip signing — sign manually later',
                  style: const TextStyle(
                      color: Color(0xFF6b7280), fontSize: 11),
                ),
              ],
            ),
          ),
        ]),
      ),
    );
  }

  Widget _buildActionRow() {
    final canRun = _fileValid && !_isProcessing;
    return Row(children: [
      if (_isProcessing) ...[
        Expanded(
          child: OutlinedButton.icon(
            onPressed: () async {
              await HbcChannel.vmProtectCancel();
              _showSnack('Cancellation requested...',
                  icon: Icons.cancel_outlined,
                  color: const Color(0xFFf59e0b));
            },
            icon: const Icon(Icons.stop_circle_outlined, size: 18),
            label: const Text('Cancel'),
            style: OutlinedButton.styleFrom(
              foregroundColor: const Color(0xFFf87171),
              side: const BorderSide(color: Color(0xFFef4444)),
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
            ),
          ),
        ),
        const SizedBox(width: 10),
      ],
      Expanded(
        flex: 2,
        child: AnimatedBuilder(
          animation: _pulseAnim,
          builder: (_, __) {
            return Container(
              decoration: canRun
                  ? BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: _accent
                              .withOpacity(0.25 + 0.15 * _pulseAnim.value),
                          blurRadius: 16,
                          spreadRadius: 2,
                        ),
                      ],
                    )
                  : null,
              child: ElevatedButton.icon(
                onPressed: canRun ? _runProtection : null,
                icon: _isProcessing
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: Colors.white))
                    : const Icon(Icons.security_rounded, size: 18),
                label: Text(_isProcessing ? 'Protecting...' : 'Protect APK'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _accent,
                  foregroundColor: Colors.white,
                  disabledBackgroundColor: const Color(0xFF2d2b3f),
                  disabledForegroundColor: const Color(0xFF4b5563),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  textStyle: const TextStyle(
                      fontWeight: FontWeight.w700, fontSize: 14),
                ),
              ),
            );
          },
        ),
      ),
    ]);
  }

  Widget _buildProgressBar() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          const Icon(Icons.download_rounded,
              color: _accent, size: 14),
          const SizedBox(width: 6),
          Text(
            _downloadProgress >= 0
                ? 'Downloading result... $_downloadProgress%'
                : 'Downloading...',
            style: const TextStyle(
                color: _accent, fontSize: 12, fontWeight: FontWeight.w600),
          ),
        ]),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: _downloadProgress >= 0 ? _downloadProgress / 100 : null,
            backgroundColor: _accent.withOpacity(0.12),
            valueColor: const AlwaysStoppedAnimation<Color>(_accent),
            minHeight: 6,
          ),
        ),
      ],
    );
  }

  Widget _buildOutputDir() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: const Color(0xFF0d1a0f),
        border: Border.all(
            color: const Color(0xFF22c55e).withOpacity(0.30)),
      ),
      child: Row(children: [
        const Icon(Icons.folder_open_rounded,
            color: Color(0xFF22c55e), size: 20),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Output saved',
                  style: TextStyle(
                      color: Color(0xFF22c55e),
                      fontWeight: FontWeight.w600,
                      fontSize: 13)),
              const SizedBox(height: 2),
              Text(
                _outputDir!,
                style: const TextStyle(
                    color: Color(0xFF6b7280), fontSize: 11),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
        GestureDetector(
          onTap: () {
            Clipboard.setData(ClipboardData(text: _outputDir!));
            _showSnack('Path copied',
                icon: Icons.check_rounded, color: _accent);
          },
          child: const Icon(Icons.copy_rounded,
              color: Color(0xFF6b7280), size: 16),
        ),
      ]),
    );
  }

  Widget _buildLogPanel() {
    return FadeTransition(
      key: _logPanelKey,
      opacity: _logFade,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: const Color(0xFF0d0d1a),
          border: Border.all(color: _accent.withOpacity(0.12)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: _accent.withOpacity(0.08),
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(14)),
              ),
              child: Row(children: [
                _isProcessing
                    ? AnimatedBuilder(
                        animation: _orbitCtrl,
                        builder: (_, __) => Transform.rotate(
                          angle: _orbitCtrl.value * 6.28,
                          child: const Icon(Icons.settings_rounded,
                              color: _accent, size: 16),
                        ),
                      )
                    : const Icon(Icons.terminal_rounded,
                        color: _accent, size: 16),
                const SizedBox(width: 8),
                Text(
                  _isProcessing ? 'Processing...' : 'Live Output',
                  style: const TextStyle(
                    color: _accent,
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                    letterSpacing: 0.5,
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: () =>
                      setState(() => _autoScroll = !_autoScroll),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: _autoScroll
                          ? const Color(0xFF22c55e).withOpacity(0.15)
                          : const Color(0xFF374151).withOpacity(0.4),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(
                        color: _autoScroll
                            ? const Color(0xFF22c55e).withOpacity(0.5)
                            : const Color(0xFF374151),
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          _autoScroll
                              ? Icons.vertical_align_bottom_rounded
                              : Icons.vertical_align_center_rounded,
                          color: _autoScroll
                              ? const Color(0xFF22c55e)
                              : const Color(0xFF6b7280),
                          size: 13,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          'Auto-scroll',
                          style: TextStyle(
                            color: _autoScroll
                                ? const Color(0xFF22c55e)
                                : const Color(0xFF6b7280),
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: () {
                    if (_logs.isEmpty) {
                      _showSnack('No logs to copy',
                          icon: Icons.info_rounded,
                          color: const Color(0xFF6b7280));
                      return;
                    }
                    Clipboard.setData(ClipboardData(text: _logs));
                    _showSnack('Logs copied',
                        icon: Icons.check_rounded, color: _accent);
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: _accent.withOpacity(0.10),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: _accent.withOpacity(0.25)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.copy_rounded, color: _accent, size: 13),
                        const SizedBox(width: 4),
                        Text('Copy',
                            style: TextStyle(
                                color: _accent,
                                fontSize: 10,
                                fontWeight: FontWeight.w600)),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: () {
                    if (_logs.isEmpty || _isProcessing) return;
                    _pollTimer?.cancel();
                    _streamSub?.cancel();
                    _stopwatch.stop();
                    _stopwatch.reset();
                    _tickTimer?.cancel();
                    setState(() {
                      _logs             = '';
                      _isProcessing     = false;
                      _logVisible       = false;
                      _outputDir        = null;
                      _downloadProgress = -1;
                      _elapsed          = '00:00';
                    });
                    HbcChannel.vmProtectClearState();
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 6, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFFef4444).withOpacity(0.08),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(
                          color: const Color(0xFFef4444).withOpacity(0.35)),
                    ),
                    child: const Icon(Icons.delete_outline_rounded,
                        color: Color(0xFFf87171), size: 14),
                  ),
                ),
              ]),
            ),
            Container(
              height: 360,
              margin: const EdgeInsets.fromLTRB(14, 10, 14, 0),
              child: Scrollbar(
                controller: _logScrollCtrl,
                thumbVisibility: true,
                child: SingleChildScrollView(
                  controller: _logScrollCtrl,
                  padding: const EdgeInsets.only(right: 8),
                  child: Text(
                    _logs.isEmpty
                        ? (_isProcessing
                            ? 'Preparing VM protection pipeline...'
                            : 'Waiting for output...')
                        : _logs,
                    style: TextStyle(
                      fontFamily: 'monospace',
                      fontSize: 11,
                      color: _logs.isEmpty
                          ? const Color(0xFF4b5563)
                          : const Color(0xFFd4d4d4),
                      height: 1.7,
                    ),
                  ),
                ),
              ),
            ),
            if (_stopwatch.elapsedMilliseconds > 0)
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: const Color(0xFF0a0a14),
                  borderRadius: const BorderRadius.vertical(
                      bottom: Radius.circular(14)),
                  border: Border(
                    top: BorderSide(
                        color: Colors.white.withOpacity(0.06)),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      _isProcessing
                          ? Icons.timer_outlined
                          : Icons.check_circle_outline_rounded,
                      color: Colors.white.withOpacity(0.7),
                      size: 14,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      _isProcessing
                          ? 'Elapsed  $_elapsed'
                          : 'Completed in $_elapsed',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.7),
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'monospace',
                      ),
                    ),
                  ],
                ),
              )
            else
              const SizedBox(height: 10),
          ],
        ),
      ),
    );
  }
}

// ── Supporting widgets ──────────────────────────────────────────────────────

class _VmChip extends StatelessWidget {
  final String label;
  const _VmChip(this.label);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: _kVmAccent.withOpacity(0.08),
        borderRadius: BorderRadius.circular(5),
        border: Border.all(color: _kVmAccent.withOpacity(0.22)),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: _kVmAccent,
          fontSize: 10,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.5,
        ),
      ),
    );
  }
}

// ── Info dialog data model ──────────────────────────────────────────────────

class _InfoSection {
  final String heading;
  final String body;
  final bool isCode;
  const _InfoSection({
    required this.heading,
    required this.body,
    this.isCode = false,
  });
}

class _InfoSectionWidget extends StatelessWidget {
  final _InfoSection section;
  const _InfoSectionWidget(this.section, {super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            section.heading,
            style: const TextStyle(
                color: _kVmAccentLight,
                fontWeight: FontWeight.w700,
                fontSize: 12,
                letterSpacing: 0.3),
          ),
          const SizedBox(height: 6),
          if (section.isCode)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFF0a0a14),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _kVmAccent.withOpacity(0.15)),
              ),
              child: Text(
                section.body,
                style: const TextStyle(
                    fontFamily: 'monospace',
                    fontSize: 11,
                    color: Color(0xFFd4d4d4),
                    height: 1.7),
              ),
            )
          else
            Text(
              section.body,
              style: const TextStyle(
                  color: Color(0xFFa0a0b8), fontSize: 13, height: 1.6),
            ),
        ],
      ),
    );
  }
}

// ── Animated painters ───────────────────────────────────────────────────────

class _VmOrbitPainter extends CustomPainter {
  final Color color;
  final double opacity;
  const _VmOrbitPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r  = (size.width / 2) - 2;
    final paint = Paint()
      ..color = color.withOpacity(opacity)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round;
    const gapRad = math.pi / 3;
    const arcRad = math.pi / 3;
    for (int i = 0; i < 3; i++) {
      canvas.drawArc(
        Rect.fromCircle(center: Offset(cx, cy), radius: r),
        i * (arcRad + gapRad), arcRad, false, paint,
      );
    }
    final dp = Paint()
      ..color = color.withOpacity(opacity * 0.9)
      ..style = PaintingStyle.fill;
    for (int i = 0; i < 3; i++) {
      final a = i * (arcRad + gapRad) + arcRad / 2;
      canvas.drawCircle(
          Offset(cx + r * math.cos(a), cy + r * math.sin(a)), 2.4, dp);
    }
  }

  @override
  bool shouldRepaint(_VmOrbitPainter o) =>
      o.color != color || o.opacity != opacity;
}

class _VmDotPainter extends CustomPainter {
  final Color color;
  final double opacity;
  const _VmDotPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r  = (size.width / 2) - 1;
    for (int i = 0; i < 6; i++) {
      final a = i * (math.pi / 3);
      canvas.drawCircle(
        Offset(cx + r * math.cos(a), cy + r * math.sin(a)),
        i % 2 == 0 ? 2.0 : 1.2,
        Paint()
          ..color = color.withOpacity(opacity * (i % 2 == 0 ? 1.0 : 0.5))
          ..style = PaintingStyle.fill,
      );
    }
  }

  @override
  bool shouldRepaint(_VmDotPainter o) =>
      o.color != color || o.opacity != opacity;
}

class _VmAppBarIcon extends StatelessWidget {
  final Animation<double> animation;
  final bool mirrored;
  const _VmAppBarIcon({required this.animation, this.mirrored = false});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: animation,
      builder: (_, __) {
        return Transform.scale(
          scaleX: mirrored ? -1 : 1,
          child: CustomPaint(
            size: const Size(20, 22),
            painter: _VmAppBarPainter(phase: animation.value),
          ),
        );
      },
    );
  }
}

class _VmAppBarPainter extends CustomPainter {
  final double phase;
  const _VmAppBarPainter({required this.phase});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    const purple = _kVmAccent;

    final shieldPath = Path()
      ..moveTo(w * 0.5, 0)
      ..lineTo(w, h * 0.18)
      ..lineTo(w, h * 0.52)
      ..quadraticBezierTo(w, h * 0.82, w * 0.5, h)
      ..quadraticBezierTo(0, h * 0.82, 0, h * 0.52)
      ..lineTo(0, h * 0.18)
      ..close();

    final glow = 0.12 + 0.10 * math.sin(phase * math.pi * 2);
    canvas.drawPath(
      shieldPath,
      Paint()
        ..shader = LinearGradient(
          colors: [
            purple.withOpacity(glow + 0.05),
            purple.withOpacity(glow * 0.5),
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ).createShader(Rect.fromLTWH(0, 0, w, h))
        ..style = PaintingStyle.fill,
    );

    final strokeOpacity = 0.5 + 0.3 * math.sin(phase * math.pi * 2);
    canvas.drawPath(
      shieldPath,
      Paint()
        ..color = purple.withOpacity(strokeOpacity)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4
        ..strokeJoin = StrokeJoin.round,
    );

    final scanY = h * 0.25 + h * 0.5 * phase;
    canvas.drawLine(
        Offset(w * 0.2, scanY), Offset(w * 0.8, scanY),
        Paint()
          ..color = purple.withOpacity(0.35)
          ..strokeWidth = 1.2
          ..style = PaintingStyle.stroke);

    final positions = [
      Offset(w * 0.35, h * 0.35),
      Offset(w * 0.65, h * 0.35),
      Offset(w * 0.5,  h * 0.52),
      Offset(w * 0.35, h * 0.68),
      Offset(w * 0.65, h * 0.68),
    ];
    for (int i = 0; i < positions.length; i++) {
      final pulse = 0.5 + 0.5 * math.sin(phase * math.pi * 2 + i * 1.2);
      canvas.drawCircle(
        positions[i],
        1.4 + 0.6 * pulse,
        Paint()
          ..color = purple.withOpacity(0.4 + 0.4 * pulse)
          ..style = PaintingStyle.fill,
      );
    }
  }

  @override
  bool shouldRepaint(_VmAppBarPainter o) => o.phase != phase;
}
