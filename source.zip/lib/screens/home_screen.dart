import '../utils/theme_provider.dart';
import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:share_plus/share_plus.dart';
import 'package:archive/archive_io.dart';
import '../widgets/app_drawer.dart';
import '../utils/hbc_channel.dart';
import '../utils/storage_helper.dart';
import '../utils/permission_helper.dart';
import '../utils/session_state.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin, WidgetsBindingObserver {
  String? _selectedFilePath;
  String? _selectedFileName;
  String? _detectedMode;   // 'dsm' | 'asm' | 'zip'
  bool _isProcessing = false;
  String _logs = '';
  String? _outputDir;
  bool _logVisible = false;

  Timer? _pollTimer;
  final ScrollController _logScrollCtrl  = ScrollController();
  final ScrollController _pageScrollCtrl = ScrollController();
  final GlobalKey        _logPanelKey    = GlobalKey();
  bool _autoScroll = true;

  // Animations
  late AnimationController _pulseCtrl;
  late AnimationController _cardCtrl;
  late AnimationController _btnCtrl;
  late AnimationController _logCtrl;
  late AnimationController _processingCtrl;
  late AnimationController _orbitCtrl;
  late AnimationController _scanCtrl;

  late Animation<double> _pulseAnim;
  late Animation<Offset>  _cardSlide;
  late Animation<double>  _cardFade;
  late Animation<double>  _btnScale;
  late Animation<double>  _logFade;
  late Animation<double>  _processingRotate;
  late Animation<double>  _orbitAnim;
  late Animation<double>  _scanAnim;

  @override
  void initState() {
    super.initState();

    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.85, end: 1.0)
        .animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _cardCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 700));
    _cardSlide = Tween<Offset>(begin: const Offset(0, 0.3), end: Offset.zero)
        .animate(CurvedAnimation(parent: _cardCtrl, curve: Curves.easeOutCubic));
    _cardFade  = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _cardCtrl, curve: Curves.easeOut));

    _btnCtrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _btnScale = Tween<double>(begin: 0.85, end: 1.0)
        .animate(CurvedAnimation(parent: _btnCtrl, curve: Curves.easeOutBack));

    _logCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 450));
    _logFade = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _logCtrl, curve: Curves.easeIn));

    _processingCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))
      ..repeat();
    _processingRotate = Tween<double>(begin: 0, end: 1).animate(_processingCtrl);

    _orbitCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 5))
      ..repeat();
    _orbitAnim = Tween<double>(begin: 0, end: 1).animate(_orbitCtrl);

    _scanCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 2200))
      ..repeat(reverse: true);
    _scanAnim = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _scanCtrl, curve: Curves.easeInOut));

    Future.delayed(const Duration(milliseconds: 100), () { if (mounted) _cardCtrl.forward(); });
    Future.delayed(const Duration(milliseconds: 350), () { if (mounted) _btnCtrl.forward(); });

    WidgetsBinding.instance.addObserver(this);
    _restoreSession();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _checkServiceState();
    }
  }

  Future<void> _restoreSession() async {
    await _checkServiceState();
    if (_isProcessing) return;

    final s = await SessionState.load();
    if (!mounted) return;

    // Only restore if the app was killed while a run was actively in progress.
    // If the last run completed (wasRunning = false), open fresh with no file
    // selected and no logs shown.
    final wasRunning = s['wasRunning'] as bool? ?? false;
    if (!wasRunning) return;

    final filePath = s['filePath'] as String?;
    if (filePath == null) return;

    setState(() {
      _selectedFilePath = filePath;
      _selectedFileName = s['fileName'] as String?;
      _detectedMode     = s['mode'] as String?;
      _logs             = s['logs'] as String? ?? '';
      _outputDir        = s['outputDir'] as String?;
      _isProcessing     = false;

      if (_logs.isNotEmpty) {
        _logVisible = true;
        _logCtrl.forward(from: 1.0);
      }
    });
  }

  Future<void> _checkServiceState() async {
    final state = await HbcChannel.getProcessingState();
    if (!mounted) return;

    final running   = state['running'] == true;
    final logs      = state['logs'] as String? ?? '';
    final status    = state['status'] as String? ?? '';
    final outputDir = state['outputDir'] as String? ?? '';
    final filePath  = state['filePath'] as String? ?? '';
    final fileName  = state['fileName'] as String? ?? '';
    final mode      = state['mode'] as String? ?? '';

    if (running) {
      setState(() {
        _isProcessing     = true;
        _logs             = logs;
        _logVisible       = true;
        _selectedFilePath = filePath.isNotEmpty ? filePath : _selectedFilePath;
        _selectedFileName = fileName.isNotEmpty ? fileName : _selectedFileName;
        _detectedMode     = mode.isNotEmpty ? mode : _detectedMode;
        _outputDir        = null;
      });
      _logCtrl.forward(from: 1.0);
      _startPolling();
    } else if (status.isNotEmpty && _isProcessing) {
      // Only apply completed-run results when we were actively tracking a run.
      // Prevents stale service logs from appearing after file picker returns.
      _stopPolling();
      setState(() {
        _isProcessing     = false;
        _logs             = logs;
        _logVisible       = logs.isNotEmpty;
        _outputDir        = outputDir.isNotEmpty ? outputDir : null;
        _selectedFilePath = filePath.isNotEmpty ? filePath : _selectedFilePath;
        _selectedFileName = fileName.isNotEmpty ? fileName : _selectedFileName;
        _detectedMode     = mode.isNotEmpty ? mode : _detectedMode;
      });
      if (logs.isNotEmpty) _logCtrl.forward(from: 1.0);

      SessionState.save(
        filePath: _selectedFilePath,
        fileName: _selectedFileName,
        mode: _detectedMode,
        logs: _logs,
        outputDir: _outputDir,
        isProcessing: false,
      );
    }

    if (_autoScroll && _logScrollCtrl.hasClients) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_logScrollCtrl.hasClients) {
          _logScrollCtrl.jumpTo(_logScrollCtrl.position.maxScrollExtent);
        }
      });
    }
  }

  void _startPolling() {
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(milliseconds: 500), (_) {
      _pollServiceLogs();
    });
  }

  void _stopPolling() {
    _pollTimer?.cancel();
    _pollTimer = null;
  }

  Future<void> _pollServiceLogs() async {
    final state = await HbcChannel.getProcessingState();
    if (!mounted) return;

    final running = state['running'] == true;
    final logs    = state['logs'] as String? ?? '';

    setState(() { _logs = logs; });

    if (_autoScroll && _logScrollCtrl.hasClients) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_logScrollCtrl.hasClients) {
          _logScrollCtrl.animateTo(
            _logScrollCtrl.position.maxScrollExtent,
            duration: const Duration(milliseconds: 80),
            curve: Curves.easeOut,
          );
        }
      });
    }

    if (!running) {
      _stopPolling();
      final status    = state['status'] as String? ?? '';
      final outputDir = state['outputDir'] as String? ?? '';

      setState(() {
        _isProcessing = false;
        _outputDir    = outputDir.isNotEmpty ? outputDir : null;
      });

      SessionState.save(
        filePath: _selectedFilePath,
        fileName: _selectedFileName,
        mode: _detectedMode,
        logs: _logs,
        outputDir: _outputDir,
        isProcessing: false,
      );

      if (status == 'success') {
        final isAsm = _detectedMode == 'asm' || _detectedMode == 'zip';
        final msg = isAsm
            ? 'Bundle saved to Taurus-Shield/output/'
            : 'HASM saved to Taurus-Shield/output/';
        _showSnack(msg, icon: Icons.check_circle_rounded, color: const Color(0xFF22c55e));
      } else {
        _showSnack('Failed — see output console', icon: Icons.error_rounded, color: const Color(0xFFef4444));
      }
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _pollTimer?.cancel();
    _logScrollCtrl.dispose();
    _pageScrollCtrl.dispose();
    _pulseCtrl.dispose();
    _cardCtrl.dispose();
    _btnCtrl.dispose();
    _logCtrl.dispose();
    _processingCtrl.dispose();
    _orbitCtrl.dispose();
    _scanCtrl.dispose();
    super.dispose();
  }


  // ── Auto-detect mode from file extension ──────────────────────────────────

  String _detectMode(String filePath) {
    final ext = filePath.split('.').last.toLowerCase();
    switch (ext) {
      case 'bundle':
      case 'hbc':
      case 'js':
        return 'dsm';
      case 'hasm':
        return 'asm';
      default:
        return 'dsm';
    }
  }

  // Peek inside a zip's file headers to decide:
  // contains .bundle/.hbc → dsm   |   contains hasm files → zip (asm)
  Future<String> _peekZipMode(String filePath) async {
    try {
      final bytes   = await File(filePath).readAsBytes();
      final archive = ZipDecoder().decodeBytes(bytes, verify: false);
      bool hasBundleOrHbc = false;
      bool hasHasm        = false;
      for (final f in archive.files) {
        final name = f.name.toLowerCase();
        if (name.endsWith('.bundle') || name.endsWith('.hbc')) {
          hasBundleOrHbc = true;
          break;
        }
        if (name.endsWith('.hasm')) {
          hasHasm = true;
        }
      }
      if (hasBundleOrHbc) return 'dsm';
      if (hasHasm)        return 'zip';
      return 'zip';
    } catch (_) {
      return 'zip';
    }
  }

  // ── Storage permission — handled centrally by PermissionHelper ───────────

  // ── Universal file picker — auto-detects mode ─────────────────────────────

  Future<void> _pickFile() async {
    // Kill any active poll before opening picker so the resumed lifecycle
    // event that fires when the picker closes cannot restore stale logs.
    _stopPolling();
    final result = await FilePicker.platform.pickFiles(
      type: FileType.any,
      dialogTitle: 'Select file — .bundle  .hbc  .hasm  .zip',
    );
    if (result != null && result.files.single.path != null) {
      final path = result.files.single.path!;
      final name = result.files.single.name;
      final ext  = name.contains('.') ? name.split('.').last.toLowerCase() : '';
      const allowed = {'bundle', 'hbc', 'hasm', 'zip', 'js'};
      if (!allowed.contains(ext)) {
        _showSnack(
          'Unsupported file type — use .bundle .hbc .hasm .zip',
          icon: Icons.error_outline_rounded,
          color: const Color(0xFFef4444),
        );
        return;
      }

      // For zip files, peek inside to determine DSM vs ASM
      final String mode;
      if (ext == 'zip') {
        mode = await _peekZipMode(path);
      } else {
        mode = _detectMode(path);
      }

      setState(() {
        _selectedFilePath = path;
        _selectedFileName = name;
        _detectedMode     = mode;
        _logs             = '';
        _outputDir        = null;
        _logVisible       = false;
      });
      SessionState.save(
        filePath: path,
        fileName: name,
        mode: mode,
        logs: '',
        outputDir: null,
      );
    }
  }

  // ── Run ───────────────────────────────────────────────────────────────────

  Future<void> _run() async {
    if (_selectedFilePath == null || _detectedMode == null) {
      _showSnack('Select a file first', icon: Icons.warning_amber_rounded, color: const Color(0xFFf59e0b));
      return;
    }

    final hasPermission = await PermissionHelper.ensureStorage(
      context,
      accent: ThemeProvider().current.primary,
    );
    if (!hasPermission) {
      _showSnack('Storage permission is required', icon: Icons.lock_rounded, color: const Color(0xFFef4444));
      return;
    }

    final isAsm     = _detectedMode == 'asm' || _detectedMode == 'zip';
    final prefix    = isAsm ? 'hbc_asm' : 'hbc_disasm';
    final outputDir = await StorageHelper.buildOutputDir(prefix: prefix);

    setState(() {
      _isProcessing = true;
      _outputDir    = null;
      _logs         = '';
      _logVisible   = true;
    });
    _logCtrl.forward(from: 0);
    _scrollToLogPanel();

    try {
      await HbcChannel.startProcessing(
        filePath: _selectedFilePath!,
        fileName: _selectedFileName ?? _selectedFilePath!.split('/').last,
        mode: _detectedMode!,
        outputDir: outputDir,
      );

      SessionState.save(
        filePath: _selectedFilePath!,
        fileName: _selectedFileName,
        mode: _detectedMode,
        logs: '',
        outputDir: outputDir,
        isProcessing: true,
      );

      _startPolling();
    } catch (e) {
      setState(() {
        _logs += 'Failed to start processing: $e\n';
        _isProcessing = false;
      });
      _showSnack('Error: $e', icon: Icons.error_rounded, color: const Color(0xFFef4444));
    }
  }

  void _scrollToLogPanel() {
    // Wait one frame for the log panel widget to be inserted into the tree,
    // then smoothly scroll the page so the top of the log panel is visible.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final ctx = _logPanelKey.currentContext;
      if (ctx == null) return;
      Scrollable.ensureVisible(
        ctx,
        duration: const Duration(milliseconds: 480),
        curve: Curves.easeInOut,
        alignment: 0.0, // align top of widget to top of viewport
      );
    });
  }

  void _showSnack(String msg, {required IconData icon, required Color color}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(icon, color: Colors.white, size: 18),
        const SizedBox(width: 10),
        Expanded(child: Text(msg, style: const TextStyle(color: Colors.white))),
      ]),
      backgroundColor: color,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      margin: const EdgeInsets.all(12),
      duration: const Duration(seconds: 3),
    ));
  }

  Future<void> _shareOutput() async {
    if (_outputDir == null) return;
    final dir   = Directory(_outputDir!);
    final files = dir.listSync().whereType<File>().toList();
    if (files.isEmpty) {
      _showSnack('No output files to share', icon: Icons.info_rounded, color: ThemeProvider().current.primary);
      return;
    }
    await Share.shareXFiles(
      files.map((f) => XFile(f.path)).toList(),
      subject: 'Taurus Shield Output',
    );
  }

  // ── Back confirmation dialog ──────────────────────────────────────────────

  Future<void> _onBackPressed() async {
    final leave = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: ThemeProvider().current.surfaceColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(color: ThemeProvider().current.primary, width: 1),
        ),
        title: Row(
          children: [
            Container(
              padding: EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: ThemeProvider().current.primary.withOpacity(0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(Icons.memory_rounded,
                  color: ThemeProvider().current.primary, size: 20),
            ),
            const SizedBox(width: 12),
            const Expanded(
              child: Text(
                'Leave HBC Tool?',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w700),
              ),
            ),
          ],
        ),
        content: const Text(
          'Are you sure you want to go back? Any active processing will continue running in the background.',
          style: TextStyle(
              color: Color(0xFFa0a0b8), fontSize: 13, height: 1.6),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Stay',
                style: TextStyle(color: Color(0xFF6b7280))),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: ThemeProvider().current.primary,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
            ),
            child: const Text('Go Back',
                style: TextStyle(fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
    if (leave == true && mounted) {
      Navigator.pop(context);
    }
  }

  // ── Build ─────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _onBackPressed();
      },
      child: Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _AppBarShield(),
            const SizedBox(width: 10),
            const Text('TAURUS SHIELD'),
            const SizedBox(width: 10),
            _AppBarShield(mirrored: true),
          ],
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [ThemeProvider().current.appBarBg, ThemeProvider().current.headerBg1],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
          ),
        ),
      ),
      drawer: const AppDrawer(),
      body: SingleChildScrollView(
        controller: _pageScrollCtrl,
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _buildHeader(),
            const SizedBox(height: 20),
            FadeTransition(
              opacity: _cardFade,
              child: SlideTransition(
                position: _cardSlide,
                child: _buildInfoCards(),
              ),
            ),
            const SizedBox(height: 20),
            FadeTransition(opacity: _cardFade, child: _buildFileSelector()),
            if (_selectedFileName != null) ...[
              const SizedBox(height: 12),
              FadeTransition(opacity: _cardFade, child: _buildDetectedFile()),
            ],
            const SizedBox(height: 16),
            ScaleTransition(scale: _btnScale, child: _buildRunButton()),
            const SizedBox(height: 20),
            if (_logVisible)
              FadeTransition(
                key: _logPanelKey,
                opacity: _logFade,
                child: _buildOutputConsole(),
              ),
          ],
        ),
      ),
    ),
    );
  }

  Widget _buildHeader() {
    return AnimatedBuilder(
      animation: Listenable.merge([_pulseAnim, _orbitAnim, _scanAnim]),
      builder: (context, _) {
        return Container(
          padding: const EdgeInsets.fromLTRB(16, 18, 16, 18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(
              colors: [Color(0xFF130820), Color(0xFF0a1228), Color(0xFF130820)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            border: Border.all(
              color: Color.lerp(
                Color(0xFF3a1260),
                ThemeProvider().current.primary,
                _pulseAnim.value,
              )!,
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: ThemeProvider().current.primary
                    .withOpacity(0.22 * _pulseAnim.value),
                blurRadius: 32,
                spreadRadius: 2,
              ),
              BoxShadow(
                color: const Color(0xFF06b6d4)
                    .withOpacity(0.07 * _pulseAnim.value),
                blurRadius: 20,
                spreadRadius: -4,
              ),
            ],
          ),
          child: Row(
            children: [
              // ── Animated shield icon ─────────────────────────────────────
              SizedBox(
                width: 88,
                height: 88,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    // Outermost pulse ring
                    Container(
                      width: 80 + 8 * _pulseAnim.value,
                      height: 80 + 8 * _pulseAnim.value,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: ThemeProvider().current.primary
                            .withOpacity(0.05 * _pulseAnim.value),
                        border: Border.all(
                          color: ThemeProvider().current.primary
                              .withOpacity(0.12 * _pulseAnim.value),
                          width: 1,
                        ),
                      ),
                    ),
                    // Rotating orbit ring (dashed arcs via CustomPaint)
                    Transform.rotate(
                      angle: _orbitAnim.value * 2 * math.pi,
                      child: CustomPaint(
                        size: const Size(72, 72),
                        painter: _OrbitRingPainter(
                          color: Color.lerp(
                            ThemeProvider().current.primary,
                            ThemeProvider().current.highlightColor,
                            _pulseAnim.value,
                          )!,
                          opacity: 0.55 + 0.35 * _pulseAnim.value,
                        ),
                      ),
                    ),
                    // Counter-rotating small dot ring
                    Transform.rotate(
                      angle: -_orbitAnim.value * 2 * math.pi * 0.6,
                      child: CustomPaint(
                        size: const Size(54, 54),
                        painter: _DotOrbitPainter(
                          color: ThemeProvider().current.highlightColor,
                          opacity: 0.6 * _pulseAnim.value,
                        ),
                      ),
                    ),
                    // Shield box with scan line
                    ClipRRect(
                      borderRadius: BorderRadius.circular(15),
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          // Shield background
                          Container(
                            width: 58,
                            height: 58,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15),
                              gradient: LinearGradient(
                                colors: [
                                  Color.lerp(
                                    const Color(0xFF2a0a50),
                                    const Color(0xFF4a1a8a),
                                    _pulseAnim.value,
                                  )!,
                                  const Color(0xFF0f0820),
                                ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                            ),
                          ),
                          // Scan line sweep
                          Positioned(
                            top: _scanAnim.value * 54 - 1,
                            left: 0,
                            right: 0,
                            child: Container(
                              height: 2,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Colors.transparent,
                                    ThemeProvider().current.highlightColor
                                        .withOpacity(0.7),
                                    Colors.transparent,
                                  ],
                                ),
                              ),
                            ),
                          ),
                          // Shield icon (scale pulse)
                          Transform.scale(
                            scale: 0.92 + 0.08 * _pulseAnim.value,
                            child: Icon(
                              Icons.shield_rounded,
                              color: Color.lerp(
                                ThemeProvider().current.primary,
                                const Color(0xFFa78bfa),
                                _pulseAnim.value,
                              ),
                              size: 30,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 14),
              // ── Text column ────────────────────────────────────────────────
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ShaderMask(
                      shaderCallback: (bounds) => LinearGradient(
                        colors: [
                          Color.lerp(Colors.white, Color(0xFFddd6fe),
                              _pulseAnim.value)!,
                          Color.lerp(Color(0xFFddd6fe),
                              ThemeProvider().current.secondary, _pulseAnim.value)!,
                        ],
                      ).createShader(bounds),
                      child: const Text(
                        'TAURUS SHIELD',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          letterSpacing: 2.2,
                        ),
                      ),
                    ),
                    SizedBox(height: 5),
                    Text(
                      'Hermes Bytecode — Assemble & Disassemble',
                      style: TextStyle(
                          fontSize: 10.5,
                          color: ThemeProvider().current.secondary,
                          letterSpacing: 0.2,
                          height: 1.4),
                    ),
                    const SizedBox(height: 6),
                    // File type chips
                    Wrap(
                      spacing: 4,
                      runSpacing: 4,
                      children: [
                        _TypeChip('.bundle'),
                        _TypeChip('.hbc'),
                        _TypeChip('.hasm'),
                        _TypeChip('.zip'),
                      ],
                    ),
                    const SizedBox(height: 6),
                    // HBC version badge
                    Row(
                      children: [
                        const _LiveDot(),
                        const SizedBox(width: 5),
                        const Text(
                          'HBC v59 – v98',
                          style: TextStyle(
                              fontSize: 10,
                              color: Color(0xFF6b7280),
                              letterSpacing: 0.3),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildInfoCards() {
    return Row(
      children: [
        Expanded(child: _InfoCard(
          icon: Icons.code_rounded,
          label: 'DISASSEMBLE',
          tag: 'DSM',
          desc: '.bundle / .hbc  →  .hasm',
          color: ThemeProvider().current.primary,
        )),
        const SizedBox(width: 12),
        Expanded(child: _InfoCard(
          icon: Icons.build_rounded,
          label: 'ASSEMBLE',
          tag: 'ASM',
          desc: '.hasm / .zip  →  .hbc',
          color: const Color(0xFF0ea5e9),
        )),
      ],
    );
  }

  Widget _buildFileSelector() {
    return _PressButton(
      onTap: _pickFile,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 18, horizontal: 20),
        decoration: BoxDecoration(
          color: ThemeProvider().current.surfaceColor,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: ThemeProvider().current.primary.withOpacity(0.5),
            width: 1.5,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.upload_file_rounded, color: ThemeProvider().current.secondary, size: 26),
            const SizedBox(width: 12),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Select File',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w700)),
                Text(
                  '.bundle  .hbc  .hasm  .zip — auto detected',
                  style: TextStyle(color: Color(0xFF6b7280), fontSize: 11),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetectedFile() {
    final isAsm     = _detectedMode == 'asm' || _detectedMode == 'zip';
    final isZip     = _detectedMode == 'zip';
    final modeColor = isAsm ? Color(0xFF0ea5e9) : ThemeProvider().current.primary;
    final modeLabel = isZip ? 'ASM  (ZIP)' : isAsm ? 'ASM' : 'DSM';
    final modeDesc  = isZip
        ? 'ZIP extracted then assembled'
        : isAsm
            ? '.hasm reassembled into bytecode'
            : 'bytecode disassembled to .hasm';

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF1a1a2e),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: modeColor.withOpacity(0.4)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.insert_drive_file_rounded, color: ThemeProvider().current.primary, size: 20),
              const SizedBox(width: 10),
              Expanded(
                child: Text(_selectedFileName!,
                    style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        fontSize: 13),
                    overflow: TextOverflow.ellipsis),
              ),
              IconButton(
                icon: const Icon(Icons.close_rounded, color: Color(0xFF6b7280), size: 20),
                onPressed: () => setState(() {
                  _selectedFilePath = null;
                  _selectedFileName = null;
                  _detectedMode     = null;
                  _logVisible       = false;
                  _logs             = '';
                  _outputDir        = null;
                }),
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: modeColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: modeColor.withOpacity(0.5)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      isAsm ? Icons.build_rounded : Icons.code_rounded,
                      color: modeColor,
                      size: 12,
                    ),
                    const SizedBox(width: 5),
                    Text(modeLabel,
                        style: TextStyle(
                            color: modeColor,
                            fontSize: 11,
                            fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(modeDesc,
                    style: const TextStyle(color: Color(0xFF6b7280), fontSize: 11)),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildRunButton() {
    final hasFile = _selectedFilePath != null;
    final isAsm   = _detectedMode == 'asm' || _detectedMode == 'zip';
    final isZip   = _detectedMode == 'zip';
    final color   = isAsm ? Color(0xFF0ea5e9) : ThemeProvider().current.primary;
    final icon    = isAsm ? Icons.build_rounded : Icons.code_rounded;
    final label   = _isProcessing
        ? (isAsm ? 'Assembling...' : 'Disassembling...')
        : !hasFile
            ? 'Select a file above to continue'
            : isZip
                ? 'Extract ZIP & Assemble'
                : isAsm
                    ? 'Assemble  (ASM)'
                    : 'Disassemble  (DSM)';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _ActionButton(
          icon: icon,
          label: label,
          color: color,
          busy: _isProcessing,
          disabled: _isProcessing || !hasFile,
          onTap: _run,
        ),
        if (_outputDir != null) ...[
          const SizedBox(height: 10),
          _ActionButton(
            icon: Icons.share_rounded,
            label: 'Share Output Files',
            color: const Color(0xFF6b7280),
            busy: false,
            disabled: false,
            onTap: _shareOutput,
            outlined: true,
          ),
        ],
      ],
    );
  }

  Widget _buildOutputConsole() {
    final isSuccess = _logs.contains('successfully') ||
        _logs.contains('generated') ||
        _logs.contains('completed');
    final isError = _logs.contains('ERROR') ||
        _logs.contains('error') ||
        _logs.contains('Failed');
    final color      = isSuccess
        ? Color(0xFF22c55e)
        : isError
            ? Color(0xFFef4444)
            : ThemeProvider().current.primary;
    final statusIcon = isSuccess
        ? Icons.check_circle_rounded
        : isError
            ? Icons.error_rounded
            : Icons.terminal_rounded;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 350),
      decoration: BoxDecoration(
        color: const Color(0xFF080810),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.5)),
        boxShadow: [BoxShadow(color: color.withOpacity(0.08), blurRadius: 16)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
            ),
            child: Row(
              children: [
                _isProcessing
                    ? AnimatedBuilder(
                        animation: _processingRotate,
                        builder: (_, __) => Transform.rotate(
                          angle: _processingRotate.value * 6.28,
                          child: Icon(Icons.settings_rounded, color: color, size: 16),
                        ),
                      )
                    : Icon(statusIcon, color: color, size: 16),
                const SizedBox(width: 8),
                Text(
                  _isProcessing ? 'Processing...' : 'Output',
                  style: TextStyle(
                      color: color,
                      fontWeight: FontWeight.w700,
                      fontSize: 13,
                      letterSpacing: 0.5),
                ),
                const Spacer(),
                // ── Auto-scroll toggle ───────────────────────────────────────
                GestureDetector(
                  onTap: () => setState(() => _autoScroll = !_autoScroll),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: _autoScroll
                          ? const Color(0xFF22c55e).withOpacity(0.15)
                          : const Color(0xFF374151).withOpacity(0.4),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(
                        color: _autoScroll
                            ? const Color(0xFF22c55e).withOpacity(0.5)
                            : const Color(0xFF374151),
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          _autoScroll
                              ? Icons.vertical_align_bottom_rounded
                              : Icons.vertical_align_center_rounded,
                          color: _autoScroll
                              ? const Color(0xFF22c55e)
                              : const Color(0xFF6b7280),
                          size: 13,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          'Auto-scroll',
                          style: TextStyle(
                            color: _autoScroll
                                ? const Color(0xFF22c55e)
                                : const Color(0xFF6b7280),
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                // ── Copy logs button ─────────────────────────────────────────
                GestureDetector(
                  onTap: () {
                    if (_logs.isEmpty) {
                      _showSnack('No logs to copy yet',
                          icon: Icons.info_rounded,
                          color: const Color(0xFF6b7280));
                      return;
                    }
                    Clipboard.setData(ClipboardData(text: _logs));
                    _showSnack('Logs copied',
                        icon: Icons.copy_rounded,
                        color: ThemeProvider().current.primary);
                  },
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: ThemeProvider().current.primary.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(
                          color: ThemeProvider().current.primary.withOpacity(0.4)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.copy_rounded,
                            color: ThemeProvider().current.secondary, size: 13),
                        SizedBox(width: 4),
                        Text('Copy',
                            style: TextStyle(
                                color: ThemeProvider().current.secondary,
                                fontSize: 10,
                                fontWeight: FontWeight.w600)),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                // ── Delete logs button ────────────────────────────────────────
                GestureDetector(
                  onTap: () {
                    if (_logs.isEmpty) return;
                    setState(() {
                      _logs       = '';
                      _outputDir  = null;
                      _logVisible = false;
                    });
                    _logCtrl.reverse();
                    SessionState.save(
                      filePath: _selectedFilePath,
                      fileName: _selectedFileName,
                      mode: _detectedMode,
                      logs: '',
                      outputDir: null,
                    );
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFFef4444).withOpacity(0.10),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(
                          color: const Color(0xFFef4444).withOpacity(0.35)),
                    ),
                    child: const Icon(
                      Icons.delete_outline_rounded,
                      color: Color(0xFFf87171),
                      size: 14,
                    ),
                  ),
                ),
              ],
            ),
          ),
          // Scrollable log area — auto-scrolls as new lines arrive
          Container(
            height: 320,
            margin: const EdgeInsets.fromLTRB(14, 10, 14, 10),
            child: Scrollbar(
              controller: _logScrollCtrl,
              thumbVisibility: true,
              child: SingleChildScrollView(
                controller: _logScrollCtrl,
                padding: const EdgeInsets.only(right: 8),
                child: Text(
                  _logs.isEmpty ? 'Waiting for output...' : _logs,
                  style: TextStyle(
                    fontFamily: 'monospace',
                    fontSize: 11.5,
                    color: _logs.isEmpty
                        ? const Color(0xFF4b5563)
                        : const Color(0xFFd4d4d4),
                    height: 1.75,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Reusable widgets ──────────────────────────────────────────────────────────

class _InfoCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String tag;
  final String desc;
  final Color color;

  const _InfoCard({
    required this.icon,
    required this.label,
    required this.tag,
    required this.desc,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: ThemeProvider().current.surfaceColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.3), width: 1),
        boxShadow: [BoxShadow(color: color.withOpacity(0.08), blurRadius: 12)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 28),
          const SizedBox(height: 10),
          Text(label,
              style: TextStyle(
                  color: color,
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1)),
          Text(tag,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 26,
                  fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          Text(desc,
              style: const TextStyle(color: Color(0xFF6b7280), fontSize: 11)),
        ],
      ),
    );
  }
}

class _PressButton extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;
  const _PressButton({required this.child, required this.onTap});

  @override
  State<_PressButton> createState() => _PressButtonState();
}

class _PressButtonState extends State<_PressButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 90));
    _scale = Tween<double>(begin: 1.0, end: 0.97).animate(_ctrl);
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) { _ctrl.reverse(); widget.onTap(); },
      onTapCancel: () => _ctrl.reverse(),
      child: ScaleTransition(scale: _scale, child: widget.child),
    );
  }
}

class _ActionButton extends StatefulWidget {
  final IconData icon;
  final String label;
  final Color color;
  final bool busy;
  final bool disabled;
  final bool outlined;
  final VoidCallback onTap;

  const _ActionButton({
    required this.icon,
    required this.label,
    required this.color,
    required this.busy,
    required this.disabled,
    required this.onTap,
    this.outlined = false,
  });

  @override
  State<_ActionButton> createState() => _ActionButtonState();
}

class _ActionButtonState extends State<_ActionButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 80));
    _scale = Tween<double>(begin: 1.0, end: 0.96).animate(_ctrl);
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final effectiveColor =
        widget.disabled ? widget.color.withOpacity(0.4) : widget.color;

    return GestureDetector(
      onTapDown: widget.disabled ? null : (_) => _ctrl.forward(),
      onTapUp:   widget.disabled
          ? null
          : (_) { _ctrl.reverse(); widget.onTap(); },
      onTapCancel: () => _ctrl.reverse(),
      child: ScaleTransition(
        scale: _scale,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: widget.outlined
              ? BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: effectiveColor),
                  color: Colors.transparent,
                )
              : BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: effectiveColor,
                  boxShadow: widget.disabled
                      ? []
                      : [
                          BoxShadow(
                              color: widget.color.withOpacity(0.3),
                              blurRadius: 12,
                              offset: const Offset(0, 4))
                        ],
                ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (widget.busy)
                SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: widget.outlined ? effectiveColor : Colors.white),
                )
              else
                Icon(widget.icon,
                    color: widget.outlined ? effectiveColor : Colors.white,
                    size: 20),
              const SizedBox(width: 10),
              Text(
                widget.label,
                style: TextStyle(
                  color: widget.outlined ? effectiveColor : Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.4,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ── Live pulse dot ─────────────────────────────────────────────────────────────

class _LiveDot extends StatefulWidget {
  const _LiveDot();

  @override
  State<_LiveDot> createState() => _LiveDotState();
}

class _LiveDotState extends State<_LiveDot> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _ring;
  late final Animation<double> _fade;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat();

    _ring = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeOut),
    );
    _fade = Tween<double>(begin: 0.8, end: 0.0).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeOut),
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 16,
      height: 16,
      child: AnimatedBuilder(
        animation: _ctrl,
        builder: (_, __) => Stack(
          alignment: Alignment.center,
          children: [
            // Expanding ripple ring
            Container(
              width:  6 + _ring.value * 10,
              height: 6 + _ring.value * 10,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: const Color(0xFF22c55e).withOpacity(_fade.value),
                  width: 1.2,
                ),
              ),
            ),
            // Solid core dot
            Container(
              width: 6,
              height: 6,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Color(0xFF22c55e),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x8022c55e),
                    blurRadius: 5,
                    spreadRadius: 1,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── AppBar shield decoration ───────────────────────────────────────────────────

class _AppBarShield extends StatelessWidget {
  final bool mirrored;
  const _AppBarShield({this.mirrored = false});

  @override
  Widget build(BuildContext context) {
    final icon = Transform.scale(
      scaleX: mirrored ? -1 : 1,
      child: CustomPaint(
        size: const Size(18, 20),
        painter: _ShieldSvgPainter(),
      ),
    );
    return icon;
  }
}

class _ShieldSvgPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final theme = ThemeProvider().current;
    final w = size.width;
    final h = size.height;

    final path = Path()
      ..moveTo(w * 0.5, 0)
      ..lineTo(w, h * 0.18)
      ..lineTo(w, h * 0.52)
      ..quadraticBezierTo(w, h * 0.82, w * 0.5, h)
      ..quadraticBezierTo(0, h * 0.82, 0, h * 0.52)
      ..lineTo(0, h * 0.18)
      ..close();

    final fillPaint = Paint()
      ..shader = LinearGradient(
        colors: [
          theme.secondary.withOpacity(0.22),
          theme.primary.withOpacity(0.12),
        ],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ).createShader(Rect.fromLTWH(0, 0, w, h))
      ..style = PaintingStyle.fill;

    canvas.drawPath(path, fillPaint);

    final strokePaint = Paint()
      ..color = theme.secondary.withOpacity(0.85)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4
      ..strokeJoin = StrokeJoin.round;

    canvas.drawPath(path, strokePaint);

    final highlightPath = Path()
      ..moveTo(w * 0.5, h * 0.04)
      ..lineTo(w * 0.88, h * 0.20)
      ..lineTo(w * 0.88, h * 0.50);

    final highlightPaint = Paint()
      ..color = theme.highlightColor.withOpacity(0.5)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8
      ..strokeCap = StrokeCap.round;

    canvas.drawPath(highlightPath, highlightPaint);

    final tPaint = Paint()
      ..color = theme.secondary.withOpacity(0.9)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..strokeCap = StrokeCap.round;

    // Horizontal bar of T
    canvas.drawLine(
      Offset(w * 0.3, h * 0.40),
      Offset(w * 0.7, h * 0.40),
      tPaint,
    );
    // Vertical bar of T
    canvas.drawLine(
      Offset(w * 0.5, h * 0.40),
      Offset(w * 0.5, h * 0.68),
      tPaint,
    );
  }

  @override
  bool shouldRepaint(_ShieldSvgPainter _) => false;
}

// ── File type chip ─────────────────────────────────────────────────────────────

class _TypeChip extends StatelessWidget {
  final String label;
  const _TypeChip(this.label);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: ThemeProvider().current.primary.withOpacity(0.10),
        borderRadius: BorderRadius.circular(5),
        border: Border.all(color: ThemeProvider().current.primary.withOpacity(0.28)),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: ThemeProvider().current.secondary,
          fontSize: 9,
          fontFamily: 'monospace',
          fontWeight: FontWeight.w600,
          letterSpacing: 0.2,
        ),
      ),
    );
  }
}

// ── Orbit ring painter — 3 dashed arc segments rotating ───────────────────────

class _OrbitRingPainter extends CustomPainter {
  final Color color;
  final double opacity;
  const _OrbitRingPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r  = (size.width / 2) - 2;

    final paint = Paint()
      ..color = color.withOpacity(opacity)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5
      ..strokeCap = StrokeCap.round;

    // Draw 3 arc segments evenly spaced (gap = 60°, arc = 60°)
    const gapRad  = math.pi / 3;   // 60°
    const arcRad  = math.pi / 3;   // 60°
    for (int i = 0; i < 3; i++) {
      final start = i * (arcRad + gapRad);
      canvas.drawArc(
        Rect.fromCircle(center: Offset(cx, cy), radius: r),
        start,
        arcRad,
        false,
        paint,
      );
    }

    // Draw 3 small diamond markers at arc midpoints
    final dotPaint = Paint()
      ..color = color.withOpacity(opacity * 0.9)
      ..style = PaintingStyle.fill;

    for (int i = 0; i < 3; i++) {
      final angle = i * (arcRad + gapRad) + arcRad / 2;
      final dx = cx + r * math.cos(angle);
      final dy = cy + r * math.sin(angle);
      canvas.drawCircle(Offset(dx, dy), 2.2, dotPaint);
    }
  }

  @override
  bool shouldRepaint(_OrbitRingPainter old) =>
      old.color != color || old.opacity != opacity;
}

// ── Dot orbit painter — 6 small dots on a tighter ring ────────────────────────

class _DotOrbitPainter extends CustomPainter {
  final Color color;
  final double opacity;
  const _DotOrbitPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r  = (size.width / 2) - 1;

    for (int i = 0; i < 6; i++) {
      final angle = i * (math.pi / 3);
      final dx = cx + r * math.cos(angle);
      final dy = cy + r * math.sin(angle);
      // Alternate sizes
      final radius = i % 2 == 0 ? 1.8 : 1.1;
      canvas.drawCircle(
        Offset(dx, dy),
        radius,
        Paint()
          ..color = color.withOpacity(opacity * (i % 2 == 0 ? 1.0 : 0.5))
          ..style = PaintingStyle.fill,
      );
    }
  }

  @override
  bool shouldRepaint(_DotOrbitPainter old) =>
      old.color != color || old.opacity != opacity;
}
