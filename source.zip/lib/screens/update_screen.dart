import '../utils/theme_provider.dart';
import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:webview_flutter/webview_flutter.dart';

// --------------------------------------------------------------------------
// Force-update watchdog — survives widget disposal
// --------------------------------------------------------------------------
class _ForceUpdateGuard with WidgetsBindingObserver {
  final NavigatorState navigator;
  final Map<String, dynamic> updateData;
  bool _active = true;
  bool _pushing = false;
  bool Function()? isMounted;

  _ForceUpdateGuard({required this.navigator, required this.updateData}) {
    WidgetsBinding.instance.addObserver(this);
  }

  void deactivate() {
    _active = false;
    isMounted = null;
    WidgetsBinding.instance.removeObserver(this);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (!_active || _pushing || state != AppLifecycleState.resumed) return;
    final showing = isMounted?.call() ?? false;
    if (!showing) {
      _pushing = true;
      navigator
          .push(PageRouteBuilder(
            opaque: true,
            barrierDismissible: false,
            pageBuilder: (_, __, ___) => UpdateScreen(
              apkUrl: updateData['apkUrl'] as String,
              versionName: updateData['versionName'] as String,
              changelog: updateData['changelog'] as String? ?? '',
              updateSize: updateData['updateSize'] as String? ?? '',
              force: true,
            ),
            transitionsBuilder: (_, anim, __, child) =>
                FadeTransition(opacity: anim, child: child),
          ))
          .then((_) => _pushing = false);
    }
  }
}

// --------------------------------------------------------------------------
// UpdateScreen
// --------------------------------------------------------------------------
class UpdateScreen extends StatefulWidget {
  final String apkUrl;
  final String versionName;
  final String changelog;
  final String updateSize;
  final bool force;

  const UpdateScreen({
    super.key,
    required this.apkUrl,
    required this.versionName,
    required this.changelog,
    required this.updateSize,
    this.force = false,
  });

  @override
  State<UpdateScreen> createState() => _UpdateScreenState();
}

class _UpdateScreenState extends State<UpdateScreen>
    with WidgetsBindingObserver {
  static const _channel = MethodChannel('com.taurus.shield/storage');
  static _ForceUpdateGuard? _guard;

  late final WebViewController _webCtrl;

  bool _downloading = false;
  double _downloadProgress = 0.0;
  String _downloadStatus = '';
  bool _cancelled = false;

  bool _awaitingPermission = false;
  bool _awaitingUninstall = false;
  String _pendingContentUri = '';
  String _pendingFileUri = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    _webCtrl = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF060610))
      ..setNavigationDelegate(NavigationDelegate(
        onNavigationRequest: (req) {
          if (!req.url.contains('taurus-shield-updater') &&
              req.isMainFrame) {
            return NavigationDecision.prevent;
          }
          return NavigationDecision.navigate;
        },
      ))
      ..addJavaScriptChannel(
        'FlutterDownload',
        onMessageReceived: (_) => _downloadAndInstall(),
      )
      ..addJavaScriptChannel(
        'FlutterCancel',
        onMessageReceived: (_) => _cancelDownload(),
      )
      ..addJavaScriptChannel(
        'FlutterDismiss',
        onMessageReceived: (_) {
          if (!widget.force) {
            deactivateGuard();
            Navigator.of(context).pop();
          }
        },
      )
      ..loadRequest(Uri.parse(
        'https://taurus-shield-updater.matrixzat99.workers.dev/update',
      ));

    if (widget.force) _activateGuard();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) return;
    if (_awaitingPermission || _awaitingUninstall) _retryInstall();
  }

  void _activateGuard() {
    _channel
        .invokeMethod<void>('setForceUpdate', {'enabled': true})
        .catchError((_) {});
    if (_guard == null) {
      _guard = _ForceUpdateGuard(
        navigator: Navigator.of(context),
        updateData: {
          'apkUrl': widget.apkUrl,
          'versionName': widget.versionName,
          'changelog': widget.changelog,
          'updateSize': widget.updateSize,
        },
      );
    }
    _guard!.isMounted = () => mounted;
  }

  static void deactivateGuard() {
    _guard?.deactivate();
    _guard = null;
    _channel
        .invokeMethod<void>('setForceUpdate', {'enabled': false})
        .catchError((_) {});
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    if (widget.force) _guard?.isMounted = null;
    super.dispose();
  }

  void _webJs(String js) {
    _webCtrl.runJavaScript(js).catchError((_) {});
  }

  Future<void> _downloadAndInstall() async {
    if (_downloading) return;
    _cancelled = false;

    if (!mounted) return;
    setState(() {
      _downloading = true;
      _awaitingPermission = false;
      _awaitingUninstall = false;
      _downloadProgress = 0.0;
    });

    _webJs("updateProgress(0,'Preparing download...')");

    try {
      final dir = await getApplicationDocumentsDirectory();
      final savePath = '${dir.path}/taurus_update.apk';

      final oldFile = File(savePath);
      if (await oldFile.exists()) await oldFile.delete();

      final request = http.Request('GET', Uri.parse(widget.apkUrl));
      final response = await request.send().timeout(const Duration(minutes: 15));

      if (!mounted) return;

      final total = response.contentLength ?? 0;
      int received = 0;
      final sink = File(savePath).openWrite();

      await for (final chunk in response.stream) {
        if (_cancelled) {
          await sink.flush();
          await sink.close();
          return;
        }
        sink.add(chunk);
        received += chunk.length;

        if (!mounted) break;
        final dlMB = received / 1048576.0;
        final totMB = total > 0 ? total / 1048576.0 : 0.0;
        final pct = total > 0 ? (received / total * 100).clamp(0, 100).toInt() : 0;
        final label = totMB > 0
            ? 'Downloading ${dlMB.toStringAsFixed(1)} / ${totMB.toStringAsFixed(1)} MB'
            : 'Downloading ${dlMB.toStringAsFixed(1)} MB...';

        if (mounted) {
          setState(() {
            _downloadProgress = pct / 100.0;
            _downloadStatus = label;
          });
        }
        _webJs("updateProgress($pct,'${label.replaceAll("'", "\\'")}')");
      }

      await sink.flush();
      await sink.close();

      if (!mounted || _cancelled) return;
      _webJs("updateProgress(100,'Preparing install...')");
      setState(() => _downloadStatus = 'Preparing install...');

      final fileUri = 'file://$savePath';
      String contentUri = fileUri;
      try {
        contentUri = await _channel.invokeMethod<String>(
              'getContentUri',
              {'filePath': savePath},
            ) ??
            fileUri;
      } catch (_) {}

      if (!mounted) return;
      setState(() {
        _pendingContentUri = contentUri;
        _pendingFileUri = fileUri;
      });

      await _runInstall(contentUri, fileUri);
    } catch (e) {
      if (!mounted || _cancelled) return;
      setState(() {
        _downloading = false;
        _downloadStatus = '';
      });
      _webJs("downloadFailed()");
    }
  }

  Future<void> _retryInstall() async {
    if (_pendingFileUri.isEmpty) return;
    String freshUri = _pendingContentUri;
    try {
      final rawPath = _pendingFileUri.replaceFirst('file://', '');
      freshUri = await _channel.invokeMethod<String>(
            'getContentUri',
            {'filePath': rawPath},
          ) ??
          _pendingContentUri;
    } catch (_) {}
    await _runInstall(freshUri, _pendingFileUri);
  }

  Future<void> _runInstall(String contentUri, String fileUri) async {
    try {
      final raw = await _channel.invokeMethod<Object>(
        'installUpdate',
        {'contentUri': contentUri, 'fileUri': fileUri},
      );
      final res = (raw as Map?)?.cast<String, dynamic>() ?? {};

      if (!mounted) return;

      final needsPerm = res['needsPermission'] as bool? ?? false;
      final sigConflict = res['signatureConflict'] as bool? ?? false;
      final conflictPkg = res['conflictingPackage'] as String? ?? '';

      if (needsPerm) {
        setState(() {
          _awaitingPermission = true;
          _awaitingUninstall = false;
          _downloading = false;
        });
      } else if (sigConflict) {
        setState(() {
          _awaitingUninstall = true;
          _awaitingPermission = false;
          _downloading = false;
          _downloadStatus = 'Please uninstall the existing version,\nthen return here.';
        });
        try {
          await _channel.invokeMethod('triggerUninstall', {'packageName': conflictPkg});
        } catch (_) {}
      } else {
        setState(() {
          _downloading = false;
          _awaitingPermission = true;
          _awaitingUninstall = false;
        });
      }
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _downloading = false;
        _downloadStatus = 'Install error. Please try again.';
      });
    }
  }

  void _cancelDownload() {
    _cancelled = true;
    if (!mounted) return;
    setState(() {
      _downloading = false;
      _downloadProgress = 0.0;
      _downloadStatus = '';
    });
    _webJs("cancelDownload()");
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !widget.force,
      child: AnnotatedRegion<SystemUiOverlayStyle>(
        value: const SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.light,
        ),
        child: Scaffold(
          backgroundColor: const Color(0xFF060610),
          body: _awaitingUninstall
              ? _buildProgressOverlay()
              : WebViewWidget(controller: _webCtrl),
        ),
      ),
    );
  }

  Widget _buildProgressOverlay() {
    final pct = (_downloadProgress * 100).toStringAsFixed(0);
    return Container(
      color: const Color(0xFF060610),
      width: double.infinity,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            'TAURUS SHIELD',
            style: TextStyle(
              color: ThemeProvider().current.primary,
              fontSize: 18,
              fontWeight: FontWeight.w800,
              letterSpacing: 2.5,
            ),
          ),
          SizedBox(height: 36),
          if (_downloadProgress >= 1.0)
            Icon(Icons.system_update_alt_rounded,
                color: ThemeProvider().current.highlightColor, size: 52)
          else
            Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 76,
                  height: 76,
                  child: CircularProgressIndicator(
                    value: _downloadProgress > 0 ? _downloadProgress : null,
                    color: ThemeProvider().current.primary,
                    backgroundColor: Colors.white10,
                    strokeWidth: 5,
                  ),
                ),
                Text(
                  '$pct%',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          const SizedBox(height: 28),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Text(
              _downloadStatus,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white.withOpacity(0.80),
                fontSize: 14,
                height: 1.5,
              ),
            ),
          ),
          const SizedBox(height: 12),
          if (_downloadProgress > 0 && _downloadProgress < 1.0)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: _downloadProgress,
                  minHeight: 6,
                  backgroundColor: Colors.white10,
                  valueColor: AlwaysStoppedAnimation<Color>(
                    ThemeProvider().current.primary,
                  ),
                ),
              ),
            ),
          const SizedBox(height: 28),
          if (_downloadProgress < 1.0)
            TextButton(
              onPressed: _cancelDownload,
              child: Text(
                'Cancel',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.4),
                  fontSize: 13,
                ),
              ),
            ),
          if (_awaitingUninstall)
            Padding(
              padding: EdgeInsets.only(top: 16),
              child: TextButton(
                onPressed: _retryInstall,
                style: TextButton.styleFrom(
                  foregroundColor: ThemeProvider().current.primary,
                  padding:
                      EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                    side: BorderSide(color: ThemeProvider().current.primary),
                  ),
                ),
                child: const Text('Retry Install'),
              ),
            ),
        ],
      ),
    );
  }
}
