import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

import '../services/upload_service.dart';
import '../utils/hbc_channel.dart';
import '../utils/theme_provider.dart';

// ── accent colours for this screen ────────────────────────────────────────────
const _kAccent  = Color(0xFF0ea5e9);   // sky-400
const _kAccent2 = Color(0xFF38bdf8);   // sky-300  (brighter)
const _kBg1     = Color(0xFF071928);
const _kBg2     = Color(0xFF0b1f30);

// ─────────────────────────────────────────────────────────────────────────────

class UploadScreen extends StatefulWidget {
  const UploadScreen({super.key});
  @override
  State<UploadScreen> createState() => _UploadScreenState();
}

enum _Status { queued, uploading, success, failed, cancelled }

class _Job {
  final int id;
  final File file;
  final int sizeBytes;
  _Status status = _Status.queued;
  int sent = 0;
  int total = 0;
  String? currentHost;
  final List<String> tried = [];
  String? resultUrl;
  String? resultHost;
  String? resultExpiry;
  String? errorMessage;
  final CancelToken token = CancelToken();

  _Job(this.id, this.file, this.sizeBytes);
}

class _UploadScreenState extends State<UploadScreen>
    with TickerProviderStateMixin {
  final List<_Job> _jobs = [];
  int _idCounter = 0;
  bool _picking = false;

  // Animations
  late final AnimationController _pulseCtrl;
  late final AnimationController _orbitCtrl;
  late final AnimationController _scanCtrl;
  late final Animation<double> _pulseAnim;
  late final Animation<double> _scanAnim;

  @override
  void initState() {
    super.initState();

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..repeat(reverse: true);

    _orbitCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 5000),
    )..repeat();

    _scanCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2400),
    )..repeat();

    _pulseAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );

    _scanAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _scanCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _orbitCtrl.dispose();
    _scanCtrl.dispose();
    for (final j in _jobs) {
      if (j.status == _Status.queued || j.status == _Status.uploading) {
        j.token.cancel();
      }
    }
    super.dispose();
  }

  Future<void> _pickFiles() async {
    if (_picking) return;
    _picking = true;
    try {
      final res = await FilePicker.platform.pickFiles(allowMultiple: true);
      if (res == null) return;
      for (final f in res.files) {
        final path = f.path;
        if (path == null) continue;
        final file = File(path);
        final size = await file.length();
        final job = _Job(++_idCounter, file, size);
        setState(() => _jobs.insert(0, job));
        unawaited(_runJob(job));
      }
    } finally {
      _picking = false;
    }
  }

  bool get _anyActive => _jobs.any(
        (j) => j.status == _Status.uploading || j.status == _Status.queued,
      );

  Future<void> _runJob(_Job j) async {
    final wasIdle = !_anyActive;
    setState(() => j.status = _Status.uploading);
    if (wasIdle) unawaited(HbcChannel.tempHostStartForeground());

    try {
      final result = await UploadHosts.dispatch(
        j.file,
        token: j.token,
        onHostStart: (host) {
          if (!mounted) return;
          setState(() {
            j.currentHost = host;
            if (!j.tried.contains(host)) j.tried.add(host);
            j.sent = 0;
            j.total = j.sizeBytes;
          });
        },
        onProgress: (sent, total) {
          if (!mounted) return;
          setState(() {
            j.sent = sent;
            j.total = total;
          });
        },
      );
      if (!mounted) return;
      setState(() {
        j.status = _Status.success;
        j.resultUrl = result.url;
        j.resultHost = result.hostName;
        j.resultExpiry = result.expiryNote;
      });
    } on CancelledException {
      if (!mounted) return;
      setState(() => j.status = _Status.cancelled);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        j.status = _Status.failed;
        j.errorMessage = e.toString();
      });
    } finally {
      if (!_anyActive) unawaited(HbcChannel.tempHostStopForeground());
    }
  }

  void _retry(_Job j) {
    j.token.reset();
    setState(() {
      j.status = _Status.queued;
      j.errorMessage = null;
      j.sent = 0;
      j.total = 0;
      j.tried.clear();
      j.currentHost = null;
    });
    unawaited(_runJob(j));
  }

  void _cancel(_Job j) => j.token.cancel();

  void _remove(_Job j) => setState(() => _jobs.remove(j));

  void _clearFinished() {
    setState(() {
      _jobs.removeWhere((j) =>
          j.status == _Status.success ||
          j.status == _Status.failed ||
          j.status == _Status.cancelled);
    });
  }

  // ── Header ─────────────────────────────────────────────────────────────────

  Widget _buildHeader() {
    return AnimatedBuilder(
      animation: Listenable.merge([_pulseAnim, _orbitCtrl, _scanAnim]),
      builder: (context, _) {
        final pulse = _pulseAnim.value;
        final orbit = _orbitCtrl.value;
        final scan  = _scanAnim.value;

        final scanOpacity = scan < 0.5
            ? (scan * 2).clamp(0.0, 1.0)
            : ((1.0 - scan) * 2).clamp(0.0, 1.0);
        final scanY = scan * 84.0;

        return Container(
          margin: const EdgeInsets.fromLTRB(16, 16, 16, 8),
          padding: const EdgeInsets.fromLTRB(16, 18, 16, 18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(
              colors: [_kBg1, _kBg2, _kBg1],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            border: Border.all(
              color: Color.lerp(
                _kAccent.withOpacity(0.25),
                _kAccent2.withOpacity(0.45),
                pulse,
              )!,
            ),
            boxShadow: [
              BoxShadow(
                color: _kAccent.withOpacity(0.05 + pulse * 0.08),
                blurRadius: 24,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Row(
            children: [
              // ── Animated icon ─────────────────────────────────────────────
              SizedBox(
                width: 96,
                height: 96,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    // Outer pulse ring
                    Container(
                      width: 90 + pulse * 6,
                      height: 90 + pulse * 6,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: _kAccent.withOpacity(0.08 + pulse * 0.10),
                          width: 1,
                        ),
                      ),
                    ),
                    // Rotating orbit arcs
                    Transform.rotate(
                      angle: orbit * 2 * math.pi,
                      child: CustomPaint(
                        size: const Size(82, 82),
                        painter: _UpOrbitPainter(
                          color: Color.lerp(_kAccent, _kAccent2, pulse)!,
                          opacity: 0.50 + pulse * 0.25,
                        ),
                      ),
                    ),
                    // Counter-rotating dot ring
                    Transform.rotate(
                      angle: -orbit * 2 * math.pi * 0.6,
                      child: CustomPaint(
                        size: const Size(68, 68),
                        painter: _UpDotPainter(
                          color: _kAccent,
                          opacity: 0.35 + pulse * 0.20,
                        ),
                      ),
                    ),
                    // Icon box with scan line
                    Transform.scale(
                      scale: 1.0 + pulse * 0.03,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(18),
                        child: Stack(
                          children: [
                            Container(
                              width: 64,
                              height: 64,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Color.lerp(const Color(0xFF0a3a5a),
                                        const Color(0xFF0d4a6e), pulse)!,
                                    const Color(0xFF041828),
                                  ],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: _kAccent.withOpacity(
                                        0.25 + pulse * 0.20),
                                    blurRadius: 18,
                                    spreadRadius: 1,
                                  ),
                                ],
                              ),
                              child: Icon(
                                Icons.cloud_upload_rounded,
                                color: _kAccent2,
                                size: 30,
                              ),
                            ),
                            // Scan line
                            Positioned(
                              top: scanY - 2,
                              left: 0,
                              right: 0,
                              child: Opacity(
                                opacity: scanOpacity * 0.6,
                                child: Container(
                                  height: 2,
                                  decoration: const BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [
                                        Colors.transparent,
                                        _kAccent,
                                        Colors.transparent,
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(width: 16),

              // ── Info column ───────────────────────────────────────────────
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ShaderMask(
                      shaderCallback: (bounds) => LinearGradient(
                        colors: [
                          Colors.white,
                          Color.lerp(
                              const Color(0xFFffffff), _kAccent2, pulse)!,
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ).createShader(bounds),
                      child: const Text(
                        'Temp Host',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'Free Temporary File Hosting',
                      style: TextStyle(
                        color: _kAccent,
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 6,
                      runSpacing: 4,
                      children: const [
                        _UpChip('any file'),
                        _UpChip('free link'),
                        _UpChip('temp host'),
                        _UpChip('multi-upload'),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        _UpLiveDot(color: _kAccent),
                        const SizedBox(width: 5),
                        const Text(
                          'Litterbox · filebin · qu.ax · +3',
                          style: TextStyle(
                            fontSize: 10,
                            color: Color(0xFF6b7280),
                            letterSpacing: 0.3,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ── Build ──────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final t = ThemeProvider().current;
    final hasFinished = _jobs.any((j) =>
        j.status == _Status.success ||
        j.status == _Status.failed ||
        j.status == _Status.cancelled);
    return Scaffold(
      appBar: AppBar(
        title: const Text('TEMP HOST'),
        actions: [
          if (hasFinished)
            IconButton(
              tooltip: 'Clear finished',
              icon: const Icon(Icons.cleaning_services_outlined),
              onPressed: _clearFinished,
            ),
        ],
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [t.appBarBg, t.headerBg1],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          _buildHeader(),
          Expanded(
            child: _jobs.isEmpty
                ? _UpEmptyState(
                    onPick: _pickFiles,
                    picking: _picking,
                    pulseAnim: _pulseAnim,
                  )
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
                    itemCount: _jobs.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (_, i) => _JobTile(
                      j: _jobs[i],
                      onCancel: () => _cancel(_jobs[i]),
                      onRetry: () => _retry(_jobs[i]),
                      onRemove: () => _remove(_jobs[i]),
                    ),
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _pickFiles,
        backgroundColor: _kAccent,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.cloud_upload_rounded),
        label: const Text('PICK FILES',
            style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1)),
      ),
    );
  }
}

// ── Empty state ────────────────────────────────────────────────────────────────

class _UpEmptyState extends StatelessWidget {
  final VoidCallback onPick;
  final bool picking;
  final Animation<double> pulseAnim;
  const _UpEmptyState({
    required this.onPick,
    required this.picking,
    required this.pulseAnim,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: AnimatedBuilder(
          animation: pulseAnim,
          builder: (_, __) {
            final p = pulseAnim.value;
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Stack(
                  alignment: Alignment.center,
                  children: [
                    Container(
                      width: 100 + p * 10,
                      height: 100 + p * 10,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: _kAccent.withOpacity(0.10 + p * 0.12),
                          width: 1,
                        ),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.all(22),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(
                          colors: [
                            _kAccent.withOpacity(0.18 + p * 0.08),
                            _kAccent.withOpacity(0.05),
                          ],
                        ),
                        border: Border.all(
                          color: _kAccent.withOpacity(0.30 + p * 0.15),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: _kAccent.withOpacity(0.08 + p * 0.10),
                            blurRadius: 20,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: Icon(
                        Icons.cloud_upload_rounded,
                        size: 46,
                        color: _kAccent2,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                const Text(
                  'No files queued',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.4,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Tap PICK FILES to start uploading.\nYou can queue multiple files.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xFF6b7280),
                    fontSize: 12.5,
                    height: 1.5,
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

// ── Job tile ──────────────────────────────────────────────────────────────────

class _JobTile extends StatelessWidget {
  final _Job j;
  final VoidCallback onCancel;
  final VoidCallback onRetry;
  final VoidCallback onRemove;
  const _JobTile({
    required this.j,
    required this.onCancel,
    required this.onRetry,
    required this.onRemove,
  });

  String _fmtBytes(int b) {
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    double v = b.toDouble();
    int u = 0;
    while (v >= 1024 && u < units.length - 1) {
      v /= 1024;
      u++;
    }
    return '${v.toStringAsFixed(v >= 100 || u == 0 ? 0 : 1)} ${units[u]}';
  }

  @override
  Widget build(BuildContext context) {
    final t = ThemeProvider().current;
    final fileName = j.file.uri.pathSegments.last;
    final pct = j.total > 0 ? (j.sent / j.total).clamp(0.0, 1.0) : 0.0;
    Color statusColor;
    String statusText;
    switch (j.status) {
      case _Status.queued:
        statusColor = t.subtextColor;
        statusText = 'Queued…';
        break;
      case _Status.uploading:
        statusColor = _kAccent;
        statusText =
            'Uploading via ${j.currentHost ?? '…'}  ·  ${_fmtBytes(j.sent)} / ${_fmtBytes(j.total)}';
        break;
      case _Status.success:
        statusColor = const Color(0xFF22c55e);
        statusText = 'Uploaded to ${j.resultHost}  ·  ${j.resultExpiry ?? ''}';
        break;
      case _Status.failed:
        statusColor = const Color(0xFFef4444);
        statusText = 'Failed: ${j.errorMessage ?? 'unknown error'}';
        break;
      case _Status.cancelled:
        statusColor = Colors.orange;
        statusText = 'Cancelled';
        break;
    }

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: t.surfaceColor,
        border: Border.all(
          color: j.status == _Status.success
              ? const Color(0xFF22c55e).withOpacity(0.35)
              : j.status == _Status.failed
                  ? const Color(0xFFef4444).withOpacity(0.30)
                  : _kAccent.withOpacity(0.22),
        ),
        boxShadow: j.status == _Status.uploading
            ? [
                BoxShadow(
                  color: _kAccent.withOpacity(0.06),
                  blurRadius: 12,
                  spreadRadius: 1,
                )
              ]
            : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: _kAccent.withOpacity(0.12),
                  border: Border.all(color: _kAccent.withOpacity(0.25)),
                ),
                child: const Icon(Icons.insert_drive_file_outlined,
                    color: _kAccent, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      fileName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: t.textColor,
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      _fmtBytes(j.sizeBytes),
                      style: TextStyle(
                        color: t.subtextColor.withOpacity(0.7),
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
              if (j.status == _Status.uploading)
                IconButton(
                  tooltip: 'Cancel',
                  icon: const Icon(Icons.close_rounded, size: 20),
                  color: t.subtextColor,
                  onPressed: onCancel,
                )
              else
                IconButton(
                  tooltip: 'Remove',
                  icon: const Icon(Icons.delete_outline_rounded, size: 20),
                  color: t.subtextColor,
                  onPressed: onRemove,
                ),
            ],
          ),
          const SizedBox(height: 10),
          if (j.status == _Status.uploading || j.status == _Status.queued)
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: j.status == _Status.queued ? null : pct,
                minHeight: 6,
                backgroundColor: _kAccent.withOpacity(0.12),
                valueColor: const AlwaysStoppedAnimation(_kAccent),
              ),
            ),
          const SizedBox(height: 8),
          Text(
            statusText,
            style: TextStyle(
              color: statusColor,
              fontSize: 11.5,
              fontWeight: FontWeight.w600,
            ),
          ),
          if (j.tried.length > 1 && j.status != _Status.success) ...[
            const SizedBox(height: 4),
            Text(
              'Tried: ${j.tried.join(' → ')}',
              style: TextStyle(
                color: t.subtextColor.withOpacity(0.55),
                fontSize: 10.5,
              ),
            ),
          ],
          if (j.status == _Status.success && j.resultUrl != null) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: t.appBarBg,
                border: Border.all(color: _kAccent.withOpacity(0.30)),
              ),
              child: SelectableText(
                j.resultUrl!,
                style: const TextStyle(
                  color: _kAccent2,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.2,
                ),
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () async {
                      await Clipboard.setData(
                          ClipboardData(text: j.resultUrl!));
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Link copied to clipboard'),
                            duration: Duration(seconds: 2),
                          ),
                        );
                      }
                    },
                    icon: const Icon(Icons.copy_rounded, size: 18),
                    label: const Text('Copy'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: _kAccent,
                      side: BorderSide(color: _kAccent.withOpacity(0.5)),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => Share.share(j.resultUrl!, subject: fileName),
                    icon: const Icon(Icons.share_rounded, size: 18),
                    label: const Text('Share'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _kAccent,
                      foregroundColor: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ],
          if (j.status == _Status.failed || j.status == _Status.cancelled) ...[
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton.icon(
                onPressed: onRetry,
                icon: const Icon(Icons.refresh_rounded, size: 18),
                label: const Text('Retry'),
                style: TextButton.styleFrom(foregroundColor: _kAccent),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

// ── Orbit painter ─────────────────────────────────────────────────────────────

class _UpOrbitPainter extends CustomPainter {
  final Color color;
  final double opacity;
  const _UpOrbitPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r  = (size.width / 2) - 2;
    final paint = Paint()
      ..color = color.withOpacity(opacity)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round;
    const gapRad = math.pi / 3;
    const arcRad = math.pi / 3;
    for (int i = 0; i < 3; i++) {
      canvas.drawArc(
        Rect.fromCircle(center: Offset(cx, cy), radius: r),
        i * (arcRad + gapRad), arcRad, false, paint,
      );
    }
    final dp = Paint()
      ..color = color.withOpacity(opacity * 0.9)
      ..style = PaintingStyle.fill;
    for (int i = 0; i < 3; i++) {
      final a = i * (arcRad + gapRad) + arcRad / 2;
      canvas.drawCircle(
          Offset(cx + r * math.cos(a), cy + r * math.sin(a)), 2.4, dp);
    }
  }

  @override
  bool shouldRepaint(_UpOrbitPainter o) =>
      o.color != color || o.opacity != opacity;
}

// ── Dot painter ───────────────────────────────────────────────────────────────

class _UpDotPainter extends CustomPainter {
  final Color color;
  final double opacity;
  const _UpDotPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r  = (size.width / 2) - 1;
    for (int i = 0; i < 6; i++) {
      final a = i * (math.pi / 3);
      canvas.drawCircle(
        Offset(cx + r * math.cos(a), cy + r * math.sin(a)),
        i % 2 == 0 ? 2.0 : 1.2,
        Paint()
          ..color = color.withOpacity(opacity * (i % 2 == 0 ? 1.0 : 0.5))
          ..style = PaintingStyle.fill,
      );
    }
  }

  @override
  bool shouldRepaint(_UpDotPainter o) =>
      o.color != color || o.opacity != opacity;
}

// ── Header chip ───────────────────────────────────────────────────────────────

class _UpChip extends StatelessWidget {
  final String label;
  const _UpChip(this.label);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: _kAccent.withOpacity(0.10),
        borderRadius: BorderRadius.circular(5),
        border: Border.all(color: _kAccent.withOpacity(0.28)),
      ),
      child: Text(
        label,
        style: const TextStyle(
          color: _kAccent,
          fontSize: 9,
          fontFamily: 'monospace',
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

// ── Live pulse dot ────────────────────────────────────────────────────────────

class _UpLiveDot extends StatefulWidget {
  final Color color;
  const _UpLiveDot({required this.color});

  @override
  State<_UpLiveDot> createState() => _UpLiveDotState();
}

class _UpLiveDotState extends State<_UpLiveDot>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _ring;
  late final Animation<double> _fade;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat();
    _ring = Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
    _fade = Tween<double>(begin: 0.8, end: 0.0).animate(
        CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 16,
      height: 16,
      child: AnimatedBuilder(
        animation: _ctrl,
        builder: (_, __) => Stack(
          alignment: Alignment.center,
          children: [
            Container(
              width: 6 + _ring.value * 10,
              height: 6 + _ring.value * 10,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: widget.color.withOpacity(_fade.value),
                  width: 1.2,
                ),
              ),
            ),
            Container(
              width: 6,
              height: 6,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: widget.color,
                boxShadow: [
                  BoxShadow(
                    color: widget.color.withOpacity(0.5),
                    blurRadius: 5,
                    spreadRadius: 1,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

void unawaited(Future<void> _) {}
