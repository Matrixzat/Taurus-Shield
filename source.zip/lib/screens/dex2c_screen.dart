import '../utils/theme_provider.dart';
import '../widgets/guide_modal.dart';
import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:archive/archive.dart';
import '../utils/hbc_channel.dart';
import '../utils/storage_helper.dart';
import '../utils/permission_helper.dart';

const _kDex2CAccent      = Color(0xFF10b981);
// ignore: unused_element
const _kDex2CAccentLight = Color(0xFF34d399);

class Dex2CScreen extends StatefulWidget {
  const Dex2CScreen({super.key});

  @override
  State<Dex2CScreen> createState() => _Dex2CScreenState();
}

class _Dex2CScreenState extends State<Dex2CScreen>
    with TickerProviderStateMixin {
  String? _selectedFilePath;
  String? _selectedFileName;
  bool    _isProcessing    = false;
  bool    _logVisible      = false;
  String  _logs            = '';
  String? _outputDir;
  int     _downloadProgress = -1;
  bool    _autoScroll      = true;
  String? _zipStatus;
  bool    _zipValid       = false;
  bool    _signApk        = true;
  StreamSubscription<String>? _streamSub;
  final Stopwatch _stopwatch = Stopwatch();
  Timer? _tickTimer;
  String _elapsed = '00:00';
  final ScrollController _logScrollCtrl  = ScrollController();
  final ScrollController _pageScrollCtrl = ScrollController();
  final GlobalKey        _logPanelKey    = GlobalKey();

  late final AnimationController _pulseCtrl;
  late final AnimationController _orbitCtrl;
  late final AnimationController _scanCtrl;
  late final AnimationController _logCtrl;
  late final Animation<double> _pulseAnim;
  late final Animation<double> _logFade;
  late final Animation<double> _scanAnim;

  static const _accent = _kDex2CAccent;

  @override
  void initState() {
    super.initState();

    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _orbitCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 5000),
    )..repeat();

    _scanCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2200),
    )..repeat();

    _logCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 400),
    );

    _pulseAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );

    _logFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _logCtrl, curve: Curves.easeOut),
    );

    _scanAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _scanCtrl, curve: Curves.easeInOut),
    );

    _checkCloudState();
  }

  Timer? _pollTimer;

  Future<void> _checkCloudState() async {
    try {
      final state = await HbcChannel.dex2cCloudState();
      final running = state['running'] == true;
      final status  = (state['status'] as String?) ?? '';
      final logs    = (state['logs'] as String?) ?? '';
      final filePath = (state['filePath'] as String?) ?? '';
      final outputDir = (state['outputDir'] as String?) ?? '';

      if (running && mounted) {
        setState(() {
          _isProcessing = true;
          _logVisible = true;
          _logs = logs;
          _selectedFilePath = filePath.isNotEmpty ? filePath : _selectedFilePath;
          _selectedFileName = filePath.isNotEmpty ? filePath.split('/').last : _selectedFileName;
        });
        _logCtrl.forward(from: 0);
        if (!_stopwatch.isRunning) _startTimer();
        _startPollingCloudState();
      } else if (status == 'success' && mounted) {
        setState(() {
          _isProcessing = false;
          _logVisible = true;
          _logs = logs;
          _outputDir = outputDir.isNotEmpty ? outputDir : null;
          _selectedFilePath = filePath.isNotEmpty ? filePath : _selectedFilePath;
          _selectedFileName = filePath.isNotEmpty ? filePath.split('/').last : _selectedFileName;
        });
        _logCtrl.forward(from: 0);
        _showSnack('Protection complete',
            icon: Icons.check_circle_rounded, color: const Color(0xFF22c55e));
      } else if (status == 'cancelled' && mounted) {
        setState(() {
          _isProcessing = false;
          _logVisible = true;
          _logs = logs;
        });
        _logCtrl.forward(from: 0);
        _showSnack('Protection cancelled',
            icon: Icons.cancel_outlined, color: const Color(0xFFf59e0b));
      } else if (status == 'error' && logs.isNotEmpty && mounted) {
        final error = (state['error'] as String?) ?? 'Protection failed';
        setState(() {
          _isProcessing = false;
          _logVisible = true;
          _logs = logs;
        });
        _logCtrl.forward(from: 0);
        _showSnack(error,
            icon: Icons.error_rounded, color: const Color(0xFFef4444));
      }
    } catch (_) {}
  }

  void _startPollingCloudState() {
    _pollTimer?.cancel();
    _streamSub?.cancel();

    _streamSub = HbcChannel.logStream.listen((line) {
      if (!mounted) return;
      if (line.startsWith('DOWNLOAD_PROGRESS:')) {
        final pct = int.tryParse(line.split(':').last) ?? -1;
        setState(() => _downloadProgress = pct);
        return;
      }
      if (line == '__TAURUS_DONE__') {
        _pollTimer?.cancel();
        _checkCloudState();
        return;
      }
      setState(() {
        _logs += (_logs.isEmpty ? '' : '\n') + line;
      });
      if (_autoScroll) _scrollLogToBottom();
    }, onDone: () {}, onError: (_) {});

    var lastStep = '';
    var consecutiveErrors = 0;
    const maxErrors = 6;

    _pollTimer = Timer.periodic(const Duration(seconds: 25), (_) async {
      if (!mounted) { _pollTimer?.cancel(); return; }
      try {
        final state = await HbcChannel.dex2cCloudState();
        consecutiveErrors = 0;
        final running = state['running'] == true;
        final logs    = (state['logs'] as String?) ?? '';
        final status  = (state['status'] as String?) ?? '';
        final outputDir = (state['outputDir'] as String?) ?? '';
        final currentStep = (state['currentStep'] as String?) ?? '';

        final logsChanged = logs != _logs;
        if (logsChanged && mounted) {
          setState(() { _logs = logs; });
          if (_autoScroll) _scrollLogToBottom();
        }

        if (currentStep.isNotEmpty && currentStep != lastStep) {
            lastStep = currentStep;
        } else if (currentStep.isNotEmpty && currentStep == lastStep) {
          }

        if (!running) {
          _pollTimer?.cancel();
          _streamSub?.cancel();
          final success = status == 'success';
          final cancelled = status == 'cancelled';
          final totalTime = _stopTimer();

          if (mounted) {
            setState(() {
              _isProcessing = false;
              _logs = logs;
              _outputDir = outputDir.isNotEmpty ? outputDir : null;
              _downloadProgress = -1;
              if (cancelled) {
                _logs += '\nCancelled by user.\n';
              } else {
                _logs += '\n${success ? "Completed" : "Failed"} in $totalTime\n';
              }
            });
            if (cancelled) {
              _showSnack('Protection cancelled',
                  icon: Icons.cancel_outlined, color: const Color(0xFFf59e0b));
            } else {
              _showSnack(
                success ? 'Protection complete — $totalTime' : 'Protection failed',
                icon: success ? Icons.check_circle_rounded : Icons.error_rounded,
                color: success ? const Color(0xFF22c55e) : const Color(0xFFef4444),
              );
            }
          }
          return;
        }
      } catch (_) {
        consecutiveErrors++;
        if (consecutiveErrors >= maxErrors && mounted) {
          _pollTimer?.cancel();
          _streamSub?.cancel();
          _stopTimer();
          setState(() {
            _isProcessing = false;
            _downloadProgress = -1;
            _logs += '\nLost connection to protection service after '
                '$maxErrors attempts.\n';
          });
          _showSnack('Connection lost — check service status',
              icon: Icons.error_rounded, color: const Color(0xFFef4444));
        }
      }
    });
  }

  void _scrollLogToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_logScrollCtrl.hasClients) {
        _logScrollCtrl.animateTo(
          _logScrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _streamSub?.cancel();
    _tickTimer?.cancel();
    _pulseCtrl.dispose();
    _orbitCtrl.dispose();
    _scanCtrl.dispose();
    _logCtrl.dispose();
    _logScrollCtrl.dispose();
    _pageScrollCtrl.dispose();
    super.dispose();
  }

  String _formatDuration(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  void _startTimer() {
    _stopwatch.reset();
    _stopwatch.start();
    _tickTimer?.cancel();
    _tickTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _elapsed = _formatDuration(_stopwatch.elapsed));
    });
  }

  String _stopTimer() {
    _stopwatch.stop();
    _tickTimer?.cancel();
    _tickTimer = null;
    final final_ = _formatDuration(_stopwatch.elapsed);
    setState(() => _elapsed = final_);
    return final_;
  }

  ({bool valid, String message}) _validateZipContents(String path) {
    try {
      final bytes = File(path).readAsBytesSync();
      final archive = ZipDecoder().decodeBytes(bytes);
      final names = archive.files
          .where((f) => !f.isFile ? false : true)
          .map((f) => f.name.split('/').last.toLowerCase())
          .toList();

      final apkFiles = names.where((n) => n.endsWith('.apk')).toList();
      final filterFiles = names.where((n) => n == 'filter.txt').toList();

      if (apkFiles.isEmpty) {
        return (valid: false, message: 'ZIP must contain an .apk file');
      }
      if (apkFiles.length > 1) {
        return (valid: false, message: 'ZIP must contain exactly one .apk file (found ${apkFiles.length})');
      }
      if (filterFiles.isEmpty) {
        return (valid: false, message: 'ZIP must contain a filter.txt file');
      }
      if (filterFiles.length > 1) {
        return (valid: false, message: 'ZIP must contain exactly one filter.txt (found ${filterFiles.length})');
      }
      return (valid: true, message: 'Contains ${apkFiles.first} + filter.txt');
    } catch (e) {
      return (valid: false, message: 'Invalid ZIP file: $e');
    }
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['zip'],
    );
    if (result == null || result.files.isEmpty) return;

    final file = result.files.single;
    if (file.path == null) return;

    final validation = _validateZipContents(file.path!);

    setState(() {
      _selectedFilePath = file.path;
      _selectedFileName = file.name;
      _zipStatus = validation.message;
      _zipValid = validation.valid;
      _logs = '';
      _logVisible = false;
      _outputDir = null;
      _downloadProgress = -1;
      _isProcessing = false;
      _stopwatch.reset();
      _tickTimer?.cancel();
      _elapsed = '00:00';
    });

    if (!validation.valid) {
      _showSnack(validation.message,
          icon: Icons.warning_rounded, color: const Color(0xFFf59e0b));
    }

    await HbcChannel.dex2cClearState();
  }

  Future<void> _runProtection() async {
    if (_selectedFilePath == null) {
      _showSnack('Pick a ZIP file first',
          icon: Icons.folder_open_rounded, color: const Color(0xFFf59e0b));
      return;
    }

    if (!_zipValid) {
      _showSnack(_zipStatus ?? 'Invalid ZIP — must contain .apk + filter.txt',
          icon: Icons.warning_rounded, color: const Color(0xFFf59e0b));
      return;
    }

    final hasPermission = await PermissionHelper.ensureStorage(
      context,
      accent: _kDex2CAccent,
    );
    if (!hasPermission) {
      _showSnack('Storage permission is required',
          icon: Icons.lock_rounded, color: const Color(0xFFef4444));
      return;
    }

    final outputDir = await StorageHelper.buildOutputDir(prefix: 'dex2c');

    setState(() {
      _isProcessing     = true;
      _logs             = '';
      _logVisible       = true;
      _downloadProgress = -1;
    });
    _logCtrl.forward(from: 0);
    _scrollToLogPanel();
    _startTimer();

    try {
      final result = await HbcChannel.dex2cAnalyze(
        filePath:  _selectedFilePath!,
        fileName:  _selectedFileName ?? _selectedFilePath!.split('/').last,
        outputDir: outputDir,
        signApk:   _signApk,
      );

      if (result['started'] == true) {
        await Future.delayed(const Duration(seconds: 1));
        _startPollingCloudState();
      } else {
        _stopTimer();
        final errMsg = (result['error'] as String?) ?? 'Failed to start protection';
        if (mounted) {
          setState(() { _isProcessing = false; });
          _showSnack(errMsg,
              icon: Icons.error_rounded, color: const Color(0xFFef4444));
        }
      }
    } catch (e) {
      _stopTimer();
      if (mounted) {
        setState(() {
          _isProcessing     = false;
          _downloadProgress = -1;
          _logs += '\nError: $e\n';
        });
        _showSnack('Error: $e',
            icon: Icons.error_rounded, color: const Color(0xFFef4444));
      }
    }
  }

  void _scrollToLogPanel() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final ctx = _logPanelKey.currentContext;
      if (ctx == null) return;
      Scrollable.ensureVisible(
        ctx,
        duration: const Duration(milliseconds: 480),
        curve: Curves.easeInOut,
        alignment: 0.0,
      );
    });
  }

  void _showSnack(String msg,
      {required IconData icon, required Color color}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(icon, color: Colors.white, size: 18),
        const SizedBox(width: 10),
        Expanded(
            child: Text(msg,
                style: const TextStyle(color: Colors.white, fontSize: 13))),
      ]),
      backgroundColor: color.withOpacity(0.9),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      duration: const Duration(seconds: 3),
    ));
  }

  Future<void> _onBackPressed() async {
    final leave = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF12102a),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: const BorderSide(color: _accent, width: 1),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: _accent.withOpacity(0.12),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.shield_rounded,
                  color: _accent, size: 20),
            ),
            const SizedBox(width: 12),
            const Expanded(
              child: Text(
                'Leave Dex2C?',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w700),
              ),
            ),
          ],
        ),
        content: Text(
          _isProcessing
              ? 'Protection is running in the background.\nYou can return later to see results.'
              : 'Are you sure you want to go back?',
          style: const TextStyle(
              color: Color(0xFFa0a0b8), fontSize: 13, height: 1.6),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Stay',
                style: TextStyle(color: Color(0xFF6b7280))),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: _accent,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8)),
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(_isProcessing ? 'Leave (keeps running)' : 'Leave'),
          ),
        ],
      ),
    );
    if (leave == true && mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _onBackPressed();
      },
      child: Scaffold(
      
      appBar: AppBar(
        centerTitle: true,
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _Dex2CAppBarIcon(animation: _pulseAnim),
            const SizedBox(width: 10),
            const Text('DEX2C'),
            const SizedBox(width: 10),
            _Dex2CAppBarIcon(animation: _pulseAnim, mirrored: true),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.menu_book_rounded, color: Colors.white70, size: 20),
            tooltip: 'How to Use',
            onPressed: () => showGuideModal(context, initialIndex: 3, singleTool: true),
          ),
        ],
        iconTheme: const IconThemeData(color: Colors.white),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [ThemeProvider().current.appBarBg, Color(0xFF0a1a14)],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            color: _accent.withOpacity(0.25),
          ),
        ),
      ),
      body: SingleChildScrollView(
        controller: _pageScrollCtrl,
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _buildHeader(),
            const SizedBox(height: 20),
            _buildFileSelector(),
            if (_selectedFileName != null) ...[
              const SizedBox(height: 12),
              _buildZipInfo(),
            ],
            const SizedBox(height: 14),
            _buildSignToggle(),
            const SizedBox(height: 14),
            _buildActionRow(),
            if (_downloadProgress >= 0) ...[
              const SizedBox(height: 12),
              _buildProgressBar(),
            ],
            if (_logVisible) ...[
              const SizedBox(height: 16),
              _buildLogPanel(),
            ],
            if (_outputDir != null && !_isProcessing) ...[
              const SizedBox(height: 14),
              _buildOutputDir(),
            ],
          ],
        ),
      ),
      ),
    );
  }

  Widget _buildHeader() {
    return AnimatedBuilder(
      animation: Listenable.merge([_pulseAnim, _orbitCtrl, _scanAnim]),
      builder: (_, __) {
        final pulse = _pulseAnim.value;
        return Container(
          padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: RadialGradient(
              center: Alignment.center,
              radius: 1.2,
              colors: [
                _accent.withOpacity(0.06 + 0.04 * pulse),
                ThemeProvider().current.scaffoldBg,
              ],
            ),
            border: Border.all(
                color: _accent.withOpacity(0.10 + 0.08 * pulse)),
          ),
          child: Column(children: [
            SizedBox(
              width: 64,
              height: 64,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Transform.rotate(
                    angle: _orbitCtrl.value * math.pi * 2,
                    child: CustomPaint(
                      size: const Size(64, 64),
                      painter: _Dex2COrbitPainter(
                          color: _accent,
                          opacity: 0.3 + 0.3 * pulse),
                    ),
                  ),
                  Transform.rotate(
                    angle: -_orbitCtrl.value * math.pi * 2 * 0.6,
                    child: CustomPaint(
                      size: const Size(40, 40),
                      painter: _Dex2CDotPainter(
                          color: _accent,
                          opacity: 0.4 + 0.3 * pulse),
                    ),
                  ),
                  Icon(Icons.shield_rounded,
                      color: _accent.withOpacity(0.7 + 0.3 * pulse),
                      size: 24),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _HeaderChip('DEX to Native'),
                const SizedBox(width: 8),
                _HeaderChip('APK Protection'),
              ],
            ),
          ]),
        );
      },
    );
  }

  Widget _buildFileSelector() {
    final hasFile = _selectedFileName != null;
    return GestureDetector(
      onTap: _isProcessing ? null : _pickFile,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: Color(0xFF111122),
          border: Border.all(
            color: hasFile
                ? _accent.withOpacity(0.30)
                : ThemeProvider().current.surfaceColor,
          ),
        ),
        child: Row(children: [
          Icon(
            hasFile ? Icons.archive_rounded : Icons.upload_file_rounded,
            color: hasFile ? _accent : const Color(0xFF4b5563),
            size: 28,
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  hasFile ? _selectedFileName! : 'Select ZIP file',
                  style: TextStyle(
                    color: hasFile ? Colors.white : const Color(0xFF6b7280),
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
                if (hasFile && _selectedFilePath != null)
                  Text(
                    _selectedFilePath!,
                    style: const TextStyle(
                        color: Color(0xFF4b5563), fontSize: 10),
                    overflow: TextOverflow.ellipsis,
                  ),
                if (!hasFile)
                  const Text(
                    'ZIP must contain: .apk + filter.txt',
                    style: TextStyle(
                        color: Color(0xFF4b5563), fontSize: 10),
                  ),
              ],
            ),
          ),
          if (hasFile)
            GestureDetector(
              onTap: _isProcessing
                  ? null
                  : () {
                      setState(() {
                        _selectedFilePath = null;
                        _selectedFileName = null;
                        _zipStatus = null;
                        _logs = '';
                        _logVisible = false;
                        _outputDir = null;
                      });
                    },
              child: Icon(Icons.close_rounded,
                  color: const Color(0xFF6b7280).withOpacity(0.6), size: 20),
            ),
        ]),
      ),
    );
  }

  Widget _buildZipInfo() {
    final statusColor = _zipValid
        ? const Color(0xFF22c55e)
        : const Color(0xFFf59e0b);
    final statusIcon = _zipValid
        ? Icons.check_circle_rounded
        : Icons.warning_rounded;
    final statusText = _zipStatus ??
        'ZIP should contain your .apk and filter.txt';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: statusColor.withOpacity(0.06),
        border: Border.all(color: statusColor.withOpacity(0.15)),
      ),
      child: Row(children: [
        Icon(statusIcon, color: statusColor, size: 16),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            statusText,
            style: TextStyle(
              color: statusColor,
              fontSize: 11,
              height: 1.4,
            ),
          ),
        ),
      ]),
    );
  }

  Widget _buildSignToggle() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: ThemeProvider().current.surfaceColor,
        border: Border.all(
          color: _signApk
              ? _accent.withOpacity(0.25)
              : const Color(0xFF2a2a3e),
        ),
      ),
      child: Row(
        children: [
          Icon(
            _signApk ? Icons.verified_rounded : Icons.shield_outlined,
            color: _signApk ? _accent : const Color(0xFF6b7280),
            size: 18,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Sign APK',
                  style: TextStyle(
                    color: _signApk ? Colors.white : const Color(0xFF9ca3af),
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                  ),
                ),
                Text(
                  _signApk
                      ? 'APK will be signed with a debug key'
                      : 'APK will be returned unsigned',
                  style: TextStyle(
                    color: _signApk
                        ? _accent.withOpacity(0.7)
                        : const Color(0xFF6b7280),
                    fontSize: 10,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 28,
            child: Switch(
              value: _signApk,
              onChanged: _isProcessing
                  ? null
                  : (v) => setState(() => _signApk = v),
              activeColor: _accent,
              activeTrackColor: _accent.withOpacity(0.3),
              inactiveThumbColor: const Color(0xFF4b5563),
              inactiveTrackColor: const Color(0xFF1f2937),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _cancelProtection() async {
    _pollTimer?.cancel();
    _tickTimer?.cancel();
    await HbcChannel.dex2cCancel();
    if (!mounted) return;
    setState(() { _isProcessing = false; });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Operation cancelled'),
        backgroundColor: Color(0xFF7f1d1d),
        duration: Duration(seconds: 3),
      ),
    );
  }

  Widget _buildActionRow() {
    final hasFile = _selectedFileName != null;
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: GestureDetector(
                onTap: (_isProcessing || !hasFile || !_zipValid) ? null : _runProtection,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    gradient: (_isProcessing || !hasFile || !_zipValid)
                        ? null
                        : const LinearGradient(
                            colors: [_accent, Color(0xFF059669)],
                          ),
                    color: (_isProcessing || !hasFile || !_zipValid)
                        ? const Color(0xFF1a1a2e)
                        : null,
                    border: Border.all(
                      color: _isProcessing
                          ? _accent.withOpacity(0.3)
                          : (!hasFile || !_zipValid)
                              ? const Color(0xFF2a2a3e)
                              : Colors.transparent,
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (_isProcessing) ...[
                        const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: _accent),
                        ),
                        const SizedBox(width: 10),
                      ],
                      Text(
                        _isProcessing ? 'Protecting...' : 'Protect  (Dex2C)',
                        style: TextStyle(
                          color: (_isProcessing || !hasFile || !_zipValid)
                              ? const Color(0xFF6b7280)
                              : Colors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
        if (_isProcessing) ...[
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: GestureDetector(
              onTap: _cancelProtection,
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: const Color(0xFF1a1a2e),
                  border: Border.all(color: Color(0xFFef4444).withOpacity(0.5)),
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.cancel_outlined, color: Color(0xFFef4444), size: 16),
                    SizedBox(width: 8),
                    Text(
                      'Cancel',
                      style: TextStyle(
                        color: Color(0xFFef4444),
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildProgressBar() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: LinearProgressIndicator(
            value: _downloadProgress / 100.0,
            backgroundColor: const Color(0xFF1a1a2e),
            color: _accent,
            minHeight: 4,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          '$_downloadProgress%',
          style: const TextStyle(
              color: Color(0xFF6b7280), fontSize: 10, fontFamily: 'monospace'),
        ),
      ],
    );
  }

  Widget _buildOutputDir() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: const Color(0xFF22c55e).withOpacity(0.06),
        border:
            Border.all(color: const Color(0xFF22c55e).withOpacity(0.25)),
      ),
      child: Row(children: [
        const Icon(Icons.folder_rounded,
            color: Color(0xFF22c55e), size: 18),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Output saved to:',
                  style: TextStyle(
                      color: Color(0xFF22c55e),
                      fontSize: 11,
                      fontWeight: FontWeight.w600)),
              const SizedBox(height: 2),
              Text(
                _outputDir ?? '',
                style: const TextStyle(
                    color: Color(0xFF4ade80),
                    fontSize: 10,
                    fontFamily: 'monospace'),
              ),
            ],
          ),
        ),
      ]),
    );
  }

  Widget _buildLogPanel() {
    return FadeTransition(
      key: _logPanelKey,
      opacity: _logFade,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: const Color(0xFF0d0d1a),
          border: Border.all(
              color: _accent.withOpacity(0.12)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: _accent.withOpacity(0.08),
                borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(14)),
              ),
              child: Row(
                children: [
                  _isProcessing
                      ? AnimatedBuilder(
                          animation: _orbitCtrl,
                          builder: (_, __) => Transform.rotate(
                            angle: _orbitCtrl.value * 6.28,
                            child: const Icon(Icons.settings_rounded,
                                color: _accent, size: 16),
                          ),
                        )
                      : const Icon(Icons.terminal_rounded,
                          color: _accent, size: 16),
                  const SizedBox(width: 8),
                  Text(
                    _isProcessing ? 'Processing...' : 'Live Output',
                    style: const TextStyle(
                      color: _accent,
                      fontWeight: FontWeight.w700,
                      fontSize: 13,
                      letterSpacing: 0.5,
                    ),
                  ),
                  const Spacer(),
                  GestureDetector(
                    onTap: () =>
                        setState(() => _autoScroll = !_autoScroll),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: _autoScroll
                            ? const Color(0xFF22c55e).withOpacity(0.15)
                            : const Color(0xFF374151).withOpacity(0.4),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(
                          color: _autoScroll
                              ? const Color(0xFF22c55e).withOpacity(0.5)
                              : const Color(0xFF374151),
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            _autoScroll
                                ? Icons.vertical_align_bottom_rounded
                                : Icons.vertical_align_center_rounded,
                            color: _autoScroll
                                ? const Color(0xFF22c55e)
                                : const Color(0xFF6b7280),
                            size: 13,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            'Auto-scroll',
                            style: TextStyle(
                              color: _autoScroll
                                  ? const Color(0xFF22c55e)
                                  : const Color(0xFF6b7280),
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: () {
                      if (_logs.isEmpty) {
                        _showSnack('No logs to copy',
                            icon: Icons.info_rounded,
                            color: const Color(0xFF6b7280));
                        return;
                      }
                      Clipboard.setData(ClipboardData(text: _logs));
                      _showSnack('Logs copied',
                          icon: Icons.check_rounded,
                          color: _accent);
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: _accent.withOpacity(0.10),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(
                            color: _accent.withOpacity(0.25)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.copy_rounded,
                              color: _accent, size: 13),
                          const SizedBox(width: 4),
                          Text('Copy',
                              style: TextStyle(
                                  color: _accent,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w600)),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: () {
                      if (_logs.isEmpty || _isProcessing) return;
                      _pollTimer?.cancel();
                      _streamSub?.cancel();
                      _stopwatch.stop();
                      _stopwatch.reset();
                      _tickTimer?.cancel();
                      setState(() {
                        _logs             = '';
                        _isProcessing     = false;
                        _logVisible       = false;
                        _outputDir        = null;
                        _downloadProgress = -1;
                        _elapsed          = '00:00';
                      });
                      HbcChannel.dex2cClearState();
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 4),
                      decoration: BoxDecoration(
                        color: const Color(0xFFef4444).withOpacity(0.08),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(
                            color:
                                const Color(0xFFef4444).withOpacity(0.35)),
                      ),
                      child: const Icon(
                        Icons.delete_outline_rounded,
                        color: Color(0xFFf87171),
                        size: 14,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 360,
              margin: const EdgeInsets.fromLTRB(14, 10, 14, 0),
              child: Scrollbar(
                controller: _logScrollCtrl,
                thumbVisibility: true,
                child: SingleChildScrollView(
                  controller: _logScrollCtrl,
                  padding: const EdgeInsets.only(right: 8),
                  child: Text(
                    _logs.isEmpty
                        ? (_isProcessing
                            ? 'Preparing protection pipeline...'
                            : 'Waiting for output...')
                        : _logs,
                    style: TextStyle(
                      fontFamily: 'monospace',
                      fontSize: 11,
                      color: _logs.isEmpty
                          ? const Color(0xFF4b5563)
                          : const Color(0xFFd4d4d4),
                      height: 1.7,
                    ),
                  ),
                ),
              ),
            ),
            if (_stopwatch.elapsedMilliseconds > 0)
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: const Color(0xFF0a0a14),
                  borderRadius: const BorderRadius.vertical(
                      bottom: Radius.circular(14)),
                  border: Border(
                    top: BorderSide(
                        color: Colors.white.withOpacity(0.06)),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      _isProcessing
                          ? Icons.timer_outlined
                          : Icons.check_circle_outline_rounded,
                      color: Colors.white.withOpacity(0.7),
                      size: 14,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      _isProcessing
                          ? 'Elapsed  $_elapsed'
                          : 'Completed in $_elapsed',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.7),
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'monospace',
                      ),
                    ),
                  ],
                ),
              )
            else
              const SizedBox(height: 10),
          ],
        ),
      ),
    );
  }
}

class _HeaderChip extends StatelessWidget {
  final String label;
  const _HeaderChip(this.label);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: _kDex2CAccent.withOpacity(0.08),
        borderRadius: BorderRadius.circular(5),
        border: Border.all(color: _kDex2CAccent.withOpacity(0.22)),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: _kDex2CAccent,
          fontSize: 10,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.5,
        ),
      ),
    );
  }
}

class _Dex2COrbitPainter extends CustomPainter {
  final Color color;
  final double opacity;
  const _Dex2COrbitPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r  = (size.width / 2) - 2;
    final paint = Paint()
      ..color = color.withOpacity(opacity)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round;
    const gapRad = math.pi / 3;
    const arcRad = math.pi / 3;
    for (int i = 0; i < 3; i++) {
      canvas.drawArc(
        Rect.fromCircle(center: Offset(cx, cy), radius: r),
        i * (arcRad + gapRad), arcRad, false, paint,
      );
    }
    final dp = Paint()
      ..color = color.withOpacity(opacity * 0.9)
      ..style = PaintingStyle.fill;
    for (int i = 0; i < 3; i++) {
      final a = i * (arcRad + gapRad) + arcRad / 2;
      canvas.drawCircle(
          Offset(cx + r * math.cos(a), cy + r * math.sin(a)), 2.4, dp);
    }
  }

  @override
  bool shouldRepaint(_Dex2COrbitPainter o) =>
      o.color != color || o.opacity != opacity;
}

class _Dex2CDotPainter extends CustomPainter {
  final Color color;
  final double opacity;
  const _Dex2CDotPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r  = (size.width / 2) - 1;
    for (int i = 0; i < 6; i++) {
      final a = i * (math.pi / 3);
      canvas.drawCircle(
        Offset(cx + r * math.cos(a), cy + r * math.sin(a)),
        i % 2 == 0 ? 2.0 : 1.2,
        Paint()
          ..color = color.withOpacity(opacity * (i % 2 == 0 ? 1.0 : 0.5))
          ..style = PaintingStyle.fill,
      );
    }
  }

  @override
  bool shouldRepaint(_Dex2CDotPainter o) =>
      o.color != color || o.opacity != opacity;
}

class _Dex2CAppBarIcon extends StatelessWidget {
  final Animation<double> animation;
  final bool mirrored;
  const _Dex2CAppBarIcon({required this.animation, this.mirrored = false});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: animation,
      builder: (_, __) {
        return Transform.scale(
          scaleX: mirrored ? -1 : 1,
          child: CustomPaint(
            size: const Size(20, 22),
            painter: _Dex2CIconPainter(phase: animation.value),
          ),
        );
      },
    );
  }
}

class _Dex2CIconPainter extends CustomPainter {
  final double phase;
  const _Dex2CIconPainter({required this.phase});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    const green = _kDex2CAccent;

    final shieldPath = Path()
      ..moveTo(w * 0.5, 0)
      ..lineTo(w, h * 0.18)
      ..lineTo(w, h * 0.52)
      ..quadraticBezierTo(w, h * 0.82, w * 0.5, h)
      ..quadraticBezierTo(0, h * 0.82, 0, h * 0.52)
      ..lineTo(0, h * 0.18)
      ..close();

    final glow = 0.12 + 0.10 * math.sin(phase * math.pi * 2);
    canvas.drawPath(
      shieldPath,
      Paint()
        ..shader = LinearGradient(
          colors: [
            green.withOpacity(glow + 0.05),
            green.withOpacity(glow * 0.5),
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ).createShader(Rect.fromLTWH(0, 0, w, h))
        ..style = PaintingStyle.fill,
    );

    final strokeOpacity = 0.5 + 0.3 * math.sin(phase * math.pi * 2);
    canvas.drawPath(
      shieldPath,
      Paint()
        ..color = green.withOpacity(strokeOpacity)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4
        ..strokeJoin = StrokeJoin.round,
    );

    final scanY = h * 0.25 + h * 0.5 * phase;
    canvas.drawLine(
        Offset(w * 0.2, scanY), Offset(w * 0.8, scanY),
        Paint()
          ..color = green.withOpacity(0.35)
          ..strokeWidth = 1.2
          ..style = PaintingStyle.stroke);

    final positions = [
      Offset(w * 0.35, h * 0.32),
      Offset(w * 0.65, h * 0.32),
      Offset(w * 0.5, h * 0.50),
      Offset(w * 0.35, h * 0.68),
      Offset(w * 0.65, h * 0.68),
    ];
    for (int i = 0; i < positions.length; i++) {
      final pulse = 0.5 + 0.5 * math.sin(phase * math.pi * 2 + i * 1.2);
      canvas.drawCircle(
        positions[i],
        1.4 + 0.6 * pulse,
        Paint()
          ..color = green.withOpacity(0.4 + 0.4 * pulse)
          ..style = PaintingStyle.fill,
      );
    }
  }

  @override
  bool shouldRepaint(_Dex2CIconPainter o) => o.phase != phase;
}
