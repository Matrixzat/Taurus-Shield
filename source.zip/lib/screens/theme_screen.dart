import 'package:flutter/material.dart';
import '../utils/theme_provider.dart';

class ThemeScreen extends StatefulWidget {
  const ThemeScreen({super.key});

  @override
  State<ThemeScreen> createState() => _ThemeScreenState();
}

class _ThemeScreenState extends State<ThemeScreen>
    with TickerProviderStateMixin {
  late final AnimationController _pulseCtrl;
  late final AnimationController _rotateCtrl;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat(reverse: true);
    _rotateCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    )..repeat();
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _rotateCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final provider = ThemeProvider();

    return ListenableBuilder(
      listenable: provider,
      builder: (context, _) {
        final activeId = provider.currentId;
        final appTheme = provider.current;

        return Scaffold(
          appBar: AppBar(title: const Text('Themes')),
          body: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [appTheme.scaffoldBg, appTheme.surfaceColor],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: ThemeProvider.allThemes.length,
              itemBuilder: (context, i) {
                final t = ThemeProvider.allThemes[i];
                final selected = t.id == activeId;

                return Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Material(
                    color: Colors.transparent,
                    borderRadius: BorderRadius.circular(16),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: () => provider.setTheme(t.id),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          color: t.surfaceColor,
                          border: Border.all(
                            color: selected ? t.primary : t.borderColor,
                            width: selected ? 2 : 1,
                          ),
                          boxShadow: selected
                              ? [
                                  BoxShadow(
                                    color: t.primary.withOpacity(0.3),
                                    blurRadius: 12,
                                    spreadRadius: 1,
                                  ),
                                ]
                              : null,
                        ),
                        child: Row(
                          children: [
                            _ThemeIconBox(
                              theme: t,
                              selected: selected,
                              pulseCtrl: _pulseCtrl,
                              rotateCtrl: _rotateCtrl,
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    t.name,
                                    style: TextStyle(
                                      color: t.textColor,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  Row(
                                    children: [
                                      _colorDot(t.primary),
                                      _colorDot(t.secondary),
                                      _colorDot(t.highlightColor),
                                      _colorDot(t.scaffoldBg),
                                      _colorDot(t.surfaceColor),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            if (selected)
                              Container(
                                width: 28,
                                height: 28,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: t.primary,
                                ),
                                child: const Icon(
                                  Icons.check_rounded,
                                  color: Colors.white,
                                  size: 18,
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        );
      },
    );
  }

  static Widget _colorDot(Color c) {
    return Container(
      width: 18,
      height: 18,
      margin: const EdgeInsets.only(right: 6),
      decoration: BoxDecoration(
        color: c,
        shape: BoxShape.circle,
        border: Border.all(color: Colors.white24, width: 1),
      ),
    );
  }
}

class _ThemeIconBox extends StatelessWidget {
  final AppThemeData theme;
  final bool selected;
  final AnimationController pulseCtrl;
  final AnimationController rotateCtrl;

  const _ThemeIconBox({
    required this.theme,
    required this.selected,
    required this.pulseCtrl,
    required this.rotateCtrl,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: selected ? Listenable.merge([pulseCtrl, rotateCtrl]) : pulseCtrl,
      builder: (_, __) {
        final pulse = pulseCtrl.value;
        final rotate = selected ? rotateCtrl.value * 6.283185 : 0.0;
        final scale = selected ? 1.0 + pulse * 0.08 : 1.0;

        return Transform.scale(
          scale: scale,
          child: Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              gradient: LinearGradient(
                colors: [theme.headerBg1, theme.headerBg2],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              border: Border.all(
                color: selected
                    ? Color.lerp(theme.primary, theme.highlightColor, pulse)!
                    : theme.primary.withOpacity(0.4),
                width: selected ? 1.8 : 1,
              ),
              boxShadow: selected
                  ? [
                      BoxShadow(
                        color: theme.primary.withOpacity(0.15 + pulse * 0.15),
                        blurRadius: 14,
                        spreadRadius: 1,
                      ),
                    ]
                  : null,
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                if (selected)
                  Transform.rotate(
                    angle: rotate,
                    child: Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: theme.highlightColor.withOpacity(0.15 + pulse * 0.1),
                          width: 1,
                        ),
                      ),
                    ),
                  ),
                Icon(
                  theme.icon,
                  size: 24,
                  color: selected
                      ? Color.lerp(theme.primary, theme.highlightColor, pulse)
                      : theme.primary,
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
