import '../utils/theme_provider.dart';
import '../widgets/guide_modal.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../utils/hbc_channel.dart';
import '../utils/storage_helper.dart';
import '../utils/permission_helper.dart';

const _kGreen      = Color(0xFF16a34a);
const _kGreenLight = Color(0xFF4ade80);

class PineHookScreen extends StatefulWidget {
  const PineHookScreen({super.key});
  @override
  State<PineHookScreen> createState() => _PineHookScreenState();
}

class _PineHookScreenState extends State<PineHookScreen>
    with TickerProviderStateMixin {

  // ── Tabs ─────────────────────────────────────────────────────────────────
  late final TabController _tabCtrl;

  // ── Injection tab state ───────────────────────────────────────────────────
  String? _filePath;
  String? _fileName;
  bool    _isProcessing = false;
  bool    _logVisible   = false;
  String  _logs         = '';
  String? _outputDir;
  bool    _autoScroll   = true;
  StreamSubscription<String>? _streamSub;
  Timer?  _pollTimer;
  final Stopwatch _stopwatch = Stopwatch();
  Timer?  _tickTimer;
  String  _elapsed = '00:00';

  final ScrollController _logScrollCtrl  = ScrollController();
  final ScrollController _pageScrollCtrl = ScrollController();

  late final AnimationController _pulseCtrl;
  late final AnimationController _logCtrl;
  late final Animation<double>   _pulseAnim;
  late final Animation<double>   _logFade;

  // ── Modules tab state ─────────────────────────────────────────────────────
  List<String> _modules       = [];
  static const _kPrefModules  = 'pinehook_modules';

  // ── Init / dispose ────────────────────────────────────────────────────────

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);

    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _logCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 400),
    );

    _pulseAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
    _logFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _logCtrl, curve: Curves.easeOut),
    );

    _loadModules();
    _checkState();
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    _pulseCtrl.dispose();
    _logCtrl.dispose();
    _pollTimer?.cancel();
    _tickTimer?.cancel();
    _streamSub?.cancel();
    _logScrollCtrl.dispose();
    _pageScrollCtrl.dispose();
    super.dispose();
  }

  // ── Modules persistence ───────────────────────────────────────────────────

  Future<void> _loadModules() async {
    final prefs = await SharedPreferences.getInstance();
    final raw   = prefs.getStringList(_kPrefModules) ?? [];
    final valid = raw.where((p) => File(p).existsSync()).toList();
    if (valid.length != raw.length) {
      await prefs.setStringList(_kPrefModules, valid);
    }
    if (mounted) setState(() { _modules = valid; });
  }

  Future<void> _saveModules() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_kPrefModules, _modules);
  }

  Future<void> _addModule() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['apk'],
      dialogTitle: 'Select Xposed Module APK',
    );
    if (result == null || result.files.single.path == null) return;
    final path = result.files.single.path!;
    if (_modules.contains(path)) {
      _showSnack('Module already added', icon: Icons.info_rounded, color: _kGreen);
      return;
    }
    setState(() => _modules.add(path));
    await _saveModules();
    _showSnack('Module added', icon: Icons.check_circle_rounded, color: _kGreen);
  }

  Future<void> _removeModule(int index) async {
    setState(() => _modules.removeAt(index));
    await _saveModules();
  }

  // ── State restore ─────────────────────────────────────────────────────────

  Future<void> _checkState() async {
    try {
      final state     = await HbcChannel.pineHookState();
      final running   = state['running'] == true;
      final status    = (state['status'] as String?) ?? '';
      final logs      = (state['logs']   as String?) ?? '';
      final filePath  = (state['filePath']  as String?) ?? '';
      final outputDir = (state['outputDir'] as String?) ?? '';

      if (running && mounted) {
        setState(() {
          _isProcessing     = true;
          _logVisible       = true;
          _logs             = logs;
          _filePath         = filePath.isNotEmpty ? filePath : _filePath;
          _fileName         = filePath.isNotEmpty ? filePath.split('/').last : _fileName;
        });
        _logCtrl.forward(from: 0);
        if (!_stopwatch.isRunning) _startTimer();
        _startPolling();
      } else if (status == 'success' && mounted) {
        setState(() {
          _isProcessing = false;
          _logVisible   = true;
          _logs         = logs;
          _outputDir    = outputDir.isNotEmpty ? outputDir : null;
        });
        _logCtrl.forward(from: 0);
        _showSnack('Injection complete', icon: Icons.check_circle_rounded, color: _kGreen);
      } else if (status == 'cancelled' && mounted) {
        setState(() { _isProcessing = false; _logVisible = true; _logs = logs; });
        _logCtrl.forward(from: 0);
        _showSnack('Cancelled', icon: Icons.cancel_outlined, color: const Color(0xFFf59e0b));
      } else if (status == 'error' && logs.isNotEmpty && mounted) {
        final error = (state['error'] as String?) ?? 'Injection failed';
        setState(() { _isProcessing = false; _logVisible = true; _logs = logs; });
        _logCtrl.forward(from: 0);
        _showSnack(error, icon: Icons.error_rounded, color: _kGreen);
      }
    } catch (_) {}
  }

  // ── Polling ───────────────────────────────────────────────────────────────

  void _startPolling() {
    _pollTimer?.cancel();
    _streamSub?.cancel();

    _streamSub = HbcChannel.logStream.listen((line) {
      if (!mounted) return;
      if (line == '__TAURUS_DONE__') {
        _pollTimer?.cancel();
        _checkState();
        return;
      }
      setState(() { _logs += '$line\n'; });
      if (_autoScroll) _scrollLogToBottom();
    });

    _pollTimer = Timer.periodic(const Duration(seconds: 8), (_) async {
      try {
        final state   = await HbcChannel.pineHookState();
        final running = state['running'] == true;
        final status  = (state['status'] as String?) ?? '';
        final logs    = (state['logs']   as String?) ?? '';
        final outDir  = (state['outputDir'] as String?) ?? '';
        if (logs.isNotEmpty && mounted) {
          setState(() { _logs = logs; });
          if (_autoScroll) _scrollLogToBottom();
        }

        if (!running) {
          _pollTimer?.cancel();
          _streamSub?.cancel();
          final success   = status == 'success';
          final cancelled = status == 'cancelled';
          final totalTime = _stopTimer();

          if (mounted) {
            setState(() {
              _isProcessing = false;
              _outputDir    = success && outDir.isNotEmpty ? outDir : _outputDir;
            });
            if (success) {
              _showSnack('Injection done in $totalTime',
                  icon: Icons.check_circle_rounded, color: _kGreen);
            } else if (cancelled) {
              _showSnack('Cancelled',
                  icon: Icons.cancel_outlined, color: const Color(0xFFf59e0b));
            } else {
              final err = (state['error'] as String?) ?? 'Injection failed';
              _showSnack(err, icon: Icons.error_rounded, color: _kGreen);
            }
          }
        }
      } catch (_) {}
    });
  }

  // ── Timer helpers ─────────────────────────────────────────────────────────

  void _startTimer() {
    _stopwatch.reset();
    _stopwatch.start();
    _tickTimer?.cancel();
    _tickTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      final s = _stopwatch.elapsed;
      setState(() {
        _elapsed = '${s.inMinutes.toString().padLeft(2, '0')}:'
            '${(s.inSeconds % 60).toString().padLeft(2, '0')}';
      });
    });
  }

  String _stopTimer() {
    _stopwatch.stop();
    _tickTimer?.cancel();
    final s = _stopwatch.elapsed;
    return '${s.inMinutes}m ${s.inSeconds % 60}s';
  }

  // ── File picking ──────────────────────────────────────────────────────────

  Future<void> _pickFile() async {
    if (!await PermissionHelper.ensureStorage(context, accent: _kGreen)) return;

    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['apk'],
      dialogTitle: 'Select APK to Inject',
    );
    if (result == null || result.files.single.path == null) return;

    final path = result.files.single.path!;
    final name = result.files.single.name;
    final ext  = name.split('.').last.toLowerCase();

    if (ext != 'apk') {
      _showSnack(
        'Unsupported format. Pick an .apk file.',
        icon: Icons.error_rounded,
        color: const Color(0xFFef4444),
      );
      return;
    }

    setState(() { _filePath = path; _fileName = name; });
  }

  // ── Injection ─────────────────────────────────────────────────────────────

  Future<void> _startInject() async {
    if (_filePath == null) return;
    if (!await PermissionHelper.ensureStorage(context, accent: _kGreen)) return;

    final outDir = await StorageHelper.buildOutputDir(prefix: 'PineHook');

    setState(() {
      _isProcessing = true;
      _logVisible   = true;
      _logs         = '';
      _outputDir    = null;
    });
    _logCtrl.forward(from: 0);
    _startTimer();

    try {
      final modulesJson = jsonEncode(_modules);
      final res = await HbcChannel.pineHookInject(
        filePath:    _filePath!,
        fileName:    _fileName ?? _filePath!.split('/').last,
        outputDir:   outDir,
        modulesJson: modulesJson,
      );
      final started = res['started'] == true || res['success'] == true;
      if (!started) {
        final err = (res['error'] as String?) ?? 'Could not start injection';
        setState(() { _isProcessing = false; });
        _stopTimer();
        _showSnack(err, icon: Icons.error_rounded, color: _kGreen);
        return;
      }
      _startPolling();
    } catch (e) {
      setState(() { _isProcessing = false; });
      _stopTimer();
      _showSnack(e.toString(), icon: Icons.error_rounded, color: _kGreen);
    }
  }

  Future<void> _cancel() async {
    await HbcChannel.pineHookCancel();
    setState(() { _isProcessing = false; });
    _stopTimer();
    _pollTimer?.cancel();
    _streamSub?.cancel();
    _showSnack('Cancelling...', icon: Icons.cancel_outlined, color: const Color(0xFFf59e0b));
  }

  Future<void> _clearState() async {
    await HbcChannel.pineHookClearState();
    setState(() {
      _logs       = '';
      _logVisible = false;
      _outputDir  = null;
      _isProcessing = false;
      _elapsed    = '00:00';
    });
    _logCtrl.reverse();
  }

  Future<void> _reset() async {
    if (_isProcessing) {
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
          backgroundColor: const Color(0xFF1A1A2E),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          title: const Text('Cancel & Reset?',
              style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w600)),
          content: const Text(
            'Injection is still running. This will cancel it and clear all state.',
            style: TextStyle(color: Colors.white60, fontSize: 13),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Keep Running', style: TextStyle(color: Colors.white54)),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Reset', style: TextStyle(color: Color(0xFFFF3B30))),
            ),
          ],
        ),
      );
      if (confirmed != true) return;
      await _cancel();
    }
    await _clearState();
    setState(() {
      _filePath = null;
      _fileName = null;
    });
    _showSnack('Reset complete', icon: Icons.refresh_rounded, color: _kGreen);
  }

  // ── Scroll helper ─────────────────────────────────────────────────────────

  void _scrollLogToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_logScrollCtrl.hasClients) {
        _logScrollCtrl.animateTo(
          _logScrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  // ── Snack helper ──────────────────────────────────────────────────────────

  void _showSnack(String msg, {required IconData icon, required Color color}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(icon, color: color, size: 18),
            const SizedBox(width: 10),
            Expanded(child: Text(msg, style: const TextStyle(fontSize: 13))),
          ],
        ),
        backgroundColor: const Color(0xFF1e1e2e),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
            side: BorderSide(color: color.withOpacity(0.3))),
        duration: const Duration(seconds: 4),
      ),
    );
  }

  // ── Build ─────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final surface = isDark ? const Color(0xFF12121C) : const Color(0xFFF5F5F5);
    final card    = isDark ? const Color(0xFF1A1A2E) : Colors.white;

    return Scaffold(
      backgroundColor: surface,
      appBar: AppBar(
        backgroundColor: isDark ? const Color(0xFF0F0F1A) : Colors.white,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedBuilder(
              animation: _pulseAnim,
              builder: (_, __) => Icon(
                Icons.webhook_rounded,
                color: Color.lerp(_kGreen, _kGreenLight, _pulseAnim.value),
                size: 20,
              ),
            ),
            const SizedBox(width: 8),
            const Text(
              'Pine Hook Injector',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600, letterSpacing: 0.2),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'How to Use',
            icon: const Icon(Icons.menu_book_rounded, size: 20),
            onPressed: () => showGuideModal(context, initialIndex: 0, singleTool: true),
          ),
          IconButton(
            tooltip: 'Reset',
            icon: const Icon(Icons.restart_alt_rounded, size: 22),
            onPressed: _reset,
          ),
          const SizedBox(width: 4),
        ],
        bottom: TabBar(
          controller: _tabCtrl,
          indicatorColor: _kGreen,
          indicatorWeight: 2,
          labelColor: _kGreen,
          unselectedLabelColor: isDark ? Colors.white54 : Colors.black45,
          labelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
          tabs: [
            const Tab(text: 'INJECTION'),
            Tab(
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('MODULES'),
                  if (_modules.isNotEmpty) ...[
                    const SizedBox(width: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                      decoration: BoxDecoration(
                        color: _kGreen,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        '${_modules.length}',
                        style: const TextStyle(
                          color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabCtrl,
        children: [
          _buildInjectionTab(isDark, card),
          _buildModulesTab(isDark, card),
        ],
      ),
    );
  }

  // ── Injection tab ─────────────────────────────────────────────────────────

  Widget _buildInjectionTab(bool isDark, Color card) {
    return SingleChildScrollView(
      controller: _pageScrollCtrl,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // About card
          _Card(
            color: card,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: _kGreen.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(Icons.webhook_rounded, color: _kGreen, size: 20),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Pine Hook Injector',
                            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
                          ),
                          Text(
                            'Hook · No root · Instant',
                            style: TextStyle(
                              fontSize: 12,
                              color: isDark ? Colors.white54 : Colors.black45,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: _kGreen.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: _kGreen.withOpacity(0.4)),
                      ),
                      child: const Text(
                        'ACTIVE',
                        style: TextStyle(
                          color: _kGreen, fontSize: 11, fontWeight: FontWeight.bold,
                          letterSpacing: 0.8,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                const Divider(height: 1),
                const SizedBox(height: 10),
                const Text(
                  'Embeds the Pine hooking framework and Xposed modules directly into an APK — no root, no setup. Output is clean and unsigned — sign and install to activate.',
                  style: TextStyle(fontSize: 13, height: 1.5),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 6, runSpacing: 6,
                  children: const ['apk', 'xposed']
                      .map((c) => _Chip(label: c, color: _kGreen))
                      .toList(),
                ),
              ],
            ),
          ),

          const SizedBox(height: 12),

          // File picker
          _Card(
            color: card,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Target APK',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: isDark ? Colors.white54 : Colors.black45,
                    letterSpacing: 0.4,
                  ),
                ),
                const SizedBox(height: 10),
                InkWell(
                  onTap: _isProcessing ? null : _pickFile,
                  borderRadius: BorderRadius.circular(10),
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: _kGreen.withOpacity(0.07),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: _filePath != null
                            ? _kGreen.withOpacity(0.5)
                            : (isDark ? Colors.white12 : Colors.black12),
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          _filePath != null
                              ? Icons.android_rounded
                              : Icons.file_open_rounded,
                          color: _filePath != null ? _kGreen : Colors.grey,
                          size: 22,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                _fileName ?? 'Tap to select APK',
                                style: TextStyle(
                                  fontWeight: _filePath != null ? FontWeight.w600 : FontWeight.normal,
                                  fontSize: 13,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                              if (_filePath != null)
                                Text(
                                  _filePath!,
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: isDark ? Colors.white38 : Colors.black38,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                            ],
                          ),
                        ),
                        Icon(
                          Icons.chevron_right_rounded,
                          color: isDark ? Colors.white30 : Colors.black26,
                          size: 20,
                        ),
                      ],
                    ),
                  ),
                ),
                if (_modules.isNotEmpty) ...[
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      const Icon(Icons.extension_rounded, color: _kGreen, size: 16),
                      const SizedBox(width: 6),
                      Text(
                        '${_modules.length} Xposed module${_modules.length > 1 ? 's' : ''} will be embedded',
                        style: const TextStyle(fontSize: 12, color: _kGreen, fontWeight: FontWeight.w500),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),

          const SizedBox(height: 12),

          // Action buttons
          if (_isProcessing)
            _GreenButton(
              label: 'Cancel  $_elapsed',
              icon: Icons.stop_circle_rounded,
              color: const Color(0xFFef4444),
              onTap: _cancel,
              pulse: false,
            )
          else if (_logVisible && _logs.isNotEmpty)
            Row(
              children: [
                Expanded(
                  child: _GreenButton(
                    label: 'Inject Again',
                    icon: Icons.webhook_rounded,
                    color: _kGreen,
                    onTap: _filePath != null ? _startInject : null,
                    pulse: false,
                  ),
                ),
                const SizedBox(width: 8),
                _GreenButton(
                  label: 'Clear',
                  icon: Icons.delete_outline_rounded,
                  color: isDark ? const Color(0xFF2d2d3d) : Colors.grey.shade200,
                  textColor: isDark ? Colors.white70 : Colors.black54,
                  onTap: _clearState,
                  pulse: false,
                  compact: true,
                ),
              ],
            )
          else
            AnimatedBuilder(
              animation: _pulseAnim,
              builder: (_, __) => _GreenButton(
                label: 'Inject Pine Framework',
                icon: Icons.webhook_rounded,
                color: Color.lerp(_kGreen, _kGreenLight.withOpacity(0.85), _pulseAnim.value * 0.3)!,
                onTap: _filePath != null ? _startInject : null,
                pulse: _filePath != null,
              ),
            ),

          // Output dir
          if (_outputDir != null && !_isProcessing) ...[
            const SizedBox(height: 10),
            _Card(
              color: _kGreen.withOpacity(0.1),
              border: _kGreen.withOpacity(0.3),
              child: Row(
                children: [
                  const Icon(Icons.folder_open_rounded, color: _kGreen, size: 18),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Output saved to',
                          style: TextStyle(fontSize: 11, color: _kGreen),
                        ),
                        Text(
                          _outputDir!,
                          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],

          // Live log panel
          if (_logVisible) ...[
            const SizedBox(height: 12),
            FadeTransition(
              opacity: _logFade,
              child: _Card(
                color: isDark ? const Color(0xFF0D0D1A) : const Color(0xFFF0F0F0),
                border: isDark ? const Color(0xFF2d2d3d) : Colors.black12,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        if (_isProcessing) ...[
                          SizedBox(
                            width: 12, height: 12,
                            child: CircularProgressIndicator(
                              strokeWidth: 1.5,
                              color: _kGreen,
                            ),
                          ),
                          const SizedBox(width: 8),
                        ],
                        Text(
                          _isProcessing ? 'Running — $_elapsed' : 'Log',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: _isProcessing ? _kGreen : (isDark ? Colors.white60 : Colors.black54),
                          ),
                        ),
                        const Spacer(),
                        if (_logs.isNotEmpty)
                          IconButton(
                            onPressed: () {
                              Clipboard.setData(ClipboardData(text: _logs));
                              _showSnack('Log copied', icon: Icons.copy_rounded, color: _kGreen);
                            },
                            icon: Icon(Icons.copy_rounded,
                                size: 14,
                                color: isDark ? Colors.white38 : Colors.black38),
                            padding: EdgeInsets.zero,
                            visualDensity: VisualDensity.compact,
                          ),
                        IconButton(
                          onPressed: () => setState(() => _autoScroll = !_autoScroll),
                          icon: Icon(
                            _autoScroll ? Icons.vertical_align_bottom_rounded : Icons.lock_open_rounded,
                            size: 14,
                            color: _autoScroll ? _kGreen : (isDark ? Colors.white38 : Colors.black38),
                          ),
                          padding: EdgeInsets.zero,
                          visualDensity: VisualDensity.compact,
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Container(
                      constraints: const BoxConstraints(maxHeight: 320),
                      child: Scrollbar(
                        controller: _logScrollCtrl,
                        child: ListView(
                          controller: _logScrollCtrl,
                          shrinkWrap: true,
                          padding: EdgeInsets.zero,
                          children: [
                            SelectableText(
                              _logs.isEmpty ? '— waiting for output —' : _logs,
                              style: TextStyle(
                                fontFamily: 'monospace',
                                fontSize: 11.5,
                                height: 1.55,
                                color: isDark ? const Color(0xFFa3e635) : const Color(0xFF166534),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],

          const SizedBox(height: 30),
        ],
      ),
    );
  }

  // ── Modules tab ───────────────────────────────────────────────────────────

  Widget _buildModulesTab(bool isDark, Color card) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
      children: [

        // ── Built-in Modules ────────────────────────────────────────────────
        Row(
          children: [
            Icon(Icons.auto_fix_high_rounded, size: 14,
                color: isDark ? Colors.white38 : Colors.black38),
            const SizedBox(width: 6),
            Text('BUILT-IN MODULES',
                style: TextStyle(
                  fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.1,
                  color: isDark ? Colors.white38 : Colors.black38,
                )),
          ],
        ),
        const SizedBox(height: 20),

        // ── Xposed Modules ──────────────────────────────────────────────────
        Row(
          children: [
            Icon(Icons.extension_rounded, size: 14,
                color: isDark ? Colors.white38 : Colors.black38),
            const SizedBox(width: 6),
            Text('XPOSED MODULES',
                style: TextStyle(
                  fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1.1,
                  color: isDark ? Colors.white38 : Colors.black38,
                )),
            const Spacer(),
            TextButton.icon(
              onPressed: _addModule,
              icon: const Icon(Icons.add_rounded, size: 16, color: _kGreen),
              label: const Text('Add APK', style: TextStyle(color: _kGreen, fontSize: 12)),
              style: TextButton.styleFrom(
                visualDensity: VisualDensity.compact,
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                  side: BorderSide(color: _kGreen.withOpacity(0.4)),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),

        if (_modules.isEmpty)
          _Card(
            color: card,
            child: Column(
              children: [
                const SizedBox(height: 8),
                Icon(Icons.extension_off_rounded,
                    size: 40, color: isDark ? Colors.white24 : Colors.black26),
                const SizedBox(height: 10),
                Text('No modules added',
                    style: TextStyle(
                      fontSize: 14,
                      color: isDark ? Colors.white38 : Colors.black38,
                    )),
                const SizedBox(height: 4),
                Text('Tap "Add APK" to add an Xposed module',
                    style: TextStyle(
                      fontSize: 12,
                      color: isDark ? Colors.white24 : Colors.black26,
                    )),
                const SizedBox(height: 14),
                OutlinedButton.icon(
                  onPressed: () => launchUrl(
                    Uri.parse('https://modules.lsposed.org/'),
                    mode: LaunchMode.externalApplication,
                  ),
                  icon: const Icon(Icons.open_in_new_rounded, size: 16, color: _kGreen),
                  label: const Text('Browse LSPosed Repo',
                      style: TextStyle(color: _kGreen, fontSize: 12)),
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(color: _kGreen.withOpacity(0.5)),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  ),
                ),
                const SizedBox(height: 8),
              ],
            ),
          )
        else
          ...List.generate(_modules.length, (i) {
            final path   = _modules[i];
            final name   = path.split('/').last;
            final file   = File(path);
            final exists = file.existsSync();
            final size   = exists ? _fmtSize(file.lengthSync()) : 'File not found';

            return Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Dismissible(
                key: ValueKey(path),
                direction: DismissDirection.endToStart,
                background: Container(
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.only(right: 20),
                  decoration: BoxDecoration(
                    color: const Color(0xFFef4444).withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.delete_rounded,
                      color: Color(0xFFef4444), size: 22),
                ),
                onDismissed: (_) => _removeModule(i),
                child: _Card(
                  color: card,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  child: Row(
                    children: [
                      Container(
                        width: 36, height: 36,
                        decoration: BoxDecoration(
                          color: _kGreen.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Center(
                          child: Text('${i + 1}',
                              style: const TextStyle(
                                color: _kGreen, fontWeight: FontWeight.bold, fontSize: 14)),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(name,
                                style: const TextStyle(
                                    fontWeight: FontWeight.w600, fontSize: 13),
                                maxLines: 1, overflow: TextOverflow.ellipsis),
                            Text(size,
                                style: TextStyle(
                                  fontSize: 11,
                                  color: exists
                                      ? (isDark ? Colors.white38 : Colors.black38)
                                      : const Color(0xFFef4444),
                                )),
                          ],
                        ),
                      ),
                      IconButton(
                        onPressed: () => _removeModule(i),
                        icon: Icon(Icons.remove_circle_outline_rounded,
                            color: isDark ? Colors.white30 : Colors.black26, size: 20),
                        padding: EdgeInsets.zero,
                        visualDensity: VisualDensity.compact,
                      ),
                    ],
                  ),
                ),
              ),
            );
          }),
      ],
    );
  }

  String _fmtSize(int bytes) {
    final kb = bytes / 1024;
    return kb >= 1024
        ? '${(kb / 1024).toStringAsFixed(2)} MB'
        : '${kb.toStringAsFixed(1)} KB';
  }
}

// ── Shared widgets ────────────────────────────────────────────────────────────

class _Card extends StatelessWidget {
  final Widget child;
  final Color  color;
  final Color? border;
  final EdgeInsetsGeometry padding;

  const _Card({
    required this.child,
    required this.color,
    this.border,
    this.padding = const EdgeInsets.all(14),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: border ?? color.withOpacity(0.5),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: child,
    );
  }
}

class _Chip extends StatelessWidget {
  final String label;
  final Color  color;
  const _Chip({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Text(
        label,
        style: TextStyle(fontSize: 11, color: color, fontWeight: FontWeight.w500),
      ),
    );
  }
}

class _GreenButton extends StatelessWidget {
  final String   label;
  final IconData icon;
  final Color    color;
  final Color?   textColor;
  final VoidCallback? onTap;
  final bool     pulse;
  final bool     compact;

  const _GreenButton({
    required this.label,
    required this.icon,
    required this.color,
    this.textColor,
    required this.onTap,
    this.pulse = false,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    final disabled = onTap == null;
    return GestureDetector(
      onTap: disabled ? null : onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: compact
            ? const EdgeInsets.symmetric(horizontal: 14, vertical: 12)
            : const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: disabled ? color.withOpacity(0.4) : color,
          borderRadius: BorderRadius.circular(12),
          boxShadow: disabled
              ? []
              : [
                  BoxShadow(
                    color: color.withOpacity(0.3),
                    blurRadius: 10,
                    offset: const Offset(0, 3),
                  ),
                ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: textColor ?? Colors.white, size: 18),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                color: textColor ?? Colors.white,
                fontWeight: FontWeight.w700,
                fontSize: 14,
                letterSpacing: 0.2,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

