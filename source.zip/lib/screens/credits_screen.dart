import '../utils/theme_provider.dart';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class CreditsScreen extends StatefulWidget {
  const CreditsScreen({super.key});

  @override
  State<CreditsScreen> createState() => _CreditsScreenState();
}

class _CreditsScreenState extends State<CreditsScreen>
    with TickerProviderStateMixin {
  late final AnimationController _pulseCtrl;
  late final AnimationController _orbitCtrl;
  late final AnimationController _shimmerCtrl;
  late final AnimationController _entryCtrl;
  late final Animation<double> _pulse;
  late final Animation<double> _shimmer;

  @override
  void initState() {
    super.initState();

    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2400),
    )..repeat(reverse: true);

    _orbitCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 6000),
    )..repeat();

    _shimmerCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 3000),
    )..repeat();

    _entryCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1200),
    )..forward();

    _pulse = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );

    _shimmer = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _shimmerCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _orbitCtrl.dispose();
    _shimmerCtrl.dispose();
    _entryCtrl.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Could not open link'),
            backgroundColor: const Color(0xFFef4444).withOpacity(0.9),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10)),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF08081a),
      appBar: AppBar(
        centerTitle: true,
        title: AnimatedBuilder(
          animation: _pulse,
          builder: (_, __) {
            final p = _pulse.value;
            return Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.star_rounded,
                    color: Color.lerp(
                        const Color(0xFFf59e0b), const Color(0xFFfbbf24), p),
                    size: 18),
                const SizedBox(width: 8),
                const Text('CREDITS',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2.5,
                      fontSize: 18,
                    )),
                const SizedBox(width: 8),
                Icon(Icons.star_rounded,
                    color: Color.lerp(
                        const Color(0xFFfbbf24), const Color(0xFFf59e0b), p),
                    size: 18),
              ],
            );
          },
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [ThemeProvider().current.appBarBg, Color(0xFF0a0a18)],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: AnimatedBuilder(
            animation: _shimmer,
            builder: (_, __) {
              return Container(
                height: 1,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      ThemeProvider().current.primary.withOpacity(0.10),
                      Color(0xFFf59e0b).withOpacity(0.40 + 0.20 * _shimmer.value),
                      ThemeProvider().current.primary.withOpacity(0.10),
                    ],
                    stops: [
                      0.0,
                      _shimmer.value,
                      1.0,
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 40),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _buildHeaderNote(),
            const SizedBox(height: 24),
            _buildToolCredit(
              index: 0,
              toolName: 'hbctool',
              developer: 'bongtrop',
              description:
                  'Hermes Bytecode disassembler and assembler. The core engine '
                  'that powers Taurus Shield\'s HBC analysis, supporting '
                  'versions 59 through 96.',
              repoUrl: 'https://github.com/bongtrop/hbctool',
              accentColor: ThemeProvider().current.primary,
              secondaryColor: ThemeProvider().current.secondary,
              iconBuilder: _buildHbcIcon,
              chips: const ['HBC', 'Disassemble', 'Assemble', 'React Native'],
            ),
            const SizedBox(height: 18),
            _buildToolCredit(
              index: 1,
              toolName: 'Blutter',
              developer: 'worawit',
              description:
                  'Flutter reverse engineering tool that extracts Dart symbols, '
                  'class structures, and function names from compiled Flutter '
                  'APKs (libapp.so).',
              repoUrl: 'https://github.com/worawit/blutter',
              accentColor: ThemeProvider().current.highlightColor,
              secondaryColor: const Color(0xFF67e8f9),
              iconBuilder: _buildBlutterIcon,
              chips: const ['Flutter', 'Dart Symbols', 'ARM64', 'libapp.so'],
            ),
            const SizedBox(height: 18),
            _buildToolCredit(
              index: 2,
              toolName: 'Dex2C',
              developer: 'codehasan',
              description:
                  'APK protection tool that converts DEX bytecode into native '
                  'C/C++ code, making methods resistant to static analysis, '
                  'decompilation and tampering.',
              repoUrl: 'https://github.com/codehasan/dex2c',
              accentColor: const Color(0xFF10b981),
              secondaryColor: const Color(0xFF34d399),
              iconBuilder: _buildDex2cIcon,
              chips: const ['DEX', 'Native C', 'Obfuscation', 'APK Protection'],
            ),
            const SizedBox(height: 18),
            _buildToolCredit(
              index: 3,
              toolName: 'Ghost Killer Method',
              developer: 'Ghost Killer',
              description:
                  'Credit to the original developer — Ghost Killer — for the '
                  'concept of automatic Flutter app patching. The String and '
                  'Boolean patching logic for Flutter APKs was independently '
                  'reverse engineered and fully reimplemented from his '
                  'FlutterMod app into Taurus Shield — no code was taken, '
                  'only the method was studied and rebuilt. Additional '
                  'features and improvements have been developed on top of '
                  'the original concept, including multi-match support, '
                  'selective patching, and deeper integration with the '
                  'full ARM64 ASM editor.',
              repoUrl: 'https://t.me/ghostgmb0',
              accentColor: const Color(0xFFf97316),
              secondaryColor: const Color(0xFFfb923c),
              iconBuilder: _buildGhostKillerIcon,
              chips: const ['Ghost Killer', 'Auto Patch', 'Strings', 'Booleans', 'Flutter'],
              linkLabel: 'Contact Developer',
              linkIcon: Icons.telegram_rounded,
            ),
            const SizedBox(height: 28),
            _buildFooter(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeaderNote() {
    return AnimatedBuilder(
      animation: _pulse,
      builder: (_, __) {
        final p = _pulse.value;
        return Container(
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: RadialGradient(
              center: Alignment.center,
              radius: 1.5,
              colors: [
                const Color(0xFFf59e0b).withOpacity(0.04 + 0.03 * p),
                const Color(0xFF08081a),
              ],
            ),
            border: Border.all(
                color: const Color(0xFFf59e0b).withOpacity(0.10 + 0.06 * p)),
          ),
          child: Column(
            children: [
              Icon(Icons.favorite_rounded,
                  color: const Color(0xFFf59e0b).withOpacity(0.6 + 0.3 * p),
                  size: 28),
              const SizedBox(height: 10),
              const Text(
                'Open Source Acknowledgements',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFFfbbf24),
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.8,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Taurus Shield is built on the shoulders of these incredible '
                'open-source projects. We are grateful to these developers '
                'for their contributions to the security research community.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: const Color(0xFFd1d5db).withOpacity(0.7),
                  fontSize: 12,
                  height: 1.6,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildToolCredit({
    required int index,
    required String toolName,
    required String developer,
    required String description,
    required String repoUrl,
    required Color accentColor,
    required Color secondaryColor,
    required Widget Function(Color accent, Color secondary) iconBuilder,
    required List<String> chips,
    String? linkLabel,
    IconData? linkIcon,
  }) {
    final entryDelay = 0.15 + index * 0.20;
    final entryEnd   = (entryDelay + 0.40).clamp(0.0, 1.0);

    return AnimatedBuilder(
      animation: _entryCtrl,
      builder: (_, child) {
        final progress = Curves.easeOutCubic.transform(
          ((_entryCtrl.value - entryDelay) / (entryEnd - entryDelay))
              .clamp(0.0, 1.0),
        );
        return Opacity(
          opacity: progress,
          child: Transform.translate(
            offset: Offset(0, 30 * (1 - progress)),
            child: child,
          ),
        );
      },
      child: AnimatedBuilder(
        animation: _pulse,
        builder: (_, __) {
          final p = _pulse.value;
          return Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              color: const Color(0xFF0e0e22),
              border: Border.all(
                  color: accentColor.withOpacity(0.12 + 0.08 * p), width: 1.2),
              boxShadow: [
                BoxShadow(
                  color: accentColor.withOpacity(0.06 + 0.04 * p),
                  blurRadius: 20,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 18, 18, 14),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 56,
                        height: 56,
                        child: iconBuilder(accentColor, secondaryColor),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              toolName,
                              style: TextStyle(
                                color: accentColor,
                                fontSize: 20,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1.0,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Row(
                              children: [
                                Icon(Icons.person_rounded,
                                    color: secondaryColor.withOpacity(0.7),
                                    size: 14),
                                const SizedBox(width: 5),
                                Text(
                                  developer,
                                  style: TextStyle(
                                    color: secondaryColor,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Divider(
                    height: 1,
                    color: accentColor.withOpacity(0.08),
                    indent: 18,
                    endIndent: 18),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 12, 18, 12),
                  child: Text(
                    description,
                    style: TextStyle(
                      color: const Color(0xFFd1d5db).withOpacity(0.8),
                      fontSize: 12.5,
                      height: 1.6,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 0, 18, 4),
                  child: Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: chips
                        .map((c) => _Chip(label: c, color: accentColor))
                        .toList(),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 10, 18, 16),
                  child: GestureDetector(
                    onTap: () => _openUrl(repoUrl),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: accentColor.withOpacity(0.08),
                        border: Border.all(
                            color: accentColor.withOpacity(0.25)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            linkIcon ?? Icons.open_in_new_rounded,
                            color: accentColor, size: 15,
                          ),
                          const SizedBox(width: 8),
                          Flexible(
                            child: Text(
                              linkLabel ?? repoUrl.replaceFirst('https://', ''),
                              style: TextStyle(
                                color: accentColor,
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                letterSpacing: 0.3,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildHbcIcon(Color accent, Color secondary) {
    return AnimatedBuilder(
      animation: Listenable.merge([_pulse, _orbitCtrl]),
      builder: (_, __) {
        final p = _pulse.value;
        final orbit = _orbitCtrl.value;
        return Stack(
          alignment: Alignment.center,
          children: [
            Transform.rotate(
              angle: orbit * math.pi * 2,
              child: CustomPaint(
                size: const Size(56, 56),
                painter: _OrbitArcPainter(
                    color: accent, opacity: 0.35 + 0.25 * p),
              ),
            ),
            Transform.rotate(
              angle: -orbit * math.pi * 2 * 0.7,
              child: CustomPaint(
                size: const Size(36, 36),
                painter: _HexDotPainter(
                    color: secondary, opacity: 0.4 + 0.3 * p),
              ),
            ),
            Container(
              width: 26,
              height: 26,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(7),
                gradient: LinearGradient(
                  colors: [
                    accent.withOpacity(0.25 + 0.15 * p),
                    accent.withOpacity(0.10 + 0.10 * p),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Center(
                child: Text(
                  'HB',
                  style: TextStyle(
                    color: accent.withOpacity(0.7 + 0.3 * p),
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildBlutterIcon(Color accent, Color secondary) {
    return AnimatedBuilder(
      animation: Listenable.merge([_pulse, _orbitCtrl]),
      builder: (_, __) {
        final p = _pulse.value;
        final orbit = _orbitCtrl.value;
        return Stack(
          alignment: Alignment.center,
          children: [
            Transform.rotate(
              angle: -orbit * math.pi * 2 * 0.8,
              child: CustomPaint(
                size: const Size(56, 56),
                painter: _OrbitArcPainter(
                    color: accent, opacity: 0.30 + 0.25 * p),
              ),
            ),
            Transform.rotate(
              angle: orbit * math.pi * 2 * 0.5,
              child: CustomPaint(
                size: const Size(40, 40),
                painter: _HexDotPainter(
                    color: secondary, opacity: 0.35 + 0.3 * p),
              ),
            ),
            Icon(Icons.flutter_dash_rounded,
                color: accent.withOpacity(0.7 + 0.3 * p), size: 22),
          ],
        );
      },
    );
  }

  Widget _buildDex2cIcon(Color accent, Color secondary) {
    return AnimatedBuilder(
      animation: Listenable.merge([_pulse, _orbitCtrl]),
      builder: (_, __) {
        final p = _pulse.value;
        final orbit = _orbitCtrl.value;
        return Stack(
          alignment: Alignment.center,
          children: [
            Transform.rotate(
              angle: orbit * math.pi * 2 * 0.6,
              child: CustomPaint(
                size: const Size(56, 56),
                painter: _ShieldOrbitPainter(
                    color: accent, opacity: 0.30 + 0.25 * p),
              ),
            ),
            Transform.rotate(
              angle: -orbit * math.pi * 2 * 0.4,
              child: CustomPaint(
                size: const Size(38, 38),
                painter: _HexDotPainter(
                    color: secondary, opacity: 0.35 + 0.25 * p),
              ),
            ),
            CustomPaint(
              size: const Size(24, 28),
              painter: _ShieldIconPainter(
                  color: accent, phase: p),
            ),
          ],
        );
      },
    );
  }

  Widget _buildGhostKillerIcon(Color accent, Color secondary) {
    return AnimatedBuilder(
      animation: Listenable.merge([_pulse, _orbitCtrl]),
      builder: (_, __) {
        final p     = _pulse.value;
        final orbit = _orbitCtrl.value;
        return Stack(
          alignment: Alignment.center,
          children: [
            Transform.rotate(
              angle: orbit * math.pi * 2 * 0.5,
              child: CustomPaint(
                size: const Size(56, 56),
                painter: _OrbitArcPainter(
                    color: accent, opacity: 0.30 + 0.25 * p),
              ),
            ),
            Transform.rotate(
              angle: -orbit * math.pi * 2 * 0.7,
              child: CustomPaint(
                size: const Size(38, 38),
                painter: _HexDotPainter(
                    color: secondary, opacity: 0.35 + 0.25 * p),
              ),
            ),
            Container(
              width: 28,
              height: 28,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(7),
                gradient: LinearGradient(
                  colors: [
                    accent.withOpacity(0.30 + 0.15 * p),
                    accent.withOpacity(0.12 + 0.10 * p),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color: accent.withOpacity(0.25 + 0.15 * p),
                    blurRadius: 8,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  'GK',
                  style: TextStyle(
                    color: accent.withOpacity(0.8 + 0.2 * p),
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildFooter() {
    return AnimatedBuilder(
      animation: _pulse,
      builder: (_, __) {
        return Column(
          children: [
            Divider(
                color: const Color(0xFF374151).withOpacity(0.3),
                indent: 40,
                endIndent: 40),
            const SizedBox(height: 14),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.code_rounded,
                    color: const Color(0xFF6b7280).withOpacity(0.5), size: 14),
                const SizedBox(width: 6),
                Text(
                  'Built with respect for open source',
                  style: TextStyle(
                    color: const Color(0xFF6b7280).withOpacity(0.5),
                    fontSize: 11,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ],
            ),
          ],
        );
      },
    );
  }
}

class _Chip extends StatelessWidget {
  final String label;
  final Color color;
  const _Chip({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.06),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: color.withOpacity(0.18)),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color.withOpacity(0.8),
          fontSize: 9.5,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.4,
        ),
      ),
    );
  }
}

class _OrbitArcPainter extends CustomPainter {
  final Color color;
  final double opacity;
  const _OrbitArcPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r  = (size.width / 2) - 2;
    final paint = Paint()
      ..color = color.withOpacity(opacity)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5
      ..strokeCap = StrokeCap.round;

    const gap = math.pi / 3;
    const arc = math.pi / 3;
    for (int i = 0; i < 3; i++) {
      canvas.drawArc(
        Rect.fromCircle(center: Offset(cx, cy), radius: r),
        i * (arc + gap), arc, false, paint,
      );
    }

    final dp = Paint()
      ..color = color.withOpacity(opacity * 0.85)
      ..style = PaintingStyle.fill;
    for (int i = 0; i < 3; i++) {
      final a = i * (arc + gap) + arc / 2;
      canvas.drawCircle(
          Offset(cx + r * math.cos(a), cy + r * math.sin(a)), 2.2, dp);
    }
  }

  @override
  bool shouldRepaint(_OrbitArcPainter o) =>
      o.color != color || o.opacity != opacity;
}

class _HexDotPainter extends CustomPainter {
  final Color color;
  final double opacity;
  const _HexDotPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r  = (size.width / 2) - 1;
    for (int i = 0; i < 6; i++) {
      final a = i * (math.pi / 3);
      canvas.drawCircle(
        Offset(cx + r * math.cos(a), cy + r * math.sin(a)),
        i % 2 == 0 ? 1.8 : 1.1,
        Paint()
          ..color = color.withOpacity(opacity * (i % 2 == 0 ? 1.0 : 0.5))
          ..style = PaintingStyle.fill,
      );
    }
  }

  @override
  bool shouldRepaint(_HexDotPainter o) =>
      o.color != color || o.opacity != opacity;
}

class _ShieldOrbitPainter extends CustomPainter {
  final Color color;
  final double opacity;
  const _ShieldOrbitPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r  = (size.width / 2) - 2;
    final paint = Paint()
      ..color = color.withOpacity(opacity)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4
      ..strokeCap = StrokeCap.round;

    const gap = math.pi / 4;
    const arc = math.pi / 4;
    for (int i = 0; i < 4; i++) {
      canvas.drawArc(
        Rect.fromCircle(center: Offset(cx, cy), radius: r),
        i * (arc + gap), arc, false, paint,
      );
    }

    final dp = Paint()
      ..color = color.withOpacity(opacity * 0.8)
      ..style = PaintingStyle.fill;
    for (int i = 0; i < 4; i++) {
      final a = i * (arc + gap) + arc / 2;
      canvas.drawCircle(
          Offset(cx + r * math.cos(a), cy + r * math.sin(a)), 2.0, dp);
    }
  }

  @override
  bool shouldRepaint(_ShieldOrbitPainter o) =>
      o.color != color || o.opacity != opacity;
}

class _ShieldIconPainter extends CustomPainter {
  final Color color;
  final double phase;
  const _ShieldIconPainter({required this.color, required this.phase});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    final path = Path()
      ..moveTo(w * 0.5, 0)
      ..lineTo(w, h * 0.18)
      ..lineTo(w, h * 0.52)
      ..quadraticBezierTo(w, h * 0.82, w * 0.5, h)
      ..quadraticBezierTo(0, h * 0.82, 0, h * 0.52)
      ..lineTo(0, h * 0.18)
      ..close();

    final glow = 0.18 + 0.12 * math.sin(phase * math.pi * 2);
    canvas.drawPath(
      path,
      Paint()
        ..shader = LinearGradient(
          colors: [
            color.withOpacity(glow + 0.08),
            color.withOpacity(glow * 0.5),
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ).createShader(Rect.fromLTWH(0, 0, w, h))
        ..style = PaintingStyle.fill,
    );

    canvas.drawPath(
      path,
      Paint()
        ..color = color.withOpacity(0.5 + 0.3 * phase)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.3
        ..strokeJoin = StrokeJoin.round,
    );

    final scanY = h * 0.2 + h * 0.6 * phase;
    canvas.drawLine(
        Offset(w * 0.2, scanY), Offset(w * 0.8, scanY),
        Paint()
          ..color = color.withOpacity(0.30)
          ..strokeWidth = 1.0);

    final dots = [
      Offset(w * 0.5, h * 0.35),
      Offset(w * 0.35, h * 0.55),
      Offset(w * 0.65, h * 0.55),
    ];
    for (int i = 0; i < dots.length; i++) {
      final dp = 0.5 + 0.5 * math.sin(phase * math.pi * 2 + i * 1.5);
      canvas.drawCircle(
        dots[i],
        1.2 + 0.4 * dp,
        Paint()
          ..color = color.withOpacity(0.4 + 0.4 * dp)
          ..style = PaintingStyle.fill,
      );
    }
  }

  @override
  bool shouldRepaint(_ShieldIconPainter o) =>
      o.color != color || o.phase != phase;
}
