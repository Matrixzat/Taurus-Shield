import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'dex_tool_screen.dart';

const _kAccent = Color(0xFF6366f1);

// ── Pulsing glow icon ──────────────────────────────────────────────────────

class _GlowIcon extends StatefulWidget {
  final Widget child;
  final Color glow;
  const _GlowIcon({required this.child, required this.glow});

  @override
  State<_GlowIcon> createState() => _GlowIconState();
}

class _GlowIconState extends State<_GlowIcon> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 2400))
      ..repeat(reverse: true);
    _anim = CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut);
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _anim,
      builder: (_, child) => Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: widget.glow.withOpacity(0.12 + 0.28 * _anim.value),
              blurRadius:  20 + 20 * _anim.value,
              spreadRadius: 1 + 5 * _anim.value,
            ),
          ],
        ),
        child: child,
      ),
      child: widget.child,
    );
  }
}

// ── Rotating orbit ring (decorative) ──────────────────────────────────────

class _OrbitRing extends StatefulWidget {
  final Color color;
  final double size;
  final Duration period;
  final bool reverse;
  const _OrbitRing({required this.color, required this.size, required this.period, this.reverse = false});

  @override
  State<_OrbitRing> createState() => _OrbitRingState();
}

class _OrbitRingState extends State<_OrbitRing> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: widget.period)..repeat();
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) => Transform.rotate(
        angle: (widget.reverse ? -1 : 1) * _ctrl.value * math.pi * 2,
        child: CustomPaint(
          size: Size(widget.size, widget.size),
          painter: _RingPainter(color: widget.color),
        ),
      ),
    );
  }
}

class _RingPainter extends CustomPainter {
  final Color color;
  const _RingPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withOpacity(0.22)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4;
    canvas.drawOval(
      Rect.fromCenter(center: Offset(size.width / 2, size.height / 2),
          width: size.width, height: size.height * 0.38),
      paint,
    );
  }

  @override
  bool shouldRepaint(_RingPainter old) => old.color != color;
}

// ── Hub Header ─────────────────────────────────────────────────────────────

class _HubHeader extends StatelessWidget {
  const _HubHeader();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: RadialGradient(
          center: Alignment.center,
          radius: 1.1,
          colors: [_kAccent.withOpacity(0.07), const Color(0xFF0a0a1a)],
        ),
        border: Border.all(color: _kAccent.withOpacity(0.15)),
      ),
      child: Column(
        children: [
          SizedBox(
            width: 100,
            height: 100,
            child: Stack(
              alignment: Alignment.center,
              children: [
                const _OrbitRing(color: _kAccent, size: 100, period: Duration(seconds: 6)),
                const _OrbitRing(color: _kAccent, size: 68, period: Duration(seconds: 9), reverse: true),
                _GlowIcon(
                  glow: _kAccent,
                  child: SvgPicture.asset('assets/icon/android_os.svg', width: 42, height: 42),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'DEX Tools',
            style: TextStyle(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.w800,
              letterSpacing: -0.5,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Android bytecode disassembly, decompile & recompile',
            style: TextStyle(color: Colors.white.withOpacity(0.45), fontSize: 12),
          ),
          const SizedBox(height: 14),
          Wrap(
            spacing: 8,
            runSpacing: 6,
            alignment: WrapAlignment.center,
            children: const [
              _Chip('.dex'), _Chip('.apk'), _Chip('.smali'),
              _Chip('.java'), _Chip('.jar'), _Chip('core'),
            ],
          ),
        ],
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  final String label;
  const _Chip(this.label);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: _kAccent.withOpacity(0.10),
        border: Border.all(color: _kAccent.withOpacity(0.25)),
      ),
      child: Text(label,
          style: TextStyle(color: _kAccent.withOpacity(0.85), fontSize: 10, fontWeight: FontWeight.w600)),
    );
  }
}

// ── Tool card ──────────────────────────────────────────────────────────────

class _ToolCard extends StatefulWidget {
  final String title;
  final String subtitle;
  final String description;
  final Color accent;
  final Widget icon;
  final VoidCallback onTap;

  const _ToolCard({
    required this.title,
    required this.subtitle,
    required this.description,
    required this.accent,
    required this.icon,
    required this.onTap,
  });

  @override
  State<_ToolCard> createState() => _ToolCardState();
}

class _ToolCardState extends State<_ToolCard> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _pulse;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 2200))
      ..repeat(reverse: true);
    _pulse = CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut);
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _pulse,
      builder: (_, __) => GestureDetector(
        onTap: widget.onTap,
        child: Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            color: const Color(0xFF0d0d1f),
            border: Border.all(
              color: widget.accent.withOpacity(0.12 + 0.10 * _pulse.value),
            ),
            boxShadow: [
              BoxShadow(
                color: widget.accent.withOpacity(0.04 + 0.04 * _pulse.value),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  color: widget.accent.withOpacity(0.08 + 0.04 * _pulse.value),
                  border: Border.all(color: widget.accent.withOpacity(0.18)),
                ),
                child: Center(child: widget.icon),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            widget.title,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            color: widget.accent.withOpacity(0.12),
                            border: Border.all(color: widget.accent.withOpacity(0.25)),
                          ),
                          child: Text(
                            'CORE',
                            style: TextStyle(
                              color: widget.accent,
                              fontSize: 9,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      widget.subtitle,
                      style: TextStyle(
                        color: widget.accent.withOpacity(0.7),
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      widget.description,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.38),
                        fontSize: 11,
                        height: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Icon(Icons.chevron_right_rounded,
                  color: widget.accent.withOpacity(0.4), size: 20),
            ],
          ),
        ),
      ),
    );
  }
}

// ── Main Hub Screen ────────────────────────────────────────────────────────

class DexToolsHubScreen extends StatelessWidget {
  const DexToolsHubScreen({super.key});

  void _open(BuildContext context, DexToolConfig cfg) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => DexToolScreen(config: cfg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0a0a1a),
      appBar: AppBar(
        centerTitle: true,
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            SvgPicture.asset('assets/icon/android_os.svg', width: 18, height: 18),
            const SizedBox(width: 8),
            const Text('DEX Tools', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            const SizedBox(width: 8),
            SvgPicture.asset('assets/icon/java.svg', width: 16, height: 16),
          ],
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF0a0a1a), Color(0xFF100e2e)],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: _kAccent.withOpacity(0.2)),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const _HubHeader(),
            const SizedBox(height: 20),
            _ToolCard(
              title: 'Smali → Java',
              subtitle: 'Decompile Smali to Java source',
              description: 'Reassemble Smali → DEX → JAR → Java source via CFR decompiler.',
              accent: const Color(0xFF0EA5E9),
              icon: Row(mainAxisSize: MainAxisSize.min, children: [
                SvgPicture.asset('assets/icon/android_os.svg', width: 20, height: 20),
                const SizedBox(width: 4),
                SvgPicture.asset('assets/icon/java.svg', width: 20, height: 20),
              ]),
              onTap: () => _open(context, const DexToolConfig(
                toolId: 'smali2java',
                toolName: 'Smali → Java',
                subtitle: 'Decompile Smali to Java source',
                accent: Color(0xFF0EA5E9),
                acceptedExtensions: ['zip', 'smali', 'apk'],
                inputLabel: 'Select .zip (smali files) or .smali',
                outputDescription: 'Output: ZIP archive of .java source files',
                iconAsset: 'assets/icon/java.svg',
              )),
            ),
            _ToolCard(
              title: 'Java → Smali',
              subtitle: 'Compile Java to Smali bytecode',
              description: 'ECJ-compile .java / dx-convert .jar/.class → DEX → Smali. Pass a .zip to batch many sources at once.',
              accent: const Color(0xFFF97316),
              icon: SvgPicture.asset('assets/icon/java.svg', width: 26, height: 26),
              onTap: () => _open(context, const DexToolConfig(
                toolId: 'java2smali',
                toolName: 'Java → Smali',
                subtitle: 'Compile Java to Smali bytecode',
                accent: Color(0xFFF97316),
                acceptedExtensions: ['java', 'jar', 'class', 'zip'],
                inputLabel: 'Select .java, .jar, .class, or .zip file',
                outputDescription: 'Output: ZIP archive of .smali files',
                iconAsset: 'assets/icon/java.svg',
              )),
            ),
            _ToolCard(
              title: 'DEX → JAR',
              subtitle: 'Convert DEX bytecode to JAR',
              description: 'Translate .dex or .apk to a standard Java .jar using dex2jar v2.4.',
              accent: const Color(0xFF8B5CF6),
              icon: SvgPicture.asset('assets/icon/java.svg', width: 26, height: 26),
              onTap: () => _open(context, const DexToolConfig(
                toolId: 'dex2jar',
                toolName: 'DEX → JAR',
                subtitle: 'Convert DEX to Java Archive',
                accent: Color(0xFF8B5CF6),
                acceptedExtensions: ['dex', 'apk'],
                inputLabel: 'Select .dex or .apk file',
                outputDescription: 'Output: .jar file (Java Archive)',
                iconAsset: 'assets/icon/java.svg',
              )),
            ),
            _ToolCard(
              title: 'DEX → Java',
              subtitle: 'Full decompilation to Java source',
              description: 'One-click: DEX/APK → JAR via dex2jar → Java source via CFR decompiler.',
              accent: const Color(0xFF22C55E),
              icon: Row(mainAxisSize: MainAxisSize.min, children: [
                SvgPicture.asset('assets/icon/android_os.svg', width: 20, height: 20),
                const SizedBox(width: 4),
                SvgPicture.asset('assets/icon/java.svg', width: 20, height: 20),
              ]),
              onTap: () => _open(context, const DexToolConfig(
                toolId: 'dex2java',
                toolName: 'DEX → Java',
                subtitle: 'Full decompilation to Java source',
                accent: Color(0xFF22C55E),
                acceptedExtensions: ['dex', 'apk'],
                inputLabel: 'Select .dex or .apk file',
                outputDescription: 'Output: ZIP archive of .java source files',
                iconAsset: 'assets/icon/java.svg',
              )),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
