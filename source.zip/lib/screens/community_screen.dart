import '../utils/theme_provider.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../utils/app_links.dart';

class CommunityScreen extends StatelessWidget {
  const CommunityScreen({super.key});

  Future<void> _launch(String url, BuildContext context) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not open link')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('JOIN OUR COMMUNITY')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _HeroSection(),
            const SizedBox(height: 28),
            _CommunityCard(
              platform: 'Telegram',
              handle: '',
              description:
                  'Join our Telegram channel for the latest updates, tool releases, tips, tutorials and direct support from the developer.',
              icon: Icons.send_rounded,
              gradient: const [Color(0xFF0088cc), Color(0xFF005fa3)],
              borderColor: const Color(0xFF0088cc),
              onTap: () => _launch(AppLinks.telegramChannel, context),
            ),
            const SizedBox(height: 14),
            _CommunityCard(
              platform: 'WhatsApp',
              handle: '',
              description:
                  'Join our WhatsApp group for quick support, community discussions and real-time help from other users.',
              icon: Icons.chat_bubble_rounded,
              gradient: const [Color(0xFF25d366), Color(0xFF128c7e)],
              borderColor: const Color(0xFF25d366),
              onTap: () => _launch(AppLinks.whatsappGroup, context),
            ),
            const SizedBox(height: 28),
            _BenefitsCard(),
          ],
        ),
      ),
    );
  }
}

class _HeroSection extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(28),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: LinearGradient(
          colors: [ThemeProvider().current.headerBg1, Color(0xFF0d1a30)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        border: Border.all(color: ThemeProvider().current.primary.withOpacity(0.4)),
      ),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: ThemeProvider().current.primary.withOpacity(0.15),
              shape: BoxShape.circle,
              border: Border.all(color: ThemeProvider().current.primary.withOpacity(0.5), width: 2),
              boxShadow: [BoxShadow(color: ThemeProvider().current.primary.withOpacity(0.3), blurRadius: 24)],
            ),
            child: Icon(Icons.groups_rounded, color: ThemeProvider().current.secondary, size: 48),
          ),
          const SizedBox(height: 18),
          const Text(
            'Join Our Community',
            style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900, letterSpacing: 0.5),
          ),
          SizedBox(height: 8),
          Text(
            'Connect with other users, get help,\nand stay updated with new releases',
            textAlign: TextAlign.center,
            style: TextStyle(color: ThemeProvider().current.secondary, fontSize: 13, height: 1.5),
          ),
        ],
      ),
    );
  }
}

class _CommunityCard extends StatelessWidget {
  final String platform;
  final String handle;
  final String description;
  final IconData icon;
  final List<Color> gradient;
  final Color borderColor;
  final VoidCallback onTap;

  const _CommunityCard({
    required this.platform,
    required this.handle,
    required this.description,
    required this.icon,
    required this.gradient,
    required this.borderColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: ThemeProvider().current.surfaceColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: borderColor.withOpacity(0.4), width: 1.5),
          boxShadow: [BoxShadow(color: borderColor.withOpacity(0.1), blurRadius: 16)],
        ),
        child: Row(
          children: [
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                gradient: LinearGradient(colors: gradient),
                boxShadow: [BoxShadow(color: borderColor.withOpacity(0.4), blurRadius: 12)],
              ),
              child: Icon(icon, color: Colors.white, size: 28),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(platform, style: TextStyle(color: borderColor, fontSize: 18, fontWeight: FontWeight.w800)),
                      const Spacer(),
                      Icon(Icons.arrow_forward_ios_rounded, color: borderColor.withOpacity(0.7), size: 16),
                    ],
                  ),
                  const SizedBox(height: 3),
                  Text(handle, style: const TextStyle(color: Color(0xFFd4d4d4), fontSize: 12, fontWeight: FontWeight.w500)),
                  const SizedBox(height: 6),
                  Text(description, style: const TextStyle(color: Color(0xFF6b7280), fontSize: 11, height: 1.5)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BenefitsCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    const benefits = [
      (Icons.new_releases_rounded, 'Early updates', 'Get notified about new features first'),
      (Icons.support_rounded, 'Direct support', 'Get help directly from the developer'),
      (Icons.people_rounded, 'Community tips', 'Learn from other power users'),
      (Icons.bug_report_rounded, 'Bug reports', 'Report issues and get fixes fast'),
    ];

    return Container(
      padding: EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: ThemeProvider().current.surfaceColor,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: ThemeProvider().current.borderColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(children: [
            Icon(Icons.star_rounded, color: Color(0xFFf59e0b), size: 20),
            SizedBox(width: 10),
            Text('Why join?', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15)),
          ]),
          const SizedBox(height: 14),
          ...benefits.map((b) => Padding(
            padding: const EdgeInsets.symmetric(vertical: 7),
            child: Row(
              children: [
                Container(
                  padding: EdgeInsets.all(7),
                  decoration: BoxDecoration(
                    color: ThemeProvider().current.primary.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(b.$1, color: ThemeProvider().current.primary, size: 16),
                ),
                const SizedBox(width: 12),
                Expanded(child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(b.$2, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
                    Text(b.$3, style: const TextStyle(color: Color(0xFF6b7280), fontSize: 11)),
                  ],
                )),
              ],
            ),
          )),
        ],
      ),
    );
  }
}
