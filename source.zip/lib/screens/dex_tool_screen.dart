import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:file_picker/file_picker.dart';
import 'package:share_plus/share_plus.dart';
import '../utils/hbc_channel.dart';
import '../utils/storage_helper.dart';
import '../utils/permission_helper.dart';
import '../utils/theme_provider.dart';

// ── Tool configuration (passed from hub) ─────────────────────────────────

class DexToolConfig {
  final String toolId;
  final String toolName;
  final String subtitle;
  final Color  accent;
  final List<String> acceptedExtensions;
  final String inputLabel;
  final String outputDescription;
  final String iconAsset;

  const DexToolConfig({
    required this.toolId,
    required this.toolName,
    required this.subtitle,
    required this.accent,
    required this.acceptedExtensions,
    required this.inputLabel,
    required this.outputDescription,
    required this.iconAsset,
  });
}

// ── Screen ─────────────────────────────────────────────────────────────────

class DexToolScreen extends StatefulWidget {
  final DexToolConfig config;
  const DexToolScreen({super.key, required this.config});

  @override
  State<DexToolScreen> createState() => _DexToolScreenState();
}

class _DexToolScreenState extends State<DexToolScreen> with TickerProviderStateMixin {
  String? _selectedFilePath;
  String? _selectedFileName;
  bool    _isProcessing    = false;
  bool    _logVisible      = false;
  String  _logs            = '';
  String? _outputPath;
  bool    _success         = false;
  bool    _autoScroll      = true;

  final Stopwatch _stopwatch = Stopwatch();
  Timer?  _tickTimer;
  String  _elapsed = '00:00';

  final ScrollController _logScrollCtrl  = ScrollController();
  final ScrollController _pageScrollCtrl = ScrollController();
  final GlobalKey        _logPanelKey    = GlobalKey();

  late final AnimationController _pulseCtrl;
  late final AnimationController _spinCtrl;
  late final AnimationController _logCtrl;
  late final Animation<double>   _pulseAnim;
  late final Animation<double>   _logFade;

  DexToolConfig get cfg => widget.config;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 2000))
      ..repeat(reverse: true);
    _spinCtrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))
      ..repeat();
    _logCtrl   = AnimationController(vsync: this, duration: const Duration(milliseconds: 380));
    _pulseAnim = CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut);
    _logFade   = CurvedAnimation(parent: _logCtrl, curve: Curves.easeOut);
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _spinCtrl.dispose();
    _logCtrl.dispose();
    _logScrollCtrl.dispose();
    _pageScrollCtrl.dispose();
    _tickTimer?.cancel();
    super.dispose();
  }

  // ── Timer ─────────────────────────────────────────────────────────────────

  void _startTimer() {
    _stopwatch.reset();
    _stopwatch.start();
    _tickTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      final e = _stopwatch.elapsed;
      if (mounted) {
        setState(() {
          _elapsed = '${e.inMinutes.toString().padLeft(2, '0')}:${(e.inSeconds % 60).toString().padLeft(2, '0')}';
        });
      }
    });
  }

  void _stopTimer() {
    _stopwatch.stop();
    _tickTimer?.cancel();
  }

  // ── Snack ─────────────────────────────────────────────────────────────────

  void _showSnack(String msg, {required IconData icon, required Color color}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(icon, color: Colors.white, size: 18),
        const SizedBox(width: 10),
        Expanded(child: Text(msg, style: const TextStyle(color: Colors.white, fontSize: 13))),
      ]),
      backgroundColor: color.withOpacity(0.9),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      duration: const Duration(seconds: 3),
    ));
  }

  // ── File picker ───────────────────────────────────────────────────────────

  Future<void> _pickFile() async {
    // FileType.any — no MIME filtering so .dex, .smali, .jar, classes.dex
    // etc. are never greyed out. Extension validation is left to the engine.
    final result = await FilePicker.platform.pickFiles(type: FileType.any);
    if (result == null || result.files.isEmpty) return;
    final file = result.files.first;
    if (file.path == null) return;
    setState(() {
      _selectedFilePath = file.path;
      _selectedFileName = file.name;
      _logs        = '';
      _logVisible  = false;
      _outputPath  = null;
      _success     = false;
      _elapsed     = '00:00';
    });
  }

  // ── Scroll to log ─────────────────────────────────────────────────────────

  void _scrollToLog() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final ctx = _logPanelKey.currentContext;
      if (ctx == null) return;
      Scrollable.ensureVisible(ctx,
          duration: const Duration(milliseconds: 480), curve: Curves.easeInOut);
    });
  }

  void _scrollLogToBottom() {
    if (!_autoScroll) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_logScrollCtrl.hasClients) {
        _logScrollCtrl.animateTo(
          _logScrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  // ── Run tool ──────────────────────────────────────────────────────────────

  Future<void> _runTool() async {
    if (_selectedFilePath == null) {
      _showSnack('Pick a file first', icon: Icons.folder_open_rounded, color: const Color(0xFFf59e0b));
      return;
    }

    final hasPermission = await PermissionHelper.ensureStorage(context, accent: cfg.accent);
    if (!hasPermission) {
      _showSnack('Storage permission is required',
          icon: Icons.lock_rounded, color: const Color(0xFFef4444));
      return;
    }

    final outputDir = await StorageHelper.buildOutputDir(prefix: cfg.toolId);

    setState(() {
      _isProcessing = true;
      _logs         = '⚙ Starting ${cfg.toolName}...\n';
      _logVisible   = true;
      _outputPath   = null;
      _success      = false;
    });
    _logCtrl.forward(from: 0);
    _scrollToLog();
    _startTimer();

    try {
      final result = await HbcChannel.dexToolsRun(
        tool:      cfg.toolId,
        filePath:  _selectedFilePath!,
        outputDir: outputDir,
      );

      _stopTimer();

      final ok      = result['success'] == true;
      final outPath = result['outputPath'] as String?;
      final errMsg  = result['error'] as String?;
      final logStr  = (result['log'] as String?) ?? '';

      if (mounted) {
        setState(() {
          _isProcessing = false;
          _success      = ok;
          _outputPath   = outPath;
          _logs += logStr.isNotEmpty ? '\n$logStr' : '';
          _logs += ok
              ? '\n✅ Done in $_elapsed — ${outPath?.split('/').last ?? ''}'
              : '\n❌ Failed: ${errMsg ?? 'unknown error'}';
        });
        _scrollLogToBottom();

        if (ok) {
          _showSnack('Conversion complete!',
              icon: Icons.check_circle_rounded, color: const Color(0xFF22c55e));
        } else {
          _showSnack(errMsg ?? 'Conversion failed',
              icon: Icons.error_rounded, color: const Color(0xFFef4444));
        }
      }
    } catch (e) {
      _stopTimer();
      if (mounted) {
        setState(() {
          _isProcessing = false;
          _logs += '\n❌ Error: $e';
        });
        _showSnack('Error: $e', icon: Icons.error_rounded, color: const Color(0xFFef4444));
      }
    }
  }

  // ── Back pressed ──────────────────────────────────────────────────────────

  Future<void> _onBackPressed() async {
    if (_isProcessing) {
      final leave = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: const Color(0xFF12102a),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
            side: BorderSide(color: cfg.accent, width: 1),
          ),
          title: Text('Leave ${cfg.toolName}?',
              style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700)),
          content: const Text(
            'Conversion is running.\nLeaving won\'t cancel it — come back to see results.',
            style: TextStyle(color: Color(0xFFa0a0b8), fontSize: 13, height: 1.6),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Stay', style: TextStyle(color: Color(0xFF6b7280))),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: cfg.accent,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              ),
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Leave'),
            ),
          ],
        ),
      );
      if (leave == true && mounted) Navigator.of(context).pop();
    } else {
      Navigator.of(context).pop();
    }
  }

  // ── Build ─────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) { if (!didPop) _onBackPressed(); },
      child: Scaffold(
        backgroundColor: ThemeProvider().current.scaffoldBg,
        appBar: AppBar(
          centerTitle: true,
          title: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              SvgPicture.asset(cfg.iconAsset, width: 18, height: 18),
              const SizedBox(width: 8),
              Text(cfg.toolName,
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
            ],
          ),
          iconTheme: const IconThemeData(color: Colors.white),
          flexibleSpace: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [ThemeProvider().current.appBarBg, const Color(0xFF0a0a1a)],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
            ),
          ),
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(1),
            child: Container(height: 1, color: cfg.accent.withOpacity(0.25)),
          ),
        ),
        body: SingleChildScrollView(
          controller: _pageScrollCtrl,
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildHeader(),
              const SizedBox(height: 20),
              _buildFilePicker(),
              const SizedBox(height: 14),
              _buildActionRow(),
              if (_logVisible) ...[
                const SizedBox(height: 16),
                _buildLogPanel(),
              ],
              if (_outputPath != null && !_isProcessing) ...[
                const SizedBox(height: 14),
                _buildOutputSection(),
              ],
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  // ── Header ────────────────────────────────────────────────────────────────

  Widget _buildHeader() {
    return AnimatedBuilder(
      animation: _pulseAnim,
      builder: (_, __) {
        final p = _pulseAnim.value;
        return Container(
          padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: RadialGradient(
              center: Alignment.center,
              radius: 1.2,
              colors: [
                cfg.accent.withOpacity(0.05 + 0.04 * p),
                ThemeProvider().current.scaffoldBg,
              ],
            ),
            border: Border.all(color: cfg.accent.withOpacity(0.10 + 0.08 * p)),
          ),
          child: Row(
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  AnimatedBuilder(
                    animation: _spinCtrl,
                    builder: (_, __) => Transform.rotate(
                      angle: _spinCtrl.value * math.pi * 2,
                      child: CustomPaint(
                        size: const Size(52, 52),
                        painter: _OrbitPainter(color: cfg.accent, opacity: 0.2 + 0.2 * p),
                      ),
                    ),
                  ),
                  SvgPicture.asset(cfg.iconAsset, width: 26, height: 26),
                ],
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      cfg.toolName,
                      style: TextStyle(
                        color: cfg.accent,
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      cfg.subtitle,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.55),
                        fontSize: 12,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      cfg.outputDescription,
                      style: TextStyle(
                        color: cfg.accent.withOpacity(0.55),
                        fontSize: 10,
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ── File Picker ───────────────────────────────────────────────────────────

  Widget _buildFilePicker() {
    final hasFile = _selectedFileName != null;
    return GestureDetector(
      onTap: _isProcessing ? null : _pickFile,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: const Color(0xFF111122),
          border: Border.all(
            color: hasFile ? cfg.accent.withOpacity(0.30) : const Color(0xFF1e1e3a),
          ),
        ),
        child: Row(
          children: [
            Icon(
              hasFile ? Icons.description_rounded : Icons.upload_file_rounded,
              color: hasFile ? cfg.accent : const Color(0xFF4b5563),
              size: 28,
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    hasFile ? _selectedFileName! : cfg.inputLabel,
                    style: TextStyle(
                      color: hasFile ? Colors.white : const Color(0xFF6b7280),
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (hasFile && _selectedFilePath != null)
                    Text(_selectedFilePath!,
                        style: const TextStyle(color: Color(0xFF4b5563), fontSize: 10),
                        overflow: TextOverflow.ellipsis),
                  if (!hasFile)
                    Text(
                      'Accepted: ${cfg.acceptedExtensions.map((e) => '.$e').join(', ')}',
                      style: const TextStyle(color: Color(0xFF4b5563), fontSize: 10),
                    ),
                ],
              ),
            ),
            if (hasFile)
              GestureDetector(
                onTap: _isProcessing ? null : () => setState(() {
                  _selectedFilePath = null;
                  _selectedFileName = null;
                  _outputPath = null;
                  _logs = '';
                  _logVisible = false;
                  _success = false;
                }),
                child: Icon(Icons.close_rounded,
                    color: const Color(0xFF6b7280).withOpacity(0.6), size: 20),
              ),
          ],
        ),
      ),
    );
  }

  // ── Action row ────────────────────────────────────────────────────────────

  Widget _buildActionRow() {
    return Row(
      children: [
        Expanded(
          child: SizedBox(
            height: 50,
            child: ElevatedButton.icon(
              onPressed: _isProcessing ? null : _runTool,
              style: ElevatedButton.styleFrom(
                backgroundColor: cfg.accent,
                foregroundColor: Colors.white,
                disabledBackgroundColor: cfg.accent.withOpacity(0.35),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)),
                elevation: 0,
              ),
              icon: _isProcessing
                  ? SizedBox(
                      width: 16, height: 16,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: Colors.white.withOpacity(0.7)),
                    )
                  : const Icon(Icons.play_arrow_rounded, size: 20),
              label: Text(
                _isProcessing ? 'Converting... $_elapsed' : 'Convert',
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ── Log panel ─────────────────────────────────────────────────────────────

  Widget _buildLogPanel() {
    return FadeTransition(
      opacity: _logFade,
      child: Container(
        key: _logPanelKey,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: const Color(0xFF080815),
          border: Border.all(color: cfg.accent.withOpacity(0.12)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              child: Row(children: [
                Icon(Icons.terminal_rounded, color: cfg.accent, size: 16),
                const SizedBox(width: 8),
                Text('Output Log',
                    style: TextStyle(color: cfg.accent, fontSize: 12, fontWeight: FontWeight.w600)),
                const Spacer(),
                if (_isProcessing)
                  Text(_elapsed,
                      style: const TextStyle(
                          color: Color(0xFF6b7280), fontSize: 11, fontFamily: 'monospace')),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: () => setState(() => _autoScroll = !_autoScroll),
                  child: Icon(_autoScroll ? Icons.vertical_align_bottom_rounded : Icons.pause_rounded,
                      color: const Color(0xFF4b5563), size: 16),
                ),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: () {
                    Clipboard.setData(ClipboardData(text: _logs));
                    _showSnack('Log copied', icon: Icons.copy_rounded, color: cfg.accent);
                  },
                  child: const Icon(Icons.copy_rounded, color: Color(0xFF4b5563), size: 16),
                ),
              ]),
            ),
            Container(height: 1, color: cfg.accent.withOpacity(0.08)),
            SizedBox(
              height: 220,
              child: Scrollbar(
                controller: _logScrollCtrl,
                child: SingleChildScrollView(
                  controller: _logScrollCtrl,
                  padding: const EdgeInsets.all(12),
                  child: SelectableText(
                    _logs.isEmpty ? 'Waiting for output...' : _logs,
                    style: TextStyle(
                      color: _logs.isEmpty
                          ? const Color(0xFF3a3a5e)
                          : Colors.white.withOpacity(0.75),
                      fontSize: 11,
                      fontFamily: 'monospace',
                      height: 1.6,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Output section ────────────────────────────────────────────────────────

  Widget _buildOutputSection() {
    final outFile = File(_outputPath!);
    final fileName = _outputPath!.split('/').last;
    final sizeBytes = outFile.existsSync() ? outFile.lengthSync() : 0;
    final sizeStr = sizeBytes > 1024 * 1024
        ? '${(sizeBytes / 1024 / 1024).toStringAsFixed(1)} MB'
        : '${(sizeBytes / 1024).toStringAsFixed(1)} KB';

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: _success ? const Color(0xFF052e16) : const Color(0xFF2d0000),
        border: Border.all(
          color: (_success ? const Color(0xFF22c55e) : const Color(0xFFef4444)).withOpacity(0.25),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Icon(
              _success ? Icons.check_circle_rounded : Icons.error_rounded,
              color: _success ? const Color(0xFF22c55e) : const Color(0xFFef4444),
              size: 18,
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                _success ? 'Conversion Complete' : 'Conversion Failed',
                style: TextStyle(
                  color: _success ? const Color(0xFF22c55e) : const Color(0xFFef4444),
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ]),
          if (_success) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.black.withOpacity(0.3),
              ),
              child: Row(children: [
                const Icon(Icons.folder_rounded, color: Color(0xFF22c55e), size: 18),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(fileName,
                        style: const TextStyle(
                            color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600),
                        overflow: TextOverflow.ellipsis),
                    Text(sizeStr,
                        style: const TextStyle(color: Color(0xFF6b7280), fontSize: 10)),
                  ]),
                ),
              ]),
            ),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                child: _OutBtn(
                  icon: Icons.copy_rounded,
                  label: 'Copy Path',
                  color: cfg.accent,
                  onTap: () {
                    Clipboard.setData(ClipboardData(text: _outputPath!));
                    _showSnack('Path copied to clipboard',
                        icon: Icons.copy_rounded, color: cfg.accent);
                  },
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _OutBtn(
                  icon: Icons.share_rounded,
                  label: 'Share',
                  color: const Color(0xFF6b7280),
                  onTap: () async {
                    try {
                      await Share.shareXFiles([XFile(_outputPath!)]);
                    } catch (_) {
                      _showSnack('Saved to: $_outputPath',
                          icon: Icons.info_rounded, color: cfg.accent);
                    }
                  },
                ),
              ),
            ]),
          ],
        ],
      ),
    );
  }
}

// ── Output button ─────────────────────────────────────────────────────────

class _OutBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;
  const _OutBtn({required this.icon, required this.label, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 11),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: color.withOpacity(0.10),
          border: Border.all(color: color.withOpacity(0.25)),
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, color: color, size: 16),
          const SizedBox(width: 6),
          Text(label,
              style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600)),
        ]),
      ),
    );
  }
}

// ── Orbit painter (decorative) ────────────────────────────────────────────

class _OrbitPainter extends CustomPainter {
  final Color color;
  final double opacity;
  const _OrbitPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withOpacity(opacity)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2;
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(size.width / 2, size.height / 2),
        width: size.width,
        height: size.height * 0.42,
      ),
      paint,
    );
  }

  @override
  bool shouldRepaint(_OrbitPainter old) => old.color != color || old.opacity != opacity;
}
