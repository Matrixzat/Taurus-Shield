import '../utils/theme_provider.dart';
import '../widgets/guide_modal.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/hbc_channel.dart';
import '../utils/storage_helper.dart';
import '../utils/permission_helper.dart';
import '../utils/search_history.dart';
import 'asm_editor_screen.dart';

class BlutterScreen extends StatefulWidget {
  const BlutterScreen({super.key});

  @override
  State<BlutterScreen> createState() => _BlutterScreenState();
}

class _BlutterScreenState extends State<BlutterScreen>
    with TickerProviderStateMixin {
  // State
  bool    _restoringState  = true;   // true while _checkCloudState is running
  String? _selectedFilePath;
  String? _selectedFileName;
  // ignore: unused_field
  String? _fileExt;
  bool    _isProcessing    = false;
  bool    _logVisible      = false;
  String  _logs            = '';
  String? _outputDir;
  String? _dartVersion;
  int     _downloadProgress = -1;   // -1 = hidden, 0-100 = downloading
  bool    _autoScroll      = true;
  String? _manualDartVersion;       // user-supplied version override
  StreamSubscription<String>? _streamSub;
  // Timer
  final Stopwatch _stopwatch = Stopwatch();
  Timer? _tickTimer;
  String _elapsed = '00:00';

  // ── PageView (patcher ↔ ASM editor) ──────────────────────────────────────
  late final PageController _patcherPageCtrl;
  int _patcherPageIdx = 0;

  // ── ASM editor full-screen ────────────────────────────────────────────────
  bool          _asmFullScreen     = false;
  VoidCallback? _exitAsmFullScreen;
  // Back-press handler registered by AsmEditorTab
  bool Function()? _asmBackHandler;

  // ── libapp.so patcher state ───────────────────────────────────────────────
  String?  _libappSoPath;
  bool     _libappSoLoading = false;
  bool     _folderMode      = false;   // user picked an existing dump folder
  String?  _pickedFolderName;

  final TextEditingController _soSearchCtrl = TextEditingController();
  bool     _soSearching   = false;
  late FocusNode _soSearchFocusNode;
  List<String>   _soSearchHistory   = [];
  bool           _showSearchHistory = false;
  List<Map<String, dynamic>> _soFileGroups = [];
  Set<String>                _markedOffsets = {};
  Set<String>                _expandedFiles = {};
  bool     _soApplying    = false;
  String?  _patchedSoPath;

  // Scroll
  final ScrollController _logScrollCtrl  = ScrollController();
  final ScrollController _pageScrollCtrl = ScrollController();
  final GlobalKey        _logPanelKey    = GlobalKey();

  // Animations
  late final AnimationController _pulseCtrl;
  late final AnimationController _orbitCtrl;
  late final AnimationController _scanCtrl;
  late final AnimationController _logCtrl;
  late final Animation<double> _pulseAnim;
  late final Animation<double> _logFade;
  late final Animation<double> _scanAnim;

  @override
  void initState() {
    super.initState();

    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _orbitCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 5000),
    )..repeat();

    _scanCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2200),
    )..repeat();

    _logCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 400),
    );

    _pulseAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );

    _logFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _logCtrl, curve: Curves.easeOut),
    );

    _scanAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _scanCtrl, curve: Curves.easeInOut),
    );

    _patcherPageCtrl = PageController();

    _soSearchFocusNode = FocusNode();
    _soSearchFocusNode.addListener(() async {
      if (_soSearchFocusNode.hasFocus) {
        final hist = await SearchHistory.load(SearchHistory.keyPatcher);
        if (mounted) setState(() { _soSearchHistory = hist; _showSearchHistory = hist.isNotEmpty; });
      } else {
        Future.delayed(const Duration(milliseconds: 200), () {
          if (mounted && !_soSearchFocusNode.hasFocus) {
            setState(() => _showSearchHistory = false);
          }
        });
      }
    });

    _checkCloudState();
  }

  Timer? _pollTimer;

  Future<void> _checkCloudState() async {
    try {
      final state = await HbcChannel.blutterCloudState();
      final running = state['running'] == true;
      final status  = (state['status'] as String?) ?? '';
      final logs    = (state['logs'] as String?) ?? '';
      final filePath = (state['filePath'] as String?) ?? '';
      final outputDir = (state['outputDir'] as String?) ?? '';

      if (running && mounted) {
        setState(() {
          _restoringState = false;
          _isProcessing = true;
          _logVisible = true;
          _logs = logs;
          _selectedFilePath = filePath.isNotEmpty ? filePath : _selectedFilePath;
          _selectedFileName = filePath.isNotEmpty ? filePath.split('/').last : _selectedFileName;
        });
        _logCtrl.forward(from: 0);
        if (!_stopwatch.isRunning) _startTimer();
        _startPollingCloudState();
      } else if (status == 'success' && mounted) {
        final savedPageIdx = (state['pageIdx'] as int?) ?? 0;
        // Validate the saved dump folder still exists on disk.
        // If it doesn't (e.g. after a fresh reinstall or the user deleted it),
        // wipe the stale state and show the welcome screen instead.
        final dirValid = outputDir.isNotEmpty && Directory(outputDir).existsSync();
        if (!dirValid && outputDir.isNotEmpty) {
          try { await HbcChannel.blutterClearState(); } catch (_) {}
          if (mounted) setState(() => _restoringState = false);
          await _restoreSession();
          return;
        }
        setState(() {
          _restoringState = false;
          _isProcessing = false;
          _logVisible = true;
          _logs = logs;
          _outputDir = dirValid ? outputDir : null;
          _selectedFilePath = filePath.isNotEmpty ? filePath : _selectedFilePath;
          _selectedFileName = filePath.isNotEmpty ? filePath.split('/').last : _selectedFileName;
        });
        _logCtrl.forward(from: 0);
        if (dirValid && _selectedFilePath != null) {
          _ensureLibappSo(outputDir, _selectedFilePath!);
        }
        _showSnack('Analysis complete',
            icon: Icons.check_circle_rounded, color: const Color(0xFF22c55e));
        // Restore the tab the user was on before the app restarted
        if (dirValid && savedPageIdx > 0) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted && _patcherPageCtrl.hasClients) {
              _patcherPageCtrl.jumpToPage(savedPageIdx);
              setState(() => _patcherPageIdx = savedPageIdx);
            }
          });
        }
      } else if (status == 'error' && logs.isNotEmpty && mounted) {
        final error = (state['error'] as String?) ?? 'Analysis failed';
        setState(() {
          _restoringState = false;
          _isProcessing = false;
          _logVisible = true;
          _logs = logs;
          _selectedFilePath = filePath.isNotEmpty ? filePath : _selectedFilePath;
          _selectedFileName = filePath.isNotEmpty ? filePath.split('/').last : _selectedFileName;
        });
        _logCtrl.forward(from: 0);
        _showSnack(error,
            icon: Icons.error_rounded, color: const Color(0xFFef4444));
      } else {
        // No cloud analysis state — restore from local SharedPreferences session
        await _restoreSession();
        if (mounted) setState(() => _restoringState = false);
      }
    } catch (_) {
      if (mounted) setState(() => _restoringState = false);
    }
  }

  int _pollFailures = 0;

  void _startPollingCloudState() {
    _pollTimer?.cancel();
    _streamSub?.cancel();
    _pollFailures = 0;

    _streamSub = HbcChannel.logStream.listen((line) {
      if (!mounted) return;
      if (line.startsWith('DOWNLOAD_PROGRESS:')) {
        final pct = int.tryParse(line.split(':').last) ?? -1;
        setState(() => _downloadProgress = pct);
        return;
      }
      if (line == '__TAURUS_DONE__') {
        _pollTimer?.cancel();
        _checkCloudState();
        return;
      }
    }, onDone: () {}, onError: (_) {});

    _pollTimer = Timer.periodic(const Duration(seconds: 25), (timer) async {
      if (!mounted) { timer.cancel(); return; }
      try {
        final state = await HbcChannel.blutterCloudState();
        final running   = state['running'] == true;
        final logs      = (state['logs'] as String?) ?? '';
        final status    = (state['status'] as String?) ?? '';
        final outputDir = (state['outputDir'] as String?) ?? '';
        final filePath  = (state['filePath']  as String?) ?? '';

        if (mounted) {
          final logsChanged = logs != _logs;
          setState(() {
            _logs = logs;
            if (!running) {
              _isProcessing = false;
              _downloadProgress = -1;
              if (status == 'success') {
                _outputDir = outputDir.isNotEmpty ? outputDir : null;
              }
            }
          });

          if (logsChanged && _autoScroll) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (_logScrollCtrl.hasClients) {
                _logScrollCtrl.animateTo(
                  _logScrollCtrl.position.maxScrollExtent,
                  duration: const Duration(milliseconds: 180),
                  curve: Curves.easeOut,
                );
              }
            });
          }
        }

        if (!running) {
          timer.cancel();
          final totalTime = _stopTimer();
          if (mounted) {
            final success = status == 'success';
            setState(() {
              _logs += '\n${success ? "Completed" : "Failed"} in $totalTime\n';
            });
            _showSnack(
              success ? 'Analysis complete  ($totalTime)' : (state['error'] as String?) ?? 'Analysis failed',
              icon: success ? Icons.check_circle_rounded : Icons.error_rounded,
              color: success ? const Color(0xFF22c55e) : const Color(0xFFef4444),
            );
            if (success && outputDir.isNotEmpty) {
              // Use in-memory path first, fall back to persisted state filePath.
              final zipSrc = _selectedFilePath ?? (filePath.isNotEmpty ? filePath : '');
              // If libapp.so already pre-extracted (at dump start), step 1
              // of so_copy_lib finds it instantly. zipSrc is the safety fallback.
              _ensureLibappSo(outputDir, zipSrc);
            }
          }
        }
        _pollFailures = 0;
      } catch (_) {
        _pollFailures++;
        if (_pollFailures >= 10 && mounted) {
          timer.cancel();
          _stopTimer();
          setState(() {
            _isProcessing = false;
            _logs += '\nLost connection to background service.\n';
          });
          _showSnack('Lost connection to service',
              icon: Icons.error_rounded, color: const Color(0xFFef4444));
        }
      }
    });
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _tickTimer?.cancel();
    _stopwatch.stop();
    _streamSub?.cancel();
    _soSearchCtrl.dispose();
    _soSearchFocusNode.dispose();
    _pulseCtrl.dispose();
    _orbitCtrl.dispose();
    _scanCtrl.dispose();
    _logCtrl.dispose();
    _logScrollCtrl.dispose();
    _pageScrollCtrl.dispose();
    _patcherPageCtrl.dispose();
    super.dispose();
  }

  // ── File picking ─────────────────────────────────────────────────────────

  // ── Reset ────────────────────────────────────────────────────────────────
  void _confirmReset() {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1e293b),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Reset', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        content: const Text(
          'Clear all paths, results, and selections and return to the start screen?',
          style: TextStyle(color: Colors.white70, fontSize: 13),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text('Cancel', style: TextStyle(color: Colors.white.withOpacity(0.5))),
          ),
          TextButton(
            onPressed: () { Navigator.pop(ctx); _resetAll(); },
            child: const Text('Reset', style: TextStyle(color: Color(0xFFef4444), fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  // ── Session persistence (survives navigating away and back) ─────────────────
  static const _kSessFile       = 'blutter_sess_filePath';
  static const _kSessFileName   = 'blutter_sess_fileName';
  static const _kSessFileExt    = 'blutter_sess_fileExt';
  static const _kSessOutputDir  = 'blutter_sess_outputDir';
  static const _kSessLibappSo   = 'blutter_sess_libappSoPath';
  static const _kSessFolderMode = 'blutter_sess_folderMode';
  static const _kSessFolderName = 'blutter_sess_folderName';

  Future<void> _saveSession() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString(_kSessFile,       _selectedFilePath ?? '');
      await p.setString(_kSessFileName,   _selectedFileName ?? '');
      await p.setString(_kSessFileExt,    _fileExt          ?? '');
      await p.setString(_kSessOutputDir,  _outputDir        ?? '');
      await p.setString(_kSessLibappSo,   _libappSoPath     ?? '');
      await p.setBool  (_kSessFolderMode, _folderMode);
      await p.setString(_kSessFolderName, _pickedFolderName ?? '');
    } catch (_) {}
  }

  Future<void> _clearSession() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.remove(_kSessFile);
      await p.remove(_kSessFileName);
      await p.remove(_kSessFileExt);
      await p.remove(_kSessOutputDir);
      await p.remove(_kSessLibappSo);
      await p.remove(_kSessFolderMode);
      await p.remove(_kSessFolderName);
    } catch (_) {}
  }

  Future<void> _restoreSession() async {
    try {
      final p = await SharedPreferences.getInstance();
      final filePath   = p.getString(_kSessFile)       ?? '';
      final fileName   = p.getString(_kSessFileName)   ?? '';
      final fileExt    = p.getString(_kSessFileExt)    ?? '';
      final outputDir  = p.getString(_kSessOutputDir)  ?? '';
      final libappSo   = p.getString(_kSessLibappSo)   ?? '';
      final folderMode = p.getBool  (_kSessFolderMode) ?? false;
      final folderName = p.getString(_kSessFolderName) ?? '';
      if (!mounted) return;
      if (filePath.isEmpty && outputDir.isEmpty) return; // nothing to restore
      setState(() {
        if (filePath.isNotEmpty) {
          _selectedFilePath = filePath;
          _selectedFileName = fileName.isNotEmpty ? fileName : filePath.split('/').last;
          _fileExt          = fileExt.isNotEmpty ? fileExt : null;
        }
        if (outputDir.isNotEmpty) {
          _outputDir = outputDir;
          if (libappSo.isNotEmpty) _libappSoPath = libappSo;
          if (folderMode) {
            _folderMode       = true;
            _pickedFolderName = folderName.isNotEmpty ? folderName : null;
          }
        }
      });
      // If folder mode or direct .so mode, try to find libapp.so
      if (outputDir.isNotEmpty && libappSo.isEmpty && folderMode) {
        _ensureLibappSo(outputDir, '');
      }
    } catch (_) {}
  }

  void _resetAll() {
    _tickTimer?.cancel();
    _tickTimer = null;
    _pollTimer?.cancel();
    _stopwatch.reset();
    _streamSub?.cancel();
    _streamSub = null;
    _soSearchCtrl.clear();
    if (_patcherPageCtrl.hasClients) _patcherPageCtrl.jumpToPage(0);
    setState(() {
      _patcherPageIdx    = 0;
      _selectedFilePath  = null;
      _selectedFileName  = null;
      _fileExt           = null;
      _isProcessing      = false;
      _logVisible        = false;
      _logs              = '';
      _outputDir         = null;
      _dartVersion       = null;
      _downloadProgress  = -1;
      _autoScroll        = true;
      _manualDartVersion = null;
      _elapsed           = '00:00';
      _libappSoPath      = null;
      _libappSoLoading   = false;
      _folderMode        = false;
      _pickedFolderName  = null;
      _soSearching       = false;
      _soFileGroups      = [];
      _markedOffsets     = {};
      _expandedFiles     = {};
      _soApplying        = false;
      _patchedSoPath     = null;
    });
    _clearSession();
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.any,
      dialogTitle: 'Select arm64-v8a.zip  OR  libapp.so directly',
    );
    if (result == null || result.files.isEmpty) return;

    final file = result.files.first;
    final ext  = file.name.split('.').last.toLowerCase();

    if (ext != 'zip' && ext != 'so') {
      _showSnack(
        'Select a .zip (arm64-v8a) or libapp.so directly',
        icon: Icons.error_rounded,
        color: const Color(0xFFef4444),
      );
      return;
    }

    _stopwatch.reset();
    _tickTimer?.cancel();
    _tickTimer = null;
    _pollTimer?.cancel();
    setState(() {
      _selectedFilePath  = file.path;
      _selectedFileName  = file.name;
      _fileExt           = ext;
      _logs              = '';
      _logVisible        = false;
      _outputDir         = null;
      _dartVersion       = null;
      _downloadProgress  = -1;
      _elapsed           = '00:00';
      _manualDartVersion = null;
      _isProcessing      = false;
      _libappSoPath      = null;
      _patchedSoPath     = null;
      _soFileGroups      = [];
      _markedOffsets     = {};
      _folderMode        = false;
      _pickedFolderName  = null;
    });

    if (ext == 'so') {
      // Direct patch mode — no Blutter dump needed
      final soPath = file.path!;
      final soDir  = soPath.substring(0, soPath.lastIndexOf('/'));
      setState(() {
        _libappSoPath = soPath;
        _outputDir    = soDir;
      });
    } else {
      try { await HbcChannel.blutterClearState(); } catch (_) {}
    }
    _saveSession();
  }

  // ── Folder picker (existing dump output) ─────────────────────────────────

  Future<void> _pickFolder() async {
    final dirPath = await FilePicker.platform.getDirectoryPath(
      dialogTitle: 'Select your Blutter output folder (contains libapp.so)',
    );
    if (dirPath == null) return;

    _pollTimer?.cancel();
    final folderName = dirPath.split('/').last;
    setState(() {
      _folderMode       = true;
      _pickedFolderName = folderName;
      _outputDir        = dirPath;
      _libappSoPath     = null;
      _patchedSoPath    = null;
      _soFileGroups     = [];
      _markedOffsets    = {};
      _selectedFilePath = null;
      _selectedFileName = null;
      _fileExt          = null;
      _logs             = '';
      _logVisible       = false;
      _isProcessing     = false;
    });
    _saveSession();
    _ensureLibappSo(dirPath, '');
  }

  // ── Manual Dart version dialog ────────────────────────────────────────────

  Future<void> _showManualVersionDialog({bool fromFailure = false}) async {
    final ctrl = TextEditingController(text: _manualDartVersion ?? '');
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1a1a2e),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text(
          'Enter Dart Version',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (fromFailure) ...[
              const Text(
                'Auto-detection failed on this binary (stripped release build).\n'
                'Enter the Dart SDK version used to compile the app.',
                style: TextStyle(color: Color(0xFFa0a0b0), fontSize: 13),
              ),
              const SizedBox(height: 12),
            ],
            const Text(
              'Format: X.Y.Z  (e.g. 3.4.0)',
              style: TextStyle(color: Color(0xFF7070a0), fontSize: 12),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: ctrl,
              autofocus: true,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: '3.4.0',
                hintStyle: const TextStyle(color: Color(0xFF555570)),
                filled: true,
                fillColor: const Color(0xFF0d0d1a),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: Color(0xFF6c63ff)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: Color(0xFF6c63ff), width: 2),
                ),
              ),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              inputFormatters: [
                FilteringTextInputFormatter.allow(RegExp(r'[\d\.]')),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel',
                style: TextStyle(color: Color(0xFF7070a0))),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF6c63ff),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8)),
            ),
            onPressed: () {
              final v = ctrl.text.trim();
              final parts = v.split('.');
              if (parts.length == 3 &&
                  parts.every((p) => int.tryParse(p) != null)) {
                Navigator.pop(ctx);
                setState(() => _manualDartVersion = v);
                if (fromFailure && _selectedFilePath != null) {
                  _runAnalysis();
                }
              } else {
                ScaffoldMessenger.of(ctx).showSnackBar(
                  const SnackBar(
                    content: Text('Invalid format — use X.Y.Z (e.g. 3.4.0)'),
                    backgroundColor: Color(0xFFef4444),
                  ),
                );
              }
            },
            child: const Text('Use This Version'),
          ),
        ],
      ),
    );
    ctrl.dispose();
  }

  // ── Elapsed timer ────────────────────────────────────────────────────────

  String _formatDuration(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    if (d.inHours > 0) {
      final h = d.inHours.toString().padLeft(2, '0');
      return '$h:$m:$s';
    }
    return '$m:$s';
  }

  void _startTimer() {
    _stopwatch.reset();
    _stopwatch.start();
    _elapsed = '00:00';
    _tickTimer?.cancel();
    _tickTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() => _elapsed = _formatDuration(_stopwatch.elapsed));
    });
  }

  String _stopTimer() {
    _stopwatch.stop();
    _tickTimer?.cancel();
    _tickTimer = null;
    final final_ = _formatDuration(_stopwatch.elapsed);
    setState(() => _elapsed = final_);
    return final_;
  }

  // ── Processing ───────────────────────────────────────────────────────────

  Future<void> _cancelOperation() async {
    _pollTimer?.cancel();
    _tickTimer?.cancel();
    _streamSub?.cancel();
    await HbcChannel.blutterCancel();
    if (!mounted) return;
    setState(() { _isProcessing = false; });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Operation cancelled'),
        backgroundColor: Color(0xFF7f1d1d),
        duration: Duration(seconds: 3),
      ),
    );
  }

  Future<void> _runAnalysis() async {
    if (_selectedFilePath == null) {
      _showSnack('Pick a file first',
          icon: Icons.folder_open_rounded, color: const Color(0xFFf59e0b));
      return;
    }

    final hasPermission = await PermissionHelper.ensureStorage(
      context,
      accent: ThemeProvider().current.highlightColor,
    );
    if (!hasPermission) {
      _showSnack('Storage permission is required',
          icon: Icons.lock_rounded, color: const Color(0xFFef4444));
      return;
    }

    final outputDir = await StorageHelper.buildOutputDir(prefix: 'blutter');

    setState(() {
      _isProcessing     = true;
      _logs             = '';
      _logVisible       = true;
      _dartVersion      = null;
      _downloadProgress = -1;
    });
    _logCtrl.forward(from: 0);
    _scrollToLogPanel();
    _startTimer();

    try {
      final result = await HbcChannel.blutterAnalyze(
        filePath:          _selectedFilePath!,
        fileName:          _selectedFileName ?? _selectedFilePath!.split('/').last,
        outputDir:         outputDir,
        manualDartVersion: _manualDartVersion,
      );

      if (result['started'] == true) {
        // Pre-extract libapp.so immediately — the zip is definitely readable now,
        // before 4+ minutes pass and before any state ambiguity can occur.
        setState(() => _outputDir = outputDir);
        _ensureLibappSo(outputDir, _selectedFilePath!);
        await Future.delayed(const Duration(seconds: 1));
        _startPollingCloudState();
      } else {
        _stopTimer();
        final errMsg = (result['error'] as String?) ?? 'Failed to start analysis';
        if (mounted) {
          setState(() { _isProcessing = false; });
          _showSnack(errMsg,
              icon: Icons.error_rounded, color: const Color(0xFFef4444));
        }
      }
    } catch (e) {
      _stopTimer();
      if (mounted) {
        setState(() {
          _isProcessing     = false;
          _downloadProgress = -1;
          _logs += '\nError: $e\n';
        });
        _showSnack('Error: $e',
            icon: Icons.error_rounded, color: const Color(0xFFef4444));
      }
    }
  }

  void _scrollToLogPanel() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final ctx = _logPanelKey.currentContext;
      if (ctx == null) return;
      Scrollable.ensureVisible(
        ctx,
        duration: const Duration(milliseconds: 480),
        curve: Curves.easeInOut,
        alignment: 0.0,
      );
    });
  }

  void _showSnack(String msg,
      {required IconData icon, required Color color}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        Icon(icon, color: Colors.white, size: 18),
        const SizedBox(width: 10),
        Expanded(
            child: Text(msg,
                style: const TextStyle(color: Colors.white, fontSize: 13))),
      ]),
      backgroundColor: color.withOpacity(0.9),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      duration: const Duration(seconds: 3),
    ));
  }

  // ── Back confirmation dialog ──────────────────────────────────────────────

  Future<void> _onBackPressed() async {
    // 1. Exit fullscreen first — no dialog needed
    if (_asmFullScreen) {
      _exitAsmFullScreen?.call();
      return;
    }
    // 2. If ASM EDITOR tab is active, let the editor step back through its states
    if (_patcherPageIdx == 1 && (_asmBackHandler?.call() ?? false)) return;
    // 3. Nothing left to step back into — confirm before leaving the screen
    final leave = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: Color(0xFF12102a),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(color: ThemeProvider().current.highlightColor, width: 1),
        ),
        title: Row(
          children: [
            Container(
              padding: EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: ThemeProvider().current.highlightColor.withOpacity(0.12),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(Icons.flutter_dash_rounded,
                  color: ThemeProvider().current.highlightColor, size: 20),
            ),
            const SizedBox(width: 12),
            const Expanded(
              child: Text(
                'Leave Blutter?',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w700),
              ),
            ),
          ],
        ),
        content: const Text(
          'Are you sure you want to go back? Any active analysis will continue running in the background.',
          style: TextStyle(
              color: Color(0xFF9ca3af), fontSize: 13, height: 1.6),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Stay',
                style: TextStyle(color: Color(0xFF6b7280))),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: ThemeProvider().current.highlightColor,
              foregroundColor: ThemeProvider().current.scaffoldBg,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
            ),
            child: const Text('Go Back',
                style: TextStyle(fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
    if (leave == true && mounted) {
      Navigator.pop(context);
    }
  }

  // ── Build ─────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _onBackPressed();
      },
      child: Scaffold(
      
      appBar: _asmFullScreen ? null : AppBar(
        centerTitle: true,
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _BlutterAppBarIcon(animation: _pulseAnim),
            const SizedBox(width: 10),
            const Text('BLUTTER'),
            const SizedBox(width: 10),
            _BlutterAppBarIcon(animation: _pulseAnim, mirrored: true),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.menu_book_rounded, color: Colors.white70, size: 20),
            tooltip: 'How to Use',
            onPressed: () => showGuideModal(context, initialIndex: 2, singleTool: true),
          ),
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: Colors.white70, size: 22),
            tooltip: 'Reset',
            onPressed: _confirmReset,
          ),
        ],
        iconTheme: const IconThemeData(color: Colors.white),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [ThemeProvider().current.appBarBg, Color(0xFF0a1a20)],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(
            height: 1,
            color: ThemeProvider().current.highlightColor.withOpacity(0.25),
          ),
        ),
      ),
      body: _restoringState
          ? Center(child: CircularProgressIndicator(color: ThemeProvider().current.primary, strokeWidth: 2))
          : (!_isProcessing && _outputDir != null)
          ? _buildPatcherWithEditorView()
          : SingleChildScrollView(
        controller: _pageScrollCtrl,
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _buildHeader(),
            const SizedBox(height: 20),
            _buildFileSelector(),
            if (_selectedFileName != null && !_folderMode) ...[
              const SizedBox(height: 12),
              _buildDetectedFile(),
            ],

            // ── OR: pick existing dump folder ─────────────────────────────
            if (!_isProcessing) ...[
              const SizedBox(height: 10),
              GestureDetector(
                onTap: _pickFolder,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                  decoration: BoxDecoration(
                    color: _folderMode
                        ? const Color(0xFF6366f1).withOpacity(0.10)
                        : Colors.white.withOpacity(0.03),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: _folderMode
                          ? const Color(0xFF6366f1).withOpacity(0.45)
                          : Colors.white.withOpacity(0.09),
                    ),
                  ),
                  child: Row(children: [
                    Icon(Icons.folder_open_rounded,
                      color: _folderMode ? const Color(0xFF6366f1) : Colors.white.withOpacity(0.4),
                      size: 18),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        _folderMode
                            ? 'Folder: $_pickedFolderName'
                            : 'Already have a dump folder?  Select it →',
                        style: TextStyle(
                          color: _folderMode ? Colors.white : Colors.white.withOpacity(0.45),
                          fontSize: 12,
                          fontWeight: _folderMode ? FontWeight.w600 : FontWeight.normal,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (_folderMode)
                      GestureDetector(
                        onTap: () => setState(() {
                          _folderMode       = false;
                          _pickedFolderName = null;
                          _outputDir        = null;
                          _libappSoPath     = null;
                          _patchedSoPath    = null;
                          _soFileGroups     = [];
                          _markedOffsets    = {};
                        }),
                        child: Icon(Icons.close_rounded, color: Colors.white.withOpacity(0.35), size: 16),
                      ),
                  ]),
                ),
              ),
            ],

            const SizedBox(height: 16),
            if (_fileExt == 'so' || _folderMode) ...[
              // Direct SO / folder mode — no dump needed
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                decoration: BoxDecoration(
                  color: const Color(0xFF22c55e).withOpacity(0.08),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: const Color(0xFF22c55e).withOpacity(0.30)),
                ),
                child: Row(children: [
                  const Icon(Icons.check_circle_rounded, color: Color(0xFF22c55e), size: 18),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      _folderMode
                          ? 'Folder loaded — scroll down to patch libapp.so'
                          : 'libapp.so loaded — scroll down to search & patch',
                      style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 13),
                    ),
                  ),
                ]),
              ),
            ] else ...[
              Row(
                children: [
                  Expanded(child: _buildRunButton()),
                  const SizedBox(width: 10),
                  _buildManualVersionButton(),
                ],
              ),
            ],
            if (_isProcessing) ...[
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: GestureDetector(
                  onTap: _cancelOperation,
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      color: const Color(0xFF1a1a2e),
                      border: Border.all(
                          color: const Color(0xFFef4444).withOpacity(0.5)),
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.cancel_outlined,
                            color: Color(0xFFef4444), size: 16),
                        SizedBox(width: 8),
                        Text('Cancel',
                            style: TextStyle(
                                color: Color(0xFFef4444),
                                fontWeight: FontWeight.w600, fontSize: 14)),
                      ],
                    ),
                  ),
                ),
              ),
            ],
            if (_dartVersion != null) ...[
              const SizedBox(height: 12),
              _buildDartVersionBadge(),
            ],
            if (_downloadProgress >= 0) ...[
              const SizedBox(height: 12),
              _buildDownloadProgress(),
            ],
            const SizedBox(height: 20),
            if (_logVisible)
              FadeTransition(
                key: _logPanelKey,
                opacity: _logFade,
                child: _buildOutputConsole(),
              ),
          ],
        ),
      ),
    ),
    );
  }

  // ── Header ─────────────────────────────────────────────────────────────────

  Widget _buildHeader() {
    return AnimatedBuilder(
      animation: Listenable.merge([_pulseAnim, _orbitCtrl, _scanAnim]),
      builder: (context, _) {
        final pulse = _pulseAnim.value;
        final orbit = _orbitCtrl.value;
        final scan  = _scanAnim.value;

        final scanOpacity = scan < 0.5
            ? (scan * 2).clamp(0.0, 1.0)
            : ((1.0 - scan) * 2).clamp(0.0, 1.0);
        final scanY = scan * 88.0;

        return Container(
          padding: const EdgeInsets.fromLTRB(16, 18, 16, 18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(
              colors: [Color(0xFF081220), Color(0xFF0a1228), Color(0xFF081220)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            border: Border.all(
              color: Color.lerp(
                ThemeProvider().current.highlightColor.withOpacity(0.25),
                ThemeProvider().current.primary.withOpacity(0.20),
                pulse,
              )!,
            ),
            boxShadow: [
              BoxShadow(
                color: ThemeProvider().current.highlightColor
                    .withOpacity(0.05 + pulse * 0.06),
                blurRadius: 24,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Row(
            children: [
              // Animated icon
              SizedBox(
                width: 96,
                height: 96,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    // Outer pulse ring
                    Container(
                      width: 90 + pulse * 6,
                      height: 90 + pulse * 6,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: ThemeProvider().current.highlightColor
                              .withOpacity(0.08 + pulse * 0.08),
                          width: 1,
                        ),
                      ),
                    ),
                    // Rotating orbit ring
                    Transform.rotate(
                      angle: orbit * 2 * math.pi,
                      child: CustomPaint(
                        size: const Size(82, 82),
                        painter: _BlutterOrbitPainter(
                          color: Color.lerp(
                            ThemeProvider().current.highlightColor,
                            ThemeProvider().current.primary,
                            pulse,
                          )!,
                          opacity: 0.50 + pulse * 0.25,
                        ),
                      ),
                    ),
                    // Counter-rotating dot ring
                    Transform.rotate(
                      angle: -orbit * 2 * math.pi * 0.6,
                      child: CustomPaint(
                        size: const Size(68, 68),
                        painter: _BlutterDotPainter(
                          color: ThemeProvider().current.highlightColor,
                          opacity: 0.35 + pulse * 0.20,
                        ),
                      ),
                    ),
                    // Icon box with scan line
                    Transform.scale(
                      scale: 1.0 + pulse * 0.03,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(18),
                        child: Stack(
                          children: [
                            Container(
                              width: 64,
                              height: 64,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Color.lerp(const Color(0xFF0a4a5a),
                                        const Color(0xFF0d5a6e), pulse)!,
                                    const Color(0xFF042030),
                                  ],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: ThemeProvider().current.highlightColor
                                        .withOpacity(0.25 + pulse * 0.20),
                                    blurRadius: 18,
                                    spreadRadius: 1,
                                  ),
                                ],
                              ),
                              child: Icon(
                                Icons.flutter_dash_rounded,
                                color: ThemeProvider().current.highlightColor,
                                size: 32,
                              ),
                            ),
                            // Scan line
                            Positioned(
                              top: scanY - 2,
                              left: 0,
                              right: 0,
                              child: Opacity(
                                opacity: scanOpacity * 0.6,
                                child: Container(
                                  height: 2,
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [
                                        Colors.transparent,
                                        ThemeProvider().current.primary,
                                        Colors.transparent,
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(width: 16),

              // Info column
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ShaderMask(
                      shaderCallback: (bounds) => LinearGradient(
                        colors: [
                          Colors.white,
                          Color.lerp(const Color(0xFFffffff),
                              const Color(0xFF67e8f9), pulse)!,
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ).createShader(bounds),
                      child: const Text(
                        'Flutter RE',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'Dart AOT Symbol Extractor',
                      style: TextStyle(
                        color: ThemeProvider().current.highlightColor,
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 6,
                      runSpacing: 4,
                      children: const [
                        _HeaderChip('.zip'),
                        _HeaderChip('arm64-v8a'),
                        _HeaderChip('libflutter.so'),
                        _HeaderChip('libapp.so'),
                      ],
                    ),
                    SizedBox(height: 6),
                    Row(
                      children: [
                        _LiveDot(color: ThemeProvider().current.highlightColor),
                        const SizedBox(width: 5),
                        const Text(
                          'Dart 3.x  ·  Flutter 3.x',
                          style: TextStyle(
                            fontSize: 10,
                            color: Color(0xFF6b7280),
                            letterSpacing: 0.3,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ── File selector ──────────────────────────────────────────────────────────

  Widget _buildFileSelector() {
    return GestureDetector(
      onTap: _isProcessing ? null : _pickFile,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
        decoration: BoxDecoration(
          color: Color(0xFF12102a),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: _selectedFileName != null
                ? ThemeProvider().current.highlightColor.withOpacity(0.40)
                : ThemeProvider().current.borderColor,
            width: 1.5,
          ),
        ),
        child: Row(
          children: [
            Icon(
              _selectedFileName != null
                  ? Icons.insert_drive_file_rounded
                  : Icons.folder_open_rounded,
              color: _selectedFileName != null
                  ? ThemeProvider().current.highlightColor
                  : const Color(0xFF6b7280),
              size: 26,
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _selectedFileName ?? 'Tap to select file',
                    style: TextStyle(
                      color: _selectedFileName != null
                          ? Colors.white
                          : const Color(0xFF6b7280),
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 3),
                  Text(
                    _selectedFileName != null
                        ? _selectedFilePath ?? ''
                        : 'Upload arm64-v8a.zip  or  libapp.so directly',
                    style: const TextStyle(
                      color: Color(0xFF6b7280),
                      fontSize: 11,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            if (_selectedFileName != null)
              IconButton(
                onPressed: () => setState(() {
                  _selectedFilePath  = null;
                  _selectedFileName  = null;
                  _fileExt           = null;
                  _manualDartVersion = null;
                  _outputDir         = null;
                  _libappSoPath      = null;
                  _patchedSoPath     = null;
                  _soFileGroups      = [];
                  _markedOffsets     = {};
                }),
                icon: const Icon(Icons.close_rounded,
                    color: Color(0xFF6b7280), size: 20),
              ),
          ],
        ),
      ),
    );
  }

  // ── Detected file pill ────────────────────────────────────────────────────

  Widget _buildDetectedFile() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: ThemeProvider().current.highlightColor.withOpacity(0.07),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
            color: ThemeProvider().current.highlightColor.withOpacity(0.25)),
      ),
      child: Row(
        children: [
          Icon(Icons.auto_awesome_rounded,
              color: ThemeProvider().current.highlightColor, size: 16),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              'arm64-v8a.zip detected — reading libflutter.so + libapp.so',
              style: TextStyle(
                color: ThemeProvider().current.highlightColor,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Run button ────────────────────────────────────────────────────────────

  Widget _buildRunButton() {
    return SizedBox(
      height: 52,
      child: ElevatedButton.icon(
        onPressed: _isProcessing ? null : _runAnalysis,
        icon: _isProcessing
            ? const SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: Colors.white,
                ),
              )
            : const Icon(Icons.biotech_rounded, size: 20),
        label: Text(
          _isProcessing ? 'Analysing...' : 'Analyse  (Blutter)',
          style: const TextStyle(
            fontWeight: FontWeight.w700,
            fontSize: 15,
            letterSpacing: 0.4,
          ),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: ThemeProvider().current.highlightColor,
          foregroundColor: ThemeProvider().current.scaffoldBg,
          disabledBackgroundColor: ThemeProvider().current.highlightColor.withOpacity(0.35),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          elevation: 6,
          shadowColor: ThemeProvider().current.highlightColor.withOpacity(0.35),
        ),
      ),
    );
  }

  // ── Manual version button ─────────────────────────────────────────────────

  Widget _buildManualVersionButton() {
    final hasVersion = _manualDartVersion != null;
    return SizedBox(
      height: 52,
      child: ElevatedButton(
        onPressed: _isProcessing ? null : () => _showManualVersionDialog(),
        style: ElevatedButton.styleFrom(
          backgroundColor: hasVersion
              ? ThemeProvider().current.primary
              : ThemeProvider().current.surfaceColor,
          foregroundColor: Colors.white,
          disabledBackgroundColor: ThemeProvider().current.surfaceColor.withOpacity(0.4),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
            side: BorderSide(
              color: hasVersion
                  ? ThemeProvider().current.primary
                  : const Color(0xFF444466),
            ),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 14),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              hasVersion ? Icons.edit_rounded : Icons.tag_rounded,
              size: 16,
              color: hasVersion ? Colors.white : const Color(0xFF9090b0),
            ),
            const SizedBox(height: 2),
            Text(
              hasVersion ? _manualDartVersion! : 'Set Ver',
              style: TextStyle(
                fontSize: hasVersion ? 11 : 10,
                fontWeight: FontWeight.w700,
                color: hasVersion ? Colors.white : const Color(0xFF9090b0),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Dart version badge ────────────────────────────────────────────────────

  Widget _buildDartVersionBadge() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: ThemeProvider().current.primary.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: ThemeProvider().current.primary.withOpacity(0.35)),
      ),
      child: Row(
        children: [
          Icon(Icons.verified_rounded,
              color: ThemeProvider().current.primary, size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              'Dart $_dartVersion detected — preparing analysis',
              style: const TextStyle(
                color: Color(0xFFa78bfa),
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  // ── Upload progress bar ───────────────────────────────────────────────────

  Widget _buildDownloadProgress() {
    final pct = _downloadProgress.clamp(0, 100);
    return Container(
      padding: EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Color(0xFF0d1a2a),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: ThemeProvider().current.highlightColor.withOpacity(0.30)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              SizedBox(
                width: 14,
                height: 14,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: ThemeProvider().current.highlightColor,
                ),
              ),
              SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Uploading to analysis cluster...',
                  style: TextStyle(
                    color: ThemeProvider().current.highlightColor,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Text(
                '$pct%',
                style: TextStyle(
                  color: ThemeProvider().current.highlightColor,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: pct / 100.0,
              minHeight: 6,
              backgroundColor: Color(0xFF1a2a3a),
              valueColor:
                  AlwaysStoppedAnimation<Color>(ThemeProvider().current.highlightColor),
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            'Encrypted transfer — processed on secure remote cluster',
            style: TextStyle(color: Color(0xFF4b5563), fontSize: 10),
          ),
        ],
      ),
    );
  }

  // ── Output console ────────────────────────────────────────────────────────

  Widget _buildOutputConsole() {
    final bool done = !_isProcessing && _logs.isNotEmpty;

    // Parse quick stats from log output
    String? asmFiles, funcCount, insnCount;
    if (done) {
      for (final line in _logs.split('\n')) {
        if (line.contains('ASM files'))   asmFiles  = _parseVal(line);
        if (line.contains('Functions'))   funcCount = _parseVal(line);
        if (line.contains('Instructions')) insnCount = _parseVal(line);
      }
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // ── Result summary card (shown after done) ─────────────────
        if (done && _outputDir != null) ...[
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFF22c55e).withOpacity(0.07),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                  color: const Color(0xFF22c55e).withOpacity(0.30)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.check_circle_rounded,
                        color: Color(0xFF22c55e), size: 18),
                    const SizedBox(width: 8),
                    const Text(
                      'Disassembly Complete',
                      style: TextStyle(
                        color: Color(0xFF22c55e),
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                // Stats row
                Row(
                  children: [
                    if (asmFiles != null)
                      _StatChip(
                          icon: Icons.folder_rounded,
                          label: '$asmFiles asm files',
                          color: ThemeProvider().current.highlightColor),
                    SizedBox(width: 8),
                    if (funcCount != null)
                      _StatChip(
                          icon: Icons.functions_rounded,
                          label: '$funcCount funcs',
                          color: ThemeProvider().current.primary),
                    const SizedBox(width: 8),
                    if (insnCount != null)
                      _StatChip(
                          icon: Icons.code_rounded,
                          label: '$insnCount insns',
                          color: const Color(0xFFf59e0b)),
                  ],
                ),
                const SizedBox(height: 10),
                const Text(
                  'Output location:',
                  style: TextStyle(
                      color: Color(0xFF6b7280), fontSize: 11),
                ),
                const SizedBox(height: 3),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: Color(0xFF0a0d14),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                        color: ThemeProvider().current.highlightColor.withOpacity(0.15)),
                  ),
                  child: Text(
                    _outputDir!,
                    style: TextStyle(
                      color: ThemeProvider().current.highlightColor,
                      fontSize: 11,
                      fontFamily: 'monospace',
                    ),
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  'asm/ folder contains one .asm file per class/package\n'
                  'blutter_index.txt has the full symbol summary',
                  style: TextStyle(
                    color: Color(0xFF6b7280),
                    fontSize: 11,
                    height: 1.5,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
        ],

        // ── Live log panel ─────────────────────────────────────────
        AnimatedContainer(
          duration: const Duration(milliseconds: 350),
          decoration: BoxDecoration(
            color: Color(0xFF080810),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
                color: ThemeProvider().current.highlightColor.withOpacity(0.35)),
            boxShadow: [
              BoxShadow(
                  color: ThemeProvider().current.highlightColor.withOpacity(0.06),
                  blurRadius: 16),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // ── Header with controls ──────────────────────────────
              Container(
                padding: EdgeInsets.symmetric(
                    horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: ThemeProvider().current.highlightColor.withOpacity(0.08),
                  borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(14)),
                ),
                child: Row(
                  children: [
                    _isProcessing
                        ? AnimatedBuilder(
                            animation: _orbitCtrl,
                            builder: (_, __) => Transform.rotate(
                              angle: _orbitCtrl.value * 6.28,
                              child: Icon(Icons.settings_rounded,
                                  color: ThemeProvider().current.highlightColor, size: 16),
                            ),
                          )
                        : Icon(Icons.terminal_rounded,
                            color: ThemeProvider().current.highlightColor, size: 16),
                    SizedBox(width: 8),
                    Text(
                      _isProcessing ? 'Processing...' : 'Live Output',
                      style: TextStyle(
                        color: ThemeProvider().current.highlightColor,
                        fontWeight: FontWeight.w700,
                        fontSize: 13,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const Spacer(),
                    // Auto-scroll toggle
                    GestureDetector(
                      onTap: () =>
                          setState(() => _autoScroll = !_autoScroll),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: _autoScroll
                              ? const Color(0xFF22c55e).withOpacity(0.15)
                              : const Color(0xFF374151).withOpacity(0.4),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(
                            color: _autoScroll
                                ? const Color(0xFF22c55e).withOpacity(0.5)
                                : const Color(0xFF374151),
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              _autoScroll
                                  ? Icons.vertical_align_bottom_rounded
                                  : Icons.vertical_align_center_rounded,
                              color: _autoScroll
                                  ? const Color(0xFF22c55e)
                                  : const Color(0xFF6b7280),
                              size: 13,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              'Auto-scroll',
                              style: TextStyle(
                                color: _autoScroll
                                    ? const Color(0xFF22c55e)
                                    : const Color(0xFF6b7280),
                                fontSize: 10,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    // Copy button
                    GestureDetector(
                      onTap: () {
                        if (_logs.isEmpty) {
                          _showSnack('No logs to copy yet',
                              icon: Icons.info_rounded,
                              color: const Color(0xFF6b7280));
                          return;
                        }
                        Clipboard.setData(ClipboardData(text: _logs));
                        _showSnack('Logs copied',
                            icon: Icons.copy_rounded,
                            color: ThemeProvider().current.highlightColor);
                      },
                      child: Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: ThemeProvider().current.highlightColor.withOpacity(0.10),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(
                              color:
                                  ThemeProvider().current.highlightColor.withOpacity(0.35)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.copy_rounded,
                                color: ThemeProvider().current.highlightColor, size: 13),
                            SizedBox(width: 4),
                            Text('Copy',
                                style: TextStyle(
                                    color: ThemeProvider().current.highlightColor,
                                    fontSize: 10,
                                    fontWeight: FontWeight.w600)),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    // Delete / clear button
                    GestureDetector(
                      onTap: () {
                        if (_logs.isEmpty) return;
                        _stopwatch.reset();
                        _tickTimer?.cancel();
                        _tickTimer = null;
                        _pollTimer?.cancel();
                        setState(() {
                          _logs             = '';
                          _outputDir        = null;
                          _logVisible       = false;
                          _isProcessing     = false;
                          _downloadProgress = -1;
                          _elapsed          = '00:00';
                        });
                        _logCtrl.reverse();
                        try { HbcChannel.blutterClearState(); } catch (_) {}
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: const Color(0xFFef4444).withOpacity(0.10),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(
                              color:
                                  const Color(0xFFef4444).withOpacity(0.35)),
                        ),
                        child: const Icon(
                          Icons.delete_outline_rounded,
                          color: Color(0xFFf87171),
                          size: 14,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              // ── Log text area ─────────────────────────────────────
              Container(
                height: 360,
                margin: const EdgeInsets.fromLTRB(14, 10, 14, 0),
                child: Scrollbar(
                  controller: _logScrollCtrl,
                  thumbVisibility: true,
                  child: SingleChildScrollView(
                    controller: _logScrollCtrl,
                    padding: const EdgeInsets.only(right: 8),
                    child: Text(
                      _logs.isEmpty
                          ? (_isProcessing
                              ? 'Parsing ELF and disassembling...'
                              : 'Waiting for output...')
                          : _logs,
                      style: TextStyle(
                        fontFamily: 'monospace',
                        fontSize: 11,
                        color: _logs.isEmpty
                            ? const Color(0xFF4b5563)
                            : const Color(0xFFd4d4d4),
                        height: 1.7,
                      ),
                    ),
                  ),
                ),
              ),
              // ── Timer bar ──────────────────────────────────────────
              if (_stopwatch.elapsedMilliseconds > 0)
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0a0a14),
                    borderRadius: const BorderRadius.vertical(
                        bottom: Radius.circular(14)),
                    border: Border(
                      top: BorderSide(
                          color: Colors.white.withOpacity(0.06)),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        _isProcessing
                            ? Icons.timer_outlined
                            : Icons.check_circle_outline_rounded,
                        color: Colors.white.withOpacity(0.7),
                        size: 14,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        _isProcessing
                            ? 'Elapsed  $_elapsed'
                            : 'Completed in $_elapsed',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.7),
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'monospace',
                        ),
                      ),
                    ],
                  ),
                )
              else
                const SizedBox(height: 10),
            ],
          ),
        ),

      ],
    );
  }

  String? _parseVal(String line) {
    final parts = line.trim().split(RegExp(r'\s+'));
    for (final p in parts.reversed) {
      if (RegExp(r'^\d+$').hasMatch(p)) return p;
    }
    return null;
  }

  // ── libapp.so patcher helpers ─────────────────────────────────────────────

  Future<void> _ensureLibappSo(String outDir, String zipPath) async {
    if (mounted) setState(() => _libappSoLoading = true);
    try {
      final path = await HbcChannel.soCopyLib(
        zipPath: zipPath,
        outputDir: outDir,
      );
      if (mounted) setState(() => _libappSoPath = path);
    } catch (_) {
      // libapp.so not found — patcher section still shows with an error hint
    } finally {
      if (mounted) setState(() => _libappSoLoading = false);
    }
  }

  // ── Patcher search history dropdown ──────────────────────────────────────
  Widget _buildSearchHistoryDropdown() {
    if (!_showSearchHistory || _soSearchHistory.isEmpty) return const SizedBox.shrink();
    return ConstrainedBox(
      constraints: const BoxConstraints(maxHeight: 220),
      child: Container(
        margin: const EdgeInsets.only(top: 6),
        decoration: BoxDecoration(
          color: const Color(0xFF1e293b),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.white.withOpacity(0.08)),
        ),
        child: ListView(
          shrinkWrap: true,
          padding: EdgeInsets.zero,
          children: _soSearchHistory.map((item) => InkWell(
            onTap: () {
              _soSearchCtrl.text = item;
              _soSearchCtrl.selection = TextSelection.collapsed(offset: item.length);
              setState(() => _showSearchHistory = false);
              _soSearch();
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              child: Row(children: [
                Icon(Icons.history_rounded, color: Colors.white.withOpacity(0.45), size: 17),
                const SizedBox(width: 10),
                Expanded(child: Text(item,
                    style: const TextStyle(color: Colors.white, fontSize: 13),
                    overflow: TextOverflow.ellipsis)),
                GestureDetector(
                  onTap: () async {
                    await SearchHistory.remove(SearchHistory.keyPatcher, item);
                    final updated = await SearchHistory.load(SearchHistory.keyPatcher);
                    if (mounted) setState(() => _soSearchHistory = updated);
                  },
                  child: Icon(Icons.close_rounded, color: Colors.red.shade300, size: 17),
                ),
              ]),
            ),
          )).toList(),
        ),
      ),
    );
  }

  Future<void> _soSearch() async {
    final q = _soSearchCtrl.text.trim();
    if (q.isEmpty) return;
    SearchHistory.add(SearchHistory.keyPatcher, q);
    setState(() {
      _soSearching      = true;
      _soFileGroups     = [];
      _showSearchHistory = false;
    });
    try {
      if (_outputDir != null) {
        final groups = await HbcChannel.soScanDump(dumpFolder: _outputDir!, keyword: q);
        if (mounted) setState(() => _soFileGroups = groups);
      }
    } catch (e) {
      if (mounted) _showSnack('Search failed: $e', icon: Icons.error_rounded, color: const Color(0xFFef4444));
    } finally {
      if (mounted) setState(() => _soSearching = false);
    }
  }

  Future<void> _soApplyAll() async {
    if (_markedOffsets.isEmpty) {
      _showSnack('No selected items to patch', icon: Icons.warning_rounded, color: const Color(0xFFf59e0b));
      return;
    }
    if (_libappSoPath == null) {
      _showSnack('Please select a .so file first!', icon: Icons.error_rounded, color: const Color(0xFFef4444));
      return;
    }
    setState(() => _soApplying = true);
    try {
      final patches = <Map<String, String>>[];
      for (final group in _soFileGroups) {
        for (final block in (group['blocks'] as List)) {
          final offset = block['offset'] as String;
          if (_markedOffsets.contains(offset)) {
            final value = block['value'] as String;
            patches.add({
              'offset': offset,
              'toggleTo': value == 'true' ? 'false' : 'true',
            });
          }
        }
      }
      final res = await HbcChannel.soApplyBoolPatches(soPath: _libappSoPath!, patches: patches);
      if (mounted) {
        final outPath = res['path'] as String?;
        final count   = res['count'] as int? ?? 0;
        setState(() {
          _patchedSoPath = outPath;
          _markedOffsets.clear();
        });
        _showSnack('Patch successful!  $count patch${count == 1 ? '' : 'es'} applied',
            icon: Icons.check_circle_rounded, color: const Color(0xFF22c55e));
      }
    } catch (e) {
      if (mounted) _showSnack('Patch failed: $e', icon: Icons.error_rounded, color: const Color(0xFFef4444));
    } finally {
      if (mounted) setState(() => _soApplying = false);
    }
  }

  // ── Quick String Patcher ────────────────────────────────────────────────
  // Opens FlutterMod-identical dialog: Original String / New String fields,
  // live "Length: X vs Y" byte counter, Cancel + PATCH.
  void _showStringPatcherDialog() {
    if (_libappSoPath == null) {
      _showSnack('Please load a libapp.so first', icon: Icons.error_rounded, color: const Color(0xFFef4444));
      return;
    }
    final origCtrl = TextEditingController();
    final newCtrl  = TextEditingController();
    bool patching  = false;

    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDlg) {
          final origBytes = utf8.encode(origCtrl.text).length;
          final newBytes  = utf8.encode(newCtrl.text).length;
          final tooLong   = newBytes > origBytes && origBytes > 0;
          final canPatch  = origCtrl.text.isNotEmpty && !tooLong && !patching;

          return AlertDialog(
            backgroundColor: const Color(0xFF1e293b),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            title: const Text('Quick String Patcher',
                style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Original String field
                TextField(
                  controller: origCtrl,
                  onChanged: (_) => setDlg(() {}),
                  style: const TextStyle(color: Colors.white, fontSize: 13, fontFamily: 'monospace'),
                  decoration: InputDecoration(
                    hintText: 'Original String',
                    hintStyle: TextStyle(color: Colors.white.withOpacity(0.35), fontSize: 13),
                    enabledBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: Color(0xFF6366f1))),
                    focusedBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: Color(0xFF6366f1), width: 2)),
                  ),
                ),
                const SizedBox(height: 8),
                // Live length counter — green if ok, red if too long
                Text(
                  'Length: $origBytes vs $newBytes',
                  style: TextStyle(
                    color: tooLong ? const Color(0xFFef4444) : const Color(0xFF22c55e),
                    fontSize: 12, fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 8),
                // New String field
                TextField(
                  controller: newCtrl,
                  onChanged: (_) => setDlg(() {}),
                  style: const TextStyle(color: Colors.white, fontSize: 13, fontFamily: 'monospace'),
                  decoration: InputDecoration(
                    hintText: 'New String',
                    hintStyle: TextStyle(color: Colors.white.withOpacity(0.35), fontSize: 13),
                    enabledBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: Color(0xFF6366f1))),
                    focusedBorder: const UnderlineInputBorder(
                        borderSide: BorderSide(color: Color(0xFF6366f1), width: 2)),
                  ),
                ),
                if (tooLong) ...[
                  const SizedBox(height: 6),
                  const Text('New string is too long!',
                      style: TextStyle(color: Color(0xFFef4444), fontSize: 11)),
                ],
              ],
            ),
            actions: [
              TextButton(
                onPressed: patching ? null : () => Navigator.pop(ctx),
                child: Text('Cancel',
                    style: TextStyle(color: Colors.white.withOpacity(0.55))),
              ),
              TextButton(
                onPressed: canPatch ? () async {
                  setDlg(() => patching = true);
                  try {
                    final res = await HbcChannel.soPatchString(
                      soPath: _libappSoPath!,
                      oldStr: origCtrl.text,
                      newStr: newCtrl.text,
                    );
                    if (res['status'] == 'multiple') {
                      // Multiple matches — close this dialog and open picker
                      if (ctx.mounted) Navigator.pop(ctx);
                      if (mounted) {
                        _showStringMatchPicker(
                          oldStr: origCtrl.text,
                          newStr: newCtrl.text,
                          offsets: List<int>.from(res['offsets'] as List),
                          contexts: List<String>.from(res['contexts'] as List),
                        );
                      }
                    } else {
                      final count = res['count'] as int? ?? 1;
                      if (ctx.mounted) Navigator.pop(ctx);
                      if (mounted) {
                        _showSnack('$count occurrence${count == 1 ? '' : 's'} patched!',
                            icon: Icons.check_circle_rounded, color: const Color(0xFF22c55e));
                      }
                    }
                  } on PlatformException catch (e) {
                    setDlg(() => patching = false);
                    if (mounted) {
                      _showSnack(e.message ?? 'Patch failed',
                          icon: Icons.error_rounded, color: const Color(0xFFef4444));
                    }
                  } catch (e) {
                    setDlg(() => patching = false);
                    if (mounted) {
                      _showSnack('Patch failed: $e',
                          icon: Icons.error_rounded, color: const Color(0xFFef4444));
                    }
                  }
                } : null,
                child: patching
                    ? const SizedBox(width: 16, height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF6366f1)))
                    : Text('PATCH',
                        style: TextStyle(
                          color: canPatch ? const Color(0xFF6366f1) : Colors.white.withOpacity(0.25),
                          fontWeight: FontWeight.bold)),
              ),
            ],
          );
        },
      ),
    );
  }

  // ── Multi-match picker ───────────────────────────────────────────────────
  void _showStringMatchPicker({
    required String oldStr,
    required String newStr,
    required List<int> offsets,
    required List<String> contexts,
  }) {
    final selected = List<bool>.filled(offsets.length, true); // all checked by default

    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF1e293b),
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => StatefulBuilder(builder: (ctx, setSheet) {
        Future<void> doPatch(List<int> chosenOffsets) async {
          Navigator.pop(ctx);
          try {
            final res = await HbcChannel.soPatchString(
              soPath: _libappSoPath!,
              oldStr: oldStr,
              newStr: newStr,
              offsets: chosenOffsets,
            );
            final count = res['count'] as int? ?? chosenOffsets.length;
            if (mounted) {
              _showSnack('$count occurrence${count == 1 ? '' : 's'} patched!',
                  icon: Icons.check_circle_rounded, color: const Color(0xFF22c55e));
            }
          } on PlatformException catch (e) {
            if (mounted) _showSnack(e.message ?? 'Patch failed',
                icon: Icons.error_rounded, color: const Color(0xFFef4444));
          }
        }

        final selectedOffsets = [
          for (int i = 0; i < offsets.length; i++)
            if (selected[i]) offsets[i]
        ];
        final anySelected = selectedOffsets.isNotEmpty;

        return SafeArea(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const SizedBox(height: 6),
            Container(width: 36, height: 4,
                decoration: BoxDecoration(color: Colors.white24,
                    borderRadius: BorderRadius.circular(2))),
            const SizedBox(height: 14),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18),
              child: Row(children: [
                const Icon(Icons.list_alt_rounded, color: Color(0xFF6366f1), size: 18),
                const SizedBox(width: 8),
                Expanded(child: Text(
                  '${offsets.length} matches found — choose which to patch',
                  style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600),
                )),
              ]),
            ),
            const SizedBox(height: 6),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18),
              child: Row(children: [
                Text('"$oldStr"  →  "$newStr"',
                    style: const TextStyle(color: Color(0xFF6366f1), fontSize: 11, fontFamily: 'monospace'),
                    overflow: TextOverflow.ellipsis),
              ]),
            ),
            const Divider(height: 16, color: Color(0xFF334155)),
            ConstrainedBox(
              constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.45),
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: offsets.length,
                itemBuilder: (_, i) => CheckboxListTile(
                  value: selected[i],
                  onChanged: (v) => setSheet(() => selected[i] = v ?? false),
                  activeColor: const Color(0xFF6366f1),
                  checkColor: Colors.white,
                  dense: true,
                  title: Text(
                    contexts[i],
                    style: const TextStyle(color: Colors.white70, fontSize: 11, fontFamily: 'monospace'),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  subtitle: Text(
                    '0x${offsets[i].toRadixString(16).padLeft(8, '0')}',
                    style: const TextStyle(color: Color(0xFF6366f1), fontSize: 10),
                  ),
                ),
              ),
            ),
            const Divider(height: 1, color: Color(0xFF334155)),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
              child: Row(children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => doPatch(offsets),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Color(0xFF6366f1)),
                      foregroundColor: const Color(0xFF6366f1),
                    ),
                    child: const Text('Patch All'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: anySelected ? () => doPatch(selectedOffsets) : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF6366f1),
                      foregroundColor: Colors.white,
                    ),
                    child: Text('Patch Selected (${ selectedOffsets.length})'),
                  ),
                ),
              ]),
            ),
          ]),
        );
      }),
    );
  }

  // ── Integer Patcher dialog ───────────────────────────────────────────────
  void _showIntPatcherDialog() {
    if (_libappSoPath == null) {
      _showSnack('Please load a libapp.so first', icon: Icons.error_rounded, color: const Color(0xFFef4444));
      return;
    }
    final oldCtrl = TextEditingController();
    final newCtrl = TextEditingController();
    int   bits    = 32;
    bool  patching = false;

    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setDlg) {
        bool isValidInt(String s) {
          if (s.isEmpty) return false;
          return int.tryParse(s) != null;
        }
        final canPatch = isValidInt(oldCtrl.text) && isValidInt(newCtrl.text) && !patching;

        return AlertDialog(
          backgroundColor: const Color(0xFF1e293b),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Row(children: [
            const Icon(Icons.tag_rounded, color: Color(0xFF22c55e), size: 20),
            const SizedBox(width: 8),
            const Text('Integer Patcher',
                style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
          ]),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Bit width selector
              Row(children: [
                const Text('Bit width:', style: TextStyle(color: Colors.white60, fontSize: 12)),
                const SizedBox(width: 10),
                _bitChip('32-bit', 32, bits, (v) => setDlg(() => bits = v)),
                const SizedBox(width: 8),
                _bitChip('64-bit', 64, bits, (v) => setDlg(() => bits = v)),
              ]),
              const SizedBox(height: 14),
              // Old value
              TextField(
                controller: oldCtrl,
                onChanged: (_) => setDlg(() {}),
                keyboardType: TextInputType.number,
                style: const TextStyle(color: Colors.white, fontSize: 13, fontFamily: 'monospace'),
                decoration: InputDecoration(
                  hintText: 'Old value  (e.g. 100)',
                  hintStyle: TextStyle(color: Colors.white.withOpacity(0.35), fontSize: 13),
                  enabledBorder: const UnderlineInputBorder(
                      borderSide: BorderSide(color: Color(0xFF22c55e))),
                  focusedBorder: const UnderlineInputBorder(
                      borderSide: BorderSide(color: Color(0xFF22c55e), width: 2)),
                ),
              ),
              const SizedBox(height: 10),
              // New value
              TextField(
                controller: newCtrl,
                onChanged: (_) => setDlg(() {}),
                keyboardType: TextInputType.number,
                style: const TextStyle(color: Colors.white, fontSize: 13, fontFamily: 'monospace'),
                decoration: InputDecoration(
                  hintText: 'New value  (e.g. 9999)',
                  hintStyle: TextStyle(color: Colors.white.withOpacity(0.35), fontSize: 13),
                  enabledBorder: const UnderlineInputBorder(
                      borderSide: BorderSide(color: Color(0xFF22c55e))),
                  focusedBorder: const UnderlineInputBorder(
                      borderSide: BorderSide(color: Color(0xFF22c55e), width: 2)),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Searches for the integer as ${bits}-bit little-endian bytes.',
                style: TextStyle(color: Colors.white.withOpacity(0.35), fontSize: 11),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: patching ? null : () => Navigator.pop(ctx),
              child: Text('Cancel', style: TextStyle(color: Colors.white.withOpacity(0.55))),
            ),
            TextButton(
              onPressed: canPatch ? () async {
                setDlg(() => patching = true);
                try {
                  final res = await HbcChannel.soPatchInt(
                    soPath: _libappSoPath!,
                    oldVal: oldCtrl.text,
                    newVal: newCtrl.text,
                    bits: bits,
                  );
                  if (res['status'] == 'multiple') {
                    if (ctx.mounted) Navigator.pop(ctx);
                    if (mounted) {
                      _showIntMatchPicker(
                        oldVal: oldCtrl.text,
                        newVal: newCtrl.text,
                        bits: bits,
                        offsets: List<int>.from(res['offsets'] as List),
                        contexts: List<String>.from(res['contexts'] as List),
                      );
                    }
                  } else {
                    final count = res['count'] as int? ?? 1;
                    if (ctx.mounted) Navigator.pop(ctx);
                    if (mounted) {
                      _showSnack('$count integer${count == 1 ? '' : 's'} patched!',
                          icon: Icons.check_circle_rounded, color: const Color(0xFF22c55e));
                    }
                  }
                } on PlatformException catch (e) {
                  setDlg(() => patching = false);
                  if (mounted) _showSnack(e.message ?? 'Patch failed',
                      icon: Icons.error_rounded, color: const Color(0xFFef4444));
                } catch (e) {
                  setDlg(() => patching = false);
                  if (mounted) _showSnack('Patch failed: $e',
                      icon: Icons.error_rounded, color: const Color(0xFFef4444));
                }
              } : null,
              child: patching
                  ? const SizedBox(width: 16, height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF22c55e)))
                  : Text('PATCH',
                      style: TextStyle(
                        color: canPatch ? const Color(0xFF22c55e) : Colors.white.withOpacity(0.25),
                        fontWeight: FontWeight.bold)),
            ),
          ],
        );
      }),
    );
  }

  Widget _bitChip(String label, int val, int current, ValueChanged<int> onTap) {
    final selected = val == current;
    return GestureDetector(
      onTap: () => onTap(val),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFF22c55e).withOpacity(0.18) : Colors.transparent,
          border: Border.all(
            color: selected ? const Color(0xFF22c55e) : Colors.white24,
          ),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(label,
            style: TextStyle(
              color: selected ? const Color(0xFF22c55e) : Colors.white54,
              fontSize: 12, fontWeight: FontWeight.w600)),
      ),
    );
  }

  // ── Integer multi-match picker ───────────────────────────────────────────
  void _showIntMatchPicker({
    required String oldVal,
    required String newVal,
    required int bits,
    required List<int> offsets,
    required List<String> contexts,
  }) {
    final selected = List<bool>.filled(offsets.length, true);

    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF1e293b),
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => StatefulBuilder(builder: (ctx, setSheet) {
        Future<void> doPatch(List<int> chosenOffsets) async {
          Navigator.pop(ctx);
          try {
            final res = await HbcChannel.soPatchInt(
              soPath: _libappSoPath!,
              oldVal: oldVal,
              newVal: newVal,
              bits: bits,
              offsets: chosenOffsets,
            );
            final count = res['count'] as int? ?? chosenOffsets.length;
            if (mounted) {
              _showSnack('$count integer${count == 1 ? '' : 's'} patched!',
                  icon: Icons.check_circle_rounded, color: const Color(0xFF22c55e));
            }
          } on PlatformException catch (e) {
            if (mounted) _showSnack(e.message ?? 'Patch failed',
                icon: Icons.error_rounded, color: const Color(0xFFef4444));
          }
        }

        final selectedOffsets = [
          for (int i = 0; i < offsets.length; i++) if (selected[i]) offsets[i]
        ];
        final anySelected = selectedOffsets.isNotEmpty;

        return SafeArea(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const SizedBox(height: 6),
            Container(width: 36, height: 4,
                decoration: BoxDecoration(color: Colors.white24,
                    borderRadius: BorderRadius.circular(2))),
            const SizedBox(height: 14),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18),
              child: Row(children: [
                const Icon(Icons.tag_rounded, color: Color(0xFF22c55e), size: 18),
                const SizedBox(width: 8),
                Expanded(child: Text(
                  '${offsets.length} matches for $oldVal — choose which to patch',
                  style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600),
                )),
              ]),
            ),
            const SizedBox(height: 6),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18),
              child: Row(children: [
                Text('$oldVal  →  $newVal  ($bits-bit)',
                    style: const TextStyle(color: Color(0xFF22c55e), fontSize: 11, fontFamily: 'monospace'),
                    overflow: TextOverflow.ellipsis),
              ]),
            ),
            const Divider(height: 16, color: Color(0xFF334155)),
            ConstrainedBox(
              constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.45),
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: offsets.length,
                itemBuilder: (_, i) => CheckboxListTile(
                  value: selected[i],
                  onChanged: (v) => setSheet(() => selected[i] = v ?? false),
                  activeColor: const Color(0xFF22c55e),
                  checkColor: Colors.white,
                  dense: true,
                  title: Text(
                    contexts[i],
                    style: const TextStyle(color: Colors.white70, fontSize: 11, fontFamily: 'monospace'),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  subtitle: Text(
                    '0x${offsets[i].toRadixString(16).padLeft(8, '0')}',
                    style: const TextStyle(color: Color(0xFF22c55e), fontSize: 10),
                  ),
                ),
              ),
            ),
            const Divider(height: 1, color: Color(0xFF334155)),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
              child: Row(children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => doPatch(offsets),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Color(0xFF22c55e)),
                      foregroundColor: const Color(0xFF22c55e),
                    ),
                    child: const Text('Patch All'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: anySelected ? () => doPatch(selectedOffsets) : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF22c55e),
                      foregroundColor: Colors.white,
                    ),
                    child: Text('Patch Selected (${selectedOffsets.length})'),
                  ),
                ),
              ]),
            ),
          ]),
        );
      }),
    );
  }

  int get _totalBlockCount {
    int n = 0;
    for (final g in _soFileGroups) n += (g['matchCount'] as int? ?? 0);
    return n;
  }

  Set<String> get _allOffsets {
    final all = <String>{};
    for (final g in _soFileGroups) {
      for (final b in (g['blocks'] as List? ?? [])) {
        final off = (b['offset'] as String?) ?? '';
        if (off.isNotEmpty) all.add(off);
      }
    }
    return all;
  }

  bool get _allSelected {
    final all = _allOffsets;
    return all.isNotEmpty && _markedOffsets.containsAll(all);
  }

  void _toggleSelectAll() {
    setState(() {
      final all = _allOffsets;
      if (_allSelected) {
        _markedOffsets.removeAll(all);
      } else {
        _markedOffsets.addAll(all);
      }
    });
  }

  Set<String> _groupOffsets(Map group) {
    final offsets = <String>{};
    for (final b in (group['blocks'] as List? ?? [])) {
      final off = (b['offset'] as String?) ?? '';
      if (off.isNotEmpty) offsets.add(off);
    }
    return offsets;
  }

  bool _allSelectedInGroup(Map group) {
    final offsets = _groupOffsets(group);
    return offsets.isNotEmpty && _markedOffsets.containsAll(offsets);
  }

  void _toggleSelectGroup(Map group) {
    setState(() {
      final offsets = _groupOffsets(group);
      if (_allSelectedInGroup(group)) {
        _markedOffsets.removeAll(offsets);
      } else {
        _markedOffsets.addAll(offsets);
      }
    });
  }

  // Bookmark SVG icon — filled (selected) or outlined (unselected)
  // Paths match Material bookmark / bookmark_border exactly.
  Widget _bookmarkIcon(bool selected, {double size = 32}) {
    final svg = selected
        ? '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">'
            '<path fill="#22c55e" d="M17 3H7c-1.1 0-2 .9-2 2v16l7-3 7 3V5c0-1.1-.9-2-2-2z"/>'
            '</svg>'
        : '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">'
            '<path fill="#ffffff30" fill-rule="evenodd"'
            ' d="M17 3H7c-1.1 0-2 .9-2 2v16l7-3 7 3V5c0-1.1-.9-2-2-2z'
            'M17 18l-5-2.18L7 18V5h10v13z"/>'
            '</svg>';
    return SvgPicture.string(svg, width: size, height: size);
  }

  Widget _buildAsmContext(String contextText) {
    final lines = contextText.split('\n');
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: lines.map((line) {
        final isHl = line.trimLeft().startsWith('>>>');
        final display = isHl ? line.replaceFirst(RegExp(r'>>>\s*'), '') : line;
        return Container(
          width: double.infinity,
          color: isHl ? ThemeProvider().current.primary.withOpacity(0.35) : Colors.transparent,
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
          child: Text(
            isHl ? '>>>  $display' : display,
            style: TextStyle(
              color: isHl ? const Color(0xFFfbbf24) : Colors.white.withOpacity(0.65),
              fontSize: 10, fontFamily: 'monospace', height: 1.4,
            ),
          ),
        );
      }).toList(),
    );
  }

  // ── PageView wrapper: Patcher (page 0) + ASM Editor (page 1) ─────────────

  Widget _buildPatcherWithEditorView() {
    return Column(children: [
      // ── Tab indicator (hidden in ASM fullscreen) ──
      if (!_asmFullScreen) ...[
        Container(
          color: ThemeProvider().current.appBarBg,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          child: Row(children: [
            _tabChip('PATCHER', 0),
            const SizedBox(width: 8),
            _tabChip('ASM EDITOR', 1),
          ]),
        ),
        const Divider(height: 1, color: Color(0xFF1e293b)),
      ],
      // ── Pages ──
      Expanded(
        child: PageView(
          controller: _patcherPageCtrl,
          physics: const NeverScrollableScrollPhysics(),
          onPageChanged: (i) {
            setState(() => _patcherPageIdx = i);
            HbcChannel.blutterSavePage(i);
          },
          children: [
            _buildPatcherView(),
            AsmEditorTab(
              key: ValueKey(_outputDir),
              outputDir: _outputDir!,
              libappSoPath: _libappSoPath,
              onFullScreenChanged: (isFs, exitFn) {
                setState(() {
                  _asmFullScreen    = isFs;
                  _exitAsmFullScreen = exitFn;
                });
              },
              onRegisterBackHandler: (fn) => _asmBackHandler = fn,
            ),
          ],
        ),
      ),
    ]);
  }

  Widget _tabChip(String label, int idx) {
    final active = _patcherPageIdx == idx;
    return GestureDetector(
      onTap: () => _patcherPageCtrl.animateToPage(idx,
          duration: const Duration(milliseconds: 300), curve: Curves.easeInOut),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: active ? ThemeProvider().current.highlightColor.withOpacity(0.15) : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: active ? ThemeProvider().current.highlightColor : Colors.white12,
          ),
        ),
        child: Text(label,
            style: TextStyle(
              color: active ? ThemeProvider().current.highlightColor : Colors.white38,
              fontSize: 11,
              fontWeight: active ? FontWeight.bold : FontWeight.normal,
              letterSpacing: 0.8,
            )),
      ),
    );
  }

  // ── Full-screen patcher view (FlutterMod-style) ──────────────────────────

  Widget _buildPatcherView() {
    final folderLabel = _outputDir ?? '';
    final soLabel     = _libappSoPath ?? '';
    final hasLib      = _libappSoPath != null;

    return Column(
      children: [
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // ── Path card ──────────────────────────────────────────────
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFF0f172a),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.white.withOpacity(0.10)),
                  ),
                  child: Column(children: [
                    // Dump Folder Path
                    Padding(
                      padding: const EdgeInsets.fromLTRB(14, 14, 14, 0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Dump Folder Path',
                              style: TextStyle(color: Colors.white.withOpacity(0.45), fontSize: 11)),
                          const SizedBox(height: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.04),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: Colors.white.withOpacity(0.08)),
                            ),
                            child: Row(children: [
                              Icon(Icons.folder_open_rounded, color: ThemeProvider().current.highlightColor, size: 16),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(folderLabel,
                                    style: const TextStyle(color: Colors.white, fontSize: 12, fontFamily: 'monospace'),
                                    overflow: TextOverflow.ellipsis),
                              ),
                            ]),
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: TextButton(
                              onPressed: _pickFolder,
                              style: TextButton.styleFrom(padding: EdgeInsets.zero),
                              child: Text('BROWSE', style: TextStyle(color: ThemeProvider().current.highlightColor, fontSize: 12, fontWeight: FontWeight.bold)),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Divider(color: Colors.white10, height: 1),
                    // Target libapp.so
                    Padding(
                      padding: const EdgeInsets.fromLTRB(14, 10, 14, 14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Target libapp.so',
                              style: TextStyle(color: Colors.white.withOpacity(0.45), fontSize: 11)),
                          const SizedBox(height: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.04),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                color: hasLib
                                    ? const Color(0xFF22c55e).withOpacity(0.30)
                                    : Colors.white.withOpacity(0.08),
                              ),
                            ),
                            child: Row(children: [
                              Icon(Icons.memory_rounded,
                                  color: hasLib ? const Color(0xFF22c55e) : Colors.white.withOpacity(0.35),
                                  size: 16),
                              SizedBox(width: 8),
                              Expanded(
                                child: _libappSoLoading
                                    ? Row(children: [
                                        SizedBox(width: 12, height: 12, child: CircularProgressIndicator(strokeWidth: 1.5, color: ThemeProvider().current.highlightColor)),
                                        const SizedBox(width: 8),
                                        Text('Locating libapp.so...', style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 12)),
                                      ])
                                    : Text(
                                        soLabel.isNotEmpty ? soLabel : 'libapp.so not found',
                                        style: TextStyle(
                                          color: hasLib ? Colors.white : const Color(0xFFef4444).withOpacity(0.7),
                                          fontSize: 12,
                                          fontFamily: 'monospace',
                                        ),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                              ),
                            ]),
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: TextButton(
                              onPressed: () async {
                                final r = await FilePicker.platform.pickFiles(type: FileType.any);
                                if (r == null || r.files.isEmpty) return;
                                final f = r.files.first;
                                if (!f.name.endsWith('.so')) return;
                                setState(() => _libappSoPath = f.path);
                              },
                              style: TextButton.styleFrom(padding: EdgeInsets.zero),
                              child: Text('SELECT SO', style: TextStyle(color: ThemeProvider().current.highlightColor, fontSize: 12, fontWeight: FontWeight.bold)),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ]),
                ),

                const SizedBox(height: 16),

                // ── Search + patcher card ──────────────────────────────────
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFF0f172a),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.white.withOpacity(0.10)),
                  ),
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      // Search bar
                      Container(
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.04),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.white.withOpacity(0.10)),
                        ),
                        child: Row(children: [
                          SizedBox(width: 12),
                          Icon(Icons.search_rounded, color: ThemeProvider().current.primary, size: 20),
                          const SizedBox(width: 8),
                          Expanded(
                            child: TextField(
                              controller: _soSearchCtrl,
                              focusNode: _soSearchFocusNode,
                              style: const TextStyle(color: Colors.white, fontSize: 13),
                              onSubmitted: (_) => _soSearch(),
                              decoration: InputDecoration(
                                hintText: 'Keyword (e.g., isPremium, 0x30)...',
                                hintStyle: TextStyle(color: Colors.white.withOpacity(0.30), fontSize: 13),
                                border: InputBorder.none,
                                isDense: true,
                                contentPadding: const EdgeInsets.symmetric(vertical: 12),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                        ]),
                      ),
                      _buildSearchHistoryDropdown(),

                      const SizedBox(height: 12),

                      // SCAN + CLEAR
                      Row(children: [
                        Expanded(
                          child: GestureDetector(
                            onTap: !_soSearching ? _soSearch : null,
                            child: Container(
                              padding: EdgeInsets.symmetric(vertical: 13),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [ThemeProvider().current.primary, Color(0xFF4c1d95)],
                                ),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                                if (_soSearching)
                                  const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                                else
                                  const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 18),
                                const SizedBox(width: 8),
                                Text(_soSearching ? 'SCANNING...' : 'SCAN',
                                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                              ]),
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: GestureDetector(
                            onTap: () => setState(() { _soFileGroups = []; _markedOffsets = {}; _expandedFiles = {}; _soSearchCtrl.clear(); }),
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 13),
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  colors: [Color(0xFFdc2626), Color(0xFF991b1b)],
                                ),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                                const Icon(Icons.delete_outline_rounded, color: Colors.white, size: 18),
                                const SizedBox(width: 8),
                                const Text('CLEAR', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                              ]),
                            ),
                          ),
                        ),
                      ]),

                      const SizedBox(height: 10),

                      // STRING PATCHER button — opens Quick String Patcher dialog
                      GestureDetector(
                        onTap: hasLib ? _showStringPatcherDialog : () {
                          _showSnack('Please load a libapp.so first',
                              icon: Icons.error_rounded, color: const Color(0xFFef4444));
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 13),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                                color: const Color(0xFFf59e0b).withOpacity(hasLib ? 0.60 : 0.25),
                                width: 1.5),
                            color: const Color(0xFFf59e0b).withOpacity(0.05),
                          ),
                          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                            Icon(Icons.edit_rounded,
                                color: Color(0xFFf59e0b).withOpacity(hasLib ? 1.0 : 0.35), size: 18),
                            const SizedBox(width: 8),
                            Text('STRING PATCHER',
                                style: TextStyle(
                                  color: Color(0xFFf59e0b).withOpacity(hasLib ? 1.0 : 0.35),
                                  fontWeight: FontWeight.bold, fontSize: 13)),
                          ]),
                        ),
                      ),

                      const SizedBox(height: 8),

                      // INTEGER PATCHER button — opens Integer Patcher dialog
                      GestureDetector(
                        onTap: hasLib ? _showIntPatcherDialog : () {
                          _showSnack('Please load a libapp.so first',
                              icon: Icons.error_rounded, color: const Color(0xFFef4444));
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 13),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                                color: const Color(0xFF22c55e).withOpacity(hasLib ? 0.60 : 0.25),
                                width: 1.5),
                            color: const Color(0xFF22c55e).withOpacity(0.05),
                          ),
                          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                            Icon(Icons.tag_rounded,
                                color: Color(0xFF22c55e).withOpacity(hasLib ? 1.0 : 0.35), size: 18),
                            const SizedBox(width: 8),
                            Text('INTEGER PATCHER',
                                style: TextStyle(
                                  color: Color(0xFF22c55e).withOpacity(hasLib ? 1.0 : 0.35),
                                  fontWeight: FontWeight.bold, fontSize: 13)),
                          ]),
                        ),
                      ),

                      const SizedBox(height: 16),

                      // Scan results label + Select All tick
                      Row(children: [
                        const Text('SCAN RESULTS',
                            style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 1.0)),
                        const SizedBox(width: 8),
                        if (_soFileGroups.isNotEmpty)
                          Text('(${_totalBlockCount})',
                              style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 12)),
                        const Spacer(),
                        if (_soFileGroups.isNotEmpty)
                          GestureDetector(
                            onTap: _toggleSelectAll,
                            child: Row(children: [
                              _bookmarkIcon(_allSelected, size: 18),
                              const SizedBox(width: 4),
                              Text(_allSelected ? 'Deselect All' : 'Select All',
                                  style: TextStyle(
                                    color: _allSelected ? const Color(0xFF22c55e) : Colors.white.withOpacity(0.55),
                                    fontSize: 11, fontWeight: FontWeight.w600)),
                            ]),
                          ),
                      ]),
                      const SizedBox(height: 8),

                      if (_soFileGroups.isEmpty)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          child: Text('No results yet. Enter a keyword and tap SCAN.',
                              style: TextStyle(color: Colors.white.withOpacity(0.30), fontSize: 12)),
                        )
                      else
                        ..._soFileGroups.map((group) {
                          final fileName   = group['fileName'] as String? ?? '';
                          final matchCount = group['matchCount'] as int? ?? 0;
                          final blocks     = (group['blocks'] as List?) ?? [];
                          final isExpanded = _expandedFiles.contains(fileName);
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              GestureDetector(
                                onTap: () => setState(() {
                                  if (isExpanded) _expandedFiles.remove(fileName);
                                  else _expandedFiles.add(fileName);
                                }),
                                child: Container(
                                  margin: const EdgeInsets.only(bottom: 6),
                                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF1e293b),
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(color: const Color(0xFFf59e0b).withOpacity(0.35)),
                                  ),
                                  child: Row(children: [
                                    Icon(Icons.insert_drive_file_outlined,
                                        color: Colors.white.withOpacity(0.5), size: 18),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Text('$fileName ($matchCount)',
                                          style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
                                    ),
                                    Icon(Icons.search_rounded,
                                        color: Colors.white.withOpacity(0.35), size: 18),
                                    SizedBox(width: 8),
                                    Icon(
                                      isExpanded ? Icons.keyboard_arrow_up_rounded : Icons.keyboard_arrow_down_rounded,
                                      color: ThemeProvider().current.primary, size: 22,
                                    ),
                                  ]),
                                ),
                              ),
                              if (isExpanded) ...[
                                GestureDetector(
                                  onTap: () => _toggleSelectGroup(group),
                                  child: Container(
                                    margin: const EdgeInsets.only(bottom: 6, left: 2, right: 2),
                                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                    decoration: BoxDecoration(
                                      color: _allSelectedInGroup(group)
                                          ? const Color(0xFF22c55e).withOpacity(0.08)
                                          : const Color(0xFF1e293b).withOpacity(0.5),
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(
                                        color: _allSelectedInGroup(group)
                                            ? const Color(0xFF22c55e).withOpacity(0.3)
                                            : Colors.white.withOpacity(0.08),
                                      ),
                                    ),
                                    child: Row(children: [
                                      _bookmarkIcon(_allSelectedInGroup(group), size: 14),
                                      const SizedBox(width: 8),
                                      Text(
                                        _allSelectedInGroup(group) ? 'Deselect all' : 'Select all',
                                        style: TextStyle(
                                          color: _allSelectedInGroup(group)
                                              ? const Color(0xFF22c55e)
                                              : Colors.white.withOpacity(0.5),
                                          fontSize: 11, fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                      const Spacer(),
                                      Text('$matchCount',
                                          style: TextStyle(color: Colors.white.withOpacity(0.35), fontSize: 11)),
                                    ]),
                                  ),
                                ),
                                ...blocks.map((block) {
                                  final offset      = (block['offset'] as String?) ?? '';
                                  final value       = (block['value'] as String?) ?? '';
                                  final headerText  = (block['headerText'] as String?) ?? '';
                                  final contextText = (block['contextText'] as String?) ?? '';
                                  final isMarked    = _markedOffsets.contains(offset);
                                  return Container(
                                    margin: const EdgeInsets.only(bottom: 8, left: 4, right: 4),
                                    padding: const EdgeInsets.all(12),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFF0f172a),
                                      borderRadius: BorderRadius.circular(10),
                                      border: Border.all(
                                        color: isMarked
                                            ? const Color(0xFF22c55e).withOpacity(0.45)
                                            : const Color(0xFFf59e0b).withOpacity(0.20),
                                      ),
                                    ),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(headerText,
                                            style: TextStyle(
                                              color: const Color(0xFF7dd3fc).withOpacity(0.85),
                                              fontSize: 10, fontFamily: 'monospace', height: 1.4),
                                            maxLines: 4, overflow: TextOverflow.ellipsis),
                                        const SizedBox(height: 6),
                                        Text(
                                            'Offset: 0x\u2026${offset.length > 4 ? offset.substring(offset.length - 4) : offset}',
                                            style: const TextStyle(
                                              color: Color(0xFFf59e0b),
                                              fontSize: 12, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
                                        const SizedBox(height: 8),
                                        Row(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Expanded(
                                              child: Container(
                                                padding: const EdgeInsets.all(6),
                                                decoration: BoxDecoration(
                                                  color: Colors.black.withOpacity(0.3),
                                                  borderRadius: BorderRadius.circular(6),
                                                ),
                                                child: _buildAsmContext(contextText),
                                              ),
                                            ),
                                            const SizedBox(width: 8),
                                            GestureDetector(
                                              onTap: () => setState(() {
                                                if (isMarked) _markedOffsets.remove(offset);
                                                else _markedOffsets.add(offset);
                                              }),
                                              child: _bookmarkIcon(isMarked, size: 34),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  );
                                }),
                              ],
                            ],
                          );
                        }),

                      // Marked count summary
                      if (_markedOffsets.isNotEmpty) ...[
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          decoration: BoxDecoration(
                            color: const Color(0xFF22c55e).withOpacity(0.06),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: const Color(0xFF22c55e).withOpacity(0.20)),
                          ),
                          child: Text('${_markedOffsets.length} patch${_markedOffsets.length == 1 ? '' : 'es'} marked',
                              style: const TextStyle(color: Color(0xFF22c55e), fontSize: 12, fontWeight: FontWeight.w600)),
                        ),
                      ],

                      const SizedBox(height: 80), // room for the bottom button
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),

        // ── APPLY ALL PATCHES — pinned bottom ─────────────────────────────
        Container(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
          decoration: BoxDecoration(
            color: const Color(0xFF080d18),
            border: Border(top: BorderSide(color: Colors.white.withOpacity(0.08))),
          ),
          child: GestureDetector(
            onTap: (!hasLib || _markedOffsets.isEmpty || _soApplying) ? null : _soApplyAll,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 16),
              decoration: BoxDecoration(
                gradient: (!hasLib || _markedOffsets.isEmpty || _soApplying)
                    ? LinearGradient(colors: [Colors.white.withOpacity(0.07), Colors.white.withOpacity(0.05)])
                    : const LinearGradient(colors: [Color(0xFFdc2626), Color(0xFF7f1d1d)]),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                if (_soApplying)
                  const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                else
                  Icon(Icons.auto_fix_high_rounded,
                      color: (!hasLib || _markedOffsets.isEmpty) ? Colors.white.withOpacity(0.25) : Colors.white,
                      size: 18),
                const SizedBox(width: 10),
                Text(
                  _soApplying ? 'Applying...' : 'APPLY ALL PATCHES',
                  style: TextStyle(
                    color: (!hasLib || _markedOffsets.isEmpty || _soApplying) ? Colors.white.withOpacity(0.25) : Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    letterSpacing: 0.5,
                  ),
                ),
              ]),
            ),
          ),
        ),
      ],
    );
  }

  // ── libapp.so patcher UI ──────────────────────────────────────────────────

  Widget _buildPatcherSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Header row
        Row(children: [
          const Icon(Icons.memory_rounded, color: Color(0xFF00e5ff), size: 18),
          const SizedBox(width: 8),
          const Text('libapp.so Patcher',
            style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold)),
          const Spacer(),
          if (_libappSoLoading)
            Row(children: [
              const SizedBox(width: 10, height: 10, child: CircularProgressIndicator(strokeWidth: 1.5, color: Color(0xFF00e5ff))),
              const SizedBox(width: 6),
              Text('Locating libapp.so...', style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 11)),
            ])
          else if (_libappSoPath != null)
            Text('Ready', style: TextStyle(color: const Color(0xFF22c55e).withOpacity(0.8), fontSize: 11))
          else
            Text('libapp.so not found', style: TextStyle(color: const Color(0xFFef4444).withOpacity(0.8), fontSize: 11)),
        ]),
        const SizedBox(height: 12),

        if (_libappSoLoading) ...[
          const SizedBox(height: 8),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF00e5ff))),
            const SizedBox(width: 10),
            Text('Locating libapp.so in output...', style: TextStyle(color: Colors.white.withOpacity(0.45), fontSize: 12)),
          ]),
        ] else if (_libappSoPath == null) ...[
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFFef4444).withOpacity(0.06),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFef4444).withOpacity(0.20)),
            ),
            child: Text(
              'libapp.so was not found in the output or the uploaded zip.\nMake sure your zip includes libapp.so inside arm64-v8a/.',
              style: TextStyle(color: Colors.white.withOpacity(0.55), fontSize: 12, height: 1.5),
            ),
          ),
        ] else ...[
          _buildInlinePatcher(),
        ],
      ],
    );
  }

  Widget _buildInlinePatcher() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.03),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Search bar
          Row(children: [
            Expanded(
              child: TextField(
                controller: _soSearchCtrl,
                focusNode: _soSearchFocusNode,
                style: const TextStyle(color: Colors.white, fontSize: 13, fontFamily: 'monospace'),
                onSubmitted: (_) => _soSearch(),
                decoration: InputDecoration(
                  isDense: true,
                  filled: true,
                  fillColor: Colors.white.withOpacity(0.06),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
                  hintText: 'Keyword (e.g., isPremium, 0x30)...',
                  hintStyle: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 12),
                  prefixIcon: Icon(Icons.search, color: Colors.white.withOpacity(0.4), size: 18),
                ),
              ),
            ),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: _soSearching ? null : _soSearch,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: _soSearching ? Colors.white.withOpacity(0.06) : const Color(0xFF6366f1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: _soSearching
                  ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Text('Search', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
              ),
            ),
          ]),
          _buildSearchHistoryDropdown(),

          if (_soFileGroups.isNotEmpty) ...[
            const SizedBox(height: 10),
            Row(children: [
              Text('${_totalBlockCount} result${_totalBlockCount == 1 ? '' : 's'}',
                style: TextStyle(color: Colors.white.withOpacity(0.45), fontSize: 11)),
              const Spacer(),
              GestureDetector(
                onTap: _toggleSelectAll,
                child: Row(children: [
                  _bookmarkIcon(_allSelected, size: 16),
                  const SizedBox(width: 4),
                  Text(_allSelected ? 'Deselect All' : 'Select All',
                      style: TextStyle(
                        color: _allSelected ? const Color(0xFF22c55e) : Colors.white.withOpacity(0.5),
                        fontSize: 11, fontWeight: FontWeight.w600)),
                ]),
              ),
            ]),
            const SizedBox(height: 6),
            ..._soFileGroups.map((group) {
              final fileName   = group['fileName'] as String? ?? '';
              final matchCount = group['matchCount'] as int? ?? 0;
              final blocks     = (group['blocks'] as List?) ?? [];
              final isExpanded = _expandedFiles.contains(fileName);
              return Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  GestureDetector(
                    onTap: () => setState(() {
                      if (isExpanded) _expandedFiles.remove(fileName);
                      else _expandedFiles.add(fileName);
                    }),
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 6),
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1e293b),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: const Color(0xFFf59e0b).withOpacity(0.35)),
                      ),
                      child: Row(children: [
                        Icon(Icons.insert_drive_file_outlined, color: Colors.white.withOpacity(0.5), size: 16),
                        SizedBox(width: 8),
                        Expanded(child: Text('$fileName ($matchCount)',
                          style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600))),
                        Icon(isExpanded ? Icons.keyboard_arrow_up_rounded : Icons.keyboard_arrow_down_rounded,
                          color: ThemeProvider().current.primary, size: 20),
                      ]),
                    ),
                  ),
                  if (isExpanded) ...[
                    GestureDetector(
                      onTap: () => _toggleSelectGroup(group),
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 6, left: 2, right: 2),
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: _allSelectedInGroup(group)
                              ? const Color(0xFF22c55e).withOpacity(0.08)
                              : const Color(0xFF1e293b).withOpacity(0.5),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: _allSelectedInGroup(group)
                                ? const Color(0xFF22c55e).withOpacity(0.3)
                                : Colors.white.withOpacity(0.08),
                          ),
                        ),
                        child: Row(children: [
                          _bookmarkIcon(_allSelectedInGroup(group), size: 14),
                          const SizedBox(width: 8),
                          Text(
                            _allSelectedInGroup(group) ? 'Deselect all' : 'Select all',
                            style: TextStyle(
                              color: _allSelectedInGroup(group)
                                  ? const Color(0xFF22c55e)
                                  : Colors.white.withOpacity(0.5),
                              fontSize: 11, fontWeight: FontWeight.w600,
                            ),
                          ),
                          const Spacer(),
                          Text('$matchCount',
                              style: TextStyle(color: Colors.white.withOpacity(0.35), fontSize: 11)),
                        ]),
                      ),
                    ),
                    ...blocks.map((block) {
                      final offset      = (block['offset'] as String?) ?? '';
                      final headerText  = (block['headerText'] as String?) ?? '';
                      final contextText = (block['contextText'] as String?) ?? '';
                      final isMarked    = _markedOffsets.contains(offset);
                      return Container(
                        margin: const EdgeInsets.only(bottom: 8, left: 4, right: 4),
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: const Color(0xFF0f172a),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: isMarked ? const Color(0xFF22c55e).withOpacity(0.45) : const Color(0xFFf59e0b).withOpacity(0.20)),
                        ),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(headerText, style: TextStyle(color: const Color(0xFF7dd3fc).withOpacity(0.85), fontSize: 9, fontFamily: 'monospace', height: 1.3), maxLines: 3, overflow: TextOverflow.ellipsis),
                          const SizedBox(height: 4),
                          Text('Offset: 0x\u2026${offset.length > 4 ? offset.substring(offset.length - 4) : offset}', style: const TextStyle(color: Color(0xFFf59e0b), fontSize: 11, fontFamily: 'monospace', fontWeight: FontWeight.bold)),
                          const SizedBox(height: 6),
                          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Expanded(child: Container(
                              padding: const EdgeInsets.all(4),
                              decoration: BoxDecoration(color: Colors.black.withOpacity(0.3), borderRadius: BorderRadius.circular(6)),
                              child: _buildAsmContext(contextText),
                            )),
                            const SizedBox(width: 6),
                            GestureDetector(
                              onTap: () => setState(() {
                                if (isMarked) _markedOffsets.remove(offset);
                                else _markedOffsets.add(offset);
                              }),
                              child: _bookmarkIcon(isMarked, size: 30),
                            ),
                          ]),
                        ]),
                      );
                    }),
                  ],
                ],
              );
            }),
          ] else if (!_soSearching && _soSearchCtrl.text.isNotEmpty) ...[
            const SizedBox(height: 10),
            Text('No matches found.', style: TextStyle(color: Colors.white.withOpacity(0.35), fontSize: 12)),
          ],

          if (_markedOffsets.isNotEmpty) ...[
            const SizedBox(height: 14),
            const Divider(color: Colors.white12),
            const SizedBox(height: 6),
            Row(children: [
              _bookmarkIcon(true, size: 15),
              const SizedBox(width: 6),
              Text('${_markedOffsets.length} marked',
                style: const TextStyle(color: Color(0xFF22c55e), fontSize: 12, fontWeight: FontWeight.bold)),
            ]),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _soApplying ? null : _soApplyAll,
                icon: _soApplying
                  ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Icon(Icons.flash_on_rounded, size: 16),
                label: Text(_soApplying ? 'Applying...' : 'Apply All  (${_markedOffsets.length})'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF6366f1),
                  padding: const EdgeInsets.symmetric(vertical: 13),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],

          // Patched output path
          if (_patchedSoPath != null) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: const Color(0xFF22c55e).withOpacity(0.07),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFF22c55e).withOpacity(0.25)),
              ),
              child: Row(children: [
                const Icon(Icons.check_circle_rounded, color: Color(0xFF22c55e), size: 16),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(_patchedSoPath!,
                    style: const TextStyle(color: Color(0xFF22c55e), fontSize: 11, fontFamily: 'monospace'),
                    maxLines: 2, overflow: TextOverflow.ellipsis),
                ),
                GestureDetector(
                  onTap: () {
                    Clipboard.setData(ClipboardData(text: _patchedSoPath!));
                    _showSnack('Path copied', icon: Icons.copy_rounded, color: const Color(0xFF6366f1));
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Icon(Icons.copy_rounded, color: Colors.white54, size: 14),
                  ),
                ),
              ]),
            ),
          ],
        ],
      ),
    );
  }

}

// ── SO Patch data class ───────────────────────────────────────────────────────


// ── Stat chip ─────────────────────────────────────────────────────────────────

class _StatChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  const _StatChip(
      {required this.icon, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.10),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.25)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 13),
          const SizedBox(width: 4),
          Text(
            label,
            style: TextStyle(
                color: color,
                fontSize: 11,
                fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }
}

// ── Orbit painters (cyan theme for Blutter) ───────────────────────────────────

class _BlutterOrbitPainter extends CustomPainter {
  final Color color;
  final double opacity;
  const _BlutterOrbitPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r  = (size.width / 2) - 2;
    final paint = Paint()
      ..color = color.withOpacity(opacity)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round;
    const gapRad = math.pi / 3;
    const arcRad = math.pi / 3;
    for (int i = 0; i < 3; i++) {
      canvas.drawArc(
        Rect.fromCircle(center: Offset(cx, cy), radius: r),
        i * (arcRad + gapRad), arcRad, false, paint,
      );
    }
    final dp = Paint()
      ..color = color.withOpacity(opacity * 0.9)
      ..style = PaintingStyle.fill;
    for (int i = 0; i < 3; i++) {
      final a = i * (arcRad + gapRad) + arcRad / 2;
      canvas.drawCircle(
          Offset(cx + r * math.cos(a), cy + r * math.sin(a)), 2.4, dp);
    }
  }

  @override
  bool shouldRepaint(_BlutterOrbitPainter o) =>
      o.color != color || o.opacity != opacity;
}

class _BlutterDotPainter extends CustomPainter {
  final Color color;
  final double opacity;
  const _BlutterDotPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final r  = (size.width / 2) - 1;
    for (int i = 0; i < 6; i++) {
      final a = i * (math.pi / 3);
      canvas.drawCircle(
        Offset(cx + r * math.cos(a), cy + r * math.sin(a)),
        i % 2 == 0 ? 2.0 : 1.2,
        Paint()
          ..color = color.withOpacity(opacity * (i % 2 == 0 ? 1.0 : 0.5))
          ..style = PaintingStyle.fill,
      );
    }
  }

  @override
  bool shouldRepaint(_BlutterDotPainter o) =>
      o.color != color || o.opacity != opacity;
}

// ── Header chip ───────────────────────────────────────────────────────────────

class _HeaderChip extends StatelessWidget {
  final String label;
  const _HeaderChip(this.label);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: ThemeProvider().current.highlightColor.withOpacity(0.08),
        borderRadius: BorderRadius.circular(5),
        border: Border.all(color: ThemeProvider().current.highlightColor.withOpacity(0.22)),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: ThemeProvider().current.highlightColor,
          fontSize: 9,
          fontFamily: 'monospace',
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

// ── Live pulse dot ─────────────────────────────────────────────────────────────

class _LiveDot extends StatefulWidget {
  final Color color;
  const _LiveDot({this.color = const Color(0xFF22c55e)});

  @override
  State<_LiveDot> createState() => _LiveDotState();
}

class _LiveDotState extends State<_LiveDot>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _ring;
  late final Animation<double> _fade;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat();
    _ring = Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
    _fade = Tween<double>(begin: 0.8, end: 0.0).animate(
        CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 16,
      height: 16,
      child: AnimatedBuilder(
        animation: _ctrl,
        builder: (_, __) => Stack(
          alignment: Alignment.center,
          children: [
            Container(
              width: 6 + _ring.value * 10,
              height: 6 + _ring.value * 10,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: widget.color.withOpacity(_fade.value),
                  width: 1.2,
                ),
              ),
            ),
            Container(
              width: 6,
              height: 6,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: widget.color,
                boxShadow: [
                  BoxShadow(
                    color: widget.color.withOpacity(0.5),
                    blurRadius: 5,
                    spreadRadius: 1,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── AppBar animated icon (blutter / reverse-engineering theme) ─────────────────

class _BlutterAppBarIcon extends StatelessWidget {
  final Animation<double> animation;
  final bool mirrored;
  const _BlutterAppBarIcon({required this.animation, this.mirrored = false});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: animation,
      builder: (_, __) {
        return Transform.scale(
          scaleX: mirrored ? -1 : 1,
          child: CustomPaint(
            size: const Size(20, 22),
            painter: _BlutterIconPainter(phase: animation.value),
          ),
        );
      },
    );
  }
}

class _BlutterIconPainter extends CustomPainter {
  final double phase;
  const _BlutterIconPainter({required this.phase});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final cyan = ThemeProvider().current.highlightColor;

    // Shield outline
    final shieldPath = Path()
      ..moveTo(w * 0.5, 0)
      ..lineTo(w, h * 0.18)
      ..lineTo(w, h * 0.52)
      ..quadraticBezierTo(w, h * 0.82, w * 0.5, h)
      ..quadraticBezierTo(0, h * 0.82, 0, h * 0.52)
      ..lineTo(0, h * 0.18)
      ..close();

    // Fill
    final glow = 0.12 + 0.10 * math.sin(phase * math.pi * 2);
    canvas.drawPath(
      shieldPath,
      Paint()
        ..shader = LinearGradient(
          colors: [
            cyan.withOpacity(glow + 0.05),
            cyan.withOpacity(glow * 0.5),
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ).createShader(Rect.fromLTWH(0, 0, w, h))
        ..style = PaintingStyle.fill,
    );

    // Stroke
    final strokeOpacity = 0.5 + 0.3 * math.sin(phase * math.pi * 2);
    canvas.drawPath(
      shieldPath,
      Paint()
        ..color = cyan.withOpacity(strokeOpacity)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4
        ..strokeJoin = StrokeJoin.round,
    );

    // Binary bits inside the shield (animated scan line)
    final scanY = h * 0.25 + h * 0.5 * phase;
    final scanPaint = Paint()
      ..color = cyan.withOpacity(0.35)
      ..strokeWidth = 1.2
      ..style = PaintingStyle.stroke;
    canvas.drawLine(
        Offset(w * 0.2, scanY), Offset(w * 0.8, scanY), scanPaint);

    // Dot grid (circuit nodes)
    final positions = [
      Offset(w * 0.35, h * 0.32),
      Offset(w * 0.65, h * 0.32),
      Offset(w * 0.5, h * 0.50),
      Offset(w * 0.35, h * 0.68),
      Offset(w * 0.65, h * 0.68),
    ];
    for (int i = 0; i < positions.length; i++) {
      final pulse = 0.5 + 0.5 * math.sin(phase * math.pi * 2 + i * 1.2);
      canvas.drawCircle(
        positions[i],
        1.4 + 0.6 * pulse,
        Paint()
          ..color = cyan.withOpacity(0.4 + 0.4 * pulse)
          ..style = PaintingStyle.fill,
      );
    }
  }

  @override
  bool shouldRepaint(_BlutterIconPainter o) => o.phase != phase;
}
