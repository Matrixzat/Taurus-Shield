import '../utils/theme_provider.dart';
import 'dart:async';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/hbc_channel.dart';
import '../utils/session_state.dart';

// ─────────────────────────────────────────────────────────────────────────────
// Data model
// ─────────────────────────────────────────────────────────────────────────────

class LogLine {
  final String date;
  final String time;
  final String pid;
  final String tid;
  final String level;
  final String tag;
  final String message;
  final String raw;

  const LogLine({
    required this.date, required this.time, required this.pid,
    required this.tid,  required this.level, required this.tag,
    required this.message, required this.raw,
  });

  static final _re = RegExp(
    r'^(\d{2}-\d{2}) (\d{2}:\d{2}:\d{2}\.\d{3})\s+(\d+)\s+(\d+)\s+([VDIWEF])\s+(.*?)\s*: (.*)$',
  );

  factory LogLine.parse(String raw) {
    final m = _re.firstMatch(raw);
    if (m == null) {
      return LogLine(date: '', time: '', pid: '', tid: '',
          level: 'V', tag: '', message: raw, raw: raw);
    }
    return LogLine(
      date: m.group(1)!, time: m.group(2)!, pid: m.group(3)!,
      tid: m.group(4)!,  level: m.group(5)!, tag: m.group(6)!.trim(),
      message: m.group(7)!, raw: raw,
    );
  }

  static Color levelColor(String level) {
    switch (level) {
      case 'V': return const Color(0xFF9E9E9E);
      case 'D': return const Color(0xFF2196F3);
      case 'I': return const Color(0xFF4CAF50);
      case 'W': return const Color(0xFFFFC107);
      case 'E': return const Color(0xFFF44336);
      case 'F': return const Color(0xFFFF5722);
      default:  return const Color(0xFF757575);
    }
  }

  // q must already be lowercased; call with '' to match everything
  bool matchesFilterLower(String q) {
    if (q.isEmpty) return true;
    return tag.toLowerCase().contains(q) ||
        message.toLowerCase().contains(q) ||
        pid.contains(q);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Main screen
// ─────────────────────────────────────────────────────────────────────────────

class LogcatScreen extends StatefulWidget {
  const LogcatScreen({super.key});

  @override
  State<LogcatScreen> createState() => _LogcatScreenState();
}

class _LogcatScreenState extends State<LogcatScreen>
    with TickerProviderStateMixin {

  late TabController _tabCtrl;

  // ── settings (SharedPreferences) ──────────────────────────────────────────
  bool   _wrapLines       = true;
  bool   _expandedLogs    = true;
  bool   _crashOnStartup  = false;
  bool   _originalFormat  = false;
  bool   _stopOnBack      = false;
  bool   _sinceLaunch     = true;
  bool   _bottomEdge      = true;
  int    _updateInterval  = 300;
  double _textSize        = 14;
  int    _displayLimit    = 5000;

  // ── connection reset signal ────────────────────────────────────────────────
  int _forcePermWallSignal = 0;

  late AnimationController _pulseCtrl;
  late Animation<double>   _pulseAnim;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 5, vsync: this);
    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
    _loadSettings().then((_) {
      if (_crashOnStartup) _tabCtrl.animateTo(1);
      _checkAfterShizuku();
    });
  }

  Future<void> _checkAfterShizuku() async {
    final wasGranted = await HbcChannel.logcatCheckAfterShizuku();
    if (wasGranted && mounted) {
      _tabCtrl.animateTo(0);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('✓ Shizuku granted READ_LOGS — logging active'),
        backgroundColor: ThemeProvider().current.highlightColor,
        duration: const Duration(seconds: 4),
      ));
    }
  }

  Future<void> _resetPermission() async {
    if (!mounted) return;
    setState(() => _forcePermWallSignal++);
    _tabCtrl.animateTo(0);
  }

  Future<void> _loadSettings() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _wrapLines      = p.getBool('lc_wrap')          ?? true;
      _expandedLogs   = p.getBool('lc_expanded')      ?? true;
      _crashOnStartup = p.getBool('lc_crash_start')   ?? false;
      _originalFormat = p.getBool('lc_orig_format')   ?? false;
      _stopOnBack     = p.getBool('lc_stop_on_back')  ?? false;
      _sinceLaunch    = p.getBool('lc_since_launch')  ?? true;
      _bottomEdge     = p.getBool('lc_bottom_edge')   ?? true;
      _updateInterval = p.getInt('lc_interval')     ?? 300;
      _textSize       = (p.getDouble('lc_text_size') ?? 14.0);
      // Clamp: if stored value is the old unreasonably large default, reset it.
      final storedLimit = p.getInt('lc_limit') ?? 5000;
      _displayLimit = (storedLimit > 20000 || storedLimit < 500) ? 5000 : storedLimit;
    });
  }

  Future<void> _saveSetting(Future<void> Function(SharedPreferences) fn) async {
    final p = await SharedPreferences.getInstance();
    await fn(p);
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    _pulseCtrl.dispose();
    HbcChannel.invalidateLogcatStream();
    super.dispose();
  }

  void _showGuide(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.85,
        maxChildSize: 0.95,
        minChildSize: 0.5,
        expand: false,
        builder: (ctx, sc) => ListView(
          controller: sc,
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
          children: [
            Center(
              child: Container(
                width: 40, height: 4, margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(color: Colors.white24,
                    borderRadius: BorderRadius.circular(2)),
              ),
            ),
            Row(children: [
              Image.asset('assets/icon/logcat_cat.png', width: 36, height: 36),
              const SizedBox(width: 10),
              const Text('How to use LogCat',
                  style: TextStyle(color: Colors.white,
                      fontSize: 18, fontWeight: FontWeight.bold)),
            ]),
            SizedBox(height: 20),

            _guideSection(
              icon: Icons.list_alt_rounded, color: ThemeProvider().current.highlightColor,
              title: 'Logs tab',
              steps: [
                ('Level filters', 'Tap V D I W E F buttons at the top to show or hide log levels.\nV=Verbose, D=Debug, I=Info, W=Warning, E=Error, F=Fatal.'),
                ('Filter bar', 'Type a package name, tag, or PID to narrow the stream in real-time.'),
                ('Pause / resume', 'Tap the pause icon (top-right) to freeze the view without stopping capture. Tap again or swipe up from the bottom edge to resume.'),
                ('Clear', 'Tap the trash icon to wipe the on-screen buffer AND the device logcat buffer.'),
                ('Auto-scroll', 'The list follows the newest line automatically. Scroll up manually to stop it; reach the bottom again to re-engage.'),
              ],
            ),
            const SizedBox(height: 16),

            _guideSection(
              icon: Icons.bug_report_rounded, color: const Color(0xFFF44336),
              title: 'Crashes tab',
              steps: [
                ('Auto-detection', 'Catches Java crashes (FATAL EXCEPTION), JNI errors, ANR, Native signal crashes (SIGSEGV/SIGABRT), and WTF assertions from the live log.'),
                ('Crash detail', 'Tap a crash card to see the full stack trace. From there you can Copy, Share, or Export the log.'),
                ('Delete', 'Swipe the delete icon on any crash card to remove it from storage.'),
                ('Notification', 'A notification fires instantly when a new crash is detected, even if the app is in the background.'),
              ],
            ),
            const SizedBox(height: 16),

            _guideSection(
              icon: Icons.fiber_manual_record, color: const Color(0xFFF44336),
              title: 'Record tab',
              steps: [
                ('Start / stop', 'Tap the big circle button to begin recording. Every line from the live stream is buffered. Tap again to stop — the session is saved automatically.'),
                ('Saved recordings', 'All sessions appear below the button with their file size. Tap Share to send the file, or delete to remove it.'),
                ('Tip', 'Start a recording just before reproducing a bug, then stop it right after — keeps the file small and focused.'),
              ],
            ),
            const SizedBox(height: 16),

            _guideSection(
              icon: Icons.lock_outlined, color: const Color(0xFF7c3aed),
              title: 'Granting READ_LOGS permission',
              steps: [
                ('First launch', 'When READ_LOGS is not granted the Logs tab shows a permission screen automatically.'),
                ('Prerequisites', 'USB Debugging and Wireless Debugging must both be enabled first.\nSettings → About Phone → tap Build Number 7 times to unlock Developer Options.\nThen enable USB Debugging and Wireless Debugging in Developer Options.'),
                ('Smart setup', 'Tap "SETUP & PAIR" — the app checks each step automatically:\n1. Opens Developer Options if USB Debugging is off\n2. Opens Wireless Debugging settings if it\'s off\n3. Requests overlay permission if needed\n4. Launches the floating pairing dialog'),
                ('PC (alternative)', 'Connect via USB or Wi-Fi ADB and run:\nadb shell pm grant com.taurus.shield android.permission.READ_LOGS'),
                ('One-time only', 'After pairing succeeds the permission sticks permanently — you will never need to do it again unless you reinstall.'),
              ],
            ),
            const SizedBox(height: 16),

            _guideSection(
              icon: Icons.notifications_active_rounded, color: const Color(0xFFFFC107),
              title: 'Foreground service & notification',
              steps: [
                ('Logging notification', 'While the log stream is active a persistent "Logging" notification appears in your shade — this keeps capture alive even when the app is minimised.'),
                ('Exit', 'Tap the Exit button in the notification to stop the service completely from anywhere.'),
                ('Tap to open', 'Tapping the notification body brings you straight back to the LogCat screen.'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _guideSection({
    required IconData icon,
    required Color color,
    required String title,
    required List<(String, String)> steps,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.25)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(icon, color: color, size: 18),
          const SizedBox(width: 8),
          Text(title, style: TextStyle(color: color,
              fontWeight: FontWeight.bold, fontSize: 14)),
        ]),
        const SizedBox(height: 12),
        for (final (label, body) in steps) ...[
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(
              margin: const EdgeInsets.only(top: 2, right: 8),
              width: 6, height: 6,
              decoration: BoxDecoration(color: color, shape: BoxShape.circle),
            ),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(label, style: const TextStyle(color: Colors.white,
                  fontWeight: FontWeight.w600, fontSize: 12)),
              const SizedBox(height: 2),
              Text(body, style: const TextStyle(color: Colors.white60,
                  fontSize: 12, height: 1.5)),
            ])),
          ]),
          const SizedBox(height: 10),
        ],
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        if (_stopOnBack) await HbcChannel.logcatStop();
        await SessionState.clearLastTool();
        if (context.mounted) Navigator.of(context).pop();
      },
      child: Scaffold(
        
      appBar: AppBar(
        
        foregroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        title: AnimatedBuilder(
          animation: _pulseAnim,
          builder: (_, __) => Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              _LogcatAppBarCat(anim: _pulseAnim, flip: false),
              const SizedBox(width: 8),
              const Text('LogCat',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              const SizedBox(width: 8),
              _LogcatAppBarCat(anim: _pulseAnim, flip: true),
            ],
          ),
        ),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF0a0a1a), Color(0xFF0d1a2a)],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
          ),
        ),
        actions: [
          IconButton(
            onPressed: () => _showGuide(context),
            icon: const Icon(Icons.help_outline_rounded, color: Colors.white60),
            tooltip: 'How to use',
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(kTextTabBarHeight + 1),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TabBar(
              controller: _tabCtrl,
              indicatorColor: ThemeProvider().current.highlightColor,
              labelColor: ThemeProvider().current.highlightColor,
              unselectedLabelColor: Colors.white54,
              labelStyle: const TextStyle(fontSize: 10, fontWeight: FontWeight.w600),
              unselectedLabelStyle: const TextStyle(fontSize: 10),
              labelPadding: EdgeInsets.zero,
              tabs: const [
                Tab(icon: Icon(Icons.list_alt_rounded,      size: 17), text: 'Logs'),
                Tab(icon: Icon(Icons.bug_report_rounded,    size: 17), text: 'Crashes'),
                Tab(icon: Icon(Icons.fiber_manual_record,   size: 17), text: 'Record'),
                Tab(icon: Icon(Icons.terminal_rounded,      size: 17), text: 'Shell'),
                Tab(icon: Icon(Icons.settings_rounded,      size: 17), text: 'Settings'),
              ],
            ),
            Container(height: 1, color: ThemeProvider().current.highlightColor.withOpacity(0.20)),
          ]),
        ),
      ),
      body: TabBarView(
        controller: _tabCtrl,
        children: [
          _LogsTab(
            wrapLines:            _wrapLines,
            expandedLogs:         _expandedLogs,
            bottomEdge:           _bottomEdge,
            textSize:             _textSize,
            displayLimit:         _displayLimit,
            forcePermWallSignal:  _forcePermWallSignal,
            sinceLaunch:          _sinceLaunch,
          ),
          _CrashesTab(originalFormat: _originalFormat),
          const _RecordTab(),
          const _TerminalTab(),
          _SettingsTab(
            wrapLines:         _wrapLines,
            expandedLogs:      _expandedLogs,
            crashOnStartup:    _crashOnStartup,
            originalFormat:    _originalFormat,
            stopOnBack:        _stopOnBack,
            sinceLaunch:       _sinceLaunch,
            bottomEdge:        _bottomEdge,
            updateInterval:    _updateInterval,
            textSize:          _textSize,
            displayLimit:      _displayLimit,
            onResetPermission: _resetPermission,
            onChanged: (key, val) {
              _saveSetting((p) async {
                if (val is bool)   p.setBool(key, val);
                if (val is int)    p.setInt(key, val);
                if (val is double) p.setDouble(key, val);
              });
              setState(() {
                switch (key) {
                  case 'lc_wrap':          _wrapLines      = val as bool;   break;
                  case 'lc_expanded':      _expandedLogs   = val as bool;   break;
                  case 'lc_crash_start':   _crashOnStartup = val as bool;   break;
                  case 'lc_orig_format':   _originalFormat = val as bool;   break;
                  case 'lc_stop_on_back':  _stopOnBack     = val as bool;   break;
                  case 'lc_since_launch':  _sinceLaunch    = val as bool;   break;
                  case 'lc_bottom_edge':   _bottomEdge     = val as bool;   break;
                  case 'lc_interval':      _updateInterval = val as int;    break;
                  case 'lc_text_size':     _textSize       = val as double; break;
                  case 'lc_limit':
                    final v = val as int;
                    _displayLimit = v.clamp(500, 20000);
                    break;
                }
              });
            },
          ),
        ],
      ),
    ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// LOGS TAB
// ─────────────────────────────────────────────────────────────────────────────

class _LogsTab extends StatefulWidget {
  final bool   wrapLines;
  final bool   expandedLogs;
  final bool   bottomEdge;
  final double textSize;
  final int    displayLimit;
  final int    forcePermWallSignal;
  final bool   sinceLaunch;

  const _LogsTab({
    required this.wrapLines, required this.expandedLogs,
    required this.bottomEdge, required this.textSize,
    required this.displayLimit,
    this.forcePermWallSignal = 0,
    this.sinceLaunch = true,
  });

  @override
  State<_LogsTab> createState() => _LogsTabState();
}

class _LogsTabState extends State<_LogsTab>
    with AutomaticKeepAliveClientMixin, TickerProviderStateMixin {

  @override
  bool get wantKeepAlive => true;

  late final AnimationController _catCtrl;
  late final Animation<double>   _catAnim;

  @override
  void didUpdateWidget(_LogsTab old) {
    super.didUpdateWidget(old);
    if (widget.forcePermWallSignal != old.forcePermWallSignal) {
      _sub?.cancel();
      _sub = null;
      HbcChannel.invalidateLogcatStream();
      setState(() {
        _hasPermission = false;
        _lines.clear();
        _pendingLines.clear();
        _filteredLines = [];
      });
    }
  }

  final _lines        = <LogLine>[];
  final _pendingLines = <LogLine>[];
  List<LogLine>   _filteredLines  = [];  // cached, only rebuilt on data/filter change
  final _scroll       = ScrollController();
  final _filterCtrl   = TextEditingController();
  StreamSubscription<String>? _sub;
  Timer? _flushTimer;
  // Non-null only while catching up with buffered-before-launch lines
  DateTime? _launchTime;

  bool _hasPermission       = false;
  bool _paused              = false;
  bool _autoScroll          = true;
  bool _usbDebuggingOn      = true;
  bool _wirelessDebuggingOn = true;
  bool _hasRoot             = false;
  // When true, every logcat start/clear/restart goes through `su -c` so
  // READ_LOGS permission is bypassed entirely. Set when the user taps the
  // root card and the SuperUser/Magisk prompt is approved.
  bool _useRoot             = false;
  Set<String> _activeLevels = {'V', 'D', 'I', 'W', 'E', 'F'};
  String _filterQuery = '';

  // Rebuild the filtered list — must be called inside setState or before build
  void _rebuildFiltered() {
    final q = _filterQuery.toLowerCase(); // compute once
    _filteredLines = _lines.where((l) =>
        _activeLevels.contains(l.level) && l.matchesFilterLower(q)).toList();
  }

  // ── log format toggles ────────────────────────────────────────────────────
  bool _fmtDate    = true;
  bool _fmtTime    = true;
  bool _fmtPID     = true;
  bool _fmtTID     = true;
  bool _fmtTag     = true;
  bool _fmtContent = true;

  @override
  void initState() {
    super.initState();
    _catCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);
    _catAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _catCtrl, curve: Curves.easeInOut),
    );
    _scroll.addListener(_onScroll);
    _checkPermAndStart();
  }

  Future<void> _checkPermAndStart() async {
    final granted = await HbcChannel.logcatCheckPermission();
    if (!mounted) return;
    if (!granted) {
      final adbStatus = await HbcChannel.logcatCheckAdbEnabled();
      // Only probe for root when we still need permission. Avoids hitting the
      // filesystem on devices that already granted READ_LOGS via ADB/Shizuku.
      final hasRoot = await HbcChannel.logcatCheckRoot();
      if (mounted) {
        setState(() {
          _usbDebuggingOn      = adbStatus['usbDebugging'] ?? true;
          _wirelessDebuggingOn = adbStatus['wirelessDebugging'] ?? true;
          _hasRoot             = hasRoot;
        });
      }
    }
    setState(() => _hasPermission = granted);
    if (granted) _startStream();
  }

  Future<void> _refreshAdbStatus() async {
    final adbStatus = await HbcChannel.logcatCheckAdbEnabled();
    if (mounted) {
      setState(() {
        _usbDebuggingOn      = adbStatus['usbDebugging'] ?? true;
        _wirelessDebuggingOn = adbStatus['wirelessDebugging'] ?? true;
      });
    }
  }

  // Returns true when a LogLine's timestamp predates [_launchTime].
  // Once we see a line at or after launch, we null out [_launchTime] so
  // parsing is skipped for every subsequent line (zero overhead after catch-up).
  bool _isPreLaunch(LogLine ll) {
    final lt = _launchTime;
    if (lt == null) return false;
    if (ll.date.isEmpty || ll.time.isEmpty) return false;
    try {
      final d = ll.date.split('-');
      final t = ll.time.split(':');
      final sMs = t[2].split('.');
      final lineTime = DateTime(lt.year,
          int.parse(d[0]), int.parse(d[1]),
          int.parse(t[0]), int.parse(t[1]),
          int.parse(sMs[0]),
          sMs.length > 1 ? int.parse(sMs[1]) : 0);
      if (!lineTime.isBefore(lt.subtract(const Duration(seconds: 1)))) {
        _launchTime = null; // caught up — stop filtering
        return false;
      }
      return true;
    } catch (_) { return false; }
  }

  void _startStream() {
    if (widget.sinceLaunch) _launchTime = DateTime.now();
    HbcChannel.logcatStart(useRoot: _useRoot);
    SessionState.saveLastTool('logcat');
    // Android now sends ArrayList<String> batches (up to 150 lines per event)
    // instead of one String per line — this is the key fix for the ANR/freeze.
    _sub = HbcChannel.logcatStream.listen((raw) {
      if (_paused || !mounted) return;
      // Handle both batch (List<dynamic> sent by Android) and single-string events
      final List<String> incoming;
      if (raw is List) {
        incoming = (raw as List).cast<String>();
      } else {
        incoming = [raw.toString()];
      }
      for (final line in incoming) {
        if (line.contains('beginning of crash')) continue;
        final parsed = LogLine.parse(line);
        if (_isPreLaunch(parsed)) continue;
        _pendingLines.add(parsed);
      }
    });
    // Flush pending lines to UI at most every 200 ms.
    // Cap each flush at 300 lines so a burst never causes a multi-second rebuild.
    // No intermediate list allocation — move directly from pending into _lines.
    _flushTimer = Timer.periodic(const Duration(milliseconds: 200), (_) {
      if (!mounted || _pendingLines.isEmpty) return;
      const maxPerFlush = 300;
      final take = _pendingLines.length.clamp(0, maxPerFlush);
      setState(() {
        _lines.addAll(_pendingLines.getRange(0, take)); // lazy iterable, no copy
        _pendingLines.removeRange(0, take);
        if (_lines.length > widget.displayLimit) {
          _lines.removeRange(0, _lines.length - widget.displayLimit);
        }
        _rebuildFiltered(); // update cache after lines change
      });
      if (_autoScroll && _scroll.hasClients) {
        _scroll.jumpTo(_scroll.position.maxScrollExtent);
      }
    });
  }

  void _onScroll() {
    final atBottom = _scroll.position.pixels >=
        _scroll.position.maxScrollExtent - 40;
    if (atBottom != _autoScroll) setState(() => _autoScroll = atBottom);
  }

  bool _restarting = false;
  Timer? _shizukuPollTimer;

  void _startShizukuPolling(void Function(String) onMsg) {
    _shizukuPollTimer?.cancel();
    _shizukuPollTimer = Timer.periodic(const Duration(seconds: 2), (_) async {
      final res = await HbcChannel.logcatShizukuGrant();
      if (!mounted) { _shizukuPollTimer?.cancel(); return; }
      if (res == 'granted') {
        _shizukuPollTimer?.cancel();
        setState(() => _hasPermission = true);
        _startStream();
      } else if (res == 'not_available' || res == 'failed') {
        _shizukuPollTimer?.cancel();
        onMsg(res == 'not_available'
            ? '✗ Shizuku is not running.'
            : '✗ Grant failed. Try the ADB method instead.');
      }
    });
  }

  Future<void> _restartLogging() async {
    if (_restarting) return;
    setState(() => _restarting = true);
    _flushTimer?.cancel();
    // Cancel Dart subscription (stops the pump loop via onCancel)
    await _sub?.cancel();
    _sub = null;
    // Invalidate cached stream so a new EventChannel subscription is created
    HbcChannel.invalidateLogcatStream();
    // Clear display immediately
    setState(() { _lines.clear(); _pendingLines.clear(); _filteredLines = []; });
    // Tell the service to atomically kill & restart (no stop-then-start gap)
    await HbcChannel.logcatRestart(useRoot: _useRoot);
    // Brief wait so the restart task is queued before we re-subscribe
    await Future.delayed(const Duration(milliseconds: 150));
    if (!mounted) return;
    _startStream();
    setState(() => _restarting = false);
  }


  @override
  void dispose() {
    _catCtrl.dispose();
    _flushTimer?.cancel();
    _sub?.cancel();
    _shizukuPollTimer?.cancel();
    _scroll.dispose();
    _filterCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    if (!_hasPermission) return _buildPermissionWall();

    final filtered = _filteredLines;

    return GestureDetector(
      onVerticalDragEnd: widget.bottomEdge ? (d) {
        if (d.primaryVelocity != null && d.primaryVelocity! < -200) {
          setState(() => _paused = false);
        }
      } : null,
      child: Column(children: [
        // ── top toolbar ────────────────────────────────────────────────────
        Container(
          color: const Color(0xFF0d0d20),
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
          child: Row(children: [
            // level toggles
            for (final lvl in ['V','D','I','W','E','F'])
              Padding(
                padding: const EdgeInsets.only(right: 4),
                child: GestureDetector(
                  onTap: () => setState(() {
                    _activeLevels.contains(lvl)
                        ? _activeLevels.remove(lvl)
                        : _activeLevels.add(lvl);
                    _rebuildFiltered();
                  }),
                  child: Container(
                    width: 28, height: 28,
                    decoration: BoxDecoration(
                      color: _activeLevels.contains(lvl)
                          ? LogLine.levelColor(lvl).withOpacity(0.25)
                          : Colors.transparent,
                      border: Border.all(
                        color: _activeLevels.contains(lvl)
                            ? LogLine.levelColor(lvl) : Colors.white24,
                        width: 1.2,
                      ),
                      borderRadius: BorderRadius.circular(5),
                    ),
                    child: Center(child: Text(lvl,
                        style: TextStyle(
                          fontSize: 11, fontWeight: FontWeight.bold,
                          color: _activeLevels.contains(lvl)
                              ? LogLine.levelColor(lvl) : Colors.white38,
                        ))),
                  ),
                ),
              ),
            const Spacer(),
            // format
            GestureDetector(
              onTap: _showFormatDialog,
              child: const Icon(Icons.format_list_bulleted_rounded, color: Colors.white60, size: 22),
            ),
            const SizedBox(width: 12),
            // pause/resume
            GestureDetector(
              onTap: () => setState(() => _paused = !_paused),
              child: Icon(_paused ? Icons.play_arrow_rounded : Icons.pause_rounded,
                  color: _paused ? const Color(0xFF4CAF50) : Colors.white60, size: 22),
            ),
            const SizedBox(width: 12),
            // clear
            GestureDetector(
              onTap: () { HbcChannel.logcatClear(useRoot: _useRoot); setState(() { _lines.clear(); _pendingLines.clear(); _filteredLines = []; }); },
              child: const Icon(Icons.delete_outline_rounded, color: Colors.white60, size: 22),
            ),
            const SizedBox(width: 12),
            // restart logging
            GestureDetector(
              onTap: _restarting ? null : _restartLogging,
              child: _restarting
                  ? SizedBox(
                      width: 22, height: 22,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: ThemeProvider().current.highlightColor))
                  : const Icon(Icons.restart_alt_rounded, color: Colors.white60, size: 22),
            ),
          ]),
        ),
        // ── filter bar ─────────────────────────────────────────────────────
        Container(
          color: const Color(0xFF0d0d20),
          padding: const EdgeInsets.fromLTRB(8, 0, 8, 6),
          child: TextField(
            controller: _filterCtrl,
            onChanged: (v) => setState(() { _filterQuery = v; _rebuildFiltered(); }),
            style: const TextStyle(color: Colors.white, fontSize: 13),
            decoration: InputDecoration(
              hintText: 'Filter by tag, package or PID…',
              hintStyle: const TextStyle(color: Colors.white38, fontSize: 13),
              prefixIcon: const Icon(Icons.search_rounded, color: Colors.white38, size: 18),
              suffixIcon: _filterQuery.isNotEmpty
                  ? GestureDetector(
                      onTap: () { _filterCtrl.clear(); setState(() { _filterQuery = ''; _rebuildFiltered(); }); },
                      child: const Icon(Icons.close_rounded, color: Colors.white38, size: 18))
                  : null,
              isDense: true,
              filled: true,
              fillColor: const Color(0xFF151530),
              contentPadding: const EdgeInsets.symmetric(vertical: 8),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide.none),
            ),
          ),
        ),
        // ── log list + auto-scroll FAB ─────────────────────────────────────
        Expanded(
          child: Stack(children: [
            filtered.isEmpty
                ? const Center(child: Text('No logs yet.',
                    style: TextStyle(color: Colors.white38)))
                : ListView.builder(
                    controller: _scroll,
                    itemCount: filtered.length,
                    itemBuilder: (ctx, i) => _buildLine(filtered[i]),
                  ),
            // scroll-to-bottom FAB
            if (!_autoScroll && !_paused)
              Positioned(
                right: 12, bottom: 12,
                child: GestureDetector(
                  onTap: () {
                    setState(() => _autoScroll = true);
                    if (_scroll.hasClients) {
                      _scroll.animateTo(
                        _scroll.position.maxScrollExtent,
                        duration: const Duration(milliseconds: 300),
                        curve: Curves.easeOut,
                      );
                    }
                  },
                  child: AnimatedScale(
                    scale: _autoScroll ? 0.0 : 1.0,
                    duration: const Duration(milliseconds: 180),
                    curve: Curves.easeOut,
                    child: Container(
                      width: 40, height: 40,
                      decoration: BoxDecoration(
                        color: const Color(0xFF7c3aed),
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFF7c3aed).withOpacity(0.45),
                            blurRadius: 10, offset: const Offset(0, 3),
                          ),
                        ],
                      ),
                      child: const Icon(Icons.keyboard_arrow_down_rounded,
                          color: Colors.white, size: 22),
                    ),
                  ),
                ),
              ),
          ]),
        ),
        // ── paused banner ─────────────────────────────────────────────────
        if (_paused)
          GestureDetector(
            onTap: () => setState(() { _paused = false; _autoScroll = true; }),
            child: Container(
              color: const Color(0xFFFFC107).withOpacity(0.15),
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.pause_circle_rounded, color: Color(0xFFFFC107), size: 16),
                  SizedBox(width: 6),
                  Text('PAUSED — tap to resume',
                      style: TextStyle(color: Color(0xFFFFC107), fontSize: 12)),
                ],
              ),
            ),
          ),
      ]),
    );
  }

  void _showFormatDialog() {
    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(builder: (ctx, ss) {
        Widget fmtRow(String label, bool val, void Function(bool) onChanged) =>
            InkWell(
              onTap: () { ss(() {}); setState(() => onChanged(!val)); },
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 11),
                child: Row(children: [
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    width: 22, height: 22,
                    decoration: BoxDecoration(
                      color: val ? ThemeProvider().current.highlightColor : Colors.transparent,
                      border: Border.all(
                        color: val ? ThemeProvider().current.highlightColor : Colors.white38,
                        width: 2,
                      ),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: val ? const Icon(Icons.check_rounded,
                        color: Colors.white, size: 14) : const SizedBox(),
                  ),
                  const SizedBox(width: 14),
                  Text(label,
                      style: const TextStyle(fontSize: 15, color: Colors.white)),
                ]),
              ),
            );

        return Dialog(
          
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const SizedBox(height: 16),
            const Icon(Icons.format_list_bulleted_rounded, size: 28, color: Colors.white60),
            const SizedBox(height: 6),
            const Text('Logs format',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: Colors.white)),
            const SizedBox(height: 8),
            const Divider(height: 1, color: Colors.white12),
            fmtRow('Date',    _fmtDate,    (v) => _fmtDate    = v),
            fmtRow('Time',    _fmtTime,    (v) => _fmtTime    = v),
            fmtRow('PID',     _fmtPID,     (v) => _fmtPID     = v),
            fmtRow('TID',     _fmtTID,     (v) => _fmtTID     = v),
            fmtRow('Tag',     _fmtTag,     (v) => _fmtTag     = v),
            fmtRow('Content', _fmtContent, (v) => _fmtContent = v),
            Divider(height: 1, color: Colors.white12),
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text('Close',
                  style: TextStyle(color: ThemeProvider().current.highlightColor, fontSize: 15)),
            ),
            const SizedBox(height: 4),
          ]),
        );
      }),
    );
  }

  Widget _buildLine(LogLine line) {
    final col = LogLine.levelColor(line.level);
    final card = Container(
      margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: col.withOpacity(0.04),
        borderRadius: BorderRadius.circular(6),
        border: Border(left: BorderSide(color: col, width: 2.5)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // header row
        Row(children: [
          Container(
            width: 20, height: 20,
            decoration: BoxDecoration(
              color: col.withOpacity(0.18),
              borderRadius: BorderRadius.circular(4),
            ),
            child: Center(child: Text(line.level,
                style: TextStyle(color: col, fontSize: 10,
                    fontWeight: FontWeight.bold))),
          ),
          const SizedBox(width: 6),
          if (line.date.isNotEmpty) ...[
            if (_fmtDate) Text(line.date,
                style: const TextStyle(color: Colors.white38, fontSize: 10)),
            if (_fmtDate) const SizedBox(width: 4),
            if (_fmtTime) Text(line.time,
                style: const TextStyle(color: Colors.white38, fontSize: 10)),
            if (_fmtTime) const SizedBox(width: 4),
            if (_fmtPID) Text('PID:${line.pid}',
                style: const TextStyle(color: Colors.white24, fontSize: 10)),
            if (_fmtPID) const SizedBox(width: 4),
            if (_fmtTID) Text('TID:${line.tid}',
                style: const TextStyle(color: Colors.white24, fontSize: 10)),
            if (_fmtTID) const SizedBox(width: 4),
          ],
          if (_fmtTag)
            Flexible(child: Text(line.tag,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: col.withOpacity(0.85),
                    fontSize: 10, fontWeight: FontWeight.w600))),
        ]),
        if (_fmtContent) ...[
          const SizedBox(height: 3),
          Text(
            line.message.isEmpty ? line.raw : line.message,
            style: TextStyle(
              color: col.withOpacity(0.90),
              fontSize: widget.textSize - 1,
              fontFamily: 'monospace',
              height: 1.35,
            ),
            softWrap: widget.wrapLines,
            overflow: widget.wrapLines ? TextOverflow.visible : TextOverflow.ellipsis,
            maxLines: widget.expandedLogs ? null : 2,
          ),
        ],
      ]),
    );

    return GestureDetector(
      onLongPressStart: (d) => _showLineMenu(line, d.globalPosition),
      child: card,
    );
  }

  Future<void> _showLineMenu(LogLine line, Offset globalPos) async {
    final RenderBox? overlay =
        Overlay.of(context).context.findRenderObject() as RenderBox?;
    if (overlay == null) return;

    final chosen = await showMenu<String>(
      context: context,
      color: const Color(0xFF1e1e3a),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 8,
      position: RelativeRect.fromRect(
        Rect.fromLTWH(globalPos.dx, globalPos.dy, 1, 1),
        Offset.zero & overlay.size,
      ),
      items: [
        PopupMenuItem(
          value: 'select',
          child: Row(children: [
            Icon(Icons.select_all_rounded, size: 18, color: ThemeProvider().current.highlightColor),
            const SizedBox(width: 12),
            const Text('Select', style: TextStyle(color: Colors.white)),
          ]),
        ),
        PopupMenuItem(
          value: 'copy',
          child: Row(children: [
            Icon(Icons.copy_rounded, size: 18, color: ThemeProvider().current.highlightColor),
            const SizedBox(width: 12),
            const Text('Copy', style: TextStyle(color: Colors.white)),
          ]),
        ),
        PopupMenuItem(
          value: 'filter',
          child: Row(children: [
            Icon(Icons.filter_list_rounded, size: 18, color: ThemeProvider().current.highlightColor),
            const SizedBox(width: 12),
            const Text('Create filter', style: TextStyle(color: Colors.white)),
          ]),
        ),
      ],
    );

    if (!mounted || chosen == null) return;

    switch (chosen) {
      case 'select':
        _showSelectDialog(line);
        break;
      case 'copy':
        await Clipboard.setData(ClipboardData(text: line.raw));
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Line copied to clipboard'),
            duration: Duration(seconds: 2),
          ));
        }
        break;
      case 'filter':
        _showCreateFilterDialog(line);
        break;
    }
  }

  void _showSelectDialog(LogLine line) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1e1e3a),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: Row(children: [
          Container(
            width: 22, height: 22,
            decoration: BoxDecoration(
              color: LogLine.levelColor(line.level).withOpacity(0.2),
              borderRadius: BorderRadius.circular(4),
            ),
            child: Center(
              child: Text(line.level,
                  style: TextStyle(
                      color: LogLine.levelColor(line.level),
                      fontSize: 11, fontWeight: FontWeight.bold)),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(line.tag,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    color: LogLine.levelColor(line.level), fontSize: 14)),
          ),
        ]),
        content: SingleChildScrollView(
          child: SelectionArea(
            child: Text(
              line.raw,
              style: const TextStyle(
                  color: Colors.white70, fontSize: 12,
                  fontFamily: 'monospace', height: 1.5),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: line.raw));
              if (mounted) Navigator.pop(context);
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                  content: Text('Copied to clipboard'),
                  duration: Duration(seconds: 2),
                ));
              }
            },
            child: Text('Copy', style: TextStyle(color: ThemeProvider().current.highlightColor)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close', style: TextStyle(color: Colors.white54)),
          ),
        ],
      ),
    );
  }

  void _showCreateFilterDialog(LogLine line) {
    final levelColor = LogLine.levelColor(line.level);
    final hasTag = line.tag.isNotEmpty;
    final hasPid = line.pid.isNotEmpty;
    final hasTid = line.tid.isNotEmpty;
    final msg = line.message.isNotEmpty ? line.message : line.raw;
    final firstWord = msg.trim().split(RegExp(r'[\s:,()]+')).firstWhere(
        (w) => w.length > 2, orElse: () => '');

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1e1e3a),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: const Text('Create filter',
            style: TextStyle(color: Colors.white, fontSize: 16)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Filter the log view by:',
                style: TextStyle(color: Colors.white54, fontSize: 12)),
            const SizedBox(height: 12),
            if (hasTag)
              _filterOption(
                icon: Icons.label_outline_rounded,
                label: 'Tag',
                value: line.tag,
                color: levelColor,
                onTap: () {
                  Navigator.pop(context);
                  _applyQuickFilter(line.tag);
                },
              ),
            if (hasPid) ...[
              const SizedBox(height: 8),
              _filterOption(
                icon: Icons.memory_rounded,
                label: 'PID',
                value: line.pid,
                color: const Color(0xFF3b82f6),
                onTap: () {
                  Navigator.pop(context);
                  _applyQuickFilter(line.pid);
                },
              ),
            ],
            if (hasTid && line.tid != line.pid) ...[
              const SizedBox(height: 8),
              _filterOption(
                icon: Icons.hub_rounded,
                label: 'TID',
                value: line.tid,
                color: const Color(0xFF8b5cf6),
                onTap: () {
                  Navigator.pop(context);
                  _applyQuickFilter(line.tid);
                },
              ),
            ],
            const SizedBox(height: 8),
            _filterOption(
              icon: Icons.tune_rounded,
              label: 'Level',
              value: _levelName(line.level),
              color: levelColor,
              onTap: () {
                Navigator.pop(context);
                setState(() {
                  _activeLevels = {line.level};
                  _rebuildFiltered();
                });
              },
            ),
            if (firstWord.isNotEmpty) ...[
              const SizedBox(height: 8),
              _filterOption(
                icon: Icons.text_fields_rounded,
                label: 'Text',
                value: firstWord.length > 30
                    ? '${firstWord.substring(0, 30)}...'
                    : firstWord,
                color: ThemeProvider().current.highlightColor,
                onTap: () {
                  Navigator.pop(context);
                  _applyQuickFilter(firstWord);
                },
              ),
            ],
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel',
                style: TextStyle(color: Colors.white54)),
          ),
        ],
      ),
    );
  }

  String _levelName(String level) {
    switch (level) {
      case 'V': return 'Verbose only';
      case 'D': return 'Debug only';
      case 'I': return 'Info only';
      case 'W': return 'Warning only';
      case 'E': return 'Error only';
      case 'F': return 'Fatal only';
      default: return level;
    }
  }

  Widget _filterOption({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
    required VoidCallback onTap,
  }) =>
      GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: color.withOpacity(0.10),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: color.withOpacity(0.30)),
          ),
          child: Row(children: [
            Icon(icon, size: 16, color: color),
            const SizedBox(width: 8),
            Text('$label: ',
                style: TextStyle(
                    color: color,
                    fontSize: 12, fontWeight: FontWeight.w600)),
            Expanded(
              child: Text(value,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 12, fontFamily: 'monospace')),
            ),
          ]),
        ),
      );

  void _applyQuickFilter(String query) {
    _filterCtrl.text = query;
    setState(() { _filterQuery = query; _rebuildFiltered(); });
  }

  // ── permission wall ────────────────────────────────────────────────────────
  Widget _buildPermissionWall() {
    bool pairing         = false;
    String pairMsg       = '';
    bool shizukuLoading  = false;
    String shizukuMsg    = '';

    return StatefulBuilder(builder: (ctx, ss) => SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const SizedBox(height: 16),
        Center(
          child: AnimatedBuilder(
            animation: _catAnim,
            builder: (_, __) {
              final t = _catAnim.value;
              return Container(
                width: 88,
                height: 88,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: ThemeProvider().current.highlightColor.withOpacity(0.18 + 0.40 * t),
                      blurRadius: 18 + 22 * t,
                      spreadRadius: 2 + 4 * t,
                    ),
                  ],
                ),
                child: Opacity(
                  opacity: 0.60 + 0.40 * t,
                  child: Image.asset(
                    'assets/icon/logcat_cat.png',
                    width: 88,
                    height: 88,
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 16),
        const Text('READ_LOGS Permission Required',
            style: TextStyle(color: Colors.white,
                fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text(
          'This permission lets the app read all device logs.\n'
          'It must be granted once via ADB — either from a PC or wirelessly from your phone.',
          style: TextStyle(color: Colors.white60, fontSize: 13, height: 1.5)),
        const SizedBox(height: 16),

        // ── ADB status banner ───────────────────────────────────────────────
        if (!_usbDebuggingOn || !_wirelessDebuggingOn)
          Container(
            margin: const EdgeInsets.only(bottom: 16),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFFFFC107).withOpacity(0.08),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: const Color(0xFFFFC107).withOpacity(0.35)),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                const Icon(Icons.warning_amber_rounded, color: Color(0xFFFFC107), size: 18),
                const SizedBox(width: 8),
                const Expanded(child: Text('Setup required before pairing',
                    style: TextStyle(color: Color(0xFFFFC107),
                        fontWeight: FontWeight.bold, fontSize: 13))),
                GestureDetector(
                  onTap: () async {
                    await _refreshAdbStatus();
                    ss(() {});
                  },
                  child: const Icon(Icons.refresh_rounded, color: Color(0xFFFFC107), size: 18),
                ),
              ]),
              const SizedBox(height: 8),
              _adbStatusRow('USB Debugging', _usbDebuggingOn),
              const SizedBox(height: 4),
              _adbStatusRow('Wireless Debugging', _wirelessDebuggingOn),
              if (!_usbDebuggingOn) ...[
                const SizedBox(height: 8),
                const Text(
                  'Enable Developer Options first:\nSettings → About Phone → tap Build Number 7 times\nThen enable USB Debugging in Developer Options.',
                  style: TextStyle(color: Colors.white54, fontSize: 11, height: 1.5),
                ),
              ],
            ]),
          ),

        const SizedBox(height: 8),

        // PC option
        _permCard(
          icon: Icons.computer_rounded, color: const Color(0xFF10b981),
          title: 'Grant via PC (USB or WiFi)',
          body: 'Run this command once from a computer with ADB installed:',
          child: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0xFF151530),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(children: [
              Expanded(child: Text(
                'adb shell pm grant com.taurus.shield android.permission.READ_LOGS',
                style: TextStyle(color: ThemeProvider().current.highlightColor, fontFamily: 'monospace',
                    fontSize: 11),
              )),
              IconButton(
                onPressed: () => Clipboard.setData(const ClipboardData(
                  text: 'adb shell pm grant com.taurus.shield android.permission.READ_LOGS')),
                icon: const Icon(Icons.copy_rounded, size: 16, color: Colors.white54),
                padding: EdgeInsets.zero, constraints: const BoxConstraints(),
              ),
            ]),
          ),
        ),
        const SizedBox(height: 12),

        // Wireless ADB option — smart sequential flow
        _permCard(
          icon: Icons.wifi_rounded, color: const Color(0xFF7c3aed),
          title: 'Pair Wirelessly (no PC needed)',
          body: 'Tap the button below — it will guide you through each step automatically:\n'
                '1. Enable USB Debugging (if off)\n'
                '2. Enable Wireless Debugging (if off)\n'
                '3. Allow overlay permission (if needed)\n'
                '4. Launch the pairing dialog (code auto-detected via logcat)',
          child: Column(children: [
            const SizedBox(height: 12),
            if (pairMsg.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Text(pairMsg,
                    style: TextStyle(
                      color: pairMsg.startsWith('✓') || pairMsg.contains('granted')
                          ? const Color(0xFF4CAF50)
                          : pairMsg.startsWith('⚙') || pairMsg.startsWith('⏳')
                              ? const Color(0xFF60a5fa)
                              : const Color(0xFFf87171),
                      fontSize: 12, height: 1.5,
                    )),
              ),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: pairing ? null : () async {
                  ss(() { pairing = true; pairMsg = ''; });
                  try {
                    // Step 1: USB Debugging
                    var adbStatus = await HbcChannel.logcatCheckAdbEnabled();
                    if (!(adbStatus['usbDebugging'] ?? false)) {
                      ss(() => pairMsg = '⚙ USB Debugging is OFF.\nOpening Developer Options — enable USB Debugging, then come back.');
                      await Future.delayed(const Duration(milliseconds: 500));
                      await HbcChannel.logcatOpenDeveloperOptions();
                      for (int i = 0; i < 120; i++) {
                        await Future.delayed(const Duration(seconds: 1));
                        if (!mounted) return;
                        try {
                          adbStatus = await HbcChannel.logcatCheckAdbEnabled();
                          if (adbStatus['usbDebugging'] ?? false) break;
                        } catch (_) {}
                      }
                      if (!(adbStatus['usbDebugging'] ?? false)) {
                        ss(() { pairing = false; pairMsg = '✗ USB Debugging still disabled. Enable it in Developer Options first.'; });
                        await _refreshAdbStatus();
                        return;
                      }
                      await _refreshAdbStatus();
                      ss(() => pairMsg = '✓ USB Debugging enabled! Checking Wireless Debugging…');
                      await Future.delayed(const Duration(milliseconds: 800));
                    }

                    // Step 2: Wireless Debugging
                    adbStatus = await HbcChannel.logcatCheckAdbEnabled();
                    if (!(adbStatus['wirelessDebugging'] ?? false)) {
                      ss(() => pairMsg = '⚙ Wireless Debugging is OFF.\nOpening Developer Options — scroll down and enable Wireless Debugging, then come back.');
                      await Future.delayed(const Duration(milliseconds: 500));
                      await HbcChannel.logcatOpenWirelessDebugging();
                      for (int i = 0; i < 120; i++) {
                        await Future.delayed(const Duration(seconds: 1));
                        if (!mounted) return;
                        try {
                          adbStatus = await HbcChannel.logcatCheckAdbEnabled();
                          if (adbStatus['wirelessDebugging'] ?? false) break;
                        } catch (_) {}
                      }
                      if (!(adbStatus['wirelessDebugging'] ?? false)) {
                        ss(() { pairing = false; pairMsg = '✗ Wireless Debugging still disabled. Enable it in Developer Options.'; });
                        await _refreshAdbStatus();
                        return;
                      }
                      await _refreshAdbStatus();
                      ss(() => pairMsg = '✓ Wireless Debugging enabled! Checking overlay permission…');
                      await Future.delayed(const Duration(milliseconds: 800));
                    }

                    // Step 3: Overlay permission
                    final hasOverlay = await HbcChannel.logcatCheckOverlayPermission();
                    if (!hasOverlay) {
                      ss(() => pairMsg = '⚙ Overlay permission needed.\nAllow "Display over other apps" for Taurus Shield, then come back.');
                      await Future.delayed(const Duration(milliseconds: 500));
                      await HbcChannel.logcatRequestOverlayPermission();
                      for (int i = 0; i < 120; i++) {
                        await Future.delayed(const Duration(seconds: 1));
                        if (!mounted) return;
                        try {
                          final ov = await HbcChannel.logcatCheckOverlayPermission();
                          if (ov) break;
                        } catch (_) {}
                      }
                      final ov = await HbcChannel.logcatCheckOverlayPermission();
                      if (!ov) {
                        ss(() { pairing = false; pairMsg = '✗ Overlay permission not granted. Allow it in settings first.'; });
                        return;
                      }
                      ss(() => pairMsg = '✓ Overlay allowed! Launching pairing dialog…');
                      await Future.delayed(const Duration(milliseconds: 800));
                    }

                    // Step 4: Launch floating pair dialog
                    await HbcChannel.logcatShowFloatingPair();
                    ss(() {
                      pairing = false;
                      pairMsg = '✓ Floating dialog launched.\nGo to Wireless Debugging → "Pair device with pairing code" — the code will be auto-filled!';
                    });
                    for (int i = 0; i < 60; i++) {
                      await Future.delayed(const Duration(seconds: 2));
                      if (!mounted) return;
                      try {
                        final ok = await HbcChannel.logcatCheckPermission();
                        if (ok && mounted) {
                          setState(() => _hasPermission = true);
                          _startStream();
                          return;
                        }
                      } catch (_) {}
                    }
                  } catch (e) {
                    ss(() {
                      pairing = false;
                      pairMsg = '✗ ${e.toString().replaceAll('PlatformException(', '').replaceAll(',', ':').split(':').take(2).join(' ').trim()}';
                    });
                  } finally {
                    ss(() => pairing = false);
                  }
                },
                icon: pairing
                    ? const SizedBox(width: 16, height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Icon(Icons.open_in_new_rounded, size: 18),
                label: Text(pairing ? 'Setting up…' : 'SETUP & PAIR'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF7c3aed),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8)),
                ),
              ),
            ),
          ]),
        ),

        const SizedBox(height: 12),

        // Shizuku option
        _permCard(
          icon: Icons.security_rounded, color: const Color(0xFF0ea5e9),
          title: 'Grant via Shizuku (no PC, no USB)',
          body: 'Shizuku lets Taurus Shield run the grant command internally.\n'
                '1. Install "Shizuku" app from Play Store\n'
                '2. Start Shizuku via Wireless Debugging or from a PC once\n'
                '3. Tap the button below — permission is granted instantly',
          child: Column(children: [
            const SizedBox(height: 12),
            if (shizukuMsg.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Text(shizukuMsg,
                    style: TextStyle(
                      color: shizukuMsg.startsWith('✓')
                          ? const Color(0xFF4CAF50) : const Color(0xFFf87171),
                      fontSize: 12, height: 1.5,
                    )),
              ),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: shizukuLoading ? null : () async {
                  ss(() { shizukuLoading = true; shizukuMsg = ''; });
                  try {
                    final res = await HbcChannel.logcatShizukuGrant();
                    if (res == 'granted') {
                      setState(() => _hasPermission = true);
                      _startStream();
                    } else if (res == 'permission_requested') {
                      ss(() {
                        shizukuMsg = '⏳ Waiting for Shizuku permission… accept the dialog above.';
                      });
                      _startShizukuPolling((msg) => ss(() => shizukuMsg = msg));
                    } else if (res == 'not_available') {
                      ss(() {
                        shizukuMsg = '✗ Shizuku is not running.\nInstall & start Shizuku first.';
                      });
                    } else {
                      ss(() { shizukuMsg = '✗ Grant failed. Try the ADB method instead.'; });
                    }
                  } catch (e) {
                    ss(() {
                      shizukuMsg = '✗ Error: ${e.toString().split(':').first.trim()}';
                    });
                  } finally {
                    ss(() => shizukuLoading = false);
                  }
                },
                icon: shizukuLoading
                    ? const SizedBox(width: 16, height: 16,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: Colors.black87))
                    : const Icon(Icons.security_rounded, size: 18),
                label: Text(shizukuLoading ? 'Granting…' : 'GRANT VIA SHIZUKU'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF0ea5e9),
                  foregroundColor: Colors.black87,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8)),
                ),
              ),
            ),
          ]),
        ),

        // ── Root option (only shown when `su` is available) ────────────────
        // Rooted devices don't need READ_LOGS at all — logcat itself is run
        // through `su -c` so the OS reads logs as root. One tap = approve the
        // SuperUser prompt once → logging starts immediately. No permission
        // grant, no pm changes, no reboot needed.
        if (_hasRoot) ...[
          const SizedBox(height: 12),
          _permCard(
            icon: Icons.bolt_rounded, color: const Color(0xFF22c55e),
            title: 'Start with Root (no permission needed)',
            body: 'Your phone appears to be rooted — no permission required.\n'
                  '1. Tap the button below\n'
                  '2. Approve the SuperUser / Magisk prompt once\n'
                  '3. Logs start streaming instantly',
            child: Column(children: [
              const SizedBox(height: 12),
              if (_rootMsg.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Text(_rootMsg,
                      style: TextStyle(
                        color: _rootMsg.startsWith('✓')
                            ? const Color(0xFF4CAF50)
                            : const Color(0xFFf87171),
                        fontSize: 12, height: 1.5,
                      )),
                ),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _rootGranting ? null : () async {
                    setState(() { _rootGranting = true; _rootMsg = ''; });
                    try {
                      final res = await HbcChannel.logcatTestRoot();
                      if (!mounted) return;
                      if (res == 'granted') {
                        setState(() {
                          _useRoot = true;
                          _hasPermission = true;
                          _rootGranting = false;
                          _rootMsg = '✓ Root approved — logging active';
                        });
                        _startStream();
                      } else if (res == 'denied') {
                        setState(() {
                          _rootGranting = false;
                          _rootMsg = '✗ SuperUser prompt was denied. Tap "Allow" '
                                     'next time, or use Shizuku / ADB instead.';
                        });
                      } else if (res == 'no_su') {
                        setState(() {
                          _rootGranting = false;
                          _hasRoot = false;
                          _rootMsg = '✗ Root not actually available on this device.';
                        });
                      } else {
                        setState(() {
                          _rootGranting = false;
                          _rootMsg = '✗ Root test failed. Try Shizuku or ADB instead.';
                        });
                      }
                    } catch (e) {
                      if (!mounted) return;
                      setState(() {
                        _rootGranting = false;
                        _rootMsg = '✗ Error: ${e.toString().split(':').first.trim()}';
                      });
                    }
                  },
                  icon: _rootGranting
                      ? const SizedBox(width: 16, height: 16,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.white))
                      : const Icon(Icons.bolt_rounded, size: 18),
                  label: Text(_rootGranting ? 'Starting…' : 'START WITH ROOT'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF22c55e),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8)),
                  ),
                ),
              ),
            ]),
          ),
        ],

        SizedBox(height: 24),
        Center(child: TextButton(
          onPressed: _checkPermAndStart,
          child: Text('I already granted it — check again',
              style: TextStyle(color: ThemeProvider().current.highlightColor)),
        )),
      ]),
    ));
  }

  // Root-grant transient state (lives on the outer State so the spinner +
  // status message survive rebuilds of the permission wall).
  bool   _rootGranting = false;
  String _rootMsg      = '';

  Widget _adbStatusRow(String label, bool enabled) => Row(children: [
    Icon(
      enabled ? Icons.check_circle_rounded : Icons.cancel_rounded,
      color: enabled ? const Color(0xFF4CAF50) : const Color(0xFFf87171),
      size: 16,
    ),
    const SizedBox(width: 8),
    Text(label,
        style: const TextStyle(color: Colors.white, fontSize: 12)),
    const Spacer(),
    Text(enabled ? 'ON' : 'OFF',
        style: TextStyle(
          color: enabled ? const Color(0xFF4CAF50) : const Color(0xFFf87171),
          fontSize: 11, fontWeight: FontWeight.bold,
        )),
  ]);

  Widget _permCard({required IconData icon, required Color color,
      required String title, required String body, Widget? child}) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0d0d20),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(icon, color: color, size: 18),
          const SizedBox(width: 8),
          Text(title, style: TextStyle(color: color,
              fontWeight: FontWeight.bold, fontSize: 13)),
        ]),
        const SizedBox(height: 8),
        Text(body, style: const TextStyle(color: Colors.white60, fontSize: 12,
            height: 1.5)),
        if (child != null) child,
      ]),
    );
  }

  Widget _portField(TextEditingController c, String hint,
      {bool isCode = false}) => TextField(
    controller: c,
    keyboardType: TextInputType.number,
    style: const TextStyle(color: Colors.white, fontSize: 13),
    decoration: InputDecoration(
      hintText: hint,
      hintStyle: const TextStyle(color: Colors.white38, fontSize: 12),
      isDense: true, filled: true, fillColor: const Color(0xFF151530),
      contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(6),
          borderSide: BorderSide.none),
    ),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// CRASHES TAB
// ─────────────────────────────────────────────────────────────────────────────

class _CrashesTab extends StatefulWidget {
  final bool originalFormat;
  const _CrashesTab({required this.originalFormat});

  @override
  State<_CrashesTab> createState() => _CrashesTabState();
}

class _CrashesTabState extends State<_CrashesTab>
    with AutomaticKeepAliveClientMixin, WidgetsBindingObserver {

  @override
  bool get wantKeepAlive => true;

  List<Map<String, dynamic>> _crashes = [];
  final Map<String, Uint8List?> _iconCache  = {};
  final Map<String, String>     _labelCache = {};
  List<String> _blacklist = [];
  List<String> _whitelist = [];
  String _query = '';
  bool _loading = true;
  Timer? _refreshTimer;
  StreamSubscription? _crashSub;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadFilters().then((_) => _load());
    _refreshTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (mounted && !_loading && _appInForeground) _load();
    });
    _crashSub = HbcChannel.crashStream.listen((_) {
      if (mounted && _appInForeground) _load();
    });
  }

  bool _appInForeground = true;

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final wasBackground = !_appInForeground;
    _appInForeground = state == AppLifecycleState.resumed;
    if (_appInForeground && wasBackground && mounted) _load();
  }

  @override
  void dispose() {
    _crashSub?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    _refreshTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadFilters() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _blacklist = p.getStringList('lc_blacklist') ?? [];
      _whitelist = p.getStringList('lc_whitelist') ?? [];
    });
  }

  Future<void> _addToBlacklist(String pkg) async {
    if (pkg.isEmpty || _blacklist.contains(pkg)) return;
    final p = await SharedPreferences.getInstance();
    final updated = [..._blacklist, pkg];
    await p.setStringList('lc_blacklist', updated);
    if (mounted) setState(() => _blacklist = updated);
  }

  Future<void> _confirmClearAll() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1e1e3a),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        title: const Text('Clear all crashes?',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        content: const Text('This will permanently delete every crash from the list.',
            style: TextStyle(color: Colors.white60)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel', style: TextStyle(color: Colors.white38)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Clear all',
                style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
    if (confirmed == true && mounted) {
      await HbcChannel.logcatClearAllCrashes();
      await _load();
    }
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final c = await HbcChannel.logcatGetCrashes();
    if (!mounted) return;
    final reversed = c.reversed.toList();
    setState(() { _crashes = reversed; _loading = false; });
    final pkgs = reversed
        .map((e) => e['packageName'] as String? ?? '')
        .where((p) => p.isNotEmpty && p != 'unknown' && p.contains('.'))
        .toSet();
    final uncachedPkgs = pkgs.where((p) =>
        !_iconCache.containsKey(p) || !_labelCache.containsKey(p)).toList();
    if (uncachedPkgs.isEmpty) return;
    final newIcons  = <String, Uint8List?>{};
    final newLabels = <String, String>{};
    await Future.wait(uncachedPkgs.map((pkg) async {
      try {
        if (!_iconCache.containsKey(pkg)) {
          newIcons[pkg] = await HbcChannel.logcatGetAppIcon(pkg);
        }
      } catch (_) {}
      try {
        if (!_labelCache.containsKey(pkg)) {
          final label = await HbcChannel.logcatGetAppLabel(pkg);
          if (label != null) newLabels[pkg] = label;
        }
      } catch (_) {}
    }));
    if (!mounted || (newIcons.isEmpty && newLabels.isEmpty)) return;
    setState(() {
      _iconCache.addAll(newIcons);
      _labelCache.addAll(newLabels);
    });
  }

  String _displayName(Map<String, dynamic> crash) {
    final pkg     = crash['packageName'] as String? ?? '';
    final stored  = crash['appName'] as String? ?? '';
    if (stored.isNotEmpty && stored != pkg) return stored;
    final cached  = _labelCache[pkg] ?? '';
    if (cached.isNotEmpty) return cached;
    return pkg;
  }

  /// Converts the epoch-ms crash ID to a smart local-time label.
  /// Examples: "just now", "5m ago", "Today 11:45 PM", "Yesterday 08:20 AM",
  ///           "Mon, Mar 29  11:45 PM", "29 Mar 2025  11:45 PM"
  String _formatCrashTime(String id) {
    final epochMs = int.tryParse(id) ?? 0;
    if (epochMs == 0) return '';
    final dt  = DateTime.fromMillisecondsSinceEpoch(epochMs); // local time
    final now = DateTime.now();
    final diff = now.difference(dt);

    // Relative label for very recent crashes
    if (diff.inSeconds < 60)  return 'just now';
    if (diff.inMinutes < 60)  return '${diff.inMinutes}m ago';
    if (diff.inHours < 3)     return '${diff.inHours}h ${diff.inMinutes % 60}m ago';

    // Time component (12-hour with AM/PM)
    final h    = dt.hour % 12 == 0 ? 12 : dt.hour % 12;
    final min  = dt.minute.toString().padLeft(2, '0');
    final ampm = dt.hour < 12 ? 'AM' : 'PM';
    final time = '$h:$min $ampm';

    final today     = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));
    final day       = DateTime(dt.year, dt.month, dt.day);

    if (day == today)     return 'Today  $time';
    if (day == yesterday) return 'Yesterday  $time';

    // Within the current year: "Mon, Mar 29  11:45 PM"
    const months  = ['Jan','Feb','Mar','Apr','May','Jun',
                     'Jul','Aug','Sep','Oct','Nov','Dec'];
    const weekdays = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
    final mon = months[dt.month - 1];
    final wd  = weekdays[(dt.weekday - 1) % 7];

    if (dt.year == now.year) return '$wd, $mon ${dt.day}  $time';

    // Older — show full date with year
    return '${dt.day} $mon ${dt.year}  $time';
  }

  List<Map<String, dynamic>> get _filtered => _crashes.where((c) {
    final pkg = c['packageName'] as String? ?? '';
    if (_blacklist.contains(pkg)) return false;
    if (_whitelist.isNotEmpty && !_whitelist.contains(pkg)) return false;
    if (_query.isEmpty) return true;
    final q = _query.toLowerCase();
    return pkg.toLowerCase().contains(q) ||
           _displayName(c).toLowerCase().contains(q) ||
           (c['type'] as String? ?? '').toLowerCase().contains(q);
  }).toList();

  @override
  Widget build(BuildContext context) {
    super.build(context);
    if (_loading) return Center(child: CircularProgressIndicator(
        color: ThemeProvider().current.highlightColor));

    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(10, 10, 10, 0),
        child: Row(children: [
          // ── search field ───────────────────────────────────────────────
          Expanded(
            child: TextField(
              onChanged: (v) => setState(() => _query = v),
              style: const TextStyle(color: Colors.white, fontSize: 13),
              decoration: InputDecoration(
                hintText: 'Search crashes…',
                hintStyle: const TextStyle(color: Colors.white38, fontSize: 13),
                prefixIcon: const Icon(Icons.search_rounded, color: Colors.white38, size: 18),
                isDense: true, filled: true, fillColor: const Color(0xFF0d0d20),
                contentPadding: const EdgeInsets.symmetric(vertical: 10),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide.none),
              ),
            ),
          ),
          // ── clear-all button ───────────────────────────────────────────
          if (_crashes.isNotEmpty) ...[
            const SizedBox(width: 8),
            Tooltip(
              message: 'Clear all crashes',
              child: InkWell(
                borderRadius: BorderRadius.circular(8),
                onTap: _confirmClearAll,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0d0d20),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(Icons.delete_sweep_rounded,
                      color: Colors.redAccent, size: 20),
                ),
              ),
            ),
          ],
        ]),
      ),
      const SizedBox(height: 10),
      Expanded(
        child: _filtered.isEmpty
            ? const Center(child: Column(
                mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.bug_report_outlined, color: Colors.white24, size: 48),
                  SizedBox(height: 12),
                  Text('No crashes detected yet.',
                      style: TextStyle(color: Colors.white38)),
                ]))
            : RefreshIndicator(
                color: ThemeProvider().current.highlightColor,
                onRefresh: _load,
                child: ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  itemCount: _filtered.length,
                  itemBuilder: (ctx, i) => _buildCrashTile(_filtered[i]),
                ),
              ),
      ),
    ]);
  }

  Widget _buildCrashIcon(String pkg, Color color) {
    final bytes = _iconCache[pkg];
    if (bytes != null) {
      return ClipOval(
        child: Image.memory(bytes, width: 36, height: 36, fit: BoxFit.cover,
            errorBuilder: (_, __, ___) =>
                Icon(Icons.bug_report_rounded, color: color, size: 30)),
      );
    }
    return Icon(Icons.bug_report_rounded, color: color, size: 30);
  }

  Widget _buildCrashTile(Map<String, dynamic> c) {
    final type  = c['type'] as String? ?? 'Java';
    final pkg   = c['packageName'] as String? ?? 'unknown';
    final id    = c['id'] as String? ?? '';
    final color = _crashTypeColor(type);
    final timeLabel = _formatCrashTime(id);

    return GestureDetector(
      onTap: () => _showDetail(c),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFF0d0d20),
          borderRadius: BorderRadius.circular(10),
          border: Border(left: BorderSide(color: color, width: 3)),
        ),
        child: Row(children: [
          _buildCrashIcon(pkg, color),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(_displayName(c), style: const TextStyle(color: Colors.white,
                fontWeight: FontWeight.w600, fontSize: 13),
                overflow: TextOverflow.ellipsis),
            Text(pkg, style: const TextStyle(color: Colors.white38, fontSize: 11),
                overflow: TextOverflow.ellipsis),
            const SizedBox(height: 3),
            Row(children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(type,
                    style: TextStyle(color: color, fontSize: 10,
                        fontWeight: FontWeight.w600)),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(timeLabel,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white54, fontSize: 11)),
              ),
            ]),
          ])),
          IconButton(
            icon: const Icon(Icons.delete_outline_rounded, color: Colors.redAccent, size: 20),
            onPressed: () async {
              await HbcChannel.logcatDeleteCrash(id);
              await _load();
            },
            padding: EdgeInsets.zero, constraints: const BoxConstraints(),
          ),
        ]),
      ),
    );
  }

  void _showDetail(Map<String, dynamic> c) {
    final pkg = c['packageName'] as String? ?? '';
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => _CrashDetailPage(
        crash: c,
        iconBytes:  _iconCache[pkg],
        appName:    _displayName(c),
        onDeleted:  _load,
        onBlacklist: _addToBlacklist,
      ),
    ));
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// CRASH TYPE HELPERS
// ─────────────────────────────────────────────────────────────────────────────

Color _crashTypeColor(String type) {
  switch (type) {
    case 'Java':   return const Color(0xFFf44336); // red
    case 'JNI':    return const Color(0xFFFF5722); // deep-orange
    case 'ANR':    return const Color(0xFFFFC107); // amber
    case 'Native': return const Color(0xFFFF9800); // orange
    case 'WTF':    return const Color(0xFF9c27b0); // purple
    case 'FATAL':  return const Color(0xFFf44336); // legacy — treat same as Java
    default:       return const Color(0xFFf44336);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// CRASH DETAIL PAGE
// ─────────────────────────────────────────────────────────────────────────────

class _CrashDetailPage extends StatefulWidget {
  final Map<String, dynamic> crash;
  final Uint8List?  iconBytes;
  final String      appName;
  final Future<void> Function() onDeleted;
  final Future<void> Function(String) onBlacklist;

  const _CrashDetailPage({
    required this.crash,
    required this.iconBytes,
    required this.appName,
    required this.onDeleted,
    required this.onBlacklist,
  });

  @override
  State<_CrashDetailPage> createState() => _CrashDetailPageState();
}

class _CrashDetailPageState extends State<_CrashDetailPage> {
  bool _wrapLines = true;
  bool _searching = false;
  String _searchQuery = '';
  final TextEditingController _searchCtrl = TextEditingController();
  final ScrollController _scrollCtrl = ScrollController();

  String get _pkg  => widget.crash['packageName'] as String? ?? '';
  String get _type => widget.crash['type'] as String? ?? 'Java';
  String get _id   => widget.crash['id'] as String? ?? '';
  String get _log  => widget.crash['log'] as String? ?? '';

  Color get _typeColor => _crashTypeColor(_type);

  int get _matchCount {
    if (_searchQuery.isEmpty) return 0;
    final q = _searchQuery.toLowerCase();
    final src = _log.toLowerCase();
    int count = 0, idx = 0;
    while ((idx = src.indexOf(q, idx)) != -1) { count++; idx += q.length; }
    return count;
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  /// Converts epoch-ms crash id to a full local date+time string for the
  /// detail page header.  Example: "Mon, 29 Mar 2026  11:45:23 PM"
  static String _localTime(String id) {
    final epochMs = int.tryParse(id) ?? 0;
    if (epochMs == 0) return '';
    final dt = DateTime.fromMillisecondsSinceEpoch(epochMs);
    const months   = ['Jan','Feb','Mar','Apr','May','Jun',
                      'Jul','Aug','Sep','Oct','Nov','Dec'];
    const weekdays = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
    final wd  = weekdays[(dt.weekday - 1) % 7];
    final mon = months[dt.month - 1];
    final h   = dt.hour % 12 == 0 ? 12 : dt.hour % 12;
    final min = dt.minute.toString().padLeft(2, '0');
    final sec = dt.second.toString().padLeft(2, '0');
    final ap  = dt.hour < 12 ? 'AM' : 'PM';
    return '$wd, ${dt.day} $mon ${dt.year}  $h:$min:$sec $ap';
  }

  Future<void> _export() async {
    final ts = DateTime.now().toIso8601String()
        .replaceAll(':', '-').replaceAll('.', '-').substring(0, 19);
    final name = 'crash-${_pkg.replaceAll(':', '_')}-$ts';
    await HbcChannel.logcatCreateDocument(filename: '$name.txt', content: _log);
  }

  Future<void> _zip() async {
    final ts = DateTime.now().toIso8601String()
        .replaceAll(':', '-').replaceAll('.', '-').substring(0, 19);
    final name = 'crash-${_pkg.replaceAll(':', '_')}-$ts';
    await HbcChannel.logcatCreateZipDocument(filename: '$name.zip', content: _log);
  }

  void _handleMenu(String value) async {
    switch (value) {
      case 'wrap':
        setState(() => _wrapLines = !_wrapLines);
        break;
      case 'notif':
        break;
      case 'blacklist':
        await widget.onBlacklist(_pkg);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('$_pkg added to blacklist'),
                backgroundColor: const Color(0xFF1e1e3a)));
        }
        break;
      case 'delete':
        await HbcChannel.logcatDeleteCrash(_id);
        await widget.onDeleted();
        if (mounted) Navigator.of(context).pop();
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final displayName = widget.appName.isNotEmpty ? widget.appName : _pkg;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        foregroundColor: Colors.black87,
        leading: _searching
            ? IconButton(
                icon: const Icon(Icons.arrow_back_rounded),
                onPressed: () => setState(() {
                  _searching = false;
                  _searchQuery = '';
                  _searchCtrl.clear();
                }),
              )
            : const BackButton(),
        title: _searching
            ? TextField(
                controller: _searchCtrl,
                autofocus: true,
                style: const TextStyle(color: Colors.black87, fontSize: 14),
                decoration: InputDecoration(
                  hintText: 'Search in crash log…',
                  hintStyle: const TextStyle(color: Colors.black38, fontSize: 14),
                  border: InputBorder.none,
                  suffixText: _searchQuery.isNotEmpty ? '${_matchCount} found' : null,
                  suffixStyle: TextStyle(
                    color: _matchCount > 0 ? const Color(0xFF4CAF50) : const Color(0xFFf87171),
                    fontSize: 11,
                  ),
                ),
                onChanged: (v) => setState(() => _searchQuery = v),
              )
            : null,
        actions: [
          if (!_searching)
            IconButton(
              icon: const Icon(Icons.search_rounded),
              onPressed: () => setState(() => _searching = true),
            ),
          if (_searching && _searchQuery.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.clear_rounded),
              onPressed: () => setState(() {
                _searchQuery = '';
                _searchCtrl.clear();
              }),
            ),
          if (!_searching)
            IconButton(
              icon: const Icon(Icons.info_outline_rounded),
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (_) => AlertDialog(
                    title: Text(displayName),
                    content: Text('Package: $_pkg\nType: $_type\nCrash time: ${_localTime(_id)}'),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('OK'),
                      ),
                    ],
                  ),
                );
              },
            ),
          PopupMenuButton<String>(
            onSelected: _handleMenu,
            color: const Color(0xFF1e1e3a),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10)),
            itemBuilder: (_) => [
              CheckedPopupMenuItem(
                value: 'wrap',
                checked: _wrapLines,
                child: const Text('Wrap log lines in details',
                    style: TextStyle(color: Colors.white)),
              ),
              const PopupMenuItem(value: 'notif',
                  child: Text('Notifications',
                      style: TextStyle(color: Colors.white))),
              const PopupMenuItem(value: 'blacklist',
                  child: Text('Add to blacklist',
                      style: TextStyle(color: Colors.white))),
              const PopupMenuItem(
                value: 'delete',
                child: Text('Delete',
                    style: TextStyle(color: Color(0xFFf87171))),
              ),
            ],
          ),
        ],
      ),
      body: Column(children: [
        // ── App header ─────────────────────────────────────────────────────
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 20, 16, 12),
          child: Column(children: [
            Container(
              width: 96, height: 96,
              decoration: const BoxDecoration(shape: BoxShape.circle),
              child: widget.iconBytes != null
                  ? ClipOval(child: Image.memory(widget.iconBytes!,
                        width: 96, height: 96, fit: BoxFit.cover))
                  : CircleAvatar(
                      radius: 48,
                      backgroundColor: _typeColor.withOpacity(0.12),
                      child: Icon(Icons.bug_report_rounded,
                          color: _typeColor, size: 52)),
            ),
            const SizedBox(height: 10),
            Text(displayName,
                style: const TextStyle(color: Colors.black87,
                    fontWeight: FontWeight.bold, fontSize: 20),
                textAlign: TextAlign.center),
            const SizedBox(height: 2),
            Text(_pkg,
                style: const TextStyle(color: Colors.black45, fontSize: 12),
                textAlign: TextAlign.center,
                overflow: TextOverflow.ellipsis),
            const SizedBox(height: 6),
            // ── crash type + local timestamp ────────────────────────────────
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: _typeColor.withOpacity(0.10),
                  borderRadius: BorderRadius.circular(5),
                  border: Border.all(color: _typeColor.withOpacity(0.30)),
                ),
                child: Text(_type,
                    style: TextStyle(
                        color: _typeColor, fontSize: 11,
                        fontWeight: FontWeight.w600)),
              ),
              const SizedBox(width: 8),
              Text(_localTime(_id),
                  style: const TextStyle(color: Colors.black45, fontSize: 11)),
            ]),
          ]),
        ),
        // ── Action buttons ─────────────────────────────────────────────────
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
            color: const Color(0xFFF5F5F5),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.black12),
          ),
          child: Row(children: [
            _actionBtn(Icons.copy_outlined, 'Copy',
                () => Clipboard.setData(ClipboardData(text: _log))),
            _vDivider(),
            _actionBtn(Icons.share_outlined, 'Share',
                () => Share.share(_log, subject: 'Crash: $_pkg')),
            _vDivider(),
            _actionBtn(Icons.upload_file_outlined, 'Export', _export),
            _vDivider(),
            _actionBtn(Icons.folder_zip_outlined, 'Zip', _zip),
          ]),
        ),
        const SizedBox(height: 10),
        // ── Log text ────────────────────────────────────────────────────────
        Expanded(
          child: Container(
            margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            decoration: BoxDecoration(
              color: const Color(0xFFF8F9FA),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.black12),
            ),
            child: Scrollbar(
              controller: _scrollCtrl,
              child: SingleChildScrollView(
                controller: _scrollCtrl,
                padding: const EdgeInsets.all(12),
                child: _searchQuery.isEmpty
                    ? Text(_log,
                        style: const TextStyle(
                            fontFamily: 'monospace',
                            fontSize: 11,
                            height: 1.45,
                            color: Colors.black87),
                        softWrap: _wrapLines)
                    : _buildHighlightedLog(),
              ),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _buildHighlightedLog() {
    final query = _searchQuery.toLowerCase();
    final logLower = _log.toLowerCase();
    final spans = <TextSpan>[];
    int start = 0;
    while (start < _log.length) {
      final idx = logLower.indexOf(query, start);
      if (idx == -1) {
        spans.add(TextSpan(text: _log.substring(start)));
        break;
      }
      if (idx > start) {
        spans.add(TextSpan(text: _log.substring(start, idx)));
      }
      spans.add(TextSpan(
        text: _log.substring(idx, idx + _searchQuery.length),
        style: const TextStyle(
          backgroundColor: Color(0xFFFFC107),
          color: Colors.black,
          fontWeight: FontWeight.bold,
        ),
      ));
      start = idx + _searchQuery.length;
    }
    return RichText(
      softWrap: _wrapLines,
      text: TextSpan(
        style: const TextStyle(
          fontFamily: 'monospace',
          fontSize: 11,
          height: 1.45,
          color: Colors.black87,
        ),
        children: spans,
      ),
    );
  }

  Widget _actionBtn(IconData icon, String label, VoidCallback onTap) =>
    Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 22, color: const Color(0xFF5C6BC0)),
            const SizedBox(height: 4),
            Text(label, style: const TextStyle(
                fontSize: 11, color: Color(0xFF5C6BC0),
                fontWeight: FontWeight.w500)),
          ]),
        ),
      ),
    );

  Widget _vDivider() => Container(
    width: 1, height: 48, color: Colors.black12,
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// RECORD TAB
// ─────────────────────────────────────────────────────────────────────────────

class _RecordTab extends StatefulWidget {
  const _RecordTab();

  @override
  State<_RecordTab> createState() => _RecordTabState();
}

class _RecordTabState extends State<_RecordTab> {
  List<Map<String, dynamic>> _recordings = [];
  final _buffer   = <String>[];
  bool _recording = false;
  StreamSubscription<String>? _recSub;

  @override
  void initState() {
    super.initState();
    _loadRecordings();
  }

  Future<void> _loadRecordings() async {
    final r = await HbcChannel.logcatGetRecordings();
    if (mounted) setState(() => _recordings = r);
  }

  void _startRecording() {
    _buffer.clear();
    HbcChannel.logcatStart();
    _recSub = HbcChannel.logcatStream.listen((line) {
      if (mounted) setState(() => _buffer.add(line));
    });
    setState(() => _recording = true);
  }

  Future<void> _stopRecording() async {
    await _recSub?.cancel();
    _recSub = null;
    if (_buffer.isNotEmpty) {
      await HbcChannel.logcatSaveRecording(List.from(_buffer));
    }
    _buffer.clear();
    setState(() => _recording = false);
    await _loadRecordings();
  }

  @override
  void dispose() {
    _recSub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      const SizedBox(height: 24),
      // record button
      Center(child: GestureDetector(
        onTap: _recording ? _stopRecording : _startRecording,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          width: 80, height: 80,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _recording
                ? Color(0xFFF44336).withOpacity(0.2)
                : ThemeProvider().current.highlightColor.withOpacity(0.1),
            border: Border.all(
              color: _recording ? Color(0xFFF44336) : ThemeProvider().current.highlightColor,
              width: 2.5),
          ),
          child: Icon(
            _recording ? Icons.stop_rounded : Icons.fiber_manual_record_rounded,
            color: _recording ? Color(0xFFF44336) : ThemeProvider().current.highlightColor,
            size: 36,
          ),
        ),
      )),
      const SizedBox(height: 10),
      Text(_recording ? 'Recording… (${_buffer.length} lines)' : 'Tap to record',
          style: TextStyle(
            color: _recording ? const Color(0xFFF44336) : Colors.white54,
            fontSize: 13,
          )),
      const SizedBox(height: 24),
      const Divider(color: Colors.white12),
      // saved recordings list
      Expanded(child: _recordings.isEmpty
          ? const Center(child: Text('No recordings saved.',
              style: TextStyle(color: Colors.white38)))
          : ListView.builder(
              padding: const EdgeInsets.all(10),
              itemCount: _recordings.length,
              itemBuilder: (ctx, i) {
                final r = _recordings[i];
                final name = r['name'] as String? ?? '';
                final size = ((r['size'] as num?)?.toInt() ?? 0);
                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Color(0xFF0d0d20),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(children: [
                    Icon(Icons.description_outlined,
                        color: ThemeProvider().current.highlightColor, size: 22),
                    const SizedBox(width: 10),
                    Expanded(child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(name, style: const TextStyle(color: Colors.white,
                          fontSize: 12, fontWeight: FontWeight.w600),
                          overflow: TextOverflow.ellipsis),
                      Text('${(size / 1024).toStringAsFixed(1)} KB',
                          style: const TextStyle(color: Colors.white38, fontSize: 11)),
                    ])),
                    IconButton(
                      icon: const Icon(Icons.save_alt_rounded, color: Colors.white54, size: 18),
                      onPressed: () => HbcChannel.logcatCreateDocument(
                          filename: name,
                          sourcePath: r['path'] as String? ?? ''),
                      padding: EdgeInsets.zero, constraints: const BoxConstraints(),
                    ),
                    const SizedBox(width: 8),
                    IconButton(
                      icon: const Icon(Icons.delete_outline_rounded,
                          color: Colors.redAccent, size: 18),
                      onPressed: () async {
                        await HbcChannel.logcatDeleteRecording(r['path'] as String? ?? '');
                        await _loadRecordings();
                      },
                      padding: EdgeInsets.zero, constraints: const BoxConstraints(),
                    ),
                  ]),
                );
              })),
    ]);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// TERMINAL TAB
// ─────────────────────────────────────────────────────────────────────────────

class _TermEntry {
  final String command;
  final String output;
  final bool   isError;
  _TermEntry({required this.command, required this.output, required this.isError});
}

class _AdbRef {
  final String cmd, desc, cat;
  const _AdbRef(this.cmd, this.desc, this.cat);
}

const _kAdbRef = <_AdbRef>[
  // ── Developer Options ──────────────────────────────────────────────────────
  _AdbRef('Settings → About Phone → tap Build Number × 7',   'Enable Developer Options menu',                     'Developer Options'),
  _AdbRef('Settings → Developer Options → USB Debugging',     'Enable USB Debugging (required for all ADB)',        'Developer Options'),
  _AdbRef('Settings → Developer Options → Wireless Debugging','Enable Wireless Debugging (no PC needed)',           'Developer Options'),
  _AdbRef('adb shell settings get global adb_enabled',        'Check if USB Debugging is on (1 = enabled)',         'Developer Options'),
  _AdbRef('adb shell settings get global adb_wifi_enabled',   'Check if Wireless Debugging is on (1 = enabled)',    'Developer Options'),

  // ── Connection ──────────────────────────────────────────────────────────────
  _AdbRef('adb devices',                  'List connected devices',             'Connection'),
  _AdbRef('adb devices -l',              'List devices with transport details', 'Connection'),
  _AdbRef('adb kill-server',             'Kill the ADB server',                 'Connection'),
  _AdbRef('adb start-server',            'Start the ADB server',                'Connection'),
  _AdbRef('adb tcpip 5555',              'Switch device to TCP/IP mode',        'Connection'),
  _AdbRef('adb connect 192.168.1.X:5555','Connect to device over WiFi',         'Connection'),
  _AdbRef('adb disconnect',              'Disconnect all wireless devices',      'Connection'),
  _AdbRef('adb disconnect 192.168.1.X',  'Disconnect specific wireless device', 'Connection'),
  _AdbRef('adb usb',                     'Restart ADB in USB mode',             'Connection'),
  _AdbRef('adb wait-for-device',         'Block until a device is connected',   'Connection'),
  _AdbRef('adb -s <serial> shell',       'Run command on specific device',      'Connection'),
  _AdbRef('adb get-state',               'Print device state',                  'Connection'),
  _AdbRef('adb get-serialno',            'Print device serial number',          'Connection'),

  // ── Port Forwarding ─────────────────────────────────────────────────────────
  _AdbRef('adb forward tcp:8080 tcp:8080',    'Forward local port to device port',  'Port Forwarding'),
  _AdbRef('adb forward --list',               'List all active forwards',           'Port Forwarding'),
  _AdbRef('adb forward --remove tcp:8080',    'Remove a specific forward',          'Port Forwarding'),
  _AdbRef('adb forward --remove-all',         'Remove all forwards',                'Port Forwarding'),
  _AdbRef('adb reverse tcp:8080 tcp:8080',    'Reverse-forward device port to host','Port Forwarding'),
  _AdbRef('adb reverse --list',               'List all active reverses',           'Port Forwarding'),
  _AdbRef('adb reverse --remove-all',         'Remove all reverse forwards',        'Port Forwarding'),

  // ── App Management ───────────────────────────────────────────────────────────
  _AdbRef('adb install app.apk',                           'Install APK',                           'App Management'),
  _AdbRef('adb install -r app.apk',                        'Reinstall APK (keep data)',              'App Management'),
  _AdbRef('adb install -d app.apk',                        'Allow version downgrade',               'App Management'),
  _AdbRef('adb install -g app.apk',                        'Grant all runtime permissions',         'App Management'),
  _AdbRef('adb install-multiple base.apk split_0.apk',     'Install split APKs',                    'App Management'),
  _AdbRef('adb uninstall com.example.app',                  'Uninstall app',                         'App Management'),
  _AdbRef('adb uninstall -k com.example.app',               'Uninstall app (keep data/cache)',       'App Management'),
  _AdbRef('adb shell pm list packages',                     'List all installed packages',           'App Management'),
  _AdbRef('adb shell pm list packages -s',                  'List system packages only',             'App Management'),
  _AdbRef('adb shell pm list packages -3',                  'List third-party packages only',        'App Management'),
  _AdbRef('adb shell pm list packages -d',                  'List disabled packages',                'App Management'),
  _AdbRef('adb shell pm path com.example.app',              'Get APK file path',                     'App Management'),
  _AdbRef('adb shell pm clear com.example.app',             'Clear app data and cache',              'App Management'),
  _AdbRef('adb shell pm disable-user --user 0 com.example.app', 'Disable app for user 0',           'App Management'),
  _AdbRef('adb shell pm enable com.example.app',            'Enable disabled app',                   'App Management'),
  _AdbRef('adb shell pm hide com.example.app',              'Hide app from launcher',                'App Management'),
  _AdbRef('adb shell pm unhide com.example.app',            'Unhide app',                            'App Management'),
  _AdbRef('adb shell pm list users',                        'List all users',                        'App Management'),
  _AdbRef('adb shell cmd package install-existing com.example.app', 'Install existing package for current user', 'App Management'),
  _AdbRef('adb shell am force-stop com.example.app',        'Force stop app',                        'App Management'),
  _AdbRef('adb shell am kill com.example.app',              'Kill background app',                   'App Management'),
  _AdbRef('adb shell am start -n com.example.app/.MainActivity',     'Start main activity',          'App Management'),
  _AdbRef('adb shell am startservice -n com.example.app/.MyService', 'Start a service',              'App Management'),
  _AdbRef('adb shell am broadcast -a android.intent.action.BOOT_COMPLETED', 'Send broadcast',        'App Management'),
  _AdbRef('adb shell monkey -p com.example.app 1000',       'Stress test with 1000 random events',  'App Management'),

  // ── File Transfer ────────────────────────────────────────────────────────────
  _AdbRef('adb pull /sdcard/screen.png',            'Pull file from device',               'File Transfer'),
  _AdbRef('adb pull /sdcard/DCIM/ ./backup/',       'Pull entire directory from device',   'File Transfer'),
  _AdbRef('adb push myfile.txt /sdcard/',           'Push file to device',                 'File Transfer'),
  _AdbRef('adb push ./files/ /sdcard/docs/',        'Push directory to device',            'File Transfer'),
  _AdbRef('adb sync',                               'Sync /system and /data partitions',   'File Transfer'),
  _AdbRef('adb shell ls /sdcard/',                  'List files on device',                'File Transfer'),
  _AdbRef('adb shell rm /sdcard/file.txt',          'Delete file on device',               'File Transfer'),
  _AdbRef('adb shell mkdir /sdcard/newfolder',      'Create folder on device',             'File Transfer'),
  _AdbRef('adb shell mv /sdcard/a.txt /sdcard/b/',  'Move file on device',                 'File Transfer'),
  _AdbRef('adb shell df -h',                        'Show disk usage (human readable)',     'File Transfer'),
  _AdbRef('adb shell cat /sdcard/file.txt',         'Print file contents',                 'File Transfer'),

  // ── Backup & Restore ─────────────────────────────────────────────────────────
  _AdbRef('adb backup -apk -shared -all -f backup.ab',          'Full device backup',        'Backup & Restore'),
  _AdbRef('adb backup -apk -shared -f backup.ab com.example.app','Backup single app',         'Backup & Restore'),
  _AdbRef('adb backup -noapk -shared -all -f backup.ab',         'Backup data only (no APKs)','Backup & Restore'),
  _AdbRef('adb restore backup.ab',                               'Restore from backup file',  'Backup & Restore'),

  // ── Reboot ───────────────────────────────────────────────────────────────────
  _AdbRef('adb reboot',              'Reboot device normally',                  'Reboot'),
  _AdbRef('adb reboot bootloader',   'Reboot to bootloader / fastboot',         'Reboot'),
  _AdbRef('adb reboot recovery',     'Reboot to recovery',                      'Reboot'),
  _AdbRef('adb reboot fastboot',     'Reboot to fastbootd (dynamic partitions)','Reboot'),
  _AdbRef('adb reboot sideload',     'Reboot to sideload mode',                 'Reboot'),
  _AdbRef('adb sideload update.zip', 'Sideload OTA / ROM zip in recovery',      'Reboot'),
  _AdbRef('adb root',                'Restart ADB daemon with root',            'Reboot'),
  _AdbRef('adb unroot',              'Restart ADB daemon without root',         'Reboot'),
  _AdbRef('adb remount',             'Remount /system as read-write (rooted)',  'Reboot'),
  _AdbRef('adb disable-verity',      'Disable dm-verity (rooted)',              'Reboot'),

  // ── Logcat & Debug ───────────────────────────────────────────────────────────
  _AdbRef('adb logcat',                      'Stream all logs',                    'Logcat & Debug'),
  _AdbRef('adb logcat *:E',                  'Stream errors only',                 'Logcat & Debug'),
  _AdbRef('adb logcat *:W',                  'Stream warnings and above',          'Logcat & Debug'),
  _AdbRef('adb logcat -s MyTag:D',           'Filter by tag',                      'Logcat & Debug'),
  _AdbRef('adb logcat -v time',              'Include timestamps',                 'Logcat & Debug'),
  _AdbRef('adb logcat -v threadtime',        'Full thread+time format',            'Logcat & Debug'),
  _AdbRef('adb logcat -c',                   'Clear logcat buffer',                'Logcat & Debug'),
  _AdbRef('adb logcat -d > logs.txt',        'Dump log to file',                   'Logcat & Debug'),
  _AdbRef('adb bugreport bugreport.zip',     'Generate full bug report',           'Logcat & Debug'),
  _AdbRef('adb shell dmesg',                 'Print kernel ring buffer',           'Logcat & Debug'),
  _AdbRef('adb shell dumpsys',               'Dump all system services',           'Logcat & Debug'),
  _AdbRef('adb shell dumpsys activity',      'Dump activity manager',              'Logcat & Debug'),
  _AdbRef('adb shell dumpsys battery',       'Battery stats',                      'Logcat & Debug'),
  _AdbRef('adb shell dumpsys meminfo',       'Memory info',                        'Logcat & Debug'),
  _AdbRef('adb shell dumpsys cpuinfo',       'CPU usage by process',               'Logcat & Debug'),
  _AdbRef('adb shell dumpsys package com.example.app', 'Package details',          'Logcat & Debug'),
  _AdbRef('adb shell dumpsys window windows','Window manager info',                'Logcat & Debug'),
  _AdbRef('adb shell dumpsys connectivity',  'Network/connectivity info',          'Logcat & Debug'),
  _AdbRef('adb shell dumpsys wifi',          'WiFi service info',                  'Logcat & Debug'),
  _AdbRef('adb shell dumpsys telephony.registry', 'Telephony events',              'Logcat & Debug'),
  _AdbRef('adb shell top',                   'Live CPU/RAM usage by process',      'Logcat & Debug'),
  _AdbRef('adb shell top -n 1',              'One-shot CPU/RAM snapshot',          'Logcat & Debug'),
  _AdbRef('adb shell ps',                    'List all running processes',         'Logcat & Debug'),
  _AdbRef('adb shell ps -A | grep example', 'Filter processes by name',           'Logcat & Debug'),
  _AdbRef('adb shell kill <pid>',            'Kill process by PID',                'Logcat & Debug'),
  _AdbRef('adb shell cat /proc/cpuinfo',     'CPU info from kernel',               'Logcat & Debug'),
  _AdbRef('adb shell cat /proc/meminfo',     'Memory info from kernel',            'Logcat & Debug'),
  _AdbRef('adb shell uname -a',              'Kernel version and build info',      'Logcat & Debug'),

  // ── Screen & Recording ───────────────────────────────────────────────────────
  _AdbRef('adb shell screencap /sdcard/screen.png',              'Take screenshot',              'Screen & Recording'),
  _AdbRef('adb pull /sdcard/screen.png',                         'Pull screenshot to computer',  'Screen & Recording'),
  _AdbRef('adb shell screenrecord /sdcard/record.mp4',           'Record screen (default 3min)', 'Screen & Recording'),
  _AdbRef('adb shell screenrecord --time-limit 30 /sdcard/r.mp4','Record screen (30 sec)',       'Screen & Recording'),
  _AdbRef('adb shell screenrecord --size 1280x720 /sdcard/r.mp4','Record at custom resolution',  'Screen & Recording'),
  _AdbRef('adb shell screenrecord --bit-rate 4000000 /sdcard/r.mp4','Record at 4Mbps bitrate',  'Screen & Recording'),

  // ── Input ────────────────────────────────────────────────────────────────────
  _AdbRef("adb shell input text 'hello world'",    'Type text on device',               'Input'),
  _AdbRef('adb shell input keyevent 66',           'Key event — ENTER (66)',            'Input'),
  _AdbRef('adb shell input keyevent 26',           'Key event — POWER (26)',            'Input'),
  _AdbRef('adb shell input keyevent 4',            'Key event — BACK (4)',              'Input'),
  _AdbRef('adb shell input keyevent 3',            'Key event — HOME (3)',              'Input'),
  _AdbRef('adb shell input keyevent 187',          'Key event — RECENTS (187)',         'Input'),
  _AdbRef('adb shell input keyevent 24',           'Key event — VOLUME UP (24)',        'Input'),
  _AdbRef('adb shell input keyevent 25',           'Key event — VOLUME DOWN (25)',      'Input'),
  _AdbRef('adb shell input keyevent 82',           'Key event — MENU (82)',             'Input'),
  _AdbRef('adb shell input tap 300 500',           'Tap at coordinates',                'Input'),
  _AdbRef('adb shell input swipe 300 1000 300 500','Swipe up gesture',                  'Input'),
  _AdbRef('adb shell input swipe 500 500 100 500 300', 'Swipe left (300ms)',            'Input'),
  _AdbRef('adb shell input roll 3 3',              'Trackball roll',                    'Input'),

  // ── Permissions ──────────────────────────────────────────────────────────────
  _AdbRef('adb shell pm grant com.example.app android.permission.WRITE_SECURE_SETTINGS',  'Grant WRITE_SECURE_SETTINGS',   'Permissions'),
  _AdbRef('adb shell pm grant com.example.app android.permission.READ_LOGS',              'Grant READ_LOGS',               'Permissions'),
  _AdbRef('adb shell pm grant com.example.app android.permission.DUMP',                   'Grant DUMP',                    'Permissions'),
  _AdbRef('adb shell pm grant com.example.app android.permission.CHANGE_NETWORK_STATE',   'Grant CHANGE_NETWORK_STATE',    'Permissions'),
  _AdbRef('adb shell pm revoke com.example.app android.permission.WRITE_SECURE_SETTINGS', 'Revoke WRITE_SECURE_SETTINGS',  'Permissions'),
  _AdbRef('adb shell pm list permissions -g',                'List all permissions by group',      'Permissions'),
  _AdbRef('adb shell dumpsys package com.example.app | grep permission', 'Check app permissions', 'Permissions'),

  // ── Display ──────────────────────────────────────────────────────────────────
  _AdbRef('adb shell wm size',                      'Get screen resolution',               'Display'),
  _AdbRef('adb shell wm size 1080x1920',            'Override screen resolution',          'Display'),
  _AdbRef('adb shell wm size reset',                'Reset resolution override',           'Display'),
  _AdbRef('adb shell wm density',                   'Get screen density (DPI)',            'Display'),
  _AdbRef('adb shell wm density 420',               'Override screen density',             'Display'),
  _AdbRef('adb shell wm density reset',             'Reset density override',              'Display'),
  _AdbRef('adb shell wm overscan reset',            'Reset overscan',                      'Display'),
  _AdbRef('adb shell settings put system screen_brightness 100',   'Set screen brightness (0-255)', 'Display'),
  _AdbRef('adb shell settings get system screen_brightness',       'Get screen brightness',         'Display'),
  _AdbRef('adb shell settings put system screen_off_timeout 60000','Set screen timeout (60s)',       'Display'),
  _AdbRef('adb shell svc power stayon true',        'Keep screen awake (charging)',        'Display'),

  // ── Network ──────────────────────────────────────────────────────────────────
  _AdbRef('adb shell svc wifi enable',              'Enable WiFi',                          'Network'),
  _AdbRef('adb shell svc wifi disable',             'Disable WiFi',                         'Network'),
  _AdbRef('adb shell svc data enable',              'Enable mobile data',                   'Network'),
  _AdbRef('adb shell svc data disable',             'Disable mobile data',                  'Network'),
  _AdbRef('adb shell ip addr',                      'Show all network interfaces + IPs',    'Network'),
  _AdbRef('adb shell ifconfig',                     'Network interfaces (older devices)',   'Network'),
  _AdbRef('adb shell netstat',                      'Active network connections',           'Network'),
  _AdbRef('adb shell nslookup google.com',          'DNS lookup',                           'Network'),
  _AdbRef('adb shell ping -c 4 8.8.8.8',           'Ping Google DNS',                      'Network'),
  _AdbRef('adb shell traceroute google.com',        'Traceroute to host',                   'Network'),
  _AdbRef('adb shell curl -s https://example.com', 'HTTP GET (if curl available)',          'Network'),
  _AdbRef('adb shell getprop gsm.operator.alpha',  'Carrier name',                         'Network'),
  _AdbRef('adb shell getprop gsm.network.type',    'Network type (LTE/5G…)',               'Network'),
  _AdbRef('adb shell getprop dhcp.wlan0.ipaddress','WiFi IP address',                      'Network'),
  _AdbRef('adb shell getprop net.dns1',            'DNS server 1',                         'Network'),
  _AdbRef('adb shell getprop net.dns2',            'DNS server 2',                         'Network'),
  _AdbRef('adb shell getprop sys.usb.config',      'Current USB mode',                     'Network'),

  // ── Settings ─────────────────────────────────────────────────────────────────
  _AdbRef('adb shell settings get global airplane_mode_on',     'Get airplane mode',              'Settings'),
  _AdbRef('adb shell settings put global airplane_mode_on 1',   'Enable airplane mode',           'Settings'),
  _AdbRef('adb shell settings put global airplane_mode_on 0',   'Disable airplane mode',          'Settings'),
  _AdbRef('adb shell settings put global bluetooth_on 1',       'Enable Bluetooth',               'Settings'),
  _AdbRef('adb shell settings put global bluetooth_on 0',       'Disable Bluetooth',              'Settings'),
  _AdbRef('adb shell settings put global nfc_on 1',             'Enable NFC',                     'Settings'),
  _AdbRef('adb shell settings put global stay_on_while_plugged_in 3', 'Keep awake while charging','Settings'),
  _AdbRef('adb shell settings put secure location_mode 3',      'Set location to high accuracy',  'Settings'),
  _AdbRef('adb shell settings put secure location_mode 0',      'Disable location',               'Settings'),
  _AdbRef('adb shell settings put system font_scale 1.0',       'Reset font scale to normal',     'Settings'),
  _AdbRef('adb shell settings put system font_scale 1.3',       'Increase font scale to 1.3×',    'Settings'),
  _AdbRef('adb shell settings put global development_settings_enabled 1', 'Enable developer options','Settings'),
  _AdbRef('adb shell settings put global usb_debugging 1',      'Enable ADB debugging via settings','Settings'),
  _AdbRef('adb shell content query --uri content://settings/secure', 'Query secure settings',     'Settings'),
  _AdbRef('adb shell content query --uri content://settings/global', 'Query global settings',     'Settings'),
  _AdbRef('adb shell content query --uri content://settings/system', 'Query system settings',     'Settings'),

  // ── Device Info ──────────────────────────────────────────────────────────────
  _AdbRef('adb shell getprop ro.product.model',          'Device model',                'Device Info'),
  _AdbRef('adb shell getprop ro.product.brand',          'Device brand',                'Device Info'),
  _AdbRef('adb shell getprop ro.product.manufacturer',   'Manufacturer',                'Device Info'),
  _AdbRef('adb shell getprop ro.product.name',           'Product name',                'Device Info'),
  _AdbRef('adb shell getprop ro.product.device',         'Device codename',             'Device Info'),
  _AdbRef('adb shell getprop ro.serialno',               'Serial number',               'Device Info'),
  _AdbRef('adb shell getprop ro.boot.serialno',          'Boot serial number',          'Device Info'),
  _AdbRef('adb shell getprop ro.build.version.release',  'Android version',             'Device Info'),
  _AdbRef('adb shell getprop ro.build.version.sdk',      'API level',                   'Device Info'),
  _AdbRef('adb shell getprop ro.build.version.security_patch', 'Security patch date',   'Device Info'),
  _AdbRef('adb shell getprop ro.build.id',               'Build ID',                    'Device Info'),
  _AdbRef('adb shell getprop ro.build.fingerprint',      'Build fingerprint',           'Device Info'),
  _AdbRef('adb shell getprop ro.build.type',             'Build type (user/userdebug)', 'Device Info'),
  _AdbRef('adb shell getprop ro.build.tags',             'Build tags',                  'Device Info'),
  _AdbRef('adb shell getprop ro.debuggable',             '1 if userdebug or eng build', 'Device Info'),
  _AdbRef('adb shell getprop persist.sys.locale',        'System locale',               'Device Info'),
  _AdbRef('adb shell getprop persist.sys.timezone',      'Timezone',                    'Device Info'),
  _AdbRef('adb shell getprop ro.hardware',               'Hardware name',               'Device Info'),
  _AdbRef('adb shell getprop ro.board.platform',         'SoC platform',                'Device Info'),
  _AdbRef('adb shell getprop ro.crypto.state',           'Encryption state',            'Device Info'),
  _AdbRef('adb shell getprop ro.crypto.type',            'Encryption type (FBE/FDE)',   'Device Info'),
  _AdbRef('adb shell getprop sys.boot_completed',        'Boot completed flag (1=done)','Device Info'),
  _AdbRef('adb shell getprop init.svc.adbd',             'ADB daemon service status',   'Device Info'),
  _AdbRef('adb shell getprop',                           'Dump ALL system properties',  'Device Info'),
  _AdbRef('adb shell setprop debug.myapp.enabled true',  'Set a system property',       'Device Info'),
  _AdbRef('adb shell getprop ro.product.cpu.abi',        'CPU architecture (ABI)',      'Device Info'),
  _AdbRef('adb shell cat /proc/cpuinfo',                 'Raw CPU info from kernel',    'Device Info'),
  _AdbRef('adb shell cat /proc/meminfo',                 'Raw memory info from kernel', 'Device Info'),
  _AdbRef('adb shell uname -a',                          'Kernel version + build info', 'Device Info'),
  _AdbRef('adb shell mount',                             'List mounted filesystems',    'Device Info'),
  _AdbRef('adb shell df -h',                             'Storage usage (human readable)','Device Info'),
];

class _TerminalTab extends StatefulWidget {
  const _TerminalTab();
  @override
  State<_TerminalTab> createState() => _TerminalTabState();
}

class _TerminalTabState extends State<_TerminalTab>
    with AutomaticKeepAliveClientMixin {

  @override
  bool get wantKeepAlive => true;

  final _entries    = <_TermEntry>[];
  final _history    = <String>[];
  int   _histIdx    = -1;
  bool  _running    = false;
  bool  _showRef    = false;
  String _refQuery  = '';

  final _inputCtrl  = TextEditingController();
  final _searchCtrl = TextEditingController();
  final _outScroll  = ScrollController();

  @override
  void dispose() {
    _inputCtrl.dispose();
    _searchCtrl.dispose();
    _outScroll.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_outScroll.hasClients) {
        _outScroll.animateTo(_outScroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 200),
            curve: Curves.easeOut);
      }
    });
  }

  Future<void> _run(String raw) async {
    final cmd = raw.trim();
    if (cmd.isEmpty) return;
    _history.remove(cmd);
    _history.insert(0, cmd);
    _histIdx = -1;

    // Handle clear client-side
    if (cmd == 'clear' || cmd.toLowerCase() == 'adb clear') {
      setState(() => _entries.clear());
      return;
    }

    setState(() { _running = true; });
    try {
      final res = await HbcChannel.logcatRunAdb(cmd);
      final special = res['special'] as String?;
      if (special == 'clear') {
        setState(() { _entries.clear(); _running = false; });
        return;
      }
      final output   = (res['output'] as String?) ?? '';
      final exitCode = (res['exitCode'] as int?) ?? -1;
      setState(() {
        _entries.add(_TermEntry(
          command: cmd,
          output:  output.isEmpty ? '(no output)' : output,
          isError: exitCode != 0,
        ));
        _running = false;
      });
    } catch (e) {
      setState(() {
        _entries.add(_TermEntry(
          command: cmd,
          output:  'Error: ${e.toString().replaceAll('PlatformException(', '').split(',').first.trim()}',
          isError: true,
        ));
        _running = false;
      });
    }
    _inputCtrl.clear();
    _scrollToBottom();
  }

  void _insertRefCmd(String cmd) {
    _inputCtrl.text = cmd;
    _inputCtrl.selection = TextSelection.fromPosition(
        TextPosition(offset: cmd.length));
    setState(() => _showRef = false);
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Column(children: [
      // ── Toggle bar ──────────────────────────────────────────────────────────
      Container(
        color: const Color(0xFF0d0d20),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        child: Row(children: [
          _tabChip('Terminal', Icons.terminal_rounded,   !_showRef),
          const SizedBox(width: 8),
          _tabChip('Reference', Icons.menu_book_rounded, _showRef),
          const Spacer(),
          if (!_showRef) ...[
            IconButton(
              icon: const Icon(Icons.delete_sweep_rounded, size: 18),
              color: Colors.white38,
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(),
              tooltip: 'Clear terminal',
              onPressed: () => setState(() => _entries.clear()),
            ),
            const SizedBox(width: 8),
            IconButton(
              icon: const Icon(Icons.copy_rounded, size: 18),
              color: Colors.white38,
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(),
              tooltip: 'Copy all output',
              onPressed: () {
                final all = _entries.map((e) => '❯ ${e.command}\n${e.output}').join('\n\n');
                Clipboard.setData(ClipboardData(text: all));
                ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Output copied'), duration: Duration(seconds: 1)));
              },
            ),
          ],
        ]),
      ),
      Divider(height: 1, color: ThemeProvider().current.highlightColor, thickness: 0.15),
      Expanded(child: _showRef ? _buildReference() : _buildTerminal()),
    ]);
  }

  Widget _tabChip(String label, IconData icon, bool active) => GestureDetector(
    onTap: () => setState(() => _showRef = label == 'Reference'),
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      decoration: BoxDecoration(
        color: active ? ThemeProvider().current.highlightColor.withOpacity(0.15) : Colors.transparent,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: active ? ThemeProvider().current.highlightColor : Colors.white12,
          width: 1,
        ),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 14,
            color: active ? ThemeProvider().current.highlightColor : Colors.white38),
        SizedBox(width: 5),
        Text(label,
            style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: active ? ThemeProvider().current.highlightColor : Colors.white38)),
      ]),
    ),
  );

  // ── Terminal view ────────────────────────────────────────────────────────────
  Widget _buildTerminal() => Column(children: [
    Expanded(
      child: _entries.isEmpty
          ? Center(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.terminal_rounded,
                    color: ThemeProvider().current.highlightColor, size: 40),
                const SizedBox(height: 10),
                const Text('ADB Shell Ready',
                    style: TextStyle(color: Colors.white60,
                        fontSize: 14, fontWeight: FontWeight.w600)),
                const SizedBox(height: 4),
                const Text('Type a command below or pick one from Reference',
                    style: TextStyle(color: Colors.white30, fontSize: 12)),
                const SizedBox(height: 12),
                Wrap(spacing: 6, children: [
                  _quickCmd('devices'),
                  _quickCmd('shell pm list packages'),
                  _quickCmd('shell getprop ro.product.model'),
                ]),
              ]),
            )
          : ListView.builder(
              controller: _outScroll,
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
              itemCount: _entries.length,
              itemBuilder: (_, i) => _buildEntry(_entries[i]),
            ),
    ),
    if (_running)
      LinearProgressIndicator(
          backgroundColor: Colors.transparent,
          color: ThemeProvider().current.highlightColor,
          minHeight: 2),
    _buildInput(),
  ]);

  Widget _quickCmd(String cmd) => GestureDetector(
    onTap: () { _inputCtrl.text = cmd; _run(cmd); },
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: const Color(0xFF0d0d20),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: Colors.white12),
      ),
      child: Text(cmd,
          style: TextStyle(
              color: ThemeProvider().current.highlightColor, fontSize: 11,
              fontFamily: 'monospace')),
    ),
  );

  Widget _buildEntry(_TermEntry e) => Padding(
    padding: EdgeInsets.only(bottom: 12),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // Prompt line
      Row(children: [
        Text('❯ ',
            style: TextStyle(color: ThemeProvider().current.highlightColor,
                fontFamily: 'monospace', fontSize: 13, fontWeight: FontWeight.bold)),
        Expanded(
          child: Text(e.command,
              style: TextStyle(
                  color: ThemeProvider().current.highlightColor,
                  fontFamily: 'monospace', fontSize: 13)),
        ),
        GestureDetector(
          onTap: () => Clipboard.setData(ClipboardData(text: e.output)),
          child: const Icon(Icons.copy_rounded, size: 14, color: Colors.white24),
        ),
      ]),
      const SizedBox(height: 3),
      // Output
      Container(
        width: double.infinity,
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: const Color(0xFF050510),
          borderRadius: BorderRadius.circular(6),
          border: Border.all(
            color: e.isError
                ? Colors.red.withOpacity(0.25)
                : Colors.white.withOpacity(0.06),
          ),
        ),
        child: SelectableText(e.output,
            style: TextStyle(
                color: e.isError
                    ? const Color(0xFFf87171)
                    : Colors.white,
                fontFamily: 'monospace',
                fontSize: 11.5,
                height: 1.45)),
      ),
    ]),
  );

  Widget _buildInput() => Container(
    padding: EdgeInsets.fromLTRB(12, 6, 12, 12),
    decoration: BoxDecoration(
      color: Color(0xFF0a0a1a),
      border: Border(top: BorderSide(color: ThemeProvider().current.highlightColor, width: 0.2)),
    ),
    child: Row(children: [
      Text('❯ ',
          style: TextStyle(color: ThemeProvider().current.highlightColor,
              fontFamily: 'monospace', fontSize: 15, fontWeight: FontWeight.bold)),
      Expanded(
        child: TextField(
          controller: _inputCtrl,
          style: TextStyle(
              color: Colors.white, fontFamily: 'monospace', fontSize: 13),
          cursorColor: ThemeProvider().current.highlightColor,
          decoration: const InputDecoration(
            hintText: 'adb devices  or  shell pm list packages',
            hintStyle: TextStyle(color: Colors.white24, fontSize: 12),
            border: InputBorder.none,
            isDense: true,
          ),
          onSubmitted: _running ? null : _run,
          enabled: !_running,
          onChanged: (_) { _histIdx = -1; },
          textInputAction: TextInputAction.send,
          keyboardType: TextInputType.text,
        ),
      ),
      // History up
      GestureDetector(
        onTap: () {
          if (_history.isEmpty) return;
          setState(() {
            _histIdx = (_histIdx + 1).clamp(0, _history.length - 1);
            _inputCtrl.text = _history[_histIdx];
            _inputCtrl.selection = TextSelection.fromPosition(
                TextPosition(offset: _inputCtrl.text.length));
          });
        },
        child: const Icon(Icons.keyboard_arrow_up_rounded,
            color: Colors.white38, size: 22),
      ),
      const SizedBox(width: 4),
      GestureDetector(
        onTap: _running ? null : () => _run(_inputCtrl.text),
        child: Container(
          padding: EdgeInsets.all(7),
          decoration: BoxDecoration(
            color: _running
                ? Colors.white12
                : ThemeProvider().current.highlightColor.withOpacity(0.2),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
                color: _running
                    ? Colors.white12
                    : ThemeProvider().current.highlightColor.withOpacity(0.5)),
          ),
          child: Icon(Icons.send_rounded,
              size: 16, color: ThemeProvider().current.highlightColor),
        ),
      ),
    ]),
  );

  // ── Reference view ───────────────────────────────────────────────────────────
  Widget _buildReference() {
    final q = _refQuery.toLowerCase();
    final filtered = q.isEmpty
        ? _kAdbRef
        : _kAdbRef.where((r) =>
            r.cmd.toLowerCase().contains(q) ||
            r.desc.toLowerCase().contains(q) ||
            r.cat.toLowerCase().contains(q)).toList();

    final categories = q.isEmpty
        ? _kAdbRef.map((r) => r.cat).toSet().toList()
        : filtered.map((r) => r.cat).toSet().toList();

    return Column(children: [
      // Search bar
      Padding(
        padding: EdgeInsets.fromLTRB(12, 10, 12, 6),
        child: TextField(
          controller: _searchCtrl,
          style: TextStyle(color: Colors.white, fontSize: 13),
          cursorColor: ThemeProvider().current.highlightColor,
          onChanged: (v) => setState(() => _refQuery = v),
          decoration: InputDecoration(
            hintText: 'Search commands…',
            hintStyle: const TextStyle(color: Colors.white30, fontSize: 13),
            prefixIcon: const Icon(Icons.search_rounded,
                color: Colors.white30, size: 18),
            suffixIcon: _refQuery.isNotEmpty
                ? GestureDetector(
                    onTap: () {
                      _searchCtrl.clear();
                      setState(() => _refQuery = '');
                    },
                    child: const Icon(Icons.close_rounded,
                        color: Colors.white30, size: 18))
                : null,
            filled: true,
            fillColor: const Color(0xFF0d0d20),
            contentPadding: const EdgeInsets.symmetric(
                horizontal: 14, vertical: 10),
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide.none),
            focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(
                    color: ThemeProvider().current.highlightColor, width: 1)),
          ),
        ),
      ),
      Expanded(
        child: filtered.isEmpty
            ? const Center(
                child: Text('No commands found',
                    style: TextStyle(color: Colors.white38, fontSize: 13)))
            : ListView.builder(
                padding: const EdgeInsets.fromLTRB(12, 0, 12, 16),
                itemCount: categories.length +
                    filtered.length +
                    (q.isNotEmpty ? 0 : 0),
                itemBuilder: (_, idx) {
                  // Build a flat list: header + items per category
                  int pos = 0;
                  for (final cat in categories) {
                    if (idx == pos) return _refHeader(cat);
                    pos++;
                    final items = filtered
                        .where((r) => r.cat == cat)
                        .toList();
                    for (final item in items) {
                      if (idx == pos) return _refItem(item);
                      pos++;
                    }
                  }
                  return const SizedBox.shrink();
                },
              ),
      ),
    ]);
  }

  Widget _refHeader(String title) => Padding(
    padding: EdgeInsets.fromLTRB(0, 14, 0, 4),
    child: Row(children: [
      Container(width: 3, height: 12,
          decoration: BoxDecoration(
              color: ThemeProvider().current.highlightColor,
              borderRadius: BorderRadius.circular(2))),
      SizedBox(width: 7),
      Text(title.toUpperCase(),
          style: TextStyle(
              color: ThemeProvider().current.highlightColor,
              fontSize: 10,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.1)),
    ]),
  );

  Widget _refItem(_AdbRef ref) => GestureDetector(
    onTap: () => _insertRefCmd(ref.cmd),
    child: Container(
      margin: const EdgeInsets.only(bottom: 4),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(
        color: const Color(0xFF0d0d20),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.white.withOpacity(0.05)),
      ),
      child: Row(children: [
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(ref.cmd,
                style: TextStyle(
                    color: ThemeProvider().current.highlightColor,
                    fontFamily: 'monospace',
                    fontSize: 12)),
            const SizedBox(height: 2),
            Text(ref.desc,
                style: const TextStyle(color: Colors.white70, fontSize: 11)),
          ]),
        ),
        const SizedBox(width: 8),
        Row(mainAxisSize: MainAxisSize.min, children: [
          GestureDetector(
            onTap: () => Clipboard.setData(ClipboardData(text: ref.cmd)),
            child: const Icon(Icons.copy_rounded, size: 14, color: Colors.white24),
          ),
          const SizedBox(width: 10),
          const Icon(Icons.arrow_forward_ios_rounded,
              size: 10, color: Colors.white24),
        ]),
      ]),
    ),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// SETTINGS TAB
// ─────────────────────────────────────────────────────────────────────────────

class _SettingsTab extends StatefulWidget {
  final bool   wrapLines, expandedLogs, crashOnStartup, originalFormat,
               stopOnBack, sinceLaunch, bottomEdge;
  final int    updateInterval, displayLimit;
  final double textSize;
  final void Function(String key, dynamic val) onChanged;
  final Future<void> Function() onResetPermission;

  const _SettingsTab({
    required this.wrapLines, required this.expandedLogs,
    required this.crashOnStartup, required this.originalFormat,
    required this.stopOnBack, required this.sinceLaunch,
    required this.bottomEdge, required this.updateInterval,
    required this.textSize, required this.displayLimit,
    required this.onChanged,
    required this.onResetPermission,
  });

  @override
  State<_SettingsTab> createState() => _SettingsTabState();
}

class _SettingsTabState extends State<_SettingsTab> {
  List<String> _blacklist = [];
  List<String> _whitelist = [];
  bool _autostart      = false;
  bool _isResetting    = false;
  bool _isHardResetting = false;

  @override
  void initState() {
    super.initState();
    _loadLists();
    HbcChannel.logcatGetAutostart().then((v) {
      if (mounted) setState(() => _autostart = v);
    });
  }

  Future<void> _loadLists() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _blacklist = p.getStringList('lc_blacklist') ?? [];
      _whitelist = p.getStringList('lc_whitelist') ?? [];
    });
  }

  Future<void> _saveBlacklist(List<String> list) async {
    final p = await SharedPreferences.getInstance();
    await p.setStringList('lc_blacklist', list);
    if (mounted) setState(() => _blacklist = list);
  }

  Future<void> _saveWhitelist(List<String> list) async {
    final p = await SharedPreferences.getInstance();
    await p.setStringList('lc_whitelist', list);
    if (mounted) setState(() => _whitelist = list);
  }

  Future<void> _addPackageDialog(String title, List<String> current,
      Future<void> Function(List<String>) onSave) async {
    final result = await Navigator.push<List<String>>(
      context,
      MaterialPageRoute(
        builder: (_) => _AppPickerPage(title: title, selected: current),
      ),
    );
    if (result != null) await onSave(result);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        _section('Logs'),
        _toggle('Stop logging when exiting with back button', widget.stopOnBack,
            (v) => widget.onChanged('lc_stop_on_back', v)),
        _toggle('Show only logs which have appeared since the app launch',
            widget.sinceLaunch,
            (v) => widget.onChanged('lc_since_launch', v)),
        _toggle('Open crashes page on startup', widget.crashOnStartup,
            (v) => widget.onChanged('lc_crash_start', v)),
        _toggle('Auto-start LogCat on device boot', _autostart, (v) async {
          await HbcChannel.logcatSetAutostart(v);
          setState(() => _autostart = v);
        }),
        _section('Logs format'),
        _toggle('Export logs in original format', widget.originalFormat,
            (v) => widget.onChanged('lc_orig_format', v)),
        _toggle('Wrap log lines in details', widget.wrapLines,
            (v) => widget.onChanged('lc_wrap', v)),
        _number('Logs update interval', widget.updateInterval, 'ms',
            (v) => widget.onChanged('lc_interval', v)),
        _number('Logs text size', widget.textSize.toInt(), '',
            (v) => widget.onChanged('lc_text_size', v.toDouble())),
        _numberLarge('Logs display limit', widget.displayLimit,
            (v) => widget.onChanged('lc_limit', v)),
        _toggle('Expanded logs', widget.expandedLogs,
            (v) => widget.onChanged('lc_expanded', v)),
        _toggle('Resume logging with bottom edge swipe', widget.bottomEdge,
            (v) => widget.onChanged('lc_bottom_edge', v)),

        // ── Blacklist ──────────────────────────────────────────────────────
        _section('Crash Blacklist'),
        _listSection(
          description: 'Crashes from these apps are hidden.',
          packages: _blacklist,
          accentColor: const Color(0xFFef4444),
          onRemove: (pkg) => _saveBlacklist(
              _blacklist.where((p) => p != pkg).toList()),
          onAdd: () => _addPackageDialog(
              'Add to blacklist', _blacklist, _saveBlacklist),
        ),

        // ── Whitelist ──────────────────────────────────────────────────────
        _section('Crash Whitelist'),
        _listSection(
          description: 'Only crashes from these apps are shown (leave empty to show all).',
          packages: _whitelist,
          accentColor: const Color(0xFF7c3aed),
          onRemove: (pkg) => _saveWhitelist(
              _whitelist.where((p) => p != pkg).toList()),
          onAdd: () => _addPackageDialog(
              'Add to whitelist', _whitelist, _saveWhitelist),
        ),

        // ── Connection ─────────────────────────────────────────────────────
        _section('Connection'),
        const SizedBox(height: 4),
        Text(
          'Revoke the READ_LOGS permission and return to the setup screen to '
          're-grant it fresh via ADB or Shizuku.',
          style: const TextStyle(color: Colors.white, fontSize: 11),
        ),
        const SizedBox(height: 12),
        _connectionButton(
          label: 'Revoke via Shizuku & Reconnect',
          icon: Icons.link_off_rounded,
          color: const Color(0xFFef4444),
          loading: _isResetting,
          onTap: () async {
            if (_isResetting) return;
            setState(() => _isResetting = true);
            final res = await HbcChannel.logcatRevokePermission();
            if (!mounted) return;
            setState(() => _isResetting = false);
            if (res == 'revoked') {
              await widget.onResetPermission();
            } else if (res == 'not_available') {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                content: Text('Shizuku is not running. Use ADB instead:\n'
                    'adb shell pm revoke <pkg> android.permission.READ_LOGS'),
                duration: Duration(seconds: 6),
              ));
            } else if (res == 'permission_requested') {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                content: Text('Shizuku permission requested — tap Allow, then try again.'),
              ));
            } else {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                content: Text('Revoke failed. Try:\n'
                    'adb shell pm revoke <pkg> android.permission.READ_LOGS'),
                duration: Duration(seconds: 6),
              ));
            }
          },
        ),
        const SizedBox(height: 8),
        _connectionButton(
          label: 'Re-show Setup Screen',
          icon: Icons.settings_backup_restore_rounded,
          color: const Color(0xFFf59e0b),
          loading: false,
          onTap: widget.onResetPermission,
        ),

        // ── Reset & Re-pair ────────────────────────────────────────────────
        _section('Reset & Re-pair'),
        Container(
          margin: const EdgeInsets.only(bottom: 4),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFF0d0d20),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.red.withOpacity(0.25)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text(
              'Stops logging, kills the ADB server, and revokes READ_LOGS. '
              'Logs will not work again until you re-pair and grant the permission.',
              style: TextStyle(color: Colors.white, fontSize: 11),
            ),
            const SizedBox(height: 12),
            _connectionButton(
              label: 'Hard Reset — Stop & Re-pair',
              icon: Icons.restart_alt_rounded,
              color: const Color(0xFFef4444),
              loading: _isHardResetting,
              onTap: () async {
                if (_isHardResetting) return;
                final confirmed = await showDialog<bool>(
                  context: context,
                  builder: (_) => AlertDialog(
                    backgroundColor: const Color(0xFF1e1e3a),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14)),
                    title: const Text('Hard Reset?',
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold)),
                    content: const Text(
                      'This will stop the log service, kill the ADB server, '
                      'and revoke READ_LOGS.\n\nYou will need to pair and grant '
                      'the permission again to get logs.',
                      style: TextStyle(color: Colors.white60)),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context, false),
                        child: const Text('Cancel',
                            style: TextStyle(color: Colors.white38)),
                      ),
                      TextButton(
                        onPressed: () => Navigator.pop(context, true),
                        child: const Text('Reset',
                            style: TextStyle(
                                color: Colors.redAccent,
                                fontWeight: FontWeight.bold)),
                      ),
                    ],
                  ),
                );
                if (confirmed != true || !mounted) return;
                setState(() => _isHardResetting = true);
                await HbcChannel.logcatHardReset();
                if (!mounted) return;
                setState(() => _isHardResetting = false);
                await widget.onResetPermission();
              },
            ),
          ]),
        ),
        const SizedBox(height: 16),
      ],
    );
  }

  Widget _connectionButton({
    required String label,
    required IconData icon,
    required Color color,
    required bool loading,
    required Future<void> Function() onTap,
  }) =>
    GestureDetector(
      onTap: loading ? null : onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: color.withOpacity(0.12),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color.withOpacity(0.35)),
        ),
        child: Row(children: [
          loading
              ? SizedBox(
                  width: 16, height: 16,
                  child: CircularProgressIndicator(
                      strokeWidth: 2, color: color))
              : Icon(icon, size: 18, color: color),
          const SizedBox(width: 10),
          Expanded(
            child: Text(label,
                style: const TextStyle(
                    color: Colors.white, fontSize: 13, fontWeight: FontWeight.w500)),
          ),
        ]),
      ),
    );


  Widget _listSection({
    required String description,
    required List<String> packages,
    required Color accentColor,
    required void Function(String) onRemove,
    required VoidCallback onAdd,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 4),
      decoration: BoxDecoration(
        color: const Color(0xFF0d0d20),
        borderRadius: BorderRadius.circular(10),
      ),
      padding: const EdgeInsets.fromLTRB(14, 10, 8, 10),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // ── description + count badge ─────────────────────────────────────
        Row(children: [
          Expanded(
            child: Text(description,
                style: const TextStyle(color: Colors.white, fontSize: 11)),
          ),
          if (packages.isNotEmpty) ...[
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: accentColor.withOpacity(0.15),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: accentColor.withOpacity(0.4)),
              ),
              child: Text(
                '${packages.length} app${packages.length == 1 ? '' : 's'}',
                style: TextStyle(
                    color: accentColor,
                    fontSize: 10,
                    fontWeight: FontWeight.w700),
              ),
            ),
          ],
        ]),
        // ── horizontally scrollable chip strip ───────────────────────────
        if (packages.isNotEmpty) ...[
          const SizedBox(height: 8),
          SizedBox(
            height: 30,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: packages.length,
              separatorBuilder: (_, __) => const SizedBox(width: 6),
              itemBuilder: (_, i) {
                final pkg = packages[i];
                final short = pkg.length > 22 ? '…${pkg.substring(pkg.length - 19)}' : pkg;
                return GestureDetector(
                  onTap: () => onRemove(pkg),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: accentColor.withOpacity(0.10),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: accentColor.withOpacity(0.35)),
                    ),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Text(short,
                          style: TextStyle(
                              color: accentColor.withOpacity(0.9),
                              fontSize: 10,
                              fontFamily: 'monospace')),
                      const SizedBox(width: 5),
                      Icon(Icons.close_rounded,
                          size: 11, color: accentColor.withOpacity(0.7)),
                    ]),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 4),
        ],
        // ── manage button ─────────────────────────────────────────────────
        GestureDetector(
          onTap: onAdd,
          child: Padding(
            padding: const EdgeInsets.only(top: 6, bottom: 2),
            child: Row(children: [
              Icon(
                packages.isEmpty
                    ? Icons.add_circle_outline_rounded
                    : Icons.edit_rounded,
                size: 14, color: accentColor,
              ),
              const SizedBox(width: 6),
              Text(
                packages.isEmpty ? 'Add apps' : 'Manage apps',
                style: TextStyle(
                    color: accentColor,
                    fontSize: 12,
                    fontWeight: FontWeight.w600),
              ),
            ]),
          ),
        ),
      ]),
    );
  }

  Widget _section(String title) => Padding(
    padding: EdgeInsets.fromLTRB(0, 22, 0, 6),
    child: Row(children: [
      Container(width: 3, height: 14,
          decoration: BoxDecoration(
            color: ThemeProvider().current.highlightColor,
            borderRadius: BorderRadius.circular(2))),
      SizedBox(width: 8),
      Text(title.toUpperCase(),
          style: TextStyle(
              color: ThemeProvider().current.highlightColor,
              fontSize: 11,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.1)),
    ]),
  );

  Widget _toggle(String label, bool val, ValueChanged<bool> onTap) =>
    Container(
      margin: const EdgeInsets.only(bottom: 4),
      decoration: BoxDecoration(
        color: const Color(0xFF0d0d20),
        borderRadius: BorderRadius.circular(10),
      ),
      child: SwitchListTile(
        value: val,
        onChanged: onTap,
        title: Text(label,
            style: TextStyle(
                color: Colors.white,
                fontSize: 13,
                fontWeight: FontWeight.w500)),
        activeColor: ThemeProvider().current.highlightColor,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14),
        dense: true,
      ),
    );

  Widget _number(String label, int val, String suffix, ValueChanged<int> onTap) =>
    Container(
      margin: const EdgeInsets.only(bottom: 4),
      decoration: BoxDecoration(
        color: const Color(0xFF0d0d20),
        borderRadius: BorderRadius.circular(10),
      ),
      child: _NumTile(label: label, value: val, suffix: suffix, onChanged: onTap),
    );

  Widget _numberLarge(String label, int val, ValueChanged<int> onTap) =>
    Container(
      margin: const EdgeInsets.only(bottom: 4),
      decoration: BoxDecoration(
        color: const Color(0xFF0d0d20),
        borderRadius: BorderRadius.circular(10),
      ),
      child: _NumTile(label: label, value: val, suffix: '', onChanged: onTap),
    );
}

class _NumTile extends StatefulWidget {
  final String label, suffix;
  final int value;
  final ValueChanged<int> onChanged;
  const _NumTile({required this.label, required this.value,
      required this.suffix, required this.onChanged});

  @override
  State<_NumTile> createState() => _NumTileState();
}

class _NumTileState extends State<_NumTile> {
  late final TextEditingController _c;

  @override
  void initState() {
    super.initState();
    _c = TextEditingController(text: widget.value.toString());
  }

  @override
  void dispose() { _c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => ListTile(
    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
    dense: true,
    title: Text(widget.label,
        style: const TextStyle(
            color: Colors.white,
            fontSize: 13,
            fontWeight: FontWeight.w500)),
    subtitle: Text(
        widget.suffix.isNotEmpty
            ? '${widget.value} ${widget.suffix}'
            : widget.value.toString(),
        style: const TextStyle(color: Colors.white, fontSize: 11)),
    onTap: () => showDialog(
      context: context,
      builder: (_) => AlertDialog(
        
        title: Text(widget.label,
            style: const TextStyle(color: Colors.white, fontSize: 14)),
        content: TextField(
          controller: _c,
          keyboardType: TextInputType.number,
          style: TextStyle(color: Colors.white),
          decoration: InputDecoration(
            suffix: Text(widget.suffix,
                style: TextStyle(color: Colors.white)),
            enabledBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: ThemeProvider().current.highlightColor)),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context),
              child: const Text('Cancel',
                  style: TextStyle(color: Colors.white))),
          TextButton(
            onPressed: () {
              final v = int.tryParse(_c.text.trim());
              if (v != null) widget.onChanged(v);
              Navigator.pop(context);
            },
            child: Text('OK', style: TextStyle(color: ThemeProvider().current.highlightColor)),
          ),
        ],
      ),
    ),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Animated cat icon for the LogCat AppBar
// ─────────────────────────────────────────────────────────────────────────────
class _LogcatAppBarCat extends StatelessWidget {
  final Animation<double> anim;
  final bool flip;
  const _LogcatAppBarCat({required this.anim, required this.flip});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: anim,
      builder: (_, __) {
        final t = anim.value;
        return Transform.scale(
          scaleX: flip ? -1 : 1,
          child: Opacity(
            opacity: 0.55 + 0.45 * t,
            child: Container(
              width: 24,
              height: 24,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: ThemeProvider().current.highlightColor.withOpacity(0.25 + 0.45 * t),
                    blurRadius: 6 + 8 * t,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: Image.asset(
                'assets/icon/logcat_cat.png',
                width: 24,
                height: 24,
              ),
            ),
          ),
        );
      },
    );
  }
}

// ── App Picker Page ────────────────────────────────────────────────────────────
class _AppPickerPage extends StatefulWidget {
  final String title;
  final List<String> selected;
  const _AppPickerPage({required this.title, required this.selected});

  @override
  State<_AppPickerPage> createState() => _AppPickerPageState();
}

class _AppPickerPageState extends State<_AppPickerPage> {
  List<Map<String, dynamic>> _apps = [];
  bool _loading = true;
  String _query = '';
  late Set<String> _selected;
  final _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _selected = Set.from(widget.selected);
    _load();
  }

  Future<void> _load() async {
    final apps = await HbcChannel.logcatGetInstalledApps();
    if (mounted) setState(() { _apps = apps; _loading = false; });
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  List<Map<String, dynamic>> get _filtered {
    if (_query.isEmpty) return _apps;
    final q = _query.toLowerCase();
    return _apps.where((a) =>
        (a['label'] as String? ?? '').toLowerCase().contains(q) ||
        (a['packageName'] as String? ?? '').toLowerCase().contains(q)).toList();
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _filtered;
    return Scaffold(
      
      appBar: AppBar(
        
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(widget.title,
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, _selected.toList()),
            child: Text('Done',
                style: TextStyle(color: ThemeProvider().current.highlightColor, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
      body: Column(children: [
        Container(
          color: const Color(0xFF0d0d20),
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
          child: TextField(
            controller: _searchCtrl,
            onChanged: (v) => setState(() => _query = v),
            style: const TextStyle(color: Colors.white, fontSize: 13),
            decoration: InputDecoration(
              hintText: 'Search apps…',
              hintStyle: const TextStyle(color: Colors.white38, fontSize: 13),
              prefixIcon: const Icon(Icons.search_rounded, color: Colors.white38, size: 18),
              suffixIcon: _query.isNotEmpty
                  ? GestureDetector(
                      onTap: () { _searchCtrl.clear(); setState(() => _query = ''); },
                      child: const Icon(Icons.close_rounded, color: Colors.white38, size: 18))
                  : null,
              isDense: true,
              filled: true,
              fillColor: const Color(0xFF151530),
              contentPadding: const EdgeInsets.symmetric(vertical: 8),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide.none),
            ),
          ),
        ),
        if (!_loading) Builder(builder: (context) {
          final allSelected = filtered.isNotEmpty &&
              filtered.every((a) => _selected.contains(a['packageName'] as String? ?? ''));
          return Container(
            color: const Color(0xFF0a0a1a),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(children: [
              Text(
                '${_selected.length} selected',
                style: const TextStyle(color: Colors.white54, fontSize: 12),
              ),
              const Spacer(),
              GestureDetector(
                onTap: () => setState(() {
                  if (allSelected) {
                    for (final a in filtered) {
                      _selected.remove(a['packageName'] as String? ?? '');
                    }
                  } else {
                    for (final a in filtered) {
                      _selected.add(a['packageName'] as String? ?? '');
                    }
                  }
                }),
                child: Row(children: [
                  Icon(
                    allSelected
                        ? Icons.deselect_rounded
                        : Icons.select_all_rounded,
                    size: 16,
                    color: ThemeProvider().current.highlightColor,
                  ),
                  SizedBox(width: 5),
                  Text(
                    allSelected ? 'Deselect all' : 'Select all',
                    style: TextStyle(
                        color: ThemeProvider().current.highlightColor,
                        fontSize: 12,
                        fontWeight: FontWeight.w600),
                  ),
                ]),
              ),
            ]),
          );
        }),
        if (_loading)
          Expanded(child: Center(
              child: CircularProgressIndicator(color: ThemeProvider().current.highlightColor)))
        else
          Expanded(
            child: ListView.builder(
              itemCount: filtered.length,
              itemBuilder: (_, i) {
                final app   = filtered[i];
                final pkg   = app['packageName'] as String? ?? '';
                final label = app['label'] as String? ?? pkg;
                final iconB = app['icon'] as Uint8List?;
                final checked = _selected.contains(pkg);
                return InkWell(
                  onTap: () => setState(() {
                    if (checked) _selected.remove(pkg); else _selected.add(pkg);
                  }),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    decoration: const BoxDecoration(
                      border: Border(bottom: BorderSide(color: Colors.white10))),
                    child: Row(children: [
                      ClipOval(
                        child: iconB != null
                            ? Image.memory(iconB, width: 40, height: 40, fit: BoxFit.cover)
                            : Container(width: 40, height: 40,
                                color: const Color(0xFF151530),
                                child: const Icon(Icons.android_rounded,
                                    color: Colors.white38, size: 24)),
                      ),
                      const SizedBox(width: 14),
                      Expanded(child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(label,
                                style: const TextStyle(color: Colors.white,
                                    fontSize: 13, fontWeight: FontWeight.w500),
                                overflow: TextOverflow.ellipsis),
                            Text(pkg,
                                style: const TextStyle(color: Colors.white38, fontSize: 11),
                                overflow: TextOverflow.ellipsis),
                          ])),
                      Checkbox(
                        value: checked,
                        onChanged: (_) => setState(() {
                          if (checked) _selected.remove(pkg); else _selected.add(pkg);
                        }),
                        activeColor: ThemeProvider().current.highlightColor,
                        side: const BorderSide(color: Colors.white38),
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      ),
                    ]),
                  ),
                );
              },
            ),
          ),
      ]),
    );
  }
}
