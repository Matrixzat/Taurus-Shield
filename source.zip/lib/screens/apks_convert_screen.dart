import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:archive/archive_io.dart';
import '../utils/hbc_channel.dart';
import '../utils/storage_helper.dart';
import '../utils/permission_helper.dart';
import '../utils/theme_provider.dart';
import '../widgets/guide_modal.dart';

const _kAccent      = Color(0xFF06b6d4);
const _kAccentLight = Color(0xFF22d3ee);
const _kBg          = Color(0xFF060610);

class ApksConvertScreen extends StatefulWidget {
  const ApksConvertScreen({super.key});
  @override
  State<ApksConvertScreen> createState() => _ApksConvertScreenState();
}

class _ApksConvertScreenState extends State<ApksConvertScreen>
    with TickerProviderStateMixin {

  String? _selectedFilePath;
  String? _selectedFileName;
  bool    _fileValid    = false;
  String  _fileStatus   = '';

  String _mode = 'extract'; // 'extract' | 'merge'

  bool    _isProcessing = false;
  bool    _logVisible   = false;
  String  _logs         = '';
  String? _outputDir;
  String? _outputPath;
  bool    _success      = false;

  StreamSubscription<String>? _streamSub;
  final ScrollController _logScroll  = ScrollController();
  final ScrollController _pageScroll = ScrollController();

  late AnimationController _pulseCtrl;
  late AnimationController _orbitCtrl;
  late AnimationController _logCtrl;
  late Animation<double>   _pulseAnim;
  late Animation<double>   _logFade;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.85, end: 1.0)
        .animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _orbitCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 6))
      ..repeat();

    _logCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 400));
    _logFade = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _logCtrl, curve: Curves.easeIn));
  }

  @override
  void dispose() {
    _streamSub?.cancel();
    _pulseCtrl.dispose();
    _orbitCtrl.dispose();
    _logCtrl.dispose();
    _logScroll.dispose();
    _pageScroll.dispose();
    super.dispose();
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.any,
    );
    if (result == null || result.files.isEmpty) return;
    final file = result.files.first;
    final path = file.path;
    if (path == null) return;

    final ext = path.toLowerCase().split('.').last;
    if (!['apk', 'apks', 'aab'].contains(ext)) {
      if (mounted) {
        _showSnack('Unsupported file type .$ext — please pick a .apk, .apks or .aab file.',
            color: const Color(0xFFf59e0b));
      }
      return;
    }

    setState(() {
      _selectedFilePath = path;
      _selectedFileName = file.name;
      _fileStatus       = 'Checking...';
      _fileValid        = false;
    });

    final lower  = path.toLowerCase();
    final isApks = lower.endsWith('.apks');
    final isAab  = lower.endsWith('.aab');

    if (isApks) {
      try {
        final names = await Future(() {
          final bytes = File(path).readAsBytesSync();
          final archive = ZipDecoder().decodeBytes(bytes);
          return archive.files.map((f) => f.name).toList();
        });
        if (names.contains('base.apk')) {
          setState(() {
            _fileValid  = true;
            _fileStatus = 'Valid .apks — ${names.length} APK(s): ${names.join(', ')}';
          });
        } else {
          setState(() {
            _fileValid  = false;
            _fileStatus = 'Invalid .apks — missing base.apk';
          });
        }
      } catch (e) {
        setState(() {
          _fileValid  = false;
          _fileStatus = 'Cannot read file: $e';
        });
      }
    } else if (isAab) {
      // .aab — verify it's a readable zip with base/ or BundleConfig.pb
      try {
        final names = await Future(() {
          final bytes = File(path).readAsBytesSync();
          final archive = ZipDecoder().decodeBytes(bytes);
          return archive.files.map((f) => f.name).toList();
        });
        final hasBase   = names.any((n) => n.startsWith('base/'));
        final hasConfig = names.contains('BundleConfig.pb');
        if (hasBase || hasConfig) {
          final sizeMb = (File(path).lengthSync() / 1024 / 1024).toStringAsFixed(1);
          setState(() {
            _fileValid  = true;
            _fileStatus = 'Valid .aab — $sizeMb MB  (${names.length} entries)';
          });
        } else {
          setState(() {
            _fileValid  = false;
            _fileStatus = 'Invalid .aab — missing base/ structure';
          });
        }
      } catch (e) {
        setState(() {
          _fileValid  = false;
          _fileStatus = 'Cannot read file: $e';
        });
      }
    } else {
      // Plain .apk
      try {
        final size = await File(path).length();
        setState(() {
          _fileValid  = true;
          _fileStatus = 'Valid .apk — ${(size / 1024 / 1024).toStringAsFixed(1)} MB';
        });
      } catch (e) {
        setState(() {
          _fileValid  = false;
          _fileStatus = 'Cannot read file: $e';
        });
      }
    }
  }

  Future<void> _run() async {
    if (!_fileValid || _selectedFilePath == null) return;

    final lower  = _selectedFilePath!.toLowerCase();
    final isApks = lower.endsWith('.apks');
    final isAab  = lower.endsWith('.aab');
    final isApk  = lower.endsWith('.apk');

    // extract mode only supports .apks and .aab inputs
    if (_mode == 'extract' && isApk) {
      _showSnack(
        'AAB→APK mode requires a .apks or .aab file, not a plain .apk.',
        color: const Color(0xFFf59e0b),
      );
      return;
    }

    final hasPermission = await PermissionHelper.ensureStorage(context, accent: _kAccent);
    if (!hasPermission) return;

    final outputDir = await StorageHelper.buildOutputDir(prefix: 'apks_convert');

    setState(() {
      _isProcessing = true;
      _logVisible   = true;
      _logs         = '';
      _outputDir    = null;
      _outputPath   = null;
      _success      = false;
    });
    _logCtrl.forward(from: 0);

    _streamSub?.cancel();
    _streamSub = HbcChannel.logStream.listen((line) {
      if (!mounted) return;
      setState(() { _logs = '$_logs$line\n'; });
      if (_logScroll.hasClients) {
        _logScroll.animateTo(
          _logScroll.position.maxScrollExtent + 200,
          duration: const Duration(milliseconds: 120),
          curve: Curves.easeOut,
        );
      }
    });

    try {
      final Map<String, dynamic> res;

      if (_mode == 'extract' && isAab) {
        // AAB → APK: convert .aab bundle back to flat APK
        res = await HbcChannel.aabToApk(
          aabPath:   _selectedFilePath!,
          outputDir: outputDir,
        );
      } else if (_mode == 'extract') {
        // AAB → APK: extract base.apk from .apks split bundle
        res = await HbcChannel.apksExtractBase(
          apksPath:  _selectedFilePath!,
          outputDir: outputDir,
        );
      } else if (isApk) {
        // APK → AAB: convert a single .apk into an Android App Bundle
        res = await HbcChannel.apkToAab(
          apkPath:   _selectedFilePath!,
          outputDir: outputDir,
        );
      } else {
        // APK → AAB via .apks: merge all splits into one APK, then convert to AAB
        final mergeRes = await HbcChannel.apksMergeUniversal(
          apksPath:  _selectedFilePath!,
          outputDir: outputDir,
        );
        if (mergeRes['status'] != 'success') {
          res = mergeRes;
        } else {
          final mergedPath = mergeRes['output_path'] as String?;
          if (mergedPath == null) {
            res = {'status': 'error', 'error': 'Merge produced no output path', 'output_dir': outputDir};
          } else {
            res = await HbcChannel.apkToAab(
              apkPath:   mergedPath,
              outputDir: outputDir,
            );
          }
        }
      }

      _streamSub?.cancel();

      final ok  = res['status'] == 'success';
      final err = (res['error'] as String?) ?? '';
      setState(() {
        _isProcessing = false;
        _success      = ok;
        _outputDir    = (res['output_dir'] as String?) ?? outputDir;
        _outputPath   = res['output_path'] as String?;
        if (!ok && err.isNotEmpty) {
          _logs = '$_logs\nERROR: $err\n';
        }
      });
    } catch (e) {
      _streamSub?.cancel();
      setState(() {
        _isProcessing = false;
        _logs = '$_logs\nFailed: $e\n';
      });
    }
  }

  void _showSnack(String msg, {Color color = const Color(0xFFef4444)}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: color,
      duration: const Duration(seconds: 3),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      body: SafeArea(
        child: Column(children: [
          _buildTopBar(),
          Expanded(
            child: SingleChildScrollView(
              controller: _pageScroll,
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 32),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const SizedBox(height: 12),
                  _buildHeader(),
                  const SizedBox(height: 18),
                  _buildFileSelector(),
                  const SizedBox(height: 12),
                  _buildModeSelector(),
                  const SizedBox(height: 14),
                  _buildRunButton(),
                  if (_logVisible) ...[
                    const SizedBox(height: 16),
                    _buildLogPanel(),
                  ],
                  if (!_isProcessing && _outputDir != null) ...[
                    const SizedBox(height: 16),
                    _buildResultCard(),
                  ],
                ],
              ),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 8, 16, 4),
      child: Row(children: [
        IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        const Expanded(
          child: Text('AAB / APK Converter',
              style: TextStyle(color: Colors.white, fontSize: 18,
                  fontWeight: FontWeight.w800, letterSpacing: 0.5)),
        ),
        if (_isProcessing)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: _kAccent.withOpacity(0.12),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _kAccent.withOpacity(0.35)),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              SizedBox(width: 10, height: 10,
                  child: CircularProgressIndicator(strokeWidth: 1.5, color: _kAccent)),
              const SizedBox(width: 6),
              Text('Running', style: TextStyle(color: _kAccent, fontSize: 11,
                  fontFamily: 'monospace')),
            ]),
          ),
        IconButton(
          icon: const Icon(Icons.menu_book_rounded, color: Colors.white38, size: 20),
          tooltip: 'How to Use',
          onPressed: () => showGuideModal(context, singleTool: true),
        ),
      ]),
    );
  }

  Widget _buildHeader() {
    return AnimatedBuilder(
      animation: Listenable.merge([_pulseAnim, _orbitCtrl]),
      builder: (_, __) {
        final p = _pulseAnim.value;
        final o = _orbitCtrl.value;
        return Container(
          padding: const EdgeInsets.fromLTRB(16, 18, 16, 18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(
              colors: [Color(0xFF080e1e), Color(0xFF0a1228), Color(0xFF080e1e)],
              begin: Alignment.topLeft, end: Alignment.bottomRight,
            ),
            border: Border.all(
              color: Color.lerp(_kAccent.withOpacity(0.25),
                  _kAccentLight.withOpacity(0.18), p)!,
            ),
            boxShadow: [BoxShadow(
              color: _kAccent.withOpacity(0.05 + p * 0.06),
              blurRadius: 24, spreadRadius: 2,
            )],
          ),
          child: Row(children: [
            SizedBox(
              width: 86, height: 86,
              child: Stack(alignment: Alignment.center, children: [
                Container(width: 82 + p * 4, height: 82 + p * 4,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: _kAccent.withOpacity(0.08 + p * 0.08)),
                    )),
                Transform.rotate(
                  angle: o * 2 * math.pi,
                  child: CustomPaint(
                    size: const Size(72, 72),
                    painter: _OrbitPainter(color: _kAccent, opacity: 0.4 + p * 0.25),
                  ),
                ),
                Container(
                  width: 56, height: 56,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    gradient: LinearGradient(
                      colors: [
                        Color.lerp(const Color(0xFF0e2a3a), const Color(0xFF0e3040), p)!,
                        const Color(0xFF060e1e),
                      ],
                      begin: Alignment.topLeft, end: Alignment.bottomRight,
                    ),
                    boxShadow: [BoxShadow(
                      color: _kAccent.withOpacity(0.2 + p * 0.15),
                      blurRadius: 16,
                    )],
                  ),
                  child: const Icon(Icons.compress_rounded, color: _kAccent, size: 28),
                ),
              ]),
            ),
            const SizedBox(width: 16),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ShaderMask(
                  shaderCallback: (b) => LinearGradient(
                    colors: [Colors.white,
                      Color.lerp(Colors.white, _kAccentLight, p)!],
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                  ).createShader(b),
                  child: const Text('AAB / APK Converter',
                      style: TextStyle(color: Colors.white, fontSize: 19,
                          fontWeight: FontWeight.w900, letterSpacing: 1.2)),
                ),
                const SizedBox(height: 4),
                const Text('AAB ↔ APK  ·  on-device conversion',
                    style: TextStyle(color: _kAccentLight, fontSize: 11,
                        fontWeight: FontWeight.w500, letterSpacing: 0.4)),
                const SizedBox(height: 8),
                Wrap(spacing: 6, runSpacing: 4, children: const [
                  _Chip('.aab'),
                  _Chip('.apks'),
                  _Chip('AAB→APK'),
                  _Chip('APK→AAB'),
                  _Chip('on-device'),
                ]),
                const SizedBox(height: 6),
                Row(children: [
                  Container(width: 6, height: 6,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle, color: _kAccent,
                        boxShadow: [BoxShadow(color: _kAccent.withOpacity(0.6), blurRadius: 6)],
                      )),
                  const SizedBox(width: 5),
                  const Text('Pure on-device · no cloud · no upload',
                      style: TextStyle(fontSize: 10, color: Color(0xFF6b7280),
                          letterSpacing: 0.3)),
                ]),
              ],
            )),
          ]),
        );
      },
    );
  }

  Widget _buildFileSelector() {
    final hasFile = _selectedFileName != null;
    return GestureDetector(
      onTap: _isProcessing ? null : _pickFile,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: const Color(0xFF111122),
          border: Border.all(
            color: hasFile
                ? (_fileValid ? _kAccent.withOpacity(0.35) : const Color(0xFFef4444).withOpacity(0.4))
                : ThemeProvider().current.surfaceColor,
          ),
        ),
        child: Row(children: [
          Icon(
            hasFile ? Icons.archive_rounded : Icons.upload_file_rounded,
            color: hasFile
                ? (_fileValid ? _kAccent : const Color(0xFFef4444))
                : const Color(0xFF4b5563),
            size: 28,
          ),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(
              hasFile ? (_selectedFileName ?? '') : 'Tap to select .apk or .apks file',
              style: TextStyle(
                color: hasFile ? Colors.white : const Color(0xFF6b7280),
                fontSize: 13, fontWeight: FontWeight.w600,
              ),
              maxLines: 1, overflow: TextOverflow.ellipsis,
            ),
            if (_fileStatus.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text(_fileStatus,
                  style: TextStyle(
                    color: _fileValid ? const Color(0xFF6b7280) : const Color(0xFFef4444),
                    fontSize: 11,
                  ),
                  maxLines: 2, overflow: TextOverflow.ellipsis),
            ],
          ])),
          if (!_isProcessing)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: _kAccent.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _kAccent.withOpacity(0.25)),
              ),
              child: Text(hasFile ? 'Change' : 'Browse',
                  style: TextStyle(color: _kAccent, fontSize: 11,
                      fontWeight: FontWeight.w600)),
            ),
        ]),
      ),
    );
  }

  Widget _buildModeSelector() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0d1117),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF1f2937)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Conversion Mode',
            style: TextStyle(color: Colors.white70, fontSize: 12,
                fontWeight: FontWeight.w700, letterSpacing: 0.3)),
        const SizedBox(height: 12),
        _ModeOption(
          value: 'extract',
          groupValue: _mode,
          label: 'AAB to APK',
          description: 'Converts an Android App Bundle (.aab / .apks) into a '
              'single installable APK. Extracts base.apk and keeps the original '
              'Play Store signature — ready to install on any device.',
          icon: Icons.file_download_rounded,
          accent: _kAccent,
          onChanged: _isProcessing ? null : (v) => setState(() => _mode = v!),
        ),
        const SizedBox(height: 10),
        _ModeOption(
          value: 'merge',
          groupValue: _mode,
          label: 'APK to AAB',
          description: 'Converts a plain .apk into an Android App Bundle (.aab) on-device. '
              'Accepts both single .apk files and .apks split bundles. '
              'Output is unsigned — sign with jarsigner before Play Store upload.',
          icon: Icons.merge_rounded,
          accent: _kAccent,
          onChanged: _isProcessing ? null : (v) => setState(() => _mode = v!),
        ),
      ]),
    );
  }

  Widget _buildRunButton() {
    final canRun = _fileValid && !_isProcessing;
    final label  = _mode == 'extract' ? 'Convert AAB to APK' : 'Convert APK to AAB';
    return AnimatedOpacity(
      opacity: canRun ? 1.0 : 0.45,
      duration: const Duration(milliseconds: 200),
      child: GestureDetector(
        onTap: canRun ? _run : null,
        child: Container(
          height: 52,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            gradient: LinearGradient(
              colors: canRun
                  ? [_kAccent, const Color(0xFF0284c7)]
                  : [const Color(0xFF374151), const Color(0xFF1f2937)],
              begin: Alignment.topLeft, end: Alignment.bottomRight,
            ),
            boxShadow: canRun ? [BoxShadow(
              color: _kAccent.withOpacity(0.25), blurRadius: 12,
            )] : null,
          ),
          child: Center(child: _isProcessing
              ? Row(mainAxisSize: MainAxisSize.min, children: [
                  SizedBox(width: 16, height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white.withOpacity(0.8))),
                  const SizedBox(width: 10),
                  const Text('Processing...', style: TextStyle(color: Colors.white,
                      fontSize: 14, fontWeight: FontWeight.w700)),
                ])
              : Row(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 20),
                  const SizedBox(width: 6),
                  Text(label, style: const TextStyle(color: Colors.white,
                      fontSize: 14, fontWeight: FontWeight.w700)),
                ])),
        ),
      ),
    );
  }

  Widget _buildLogPanel() {
    return FadeTransition(
      opacity: _logFade,
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF0a0f1e),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _kAccent.withOpacity(0.18)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Container(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
            decoration: BoxDecoration(
              color: _kAccent.withOpacity(0.06),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
              border: Border(bottom: BorderSide(color: _kAccent.withOpacity(0.12))),
            ),
            child: Row(children: [
              Icon(Icons.terminal_rounded, color: _kAccent, size: 16),
              const SizedBox(width: 8),
              Text('Live Output', style: TextStyle(color: _kAccent, fontSize: 12,
                  fontWeight: FontWeight.w700)),
              const Spacer(),
              if (_isProcessing)
                SizedBox(width: 12, height: 12,
                    child: CircularProgressIndicator(strokeWidth: 1.5, color: _kAccent)),
            ]),
          ),
          SizedBox(
            height: 240,
            child: _logs.isEmpty
                ? Center(child: Text('Waiting for output...',
                    style: TextStyle(color: _kAccent.withOpacity(0.35),
                        fontSize: 12, fontFamily: 'monospace')))
                : Scrollbar(
                    controller: _logScroll,
                    thumbVisibility: true,
                    child: SingleChildScrollView(
                      controller: _logScroll,
                      padding: const EdgeInsets.all(12),
                      child: Text(_logs,
                          style: const TextStyle(color: Color(0xFFd1fae5),
                              fontSize: 11, fontFamily: 'monospace', height: 1.55)),
                    ),
                  ),
          ),
        ]),
      ),
    );
  }

  Widget _buildResultCard() {
    const green = Color(0xFF22c55e);
    const red   = Color(0xFFef4444);
    final ok    = _success;
    final c     = ok ? green : red;

    String friendlyDir = _outputDir ?? '';
    const prefix = '/storage/emulated/0/';
    if (friendlyDir.startsWith(prefix)) friendlyDir = friendlyDir.substring(prefix.length);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: ok ? const Color(0xFF0a1a10) : const Color(0xFF1a0a0a),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: c.withOpacity(0.35)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: c.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(ok ? Icons.task_alt_rounded : Icons.error_rounded, color: c, size: 20),
          ),
          const SizedBox(width: 10),
          Text(ok ? 'Saved to storage' : 'Operation failed',
              style: TextStyle(color: c, fontSize: 13, fontWeight: FontWeight.w700)),
        ]),
        if (ok) ...[
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0xFF0d1a0d),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: green.withOpacity(0.15)),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                const Icon(Icons.folder_open_rounded, color: green, size: 14),
                const SizedBox(width: 6),
                const Text('Save Location',
                    style: TextStyle(color: green, fontSize: 11, fontWeight: FontWeight.w600)),
              ]),
              const SizedBox(height: 6),
              Text('Internal Storage  →  $friendlyDir',
                  style: const TextStyle(color: Color(0xFF86efac),
                      fontSize: 10.5, fontFamily: 'monospace', height: 1.4)),
              if (_outputPath != null) ...[
                const SizedBox(height: 4),
                Text(_outputPath!.split('/').last,
                    style: const TextStyle(color: Color(0xFF6b7280),
                        fontSize: 9.5, fontFamily: 'monospace')),
              ],
            ]),
          ),
          const SizedBox(height: 8),
          const Text('Open any file manager and navigate to the path above.',
              style: TextStyle(color: Color(0xFF6b7280), fontSize: 10.5, height: 1.4)),
        ],
      ]),
    );
  }
}

class _ModeOption extends StatelessWidget {
  final String value;
  final String groupValue;
  final String label;
  final String description;
  final IconData icon;
  final Color accent;
  final ValueChanged<String?>? onChanged;
  const _ModeOption({
    required this.value, required this.groupValue,
    required this.label, required this.description,
    required this.icon, required this.accent, required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final selected = value == groupValue;
    return GestureDetector(
      onTap: onChanged == null ? null : () => onChanged!(value),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: selected ? accent.withOpacity(0.08) : Colors.transparent,
          border: Border.all(
            color: selected ? accent.withOpacity(0.40) : const Color(0xFF1f2937),
          ),
        ),
        child: Row(children: [
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: selected ? accent.withOpacity(0.15) : const Color(0xFF111827),
            ),
            child: Icon(icon, color: selected ? accent : const Color(0xFF4b5563), size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label,
                style: TextStyle(
                  color: selected ? Colors.white : Colors.white60,
                  fontSize: 13, fontWeight: FontWeight.w700,
                )),
            const SizedBox(height: 3),
            Text(description,
                style: const TextStyle(color: Color(0xFF6b7280), fontSize: 11, height: 1.35)),
          ])),
          Radio<String>(
            value: value, groupValue: groupValue,
            onChanged: onChanged,
            activeColor: accent,
            fillColor: MaterialStateProperty.resolveWith((s) =>
                s.contains(MaterialState.selected) ? accent : const Color(0xFF4b5563)),
          ),
        ]),
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  final String label;
  const _Chip(this.label);
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: _kAccent.withOpacity(0.08),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _kAccent.withOpacity(0.25)),
      ),
      child: Text(label,
          style: TextStyle(color: _kAccent.withOpacity(0.8),
              fontSize: 10.5, fontWeight: FontWeight.w600)),
    );
  }
}

class _OrbitPainter extends CustomPainter {
  final Color color;
  final double opacity;
  const _OrbitPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withOpacity(opacity)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    final c = Offset(size.width / 2, size.height / 2);
    final r = size.width / 2;
    canvas.drawCircle(c, r, paint);
    final dot = Paint()
      ..color = color.withOpacity((opacity * 1.8).clamp(0.0, 1.0));
    canvas.drawCircle(Offset(c.dx + r, c.dy), 3, dot);
  }

  @override
  bool shouldRepaint(_OrbitPainter o) => o.opacity != opacity;
}
