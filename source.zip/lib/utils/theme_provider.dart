import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppThemeData {
  final String id;
  final String name;
  final IconData icon;
  final Color scaffoldBg;
  final Color surfaceColor;
  final Color primary;
  final Color secondary;
  final Color appBarBg;
  final Color drawerBg1;
  final Color drawerBg2;
  final Color headerBg1;
  final Color headerBg2;
  final Color borderColor;
  final Color highlightColor;
  final Color textColor;
  final Color subtextColor;
  final Color dividerColor;

  const AppThemeData({
    required this.id,
    required this.name,
    required this.icon,
    required this.scaffoldBg,
    required this.surfaceColor,
    required this.primary,
    required this.secondary,
    required this.appBarBg,
    required this.drawerBg1,
    required this.drawerBg2,
    required this.headerBg1,
    required this.headerBg2,
    required this.borderColor,
    required this.highlightColor,
    required this.textColor,
    required this.subtextColor,
    required this.dividerColor,
  });

  ThemeData toThemeData() {
    return ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: scaffoldBg,
      colorScheme: ColorScheme.dark(
        primary: primary,
        secondary: secondary,
        surface: surfaceColor,
        onPrimary: Colors.white,
        onSurface: textColor,
      ),
      cardTheme: CardThemeData(
        color: surfaceColor,
        elevation: 8,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: borderColor, width: 1),
        ),
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: appBarBg,
        foregroundColor: textColor,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.2,
          color: textColor,
        ),
      ),
      drawerTheme: DrawerThemeData(
        backgroundColor: drawerBg1,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primary,
          foregroundColor: Colors.white,
          elevation: 6,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          textStyle: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.8,
          ),
        ),
      ),
      useMaterial3: true,
    );
  }
}

class ThemeProvider extends ChangeNotifier {
  static final ThemeProvider _instance = ThemeProvider._();
  factory ThemeProvider() => _instance;
  ThemeProvider._();

  String _currentId = 'arctic';

  AppThemeData get current =>
      allThemes.firstWhere((t) => t.id == _currentId, orElse: () => allThemes.first);

  String get currentId => _currentId;

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    _currentId = p.getString('app_theme') ?? 'arctic';
    notifyListeners();
  }

  Future<void> setTheme(String id) async {
    if (_currentId == id) return;
    _currentId = id;
    final p = await SharedPreferences.getInstance();
    await p.setString('app_theme', id);
    notifyListeners();
  }

  static final List<AppThemeData> allThemes = [
    const AppThemeData(
      id: 'arctic',
      name: 'Arctic Frost',
      icon: Icons.ac_unit_rounded,
      scaffoldBg: Color(0xFF000000),
      surfaceColor: Color(0xFF101c24),
      primary: Color(0xFF06b6d4),
      secondary: Color(0xFF22d3ee),
      appBarBg: Color(0xFF0c141a),
      drawerBg1: Color(0xFF0c141a),
      drawerBg2: Color(0xFF080e14),
      headerBg1: Color(0xFF0e2030),
      headerBg2: Color(0xFF0a1620),
      borderColor: Color(0xFF164e63),
      highlightColor: Color(0xFF67e8f9),
      textColor: Color(0xFFe0f7fa),
      subtextColor: Color(0xFF67e8f9),
      dividerColor: Color(0xFF133040),
    ),
    const AppThemeData(
      id: 'default',
      name: 'Cyber Purple',
      icon: Icons.blur_on_rounded,
      scaffoldBg: Color(0xFF000000),
      surfaceColor: Color(0xFF12121e),
      primary: Color(0xFF7c3aed),
      secondary: Color(0xFF9d5cf6),
      appBarBg: Color(0xFF0d0d20),
      drawerBg1: Color(0xFF0d0d20),
      drawerBg2: Color(0xFF120820),
      headerBg1: Color(0xFF1a0a30),
      headerBg2: Color(0xFF0d1230),
      borderColor: Color(0xFF2a1a4a),
      highlightColor: Color(0xFF4ade80),
      textColor: Colors.white,
      subtextColor: Color(0xFF9d5cf6),
      dividerColor: Color(0xFF2a1a4a),
    ),
    const AppThemeData(
      id: 'cyber_blue',
      name: 'Cyber Blue',
      icon: Icons.shield_rounded,
      scaffoldBg: Color(0xFF000000),
      surfaceColor: Color(0xFF0c1424),
      primary: Color(0xFF3b82f6),
      secondary: Color(0xFF60a5fa),
      appBarBg: Color(0xFF080e1e),
      drawerBg1: Color(0xFF080e1e),
      drawerBg2: Color(0xFF050a14),
      headerBg1: Color(0xFF0a1830),
      headerBg2: Color(0xFF061020),
      borderColor: Color(0xFF1a2a4a),
      highlightColor: Color(0xFF38bdf8),
      textColor: Colors.white,
      subtextColor: Color(0xFF93c5fd),
      dividerColor: Color(0xFF152040),
    ),
    const AppThemeData(
      id: 'blood_moon',
      name: 'Blood Moon',
      icon: Icons.nightlight_round,
      scaffoldBg: Color(0xFF000000),
      surfaceColor: Color(0xFF1c0e14),
      primary: Color(0xFFbe123c),
      secondary: Color(0xFFe11d48),
      appBarBg: Color(0xFF10080c),
      drawerBg1: Color(0xFF10080c),
      drawerBg2: Color(0xFF0a0506),
      headerBg1: Color(0xFF2a0a18),
      headerBg2: Color(0xFF18060e),
      borderColor: Color(0xFF3a1528),
      highlightColor: Color(0xFFfb7185),
      textColor: Color(0xFFfff1f2),
      subtextColor: Color(0xFFfda4af),
      dividerColor: Color(0xFF301020),
    ),
    const AppThemeData(
      id: 'sunset',
      name: 'Sunset Blaze',
      icon: Icons.wb_sunny_rounded,
      scaffoldBg: Color(0xFF000000),
      surfaceColor: Color(0xFF1c1408),
      primary: Color(0xFFf59e0b),
      secondary: Color(0xFFfbbf24),
      appBarBg: Color(0xFF120e06),
      drawerBg1: Color(0xFF120e06),
      drawerBg2: Color(0xFF0a0804),
      headerBg1: Color(0xFF2a1a06),
      headerBg2: Color(0xFF1a1004),
      borderColor: Color(0xFF4a3010),
      highlightColor: Color(0xFFfcd34d),
      textColor: Color(0xFFFFF8E1),
      subtextColor: Color(0xFFfbbf24),
      dividerColor: Color(0xFF352510),
    ),
    const AppThemeData(
      id: 'venom',
      name: 'Venom',
      icon: Icons.pest_control_rounded,
      scaffoldBg: Color(0xFF000000),
      surfaceColor: Color(0xFF0e140e),
      primary: Color(0xFF65a30d),
      secondary: Color(0xFF84cc16),
      appBarBg: Color(0xFF080c08),
      drawerBg1: Color(0xFF080c08),
      drawerBg2: Color(0xFF050805),
      headerBg1: Color(0xFF142010),
      headerBg2: Color(0xFF0a140a),
      borderColor: Color(0xFF1a3010),
      highlightColor: Color(0xFFbef264),
      textColor: Color(0xFFecfccb),
      subtextColor: Color(0xFF84cc16),
      dividerColor: Color(0xFF162810),
    ),
    const AppThemeData(
      id: 'sakura',
      name: 'Sakura',
      icon: Icons.spa_rounded,
      scaffoldBg: Color(0xFF000000),
      surfaceColor: Color(0xFF1a1018),
      primary: Color(0xFFec4899),
      secondary: Color(0xFFf472b6),
      appBarBg: Color(0xFF100a0e),
      drawerBg1: Color(0xFF100a0e),
      drawerBg2: Color(0xFF0a0608),
      headerBg1: Color(0xFF280e20),
      headerBg2: Color(0xFF180814),
      borderColor: Color(0xFF3a1530),
      highlightColor: Color(0xFFfbcfe8),
      textColor: Color(0xFFfff1f7),
      subtextColor: Color(0xFFf472b6),
      dividerColor: Color(0xFF2e1025),
    ),
    const AppThemeData(
      id: 'midnight',
      name: 'Midnight Indigo',
      icon: Icons.dark_mode_rounded,
      scaffoldBg: Color(0xFF000000),
      surfaceColor: Color(0xFF0e0e1e),
      primary: Color(0xFF6366f1),
      secondary: Color(0xFF818cf8),
      appBarBg: Color(0xFF080814),
      drawerBg1: Color(0xFF080814),
      drawerBg2: Color(0xFF05050c),
      headerBg1: Color(0xFF14142a),
      headerBg2: Color(0xFF0a0a1a),
      borderColor: Color(0xFF252548),
      highlightColor: Color(0xFFa5b4fc),
      textColor: Color(0xFFe8e8ff),
      subtextColor: Color(0xFF818cf8),
      dividerColor: Color(0xFF1e1e3a),
    ),
    const AppThemeData(
      id: 'emerald',
      name: 'Emerald Depths',
      icon: Icons.hexagon_rounded,
      scaffoldBg: Color(0xFF000000),
      surfaceColor: Color(0xFF0a1616),
      primary: Color(0xFF059669),
      secondary: Color(0xFF10b981),
      appBarBg: Color(0xFF060e0e),
      drawerBg1: Color(0xFF060e0e),
      drawerBg2: Color(0xFF040a0a),
      headerBg1: Color(0xFF082018),
      headerBg2: Color(0xFF061410),
      borderColor: Color(0xFF0f3a2a),
      highlightColor: Color(0xFF6ee7b7),
      textColor: Color(0xFFd1fae5),
      subtextColor: Color(0xFF10b981),
      dividerColor: Color(0xFF0c2a1e),
    ),
    const AppThemeData(
      id: 'volcano',
      name: 'Volcano',
      icon: Icons.whatshot_rounded,
      scaffoldBg: Color(0xFF000000),
      surfaceColor: Color(0xFF1a0e08),
      primary: Color(0xFFea580c),
      secondary: Color(0xFFf97316),
      appBarBg: Color(0xFF100806),
      drawerBg1: Color(0xFF100806),
      drawerBg2: Color(0xFF0a0504),
      headerBg1: Color(0xFF2a1208),
      headerBg2: Color(0xFF1a0c06),
      borderColor: Color(0xFF4a2010),
      highlightColor: Color(0xFFfdba74),
      textColor: Color(0xFFfff7ed),
      subtextColor: Color(0xFFf97316),
      dividerColor: Color(0xFF361a0c),
    ),
    const AppThemeData(
      id: 'abyss',
      name: 'Abyss',
      icon: Icons.waves_rounded,
      scaffoldBg: Color(0xFF000000),
      surfaceColor: Color(0xFF0a0e18),
      primary: Color(0xFF1e40af),
      secondary: Color(0xFF3b82f6),
      appBarBg: Color(0xFF060810),
      drawerBg1: Color(0xFF060810),
      drawerBg2: Color(0xFF040608),
      headerBg1: Color(0xFF0a1428),
      headerBg2: Color(0xFF060e1a),
      borderColor: Color(0xFF1a2850),
      highlightColor: Color(0xFF93c5fd),
      textColor: Color(0xFFdbeafe),
      subtextColor: Color(0xFF60a5fa),
      dividerColor: Color(0xFF121e40),
    ),
  ];
}
