import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:archive/archive.dart';
import 'package:crypto/crypto.dart' as crypto;

const _kCfBase = 'https://api.cloudflare.com/client/v4';

class CfResult {
  final bool ok;
  final dynamic data;
  final String? error;
  const CfResult({required this.ok, this.data, this.error});
}

class CfApi {
  final String token;
  const CfApi(this.token);

  Map<String, String> get _h => {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      };

  Future<CfResult> _get(String path) async {
    try {
      final r = await http
          .get(Uri.parse('$_kCfBase$path'), headers: _h)
          .timeout(const Duration(seconds: 20));
      final j = jsonDecode(r.body);
      if (j['success'] == true) return CfResult(ok: true, data: j);
      final e = (j['errors'] as List?)?.firstOrNull?['message'] ?? 'Error';
      return CfResult(ok: false, error: e);
    } catch (e) {
      return CfResult(ok: false, error: e.toString());
    }
  }

  Future<CfResult> _post(String path, Map body) async {
    try {
      final r = await http
          .post(Uri.parse('$_kCfBase$path'),
              headers: _h, body: jsonEncode(body))
          .timeout(const Duration(seconds: 20));
      final j = jsonDecode(r.body);
      if (j['success'] == true) return CfResult(ok: true, data: j);
      final e = (j['errors'] as List?)?.firstOrNull?['message'] ?? 'Error';
      return CfResult(ok: false, error: e);
    } catch (e) {
      return CfResult(ok: false, error: e.toString());
    }
  }

  Future<CfResult> _patch(String path, Map body) async {
    try {
      final r = await http
          .patch(Uri.parse('$_kCfBase$path'),
              headers: _h, body: jsonEncode(body))
          .timeout(const Duration(seconds: 20));
      final j = jsonDecode(r.body);
      if (j['success'] == true) return CfResult(ok: true, data: j);
      final e = (j['errors'] as List?)?.firstOrNull?['message'] ?? 'Error';
      return CfResult(ok: false, error: e);
    } catch (e) {
      return CfResult(ok: false, error: e.toString());
    }
  }

  Future<CfResult> _put(String path, Map body) async {
    try {
      final r = await http
          .put(Uri.parse('$_kCfBase$path'),
              headers: _h, body: jsonEncode(body))
          .timeout(const Duration(seconds: 20));
      final j = jsonDecode(r.body);
      if (j['success'] == true) return CfResult(ok: true, data: j);
      final e = (j['errors'] as List?)?.firstOrNull?['message'] ?? 'Error';
      return CfResult(ok: false, error: e);
    } catch (e) {
      return CfResult(ok: false, error: e.toString());
    }
  }

  Future<CfResult> _delete(String path) async {
    try {
      final r = await http
          .delete(Uri.parse('$_kCfBase$path'), headers: _h)
          .timeout(const Duration(seconds: 20));
      final j = jsonDecode(r.body);
      if (j['success'] == true) return CfResult(ok: true, data: j);
      final e = (j['errors'] as List?)?.firstOrNull?['message'] ?? 'Error';
      return CfResult(ok: false, error: e);
    } catch (e) {
      return CfResult(ok: false, error: e.toString());
    }
  }

  Future<CfResult> _deleteBody(String path, dynamic body) async {
    try {
      final r = await http
          .delete(Uri.parse('$_kCfBase$path'),
              headers: _h, body: jsonEncode(body))
          .timeout(const Duration(seconds: 20));
      final j = jsonDecode(r.body);
      if (j['success'] == true) return CfResult(ok: true, data: j);
      final e = (j['errors'] as List?)?.firstOrNull?['message'] ?? 'Error';
      return CfResult(ok: false, error: e);
    } catch (e) {
      return CfResult(ok: false, error: e.toString());
    }
  }

  Future<CfResult> _getRaw(String path) async {
    try {
      final r = await http
          .get(Uri.parse('$_kCfBase$path'),
              headers: {'Authorization': 'Bearer $token'})
          .timeout(const Duration(seconds: 20));
      if (r.statusCode >= 200 && r.statusCode < 300) {
        return CfResult(ok: true, data: r.body);
      }
      try {
        final j = jsonDecode(r.body);
        final e = (j['errors'] as List?)?.firstOrNull?['message'] ?? 'Error ${r.statusCode}';
        return CfResult(ok: false, error: e);
      } catch (_) {
        return CfResult(ok: false, error: 'Error ${r.statusCode}');
      }
    } catch (e) {
      return CfResult(ok: false, error: e.toString());
    }
  }

  Future<CfResult> _putRaw(String path, String body, String contentType) async {
    try {
      final r = await http
          .put(Uri.parse('$_kCfBase$path'),
              headers: {'Authorization': 'Bearer $token', 'Content-Type': contentType},
              body: body)
          .timeout(const Duration(seconds: 20));
      if (r.statusCode >= 200 && r.statusCode < 300) {
        try {
          final j = jsonDecode(r.body);
          if (j['success'] == true) return CfResult(ok: true, data: j);
        } catch (_) {
          return CfResult(ok: true, data: r.body);
        }
      }
      try {
        final j = jsonDecode(r.body);
        final e = (j['errors'] as List?)?.firstOrNull?['message'] ?? 'Error ${r.statusCode}';
        return CfResult(ok: false, error: e);
      } catch (_) {
        return CfResult(ok: false, error: 'Error ${r.statusCode}');
      }
    } catch (e) {
      return CfResult(ok: false, error: e.toString());
    }
  }

  // ── Auth ──────────────────────────────────────────────────────────────────
  Future<CfResult> verifyToken() => _get('/user/tokens/verify');
  Future<CfResult> getUserInfo() => _get('/user');
  Future<CfResult> listAccounts() => _get('/accounts');

  // ── Zones ─────────────────────────────────────────────────────────────────
  Future<CfResult> listZones({int page = 1}) =>
      _get('/zones?page=$page&per_page=50');

  // ── DNS ───────────────────────────────────────────────────────────────────
  Future<CfResult> listDNSRecords(String zoneId) =>
      _get('/zones/$zoneId/dns_records?per_page=100');

  Future<CfResult> createDNSRecord(String zoneId, Map data) =>
      _post('/zones/$zoneId/dns_records', data);

  Future<CfResult> updateDNSRecord(String zoneId, String recordId, Map data) =>
      _patch('/zones/$zoneId/dns_records/$recordId', data);

  Future<CfResult> deleteDNSRecord(String zoneId, String recordId) =>
      _delete('/zones/$zoneId/dns_records/$recordId');

  // ── Workers ───────────────────────────────────────────────────────────────
  Future<CfResult> listWorkers(String accountId) =>
      _get('/accounts/$accountId/workers/scripts');

  Future<CfResult> getWorkerSubdomain(String accountId) =>
      _get('/accounts/$accountId/workers/subdomain');

  Future<CfResult> deleteWorker(String accountId, String name) =>
      _delete('/accounts/$accountId/workers/scripts/$name');

  Future<CfResult> getWorkerRoutes(String zoneId) =>
      _get('/zones/$zoneId/workers/routes');

  Future<CfResult> createWorkerRoute(
          String zoneId, String pattern, String scriptName) =>
      _post('/zones/$zoneId/workers/routes',
          {'pattern': pattern, 'script': scriptName});

  Future<CfResult> deleteWorkerRoute(String zoneId, String routeId) =>
      _delete('/zones/$zoneId/workers/routes/$routeId');

  // Secrets / environment variables (encrypted)
  Future<CfResult> listWorkerSecrets(String accountId, String name) =>
      _get('/accounts/$accountId/workers/scripts/$name/secrets');

  Future<CfResult> putWorkerSecret(
          String accountId, String name, String secretName, String value) =>
      _put('/accounts/$accountId/workers/scripts/$name/secrets', {
        'name': secretName,
        'text': value,
        'type': 'secret_text',
      });

  Future<CfResult> deleteWorkerSecret(
          String accountId, String name, String secretName) =>
      _delete(
          '/accounts/$accountId/workers/scripts/$name/secrets/$secretName');

  // Worker Settings (bindings, compatibility date, usage model, placement)
  Future<CfResult> getWorkerSettings(String accountId, String name) =>
      _get('/accounts/$accountId/workers/scripts/$name/settings');

  Future<CfResult> patchWorkerSettings(
          String accountId, String name, Map<String, dynamic> settings) =>
      _patch('/accounts/$accountId/workers/scripts/$name/settings', settings);

  // Cron Triggers / Schedules
  Future<CfResult> getWorkerCrons(String accountId, String name) =>
      _get('/accounts/$accountId/workers/scripts/$name/schedules');

  Future<CfResult> putWorkerCrons(String accountId, String name,
          List<Map<String, dynamic>> schedules) =>
      _put('/accounts/$accountId/workers/scripts/$name/schedules',
          {'schedules': schedules});

  // Custom Domains
  Future<CfResult> listWorkerCustomDomains(String accountId, String name) =>
      _get('/accounts/$accountId/workers/scripts/$name/domains');

  Future<CfResult> addWorkerCustomDomain(
          String accountId, String name, String hostname, String zoneId) =>
      _post('/accounts/$accountId/workers/scripts/$name/domains',
          {'hostname': hostname, 'zone_id': zoneId});

  Future<CfResult> deleteWorkerCustomDomain(
          String accountId, String name, String id) =>
      _delete('/accounts/$accountId/workers/scripts/$name/domains/$id');

  // Subdomain (workers.dev) enable/disable
  Future<CfResult> setWorkerSubdomainEnabled(
          String accountId, String name, bool enabled) =>
      _post('/accounts/$accountId/workers/scripts/$name/subdomain',
          {'enabled': enabled});

  // Resource listing for binding pickers
  Future<CfResult> listKvNamespaces(String accountId) =>
      _get('/accounts/$accountId/storage/kv/namespaces?per_page=100');

  Future<CfResult> listR2Buckets(String accountId) =>
      _get('/accounts/$accountId/r2/buckets');

  Future<CfResult> listD1Databases(String accountId) =>
      _get('/accounts/$accountId/d1/database?per_page=100');

  Future<CfResult> listQueues(String accountId) =>
      _get('/accounts/$accountId/queues');

  // Rename = deploy to new name + delete old
  Future<CfResult> renameWorker(
      String accountId, String oldName, String newName) async {
    final script = await getWorkerScript(accountId, oldName);
    if (script == null || script.isEmpty) {
      return CfResult(ok: false, error: 'Could not fetch script for rename');
    }
    final upload = await uploadWorkerScript(accountId, newName, script);
    if (!upload.ok) return upload;
    return deleteWorker(accountId, oldName);
  }

  Future<String?> getWorkerScript(String accountId, String name) async {
    try {
      final r = await http
          .get(
              Uri.parse(
                  '$_kCfBase/accounts/$accountId/workers/scripts/$name'),
              headers: {'Authorization': 'Bearer $token'})
          .timeout(const Duration(seconds: 30));
      String body = r.body;
      final ct = r.headers['content-type'] ?? '';
      if (ct.contains('multipart/form-data')) {
        final bm = RegExp(r'boundary=(.+)').firstMatch(ct);
        if (bm != null) {
          final boundary = bm.group(1)!.trim();
          final parts = body.split('--$boundary');
          for (final part in parts) {
            if (part.contains('.js"') || part.contains('name="script"')) {
              final idx = part.indexOf('\r\n\r\n');
              if (idx != -1) {
                body = part.substring(idx + 4).trim();
                if (body.endsWith('--')) body = body.substring(0, body.length - 2).trim();
                break;
              }
            }
          }
        }
      }
      return body;
    } catch (_) {
      return null;
    }
  }

  static String? extractJsFromZip(Uint8List zipBytes) {
    try {
      final archive = ZipDecoder().decodeBytes(zipBytes);
      const candidates = [
        'index.js', 'worker.js', 'src/index.js', 'dist/index.js',
        'dist/worker.js', 'src/worker.js', '_worker.js',
      ];
      for (final name in candidates) {
        final f = archive.findFile(name);
        if (f != null && f.isFile) return utf8.decode(f.content as List<int>, allowMalformed: true);
      }
      for (final f in archive.files) {
        if (f.isFile && (f.name.endsWith('.js') || f.name.endsWith('.mjs'))) {
          return utf8.decode(f.content as List<int>, allowMalformed: true);
        }
      }
      return null;
    } catch (_) { return null; }
  }

  Future<CfResult> uploadWorkerScript(
      String accountId, String name, String script) async {
    try {
      final isModule = script.contains('export default') ||
          script.contains('export {') ||
          script.trimLeft().startsWith('import ');
      final req = http.MultipartRequest(
        'PUT',
        Uri.parse('$_kCfBase/accounts/$accountId/workers/scripts/$name'),
      )..headers['Authorization'] = 'Bearer $token';

      if (isModule) {
        req.files.add(http.MultipartFile.fromString(
          'worker.js', script,
          filename: 'worker.js',
          contentType: MediaType('application', 'javascript+module'),
        ));
        req.fields['metadata'] = jsonEncode({
          'main_module': 'worker.js',
          'compatibility_date': '2024-01-01',
        });
      } else {
        req.files.add(http.MultipartFile.fromString(
          'script', script,
          filename: 'worker.js',
          contentType: MediaType('application', 'javascript'),
        ));
        req.fields['metadata'] = jsonEncode({
          'body_part': 'script',
          'compatibility_date': '2024-01-01',
        });
      }

      final streamed = await req.send().timeout(const Duration(seconds: 60));
      final resp = await http.Response.fromStream(streamed);
      final j = jsonDecode(resp.body);
      if (j['success'] == true) return CfResult(ok: true, data: j);
      final e = (j['errors'] as List?)?.firstOrNull?['message'] ?? 'Upload failed';
      return CfResult(ok: false, error: e);
    } catch (e) {
      return CfResult(ok: false, error: e.toString());
    }
  }

  // ── Analytics (GraphQL) ──────────────────────────────────────────────────
  Future<CfResult> getWorkersAnalytics(String accountId, int days) async {
    final now = DateTime.now().toUtc();
    final start = days == 30
        ? DateTime.utc(now.year, now.month, 1)
        : now.subtract(Duration(hours: days * 24));
    final query = '''
{
  viewer {
    accounts(filter: {accountTag: "$accountId"}) {
      workersInvocationsAdaptive(
        filter: { datetime_geq: "${start.toIso8601String()}", datetime_leq: "${now.toIso8601String()}" }
        limit: 10000
      ) {
        sum { requests errors }
        dimensions { scriptName }
      }
      workersCpuTime: workersInvocationsAdaptive(
        filter: { datetime_geq: "${start.toIso8601String()}", datetime_leq: "${now.toIso8601String()}" }
        limit: 10000
      ) {
        quantiles { cpuTimeP50 cpuTimeP99 }
        sum { requests }
        dimensions { scriptName }
      }
    }
  }
}''';
    try {
      final r = await http
          .post(
            Uri.parse('$_kCfBase/graphql'),
            headers: {
              'Authorization': 'Bearer $token',
              'Content-Type': 'application/json',
            },
            body: jsonEncode({'query': query}),
          )
          .timeout(const Duration(seconds: 30));
      final j = jsonDecode(r.body);
      if (j['errors'] != null) {
        return CfResult(ok: false, error: j['errors'].toString());
      }
      return CfResult(ok: true, data: j);
    } catch (e) {
      return CfResult(ok: false, error: e.toString());
    }
  }

  // ── Pages ─────────────────────────────────────────────────────────────────
  Future<CfResult> listPagesProjects(String accountId) =>
      _get('/accounts/$accountId/pages/projects');

  Future<CfResult> getPagesProject(String accountId, String name) =>
      _get('/accounts/$accountId/pages/projects/$name');

  Future<CfResult> createPagesProject(String accountId, String name) =>
      _post('/accounts/$accountId/pages/projects', {
        'name': name,
        'production_branch': 'main',
      });

  Future<CfResult> listPagesDeployments(String accountId, String name) =>
      _get('/accounts/$accountId/pages/projects/$name/deployments');

  Future<CfResult> deletePagesProject(String accountId, String name) =>
      _delete('/accounts/$accountId/pages/projects/$name');

  Future<CfResult> getLatestPagesDeployment(String accountId, String projectName) async {
    final list = await _get('/accounts/$accountId/pages/projects/$projectName/deployments?per_page=25');
    if (!list.ok) return list;
    final items = list.data['result'] as List? ?? [];
    if (items.isEmpty) return CfResult(ok: false, error: 'No deployments found');
    final latest = items.firstWhere(
      (d) => (d['latest_stage']?['status'] ?? '') == 'success',
      orElse: () => items.first,
    );
    final id = latest['id'] as String? ?? '';
    if (id.isEmpty) return CfResult(ok: true, data: {'result': latest});
    return _get('/accounts/$accountId/pages/projects/$projectName/deployments/$id');
  }

  Future<CfResult> deletePagesDeployment(String accountId, String projectName, String deploymentId) =>
      _delete('/accounts/$accountId/pages/projects/$projectName/deployments/$deploymentId?force=true');

  Future<CfResult> deployPagesZip(
      String accountId, String projectName, Uint8List zipBytes) async {
    try {
      final archive = ZipDecoder().decodeBytes(zipBytes);
      final files = <String, Uint8List>{};
      for (final f in archive.files) {
        if (f.isFile && !f.name.startsWith('__MACOSX')) {
          final raw = f.content;
          files['/${f.name}'] = raw is Uint8List ? raw : Uint8List.fromList(raw as List<int>);
        }
      }
      if (files.isEmpty) return CfResult(ok: false, error: 'ZIP contains no files');

      final tokenRes = await http.get(
        Uri.parse('$_kCfBase/accounts/$accountId/pages/projects/$projectName/upload-token'),
        headers: {'Authorization': 'Bearer $token'},
      );
      final tokenJson = jsonDecode(tokenRes.body);
      if (tokenJson['success'] != true) {
        return CfResult(ok: false, error: tokenJson['errors']?[0]?['message'] ?? 'Could not get upload token');
      }
      final jwt = tokenJson['result']['jwt'] as String;

      final manifest = <String, String>{};
      final toUpload = <Map<String, dynamic>>[];
      for (final entry in files.entries) {
        final hash = base64Url.encode(crypto.sha256.convert(entry.value).bytes).replaceAll('=', '');
        manifest[entry.key] = hash;
        toUpload.add({'key': hash, 'value': base64.encode(entry.value),
            'metadata': {'contentType': _mimeFor(entry.key)}});
      }

      const batchSize = 20;
      for (var i = 0; i < toUpload.length; i += batchSize) {
        final batch = toUpload.skip(i).take(batchSize).toList();
        final upResp = await http.post(
          Uri.parse('https://api.cloudflare.com/client/v4/pages/assets/upload'),
          headers: {'Authorization': 'Bearer $jwt', 'Content-Type': 'application/json'},
          body: jsonEncode(batch),
        );
        final upJson = jsonDecode(upResp.body);
        if (upJson['success'] != true) {
          return CfResult(ok: false, error: upJson['errors']?[0]?['message'] ?? 'File upload failed');
        }
      }

      final depResp = await http.post(
        Uri.parse('$_kCfBase/accounts/$accountId/pages/projects/$projectName/deployments'),
        headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
        body: jsonEncode({'manifest': manifest}),
      );
      final depJson = jsonDecode(depResp.body);
      if (depJson['success'] == true) return CfResult(ok: true, data: depJson);
      return CfResult(ok: false, error: depJson['errors']?[0]?['message'] ?? 'Deployment failed');
    } catch (e) {
      return CfResult(ok: false, error: e.toString());
    }
  }

  // ── KV Namespaces ─────────────────────────────────────────────────────────
  Future<CfResult> createKvNamespace(String accountId, String title) =>
      _post('/accounts/$accountId/storage/kv/namespaces', {'title': title});

  Future<CfResult> deleteKvNamespace(String accountId, String id) =>
      _delete('/accounts/$accountId/storage/kv/namespaces/$id');

  Future<CfResult> renameKvNamespace(String accountId, String id, String title) =>
      _put('/accounts/$accountId/storage/kv/namespaces/$id', {'title': title});

  Future<CfResult> listKvKeys(String accountId, String nsId,
      {String? prefix, String? cursor, int limit = 100}) {
    var path =
        '/accounts/$accountId/storage/kv/namespaces/$nsId/keys?limit=$limit';
    if (prefix != null && prefix.isNotEmpty) {
      path += '&prefix=${Uri.encodeComponent(prefix)}';
    }
    if (cursor != null && cursor.isNotEmpty) {
      path += '&cursor=${Uri.encodeComponent(cursor)}';
    }
    return _get(path);
  }

  Future<CfResult> getKvValue(String accountId, String nsId, String key) =>
      _getRaw('/accounts/$accountId/storage/kv/namespaces/$nsId/values/${Uri.encodeComponent(key)}');

  Future<CfResult> putKvValue(
      String accountId, String nsId, String key, String value,
      {int? expirationTtl}) {
    var path =
        '/accounts/$accountId/storage/kv/namespaces/$nsId/values/${Uri.encodeComponent(key)}';
    if (expirationTtl != null && expirationTtl > 0) {
      path += '?expiration_ttl=$expirationTtl';
    }
    return _putRaw(path, value, 'text/plain');
  }

  Future<CfResult> deleteKvValue(String accountId, String nsId, String key) =>
      _delete('/accounts/$accountId/storage/kv/namespaces/$nsId/values/${Uri.encodeComponent(key)}');

  Future<CfResult> deleteKvKeys(
          String accountId, String nsId, List<String> keys) =>
      _deleteBody(
          '/accounts/$accountId/storage/kv/namespaces/$nsId/bulk/delete', keys);

  // ── D1 Databases ───────────────────────────────────────────────────────────
  Future<CfResult> createD1Database(String accountId, String name) =>
      _post('/accounts/$accountId/d1/database', {'name': name});

  Future<CfResult> deleteD1Database(String accountId, String databaseId) =>
      _delete('/accounts/$accountId/d1/database/$databaseId');

  Future<CfResult> queryD1(String accountId, String databaseId, String sql,
          {List<dynamic>? params}) =>
      _post('/accounts/$accountId/d1/database/$databaseId/query',
          {'sql': sql, if (params != null && params.isNotEmpty) 'params': params});

  // ── R2 Buckets ─────────────────────────────────────────────────────────────
  Future<CfResult> createR2Bucket(String accountId, String name,
          {String? locationHint}) =>
      _post('/accounts/$accountId/r2/buckets', {
        'name': name,
        if (locationHint != null) 'locationHint': locationHint,
      });

  Future<CfResult> deleteR2Bucket(String accountId, String name) =>
      _delete('/accounts/$accountId/r2/buckets/$name');

  Future<CfResult> getR2BucketCors(String accountId, String name) =>
      _get('/accounts/$accountId/r2/buckets/$name/cors');

  Future<CfResult> putR2BucketCors(
          String accountId, String name, List<dynamic> rules) =>
      _put('/accounts/$accountId/r2/buckets/$name/cors', {'rules': rules});

  Future<CfResult> deleteR2BucketCors(String accountId, String name) =>
      _delete('/accounts/$accountId/r2/buckets/$name/cors');

  Future<CfResult> getR2BucketLifecycle(String accountId, String name) =>
      _get('/accounts/$accountId/r2/buckets/$name/lifecycle');

  Future<CfResult> putR2BucketLifecycle(
          String accountId, String name, List<dynamic> rules) =>
      _put('/accounts/$accountId/r2/buckets/$name/lifecycle', {'rules': rules});

  Future<CfResult> deleteR2BucketLifecycle(String accountId, String name) =>
      _delete('/accounts/$accountId/r2/buckets/$name/lifecycle');

  // ── Queues ─────────────────────────────────────────────────────────────────
  Future<CfResult> createQueue(String accountId, String name) =>
      _post('/accounts/$accountId/queues', {'queue_name': name});

  Future<CfResult> deleteQueue(String accountId, String queueId) =>
      _delete('/accounts/$accountId/queues/$queueId');

  Future<CfResult> getQueue(String accountId, String queueId) =>
      _get('/accounts/$accountId/queues/$queueId');

  Future<CfResult> listQueueConsumers(String accountId, String queueId) =>
      _get('/accounts/$accountId/queues/$queueId/consumers');

  Future<CfResult> createQueueConsumer(String accountId, String queueId,
          Map<String, dynamic> consumer) =>
      _post('/accounts/$accountId/queues/$queueId/consumers', consumer);

  Future<CfResult> updateQueueConsumer(String accountId, String queueId,
          String consumerId, Map<String, dynamic> consumer) =>
      _put('/accounts/$accountId/queues/$queueId/consumers/$consumerId',
          consumer);

  Future<CfResult> deleteQueueConsumer(
          String accountId, String queueId, String consumerId) =>
      _delete('/accounts/$accountId/queues/$queueId/consumers/$consumerId');

  Future<CfResult> sendQueueMessages(String accountId, String queueId,
          List<Map<String, dynamic>> messages) =>
      _post('/accounts/$accountId/queues/$queueId/messages',
          {'messages': messages});

  Future<CfResult> pullQueueMessages(String accountId, String queueId,
          {int batchSize = 10}) =>
      _post('/accounts/$accountId/queues/$queueId/messages/pull',
          {'batch_size': batchSize});

  Future<CfResult> ackQueueMessages(String accountId, String queueId,
          List<String> leaseIds, List<String> retryIds) =>
      _post('/accounts/$accountId/queues/$queueId/messages/ack', {
        'acks': leaseIds.map((id) => {'lease_id': id}).toList(),
        'retries': retryIds.map((id) => {'lease_id': id}).toList(),
      });

  static String _mimeFor(String path) {
    final ext = path.split('.').last.toLowerCase();
    const m = {
      'html': 'text/html', 'htm': 'text/html',
      'css': 'text/css', 'js': 'application/javascript',
      'mjs': 'application/javascript', 'json': 'application/json',
      'png': 'image/png', 'jpg': 'image/jpeg', 'jpeg': 'image/jpeg',
      'gif': 'image/gif', 'svg': 'image/svg+xml', 'webp': 'image/webp',
      'ico': 'image/x-icon', 'woff': 'font/woff', 'woff2': 'font/woff2',
      'ttf': 'font/ttf', 'txt': 'text/plain', 'xml': 'application/xml',
      'pdf': 'application/pdf', 'mp4': 'video/mp4', 'webm': 'video/webm',
    };
    return m[ext] ?? 'application/octet-stream';
  }
}
