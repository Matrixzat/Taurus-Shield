import 'package:shared_preferences/shared_preferences.dart';

class SearchHistory {
  static const int _maxItems = 12;

  static const String keyAsmFind     = 'asm_find_history';
  static const String keyPatcher     = 'patcher_search_history';

  static Future<List<String>> load(String key) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getStringList(key) ?? [];
  }

  static Future<void> add(String key, String query) async {
    final q = query.trim();
    if (q.isEmpty) return;
    final prefs = await SharedPreferences.getInstance();
    final list = (prefs.getStringList(key) ?? [])
        .where((e) => e != q)
        .toList();
    list.insert(0, q);
    if (list.length > _maxItems) list.removeRange(_maxItems, list.length);
    await prefs.setStringList(key, list);
  }

  static Future<void> remove(String key, String query) async {
    final prefs = await SharedPreferences.getInstance();
    final list = (prefs.getStringList(key) ?? [])
        .where((e) => e != query)
        .toList();
    await prefs.setStringList(key, list);
  }
}
