import 'dart:io';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';

class StorageHelper {
  static const _storageChannel = MethodChannel('com.taurus.shield/storage');

  static const String appFolder = 'Taurus-Shield';

  /// Returns the root external storage path (/storage/emulated/0)
  static Future<String> getRootDir() async {
    final path = await _storageChannel.invokeMethod<String>('getRootDir');
    return path ?? '/storage/emulated/0';
  }

  /// Returns true if the app has full storage access
  static Future<bool> hasFullStorageAccess() async {
    if (Platform.isAndroid) {
      if (await _isAndroid11OrAbove()) {
        final granted = await _storageChannel.invokeMethod<bool>('hasManagePermission');
        return granted ?? false;
      } else {
        return await Permission.storage.isGranted;
      }
    }
    return true;
  }

  /// Requests full storage access — opens system settings on Android 11+
  static Future<void> requestFullStorageAccess() async {
    if (await _isAndroid11OrAbove()) {
      await _storageChannel.invokeMethod('openManagePermissionSettings');
    } else {
      await Permission.storage.request();
    }
  }

  /// Requests legacy storage permissions for Android < 11
  static Future<bool> requestLegacyPermission() async {
    final status = await Permission.storage.request();
    return status.isGranted;
  }

  /// Builds a timestamped output directory path under Taurus-Shield/output/
  static Future<String> buildOutputDir({required String prefix}) async {
    final root = await getRootDir();
    final ts   = DateTime.now().millisecondsSinceEpoch;
    final dir  = '$root/$appFolder/output/${prefix}_$ts';
    await _storageChannel.invokeMethod('ensureOutputDir', {'path': dir});
    return dir;
  }

  /// Ensures the Android ID spoof output directory exists and returns its path.
  static Future<String?> ensureSpoofDir() async {
    try {
      final root = await getRootDir();
      final dir  = '$root/$appFolder/android_spoof';
      final ok   = await _storageChannel.invokeMethod<bool>('ensureOutputDir', {'path': dir});
      return (ok == true) ? dir : null;
    } catch (_) {
      return null;
    }
  }

  static Future<bool> _isAndroid11OrAbove() async {
    try {
      // SDK_INT >= 30 means Android 11+
      final sdkInt = await _storageChannel.invokeMethod<int>('getSdkInt') ?? 30;
      return sdkInt >= 30;
    } catch (_) {
      return true; // safe default — assume we need MANAGE_EXTERNAL_STORAGE
    }
  }
}
