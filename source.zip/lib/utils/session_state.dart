import 'package:shared_preferences/shared_preferences.dart';

class SessionState {
  static const _kFilePath   = 'ss_file_path';
  static const _kFileName   = 'ss_file_name';
  static const _kMode       = 'ss_mode';
  static const _kLogs       = 'ss_logs';
  static const _kOutputDir  = 'ss_output_dir';
  static const _kWasRunning = 'ss_was_running';
  static const _kLastTool   = 'ss_last_tool';

  static Future<void> save({
    String? filePath,
    String? fileName,
    String? mode,
    String? logs,
    String? outputDir,
    bool isProcessing = false,
  }) async {
    final p = await SharedPreferences.getInstance();
    if (filePath != null) await p.setString(_kFilePath, filePath);
    if (fileName != null) await p.setString(_kFileName, fileName);
    if (mode != null) await p.setString(_kMode, mode);
    if (logs != null) await p.setString(_kLogs, logs);
    if (outputDir != null) {
      await p.setString(_kOutputDir, outputDir);
    } else {
      await p.remove(_kOutputDir);
    }
    await p.setBool(_kWasRunning, isProcessing);
  }

  static Future<Map<String, dynamic>> load() async {
    final p = await SharedPreferences.getInstance();
    return {
      'filePath':   p.getString(_kFilePath),
      'fileName':   p.getString(_kFileName),
      'mode':       p.getString(_kMode),
      'logs':       p.getString(_kLogs),
      'outputDir':  p.getString(_kOutputDir),
      'wasRunning': p.getBool(_kWasRunning) ?? false,
    };
  }

  static Future<void> clear() async {
    final p = await SharedPreferences.getInstance();
    for (final k in [_kFilePath, _kFileName, _kMode, _kLogs, _kOutputDir, _kWasRunning]) {
      await p.remove(k);
    }
  }

  static Future<void> saveLastTool(String tool) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_kLastTool, tool);
  }

  static Future<String?> loadLastTool() async {
    final p = await SharedPreferences.getInstance();
    return p.getString(_kLastTool);
  }

  static Future<void> clearLastTool() async {
    final p = await SharedPreferences.getInstance();
    await p.remove(_kLastTool);
  }
}
