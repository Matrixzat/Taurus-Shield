import 'dart:typed_data';
import 'package:flutter/services.dart';

class HbcChannel {
  static const _channel        = MethodChannel('com.taurus.shield/hbc');
  static const _storeChannel   = MethodChannel('com.taurus.shield/storage');
  static const _logChannel     = EventChannel('com.taurus.shield/log_stream');
  static const _logcatStream   = EventChannel('com.taurus.shield/logcat_stream');
  static const _crashStream    = EventChannel('com.taurus.shield/crash_stream');
  static const _logcatChannel  = MethodChannel('com.taurus.shield/logcat');

  static Stream<String> get logStream =>
      _logChannel.receiveBroadcastStream().map((e) => e.toString());

  static Stream<String>? _cachedLogcatStream;
  static Stream<String> get logcatStream =>
      _cachedLogcatStream ??=
          _logcatStream.receiveBroadcastStream().map((e) => e.toString());

  static Stream<String>? _cachedCrashStream;
  static Stream<String> get crashStream =>
      _cachedCrashStream ??=
          _crashStream.receiveBroadcastStream().map((e) => e.toString());

  static void invalidateLogcatStream() {
    _cachedLogcatStream = null;
  }

  static void invalidateCrashStream() {
    _cachedCrashStream = null;
  }

  // ── LogCat control ─────────────────────────────────────────────────────────
  // [useRoot] — when true, the LogcatService runs `logcat` itself through
  // `su -c`, bypassing the READ_LOGS permission. When `null` (the default),
  // the service preserves whatever mode was last set — so secondary call
  // sites (e.g. the recording tab) won't accidentally flip an active root
  // session back to non-root.
  static Future<void> logcatStart({bool? useRoot}) async =>
      _logcatChannel.invokeMethod(
          'logcat_start', useRoot == null ? const {} : {'useRoot': useRoot});

  static Future<void> logcatStop() async =>
      _logcatChannel.invokeMethod('logcat_stop');

  static Future<void> logcatClear({bool? useRoot}) async =>
      _logcatChannel.invokeMethod(
          'logcat_clear', useRoot == null ? const {} : {'useRoot': useRoot});

  static Future<void> logcatRestart({bool? useRoot}) async =>
      _logcatChannel.invokeMethod(
          'logcat_restart', useRoot == null ? const {} : {'useRoot': useRoot});

  static Future<String> logcatRevokePermission() async {
    final r = await _logcatChannel.invokeMethod<String>('logcat_revoke_permission');
    return r ?? 'failed';
  }

  static Future<bool> logcatCheckPermission() async {
    final r = await _logcatChannel.invokeMethod<bool>('logcat_check_permission');
    return r ?? false;
  }

  /// Returns true when an `su` binary is present on this device — this is a
  /// best-effort check (a binary may exist on a non-rooted phone), but it's
  /// the same heuristic used by every root-detection library on Android. If
  /// it returns true the UI should expose a "Grant via Root" option.
  static Future<bool> logcatCheckRoot() async {
    try {
      final r = await _logcatChannel.invokeMethod<bool>('logcat_check_root');
      return r ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Triggers the SuperUser/Magisk prompt and verifies root works by running
  /// `su -c "id -u"` and checking the output is `0`. Used by the Logcat
  /// screen so it can pass `useRoot: true` to subsequent start/clear/restart
  /// calls — root mode bypasses the READ_LOGS permission entirely. Returns
  /// one of: `granted`, `denied`, `no_su`, `failed`.
  static Future<String> logcatTestRoot() async {
    try {
      final r = await _logcatChannel.invokeMethod<String>('logcat_test_root');
      return r ?? 'failed';
    } catch (_) {
      return 'failed';
    }
  }

  static Future<String> logcatPairAdb({
    required String pairCode,
  }) async {
    final r = await _logcatChannel.invokeMethod<String>('logcat_pair_adb', {
      'pairCode': pairCode,
    });
    return r ?? '';
  }

  static Future<bool> logcatCheckOverlayPermission() async {
    final r = await _logcatChannel.invokeMethod<bool>('check_overlay_permission');
    return r ?? false;
  }

  static Future<void> logcatRequestOverlayPermission() async {
    await _logcatChannel.invokeMethod('request_overlay_permission');
  }

  static Future<void> logcatShowFloatingPair() async {
    await _logcatChannel.invokeMethod('show_floating_pair');
  }

  static Future<Map<String, bool>> logcatCheckAdbEnabled() async {
    final raw = await _logcatChannel.invokeMethod<Map>('logcat_check_adb_enabled');
    if (raw == null) return {'usbDebugging': false, 'wirelessDebugging': false};
    return {
      'usbDebugging': raw['usbDebugging'] as bool? ?? false,
      'wirelessDebugging': raw['wirelessDebugging'] as bool? ?? false,
    };
  }

  static Future<void> logcatOpenDeveloperOptions() async =>
      _logcatChannel.invokeMethod('open_developer_options');

  static Future<void> logcatOpenWirelessDebugging() async =>
      _logcatChannel.invokeMethod('open_wireless_debugging');

  static Future<String?> logcatGetAppLabel(String packageName) async {
    try {
      return await _logcatChannel.invokeMethod<String>(
          'logcat_get_app_label', {'packageName': packageName});
    } catch (_) { return null; }
  }

  static Future<bool> logcatCheckAfterShizuku() async {
    try {
      final r = await _logcatChannel.invokeMethod<bool>('logcat_check_after_shizuku');
      return r ?? false;
    } catch (_) { return false; }
  }

  /// Returns "granted", "permission_requested", "not_available", or "failed"
  static Future<String> logcatShizukuGrant() async {
    try {
      final r = await _logcatChannel.invokeMethod<String>('logcat_shizuku_grant');
      return r ?? 'failed';
    } catch (_) { return 'not_available'; }
  }

  static Future<bool> logcatGetAutostart() async {
    try {
      final r = await _logcatChannel.invokeMethod<bool>('logcat_get_autostart');
      return r ?? false;
    } catch (_) { return false; }
  }

  static Future<void> logcatSetAutostart(bool enabled) async {
    try {
      await _logcatChannel.invokeMethod('logcat_set_autostart', {'enabled': enabled});
    } catch (_) {}
  }

  static Future<bool> logcatCreateZipDocument({
    required String filename,
    String? content,
    String? sourcePath,
  }) async {
    try {
      final args = <String, dynamic>{'filename': filename};
      if (content    != null) args['content']    = content;
      if (sourcePath != null) args['sourcePath'] = sourcePath;
      final r = await _logcatChannel.invokeMethod<String>(
          'logcat_create_zip_document', args);
      return r != null;
    } catch (_) { return false; }
  }

  static Future<bool> logcatCreateDocument({
    required String filename,
    String? content,
    String? sourcePath,
  }) async {
    try {
      final args = <String, dynamic>{'filename': filename};
      if (content    != null) args['content']    = content;
      if (sourcePath != null) args['sourcePath'] = sourcePath;
      final r = await _logcatChannel.invokeMethod<String>(
          'logcat_create_document', args);
      return r != null; // null means user cancelled
    } catch (_) {
      return false;
    }
  }

  static Future<List<Map<String, dynamic>>> logcatGetInstalledApps() async {
    try {
      final raw = await _logcatChannel.invokeMethod<List>('logcat_get_installed_apps');
      return (raw ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    } catch (_) { return []; }
  }

  static Future<Uint8List?> logcatGetAppIcon(String packageName) async {
    try {
      final r = await _logcatChannel.invokeMethod<Uint8List>(
          'logcat_get_app_icon', {'packageName': packageName});
      return r;
    } catch (_) {
      return null;
    }
  }

  static Future<List<Map<String, dynamic>>> logcatGetCrashes() async {
    final raw = await _logcatChannel.invokeMethod<List>('logcat_get_crashes');
    return (raw ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  static Future<void> logcatDeleteCrash(String id) async =>
      _logcatChannel.invokeMethod('logcat_delete_crash', {'id': id});

  static Future<void> logcatClearAllCrashes() async =>
      _logcatChannel.invokeMethod('logcat_clear_all_crashes');

  static Future<void> logcatHardReset() async =>
      _logcatChannel.invokeMethod('logcat_hard_reset');

  static Future<Map<String, dynamic>> logcatRunAdb(String command) async {
    final raw = await _logcatChannel.invokeMethod<Map>(
        'logcat_run_adb', {'command': command});
    return Map<String, dynamic>.from(raw ?? {'output': '', 'exitCode': -1});
  }

  static Future<String?> logcatSaveRecording(List<String> lines) async =>
      _logcatChannel.invokeMethod<String>('logcat_save_recording', {'lines': lines});

  static Future<List<Map<String, dynamic>>> logcatGetRecordings() async {
    final raw = await _logcatChannel.invokeMethod<List>('logcat_get_recordings');
    return (raw ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  static Future<void> logcatDeleteRecording(String path) async =>
      _logcatChannel.invokeMethod('logcat_delete_recording', {'path': path});

  static Future<void> startProcessing({
    required String filePath,
    required String fileName,
    required String mode,
    required String outputDir,
  }) async {
    await _channel.invokeMethod('startProcessing', {
      'filePath': filePath,
      'fileName': fileName,
      'mode': mode,
      'outputDir': outputDir,
    });
  }

  static Future<Map<String, dynamic>> getProcessingState() async {
    final result = await _channel.invokeMapMethod<String, dynamic>(
      'getProcessingState',
    );
    return result ?? {'running': false};
  }

  static Future<Map<String, dynamic>> disassemble({
    required String hbcFilePath,
    required String outputDir,
  }) async {
    final result = await _channel.invokeMapMethod<String, dynamic>(
      'disassemble',
      {'hbcFilePath': hbcFilePath, 'outputDir': outputDir},
    );
    return result ?? {'status': 'error', 'log': 'No response from native layer'};
  }

  static Future<Map<String, dynamic>> assemble({
    required String hasmFilePath,
    required String outputDir,
  }) async {
    final result = await _channel.invokeMapMethod<String, dynamic>(
      'assemble',
      {'hasmFilePath': hasmFilePath, 'outputDir': outputDir},
    );
    return result ?? {'status': 'error', 'log': 'No response from native layer'};
  }

  static Future<Map<String, dynamic>> blutterAnalyze({
    required String filePath,
    required String fileName,
    required String outputDir,
    String? manualDartVersion,
  }) async {
    final args = <String, dynamic>{
      'filePath':  filePath,
      'fileName':  fileName,
      'outputDir': outputDir,
    };
    if (manualDartVersion != null && manualDartVersion.isNotEmpty) {
      args['manualDartVersion'] = manualDartVersion;
    }
    final result = await _channel.invokeMapMethod<String, dynamic>(
      'blutter_analyze',
      args,
    );
    return result ?? {'success': false, 'output': 'No response from native layer'};
  }

  static Future<Map<String, dynamic>> blutterCloudState() async {
    final result = await _channel.invokeMapMethod<String, dynamic>(
      'blutter_cloud_state',
    );
    return result ?? {'running': false};
  }

  static Future<void> blutterClearState() async {
    await _channel.invokeMethod('blutter_clear_state');
  }

  static Future<void> blutterCancel() async {
    await _channel.invokeMethod('blutter_cancel');
  }

  static Future<void> blutterSavePage(int pageIdx) async {
    try {
      await _channel.invokeMethod('blutter_save_page', {'pageIdx': pageIdx});
    } catch (_) {}
  }

  static Future<Map<String, dynamic>> dex2cAnalyze({
    required String filePath,
    required String fileName,
    required String outputDir,
    bool signApk = true,
  }) async {
    final result = await _channel.invokeMapMethod<String, dynamic>(
      'dex2c_analyze',
      {
        'filePath':  filePath,
        'fileName':  fileName,
        'outputDir': outputDir,
        'signApk':   signApk,
      },
    );
    return result ?? {'success': false, 'output': 'No response from native layer'};
  }

  static Future<Map<String, dynamic>> dex2cCloudState() async {
    final result = await _channel.invokeMapMethod<String, dynamic>(
      'dex2c_cloud_state',
    );
    return result ?? {'running': false};
  }

  static Future<void> dex2cClearState() async {
    await _channel.invokeMethod('dex2c_clear_state');
  }

  static Future<void> dex2cCancel() async {
    await _channel.invokeMethod('dex2c_cancel');
  }

  static Future<Map<String, dynamic>> dptShellAnalyze({
    required String filePath,
    required String fileName,
    required String outputDir,
    bool signApk = true,
  }) async {
    final result = await _channel.invokeMapMethod<String, dynamic>(
      'dptshell_analyze',
      {
        'filePath':  filePath,
        'fileName':  fileName,
        'outputDir': outputDir,
        'signApk':   signApk,
      },
    );
    return result ?? {'success': false, 'output': 'No response from native layer'};
  }

  static Future<Map<String, dynamic>> dptShellCloudState() async {
    final result = await _channel.invokeMapMethod<String, dynamic>(
      'dptshell_cloud_state',
    );
    return result ?? {'running': false};
  }

  static Future<void> dptShellClearState() async {
    await _channel.invokeMethod('dptshell_clear_state');
  }

  static Future<void> dptShellCancel() async {
    await _channel.invokeMethod('dptshell_cancel');
  }

  // ── Temp Host foreground service ────────────────────────────────────────────

  static Future<void> tempHostStartForeground() async {
    try { await _channel.invokeMethod('temphost_start_foreground'); } catch (_) {}
  }

  static Future<void> tempHostStopForeground() async {
    try { await _channel.invokeMethod('temphost_stop_foreground'); } catch (_) {}
  }

  // ── VM Protect (nmmp) ───────────────────────────────────────────────────────

  static Future<Map<String, dynamic>> vmProtectAnalyze({
    required String filePath,
    required String fileName,
    required String outputDir,
    bool signApk = true,
  }) async {
    final result = await _channel.invokeMapMethod<String, dynamic>(
      'vmProtect_analyze',
      {
        'filePath':  filePath,
        'fileName':  fileName,
        'outputDir': outputDir,
        'signApk':   signApk,
      },
    );
    return result ?? {'success': false, 'output': 'No response from native layer'};
  }

  static Future<Map<String, dynamic>> vmProtectCloudState() async {
    final result = await _channel.invokeMapMethod<String, dynamic>(
      'vmProtect_cloud_state',
    );
    return result ?? {'running': false};
  }

  static Future<void> vmProtectClearState() async {
    await _channel.invokeMethod('vmProtect_clear_state');
  }

  static Future<void> vmProtectCancel() async {
    await _channel.invokeMethod('vmProtect_cancel');
  }

  static Future<Map<String, dynamic>> apkToolAnalyze({
    required String filePath,
    required String fileName,
    required String outputDir,
    required String mode,
    bool signApk = false,
  }) async {
    final result = await _channel.invokeMapMethod<String, dynamic>(
      'apktool_analyze',
      {
        'filePath':  filePath,
        'fileName':  fileName,
        'outputDir': outputDir,
        'mode':      mode,
        'signApk':   signApk,
      },
    );
    return result ?? {'success': false, 'output': 'No response from native layer'};
  }

  static Future<Map<String, dynamic>> apkToolCloudState() async {
    final result = await _channel.invokeMapMethod<String, dynamic>(
      'apktool_cloud_state',
    );
    return result ?? {'running': false};
  }

  static Future<void> apkToolClearState() async {
    await _channel.invokeMethod('apktool_clear_state');
  }

  static Future<void> apkToolCancel() async {
    await _channel.invokeMethod('apktool_cancel');
  }

  static Future<Map<Object?, Object?>> invokeMethod(
      String method, Map<String, dynamic> args) async {
    final result =
        await _channel.invokeMapMethod<Object?, Object?>(method, args);
    return result ?? {};
  }

  static Future<Map<String, dynamic>> jsEncryptorAnalyze({
    required String filePath,
    required String fileName,
    required String outputDir,
    required String method,
    String? subzeroKey,
  }) async {
    final result = await _channel.invokeMapMethod<String, dynamic>(
      'jsEncryptor_analyze',
      {
        'filePath':    filePath,
        'fileName':    fileName,
        'outputDir':   outputDir,
        'method':      method,
        if (subzeroKey != null) 'subzeroKey': subzeroKey,
      },
    );
    return result ?? {'success': false, 'output': 'No response from native layer'};
  }

  static Future<Map<String, dynamic>> jsEncryptorState() async {
    final result = await _channel.invokeMapMethod<String, dynamic>(
      'jsEncryptor_state',
    );
    return result ?? {'running': false};
  }

  static Future<void> jsEncryptorClearState() async {
    await _channel.invokeMethod('jsEncryptor_clear_state');
  }

  static Future<void> jsEncryptorCancel() async {
    await _channel.invokeMethod('jsEncryptor_cancel');
  }

  static Future<void> jsEncryptorBatchAnalyze({
    required String zipPath,
    required String zipName,
    required String outputDir,
    required String tasksJson,
  }) async {
    await _channel.invokeMethod('jsEncryptor_batch_analyze', {
      'zipPath':   zipPath,
      'zipName':   zipName,
      'outputDir': outputDir,
      'tasksJson': tasksJson,
    });
  }

  static Future<Map<String, dynamic>> jsEncryptorBatchState() async {
    final result = await _channel.invokeMapMethod<String, dynamic>('jsEncryptor_batch_state');
    return result ?? {'running': false};
  }

  static Future<void> jsEncryptorBatchClearState() async {
    await _channel.invokeMethod('jsEncryptor_batch_clear_state');
  }

  static Future<void> jsEncryptorBatchCancel() async {
    await _channel.invokeMethod('jsEncryptor_batch_cancel');
  }

  static Future<void> phpAlomStart({
    required String zipPath,
    required String baseName,
    required int    depth,
    required String outputDir,
  }) async {
    await _channel.invokeMethod('phpAlom_start', {
      'zipPath':   zipPath,
      'baseName':  baseName,
      'depth':     depth,
      'outputDir': outputDir,
    });
  }

  static Future<Map<String, dynamic>> phpAlomState() async {
    final result = await _channel.invokeMapMethod<String, dynamic>('phpAlom_state');
    return result ?? {'running': false, 'status': 'idle'};
  }

  static Future<void> phpAlomClearState() async {
    await _channel.invokeMethod('phpAlom_clear_state');
  }

  static Future<void> phpAlomCancel() async {
    await _channel.invokeMethod('phpAlom_cancel');
  }

  static Future<Map<String, dynamic>> adsPatchAnalyze({
    required String filePath,
    required String fileName,
    required String outputDir,
    required String patchLevel,
    bool signApk = true,
  }) async {
    final result = await _channel.invokeMapMethod<String, dynamic>(
      'adsPatch_analyze',
      {
        'filePath':   filePath,
        'fileName':   fileName,
        'outputDir':  outputDir,
        'patchLevel': patchLevel,
        'signApk':    signApk,
      },
    );
    return result ?? {'success': false, 'output': 'No response from native layer'};
  }

  static Future<Map<String, dynamic>> adsPatchCloudState() async {
    final result = await _channel.invokeMapMethod<String, dynamic>(
      'adsPatch_cloud_state',
    );
    return result ?? {'running': false};
  }

  static Future<void> adsPatchClearState() async {
    await _channel.invokeMethod('adsPatch_clear_state');
  }

  static Future<void> adsPatchCancel() async {
    await _channel.invokeMethod('adsPatch_cancel');
  }

  // ── ReFlutter ───────────────────────────────────────────────────────────────

  static Future<Map<String, dynamic>> reflutterAnalyze({
    required String filePath,
    required String fileName,
    required String outputDir,
  }) async {
    final result = await _channel.invokeMapMethod<String, dynamic>(
      'reflutter_analyze',
      {
        'filePath':  filePath,
        'fileName':  fileName,
        'outputDir': outputDir,
      },
    );
    return result ?? {'success': false, 'output': 'No response from native layer'};
  }

  static Future<Map<String, dynamic>> reflutterCloudState() async {
    final result = await _channel.invokeMapMethod<String, dynamic>(
      'reflutter_cloud_state',
    );
    return result ?? {'running': false};
  }

  static Future<void> reflutterClearState() async {
    await _channel.invokeMethod('reflutter_clear_state');
  }

  static Future<void> reflutterCancel() async {
    await _channel.invokeMethod('reflutter_cancel');
  }

  // ── Pine Hook Injector ──────────────────────────────────────────────────────

  static Future<Map<String, dynamic>> pineHookInject({
    required String filePath,
    required String fileName,
    required String outputDir,
    String modulesJson = '[]',
  }) async {
    final result = await _channel.invokeMapMethod<String, dynamic>(
      'pineHook_analyze',
      {
        'filePath':    filePath,
        'fileName':    fileName,
        'outputDir':   outputDir,
        'modulesJson': modulesJson,
      },
    );
    return result ?? {'success': false, 'error': 'No response from native layer'};
  }

  static Future<Map<String, dynamic>> pineHookState() async {
    final result = await _channel.invokeMapMethod<String, dynamic>(
      'pineHook_state',
    );
    return result ?? {'running': false};
  }

  static Future<void> pineHookClearState() async {
    await _channel.invokeMethod('pineHook_clear_state');
  }

  static Future<void> pineHookCancel() async {
    await _channel.invokeMethod('pineHook_cancel');
  }

  // ── SSL Unpinner ────────────────────────────────────────────────────────────

  static Future<Map<String, dynamic>> sslUnpinAnalyze({
    required String filePath,
    required String fileName,
    required String outputDir,
    bool signApk = true,
  }) async {
    final result = await _channel.invokeMapMethod<String, dynamic>(
      'sslUnpin_analyze',
      {
        'filePath':  filePath,
        'fileName':  fileName,
        'outputDir': outputDir,
        'signApk':   signApk,
      },
    );
    return result ?? {'success': false, 'error': 'No response from native layer'};
  }

  static Future<Map<String, dynamic>> sslUnpinState() async {
    final result = await _channel.invokeMapMethod<String, dynamic>(
      'sslUnpin_state',
    );
    return result ?? {'running': false};
  }

  static Future<void> sslUnpinClearState() async {
    await _channel.invokeMethod('sslUnpin_clear_state');
  }

  static Future<void> sslUnpinCancel() async {
    await _channel.invokeMethod('sslUnpin_cancel');
  }

  static Future<Map<String, dynamic>> antiKillerAnalyze({
    required String filePath,
    required String fileName,
    required String outputDir,
    String mainActivity = '',
  }) async {
    final result = await _channel.invokeMapMethod<String, dynamic>(
      'antiKiller_analyze',
      {
        'filePath':     filePath,
        'fileName':     fileName,
        'outputDir':    outputDir,
        'mainActivity': mainActivity,
      },
    );
    return result ?? {'success': false, 'output': 'No response from native layer'};
  }

  static Future<Map<String, dynamic>> antiKillerCloudState() async {
    final result = await _channel.invokeMapMethod<String, dynamic>(
      'antiKiller_cloud_state',
    );
    return result ?? {'running': false};
  }

  static Future<void> antiKillerClearState() async {
    await _channel.invokeMethod('antiKiller_clear_state');
  }

  static Future<void> antiKillerCancel() async {
    await _channel.invokeMethod('antiKiller_cancel');
  }

  // ── libapp.so patcher (STORE_CHANNEL) ─────────────────────────────────────

  /// Parses Blutter asm/ files into function blocks grouped by file.
  /// Returns [{fileName, matchCount, blocks:[{funcName, offset, value,
  ///          headerText, contextText}]}]
  static Future<List<Map<String, dynamic>>> soScanDump({
    required String dumpFolder,
    required String keyword,
  }) async {
    final raw = await _storeChannel.invokeMethod<List<dynamic>>(
      'so_scan_dump',
      {'dumpFolder': dumpFolder, 'keyword': keyword},
    );
    if (raw == null) return [];
    return raw.map((e) {
      final m = Map<String, dynamic>.from(e as Map);
      if (m['blocks'] is List) {
        m['blocks'] = (m['blocks'] as List)
            .map((b) => Map<String, dynamic>.from(b as Map))
            .toList();
      }
      return m;
    }).toList();
  }

  /// ARM64 instruction-level boolean toggle on libapp.so.
  /// patches: [{offset:"hex", toggleTo:"true"|"false"}]
  static Future<Map<String, dynamic>> soApplyBoolPatches({
    required String soPath,
    required List<Map<String, String>> patches,
  }) async {
    final raw = await _storeChannel.invokeMapMethod<String, dynamic>(
      'so_apply_bool_patches',
      {'soPath': soPath, 'patches': patches},
    );
    return raw ?? {};
  }

  static Future<String?> soCopyLib({
    required String zipPath,
    required String outputDir,
  }) async {
    return _storeChannel.invokeMethod<String>(
      'so_copy_lib',
      {'zipPath': zipPath, 'outputDir': outputDir},
    );
  }

  static Future<List<Map<String, dynamic>>> soSearch({
    required String soPath,
    required String query,
  }) async {
    final raw = await _storeChannel.invokeMethod<List<dynamic>>(
      'so_search',
      {'soPath': soPath, 'query': query},
    );
    return (raw ?? [])
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList();
  }

  static Future<String?> soApplyPatches({
    required String soPath,
    required List<Map<String, dynamic>> patches,
  }) async {
    return _storeChannel.invokeMethod<String>(
      'so_apply_patches',
      {'soPath': soPath, 'patches': patches},
    );
  }

  /// FlutterMod-identical Quick String Patcher.
  /// Searches libapp.so for [oldStr] bytes, patches in-place with [newStr]
  /// (zero-padded to original field width).
  /// Throws PlatformException with PATCH_ERROR code on failure
  /// (NOT FOUND, TOO LONG, MULTIPLE MATCHES, etc.).
  static Future<Map<String, dynamic>> soPatchString({
    required String soPath,
    required String oldStr,
    required String newStr,
    bool patchAll = false,
    List<int>? offsets,
  }) async {
    final args = <String, dynamic>{
      'soPath': soPath, 'oldStr': oldStr, 'newStr': newStr,
      'patchAll': patchAll,
      if (offsets != null) 'offsets': offsets,
    };
    final raw = await _storeChannel.invokeMapMethod<String, dynamic>(
      'so_patch_string', args,
    );
    return raw ?? {};
  }

  /// Integer Patcher — searches libapp.so for a 32-bit or 64-bit little-endian
  /// integer constant and patches it in-place.
  /// bits: 32 or 64.  oldVal/newVal passed as strings to avoid overflow.
  static Future<Map<String, dynamic>> soPatchInt({
    required String soPath,
    required String oldVal,
    required String newVal,
    int bits = 32,
    List<int>? offsets,
  }) async {
    final args = <String, dynamic>{
      'soPath': soPath,
      'oldVal': oldVal,
      'newVal': newVal,
      'bits': bits,
      if (offsets != null) 'offsets': offsets,
    };
    final raw = await _storeChannel.invokeMapMethod<String, dynamic>(
      'so_patch_int', args,
    );
    return raw ?? {};
  }

  // ── ASM Editor bindings ────────────────────────────────────────────────────

  static Future<String?> asmInitEdit({required String outputDir}) async {
    return _storeChannel.invokeMethod<String>('asm_init_edit', {'outputDir': outputDir});
  }

  static Future<List<Map<String, dynamic>>> asmListDir({required String dir}) async {
    final raw = await _storeChannel.invokeMethod<List<dynamic>>('asm_list_dir', {'dir': dir});
    return (raw ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  static Future<String?> asmReadFile({required String path}) async {
    return _storeChannel.invokeMethod<String>('asm_read_file', {'path': path});
  }

  static Future<Map<String, dynamic>> asmSaveAndPatch({
    required String editPath,
    required String soPath,
    required List<String> origLines,
    required List<String> newLines,
  }) async {
    final raw = await _storeChannel.invokeMapMethod<String, dynamic>(
      'asm_save_and_patch',
      {'editPath': editPath, 'soPath': soPath, 'origLines': origLines, 'newLines': newLines},
    );
    return raw ?? {};
  }

  static Future<String?> asmRevertFile({
    required String editPath,
    required String origPath,
  }) async {
    return _storeChannel.invokeMethod<String>(
      'asm_revert_file',
      {'editPath': editPath, 'origPath': origPath},
    );
  }

  static Future<List<Map<String, dynamic>>> asmSearchAll({
    required String rootDir,
    required String keyword,
  }) async {
    final raw = await _storeChannel.invokeMethod<List<dynamic>>(
      'asm_search_all',
      {'rootDir': rootDir, 'keyword': keyword},
    );
    return (raw ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  // ── DEX Tools — on-device conversion ─────────────────────────────────────
  static const _dexToolsChannel = MethodChannel('com.taurus.shield/dex_tools');

  static Future<Map<String, dynamic>> dexToolsSetup() async {
    final raw = await _dexToolsChannel.invokeMapMethod<String, dynamic>('setup', {});
    return raw ?? {};
  }

  static Future<Map<String, dynamic>> dexToolsRun({
    required String tool,
    required String filePath,
    required String outputDir,
  }) async {
    final raw = await _dexToolsChannel.invokeMapMethod<String, dynamic>(
      'run',
      {'tool': tool, 'filePath': filePath, 'outputDir': outputDir},
    );
    return raw ?? {};
  }

  static Future<Map<String, dynamic>> apksExtractBase({
    required String apksPath,
    required String outputDir,
  }) async {
    final raw = await _channel.invokeMapMethod<String, dynamic>(
      'apks_extract_base',
      {'apksPath': apksPath, 'outputDir': outputDir},
    );
    return raw ?? {};
  }

  static Future<Map<String, dynamic>> apksMergeUniversal({
    required String apksPath,
    required String outputDir,
  }) async {
    final raw = await _channel.invokeMapMethod<String, dynamic>(
      'apks_merge_universal',
      {'apksPath': apksPath, 'outputDir': outputDir},
    );
    return raw ?? {};
  }

  static Future<Map<String, dynamic>> apkToAab({
    required String apkPath,
    required String outputDir,
  }) async {
    final raw = await _channel.invokeMapMethod<String, dynamic>(
      'apk_to_aab',
      {'apkPath': apkPath, 'outputDir': outputDir},
    );
    return raw ?? {};
  }

  static Future<Map<String, dynamic>> aabToApk({
    required String aabPath,
    required String outputDir,
  }) async {
    final raw = await _channel.invokeMapMethod<String, dynamic>(
      'aab_to_apk',
      {'aabPath': aabPath, 'outputDir': outputDir},
    );
    return raw ?? {};
  }

}
