import 'theme_provider.dart';
import 'package:flutter/material.dart';
import 'storage_helper.dart';

/// Central permission manager for Taurus Shield.
///
/// Usage:
///   – App startup  : PermissionHelper.checkStartup(context)
///   – Before a run : await PermissionHelper.ensureStorage(context, accent: color)
///
/// Adding a new tool in the future? Just call ensureStorage() — nothing else needed.
class PermissionHelper {
  PermissionHelper._();

  // ── Startup check ──────────────────────────────────────────────────────────
  /// Shows a unified permission dialog the first time the app opens (if not
  /// already granted). If the OS says permission is already granted this
  /// returns immediately without showing anything.
  static Future<void> checkStartup(BuildContext context) async {
    final hasAccess = await StorageHelper.hasFullStorageAccess();
    if (hasAccess || !context.mounted) return;

    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const _StartupPermissionDialog(),
    );
  }

  // ── Per-tool fallback ──────────────────────────────────────────────────────
  /// Checks storage permission before a tool run.
  /// • Already granted  → returns true immediately, no dialog shown.
  /// • Not granted      → shows a tool-coloured dialog, requests permission,
  ///                       returns true/false based on what the user did.
  ///
  /// [accent] should be the tool's primary colour so the dialog feels native
  /// to the screen the user is on.
  static Future<bool> ensureStorage(
    BuildContext context, {
    Color accent = const Color(0xFF7c3aed),
  }) async {
    final hasAccess = await StorageHelper.hasFullStorageAccess();
    if (hasAccess) return true;
    if (!context.mounted) return false;

    final confirmed = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => _ToolPermissionDialog(accent: accent),
    );

    if (confirmed == true) {
      await StorageHelper.requestFullStorageAccess();
      await Future.delayed(const Duration(milliseconds: 800));
      return await StorageHelper.hasFullStorageAccess();
    }
    return false;
  }
}

// ── Startup dialog — shown once on app open if permission not yet granted ──────

class _StartupPermissionDialog extends StatelessWidget {
  const _StartupPermissionDialog();

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 40),
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF0f0f22),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: const Color(0xFF7c3aed).withOpacity(0.6),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF7c3aed).withOpacity(0.15),
              blurRadius: 32,
              spreadRadius: 2,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // ── Top accent bar
            Container(
              height: 4,
              decoration: const BoxDecoration(
                borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
                gradient: LinearGradient(
                  colors: [
                    Color(0xFF7c3aed),
                    Color(0xFF22d3ee),
                    Color(0xFF10b981),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(22, 22, 22, 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ── Icon + title
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: const Color(0xFF7c3aed).withOpacity(0.12),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                              color: const Color(0xFF7c3aed).withOpacity(0.35)),
                        ),
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            const Icon(Icons.folder_rounded,
                                color: Color(0xFF7c3aed), size: 28),
                            Positioned(
                              right: 0,
                              bottom: 0,
                              child: Container(
                                padding: const EdgeInsets.all(2),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF0f0f22),
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                      color: const Color(0xFF7c3aed)
                                          .withOpacity(0.4)),
                                ),
                                child: const Icon(Icons.lock_rounded,
                                    color: Color(0xFF9d5cf6), size: 10),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 14),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'All Files Access',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 0.3,
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              'Required to save tool output',
                              style: TextStyle(
                                color: Color(0xFF6b7280),
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),

                  // ── Explanation
                  Container(
                    padding: const EdgeInsets.all(13),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0a0a18),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                          color: const Color(0xFF1e1e3a)),
                    ),
                    child: const Text(
                      'Taurus Shield saves all results directly to your device storage. Grant this once and every tool works without interruption.',
                      style: TextStyle(
                        color: Color(0xFFa0aec0),
                        fontSize: 12.5,
                        height: 1.6,
                      ),
                    ),
                  ),

                  const SizedBox(height: 14),

                  // ── What each tool saves
                  const Text(
                    'WHAT GETS SAVED',
                    style: TextStyle(
                      color: Color(0xFF4b3a6e),
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.2,
                    ),
                  ),
                  const SizedBox(height: 8),
                  _ToolRow(
                    icon: Icons.memory_rounded,
                    color: Color(0xFF7c3aed),
                    label: 'HBC Tool',
                    detail: '.hasm disassembly & rebuilt .hbc files',
                  ),
                  const SizedBox(height: 6),
                  _ToolRow(
                    icon: Icons.flutter_dash_rounded,
                    color: Color(0xFF22d3ee),
                    label: 'Blutter',
                    detail: 'Dart symbols, class dumps & ARM64 code',
                  ),
                  const SizedBox(height: 6),
                  _ToolRow(
                    icon: Icons.enhanced_encryption_rounded,
                    color: Color(0xFF10b981),
                    label: 'Dex2C',
                    detail: 'Protected APKs ready to install',
                  ),

                  const SizedBox(height: 20),

                  // ── Buttons
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF7c3aed),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                        elevation: 0,
                      ),
                      onPressed: () async {
                        Navigator.pop(context);
                        await StorageHelper.requestFullStorageAccess();
                      },
                      icon: const Icon(Icons.lock_open_rounded, size: 18),
                      label: const Text(
                        'Grant Access',
                        style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 15,
                            letterSpacing: 0.4),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    child: TextButton(
                      onPressed: () => Navigator.pop(context),
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                      child: const Text(
                        'Skip for Now',
                        style: TextStyle(
                          color: Color(0xFF4b5563),
                          fontSize: 13,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ToolRow extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String label;
  final String detail;

  const _ToolRow({
    required this.icon,
    required this.color,
    required this.label,
    required this.detail,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(5),
          decoration: BoxDecoration(
            color: color.withOpacity(0.10),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: color.withOpacity(0.25)),
          ),
          child: Icon(icon, color: color, size: 14),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: RichText(
            text: TextSpan(
              children: [
                TextSpan(
                  text: '$label  ',
                  style: TextStyle(
                    color: color,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                TextSpan(
                  text: detail,
                  style: const TextStyle(
                    color: Color(0xFF6b7280),
                    fontSize: 11.5,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

// ── Per-tool fallback dialog ───────────────────────────────────────────────────

class _ToolPermissionDialog extends StatelessWidget {
  final Color accent;
  const _ToolPermissionDialog({required this.accent});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: const Color(0xFF12121e),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: BorderSide(color: accent, width: 1),
      ),
      title: Row(children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: accent.withOpacity(0.15),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(Icons.folder_open_rounded, color: accent, size: 22),
        ),
        const SizedBox(width: 12),
        const Expanded(
          child: Text(
            'Storage Access Required',
            style: TextStyle(
                color: Colors.white,
                fontSize: 15,
                fontWeight: FontWeight.w700),
          ),
        ),
      ]),
      content: const Text(
        'This app needs All Files Access to save output files to the Taurus-Shield folder on your device.\n\nPlease grant this permission on the next screen.',
        style: TextStyle(
            color: Color(0xFFa0a0b8), fontSize: 13, height: 1.6),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, false),
          child: const Text('Cancel',
              style: TextStyle(color: Color(0xFF6b7280))),
        ),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: accent,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10)),
            elevation: 0,
          ),
          onPressed: () => Navigator.pop(context, true),
          child: const Text('Grant Access',
              style: TextStyle(fontWeight: FontWeight.w700)),
        ),
      ],
    );
  }
}
