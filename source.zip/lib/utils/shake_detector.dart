import 'dart:async';
import 'dart:math';
import 'package:sensors_plus/sensors_plus.dart';
import 'theme_provider.dart';

class ShakeDetector {
  static final ShakeDetector _instance = ShakeDetector._();
  factory ShakeDetector() => _instance;
  ShakeDetector._();

  StreamSubscription<AccelerometerEvent>? _sub;
  DateTime _lastShake = DateTime(2000);
  bool _ready = false;
  static const _shakeThreshold = 15.0;
  static const _cooldown = Duration(milliseconds: 1200);
  static const _warmup = Duration(milliseconds: 800);

  void start() {
    _sub?.cancel();
    _ready = false;
    _sub = accelerometerEventStream(
      samplingPeriod: const Duration(milliseconds: 80),
    ).listen(_onEvent);
    Future.delayed(_warmup, () => _ready = true);
  }

  void stop() {
    _sub?.cancel();
    _sub = null;
    _ready = false;
  }

  void _onEvent(AccelerometerEvent e) {
    if (!_ready) return;
    final magnitude = sqrt(e.x * e.x + e.y * e.y + e.z * e.z);
    if (magnitude > _shakeThreshold) {
      final now = DateTime.now();
      if (now.difference(_lastShake) > _cooldown) {
        _lastShake = now;
        _cycleTheme();
      }
    }
  }

  void _cycleTheme() {
    final provider = ThemeProvider();
    final themes = ThemeProvider.allThemes;
    final currentIndex = themes.indexWhere((t) => t.id == provider.currentId);
    final nextIndex = (currentIndex + 1) % themes.length;
    provider.setTheme(themes[nextIndex].id);
  }
}
