import 'package:flutter/services.dart';

/// Dart-side wrapper for the native notification MethodChannel.
/// All notification work runs on the Kotlin side so it works even when the
/// app is in the background.
class NotificationHelper {
  static const _ch = MethodChannel('com.taurus.shield/notification');

  /// Request POST_NOTIFICATIONS permission on Android 13+.
  /// Returns true if granted (or not needed on older Android).
  static Future<bool> requestPermission() async {
    try {
      final granted = await _ch.invokeMethod<bool>('requestPermission');
      return granted ?? true;
    } on PlatformException {
      return true;
    }
  }

  /// Show a persistent (non-dismissable) notification while processing.
  static Future<void> showProcessing({
    required String title,
    required String body,
  }) async {
    try {
      await _ch.invokeMethod('showProcessing', {'title': title, 'body': body});
    } on PlatformException {
      // Best-effort — don't block processing if notifications fail
    }
  }

  /// Replace the processing notification with a final success/failure result.
  static Future<void> showResult({
    required bool success,
    required String title,
    required String body,
  }) async {
    try {
      await _ch.invokeMethod('showResult', {
        'success': success,
        'title': title,
        'body': body,
      });
    } on PlatformException {
      // Best-effort
    }
  }

  /// Cancel the ongoing processing notification (e.g. on error before result).
  static Future<void> cancelProcessing() async {
    try {
      await _ch.invokeMethod('cancelProcessing');
    } on PlatformException {
      // Best-effort
    }
  }
}
