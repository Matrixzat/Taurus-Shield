// ── Changelog entries ──────────────────────────────────────────────────────────
//
// HOW TO UPDATE:
//  1. Bump the version in pubspec.yaml  (e.g.  1.1.0+2)
//  2. Prepend a new ChangelogEntry at the TOP of kChangelog below.
//  3. Set version: 'current' on the newest entry — the app reads the real
//     version string from pubspec.yaml automatically at runtime.
//  4. All older entries keep their explicit version strings as history.
//
// Tags:
//   added    → new feature or screen
//   improved → enhancement to existing behaviour
//   fixed    → bug fix
//   removed  → something taken out

class ChangelogEntry {
  final String version; // use 'current' for the latest entry
  final String date;
  final List<ChangelogItem> items;
  const ChangelogEntry({
    required this.version,
    required this.date,
    required this.items,
  });
}

class ChangelogItem {
  final ChangelogTag tag;
  final String text;
  const ChangelogItem({required this.tag, required this.text});
}

enum ChangelogTag { added, improved, fixed, removed }

// ── Add new versions at the TOP — set version: 'current' on the newest ────────

const List<ChangelogEntry> kChangelog = [
  ChangelogEntry(
    version: 'current', // ← always keep 'current' on the newest entry
    date: 'March 2026',
    items: [
      ChangelogItem(tag: ChangelogTag.added,    text: 'Initial release of Taurus Shield'),
      ChangelogItem(tag: ChangelogTag.added,    text: 'Hermes bytecode disassembler (DSM)'),
      ChangelogItem(tag: ChangelogTag.added,    text: 'Hermes bytecode assembler (ASM)'),
      ChangelogItem(tag: ChangelogTag.added,    text: 'ZIP folder assembly support'),
      ChangelogItem(tag: ChangelogTag.added,    text: 'Auto file-type detection on import'),
      ChangelogItem(tag: ChangelogTag.added,    text: 'Local processing — no internet required'),
      ChangelogItem(tag: ChangelogTag.added,    text: 'Real-time processing log panel'),
      ChangelogItem(tag: ChangelogTag.added,    text: 'Output saved to /Taurus-Shield/output/'),
      ChangelogItem(tag: ChangelogTag.added,    text: 'Animated header with orbit ring effects'),
      ChangelogItem(tag: ChangelogTag.added,    text: 'How to Use guide built into the app'),
      ChangelogItem(tag: ChangelogTag.added,    text: 'Community links (Telegram & WhatsApp)'),
    ],
  ),
];
