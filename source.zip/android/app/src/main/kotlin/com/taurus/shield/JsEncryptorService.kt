package com.taurus.shield

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.IBinder
import android.os.PowerManager
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.Executors
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class JsEncryptorService : Service() {

    companion object {
        private const val PREFS       = "jsenc_state"
        private const val K_RUNNING   = "running"
        private const val K_STATUS    = "status"
        private const val K_LOG       = "log"
        private const val K_OUT_DIR   = "outputDir"
        private const val K_OUT_FILE  = "outputFile"
        private const val K_SUCCESS   = "success"
        private const val K_METHOD    = "method"
        private const val K_FILE_NAME = "fileName"
        private const val BATCH_PREFS = "jsenc_batch_state"
        private const val NOTIF_ID    = 2800

        fun isRunning(ctx: Context): Boolean =
            prefs(ctx).getBoolean(K_RUNNING, false) || batchPrefs(ctx).getBoolean(K_RUNNING, false)

        fun isBatchRunning(ctx: Context): Boolean =
            batchPrefs(ctx).getBoolean(K_RUNNING, false)

        fun getBatchState(ctx: Context): Map<String, Any?> {
            val p = batchPrefs(ctx)
            return mapOf(
                "running"    to p.getBoolean(K_RUNNING, false),
                "status"     to p.getString(K_STATUS, "idle"),
                "log"        to p.getString(K_LOG, ""),
                "outputDir"  to p.getString(K_OUT_DIR, null),
                "outputFile" to p.getString(K_OUT_FILE, null),
                "success"    to p.getBoolean(K_SUCCESS, false),
            )
        }

        fun clearBatchState(ctx: Context) { batchPrefs(ctx).edit().clear().apply() }

        fun getState(ctx: Context): Map<String, Any?> {
            val p = prefs(ctx)
            return mapOf(
                "running"    to p.getBoolean(K_RUNNING, false),
                "status"     to p.getString(K_STATUS, "idle"),
                "log"        to p.getString(K_LOG, ""),
                "outputDir"  to p.getString(K_OUT_DIR, null),
                "outputFile" to p.getString(K_OUT_FILE, null),
                "success"    to p.getBoolean(K_SUCCESS, false),
                "method"     to p.getString(K_METHOD, null),
                "fileName"   to p.getString(K_FILE_NAME, null),
            )
        }

        fun clearState(ctx: Context) {
            prefs(ctx).edit().clear().apply()
        }

        fun cancel(ctx: Context) {
            ctx.stopService(Intent(ctx, JsEncryptorService::class.java))
        }

        private fun prefs(ctx: Context): SharedPreferences =
            ctx.getSharedPreferences(PREFS, MODE_PRIVATE)

        private fun batchPrefs(ctx: Context): SharedPreferences =
            ctx.getSharedPreferences(BATCH_PREFS, MODE_PRIVATE)
    }

    private val executor = Executors.newSingleThreadExecutor()
    private var wakeLock: PowerManager.WakeLock? = null
    private var engine: WebViewJsEngine? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val mode      = intent?.getStringExtra("mode")      ?: "single"
        val outputDir = intent?.getStringExtra("outputDir") ?: return START_NOT_STICKY

        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "TaurusShield:JsEnc")
        wakeLock?.acquire(60 * 60 * 1000L)

        NotificationHelper.createChannels(this)
        engine = WebViewJsEngine(applicationContext)

        if (mode == "batch") {
            val zipPath   = intent.getStringExtra("zipPath")   ?: return START_NOT_STICKY
            val zipName   = intent.getStringExtra("zipName")   ?: zipPath.substringAfterLast('/')
            val tasksJson = intent.getStringExtra("tasksJson") ?: "[]"

            startForeground(NOTIF_ID, NotificationHelper.buildProcessingNotif(
                this, "JS Encryptor", "Batch encrypting…"))

            val p = getSharedPreferences(BATCH_PREFS, MODE_PRIVATE)
            p.edit()
                .putBoolean(K_RUNNING, true)
                .putString(K_STATUS,  "running")
                .putString(K_LOG,     "")
                .putString(K_OUT_DIR, outputDir)
                .remove(K_OUT_FILE)
                .putBoolean(K_SUCCESS, false)
                .apply()

            executor.execute { doBatchWork(zipPath, zipName, tasksJson, outputDir, p) }

        } else {
            val filePath   = intent.getStringExtra("filePath")   ?: return START_NOT_STICKY
            val fileName   = intent.getStringExtra("fileName")   ?: filePath.substringAfterLast('/')
            val method     = intent.getStringExtra("method")     ?: "encmatrix"
            val subzeroKey = intent.getStringExtra("subzeroKey") ?: ""

            startForeground(NOTIF_ID, NotificationHelper.buildProcessingNotif(
                this, "JS Encryptor", "Preparing engine…"))

            val p = getSharedPreferences(PREFS, MODE_PRIVATE)
            p.edit()
                .putBoolean(K_RUNNING,   true)
                .putString(K_STATUS,     "running")
                .putString(K_LOG,        "")
                .putString(K_METHOD,     method)
                .putString(K_FILE_NAME,  fileName)
                .putString(K_OUT_DIR,    outputDir)
                .remove(K_OUT_FILE)
                .putBoolean(K_SUCCESS,   false)
                .apply()

            executor.execute { doWork(filePath, fileName, outputDir, method, subzeroKey, p) }
        }
        return START_NOT_STICKY
    }

    private fun appendLog(p: SharedPreferences, line: String) {
        val cur = p.getString(K_LOG, "") ?: ""
        p.edit().putString(K_LOG, if (cur.isEmpty()) line else "$cur\n$line").apply()
    }

    private fun doWork(filePath: String, fileName: String, outputDir: String, method: String, szKey: String, p: SharedPreferences) {
        fun log(msg: String) {
            appendLog(p, msg)
        }

        try {
            log("[*] Engine initializing…")
            val eng = engine ?: throw RuntimeException("Engine not initialized")

            val outDir = File(outputDir).also { it.mkdirs() }
            val inputFile = File(filePath)
            val isZip = filePath.endsWith(".zip", ignoreCase = true)
            val isHtml = filePath.endsWith(".html", ignoreCase = true) || filePath.endsWith(".htm", ignoreCase = true)
            val isDecrypt = method == "decrypt"
            val isSubZero = method == "subzero"

            log("[*] Method: ${method.uppercase()}")
            log("[*] File:   $fileName")

            if (isZip) {
                log("[*] ZIP detected — processing all matching files…")
                processZip(inputFile, outDir, method, isDecrypt, isSubZero, szKey, eng, p, ::log, fileName)
            } else {
                val code = inputFile.readText(Charsets.UTF_8)
                log("[*] Read ${code.length} chars from input")

                val result = when {
                    isDecrypt -> { log("[*] Decrypting with webcrack…"); eng.decrypt(code) }
                    isSubZero -> { log("[*] Applying SubZero HTML encryption…"); eng.subzero(code, szKey) }
                    else -> { log("[*] Encrypting…"); eng.encrypt(code, method) }
                }

                val ext = when {
                    isDecrypt || isHtml -> fileName.substringAfterLast('.').let { ".$it" }
                    else -> ".enc.js"
                }
                val baseName = fileName.substringBeforeLast('.')
                val suffix   = if (isDecrypt) ".dec.js" else if (isSubZero) ".szero${ext}" else ".enc.js"
                val outName  = "$baseName$suffix"
                val outFile  = File(outDir, outName)
                outFile.writeText(result, Charsets.UTF_8)

                log("[+] Done! Output: $outName")
                log("[+] Size: ${result.length} chars")

                p.edit()
                    .putBoolean(K_SUCCESS, true)
                    .putString(K_OUT_FILE, outFile.absolutePath)
                    .apply()
            }

            p.edit()
                .putBoolean(K_RUNNING, false)
                .putString(K_STATUS, "done")
                .apply()

            NotificationHelper.showResult(this, true, "JS Encryptor",
                "Encryption complete — check output folder")

        } catch (e: Exception) {
            log("[!] Error: ${e.message}")
            p.edit()
                .putBoolean(K_RUNNING, false)
                .putString(K_STATUS, "error")
                .putBoolean(K_SUCCESS, false)
                .apply()
            NotificationHelper.showResult(this, false, "JS Encryptor",
                "Failed: ${e.message}")
        } finally {
            wakeLock?.release()
            stopSelf()
        }
    }

    private val methodLabels = mapOf(
        "encmatrix"    to "Matrix",    "encultra"    to "Ultra",    "encarab"   to "Arab",
        "encjapxab"   to "JapxArab",  "enchector"   to "Hector",  "encinvisible" to "Invisible",
        "encstealth"  to "Stealth",   "dracula"     to "Dracula", "encchina"  to "China",
        "encquantum"  to "Quantum",   "encnova"     to "Nova",    "encvampire" to "Vampire",
        "encjapan"    to "Japan",     "encfatality" to "Fatality","immortal"  to "Immortal",
        "subzero"     to "SubZero",   "decrypt"     to "Decrypt"
    )

    private fun doBatchWork(
        zipPath: String,
        zipName: String,
        tasksJson: String,
        outputDir: String,
        p: SharedPreferences
    ) {
        fun log(msg: String) = appendLog(p, msg)
        try {
            val arr     = org.json.JSONArray(tasksJson)
            val taskMap = mutableMapOf<String, Pair<String, String>>()
            for (i in 0 until arr.length()) {
                val t = arr.getJSONObject(i)
                taskMap[t.getString("path")] = t.getString("method") to t.optString("szKey", "")
            }

            log("[*] Batch — ${taskMap.size} file(s) selected")
            val eng    = engine ?: throw RuntimeException("Engine not initialized")
            val outDir = File(outputDir).also { it.mkdirs() }
            val outZip = File(outDir, zipName.substringBeforeLast('.') + ".enc.zip")
            var done   = 0

            val total = taskMap.size
            ZipOutputStream(outZip.outputStream().buffered()).use { zos ->
                ZipInputStream(File(zipPath).inputStream().buffered()).use { zis ->
                    var entry = zis.nextEntry
                    while (entry != null) {
                        if (entry.isDirectory) {
                            zos.putNextEntry(ZipEntry(entry.name))
                            zos.closeEntry()
                        } else if (taskMap.containsKey(entry.name)) {
                            val (method, szKey) = taskMap[entry.name]!!
                            val lbl = methodLabels[method] ?: method
                            log("[●] Encrypting  ${entry.name}  [$lbl]")
                            startForeground(NOTIF_ID, NotificationHelper.buildProcessingNotif(
                                this, "JS Encryptor",
                                "[$done/$total] ${entry.name.substringAfterLast('/')}"))
                            val code = zis.readBytes().toString(Charsets.UTF_8)
                            val out  = try {
                                when (method) {
                                    "decrypt" -> eng.decrypt(code)
                                    "subzero" -> eng.subzero(code, szKey)
                                    else      -> eng.encrypt(code, method)
                                }
                            } catch (e: Exception) {
                                log("[!] ${entry.name}: ${e.message}")
                                code
                            }
                            zos.putNextEntry(ZipEntry(entry.name))
                            zos.write(out.toByteArray(Charsets.UTF_8))
                            zos.closeEntry()
                            log("[✓] Done        ${entry.name}")
                            done++
                        } else {
                            val buf = ByteArrayOutputStream()
                            val tmp = ByteArray(8192); var n: Int
                            while (zis.read(tmp).also { n = it } != -1) buf.write(tmp, 0, n)
                            zos.putNextEntry(ZipEntry(entry.name))
                            zos.write(buf.toByteArray())
                            zos.closeEntry()
                        }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }
            }

            log("[*] Repacking complete — $done file(s) encrypted")
            log("[✓] Saved → ${outZip.name}")
            p.edit()
                .putBoolean(K_RUNNING, false).putString(K_STATUS, "done")
                .putBoolean(K_SUCCESS, true).putString(K_OUT_FILE, outZip.absolutePath)
                .apply()
            NotificationHelper.showResult(this, true, "JS Encryptor", "Batch complete — $done file(s) encrypted")

        } catch (e: Exception) {
            log("[!] Error: ${e.message}")
            p.edit()
                .putBoolean(K_RUNNING, false).putString(K_STATUS, "error")
                .putBoolean(K_SUCCESS, false).apply()
            NotificationHelper.showResult(this, false, "JS Encryptor", "Batch failed: ${e.message}")
        } finally {
            wakeLock?.release()
            stopSelf()
        }
    }

    private fun processZip(
        zipFile: File,
        outDir: File,
        method: String,
        isDecrypt: Boolean,
        isSubZero: Boolean,
        szKey: String,
        eng: WebViewJsEngine,
        p: SharedPreferences,
        log: (String) -> Unit,
        origName: String
    ) {
        val zipBaseName = origName.substringBeforeLast('.')
        val suffix      = if (isDecrypt) ".dec" else if (isSubZero) ".szero" else ".enc"
        val outZipFile  = File(outDir, "${zipBaseName}${suffix}.zip")

        val allowedExt = if (isSubZero) setOf("html", "htm") else setOf("js")

        ZipOutputStream(outZipFile.outputStream().buffered()).use { zos ->
            ZipInputStream(zipFile.inputStream().buffered()).use { zis ->
                var entry = zis.nextEntry
                var processed = 0
                var skipped   = 0
                while (entry != null) {
                    val entryExt = entry.name.substringAfterLast('.').lowercase()
                    if (!entry.isDirectory && entryExt in allowedExt) {
                        log("[*] Processing: ${entry.name}")
                        val code = zis.readBytes().toString(Charsets.UTF_8)
                        val result = try {
                            when {
                                isDecrypt -> eng.decrypt(code)
                                isSubZero -> eng.subzero(code, szKey)
                                else      -> eng.encrypt(code, method)
                            }
                        } catch (e: Exception) {
                            log("[!] ${entry.name}: ${e.message}")
                            code
                        }
                        val outEntryName = if (isDecrypt)
                            entry.name.substringBeforeLast('.') + ".dec.js"
                        else if (isSubZero)
                            entry.name.substringBeforeLast('.') + ".szero.html"
                        else
                            entry.name.substringBeforeLast('.') + ".enc.js"
                        zos.putNextEntry(ZipEntry(outEntryName))
                        zos.write(result.toByteArray(Charsets.UTF_8))
                        zos.closeEntry()
                        processed++
                        log("[+] Done: ${entry.name} → $outEntryName")
                    } else {
                        zos.putNextEntry(ZipEntry(entry.name))
                        val buf = ByteArrayOutputStream()
                        val tmp = ByteArray(8192)
                        var n: Int
                        while (zis.read(tmp).also { n = it } != -1) buf.write(tmp, 0, n)
                        zos.write(buf.toByteArray())
                        zos.closeEntry()
                        skipped++
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
                log("[+] ZIP complete: $processed file(s) encrypted, $skipped passed through")
            }
        }

        p.edit()
            .putBoolean(K_SUCCESS, true)
            .putString(K_OUT_FILE, outZipFile.absolutePath)
            .apply()
    }

    override fun onDestroy() {
        // If the OS kills this service before work finishes (e.g. memory pressure,
        // app swiped away), shared-prefs will be left with running=true and the Dart
        // side would poll forever showing "Processing..." on next open.  Clear it here.
        val p1 = getSharedPreferences(PREFS, MODE_PRIVATE)
        if (p1.getBoolean(K_RUNNING, false)) {
            val existing = p1.getString(K_LOG, "") ?: ""
            p1.edit()
                .putBoolean(K_RUNNING, false)
                .putString(K_STATUS,  "error")
                .putString(K_LOG, if (existing.isEmpty()) "[!] Service stopped by OS — tap Encrypt to retry"
                                  else "$existing\n[!] Service stopped by OS — tap Encrypt to retry")
                .apply()
        }
        val p2 = getSharedPreferences(BATCH_PREFS, MODE_PRIVATE)
        if (p2.getBoolean(K_RUNNING, false)) {
            val existing = p2.getString(K_LOG, "") ?: ""
            p2.edit()
                .putBoolean(K_RUNNING, false)
                .putString(K_STATUS,  "error")
                .putString(K_LOG, if (existing.isEmpty()) "[!] Service stopped by OS — tap Encrypt to retry"
                                  else "$existing\n[!] Service stopped by OS — tap Encrypt to retry")
                .apply()
        }
        wakeLock?.let { if (it.isHeld) it.release() }
        engine?.destroy()
        engine = null
        super.onDestroy()
    }
}
