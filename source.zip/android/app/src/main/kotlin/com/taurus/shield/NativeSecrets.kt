package com.taurus.shield

internal object NativeSecrets {
    init {
        System.loadLibrary("taurus_native")
    }

    @JvmStatic
    external fun workerUrl(): String

    @JvmStatic
    external fun jsEncConfigs(): String

    @JvmStatic
    external fun updaterUrl(): String

    @JvmStatic
    external fun pyKey(): String

    @JvmStatic
    external fun isUnderAttack(): Boolean
}
