package com.taurus.shield

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.FileInputStream
import java.security.SecureRandom
import java.util.concurrent.Executors
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class ForgeBridge(private val context: Context) : MethodChannel.MethodCallHandler {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val rng = SecureRandom()

    companion object {
        @Volatile var currentProgress: Int = 0
        @Volatile var cancelRequested: Boolean = false
    }

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "forge_compress"      -> launchCompress(call, result)
            "forge_extract"       -> launchExtract(call, result)
            "forge_detect"        -> detectEncryption(call, result)
            "forge_pbkdf2"        -> nativePbkdf2(call, result)
            "forge_encrypt_file"  -> nativeEncryptFile(call, result)
            "forge_decrypt_file"  -> nativeDecryptFile(call, result)
            "forge_get_progress"   -> result.success(currentProgress)
            "forge_cancel"         -> { cancelRequested = true; result.success(true) }
            "forge_cancel_archive" -> { ForgeService.cancelCurrent(); result.success(true) }
            "forge_state"          -> result.success(ForgeService.getState(context))
            else                  -> result.notImplemented()
        }
    }

    // ── Native PBKDF2 (kept for compatibility) ────────────────────────────────

    private fun nativePbkdf2(call: MethodCall, result: MethodChannel.Result) {
        val password   = call.argument<String>("password") ?: ""
        val salt       = call.argument<ByteArray>("salt") ?: ByteArray(32)
        val iterations = call.argument<Int>("iterations") ?: 1_000_000
        val keyBits    = call.argument<Int>("keyBits") ?: 256
        val hashAlg    = call.argument<String>("hashAlg") ?: "SHA512"

        Executors.newSingleThreadExecutor().execute {
            try {
                val keyBytes = pbkdf2(password, salt, iterations, keyBits, hashAlg)
                mainHandler.post { result.success(keyBytes) }
            } catch (e: Exception) {
                mainHandler.post { result.error("PBKDF2_FAIL", e.message, null) }
            }
        }
    }

    // ── Full native streaming file encryption ─────────────────────────────────
    // Streams file in 2 MB chunks → updates currentProgress (0–100) → honours cancelRequested.
    //
    // Parameters (all required):
    //   filePath, keySource (0=pw/1=hex/2=auto), password, hexKey,
    //   keyBits, iterations, hashAlg, aadText, outputDir
    //
    // Returns: { "outputPath": String, "autoKey": String? }

    private fun nativeEncryptFile(call: MethodCall, result: MethodChannel.Result) {
        val filePath   = call.argument<String>("filePath")   ?: run { result.error("NO_FILE", "filePath required", null); return }
        val keySource  = call.argument<Int>("keySource")     ?: 0
        val password   = call.argument<String>("password")   ?: ""
        val hexKey     = call.argument<String>("hexKey")     ?: ""
        val keyBits    = call.argument<Int>("keyBits")       ?: 256
        val iterations = call.argument<Int>("iterations")    ?: 1_000_000
        val hashAlg    = call.argument<String>("hashAlg")    ?: "SHA512"
        val aadText    = call.argument<String>("aadText")    ?: ""
        val outputDir  = call.argument<String>("outputDir")  ?: run { result.error("NO_DIR", "outputDir required", null); return }

        cancelRequested = false
        currentProgress = 0
        CryptoService.start(context, "Encrypting...")

        Executors.newSingleThreadExecutor().execute {
            var outFile: File? = null
            try {
                val inFile = File(filePath)
                val total  = inFile.length()

                val salt = ByteArray(32).also { rng.nextBytes(it) }
                val iv   = ByteArray(12).also { rng.nextBytes(it) }

                currentProgress = 3

                var autoKey: String? = null
                val keyBytes: ByteArray = when (keySource) {
                    2 -> {
                        val k = ByteArray(keyBits / 8).also { rng.nextBytes(it) }
                        autoKey = k.joinToString("") { "%02x".format(it) }
                        k
                    }
                    1 -> hexToBytes(hexKey.replace(Regex("[^0-9a-fA-F]"), ""))
                    else -> {
                        currentProgress = 5
                        pbkdf2(password, salt, iterations, keyBits, hashAlg)
                    }
                }

                currentProgress = 18

                if (cancelRequested) { cancelRequested = false; mainHandler.post { result.error("CANCELLED", "Cancelled", null) }; return@execute }

                val aadBytes = aadText.toByteArray(Charsets.UTF_8)
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(keyBytes, "AES"), GCMParameterSpec(128, iv))
                if (aadBytes.isNotEmpty()) cipher.updateAAD(aadBytes)

                val iterBytes = if (keySource == 0)
                    byteArrayOf(((iterations shr 16) and 0xFF).toByte(),
                                ((iterations shr  8) and 0xFF).toByte(),
                                ( iterations         and 0xFF).toByte())
                else byteArrayOf(0, 0, 0)

                val header = byteArrayOf(
                    0x42, 0x46, 0x45, 0x01,
                    (if (keyBits == 256) 0x02 else 0x01).toByte(),
                    (if (hashAlg == "SHA512") 0x02 else 0x01).toByte(),
                    iterBytes[0], iterBytes[1], iterBytes[2],
                    (if (aadBytes.isNotEmpty()) 0x01 else 0x00).toByte()
                )

                outFile = File(File(outputDir).also { it.mkdirs() }, "${inFile.name}.enc")
                outFile.outputStream().buffered().use { out ->
                    out.write(header)
                    out.write(salt)
                    out.write(iv)

                    val buf = ByteArray(2 * 1024 * 1024)  // 2 MB chunks
                    var processed = 0L
                    FileInputStream(inFile).use { ins ->
                        var bytesRead: Int
                        while (ins.read(buf).also { bytesRead = it } != -1) {
                            if (cancelRequested) {
                                cancelRequested = false
                                throw CancelledException()
                            }
                            val chunk = cipher.update(buf, 0, bytesRead)
                            if (chunk != null && chunk.isNotEmpty()) out.write(chunk)
                            processed += bytesRead
                            currentProgress = 18 + ((processed * 80) / total).toInt()
                        }
                    }
                    val finalChunk = cipher.doFinal()
                    if (finalChunk != null && finalChunk.isNotEmpty()) out.write(finalChunk)
                }

                currentProgress = 100
                val outPath = outFile.absolutePath
                CryptoService.stop(context)
                mainHandler.post { result.success(mapOf("outputPath" to outPath, "autoKey" to autoKey)) }

            } catch (e: CancelledException) {
                outFile?.delete()
                CryptoService.stop(context)
                mainHandler.post { result.error("CANCELLED", "Cancelled by user", null) }
            } catch (e: Exception) {
                outFile?.delete()
                CryptoService.stop(context)
                mainHandler.post { result.error("ENCRYPT_FAIL", e.message, null) }
            }
        }
    }

    // ── Full native streaming file decryption ─────────────────────────────────
    // Parameters: filePath, password (or hex key), aadText, outputDir
    // Returns: { "outputPath": String }

    private fun nativeDecryptFile(call: MethodCall, result: MethodChannel.Result) {
        val filePath  = call.argument<String>("filePath")  ?: run { result.error("NO_FILE", "filePath required", null); return }
        val password  = call.argument<String>("password")  ?: ""
        val aadText   = call.argument<String>("aadText")   ?: ""
        val outputDir = call.argument<String>("outputDir") ?: run { result.error("NO_DIR",  "outputDir required", null); return }

        cancelRequested = false
        currentProgress = 0
        CryptoService.start(context, "Decrypting...")

        Executors.newSingleThreadExecutor().execute {
            var outFile: File? = null
            try {
                val inFile = File(filePath)
                val total  = inFile.length()

                if (total < 10 + 32 + 12 + 16) {
                    CryptoService.stop(context)
                    mainHandler.post { result.error("BAD_FILE", "File too small to be a valid encrypted file", null) }
                    return@execute
                }

                FileInputStream(inFile).use { ins ->
                    val hdr = ByteArray(10); ins.read(hdr)
                    if (hdr[0] != 0x42.toByte() || hdr[1] != 0x46.toByte() || hdr[2] != 0x45.toByte()) {
                        CryptoService.stop(context)
                        mainHandler.post { result.error("BAD_FILE", "Not a valid Black Forge encrypted file", null) }
                        return@execute
                    }

                    val keyBits = if (hdr[4] == 0x02.toByte()) 256 else 128
                    val hashAlg = if (hdr[5] == 0x02.toByte()) "SHA512" else "SHA256"
                    val iter    = ((hdr[6].toInt() and 0xFF) shl 16) or
                                  ((hdr[7].toInt() and 0xFF) shl  8) or
                                  (hdr[8].toInt() and 0xFF)

                    val salt = ByteArray(32); ins.read(salt)
                    val iv   = ByteArray(12); ins.read(iv)

                    currentProgress = 3

                    val isHexKey = iter == 0 ||
                        (password.matches(Regex("[0-9a-fA-F]+")) && password.length == keyBits / 4)

                    val keyBytes: ByteArray = if (isHexKey) {
                        hexToBytes(password)
                    } else {
                        currentProgress = 5
                        val k = pbkdf2(password, salt, iter, keyBits, hashAlg)
                        k
                    }

                    currentProgress = 18

                    if (cancelRequested) { cancelRequested = false; CryptoService.stop(context); mainHandler.post { result.error("CANCELLED", "Cancelled", null) }; return@execute }

                    val aadBytes = aadText.toByteArray(Charsets.UTF_8)
                    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                    cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(keyBytes, "AES"), GCMParameterSpec(128, iv))
                    if (aadBytes.isNotEmpty()) cipher.updateAAD(aadBytes)

                    var outName = inFile.name
                    if (outName.lowercase().endsWith(".enc")) outName = outName.dropLast(4)

                    outFile = File(File(outputDir).also { it.mkdirs() }, outName)
                    val tmpFile = File(File(outputDir), "${outName}.tmp")

                    // Stream decrypt into temp file — final 16 bytes are the GCM tag,
                    // JCE buffers them internally and verifies on doFinal().
                    val ciphertextLen = total - 54  // skip 10-byte header + 32-byte salt + 12-byte IV
                    var processed = 0L

                    tmpFile.outputStream().buffered().use { out ->
                        val buf = ByteArray(2 * 1024 * 1024)
                        var bytesRead: Int
                        while (ins.read(buf).also { bytesRead = it } != -1) {
                            if (cancelRequested) {
                                cancelRequested = false
                                throw CancelledException()
                            }
                            val chunk = cipher.update(buf, 0, bytesRead)
                            if (chunk != null && chunk.isNotEmpty()) out.write(chunk)
                            processed += bytesRead
                            currentProgress = 18 + ((processed * 80) / ciphertextLen).toInt()
                        }
                        val finalChunk = cipher.doFinal()  // verifies GCM auth tag
                        if (finalChunk != null && finalChunk.isNotEmpty()) out.write(finalChunk)
                    }

                    // Detect extension from magic bytes if needed
                    if (!outName.contains('.')) {
                        val firstBytes = ByteArray(12)
                        tmpFile.inputStream().use { it.read(firstBytes) }
                        val ext = detectExtension(firstBytes)
                        if (ext != null) {
                            outFile = File(File(outputDir), "$outName.$ext")
                        }
                    }
                    if (outFile!!.name.isEmpty()) outFile = File(File(outputDir), "decrypted_${System.currentTimeMillis()}")

                    tmpFile.renameTo(outFile!!)
                    currentProgress = 100

                    val outPath = outFile!!.absolutePath
                    CryptoService.stop(context)
                    mainHandler.post { result.success(mapOf("outputPath" to outPath)) }
                }
            } catch (e: CancelledException) {
                outFile?.delete()
                CryptoService.stop(context)
                mainHandler.post { result.error("CANCELLED", "Cancelled by user", null) }
            } catch (e: javax.crypto.AEADBadTagException) {
                outFile?.delete()
                CryptoService.stop(context)
                mainHandler.post { result.error("BAD_TAG", "Wrong password / key or file is corrupted", null) }
            } catch (e: Exception) {
                outFile?.delete()
                CryptoService.stop(context)
                val msg = e.message ?: "Unknown error"
                if (msg.contains("Tag mismatch") || msg.contains("mac") || msg.contains("GCM")) {
                    mainHandler.post { result.error("BAD_TAG", "Wrong password / key or file is corrupted", null) }
                } else {
                    mainHandler.post { result.error("DECRYPT_FAIL", msg, null) }
                }
            }
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private class CancelledException : Exception("Cancelled by user")

    private fun pbkdf2(password: String, salt: ByteArray, iterations: Int, keyBits: Int, hashAlg: String): ByteArray {
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmac$hashAlg")
        val spec    = PBEKeySpec(password.toCharArray(), salt, iterations, keyBits)
        val key     = factory.generateSecret(spec).encoded
        spec.clearPassword()
        return key
    }

    private fun hexToBytes(hex: String): ByteArray =
        ByteArray(hex.length / 2) { i -> hex.substring(i * 2, i * 2 + 2).toInt(16).toByte() }

    private fun detectExtension(b: ByteArray): String? {
        if (b.size < 4) return null
        return when {
            b[0] == 0xFF.toByte() && (b[1].toInt() and 0xE0) == 0xE0 -> "mp3"
            b[0] == 0x49.toByte() && b[1] == 0x44.toByte() && b[2] == 0x33.toByte() -> "mp3"
            b[0] == 0xFF.toByte() && b[1] == 0xD8.toByte() && b[2] == 0xFF.toByte() -> "jpg"
            b[0] == 0x89.toByte() && b[1] == 0x50.toByte() && b[2] == 0x4E.toByte() && b[3] == 0x47.toByte() -> "png"
            b[0] == 0x47.toByte() && b[1] == 0x49.toByte() && b[2] == 0x46.toByte() -> "gif"
            b[0] == 0x25.toByte() && b[1] == 0x50.toByte() && b[2] == 0x44.toByte() && b[3] == 0x46.toByte() -> "pdf"
            b[0] == 0x50.toByte() && b[1] == 0x4B.toByte() && b[2] == 0x03.toByte() && b[3] == 0x04.toByte() -> "zip"
            b.size >= 12 && b[4] == 0x66.toByte() && b[5] == 0x74.toByte() && b[6] == 0x79.toByte() && b[7] == 0x70.toByte() -> "mp4"
            b[0] == 0x52.toByte() && b[1] == 0x49.toByte() && b[2] == 0x46.toByte() && b[3] == 0x46.toByte() ->
                if (b.size >= 12 && b[8] == 0x57.toByte() && b[9] == 0x41.toByte() && b[10] == 0x56.toByte() && b[11] == 0x45.toByte()) "wav" else "avi"
            b[0] == 0x4F.toByte() && b[1] == 0x67.toByte() && b[2] == 0x67.toByte() && b[3] == 0x53.toByte() -> "ogg"
            b[0] == 0x66.toByte() && b[1] == 0x4C.toByte() && b[2] == 0x61.toByte() && b[3] == 0x43.toByte() -> "flac"
            b[0] == 0xFF.toByte() && (b[1].toInt() and 0xF6) == 0xF0 -> "aac"
            b[0] == 0x1A.toByte() && b[1] == 0x45.toByte() && b[2] == 0xDF.toByte() && b[3] == 0xA3.toByte() -> "mkv"
            b[0] == 0x64.toByte() && b[1] == 0x65.toByte() && b[2] == 0x78.toByte() && b[3] == 0x0A.toByte() -> "dex"
            b[0] == 0x7F.toByte() && b[1] == 0x45.toByte() && b[2] == 0x4C.toByte() && b[3] == 0x46.toByte() -> "elf"
            else -> null
        }
    }

    // ── Archive / detect ──────────────────────────────────────────────────────

    private fun detectEncryption(call: MethodCall, result: MethodChannel.Result) {
        val file = call.argument<String>("file") ?: run {
            result.error("INVALID_ARG", "file required", null); return
        }
        Executors.newSingleThreadExecutor().execute {
            try {
                val bin = BinRef.c(context.applicationInfo.nativeLibraryDir)
                val pb  = ProcessBuilder(bin, "l", "-slt", file).redirectErrorStream(true)
                pb.environment()["HOME"]   = context.filesDir.absolutePath
                pb.environment()["TMPDIR"] = context.cacheDir.absolutePath
                val proc   = pb.start()
                val output = proc.inputStream.bufferedReader().readText()
                proc.waitFor()
                mainHandler.post { result.success(mapOf("encrypted" to output.contains("Encrypted = +"))) }
            } catch (e: Exception) {
                mainHandler.post { result.success(mapOf("encrypted" to false)) }
            }
        }
    }

    private fun launchCompress(call: MethodCall, result: MethodChannel.Result) {
        if (ForgeService.isRunning(context)) { result.error("BUSY", "Forge is already running", null); return }

        val files        = call.argument<List<String>>("files") ?: run { result.error("INVALID_ARG", "files required", null); return }
        val format       = call.argument<String>("format")       ?: "7z"
        val level        = call.argument<Int>("level")           ?: 7
        val encryption   = call.argument<String>("encryption")   ?: "none"
        val password     = call.argument<String>("password")     ?: ""
        val split        = call.argument<String>("split")
        val deleteSource = call.argument<Boolean>("deleteSource") ?: false

        val intent = Intent(context, ForgeService::class.java).apply {
            putExtra("mode", "compress")
            putStringArrayListExtra("files", ArrayList(files))
            putExtra("format", format)
            putExtra("level", level)
            putExtra("encryption", encryption)
            putExtra("password", password)
            if (split != null) putExtra("split", split)
            putExtra("deleteSource", deleteSource)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
        else context.startService(intent)
        result.success(mapOf("started" to true))
    }

    private fun launchExtract(call: MethodCall, result: MethodChannel.Result) {
        if (ForgeService.isRunning(context)) { result.error("BUSY", "Forge is already running", null); return }

        val file     = call.argument<String>("file")     ?: run { result.error("INVALID_ARG", "file required", null); return }
        val password = call.argument<String>("password") ?: ""

        val intent = Intent(context, ForgeService::class.java).apply {
            putExtra("mode", "extract")
            putExtra("file", file)
            putExtra("password", password)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
        else context.startService(intent)
        result.success(mapOf("started" to true))
    }
}
