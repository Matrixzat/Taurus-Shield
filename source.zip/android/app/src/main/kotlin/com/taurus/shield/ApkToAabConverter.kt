package com.taurus.shield

import android.os.Handler
import android.os.Looper
import com.reandroid.apk.ApkModule
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

class ApkToAabConverter {

    companion object {
        /**
         * Minimal BundleConfig.pb:
         *   message BundleConfig { BundletoolConfig bundletool = 1; }
         *   message BundletoolConfig { string version = 1; }
         *   version = "1.0.0"
         *
         * Proto encoding:
         *   field 1, type LEN (0x0a), length 7 → bundletool block
         *     field 1, type LEN (0x0a), length 5, "1.0.0"
         */
        private val BUNDLE_CONFIG_PB = byteArrayOf(
            0x0a, 0x07, 0x0a, 0x05,
            '1'.code.toByte(), '.'.code.toByte(), '0'.code.toByte(),
            '.'.code.toByte(), '0'.code.toByte()
        )
    }

    private val executor    = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    fun convert(
        apkPath:    String,
        outputDir:  String,
        onLog:      (String) -> Unit,
        onComplete: (Map<String, Any?>) -> Unit,
    ) {
        executor.execute {
            try {
                val outPath = doConvert(apkPath, outputDir, onLog)
                mainHandler.post {
                    onComplete(mapOf(
                        "status"      to "success",
                        "output_dir"  to outputDir,
                        "output_path" to outPath,
                    ))
                }
            } catch (e: Exception) {
                mainHandler.post {
                    onComplete(mapOf(
                        "status"     to "error",
                        "error"      to (e.message ?: "Unknown error"),
                        "output_dir" to outputDir,
                    ))
                }
            }
        }
    }

    private fun doConvert(
        apkPath:  String,
        outputDir: String,
        log:       (String) -> Unit,
    ): String {
        log("=".repeat(50))
        log("  TAURUS SHIELD — APK TO AAB")
        log("=".repeat(50))
        val apkFile = File(apkPath)
        log("  Input : ${apkFile.name}")
        log("  Output: $outputDir")
        log("-".repeat(50))

        // ── [1/4] Validate input ─────────────────────────────────────────────
        log("[1/4] Validating APK...")
        if (!apkFile.exists()) throw IllegalArgumentException("File not found: $apkPath")
        val sizeMb = String.format("%.2f", apkFile.length() / 1024.0 / 1024.0)
        log("      Size: $sizeMb MB")

        var hasManifest  = false
        var hasResources = false
        val dexFiles      = mutableListOf<String>()
        val libEntries    = mutableListOf<String>()
        val assetEntries  = mutableListOf<String>()
        val resEntries    = mutableListOf<String>()
        val rootEntries   = mutableListOf<String>()
        val metaInfEntries = mutableListOf<String>()

        ZipFile(apkFile).use { zip ->
            for (e in zip.entries()) {
                if (e.isDirectory) continue
                val n = e.name
                when {
                    n == "AndroidManifest.xml"                    -> hasManifest  = true
                    n == "resources.arsc"                         -> hasResources = true
                    n.startsWith("classes") && n.endsWith(".dex") -> dexFiles      += n
                    n.startsWith("lib/")                          -> libEntries     += n
                    n.startsWith("assets/")                       -> assetEntries   += n
                    n.startsWith("res/")                          -> resEntries     += n
                    n.startsWith("META-INF/")                     -> metaInfEntries += n
                    !n.contains('/')                              -> rootEntries    += n
                }
            }
        }
        if (!hasManifest) throw IllegalArgumentException("Not a valid APK — AndroidManifest.xml missing")
        log("      DEX: ${dexFiles.size}  lib: ${libEntries.size}  assets: ${assetEntries.size}  res: ${resEntries.size}  META-INF: ${metaInfEntries.size}")
        log("      OK")

        // ── [2/4] Parse via ARSCLib (package name + optional proto resources) ─
        log("[2/4] Parsing APK metadata...")
        var packageName = "unknown"
        var resourcesPb = byteArrayOf()

        try {
            val module = ApkModule.loadApkFile(apkFile)
            packageName = module.androidManifest?.packageName ?: "unknown"
            log("      Package : $packageName")

            if (hasResources) {
                val tableBlock = module.tableBlock
                if (tableBlock != null) {
                    // Try reflection for proto serialisation — method name differs by ARSCLib build
                    val protoMethodCandidates = listOf(
                        "serializeToProtobuf", "toProtobuf", "writeToProtobuf", "writeProtobuf"
                    )
                    var converted = false
                    for (mName in protoMethodCandidates) {
                        try {
                            val m = tableBlock.javaClass.getMethod(mName, java.io.OutputStream::class.java)
                            val baos = ByteArrayOutputStream()
                            m.invoke(tableBlock, baos)
                            val pb = baos.toByteArray()
                            if (pb.isNotEmpty()) {
                                resourcesPb = pb
                                log("      resources.pb: ${pb.size} bytes (proto via $mName)")
                                converted = true
                            }
                            break
                        } catch (_: NoSuchMethodException) { /* try next */ }
                        catch (e: Exception) {
                            log("      WARN [$mName]: ${e.message?.take(60)}")
                            break
                        }
                    }
                    if (!converted) log("      resources.pb: proto API unavailable — binary fallback")
                }
            }
        } catch (e: Exception) {
            log("      WARN: ARSCLib: ${e.message?.take(80)}")
        }
        log("      OK")

        // ── [3/4] Write AAB zip ───────────────────────────────────────────────
        log("[3/4] Building AAB structure...")
        val outDir  = File(outputDir).also { it.mkdirs() }
        val aabFile = File(outDir, "${apkFile.nameWithoutExtension}.aab")

        ZipOutputStream(FileOutputStream(aabFile)).use { aab ->

            aab.put("BundleConfig.pb", BUNDLE_CONFIG_PB)
            aab.put("base/resources.pb", resourcesPb)

            ZipFile(apkFile).use { apk ->

                // Manifest → base/manifest/
                apk.getEntry("AndroidManifest.xml")?.let { e ->
                    aab.put("base/manifest/AndroidManifest.xml", apk.getInputStream(e).readBytes())
                    log("      manifest  → base/manifest/AndroidManifest.xml")
                }

                // DEX → base/dex/
                for (dexName in dexFiles) {
                    apk.getEntry(dexName)?.let { e ->
                        aab.put("base/dex/$dexName", apk.getInputStream(e).readBytes())
                    }
                }
                log("      dex       → base/dex/       (${dexFiles.size})")

                // lib → base/lib/
                for (libName in libEntries) {
                    apk.getEntry(libName)?.let { e ->
                        aab.put("base/$libName", apk.getInputStream(e).readBytes())
                    }
                }
                log("      lib       → base/lib/       (${libEntries.size})")

                // assets → base/assets/
                for (assetName in assetEntries) {
                    apk.getEntry(assetName)?.let { e ->
                        aab.put("base/$assetName", apk.getInputStream(e).readBytes())
                    }
                }
                log("      assets    → base/assets/    (${assetEntries.size})")

                // res → base/res/
                for (resName in resEntries) {
                    apk.getEntry(resName)?.let { e ->
                        aab.put("base/$resName", apk.getInputStream(e).readBytes())
                    }
                }
                log("      res       → base/res/       (${resEntries.size})")

                // Misc root files → base/root/
                val skipRoots = setOf("AndroidManifest.xml", "resources.arsc")
                for (rootName in rootEntries) {
                    if (rootName in skipRoots) continue
                    apk.getEntry(rootName)?.let { e ->
                        aab.put("base/root/$rootName", apk.getInputStream(e).readBytes())
                    }
                }
                if (rootEntries.isNotEmpty())
                    log("      root      → base/root/      (${rootEntries.size})")

                // resources.arsc as binary fallback if proto conversion failed
                if (resourcesPb.isEmpty() && hasResources) {
                    apk.getEntry("resources.arsc")?.let { e ->
                        aab.put("base/root/resources.arsc", apk.getInputStream(e).readBytes())
                        log("      resources.arsc → base/root/ (binary fallback — proto unavailable)")
                    }
                }

                // META-INF → root META-INF/ (preserves APK signature block in AAB)
                for (metaName in metaInfEntries) {
                    apk.getEntry(metaName)?.let { e ->
                        aab.put(metaName, apk.getInputStream(e).readBytes())
                    }
                }
                if (metaInfEntries.isNotEmpty())
                    log("      META-INF  → META-INF/        (${metaInfEntries.size})")
            }
        }

        val outMb = String.format("%.2f", aabFile.length() / 1024.0 / 1024.0)
        log("      Output: ${aabFile.name}  ($outMb MB)")
        log("      OK")

        // ── [4/4] Done ───────────────────────────────────────────────────────
        log("[4/4] Done.")
        log("  Package : $packageName")
        log("  Note    : AAB is unsigned. Sign with jarsigner before Play Store upload.")
        log("-".repeat(50))
        log("  CONVERSION COMPLETE")
        log("=".repeat(50))

        return aabFile.absolutePath
    }

    private fun ZipOutputStream.put(name: String, data: ByteArray) {
        putNextEntry(ZipEntry(name))
        write(data)
        closeEntry()
    }
}
