package com.taurus.shield

import android.util.Log
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.PrintStream
import java.nio.file.Path
import java.nio.file.spi.FileSystemProvider
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class DexToolsService {

    companion object {
        private const val TAG = "DexToolsService"
        private val lock = Any()

        // ── ZIP FileSystem injection ──────────────────────────────────────────
        // Android's java.nio.file has no "jar:" provider. dex2jar needs one to
        // write output JARs. We inject AndroidZipFileSystemProvider once.
        @Volatile private var zipFsInstalled = false

        private fun ensureZipFs() {
            if (zipFsInstalled) return
            synchronized(lock) {
                if (zipFsInstalled) return
                try {
                    val cls   = FileSystemProvider::class.java
                    val field = cls.getDeclaredField("installedProviders")
                    field.isAccessible = true
                    @Suppress("UNCHECKED_CAST")
                    val current = (field.get(null) as? List<FileSystemProvider>) ?: emptyList()
                    if (current.none { it.scheme.equals("jar", ignoreCase = true) }) {
                        val list = ArrayList<FileSystemProvider>(current)
                        list.add(AndroidZipFileSystemProvider())
                        field.set(null, list)
                        Log.d(TAG, "AndroidZipFileSystemProvider injected")
                    }
                    zipFsInstalled = true
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to install ZipFS provider: $e")
                }
            }
        }
    }

    private class ExitException(val status: Int) : SecurityException("exit($status)")

    // ── Entry point ───────────────────────────────────────────────────────────

    fun handle(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "setup" -> {
                // No-op: tool JARs are compiled into the app DEX at build time.
                // Class.forName() resolves them directly — no extraction needed.
                result.success(mapOf("success" to true))
            }
            "run" -> {
                val tool      = call.argument<String>("tool") ?: ""
                val filePath  = call.argument<String>("filePath") ?: ""
                val outputDir = call.argument<String>("outputDir") ?: ""
                try {
                    val res = runTool(tool, filePath, outputDir)
                    result.success(res)
                } catch (e: Exception) {
                    result.success(mapOf("success" to false, "error" to e.message, "log" to ""))
                }
            }
            else -> result.notImplemented()
        }
    }

    // ── Tool dispatcher ───────────────────────────────────────────────────────

    private fun runTool(tool: String, inputPath: String, outputDir: String): Map<String, Any> {
        File(outputDir).mkdirs()
        return when (tool) {
            "smali2java" -> smali2Java(inputPath, outputDir)
            "java2smali" -> java2Smali(inputPath, outputDir)
            "dex2jar"    -> dex2Jar(inputPath, outputDir)
            "dex2java"   -> dex2Java(inputPath, outputDir)
            else         -> mapOf("success" to false, "error" to "Unknown tool: $tool")
        }
    }

    // ── Smali → Java ─────────────────────────────────────────────────────────

    private fun smali2Java(inputPath: String, outputDir: String): Map<String, Any> {
        val sb  = StringBuilder()
        val tmp = File(outputDir, "smali2java_tmp").also { it.mkdirs() }

        val smaliDir = File(tmp, "smali")
        smaliDir.mkdirs()

        if (inputPath.endsWith(".zip", ignoreCase = true) ||
            inputPath.endsWith(".apk", ignoreCase = true)) {
            unzip(File(inputPath), smaliDir)
        } else {
            File(inputPath).copyTo(File(smaliDir, File(inputPath).name), overwrite = true)
        }

        val tempDex = File(tmp, "assembled.dex")
        val (smExit, smLog) = invokeInProcess(
            "com.googlecode.d2j.smali.SmaliCmd",
            arrayOf("assemble", smaliDir.absolutePath, "-o", tempDex.absolutePath)
        )
        sb.appendLine(smLog)

        if (smExit != 0 || !tempDex.exists()) {
            tmp.deleteRecursively()
            return mapOf("success" to false, "error" to "smali assemble failed", "log" to sb.toString())
        }

        val tempJar = File(tmp, "assembled.jar")
        val (d2Exit, d2Log) = dex2JarDirect(tempDex.absolutePath, tempJar.absolutePath)
        sb.appendLine(d2Log)

        if (d2Exit != 0 || !tempJar.exists()) {
            tmp.deleteRecursively()
            return mapOf("success" to false, "error" to "dex2jar failed", "log" to sb.toString())
        }

        val javaOut = File(tmp, "java_src")
        javaOut.mkdirs()
        val (_, cfrLog) = invokeInProcess(
            "org.benf.cfr.reader.Main",
            arrayOf(tempJar.absolutePath, "--outputdir", javaOut.absolutePath, "--silent", "true")
        )
        sb.appendLine(cfrLog)

        val input   = File(inputPath)
        val zipPath = File(outputDir, "${input.nameWithoutExtension}_java.zip").absolutePath
        zipFolder(javaOut, zipPath)
        tmp.deleteRecursively()

        return if (File(zipPath).exists())
            mapOf("success" to true, "outputPath" to zipPath, "log" to sb.toString())
        else
            mapOf("success" to false, "error" to "CFR produced no output", "log" to sb.toString())
    }

    // ── Java → Smali ─────────────────────────────────────────────────────────
    //
    // Accepts: .java, .jar, .class, or .zip (containing any mix of those).
    //
    // Pipeline:
    //   1. Collect all .java / .jar / .class inputs (unzipping a .zip first).
    //   2. ECJ-compile every .java file together into a shared classes dir.
    //   3. dx --dex everything (classes dir + standalone .jar / .class) into
    //      a single compiled.dex.
    //   4. baksmali compiled.dex into per-class .smali files.
    //   5. Zip the .smali tree as <input>_smali.zip.

    private fun java2Smali(inputPath: String, outputDir: String): Map<String, Any> {
        val sb      = StringBuilder()
        val tmp     = File(outputDir, "java2smali_tmp").also { it.mkdirs() }
        val input   = File(inputPath)
        val tempDex = File(tmp, "compiled.dex")

        // 1. Collect inputs.
        val javaFiles    = mutableListOf<File>()
        val jarClassDxIn = mutableListOf<File>()

        try {
            when {
                inputPath.endsWith(".zip", ignoreCase = true) -> {
                    val srcDir = File(tmp, "src").also { it.mkdirs() }
                    unzip(input, srcDir)
                    srcDir.walkTopDown().filter { it.isFile }.forEach { f ->
                        when {
                            f.name.endsWith(".java",  ignoreCase = true) -> javaFiles.add(f)
                            f.name.endsWith(".jar",   ignoreCase = true) -> jarClassDxIn.add(f)
                            f.name.endsWith(".class", ignoreCase = true) -> jarClassDxIn.add(f)
                        }
                    }
                    if (javaFiles.isEmpty() && jarClassDxIn.isEmpty()) {
                        tmp.deleteRecursively()
                        return mapOf(
                            "success" to false,
                            "error"   to "ZIP contains no .java, .jar, or .class files"
                        )
                    }
                    sb.appendLine(
                        "Discovered in ZIP: ${javaFiles.size} .java, " +
                        "${jarClassDxIn.count { it.extension.equals("jar", true) }} .jar, " +
                        "${jarClassDxIn.count { it.extension.equals("class", true) }} .class"
                    )
                }
                inputPath.endsWith(".java",  ignoreCase = true) -> javaFiles.add(input)
                inputPath.endsWith(".jar",   ignoreCase = true) -> jarClassDxIn.add(input)
                inputPath.endsWith(".class", ignoreCase = true) -> jarClassDxIn.add(input)
                else -> {
                    tmp.deleteRecursively()
                    return mapOf(
                        "success" to false,
                        "error"   to "Unsupported input: use .java, .jar, .class, or .zip"
                    )
                }
            }
        } catch (e: Exception) {
            tmp.deleteRecursively()
            return mapOf("success" to false, "error" to "Failed to read input: ${e.message}", "log" to sb.toString())
        }

        // 2. ECJ-compile any .java files together.
        val classDir = File(tmp, "classes")
        if (javaFiles.isNotEmpty()) {
            classDir.mkdirs()
            val ecjArgs = mutableListOf("-source", "1.8", "-target", "1.8", "-nowarn")
            javaFiles.forEach { ecjArgs.add(it.absolutePath) }
            ecjArgs.add("-d"); ecjArgs.add(classDir.absolutePath)
            val (ecjExit, ecjLog) = invokeInProcess(
                "org.eclipse.jdt.internal.compiler.batch.Main",
                ecjArgs.toTypedArray()
            )
            sb.appendLine(ecjLog)
            if (ecjExit != 0) {
                tmp.deleteRecursively()
                return mapOf("success" to false, "error" to "ECJ compile failed", "log" to sb.toString())
            }
        }

        // 3. dx all compiled output + standalone .jar/.class into a single DEX.
        val dxInputs = mutableListOf<String>()
        if (classDir.exists() && classDir.walkTopDown().any { it.isFile }) {
            dxInputs.add(classDir.absolutePath)
        }
        jarClassDxIn.forEach { dxInputs.add(it.absolutePath) }

        if (dxInputs.isEmpty()) {
            tmp.deleteRecursively()
            return mapOf("success" to false, "error" to "Nothing to dex after compile", "log" to sb.toString())
        }

        val dxArgs = mutableListOf("--dex", "--output=${tempDex.absolutePath}")
        dxArgs.addAll(dxInputs)
        val (dxExit, dxLog) = invokeInProcess(
            "com.android.dx.command.Main",
            dxArgs.toTypedArray()
        )
        sb.appendLine(dxLog)
        if (dxExit != 0 || !tempDex.exists()) {
            tmp.deleteRecursively()
            return mapOf("success" to false, "error" to "dx dex failed", "log" to sb.toString())
        }

        // 4. baksmali → smali tree.
        val smaliOut = File(tmp, "smali_out").also { it.mkdirs() }
        val (bkExit, bkLog) = invokeInProcess(
            "com.googlecode.d2j.smali.BaksmaliCmd",
            arrayOf("disassemble", tempDex.absolutePath, "-o", smaliOut.absolutePath)
        )
        sb.appendLine(bkLog)

        // 5. Zip and return.
        val zipPath = File(outputDir, "${input.nameWithoutExtension}_smali.zip").absolutePath
        zipFolder(smaliOut, zipPath)
        tmp.deleteRecursively()

        return if (File(zipPath).exists())
            mapOf("success" to true, "outputPath" to zipPath, "log" to sb.toString())
        else
            mapOf("success" to false, "error" to "baksmali failed (exit $bkExit)", "log" to sb.toString())
    }

    // ── DEX → JAR ────────────────────────────────────────────────────────────

    private fun dex2Jar(inputPath: String, outputDir: String): Map<String, Any> {
        val input   = File(inputPath)
        val jarPath = File(outputDir, "${input.nameWithoutExtension}.jar").absolutePath

        val (exit, log) = dex2JarDirect(inputPath, jarPath)

        return if (exit == 0 && File(jarPath).exists())
            mapOf("success" to true, "outputPath" to jarPath, "log" to log)
        else
            mapOf("success" to false, "error" to "dex2jar failed (exit $exit)", "log" to log)
    }

    // ── Direct dex2jar via Dex2jar API ────────────────────────────────────────
    //
    // Instead of going through Dex2jarCmd.main() (which calls
    // FileSystems.newFileSystem("jar:...") and fails on Android with
    // "cant find zipfs support"), we call the lower-level Dex2jar.from(File)
    // API directly and pass an AndroidZipPath as the output "directory".
    //
    // When Dex2jar.to(path) sees the path reports isDirectory()=true, it skips
    // ZIP creation entirely and writes .class files directly to that path via
    // Files.write(). Our AndroidZipFileSystem intercepts those writes and routes
    // them into a ZipOutputStream, producing a valid JAR at outputJarPath.

    private fun dex2JarDirect(inputPath: String, outputJarPath: String): Pair<Int, String> {
        val sb   = StringBuilder()
        sb.appendLine("dex2jar $inputPath -> $outputJarPath")
        val prov = AndroidZipFileSystemProvider()
        val outFs = AndroidZipFileSystem(prov, outputJarPath)
        return try {
            val dex2jarClass = Class.forName("com.googlecode.d2j.dex.Dex2jar")
            val fromMethod   = dex2jarClass.getMethod("from", java.io.File::class.java)
            val d2j          = fromMethod.invoke(null, java.io.File(inputPath))
            val root: Path   = outFs.getPath("/")
            val toMethod     = d2j!!.javaClass.getMethod("to", Path::class.java)
            toMethod.invoke(d2j, root)
            outFs.close()
            Pair(0, sb.toString())
        } catch (e: java.lang.reflect.InvocationTargetException) {
            sb.appendLine("Error: ${e.cause?.message ?: e.message}")
            runCatching { outFs.close() }
            Pair(1, sb.toString())
        } catch (e: Exception) {
            sb.appendLine("Error: ${e.message}")
            runCatching { outFs.close() }
            Pair(1, sb.toString())
        }
    }

    // ── DEX → Java ───────────────────────────────────────────────────────────

    private fun dex2Java(inputPath: String, outputDir: String): Map<String, Any> {
        val sb    = StringBuilder()
        val tmp   = File(outputDir, "dex2java_tmp").also { it.mkdirs() }
        val input = File(inputPath)

        val tempJar = File(tmp, "temp.jar")
        val (d2Exit, d2Log) = dex2JarDirect(inputPath, tempJar.absolutePath)
        sb.appendLine(d2Log)

        if (d2Exit != 0 || !tempJar.exists()) {
            tmp.deleteRecursively()
            return mapOf("success" to false, "error" to "dex2jar failed (exit $d2Exit)", "log" to sb.toString())
        }

        val javaOut = File(tmp, "java_src")
        javaOut.mkdirs()
        val (cfrExit, cfrLog) = invokeInProcess(
            "org.benf.cfr.reader.Main",
            arrayOf(tempJar.absolutePath, "--outputdir", javaOut.absolutePath, "--silent", "true")
        )
        sb.appendLine(cfrLog)

        val zipPath = File(outputDir, "${input.nameWithoutExtension}_java.zip").absolutePath
        zipFolder(javaOut, zipPath)
        tmp.deleteRecursively()

        return if (File(zipPath).exists())
            mapOf("success" to true, "outputPath" to zipPath, "log" to sb.toString())
        else
            mapOf("success" to false, "error" to "CFR produced no output (exit $cfrExit)", "log" to sb.toString())
    }

    // ── In-process invocation ─────────────────────────────────────────────────
    //
    // Runs a tool's main() inside the app's own process via reflection.
    // Classes are already in the app DEX (compiled from libs/*.jar at build time)
    // so Class.forName() resolves them with no extra ClassLoader.
    //
    // System.setOut/Err redirect stdout/stderr to a capture buffer.
    // A SecurityManager intercepts System.exit() calls so they don't kill the app.
    // The entire invocation is synchronized so concurrent calls can't corrupt
    // the global stdout/stderr pointers.

    private fun invokeInProcess(mainClass: String, args: Array<String>): Pair<Int, String> {
        ensureZipFs()
        return synchronized(lock) {
            val capture = ByteArrayOutputStream()
            val ps      = PrintStream(capture, true, "UTF-8")
            val oldOut  = System.out
            val oldErr  = System.err
            var exitCode = 0

            @Suppress("DEPRECATION")
            val prevSM = System.getSecurityManager()
            val noExitSM = object : SecurityManager() {
                override fun checkExit(status: Int) = throw ExitException(status)
                @Suppress("EmptyFunctionBlock")
                override fun checkPermission(perm: java.security.Permission?) {}
            }

            System.setOut(ps)
            System.setErr(ps)

            try {
                @Suppress("DEPRECATION")
                System.setSecurityManager(noExitSM)
            } catch (e: Exception) {
                Log.w(TAG, "SecurityManager not settable: ${e.message}")
            }

            try {
                val clazz  = Class.forName(mainClass)
                val method = clazz.getMethod("main", Array<String>::class.java)
                method.invoke(null, args as Any)
            } catch (e: java.lang.reflect.InvocationTargetException) {
                when (val cause = e.cause) {
                    is ExitException -> exitCode = cause.status
                    else -> {
                        ps.println("Error: ${cause?.message ?: e.message}")
                        exitCode = 1
                    }
                }
            } catch (e: ExitException) {
                exitCode = e.status
            } catch (e: Exception) {
                ps.println("Error: ${e.message}")
                Log.e(TAG, "invokeInProcess error for $mainClass", e)
                exitCode = 1
            } finally {
                System.setOut(oldOut)
                System.setErr(oldErr)
                try {
                    @Suppress("DEPRECATION")
                    System.setSecurityManager(prevSM)
                } catch (_: Exception) {}
            }

            Log.d(TAG, "invokeInProcess $mainClass → exit $exitCode")
            Pair(exitCode, capture.toString("UTF-8"))
        }
    }

    // ── ZIP helpers ───────────────────────────────────────────────────────────

    private fun zipFolder(folder: File, zipPath: String) {
        ZipOutputStream(FileOutputStream(zipPath)).use { zos ->
            folder.walkTopDown().filter { it.isFile }.forEach { file ->
                val entry = ZipEntry(file.relativeTo(folder).path)
                zos.putNextEntry(entry)
                file.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }

    private fun unzip(zip: File, destDir: File) {
        val destRoot = destDir.canonicalPath
        ZipInputStream(FileInputStream(zip)).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val outFile = File(destDir, entry.name)
                // Zip-slip guard: refuse entries whose canonical path escapes destDir.
                val outCanon = outFile.canonicalPath
                if (outCanon != destRoot && !outCanon.startsWith(destRoot + File.separator)) {
                    throw java.io.IOException("Zip entry escapes target dir: ${entry.name}")
                }
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    outFile.outputStream().use { zis.copyTo(it) }
                }
                entry = zis.nextEntry
            }
        }
    }
}
