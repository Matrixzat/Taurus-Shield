package com.taurus.shield

import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object ShizukuHelper {

    private const val REQUEST_CODE  = 4827
    private const val PREFS_NAME    = "lc_shizuku_prefs"
    private const val KEY_AFTER     = "lc_after_shizuku"

    fun isAvailable(): Boolean = try {
        Shizuku.pingBinder()
    } catch (_: Throwable) { false }

    fun hasPermission(): Boolean = try {
        if (!isAvailable()) false
        else Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    fun requestPermission() {
        try { Shizuku.requestPermission(REQUEST_CODE) } catch (_: Throwable) {}
    }

    /**
     * Grants android.permission.READ_LOGS to [packageName] using the
     * Shizuku privileged shell. Returns "granted", "permission_requested",
     * or "not_available".
     */
    fun checkAndClearAfterFlag(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val set = prefs.getBoolean(KEY_AFTER, false)
        if (set) prefs.edit().putBoolean(KEY_AFTER, false).apply()
        return set
    }

    /**
     * Revokes android.permission.READ_LOGS from [packageName] using the
     * Shizuku privileged shell. Returns "revoked", "permission_requested",
     * "not_available", or "failed".
     */
    fun revokeReadLogs(packageName: String, context: Context): String {
        if (!isAvailable()) return "not_available"
        if (!hasPermission()) {
            requestPermission()
            return "permission_requested"
        }
        return try {
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            val proc = method.invoke(null,
                arrayOf("pm", "revoke", packageName, "android.permission.READ_LOGS"),
                null, null
            ) as Process
            if (proc.waitFor() == 0) "revoked" else "failed"
        } catch (_: Exception) { "failed" }
    }

    fun grantReadLogs(packageName: String, context: Context): String {
        if (!isAvailable()) return "not_available"
        if (!hasPermission()) {
            requestPermission()
            return "permission_requested"
        }
        return try {
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            // Save flag synchronously BEFORE pm grant — process may be killed right after
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_AFTER, true).commit()
            val proc = method.invoke(null,
                arrayOf("pm", "grant", packageName, "android.permission.READ_LOGS"),
                null, null
            ) as Process
            val exit = proc.waitFor()
            if (exit == 0) "granted" else {
                context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit().putBoolean(KEY_AFTER, false).apply()
                "failed"
            }
        } catch (_: Exception) {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_AFTER, false).apply()
            "failed"
        }
    }
}
