package com.taurus.shield

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * Re-posts the last result notification after the device restarts,
 * and optionally restarts the LogCat service if auto-start is enabled.
 * Registered in AndroidManifest with RECEIVE_BOOT_COMPLETED permission.
 */
class BootReceiver : BroadcastReceiver() {

    companion object {
        const val PREFS          = "lc_boot"
        const val KEY_AUTOSTART  = "lc_autostart"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED &&
            intent.action != "android.intent.action.QUICKBOOT_POWERON"
        ) return

        NotificationHelper.createChannels(context)
        NotificationHelper.restoreAfterBoot(context)

        // Restart LogCat service if user enabled auto-start on boot
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_AUTOSTART, false)) {
            val svc = Intent(context, LogcatService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(svc)
            } else {
                context.startService(svc)
            }
        }
    }
}
