package com.taurus.shield

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

/**
 * Handles all notification duties for Taurus Shield:
 *  - Ongoing (persistent) notification while processing
 *  - Result notifications on success / failure
 *  - SharedPreferences persistence so BootReceiver can re-post after reboot
 */
object NotificationHelper {

    private const val CH_PROCESSING = "taurus_processing"
    private const val CH_RESULTS    = "taurus_results"

    const val NOTIF_PROCESSING = 1001
    const val NOTIF_RESULT     = 1002

    private const val PREFS       = "taurus_notif"
    private const val KEY_HAS     = "has_result"
    private const val KEY_SUCCESS = "success"
    private const val KEY_TITLE   = "title"
    private const val KEY_BODY    = "body"

    // ── Channel setup (call once at app start) ─────────────────────────────────
    fun createChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = notifMgr(context)

            mgr.createNotificationChannel(
                NotificationChannel(
                    CH_PROCESSING,
                    "Processing",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Shown while Taurus Shield is processing a file"
                    setShowBadge(false)
                }
            )

            mgr.createNotificationChannel(
                NotificationChannel(
                    CH_RESULTS,
                    "Results",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Notifies you when processing succeeds or fails"
                }
            )

            mgr.createNotificationChannel(
                NotificationChannel(
                    "logcat_fg",
                    "LogCat Service",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Shown while LogCat is streaming"
                    setShowBadge(false)
                }
            )

            mgr.createNotificationChannel(
                NotificationChannel(
                    "logcat_crash",
                    "Crash Alerts",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Alerts when a crash is detected in logcat"
                }
            )
        }
    }

    // ── Build a processing notification (returns Notification for startForeground) ─
    fun buildProcessingNotif(context: Context, title: String, body: String): android.app.Notification {
        return NotificationCompat.Builder(context, CH_PROCESSING)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(body)
            .setOngoing(true)
            .setAutoCancel(false)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(launchIntent(context))
            .build()
    }

    // ── Ongoing (non-dismissable) while processing ─────────────────────────────
    fun showProcessing(context: Context, title: String, body: String) {
        notifMgr(context).notify(NOTIF_PROCESSING, buildProcessingNotif(context, title, body))
    }

    // ── Result notification (auto-dismiss on tap, persisted for boot) ──────────
    fun showResult(context: Context, success: Boolean, title: String, body: String) {
        cancelProcessing(context)

        val notif = NotificationCompat.Builder(context, CH_RESULTS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(launchIntent(context))
            .build()

        notifMgr(context).notify(NOTIF_RESULT, notif)

        // Persist so BootReceiver can restore after device restart
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_HAS, true)
            .putBoolean(KEY_SUCCESS, success)
            .putString(KEY_TITLE, title)
            .putString(KEY_BODY, body)
            .apply()
    }

    // ── Cancel the ongoing processing notification ─────────────────────────────
    fun cancelProcessing(context: Context) {
        notifMgr(context).cancel(NOTIF_PROCESSING)
    }

    // ── Re-post last result after device reboot ────────────────────────────────
    fun restoreAfterBoot(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(KEY_HAS, false)) return
        val success = prefs.getBoolean(KEY_SUCCESS, true)
        val title   = prefs.getString(KEY_TITLE, "Taurus Shield") ?: return
        val body    = prefs.getString(KEY_BODY, "")  ?: return
        showResult(context, success, title, body)
    }

    // ── Private helpers ────────────────────────────────────────────────────────
    private fun notifMgr(ctx: Context) =
        ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private fun launchIntent(ctx: Context): PendingIntent {
        val intent = Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            ctx, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }
}
