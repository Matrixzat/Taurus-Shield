package com.taurus.shield

import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

object CrashBridge {
    private val queue = LinkedBlockingQueue<String>(100)

    fun notifyCrash(crashId: String) { queue.offer(crashId) }
    fun poll(timeoutMs: Long): String? = queue.poll(timeoutMs, TimeUnit.MILLISECONDS)
    fun clear() { queue.clear() }
}
