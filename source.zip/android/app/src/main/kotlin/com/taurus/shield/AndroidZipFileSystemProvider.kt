package com.taurus.shield

import android.util.Log
import java.io.FileOutputStream
import java.io.OutputStream
import java.net.URI
import java.nio.channels.SeekableByteChannel
import java.nio.file.*
import java.nio.file.attribute.*
import java.nio.file.spi.FileSystemProvider
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

// ── Android ZIP FileSystemProvider ───────────────────────────────────────────
//
// Android's java.nio.file has no "jar:" / "zip:" FileSystemProvider.
// dex2jar calls FileSystems.newFileSystem(URI("jar:file://..."), env) to write
// output JARs — which throws ProviderNotFoundException on Android, translated
// into "cant find zipfs support".
//
// This provider implements the minimum surface required for dex2jar to write
// class files into a ZIP:
//   1. newFileSystem()      — creates a ZipOutputStream-backed FileSystem
//   2. newOutputStream()    — opens a ZipEntry for writing
//   3. createDirectory()    — no-op (ZIP entries are flat)
//   4. readAttributes()     — minimal BasicFileAttributes
//   5. checkAccess()        — allow-all
//
// Register once via DexToolsService.ensureZipFs().

private const val ZFS_TAG = "AndroidZipFs"

// ── Provider ─────────────────────────────────────────────────────────────────

class AndroidZipFileSystemProvider : FileSystemProvider() {

    private val systems = ConcurrentHashMap<String, AndroidZipFileSystem>()

    override fun getScheme(): String = "jar"

    override fun newFileSystem(uri: URI, env: Map<String, *>?): FileSystem {
        val filePath = uriToPath(uri)
        val fs = AndroidZipFileSystem(this, filePath)
        systems[filePath] = fs
        Log.d(ZFS_TAG, "newFileSystem → $filePath")
        return fs
    }

    override fun getFileSystem(uri: URI): FileSystem {
        return systems[uriToPath(uri)] ?: throw FileSystemNotFoundException(uri.toString())
    }

    override fun getPath(uri: URI): Path = throw UnsupportedOperationException()

    override fun newOutputStream(path: Path, vararg options: OpenOption?): OutputStream {
        val zp = path as AndroidZipPath
        return zp.zipFs.openEntry(zp.entryName)
    }

    override fun newByteChannel(
        path: Path,
        options: MutableSet<out OpenOption>?,
        vararg attrs: FileAttribute<*>?
    ): SeekableByteChannel = throw UnsupportedOperationException("write-only zip fs")

    override fun newDirectoryStream(
        dir: Path,
        filter: DirectoryStream.Filter<in Path>?
    ): DirectoryStream<Path> = object : DirectoryStream<Path> {
        override fun iterator(): MutableIterator<Path> = mutableListOf<Path>().iterator()
        override fun close() {}
    }

    override fun createDirectory(dir: Path, vararg attrs: FileAttribute<*>?) { /* no-op */ }
    override fun delete(path: Path) { /* no-op */ }

    override fun copy(source: Path, target: Path, vararg options: CopyOption?) =
        throw UnsupportedOperationException()

    override fun move(source: Path, target: Path, vararg options: CopyOption?) =
        throw UnsupportedOperationException()

    override fun isSameFile(path: Path, path2: Path): Boolean =
        path.toString() == path2.toString()

    override fun isHidden(path: Path): Boolean = false

    override fun getFileStore(path: Path): FileStore =
        throw UnsupportedOperationException()

    override fun checkAccess(path: Path, vararg modes: AccessMode?) { /* allow all */ }

    override fun <V : FileAttributeView?> getFileAttributeView(
        path: Path, type: Class<V>?, vararg options: LinkOption?
    ): V? = null

    @Suppress("UNCHECKED_CAST")
    override fun <A : BasicFileAttributes?> readAttributes(
        path: Path, type: Class<A>?, vararg options: LinkOption?
    ): A = object : BasicFileAttributes {
        override fun lastModifiedTime(): FileTime = FileTime.fromMillis(0)
        override fun lastAccessTime(): FileTime  = FileTime.fromMillis(0)
        override fun creationTime(): FileTime    = FileTime.fromMillis(0)
        override fun isRegularFile(): Boolean    = !path.toString().let { it.endsWith("/") || it == "/" }
        override fun isDirectory(): Boolean      = path.toString().let { it.endsWith("/")  || it == "/" }
        override fun isSymbolicLink(): Boolean   = false
        override fun isOther(): Boolean          = false
        override fun size(): Long                = 0L
        override fun fileKey(): Any?             = null
    } as A

    override fun readAttributes(
        path: Path, attributes: String?, vararg options: LinkOption?
    ): Map<String, Any> = emptyMap()

    override fun setAttribute(
        path: Path, attribute: String?, value: Any?, vararg options: LinkOption?
    ) { /* no-op */ }

    private fun uriToPath(uri: URI): String =
        uri.schemeSpecificPart
            .removePrefix("file://")
            .removePrefix("//")
            .removePrefix("file:")
}

// ── FileSystem ────────────────────────────────────────────────────────────────

class AndroidZipFileSystem(
    private val prov: AndroidZipFileSystemProvider,
    private val outputFilePath: String
) : FileSystem() {

    private val zos = ZipOutputStream(FileOutputStream(outputFilePath))
    @Volatile private var open = true

    // Opens a new entry for writing; caller must close the returned stream
    // to close the entry (ZipOutputStream.closeEntry).
    fun openEntry(entryName: String): OutputStream {
        val name = entryName.trimStart('/')
        zos.putNextEntry(ZipEntry(name))
        return object : OutputStream() {
            override fun write(b: Int)                        = zos.write(b)
            override fun write(b: ByteArray, off: Int, len: Int) = zos.write(b, off, len)
            override fun flush()  = zos.flush()
            override fun close()  = zos.closeEntry()
        }
    }

    override fun provider(): FileSystemProvider = prov
    override fun close() {
        if (open) {
            open = false
            runCatching { zos.close() }
            Log.d(ZFS_TAG, "closed → $outputFilePath")
        }
    }
    override fun isOpen(): Boolean    = open
    override fun isReadOnly(): Boolean = false
    override fun getSeparator(): String = "/"
    override fun getRootDirectories(): Iterable<Path> = listOf(getPath("/"))
    override fun getFileStores(): Iterable<FileStore> = emptyList()
    override fun supportedFileAttributeViews(): Set<String> = emptySet()

    override fun getPath(first: String, vararg more: String): Path {
        val full = if (more.isEmpty()) first
        else first.trimEnd('/') + "/" + more.joinToString("/")
        return AndroidZipPath(this, full)
    }

    override fun getPathMatcher(syntaxAndPattern: String?): PathMatcher =
        throw UnsupportedOperationException()
    override fun getUserPrincipalLookupService(): UserPrincipalLookupService =
        throw UnsupportedOperationException()
    override fun newWatchService(): WatchService =
        throw UnsupportedOperationException()
}

// ── Path ──────────────────────────────────────────────────────────────────────

class AndroidZipPath(
    val zipFs: AndroidZipFileSystem,
    private val raw: String
) : Path {

    val entryName: String get() = raw.trimStart('/')

    override fun getFileSystem(): FileSystem = zipFs
    override fun isAbsolute(): Boolean = raw.startsWith("/")
    override fun getRoot(): Path? = if (isAbsolute) AndroidZipPath(zipFs, "/") else null

    override fun getFileName(): Path? {
        val name = raw.trimEnd('/').substringAfterLast('/')
        return if (name.isEmpty()) null else AndroidZipPath(zipFs, name)
    }

    override fun getParent(): Path? {
        val t = raw.trimEnd('/')
        val i = t.lastIndexOf('/')
        return if (i < 0) null
        else AndroidZipPath(zipFs, if (i == 0) "/" else t.substring(0, i))
    }

    override fun getNameCount(): Int = raw.split("/").count { it.isNotEmpty() }

    override fun getName(index: Int): Path =
        raw.split("/").filter { it.isNotEmpty() }
            .let { AndroidZipPath(zipFs, it[index]) }

    override fun subpath(beginIndex: Int, endIndex: Int): Path =
        raw.split("/").filter { it.isNotEmpty() }
            .subList(beginIndex, endIndex)
            .joinToString("/")
            .let { AndroidZipPath(zipFs, it) }

    override fun startsWith(other: Path): Boolean  = raw.startsWith(other.toString())
    override fun startsWith(other: String): Boolean = raw.startsWith(other)
    override fun endsWith(other: Path): Boolean    = raw.endsWith(other.toString())
    override fun endsWith(other: String): Boolean  = raw.endsWith(other)
    override fun normalize(): Path = this

    override fun resolve(other: Path): Path {
        val o = other.toString()
        return if (o.startsWith("/")) AndroidZipPath(zipFs, o)
        else AndroidZipPath(zipFs, raw.trimEnd('/') + "/" + o)
    }

    override fun resolve(other: String): Path {
        return if (other.startsWith("/")) AndroidZipPath(zipFs, other)
        else AndroidZipPath(zipFs, raw.trimEnd('/') + "/" + other)
    }

    override fun resolveSibling(other: Path): Path =
        (getParent() ?: AndroidZipPath(zipFs, "")).resolve(other)

    override fun resolveSibling(other: String): Path =
        (getParent() ?: AndroidZipPath(zipFs, "")).resolve(other)

    override fun relativize(other: Path): Path {
        val base = raw.trimEnd('/')
        val target = other.toString()
        return AndroidZipPath(zipFs, target.removePrefix("$base/"))
    }

    override fun toUri(): URI = URI.create("jar:file://$raw")
    override fun toAbsolutePath(): Path = if (isAbsolute) this else AndroidZipPath(zipFs, "/$raw")
    override fun toRealPath(vararg options: LinkOption?): Path = toAbsolutePath()
    override fun toFile(): java.io.File = throw UnsupportedOperationException()

    override fun register(
        watcher: WatchService, vararg events: WatchEvent.Kind<*>?
    ): WatchKey = throw UnsupportedOperationException()

    override fun register(
        watcher: WatchService?, events: Array<out WatchEvent.Kind<*>?>,
        vararg modifiers: WatchEvent.Modifier?
    ): WatchKey = throw UnsupportedOperationException()

    override fun iterator(): MutableIterator<Path> =
        raw.split("/").filter { it.isNotEmpty() }
            .map { AndroidZipPath(zipFs, it) as Path }
            .toMutableList().iterator()

    override fun compareTo(other: Path): Int = raw.compareTo(other.toString())
    override fun toString(): String = raw
    override fun equals(other: Any?): Boolean =
        other is AndroidZipPath && raw == other.raw && zipFs === other.zipFs
    override fun hashCode(): Int = 31 * System.identityHashCode(zipFs) + raw.hashCode()
}
