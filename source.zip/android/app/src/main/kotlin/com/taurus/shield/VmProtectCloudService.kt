package com.taurus.shield

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.zip.ZipFile

class VmProtectCloudService : Service() {

    companion object {
        const val PREFS           = "vmprotect_cloud_svc"
        const val KEY_RUNNING     = "running"
        const val KEY_PHASE       = "phase"
        const val KEY_LOGS        = "logs"
        const val KEY_STATUS      = "result_status"
        const val KEY_OUTPUT_DIR  = "output_dir"
        const val KEY_ERROR       = "error"
        const val KEY_FILE_NAME   = "file_name"
        const val KEY_FILE_PATH   = "file_path"
        const val KEY_JOB_ID      = "job_id"
        const val KEY_RUN_ID      = "run_id"
        const val KEY_TRIGGER_AT  = "trigger_at"
        const val KEY_STEP        = "current_step"

        private val cancelFlag   = AtomicBoolean(false)
        private var workerThread: Thread? = null

        fun cancel(context: Context) {
            cancelFlag.set(true)
            workerThread?.interrupt()
            context.stopService(Intent(context, VmProtectCloudService::class.java))
        }

        fun isRunning(context: Context): Boolean =
            context.getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_RUNNING, false)

        fun getState(context: Context): Map<String, Any?> {
            val p = context.getSharedPreferences(PREFS, MODE_PRIVATE)
            return mapOf(
                "running"     to p.getBoolean(KEY_RUNNING, false),
                "phase"       to (p.getString(KEY_PHASE, "") ?: ""),
                "logs"        to (p.getString(KEY_LOGS, "") ?: ""),
                "status"      to (p.getString(KEY_STATUS, "") ?: ""),
                "outputDir"   to (p.getString(KEY_OUTPUT_DIR, "") ?: ""),
                "error"       to (p.getString(KEY_ERROR, "") ?: ""),
                "fileName"    to (p.getString(KEY_FILE_NAME, "") ?: ""),
                "filePath"    to (p.getString(KEY_FILE_PATH, "") ?: ""),
                "jobId"       to (p.getString(KEY_JOB_ID, "") ?: ""),
                "runId"       to p.getLong(KEY_RUN_ID, 0),
                "currentStep" to (p.getString(KEY_STEP, "") ?: ""),
            )
        }

        fun clearState(context: Context) {
            context.getSharedPreferences(PREFS, MODE_PRIVATE).edit().clear().apply()
        }
    }

    private val executor = Executors.newSingleThreadExecutor()
    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var prefs: SharedPreferences
    private val logBuf = StringBuilder()

    private val WORKER by lazy { NativeSecrets.workerUrl() }

    override fun onBind(intent: Intent?): IBinder? = null

    private var signApk = true

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val filePath  = intent?.getStringExtra("filePath")  ?: return bail()
        val fileName  = intent.getStringExtra("fileName")   ?: filePath.substringAfterLast('/')
        val outputDir = intent.getStringExtra("outputDir")  ?: return bail()
        signApk       = intent.getBooleanExtra("signApk", true)

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "TaurusShield::VmProtectCloud")
        wakeLock?.acquire(60 * 60 * 1000L)

        NotificationHelper.createChannels(this)
        val notif = NotificationHelper.buildProcessingNotif(this, "VM Protect", "Uploading...")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NotificationHelper.NOTIF_PROCESSING, notif,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NotificationHelper.NOTIF_PROCESSING, notif)
        }

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        prefs.edit()
            .putBoolean(KEY_RUNNING, true)
            .putString(KEY_PHASE, "uploading")
            .putString(KEY_LOGS, "")
            .putString(KEY_STATUS, "")
            .putString(KEY_OUTPUT_DIR, outputDir)
            .putString(KEY_ERROR, "")
            .putString(KEY_FILE_NAME, fileName)
            .putString(KEY_FILE_PATH, filePath)
            .putString(KEY_JOB_ID, "")
            .putLong(KEY_RUN_ID, 0)
            .putString(KEY_STEP, "Uploading")
            .apply()

        cancelFlag.set(false)
        LogBridge.clear()

        executor.execute {
            workerThread = Thread.currentThread()
            runCloudProtection(filePath, fileName, outputDir)
        }

        return START_NOT_STICKY
    }

    private fun bail(): Int { stopSelf(); return START_NOT_STICKY }

    private fun log(line: String) {
        LogBridge.push(line)
        logBuf.appendLine(line)
        prefs.edit().putString(KEY_LOGS, logBuf.toString()).apply()
    }

    private fun updateStep(step: String) {
        prefs.edit().putString(KEY_STEP, step).apply()
        NotificationHelper.showProcessing(this, "VM Protect", step)
    }

    private fun finish(success: Boolean, outputDir: String, error: String) {
        LogBridge.done()
        prefs.edit()
            .putBoolean(KEY_RUNNING, false)
            .putString(KEY_STATUS, if (success) "success" else "error")
            .putString(KEY_OUTPUT_DIR, outputDir)
            .putString(KEY_ERROR, error)
            .putString(KEY_PHASE, "done")
            .apply()

        val fileName = prefs.getString(KEY_FILE_NAME, "file") ?: "file"
        NotificationHelper.showResult(
            this, success,
            if (success) "VM Protect — Complete" else "VM Protect — Failed",
            if (success) "$fileName protected successfully. Tap to view results."
            else "Protection failed: $error"
        )

        releaseWake()
        stopForeground(true)
        stopSelf()
    }

    private fun finishCancelled(outputDir: String) {
        cancelFlag.set(false)
        val runId = prefs.getLong(KEY_RUN_ID, 0L)
        if (runId != 0L) {
            try { workerPost("/cancel-run?run_id=$runId") } catch (_: Exception) {}
        }
        LogBridge.push("Protection cancelled by user.")
        LogBridge.done()
        prefs.edit()
            .putBoolean(KEY_RUNNING, false)
            .putString(KEY_STATUS, "cancelled")
            .putString(KEY_OUTPUT_DIR, outputDir)
            .putString(KEY_ERROR, "Cancelled by user")
            .putString(KEY_PHASE, "done")
            .apply()
        NotificationHelper.cancelProcessing(this)
        releaseWake()
        stopForeground(true)
        stopSelf()
    }

    private fun runCloudProtection(filePath: String, fileName: String, outputDir: String) {
        val file   = File(filePath)
        val ext    = file.extension.lowercase()
        val sizeMb = String.format("%.1f", file.length() / 1_048_576.0)

        try {
            // ── Validate input ───────────────────────────────────────────────
            updateStep("Validating input...")
            log("Validating input ($sizeMb MB)...")

            if (ext == "zip") {
                try {
                    val zf      = ZipFile(file)
                    val entries = zf.entries().toList()
                        .filter { !it.isDirectory }
                        .map { it.name.substringAfterLast('/').lowercase() }
                    zf.close()

                    val apkCount = entries.count { it.endsWith(".apk") }
                    if (apkCount != 1) {
                        val msg = "ZIP must contain exactly one .apk file (found $apkCount)"
                        log("ERROR: $msg")
                        finish(false, outputDir, msg); return
                    }
                    val hasRules   = entries.any { it == "rules.txt" }
                    val hasMapping = entries.any { it == "mapping.txt" }
                    log("ZIP validated: 1 APK" +
                        (if (hasRules) " + rules.txt" else "") +
                        (if (hasMapping) " + mapping.txt" else ""))
                } catch (e: Exception) {
                    log("ERROR: Invalid ZIP — ${e.message}")
                    finish(false, outputDir, "Invalid ZIP file"); return
                }
            } else if (ext == "apk") {
                log("Raw APK — will protect all classes (no rules.txt)")
            } else {
                val msg = "Unsupported file type .$ext — use .apk or .zip"
                log("ERROR: $msg")
                finish(false, outputDir, msg); return
            }

            // ── Step 1: Upload file (stall-watchdog + auto-retry) ─────────────
            // Sends ONLY the file to the worker — no workflow dispatch yet.
            // Keeping upload and dispatch as separate requests means neither
            // request risks hitting Cloudflare's 30-second wall-clock limit.
            val signParam   = if (signApk) "true" else "false"
            val contentType = if (ext == "apk") "application/octet-stream" else "application/zip"
            val uploadPath  = "/upload-asset?ext=$ext"
            val maxAttempts = 3
            var uploadJson: String? = null
            var attempt = 0
            while (uploadJson == null && attempt < maxAttempts && !cancelFlag.get()) {
                attempt++
                if (attempt > 1) {
                    val wait = attempt * 4_000L
                    log("Connection stalled — retrying ($attempt/$maxAttempts) in ${wait/1000}s...")
                    updateStep("Retrying... ($attempt/$maxAttempts)")
                    Thread.sleep(wait)
                    if (cancelFlag.get()) { finishCancelled(outputDir); return }
                }
                updateStep("Uploading $sizeMb MB...${if (attempt > 1) " (attempt $attempt)" else ""}")
                if (attempt == 1) log("Uploading to secure protection cluster...")
                uploadJson = workerPostFile(uploadPath, file, contentType)
                if (uploadJson == null && attempt < maxAttempts && !cancelFlag.get()) {
                    log("Attempt $attempt failed — will retry")
                }
            }
            if (uploadJson == null) {
                log("Upload failed after $attempt attempt(s) — check connection")
                finish(false, outputDir, "Upload failed"); return
            }

            val uploadObj = JSONObject(uploadJson)
            val jobId   = uploadObj.getString("job_id")
            val assetId = uploadObj.getLong("asset_id")
            log("Upload complete. Job ID: $jobId")

            // ── Step 2: Dispatch workflow (fast separate call ~1 s) ────────────
            // Worker dispatches vm-protect.yml with the asset_id and returns
            // immediately — this request is far under the 30-second CF limit.
            updateStep("Dispatching to cluster...")
            log("Dispatching to VM protection cluster...")
            val dispatchPath = "/dispatch-job?workflow=vm-protect.yml" +
                               "&asset_id=$assetId&job_id=$jobId&sign_apk=$signParam"
            val dispatchJson = withNetworkRetry("dispatch") { workerGet(dispatchPath) }
            if (dispatchJson == null) {
                log("Dispatch failed — no network after retries")
                finish(false, outputDir, "Could not reach protection engine"); return
            }

            val triggerAt = System.currentTimeMillis()
            prefs.edit()
                .putString(KEY_JOB_ID, jobId)
                .putLong(KEY_TRIGGER_AT, triggerAt)
                .putString(KEY_PHASE, "finding_run")
                .apply()
            Thread.sleep(4_000)
            if (cancelFlag.get()) { finishCancelled(outputDir); return }

            // ── Find workflow run ─────────────────────────────────────────────
            val runId = findRun(triggerAt)
            if (cancelFlag.get()) { finishCancelled(outputDir); return }
            if (runId == null) {
                log("Could not reach the protection engine")
                finish(false, outputDir, "Could not reach protection engine"); return
            }

            prefs.edit()
                .putLong(KEY_RUN_ID, runId)
                .putString(KEY_PHASE, "polling")
                .apply()

            log("VM protection started — streaming live progress...")
            val success = pollUntilDone(runId)
            if (cancelFlag.get()) { finishCancelled(outputDir); return }
            if (!success) {
                log("Protection engine returned a failure")
                finish(false, outputDir, "Protection failed"); return
            }

            // Worker streams the protected APK directly — no CDN URL needed.
            prefs.edit().putString(KEY_PHASE, "downloading").apply()
            updateStep("Downloading results...")
            log("Downloading protected APK...")

            File(outputDir).mkdirs()

            val outApk = File(outputDir, "protected.apk")
            val downloaded = withNetworkRetry("download") {
                if (workerDownloadToFile("/vm-result?job_id=$jobId", outApk)) true else null
            } == true
            if (!downloaded) {
                log("Could not download protected APK after retries")
                finish(false, outputDir, "Download failed"); return
            }
            log("Protected APK: ${outApk.length() / 1024}KB")
            finish(true, outputDir, "")

        } catch (e: Exception) {
            if (cancelFlag.get() || e is InterruptedException) {
                finishCancelled(outputDir)
            } else {
                log("Cloud error: ${e.message}")
                finish(false, outputDir, e.message ?: "Unknown error")
            }
        }
    }

    private fun findRun(afterMs: Long): Long? {
        repeat(40) { attempt ->
            Thread.sleep(3_000)
            if (cancelFlag.get()) return null
            val body = workerGet("/find-run?after=$afterMs&workflow=vm-protect.yml") ?: run {
                log("Waiting for cluster node... (${(attempt + 1) * 3}s)"); return@repeat
            }
            val json = JSONObject(body)
            if (json.optBoolean("found")) {
                val runId = json.getLong("run_id")
                log("Node acquired (task #${json.optInt("run_number")})")
                updateStep("Node acquired")
                return runId
            }
            log("Waiting for cluster node... (${(attempt + 1) * 3}s)")
        }
        return null
    }

    private fun pollUntilDone(runId: Long): Boolean {
        var lastStep            = ""
        var sameStepCount       = 0
        var activePolls         = 0
        val maxActive           = 540
        var consecutiveNetFails = 0

        while (activePolls < maxActive) {
            Thread.sleep(5_000)
            if (cancelFlag.get()) return false

            val elapsed    = activePolls * 5
            val elapsedStr = if (elapsed >= 60) "${elapsed / 60}m ${elapsed % 60}s" else "${elapsed}s"

            val liveBody = workerGet("/job-live?run_id=$runId")
            var gotLive  = false
            if (liveBody != null) {
                try {
                    val liveJson    = JSONObject(liveBody)
                    val currentStep = liveJson.optString("current_step", "")
                    val done        = liveJson.optInt("completed_count", 0)
                    val total       = liveJson.optInt("total_steps", 0)
                    if (currentStep.isNotEmpty()) {
                        gotLive = true
                        if (currentStep != lastStep) {
                            sameStepCount = 0
                            val progress = if (total > 0) " ($done/$total)" else ""
                            val friendly = friendlyStepName(currentStep)
                            log("⚙ $friendly$progress")
                            updateStep(friendly)
                            lastStep = currentStep
                        } else {
                            sameStepCount++
                            if (sameStepCount % 2 == 0) {
                                val friendly = friendlyStepName(currentStep)
                                log("   ⏳ $friendly — $elapsedStr")
                                updateStep("$friendly ($elapsedStr)")
                            }
                        }
                    }
                } catch (_: Exception) {}
            }
            val body = workerGet("/status?run_id=$runId")
            if (body == null) {
                consecutiveNetFails++
                if (!gotLive) {
                    log("   ⚠ Network unavailable — waiting to reconnect... ($consecutiveNetFails)")
                    updateStep("Waiting for network...")
                }
                continue   // don't count this poll — network is down
            }
            consecutiveNetFails = 0
            activePolls++

            if (!gotLive) log("   ⏳ waiting... $elapsedStr")
            val json       = JSONObject(body)
            val status     = json.optString("status")
            val conclusion = json.optString("conclusion")

            if (status == "completed") {
                if (conclusion != "success") {
                    log("── VM protection engine error ──")
                    try {
                        val errorDetail = workerGet("/job-error?run_id=$runId")
                        if (!errorDetail.isNullOrBlank()) {
                            errorDetail.lines().map { it.trim() }.filter { it.isNotEmpty() }
                                .takeLast(12).forEach { log(it) }
                        }
                    } catch (_: Exception) {}
                }
                return conclusion == "success"
            }
        }
        log("Timed out waiting for VM protection cluster.")
        return false
    }

    private fun friendlyStepName(step: String): String = when {
        step.contains("Download", true) && step.contains("asset", true)  -> "Downloading uploaded file..."
        step.contains("Delete asset", true)                               -> "Cleaning upload slot..."
        step.contains("Detect", true) && step.contains("extract", true)  -> "Extracting APK..."
        step.contains("system dep", true) || step.contains("Install system", true) -> "Installing system tools..."
        step.contains("NDK", true) && step.contains("Download", true)    -> "Downloading Android NDK..."
        step.contains("SDK", true)                                        -> "Resolving Android SDK..."
        step.contains("vm-protect", true) || step.contains("vm protect", true) -> "Downloading VM Protect engine..."
        step.contains("Run VM", true) || step.contains("protect", true)  -> "Converting to native code..."
        step.contains("Collect", true) || step.contains("output", true)  -> "Collecting protected APK..."
        step.contains("Sign APK", true)                                   -> "Signing APK..."
        step.contains("Upload", true) && (step.contains("artifact", true) || step.contains("result", true)) -> "Packaging output..."
        step.contains("error log", true)                                  -> "Collecting error logs..."
        step.contains("Set up job", true)                                 -> "Preparing environment..."
        step.contains("Complete job", true)                               -> "Finalizing..."
        else -> step
    }

    /**
     * POST [file] to the Cloudflare Worker at [path].
     *
     * Stall watchdog: a daemon thread checks byte-progress every 5 s.
     * If no bytes have moved for STALL_MS (30 s) it calls conn.disconnect(),
     * converting a silent hang into an IOException that the retry loop catches.
     *
     * 256 KB buffer: larger chunks reduce syscall overhead on fast links.
     */
    private fun workerPostFile(path: String, file: File, contentType: String): String? {
        val STALL_MS = 30_000L
        val total    = file.length()
        val conn     = (URL(WORKER + path).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", contentType)
            setRequestProperty("Content-Length", total.toString())
            connectTimeout = 30_000
            readTimeout    = 120_000   // response-read timeout (after upload finishes)
            doOutput       = true
            setFixedLengthStreamingMode(total)
        }

        val lastProgressAt = AtomicLong(System.currentTimeMillis())
        val uploadDone     = AtomicBoolean(false)

        // Watchdog thread — kills the connection if upload stalls
        val watchdog = Thread {
            try {
                while (!uploadDone.get()) {
                    Thread.sleep(5_000)
                    if (!uploadDone.get() && System.currentTimeMillis() - lastProgressAt.get() > STALL_MS) {
                        conn.disconnect()   // unblocks the write in the upload thread
                        break
                    }
                }
            } catch (_: InterruptedException) {}
        }.also { it.isDaemon = true; it.start() }

        var sent = 0L; var lastPct = -1
        val buf  = ByteArray(256 * 1024)   // 256 KB chunks
        return try {
            file.inputStream().use { inp ->
                conn.outputStream.use { out ->
                    var n: Int
                    while (inp.read(buf).also { n = it } != -1) {
                        out.write(buf, 0, n)
                        sent += n
                        lastProgressAt.set(System.currentTimeMillis())   // feed watchdog
                        val pct = ((sent * 99) / total).toInt()
                        if (pct != lastPct) {
                            lastPct = pct
                            LogBridge.push("DOWNLOAD_PROGRESS:$pct")
                            if (pct % 10 == 0) updateStep("Uploading... $pct%")
                        }
                    }
                }
            }
            uploadDone.set(true)
            LogBridge.push("DOWNLOAD_PROGRESS:100")
            val code = conn.responseCode
            val body = try { conn.inputStream.bufferedReader().readText() } catch (_: Exception) { null }
            conn.disconnect()
            if (code in 200..299) body else null
        } catch (_: Exception) {
            uploadDone.set(true)
            try { conn.disconnect() } catch (_: Exception) {}
            null
        } finally {
            uploadDone.set(true)
            watchdog.interrupt()
        }
    }

    private fun workerGet(path: String): String? {
        val conn = (URL(WORKER + path).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout    = 30_000
        }
        val code = conn.responseCode
        val body = try { conn.inputStream.bufferedReader().readText() } catch (_: Exception) { null }
        conn.disconnect()
        return if (code in 200..299) body else null
    }

    private fun workerDownloadToFile(path: String, outFile: File): Boolean {
        val conn = (URL(WORKER + path).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30_000
            readTimeout    = 180_000
        }
        if (conn.responseCode !in 200..299) { conn.disconnect(); return false }
        val total = conn.contentLengthLong.takeIf { it > 0 } ?: 1L
        var done  = 0L; var lastPct = -1
        val buf   = ByteArray(32_768)
        conn.inputStream.use { inp ->
            FileOutputStream(outFile).use { out ->
                var n: Int
                while (inp.read(buf).also { n = it } != -1) {
                    out.write(buf, 0, n); done += n
                    val pct = ((done * 100) / total).toInt().coerceIn(0, 99)
                    if (pct != lastPct) {
                        lastPct = pct
                        LogBridge.push("DOWNLOAD_PROGRESS:$pct")
                        if (pct % 10 == 0) updateStep("Downloading... $pct%")
                    }
                }
            }
        }
        conn.disconnect()
        LogBridge.push("DOWNLOAD_PROGRESS:100")
        return true
    }

    private fun directDownloadToFile(url: String, outFile: File): Boolean {
        val conn = (java.net.URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout          = 30_000
            readTimeout             = 300_000
            instanceFollowRedirects = true
        }
        if (conn.responseCode !in 200..299) { conn.disconnect(); return false }
        val total = conn.contentLengthLong.takeIf { it > 0 } ?: 1L
        var done  = 0L; var lastPct = -1
        val buf   = ByteArray(256 * 1024)
        conn.inputStream.use { inp ->
            FileOutputStream(outFile).use { out ->
                var n: Int
                while (inp.read(buf).also { n = it } != -1) {
                    out.write(buf, 0, n); done += n
                    val pct = ((done * 100) / total).toInt().coerceIn(0, 99)
                    if (pct != lastPct) {
                        lastPct = pct
                        LogBridge.push("DOWNLOAD_PROGRESS:$pct")
                        if (pct % 10 == 0) updateStep("Downloading... $pct%")
                    }
                }
            }
        }
        conn.disconnect()
        LogBridge.push("DOWNLOAD_PROGRESS:100")
        return true
    }

    // ── Network retry helper ──────────────────────────────────────────────────
    // Cloud job keeps running on the server even when network is off.
    // This only retries the HTTP call — never restarts the cloud job.
    private fun <T> withNetworkRetry(
        label: String,
        maxAttempts: Int = 40,
        delayMs: Long = 15_000L,
        isSuccess: (T?) -> Boolean = { it != null },
        block: () -> T?
    ): T? {
        var attempt = 0
        while (attempt < maxAttempts) {
            if (cancelFlag.get()) return null
            val result = try { block() } catch (_: Exception) { null }
            if (isSuccess(result)) return result
            attempt++
            if (attempt >= maxAttempts) break
            log("   ⚠ Network unavailable — retrying $label in ${delayMs / 1000}s... ($attempt/$maxAttempts)")
            updateStep("Waiting for network...")
            try { Thread.sleep(delayMs) } catch (_: InterruptedException) { return null }
        }
        return null
    }

    private fun workerPost(path: String) {
        try {
            val conn = (URL(WORKER + path).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput      = false
                connectTimeout = 10_000
                readTimeout    = 10_000
            }
            conn.responseCode; conn.disconnect()
        } catch (_: Exception) {}
    }

    private fun releaseWake() {
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
    }

    override fun onDestroy() { releaseWake(); super.onDestroy() }
}
