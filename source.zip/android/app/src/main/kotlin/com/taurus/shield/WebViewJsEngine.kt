package com.taurus.shield

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

class WebViewJsEngine(private val context: Context) {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var webView: WebView? = null
    private val readyLatch = CountDownLatch(1)
    private val results = ConcurrentHashMap<String, LinkedBlockingQueue<Pair<Boolean, String>>>()

    companion object {
        const val TIMEOUT_S = 240L
        private const val ASSET_JC  = "jsenc/js_confuser.js"
        private const val ASSET_WC  = "jsenc/webcrack.js"
    }

    init {
        // Libraries are read from APK assets on a background thread, then WebView is
        // initialised on the main thread. readyLatch is released by NativeAndroid.onReady()
        // called from JS after all three <script> blocks have executed.
        Thread {
            val jcJs = readAsset(ASSET_JC)
            val wcJs = readAsset(ASSET_WC)
            val html = buildHtml(jcJs, wcJs)
            mainHandler.post { initWebView(html) }
        }.also { it.isDaemon = true }.start()
    }

    /** Read a raw text asset from the APK. Returns an error comment on failure. */
    private fun readAsset(path: String): String {
        return try {
            context.assets.open(path).bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (e: Exception) {
            "/* ASSET_READ_FAILED: $path — ${e.message} */"
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun initWebView(html: String) {
        val wv = WebView(context.applicationContext)
        wv.settings.apply {
            javaScriptEnabled  = true
            cacheMode          = WebSettings.LOAD_NO_CACHE
            domStorageEnabled  = true
            allowFileAccess    = true
            allowContentAccess = true
        }
        wv.addJavascriptInterface(AndroidBridge(), "NativeAndroid")
        // onPageFinished fires when HTML is parsed; NOT when JS has executed.
        // Readiness is signalled by NativeAndroid.onReady() called from JS itself.
        wv.webViewClient = object : WebViewClient() { /* intentionally empty */ }
        wv.loadDataWithBaseURL("https://localhost/", html, "text/html", "UTF-8", null)
        webView = wv
    }

    private fun buildHtml(jcJs: String, wcJs: String): String {
        val engineJs = buildEngineJs()
        // IMPORTANT: do NOT wrap jcJs/wcJs in IIFEs. The browser.js bundles use UMD/var patterns
        // that assign globals via 'this' or top-level 'var'. An IIFE traps those into function scope,
        // making JsConfuser/webcrack invisible to subsequent scripts. Plain <script> tags execute
        // at true global scope so 'var JsConfuser' and UMD 'root.JsConfuser' reach window correctly.
        return """<!DOCTYPE html>
<html><head><meta charset="UTF-8">
<script>
// Stubs required by Node.js-derived bundles running in WebView
if (typeof process === 'undefined') { var process = { env: {}, argv: [], version: '', platform: 'browser' }; }
if (typeof Buffer === 'undefined') { var Buffer = { isBuffer: function(){ return false; } }; }
if (typeof global === 'undefined') { var global = window; }
</script>
<script>
try {
$jcJs
} catch(e) { console.error('jc-load-err:'+e); }
</script>
<script>
try {
$wcJs
} catch(e) { console.error('wc-load-err:'+e); }
</script>
<script>
try {
$engineJs
} catch(e) {
  console.error('engine-err:'+e);
  try { NativeAndroid.onError('INIT', 'Engine init failed: '+e.message); } catch(_){}
  try { NativeAndroid.onReady(); } catch(_){}
}
</script>
</head><body></body></html>"""
    }

    private fun buildEngineJs(): String = NativeSecrets.jsEncConfigs()

    fun encrypt(code: String, method: String): String = callJs("doEncrypt", code, method)

    fun decrypt(code: String): String = callJs("doDecrypt", code, null)

    fun subzero(html: String, key: String): String = callJs("doSubZero", html, key)

    private fun callJs(fn: String, code: String, method: String?): String {
        waitReady()
        val id = UUID.randomUUID().toString()
        val queue = LinkedBlockingQueue<Pair<Boolean, String>>(1)
        results[id] = queue
        val escaped = escapeJs(code)
        val js = when (fn) {
            "doEncrypt" -> "window.doEncrypt('$id','$escaped','$method');"
            "doDecrypt" -> "window.doDecrypt('$id','$escaped');"
            else        -> "window.doSubZero('$id','$escaped','${escapeJs(method ?: "")}');"
        }
        mainHandler.post { webView?.evaluateJavascript(js, null) }
        val pair = queue.poll(TIMEOUT_S, TimeUnit.SECONDS)
            ?: throw RuntimeException("JS engine timed out after ${TIMEOUT_S}s — try again")
        val (ok, res) = pair
        if (!ok) throw RuntimeException(res)
        return res
    }

    fun destroy() {
        mainHandler.post { webView?.destroy(); webView = null }
    }

    private fun waitReady() {
        if (!readyLatch.await(120, TimeUnit.SECONDS)) {
            throw RuntimeException("WebView engine did not initialize within 120s — try restarting the app")
        }
    }

    private fun escapeJs(s: String): String =
        s.replace("\\", "\\\\")
         .replace("'", "\\'")
         .replace("\n", "\\n")
         .replace("\r", "\\r")
         .replace("\u2028", "\\u2028")
         .replace("\u2029", "\\u2029")

    inner class AndroidBridge {
        @JavascriptInterface
        fun onReady() {
            // Called from JS after ALL scripts have executed.
            // This is the correct point — JsConfuser and webcrack are now available.
            readyLatch.countDown()
        }

        @JavascriptInterface
        fun onResult(id: String, result: String) {
            results.remove(id)?.offer(Pair(true, result))
        }

        @JavascriptInterface
        fun onError(id: String, error: String) {
            results.remove(id)?.offer(Pair(false, error))
        }
    }
}
