package com.taurus.shield

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class WebApkBridge(private val context: Context) : MethodChannel.MethodCallHandler {

    private val executor = Executors.newSingleThreadExecutor()

    private val WORKER by lazy { NativeSecrets.workerUrl() }

    companion object {

        const val PREFS          = "webapk_bridge"
        const val KEY_RUNNING    = "running"
        const val KEY_PHASE      = "phase"
        const val KEY_PROGRESS   = "progress"
        const val KEY_LOGS       = "logs"
        const val KEY_STATUS     = "status"
        const val KEY_OUTPUT     = "output_path"
        const val KEY_ERROR      = "error"
        const val KEY_APP_NAME   = "app_name"

        @Volatile var cancelFlag = false

        fun getState(context: Context): Map<String, Any?> {
            val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            return mapOf(
                "running"    to p.getBoolean(KEY_RUNNING, false),
                "phase"      to (p.getString(KEY_PHASE,   "") ?: ""),
                "progress"   to p.getInt(KEY_PROGRESS, 0),
                "logs"       to (p.getString(KEY_LOGS,    "") ?: ""),
                "status"     to (p.getString(KEY_STATUS,  "") ?: ""),
                "outputPath" to (p.getString(KEY_OUTPUT,  "") ?: ""),
                "error"      to (p.getString(KEY_ERROR,   "") ?: ""),
                "appName"    to (p.getString(KEY_APP_NAME,"") ?: ""),
            )
        }

        fun clearState(context: Context) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
        }
    }

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "webapk_cloud_build"  -> startCloudBuild(call, result)
            "webapk_state"        -> result.success(getState(context))
            "webapk_cancel"       -> {
                cancelFlag = true
                WebApkService.stop(context)
                result.success(true)
            }
            "webapk_clear"        -> { clearState(context); result.success(true) }
            "webapk_install"      -> installApk(call, result)
            else                  -> result.notImplemented()
        }
    }

    private fun installApk(call: MethodCall, result: MethodChannel.Result) {
        val path = call.argument<String>("path") ?: run {
            result.error("NO_PATH", "path required", null); return
        }
        val file = File(path)
        if (!file.exists()) { result.error("NOT_FOUND", "APK not found", null); return }
        try {
            // On Android 13+ the FileProvider metadata lookup can silently fail when an
            // Activity context is used and the file lives on external storage outside the
            // app-specific directory.  Two fixes applied here:
            //
            //  1. Copy the APK into the app's cache dir so it is always covered by
            //     <cache-path name="cache_files" path="."> in file_paths.xml.
            //  2. Use applicationContext for the FileProvider call — the Application
            //     context is always stable and correctly resolves provider metadata.
            val appCtx = context.applicationContext
            val cacheApk = File(appCtx.cacheDir, file.name).also { dest ->
                if (!dest.exists() || dest.length() != file.length()) {
                    file.copyTo(dest, overwrite = true)
                }
            }
            val uri = androidx.core.content.FileProvider.getUriForFile(
                appCtx, "${appCtx.packageName}.fileprovider", cacheApk
            )
            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            result.success(true)
        } catch (e: Exception) {
            result.error("INSTALL_FAIL", e.message, null)
        }
    }

    // ── finish helper ─────────────────────────────────────────────────────────

    private fun finish(
        prefs: SharedPreferences,
        success: Boolean,
        outputPath: String,
        error: String,
        logBuf: StringBuilder
    ) {
        LogBridge.done()
        prefs.edit()
            .putBoolean(KEY_RUNNING, false)
            .putInt(KEY_PROGRESS, if (success) 100 else 0)
            .putString(KEY_PHASE,  "done")
            .putString(KEY_STATUS, if (success) "success" else "error")
            .putString(KEY_OUTPUT, outputPath)
            .putString(KEY_ERROR,  error)
            .putString(KEY_LOGS,   logBuf.toString())
            .apply()

        WebApkService.stop(context)

        val appName = prefs.getString(KEY_APP_NAME, "App") ?: "App"
        if (success) {
            NotificationHelper.showResult(
                context, true,
                "APK Ready — $appName",
                "Saved to Taurus-Shield/output/web2apk/"
            )
        } else if (error != "Cancelled") {
            NotificationHelper.showResult(
                context, false,
                "Web 2 Apk Build Failed",
                error.take(120)
            )
        }
    }

    // ── Cloud Build ───────────────────────────────────────────────────────────

    private fun startCloudBuild(call: MethodCall, result: MethodChannel.Result) {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (p.getBoolean(KEY_RUNNING, false)) {
            result.error("BUSY", "Build already running", null); return
        }
        val configJson = call.argument<String>("configJson")
            ?: run { result.error("NO_CONFIG", "configJson required", null); return }
        val iconBase64 = call.argument<String>("iconBase64")   ?: ""
        val lottieB64  = call.argument<String>("lottieBase64") ?: ""
        val appName    = call.argument<String>("appName")      ?: "My App"
        val outputDir  = call.argument<String>("outputDir")    ?: ""

        cancelFlag = false

        p.edit()
            .putBoolean(KEY_RUNNING, true)
            .putString(KEY_PHASE,   "initialising")
            .putInt(KEY_PROGRESS,   0)
            .putString(KEY_LOGS,    "")
            .putString(KEY_STATUS,  "")
            .putString(KEY_OUTPUT,  "")
            .putString(KEY_ERROR,   "")
            .putString(KEY_APP_NAME, appName)
            .apply()

        result.success(true)
        WebApkService.start(context, "Cloud Build — $appName")

        executor.execute { runCloudBuild(configJson, iconBase64, lottieB64, appName, outputDir) }
    }

    private fun runCloudBuild(
        configJson: String, iconBase64: String, lottieB64: String, appName: String, outputDir: String
    ) {
        val prefs  = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val logBuf = StringBuilder()
        fun log(s: String) {
            LogBridge.push(s)
            logBuf.appendLine(s)
            prefs.edit().putString(KEY_LOGS, logBuf.toString()).apply()
        }
        fun progress(pct: Int, phase: String) {
            prefs.edit().putInt(KEY_PROGRESS, pct).putString(KEY_PHASE, phase).apply()
        }

        try {
            log("Web2Apk — Cloud Build")
            progress(2, "preparing")

            val cfg = org.json.JSONObject(configJson)
            val confSb = StringBuilder()
            confSb.append("mainURL = ${cfg.optString("mainURL", "https://example.com")}\n")
            confSb.append("name = ${cfg.optString("appName", appName)}\n")
            confSb.append("id = ${cfg.optString("packageId", "com.example.myapp")}\n")
            confSb.append("requireDoubleBackToExit = true\n")
            confSb.append("allowSubdomains = true\n")
            confSb.append("enableExternalLinks = true\n")
            confSb.append("openExternalLinksInBrowser = false\n")
            confSb.append("JSEnabled = true\n")
            confSb.append("DomStorageEnabled = true\n")
            confSb.append("DatabaseEnabled = true\n")
            confSb.append("SavePassword = true\n")
            confSb.append("AllowFileAccess = true\n")
            confSb.append("geolocationEnabled = true\n")
            confSb.append("forceLandscapeMode = false\n")
            confSb.append("edgeToEdge = ${cfg.optBoolean("edgeToEdge", false)}\n")
            confSb.append("forceDarkTheme = ${cfg.optBoolean("darkTheme", true)}\n")
            confSb.append("enablePullToRefresh = ${cfg.optBoolean("pullRefresh", true)}\n")
            confSb.append("biometricLockEnabled = ${cfg.optBoolean("biometric", false)}\n")
            confSb.append("biometricTimeoutMinutes = ${cfg.optInt("bioTimeoutMin", 5)}\n")
            confSb.append("biometricType = ${cfg.optString("bioType", "both")}\n")
            confSb.append("signApk = ${cfg.optBoolean("signApk", true)}\n")
            confSb.append("versionName = ${cfg.optString("versionName", "1.0.0")}\n")
            confSb.append("versionCode = ${cfg.optInt("versionCode", 1)}\n")
            confSb.append("screenshotPrevention = ${cfg.optBoolean("screenshotPrevention", false)}\n")
            confSb.append("zoomEnabled = ${cfg.optBoolean("zoomEnabled", false)}\n")
            val deepLinkEnabled = cfg.optBoolean("deepLinkEnabled", false)
            confSb.append("deepLinkEnabled = $deepLinkEnabled\n")
            val deepLinkScheme = cfg.optString("deepLinkScheme", "").trim()
            if (deepLinkEnabled && deepLinkScheme.isNotEmpty()) {
                confSb.append("deepLinkScheme = $deepLinkScheme\n")
            }
            confSb.append("incognitoOnExit = ${cfg.optBoolean("incognitoOnExit", false)}\n")
            confSb.append("pipEnabled = ${cfg.optBoolean("pipEnabled", false)}\n")

            val iconBytes: ByteArray? = if (iconBase64.isNotEmpty()) {
                try { Base64.decode(iconBase64, Base64.DEFAULT) } catch (_: Exception) { null }
            } else null
            val lottieBytes: ByteArray? = if (lottieB64.isNotEmpty()) {
                try { Base64.decode(lottieB64, Base64.DEFAULT) } catch (_: Exception) { null }
            } else null
            if (iconBytes != null) confSb.append("icon = icon.png\n")
            val confStr = confSb.toString()

            val workDir = File(context.filesDir, "webapk_cloud").apply { mkdirs() }
            val zipFile = File(workDir, "webapk_input_${System.currentTimeMillis()}.zip")
            log("Preparing build package...")
            progress(5, "packing")
            ZipOutputStream(zipFile.outputStream().buffered()).use { zout ->
                zout.putNextEntry(ZipEntry("webapk.conf"))
                zout.write(confStr.toByteArray(Charsets.UTF_8))
                zout.closeEntry()
                if (iconBytes != null) {
                    zout.putNextEntry(ZipEntry("icon.png"))
                    zout.write(iconBytes); zout.closeEntry()
                    log("Icon: included (${iconBytes.size / 1024} KB)")
                } else {
                    log("Icon: using template default")
                }
                if (lottieBytes != null) {
                    zout.putNextEntry(ZipEntry("custom_splash.json"))
                    zout.write(lottieBytes); zout.closeEntry()
                    log("Lottie splash: included (${lottieBytes.size / 1024} KB)")
                }
            }
            log("Build package: ${zipFile.length() / 1024} KB")

            if (cancelFlag) { finish(prefs, false, "", "Cancelled", logBuf); zipFile.delete(); return }

            progress(8, "uploading")
            log("Uploading build package...")
            var uploadBody: String? = null
            run retryUpload@{
                var uAttempt = 0
                while (uAttempt < 40 && uploadBody == null) {
                    if (cancelFlag) return@retryUpload
                    uploadBody = cbWorkerPost("/upload-asset?ext=zip", zipFile) { pct ->
                        LogBridge.push("DOWNLOAD_PROGRESS:$pct")
                    }
                    if (uploadBody == null) {
                        uAttempt++
                        if (uAttempt >= 40) return@retryUpload
                        log("   ⚠ Network unavailable — retrying upload in 15s... ($uAttempt/40)")
                        try { Thread.sleep(15_000) } catch (_: InterruptedException) { return@retryUpload }
                    }
                }
            }
            zipFile.delete()
            if (uploadBody == null) {
                finish(prefs, false, "", "Upload failed — no network after retries", logBuf); return
            }
            val uploadJson = org.json.JSONObject(uploadBody)
            val jobId   = uploadJson.optString("job_id")
            val assetId = uploadJson.optLong("asset_id")
            if (assetId == 0L) {
                finish(prefs, false, "", "Upload failed", logBuf); return
            }
            log("Package uploaded successfully")

            if (cancelFlag) {
                cbWorkerDelete("/asset?asset_id=$assetId")
                finish(prefs, false, "", "Cancelled", logBuf); return
            }

            progress(18, "dispatching")
            log("Dispatching to build cluster...")
            val triggerAt    = System.currentTimeMillis()
            val dispatchPath = "/dispatch-job?workflow=webapk-build.yml&asset_id=$assetId&job_id=$jobId"
            var dispatchCode = -1
            run retryDispatch@{
                var dAttempt = 0
                while (dAttempt < 40 && dispatchCode !in 200..299) {
                    if (cancelFlag) return@retryDispatch
                    val (c, _) = cbWorkerGetWithCode(dispatchPath)
                    dispatchCode = c
                    if (dispatchCode == -1) {
                        dAttempt++
                        if (dAttempt >= 40) return@retryDispatch
                        log("   ⚠ Network unavailable — retrying dispatch in 15s... ($dAttempt/40)")
                        try { Thread.sleep(15_000) } catch (_: InterruptedException) { return@retryDispatch }
                    }
                }
            }
            if (dispatchCode !in 200..299) {
                finish(prefs, false, "", "Dispatch failed (HTTP $dispatchCode)", logBuf); return
            }
            log("Build dispatched — job $jobId")
            progress(22, "finding_run")

            Thread.sleep(4_000)
            if (cancelFlag) { finish(prefs, false, "", "Cancelled", logBuf); return }

            val runId = cbFindRun(triggerAt, "webapk-build.yml") { msg -> log(msg) }
            if (cancelFlag) { finish(prefs, false, "", "Cancelled", logBuf); return }
            if (runId == null) {
                cbWorkerDelete("/asset?asset_id=$assetId")
                finish(prefs, false, "", "Could not reach build cluster", logBuf); return
            }
            log("Build in progress...")
            progress(30, "building")

            val success = cbPollUntilDone(runId) { pct, step ->
                progress(pct, "building")
                log(step)
            }
            if (cancelFlag) { finish(prefs, false, "", "Cancelled", logBuf); return }
            if (!success) {
                log("Fetching build logs...")
                cbFetchJobLogs(runId) { msg -> log(msg) }
                finish(prefs, false, "", "Build failed", logBuf); return
            }

            progress(88, "downloading")
            log("Downloading signed APK...")
            val saveDir = if (outputDir.isNotEmpty()) File(outputDir).apply { mkdirs() }
                          else File(context.getExternalFilesDir(null), "output/web2apk").apply { mkdirs() }
            val tmpZip  = File(saveDir, "_webapk_tmp.zip")
            var downloaded = false
            run retryDownload@{
                var dlAttempt = 0
                while (dlAttempt < 40 && !downloaded) {
                    if (cancelFlag) return@retryDownload
                    downloaded = cbWorkerDownload(
                        "/artifact?run_id=$runId&job_id=$jobId&prefix=webapk", tmpZip) { pct ->
                        LogBridge.push("DOWNLOAD_PROGRESS:$pct")
                    }
                    if (!downloaded) {
                        dlAttempt++
                        if (dlAttempt >= 40) return@retryDownload
                        log("   ⚠ Network unavailable — retrying download in 15s... ($dlAttempt/40)")
                        try { Thread.sleep(15_000) } catch (_: InterruptedException) { return@retryDownload }
                    }
                }
            }
            if (!downloaded) {
                finish(prefs, false, "", "Download failed — no network after retries", logBuf); return
            }

            progress(95, "extracting")
            log("Extracting APK...")
            var apkFile: File? = null
            ZipInputStream(tmpZip.inputStream().buffered()).use { zin ->
                var entry = zin.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory && entry.name.endsWith(".apk", ignoreCase = true)) {
                        val safeName = "${appName.replace(Regex("[^a-zA-Z0-9_.-]"), "_")}.apk"
                        apkFile = File(saveDir, safeName)
                        apkFile!!.outputStream().use { out -> zin.copyTo(out) }
                        break
                    }
                    entry = zin.nextEntry
                }
            }
            tmpZip.delete()

            if (apkFile == null || !apkFile!!.exists()) {
                finish(prefs, false, "", "APK not found in build output", logBuf); return
            }
            log("Build complete: ${apkFile!!.name} (${apkFile!!.length() / 1024} KB)")
            log("Saved to Taurus-Shield folder")
            finish(prefs, true, apkFile!!.absolutePath, "", logBuf)

        } catch (e: Throwable) {
            if (cancelFlag || e is InterruptedException) {
                finish(prefs, false, "", "Cancelled", logBuf)
            } else {
                try { log("Cloud error: ${e.message}") } catch (_: Throwable) {}
                try { finish(prefs, false, "", e.message ?: "Unknown error", logBuf) } catch (_: Throwable) {}
            }
        }
    }

    private fun cbWorkerGet(path: String): String? {
        return try {
            val conn = (URL(WORKER + path).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000; readTimeout = 30_000
            }
            val code = conn.responseCode
            val body = try { conn.inputStream.bufferedReader().readText() } catch (_: Exception) { null }
            conn.disconnect()
            if (code in 200..299) body else null
        } catch (_: Exception) { null }
    }

    private fun cbWorkerGetWithCode(path: String): Pair<Int, String?> {
        return try {
            val conn = (URL(WORKER + path).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000; readTimeout = 30_000
            }
            val code = conn.responseCode
            val body = try {
                if (code in 200..299) conn.inputStream.bufferedReader().readText()
                else conn.errorStream?.bufferedReader()?.readText()
            } catch (_: Exception) { null }
            conn.disconnect()
            Pair(code, body)
        } catch (e: Exception) {
            Pair(-1, e.message)
        }
    }

    private fun cbWorkerPost(path: String, file: File, onProgress: (Int) -> Unit): String? {
        return try {
            val total = file.length()
            val conn = (URL(WORKER + path).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/octet-stream")
                setRequestProperty("Content-Length", total.toString())
                connectTimeout = 30_000; readTimeout = 600_000
                doOutput = true
                setFixedLengthStreamingMode(total)
            }
            var sent = 0L; var lastPct = -1
            val buf = ByteArray(65_536)
            file.inputStream().use { inp ->
                conn.outputStream.use { out ->
                    var n: Int
                    while (inp.read(buf).also { n = it } != -1) {
                        out.write(buf, 0, n); sent += n
                        val pct = ((sent * 99) / total).toInt()
                        if (pct != lastPct) { lastPct = pct; onProgress(pct) }
                    }
                }
            }
            onProgress(100)
            val code = conn.responseCode
            val body = if (code in 200..299) {
                try { conn.inputStream.bufferedReader().readText() } catch (_: Exception) { null }
            } else null
            conn.disconnect()
            body
        } catch (_: Exception) { null }
    }

    private fun cbFetchJobLogs(runId: Long, log: (String) -> Unit) {
        try {
            val text = cbWorkerGet("/job-error?run_id=$runId") ?: return
            log("─────────────────────────────────────────")
            text.lines().forEach { log(it) }
        } catch (_: Exception) {}
    }

    private fun cbFindRun(afterMs: Long, workflow: String, log: (String) -> Unit): Long? {
        repeat(40) { attempt ->
            Thread.sleep(3_000)
            if (cancelFlag) return null
            val body = cbWorkerGet("/find-run?after=$afterMs&workflow=$workflow")
                ?: run { log("Waiting for build node... (${(attempt + 1) * 3}s)"); return@repeat }
            val json = org.json.JSONObject(body)
            if (json.optBoolean("found")) {
                val runId = json.getLong("run_id")
                log("Build node acquired (task #${json.optInt("run_number")})")
                return runId
            }
            log("Waiting for build node... (${(attempt + 1) * 3}s)")
        }
        return null
    }

    private fun cbPollUntilDone(runId: Long, onUpdate: (Int, String) -> Unit): Boolean {
        var lastStep            = ""
        var activePolls         = 0
        val maxActive           = 600
        var consecutiveNetFails = 0

        while (activePolls < maxActive) {
            Thread.sleep(5_000)
            if (cancelFlag) return false

            val elapsed    = activePolls * 5
            val elapsedStr = if (elapsed >= 60) "${elapsed / 60}m ${elapsed % 60}s" else "${elapsed}s"

            val liveBody = cbWorkerGet("/job-live?run_id=$runId")
            if (liveBody != null) {
                try {
                    val lj    = org.json.JSONObject(liveBody)
                    val step  = lj.optString("current_step", "")
                    val done  = lj.optInt("completed_count", 0)
                    val total = lj.optInt("total_steps", 0)
                    if (step.isNotEmpty() && step != lastStep) {
                        lastStep = step
                        val pct  = (30 + if (total > 0) (done * 55) / total else 0).coerceIn(30, 85)
                        val prog = if (total > 0) " ($done/$total)" else ""
                        onUpdate(pct, "⚙ $step$prog")
                    }
                } catch (_: Exception) {}
            }

            val statusBody = cbWorkerGet("/status?run_id=$runId")
            if (statusBody == null) {
                consecutiveNetFails++
                onUpdate(50, "   ⚠ Network unavailable — waiting to reconnect... ($consecutiveNetFails)")
                continue   // don't count this poll — network down, cloud job still running
            }
            consecutiveNetFails = 0
            activePolls++

            if (liveBody == null) onUpdate(50, "   ⏳ building... $elapsedStr")

            val json = org.json.JSONObject(statusBody)
            if (json.optString("status") == "completed") {
                return json.optString("conclusion") == "success"
            }
        }
        return false
    }

    private fun cbWorkerDownload(path: String, outFile: File, onProgress: (Int) -> Unit): Boolean {
        return try {
            val conn = (URL(WORKER + path).openConnection() as HttpURLConnection).apply {
                connectTimeout = 30_000; readTimeout = 300_000
            }
            if (conn.responseCode !in 200..299) { conn.disconnect(); return false }
            val total = conn.contentLengthLong.takeIf { it > 0 } ?: 1L
            var done  = 0L; var lastPct = -1
            val buf   = ByteArray(32_768)
            conn.inputStream.use { inp ->
                FileOutputStream(outFile).use { out ->
                    var n: Int
                    while (inp.read(buf).also { n = it } != -1) {
                        out.write(buf, 0, n); done += n
                        val pct = ((done * 100) / total).toInt().coerceIn(0, 99)
                        if (pct != lastPct) { lastPct = pct; onProgress(pct) }
                    }
                }
            }
            conn.disconnect(); onProgress(100); true
        } catch (_: Exception) { false }
    }

    private fun cbWorkerDelete(path: String) {
        try {
            val conn = (URL(WORKER + path).openConnection() as HttpURLConnection).apply {
                requestMethod = "DELETE"; connectTimeout = 10_000; readTimeout = 10_000
            }
            conn.responseCode; conn.disconnect()
        } catch (_: Exception) {}
    }

    /** Returns true if [file] is readable and starts with a valid ZIP local-file header (PK\x03\x04). */
    private fun isValidZip(file: File): Boolean {
        return try {
            file.inputStream().use { ins ->
                val sig = ByteArray(4)
                ins.read(sig) == 4 &&
                sig[0] == 0x50.toByte() && sig[1] == 0x4B.toByte() &&
                sig[2] == 0x03.toByte() && sig[3] == 0x04.toByte()
            }
        } catch (_: Exception) { false }
    }

    private operator fun ByteArray.plus(other: ByteArray): ByteArray {
        val result = ByteArray(this.size + other.size)
        System.arraycopy(this, 0, result, 0, this.size)
        System.arraycopy(other, 0, result, this.size, other.size)
        return result
    }
}
