package com.taurus.shield

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class LogcatService : Service() {

    companion object {
        const val ACTION_START   = "logcat_start"
        const val ACTION_STOP    = "logcat_stop"
        const val ACTION_CLEAR   = "logcat_clear"
        const val ACTION_RESTART = "logcat_restart"
        const val EXTRA_USE_ROOT = "use_root"
        private const val NOTIF_ID         = 9010
        private const val CRASH_NOTIF_BASE = 9020
        @Volatile private var activeInstance: LogcatService? = null
        fun invalidateCrashHashes() { activeInstance?.savedLogHashes?.clear() }
    }

    private val running    = AtomicBoolean(false)
    @Volatile private var restarting = false
    private val executor   = Executors.newSingleThreadExecutor()
    @Volatile private var process: Process? = null
    // When true, logcat itself is launched through `su -c` so the OS reads
    // logs as root and READ_LOGS permission is bypassed entirely. Sticky
    // across the lifetime of the service; updated on every START / RESTART
    // intent so the UI can switch modes between sessions.
    @Volatile private var useRoot = false

    // ── crash collector ────────────────────────────────────────────────────────
    private val crashLines        = mutableListOf<String>()
    private var collectCrash      = false
    private var crashPkg          = "unknown"
    private var crashType         = "FATAL"
    // How many consecutive non-AndroidRuntime lines have appeared during a Java crash
    private var nonCrashLineCount = 0

    // ── deduplication: skip re-saving the same crash within 15 seconds ─────────
    private var lastSavedPkg  = ""
    private var lastSavedType = ""
    private var lastSavedTime = 0L
    private val DEDUP_MS      = 15_000L

    // ── content-hash dedup: never save a crash whose log text was already stored ─
    private val savedLogHashes = mutableSetOf<Int>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        activeInstance = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Always honour the latest useRoot preference from the caller. The
        // value sticks until the next intent overrides it, so RESTART/CLEAR
        // intents without the extra preserve the current mode.
        if (intent?.hasExtra(EXTRA_USE_ROOT) == true) {
            useRoot = intent.getBooleanExtra(EXTRA_USE_ROOT, false)
        }
        when (intent?.action) {
            ACTION_STOP  -> {
                // Wipe all crash logs and session state so the app never
                // auto-redirects or shows stale data after exit.
                crashFile().delete()
                savedLogHashes.clear()
                CrashBridge.clear()
                try {
                    getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
                        .edit()
                        .remove("flutter.lc_session_active")
                        .remove("flutter.ss_last_tool")
                        .apply()
                } catch (_: Exception) {}
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_CLEAR -> { clearLogcat(); return START_NOT_STICKY }
            ACTION_RESTART -> {
                // Atomically kill old stream and queue a fresh one.
                // restarting=true suppresses LogcatBridge.done() so the Dart stream stays open.
                restarting = true
                running.set(false)
                try { process?.destroy() } catch (_: Exception) {}
                executor.execute {
                    // Runs after old startStream task exits
                    restarting = false
                    if (running.compareAndSet(false, true)) startStreamBody()
                }
                return START_STICKY
            }
        }
        if (!running.getAndSet(true)) {
            crashFile().delete()
            savedLogHashes.clear()
            startForeground(NOTIF_ID, buildLoggingNotif())
            startStream()
        }
        return START_STICKY
    }

    private fun startStream() { executor.execute { startStreamBody() } }

    private var crashDetectionStartMs = 0L

    private fun isLineAfterStart(line: String): Boolean {
        if (crashDetectionStartMs <= 0L) return true
        val m = Regex("""^(\d{2})-(\d{2})\s+(\d{2}):(\d{2}):(\d{2})\.(\d{3})""").find(line)
            ?: return false
        val (mo, da, hh, mm, ss, ms) = m.destructured
        val cal = java.util.Calendar.getInstance()
        cal.set(cal.get(java.util.Calendar.YEAR),
            mo.toInt() - 1, da.toInt(), hh.toInt(), mm.toInt(), ss.toInt())
        cal.set(java.util.Calendar.MILLISECOND, ms.toInt())
        return cal.timeInMillis >= crashDetectionStartMs - 3000
    }

    private fun startStreamBody() {
        crashDetectionStartMs = System.currentTimeMillis()
        try {
            // On rooted devices we wrap logcat in `su -c` so the OS allows
            // reading without the READ_LOGS permission. The first invocation
            // pops a SuperUser/Magisk prompt — once approved, subsequent
            // logcat calls run silently.
            val proc = if (useRoot) {
                Runtime.getRuntime().exec(
                    arrayOf("su", "-c", "logcat -v threadtime *:V")
                )
            } else {
                Runtime.getRuntime().exec(
                    arrayOf("logcat", "-v", "threadtime", "*:V")
                )
            }
            process = proc
            val br = BufferedReader(InputStreamReader(proc.inputStream), 8192)
            var line: String? = null
            while (running.get() && br.readLine().also { line = it } != null) {
                val l = line ?: continue
                LogcatBridge.offer(l)
                if (isLineAfterStart(l)) checkCrash(l)
            }
        } catch (_: Exception) {
        } finally {
            running.set(false)
            // Do NOT send DONE during restart — the Dart stream must stay alive
            if (!restarting) LogcatBridge.done()
        }
    }

    private fun clearLogcat() {
        try {
            val p = if (useRoot) {
                Runtime.getRuntime().exec(arrayOf("su", "-c", "logcat -c"))
            } else {
                Runtime.getRuntime().exec(arrayOf("logcat", "-c"))
            }
            p.waitFor()
        } catch (_: Exception) {}
        LogcatBridge.clear()
    }

    // ── crash detection ────────────────────────────────────────────────────────
    private fun checkCrash(line: String) {
        when {
            // ── Java crash (FATAL EXCEPTION from AndroidRuntime / any thread) ──
            line.contains("FATAL EXCEPTION") -> {
                // Save any in-progress crash before starting a new one
                if (collectCrash && crashLines.size > 3) saveCrash()
                crashLines.clear(); collectCrash = true; crashType = "Java"
                nonCrashLineCount = 0
                crashPkg = pkgFromLogcatLine(line) ?: "unknown"
                crashLines.add(line)
            }
            // ── JNI crash (NDK/ART error) ──────────────────────────────────────
            line.contains("JNI DETECTED ERROR") || line.contains("JNI ERROR") -> {
                if (collectCrash && crashLines.size > 3) saveCrash()
                crashLines.clear(); collectCrash = true; crashType = "JNI"
                nonCrashLineCount = 0
                crashPkg = pkgFromLogcatLine(line) ?: parsePackageFromLine(line)
                crashLines.add(line)
            }
            // ── ANR ───────────────────────────────────────────────────────────
            line.contains("ANR in") -> {
                if (collectCrash && crashLines.size > 3) saveCrash()
                crashLines.clear(); collectCrash = true; crashType = "ANR"
                nonCrashLineCount = 0
                crashPkg = Regex("""ANR in\s+(\S+)""")
                    .find(line)?.groupValues?.getOrNull(1)
                    ?.split("(")?.firstOrNull()?.trim() ?: "unknown"
                crashLines.add(line)
            }
            // ── Native crash (F DEBUG or F crash_dump — *** *** header) ───────
            !collectCrash && line.contains("*** ***") &&
                (line.contains("DEBUG") || line.contains("crash_dump")) -> {
                crashLines.clear(); collectCrash = true; crashType = "Native"
                nonCrashLineCount = 0
                crashPkg = pkgFromLogcatLine(line) ?: "unknown"
                crashLines.add(line)
            }
            // ── WTF (What a Terrible Failure — F WTF tag) ─────────────────────
            !collectCrash && line.contains(" F WTF") -> {
                crashLines.clear(); collectCrash = true; crashType = "WTF"
                nonCrashLineCount = 0
                crashPkg = pkgFromLogcatLine(line) ?: "unknown"
                crashLines.add(line)
            }
            collectCrash -> {
                crashLines.add(line)
                // For Java crashes: fallback pkg from "Process: com.pkg, PID:"
                if (crashPkg == "unknown" && line.contains(": Process: ")) {
                    crashPkg = Regex("""Process:\s*(\S+)""")
                        .find(line)?.groupValues?.getOrNull(1)
                        ?.trimEnd(',') ?: "unknown"
                }
                // For native crashes: extract pkg from ">>> com.pkg <<<"
                if (crashPkg == "unknown" && line.contains(">>>")) {
                    crashPkg = Regex(""">>>\s*(\S+)\s*<<<""")
                        .find(line)?.groupValues?.getOrNull(1) ?: "unknown"
                }

                // Track non-AndroidRuntime lines for Java crash end detection
                if (crashType == "Java") {
                    if (!line.contains("AndroidRuntime") && line.isNotBlank()) {
                        nonCrashLineCount++
                    } else {
                        nonCrashLineCount = 0
                    }
                }

                val done = crashLines.size >= 120 ||
                    (crashLines.size > 10 && line.isBlank()) ||
                    // Java: stack trace is over when 3+ unrelated lines arrive after 8+ collected
                    (crashType == "Java" && crashLines.size > 8 && nonCrashLineCount >= 3)
                if (done) { saveCrash(); collectCrash = false }
            }
        }
    }

    /**
     * Logcat threadtime format: "MM-DD HH:MM:SS.mmm  PID  TID  LEVEL  TAG: msg"
     * Field index 2 (0-based) is the PID. We read /proc/{pid}/cmdline which
     * contains the process name (= package name for Android apps).
     */
    private fun pkgFromLogcatLine(line: String): String? {
        return try {
            val pid = line.trim().split(Regex("\\s+")).getOrNull(2) ?: return null
            pid.toLong() // verify it's a number
            val cmdline = File("/proc/$pid/cmdline").readText()
                .replace('\u0000', ' ').trim().split(" ").firstOrNull()?.trim()
            if (cmdline.isNullOrEmpty() || cmdline == "unknown") null
            else cmdline.split(":").firstOrNull()?.trim() ?: cmdline
        } catch (_: Exception) { null }
    }

    private fun parsePackageFromLine(line: String): String {
        return Regex("""([a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]*){2,})""")
            .findAll(line).lastOrNull()?.value ?: "unknown"
    }

    private fun loadExistingHashes() {
        if (savedLogHashes.isNotEmpty()) return
        try {
            val arr = loadCrashes()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val log = obj.optString("log", "")
                if (log.isNotEmpty()) {
                    savedLogHashes.add(log.trim().hashCode())
                }
            }
        } catch (_: Exception) {}
    }

    private fun saveCrash() {
        val now = System.currentTimeMillis()
        // Skip if the exact same app + type crashed less than 15 seconds ago
        if (crashPkg == lastSavedPkg && crashType == lastSavedType &&
                (now - lastSavedTime) < DEDUP_MS) {
            crashLines.clear()
            collectCrash = false
            return
        }

        val logText = crashLines.joinToString("\n")
        val logHash = logText.trim().hashCode()

        // Skip if we already have a crash with identical log content
        loadExistingHashes()
        if (logHash in savedLogHashes) {
            crashLines.clear()
            collectCrash = false
            return
        }

        lastSavedPkg  = crashPkg
        lastSavedType = crashType
        lastSavedTime = now
        savedLogHashes.add(logHash)

        val arr    = loadCrashes()
        val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm:ss", Locale.getDefault())
        sdf.timeZone = java.util.TimeZone.getDefault()
        val ts = sdf.format(Date())
        val id     = System.currentTimeMillis().toString()
        val appName = resolveAppName(crashPkg)
        arr.put(JSONObject().apply {
            put("id",          id)
            put("timestamp",   ts)
            put("packageName", crashPkg)
            put("appName",     appName)
            put("type",        crashType)
            put("log",         logText)
        })
        crashFile().writeText(arr.toString())
        CrashBridge.notifyCrash(id)
        showCrashNotif(appName, crashPkg, crashType, id, logText)
        crashLines.clear()
    }

    private fun resolveAppName(pkg: String): String {
        if (pkg == "unknown" || pkg.isEmpty()) return pkg
        return try {
            // Use 0 flags — much faster than GET_META_DATA; we only need the label
            @Suppress("DEPRECATION")
            val info = packageManager.getApplicationInfo(pkg, 0)
            packageManager.getApplicationLabel(info).toString()
        } catch (_: Exception) { pkg }
    }

    fun crashFile(): File = File(filesDir, "logcat_crashes.json")

    fun loadCrashes(): JSONArray = try {
        JSONArray(crashFile().readText())
    } catch (_: Exception) { JSONArray() }

    // ── recording ──────────────────────────────────────────────────────────────
    fun recordingsDir(): File = File(filesDir, "logcat_recordings").also { it.mkdirs() }

    // ── notifications ──────────────────────────────────────────────────────────
    private fun buildLoggingNotif(): Notification {
        val stopIntent = Intent(this, LogcatService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPi = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openPi = PendingIntent.getActivity(
            this, 1,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, "logcat_fg")
            .setContentTitle("Logging")
            .setContentText("Capturing all app logs — tap to open")
            .setSmallIcon(R.drawable.ic_notification)
            .setOngoing(true)
            .setContentIntent(openPi)
            .addAction(android.R.drawable.ic_delete, "Exit", stopPi)
            .build()
    }

    private fun showCrashNotif(
        appName: String, pkg: String, type: String, id: String, logText: String
    ) {
        val notifId = CRASH_NOTIF_BASE + (id.takeLast(3).toIntOrNull() ?: 0)
        val firstLine = logText.lines().firstOrNull { it.isNotBlank() } ?: pkg

        // Tap notification → open app
        val openPi = PendingIntent.getActivity(
            this, notifId,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("open_logcat_crashes", true)
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        // Copy action → CopyReceiver
        val copyIntent = Intent(this, CopyReceiver::class.java).apply {
            action = CopyReceiver.ACTION_COPY_CRASH
            putExtra(CopyReceiver.EXTRA_LOG, logText)
            putExtra(CopyReceiver.EXTRA_NOTIF_ID, notifId)
        }
        val copyPi = PendingIntent.getBroadcast(
            this, notifId + 1, copyIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val displayName = if (appName != pkg && appName.isNotEmpty()) appName else pkg
        val title = if (type == "ANR") "$displayName not responding" else "$displayName crashed"

        val nm      = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val chId    = getOrCreateCrashChannel(nm, pkg, displayName)
        val n  = NotificationCompat.Builder(this, chId)
            .setContentTitle(title)
            .setContentText(firstLine)
            .setStyle(NotificationCompat.BigTextStyle().bigText(firstLine))
            .setSmallIcon(R.drawable.ic_notification)
            .setAutoCancel(true)
            .setContentIntent(openPi)
            .addAction(android.R.drawable.ic_menu_share, "Copy", copyPi)
            .build()
        nm.notify(notifId, n)
    }

    // ── per-app notification channel ───────────────────────────────────────────
    private fun getOrCreateCrashChannel(
        nm: NotificationManager, pkg: String, appName: String
    ): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return "logcat_crash"
        val chId = "lc_crash_${pkg.replace('.', '_').take(40)}"
        if (nm.getNotificationChannel(chId) == null) {
            val chName = if (appName != pkg && appName.isNotEmpty())
                "$appName Crashes" else "Crashes – $pkg"
            nm.createNotificationChannel(
                NotificationChannel(chId, chName, NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Crash & ANR alerts from $appName ($pkg)"
                }
            )
        }
        return chId
    }

    override fun onDestroy() {
        activeInstance = null
        running.set(false)
        try { process?.destroy() } catch (_: Exception) {}
        LogcatBridge.done()
        super.onDestroy()
    }
}
