package com.taurus.shield

import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

object LogcatBridge {
    const val DONE = "__LOGCAT_DONE__"
    private val queue = LinkedBlockingQueue<String>(30_000)

    fun offer(line: String) { if (!queue.offer(line)) queue.poll(); queue.offer(line) }
    fun poll(timeoutMs: Long): String? = queue.poll(timeoutMs, TimeUnit.MILLISECONDS)
    fun done()  { queue.clear(); queue.offer(DONE) }
    fun clear() { queue.clear() }
    fun drainStale() { queue.clear() }
}
