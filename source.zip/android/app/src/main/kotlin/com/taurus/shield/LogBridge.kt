package com.taurus.shield

import java.util.concurrent.LinkedBlockingQueue

/**
 * Singleton log queue that bridges Python stdout → Kotlin → Flutter EventChannel.
 * Python calls LogBridge.push() via Chaquopy's jclass mechanism.
 * Kotlin drains the queue and forwards each line to the Flutter EventSink.
 *
 * "Copying entries... [X/Y]" lines emitted by the Pine bridge are collapsed into
 * a single "Assembling APK..." header + a final "  Assembled: N entries" tail so
 * the log panel stays clean during the ZIP-copy phase.
 */
object LogBridge {

    const val DONE = "__TAURUS_DONE__"

    private val queue = LinkedBlockingQueue<String>()

    private val COPY_RE = Regex("""^Copying entries\.\.\. \[(\d+)/(\d+)]$""")

    @Volatile private var packingStarted = false
    @Volatile private var packingTotal   = 0

    @JvmStatic
    fun push(line: String?) {
        if (line.isNullOrBlank()) return
        val m = COPY_RE.find(line.trim())
        if (m != null) {
            val current = m.groupValues[1].toIntOrNull() ?: 0
            val total   = m.groupValues[2].toIntOrNull() ?: 0
            if (!packingStarted) {
                packingStarted = true
                packingTotal   = total
                queue.offer("Assembling APK...")
            }
            if (current >= total) {
                queue.offer("  Assembled: $total entries")
                packingStarted = false
                packingTotal   = 0
            }
            return
        }
        queue.offer(line)
    }

    @JvmStatic
    fun done() {
        queue.offer(DONE)
    }

    @JvmStatic
    fun poll(timeoutMs: Long = 100): String? =
        queue.poll(timeoutMs, java.util.concurrent.TimeUnit.MILLISECONDS)

    @JvmStatic
    fun clear() {
        queue.clear()
        packingStarted = false
        packingTotal   = 0
    }
}
