package com.taurus.shield

import android.Manifest
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageInstaller
import android.content.pm.PackageManager
import android.net.Uri
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.net.NetworkInterface
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : FlutterActivity() {

    private val HBC_CHANNEL      = "com.taurus.shield/hbc"
    private val STORE_CHANNEL    = "com.taurus.shield/storage"
    private val LOG_CHANNEL      = "com.taurus.shield/log_stream"
    private val NOTIF_CHANNEL    = "com.taurus.shield/notification"
    private val LOGCAT_STREAM    = "com.taurus.shield/logcat_stream"
    private val CRASH_STREAM     = "com.taurus.shield/crash_stream"
    private val LOGCAT_CHANNEL   = "com.taurus.shield/logcat"
    private val FORGE_CHANNEL    = "com.taurus.shield/forge"
    private val WEBAPK_CHANNEL   = "com.taurus.shield/webapk"
    private val SECRETS_CHANNEL  = "com.taurus.shield/secrets"
    private val PYTHON_CHANNEL   = "com.taurus.shield/python_idle"
    private val DEX_TOOLS_CHANNEL = "com.taurus.shield/dex_tools"
    private val COCOS_CHANNEL     = "com.taurus.shield/cocos"

    private val executor        = Executors.newSingleThreadExecutor()
    private val logExecutor     = Executors.newSingleThreadExecutor()
    private val logcatExecutor  = Executors.newSingleThreadExecutor()
    private val crashExecutor   = Executors.newSingleThreadExecutor()
    private val mainHandler     = Handler(Looper.getMainLooper())

    // ── Self-update state ──────────────────────────────────────────────────────
    private val REQ_INSTALL_PERM = 7429
    // Saved while waiting for the user to grant install permission in Settings
    private var pendingInstallUri: Uri? = null
    private var pendingInstallFileUri: String = ""
    // Saved PackageInstaller confirmation intent — launched on next onResume()
    // if startActivity() failed because the Activity was in the background
    private var pendingConfirmIntent: Intent? = null
    @Volatile private var installerLaunched = false
    @Volatile private var isAppInForeground = false

    // ── SAF document save (ACTION_CREATE_DOCUMENT) ─────────────────────────────
    private val REQ_CREATE_DOC = 8833
    private var pendingDocBytes: ByteArray? = null
    private var pendingDocResult: io.flutter.plugin.common.MethodChannel.Result? = null

    // ── WiFi IP helper — finds the device's own wlan/wifi IPv4 address ─────────
    private fun getWifiIp(): String {
        try {
            val ifaces = NetworkInterface.getNetworkInterfaces() ?: return "127.0.0.1"
            for (iface in ifaces.asSequence()) {
                val name = iface.name.lowercase()
                if (!name.startsWith("wlan") && !name.startsWith("wifi") &&
                    !name.startsWith("eth") && !name.startsWith("rmnet")) continue
                for (addr in iface.inetAddresses.asSequence()) {
                    if (addr.isLoopbackAddress) continue
                    val ip = addr.hostAddress ?: continue
                    if (ip.contains(':')) continue  // skip IPv6
                    return ip
                }
            }
        } catch (_: Exception) {}
        return "127.0.0.1"
    }

    // ── Activity lifecycle ─────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        if (NativeSecrets.isUnderAttack()) {
            startActivity(Intent(this, TamperActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            })
            finish()
            return
        }
        super.onCreate(savedInstanceState)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_INSTALL_PERM) {
            val uri  = pendingInstallUri  ?: return
            val fUri = pendingInstallFileUri
            pendingInstallUri     = null
            pendingInstallFileUri = ""
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                packageManager.canRequestPackageInstalls()) {
                installViaSession(uri, fUri)
            }
        }
        if (requestCode == REQ_CREATE_DOC) {
            val docResult = pendingDocResult
            val docBytes  = pendingDocBytes
            pendingDocResult = null
            pendingDocBytes  = null
            val uri = data?.data
            if (uri != null && docBytes != null) {
                try {
                    contentResolver.openOutputStream(uri)?.use { out -> out.write(docBytes) }
                    docResult?.success("ok")
                } catch (e: Exception) {
                    docResult?.error("WRITE_ERROR", e.message, null)
                }
            } else {
                docResult?.success(null) // user cancelled
            }
        }
    }

    override fun onResume() {
        super.onResume()
        isAppInForeground  = true
        installerLaunched  = false

        LogcatBridge.drainStale()
        LogBridge.clear()

        pendingConfirmIntent?.let { intent ->
            pendingConfirmIntent = null
            installerLaunched = true
            try { startActivity(intent) } catch (_: Exception) {
                installerLaunched = false
            }
        }
    }

    override fun onStop() {
        super.onStop()
        isAppInForeground = false
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        if (!Python.isStarted()) {
            Python.start(AndroidPlatform(this))
        }

        NotificationHelper.createChannels(this)

        // ── Live log streaming ───────────────────────────────────────────────
        EventChannel(flutterEngine.dartExecutor.binaryMessenger, LOG_CHANNEL)
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, events: EventChannel.EventSink) {
                    val pumping = AtomicBoolean(true)
                    logExecutor.execute {
                        while (pumping.get()) {
                            if (!isAppInForeground) {
                                Thread.sleep(500L)
                                continue
                            }
                            val line = LogBridge.poll(100L)
                            when {
                                line == null       -> { }
                                line == LogBridge.DONE -> {
                                    pumping.set(false)
                                    mainHandler.post { events.endOfStream() }
                                }
                                else -> mainHandler.post { events.success(line) }
                            }
                        }
                    }
                }
                override fun onCancel(arguments: Any?) { LogBridge.done() }
            })

        // ── LogCat live stream ───────────────────────────────────────────────
        EventChannel(flutterEngine.dartExecutor.binaryMessenger, LOGCAT_STREAM)
            .setStreamHandler(object : EventChannel.StreamHandler {
                @Volatile var activePumping: AtomicBoolean? = null

                override fun onListen(arguments: Any?, events: EventChannel.EventSink) {
                    activePumping?.set(false)
                    val pumping = AtomicBoolean(true)
                    activePumping = pumping
                    logcatExecutor.execute {
                        while (pumping.get()) {
                            if (!isAppInForeground) {
                                Thread.sleep(500L)
                                continue
                            }
                            val first = LogcatBridge.poll(150L) ?: continue
                            if (first == LogcatBridge.DONE) {
                                pumping.set(false); activePumping = null
                                mainHandler.post { events.endOfStream() }
                                break
                            }
                            val batch = ArrayList<String>(200).also { it.add(first) }
                            var done = false
                            for (i in 0 until 199) {
                                val next = LogcatBridge.poll(0L) ?: break
                                if (next == LogcatBridge.DONE) { done = true; break }
                                batch.add(next)
                            }
                            val copy = ArrayList(batch)
                            if (done) {
                                pumping.set(false); activePumping = null
                                mainHandler.post { events.success(copy); events.endOfStream() }
                                break
                            }
                            mainHandler.post { events.success(copy) }
                            Thread.sleep(150L)
                        }
                    }
                }
                override fun onCancel(arguments: Any?) {
                    activePumping?.set(false)          // stop consuming events, keep service alive
                    activePumping = null
                }
            })

        // ── Crash event stream (notifies Flutter instantly on new crash) ─────
        EventChannel(flutterEngine.dartExecutor.binaryMessenger, CRASH_STREAM)
            .setStreamHandler(object : EventChannel.StreamHandler {
                @Volatile var pumping: AtomicBoolean? = null

                override fun onListen(arguments: Any?, events: EventChannel.EventSink) {
                    pumping?.set(false)
                    val p = AtomicBoolean(true)
                    pumping = p
                    crashExecutor.execute {
                        while (p.get()) {
                            val id = CrashBridge.poll(500L) ?: continue
                            mainHandler.post { events.success(id) }
                        }
                    }
                }
                override fun onCancel(arguments: Any?) {
                    pumping?.set(false)
                    pumping = null
                    CrashBridge.clear()
                }
            })

        // ── Mod Engine — Unity IL2CPP game modding via GitHub Actions ────────
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "com.taurus.shield/mod_engine")
            .setMethodCallHandler { call, result ->
                val prefs = getSharedPreferences(ModEngineService.PREFS, Context.MODE_PRIVATE)
                when (call.method) {

                    "startDump" -> {
                        val zipPath = call.argument<String>("zip_path") ?: run {
                            result.error("INVALID_ARG", "zip_path required", null)
                            return@setMethodCallHandler
                        }
                        startService(Intent(this, ModEngineService::class.java).apply {
                            action = ModEngineService.ACTION_DUMP
                            putExtra(ModEngineService.EXTRA_ZIP_PATH, zipPath)
                        })
                        result.success(null)
                    }

                    "startPatch" -> {
                        val apkPath  = call.argument<String>("apk_path") ?: run {
                            result.error("INVALID_ARG", "apk_path required", null)
                            return@setMethodCallHandler
                        }
                        val gameName = call.argument<String>("game_name") ?: "game"
                        val features = call.argument<String>("features_json") ?: "[]"
                        startService(Intent(this, ModEngineService::class.java).apply {
                            action = ModEngineService.ACTION_BUILD
                            putExtra(ModEngineService.EXTRA_APK_PATH, apkPath)
                            putExtra(ModEngineService.EXTRA_GAME_NAME, gameName)
                            putExtra(ModEngineService.EXTRA_FEATURES_JSON, features)
                        })
                        result.success(null)
                    }

                    "getState" -> {
                        result.success(mapOf(
                            "running"            to (prefs.getBoolean(ModEngineService.KEY_RUNNING, false)),
                            "phase"              to (prefs.getString(ModEngineService.KEY_PHASE, "") ?: ""),
                            "logs"               to (prefs.getString(ModEngineService.KEY_LOGS, "") ?: ""),
                            "result_status"      to (prefs.getString(ModEngineService.KEY_STATUS, "") ?: ""),
                            "result"             to (prefs.getString(ModEngineService.KEY_RESULT, "") ?: ""),
                            "dump_cs_path"       to (prefs.getString(ModEngineService.KEY_DUMP_CS, "") ?: ""),
                            "dump_h_path"        to (prefs.getString(ModEngineService.KEY_DUMP_H, "") ?: ""),
                            "script_json_path"   to (prefs.getString(ModEngineService.KEY_SCRIPT_JSON, "") ?: ""),
                            "stringliteral_path" to (prefs.getString(ModEngineService.KEY_STRING_LIT, "") ?: ""),
                            "ida_py_path"        to (prefs.getString(ModEngineService.KEY_IDA_PY, "") ?: ""),
                            "ida_struct_path"    to (prefs.getString(ModEngineService.KEY_IDA_STRUCT, "") ?: ""),
                            "ghidra_py_path"     to (prefs.getString(ModEngineService.KEY_GHIDRA_PY, "") ?: ""),
                            "job_id"             to (prefs.getString(ModEngineService.KEY_JOB_ID, "") ?: ""),
                            "progress"           to (prefs.getInt(ModEngineService.KEY_PROGRESS, -1)),
                        ))
                    }

                    "clearState" -> {
                        ModEngineService.clearState(this)
                        result.success(null)
                    }

                    "installApk" -> {
                        val path = call.argument<String>("path") ?: run {
                            result.error("INVALID_ARG", "path required", null)
                            return@setMethodCallHandler
                        }
                        try {
                            val file = File(path)
                            val uri  = androidx.core.content.FileProvider.getUriForFile(
                                this, "$packageName.fileprovider", file)
                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(uri, "application/vnd.android.package-archive")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            startActivity(intent)
                            result.success(null)
                        } catch (e: Exception) {
                            result.error("INSTALL_ERROR", e.message, null)
                        }
                    }

                    "stopService" -> {
                        startService(Intent(this, ModEngineService::class.java).apply {
                            action = ModEngineService.ACTION_STOP
                        })
                        result.success(null)
                    }

                    "modEngine_cancel" -> {
                        ModEngineService.cancel(this)
                        result.success(null)
                    }

                    // Read the package name from any APK file without installing it
                    "getApkPackage" -> {
                        val path = call.argument<String>("path") ?: run {
                            result.error("INVALID_ARG", "path required", null)
                            return@setMethodCallHandler
                        }
                        executor.execute {
                            try {
                                @Suppress("DEPRECATION")
                                val info = packageManager.getPackageArchiveInfo(path, 0)
                                mainHandler.post { result.success(info?.packageName) }
                            } catch (e: Exception) {
                                mainHandler.post { result.success(null) }
                            }
                        }
                    }

                    else -> result.notImplemented()
                }
            }

        // ── Black Forge archive methods ─────────────────────────────────────
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, FORGE_CHANNEL)
            .setMethodCallHandler(ForgeBridge(this))

        // ── WebApk Forge — local website-to-APK builder ─────────────────────
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, WEBAPK_CHANNEL)
            .setMethodCallHandler(WebApkBridge(this))

        // ── Cocos2d-x Analyser — fully on-device ─────────────────────────────
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, COCOS_CHANNEL)
            .setMethodCallHandler { call, result ->
                val prefs = getSharedPreferences(CocosService.PREFS, Context.MODE_PRIVATE)
                when (call.method) {

                    "startAnalyse" -> {
                        val apkPath  = call.argument<String>("apk_path") ?: run {
                            result.error("INVALID_ARG", "apk_path required", null); return@setMethodCallHandler }
                        val gameName = call.argument<String>("game_name") ?: "game"
                        startService(Intent(this, CocosService::class.java).apply {
                            action = CocosService.ACTION_ANALYSE
                            putExtra(CocosService.EXTRA_APK_PATH,  apkPath)
                            putExtra(CocosService.EXTRA_GAME_NAME, gameName)
                        })
                        result.success(null)
                    }

                    "startPatchNative" -> {
                        val apkPath  = call.argument<String>("apk_path") ?: run {
                            result.error("INVALID_ARG", "apk_path required", null); return@setMethodCallHandler }
                        val gameName = call.argument<String>("game_name") ?: "game"
                        val features = call.argument<String>("features_json") ?: "[]"
                        startService(Intent(this, CocosService::class.java).apply {
                            action = CocosService.ACTION_PATCH_NATIVE
                            putExtra(CocosService.EXTRA_APK_PATH,      apkPath)
                            putExtra(CocosService.EXTRA_GAME_NAME,     gameName)
                            putExtra(CocosService.EXTRA_FEATURES_JSON, features)
                        })
                        result.success(null)
                    }

                    "startPatchScript" -> {
                        val apkPath  = call.argument<String>("apk_path") ?: run {
                            result.error("INVALID_ARG", "apk_path required", null); return@setMethodCallHandler }
                        val gameName = call.argument<String>("game_name") ?: "game"
                        val patches  = call.argument<String>("patches_json") ?: "[]"
                        startService(Intent(this, CocosService::class.java).apply {
                            action = CocosService.ACTION_PATCH_SCRIPT
                            putExtra(CocosService.EXTRA_APK_PATH,     apkPath)
                            putExtra(CocosService.EXTRA_GAME_NAME,    gameName)
                            putExtra(CocosService.EXTRA_PATCHES_JSON, patches)
                        })
                        result.success(null)
                    }

                    "getState" -> {
                        result.success(mapOf(
                            "running"       to prefs.getBoolean(CocosService.KEY_RUNNING, false),
                            "phase"         to (prefs.getString(CocosService.KEY_PHASE, "") ?: ""),
                            "logs"          to (prefs.getString(CocosService.KEY_LOGS, "") ?: ""),
                            "result_status" to (prefs.getString(CocosService.KEY_STATUS, "") ?: ""),
                            "result"        to (prefs.getString(CocosService.KEY_RESULT, "") ?: ""),
                            "progress"      to prefs.getInt(CocosService.KEY_PROGRESS, -1),
                            "game_type"     to (prefs.getString(CocosService.KEY_GAME_TYPE, "") ?: ""),
                        ))
                    }

                    "clearState" -> {
                        CocosService.clearState(this)
                        result.success(null)
                    }

                    "cancelCocos" -> {
                        CocosService.cancel(this)
                        result.success(null)
                    }

                    else -> result.notImplemented()
                }
            }

        // ── LogCat control methods ───────────────────────────────────────────
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, LOGCAT_CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {

                    "logcat_start" -> {
                        // useRoot may be omitted/null — in that case we don't
                        // attach EXTRA_USE_ROOT so the service preserves its
                        // current mode (set by an earlier intent). This lets
                        // secondary call sites (e.g. recording tab) talk to
                        // the service without resetting root mode.
                        val intent = android.content.Intent(this, LogcatService::class.java)
                            .setAction(LogcatService.ACTION_START)
                        call.argument<Boolean>("useRoot")?.let {
                            intent.putExtra(LogcatService.EXTRA_USE_ROOT, it)
                        }
                        startService(intent)
                        result.success(null)
                    }

                    "logcat_stop" -> {
                        startService(android.content.Intent(this, LogcatService::class.java)
                            .setAction(LogcatService.ACTION_STOP))
                        result.success(null)
                    }

                    "logcat_clear" -> {
                        val intent = android.content.Intent(this, LogcatService::class.java)
                            .setAction(LogcatService.ACTION_CLEAR)
                        call.argument<Boolean>("useRoot")?.let {
                            intent.putExtra(LogcatService.EXTRA_USE_ROOT, it)
                        }
                        startService(intent)
                        result.success(null)
                    }

                    "logcat_restart" -> {
                        val intent = android.content.Intent(this, LogcatService::class.java)
                            .setAction(LogcatService.ACTION_RESTART)
                        call.argument<Boolean>("useRoot")?.let {
                            intent.putExtra(LogcatService.EXTRA_USE_ROOT, it)
                        }
                        startService(intent)
                        result.success(null)
                    }

                    "logcat_revoke_permission" -> {
                        executor.execute {
                            val res = ShizukuHelper.revokeReadLogs(
                                applicationContext.packageName, applicationContext)
                            mainHandler.post { result.success(res) }
                        }
                    }

                    "logcat_hard_reset" -> {
                        // Stop logcat service immediately
                        stopService(android.content.Intent(this, LogcatService::class.java)
                            .setAction(LogcatService.ACTION_STOP))
                        executor.execute {
                            val adbBin = BinRef.r(applicationInfo.nativeLibraryDir)
                            var revokedViaAdb = false
                            try {
                                // Kill any running ADB server (clears all connections/pairs)
                                ProcessBuilder(adbBin, "kill-server")
                                    .start().waitFor(5, java.util.concurrent.TimeUnit.SECONDS)
                                // Try to start fresh + connect to self and revoke
                                ProcessBuilder(adbBin, "start-server")
                                    .start().waitFor(5, java.util.concurrent.TimeUnit.SECONDS)
                                val devOut = ProcessBuilder(adbBin, "devices").start()
                                    .let { it.inputStream.bufferedReader().readText().also { _ -> it.waitFor(5, java.util.concurrent.TimeUnit.SECONDS) } }
                                val hasDevice = devOut.lines().drop(1).any { it.contains("\tdevice") }
                                if (hasDevice) {
                                    val grantProc = ProcessBuilder(
                                        adbBin, "shell", "pm", "revoke",
                                        packageName, "android.permission.READ_LOGS"
                                    ).start()
                                    grantProc.waitFor(10, java.util.concurrent.TimeUnit.SECONDS)
                                    revokedViaAdb = checkSelfPermission(
                                        android.Manifest.permission.READ_LOGS) !=
                                        android.content.pm.PackageManager.PERMISSION_GRANTED
                                }
                                // Kill server again so state is fully clean
                                ProcessBuilder(adbBin, "kill-server")
                                    .start().waitFor(5, java.util.concurrent.TimeUnit.SECONDS)
                            } catch (_: Exception) {}
                            // Fallback: try Shizuku revoke if ADB revoke didn't work
                            if (!revokedViaAdb) {
                                ShizukuHelper.revokeReadLogs(
                                    applicationContext.packageName, applicationContext)
                            }
                            mainHandler.post { result.success(null) }
                        }
                    }

                    "logcat_check_permission" -> {
                        val granted = checkSelfPermission(android.Manifest.permission.READ_LOGS) ==
                            android.content.pm.PackageManager.PERMISSION_GRANTED
                        result.success(granted)
                    }

                    "logcat_check_root" -> {
                        // Detects whether `su` is reachable on PATH or in the
                        // common system locations. We don't actually invoke su
                        // here — that would trigger a SuperUser prompt. Just
                        // check for the binary so the UI knows whether to
                        // expose the root-grant button at all. Runs on a
                        // background thread to keep the platform/UI thread
                        // responsive on devices where the filesystem stat or
                        // `which` lookup is slow.
                        Thread {
                            val suPaths = listOf(
                                "/system/bin/su", "/system/xbin/su", "/sbin/su",
                                "/su/bin/su", "/magisk/.core/bin/su",
                                "/system/sbin/su", "/data/local/xbin/su",
                                "/data/local/bin/su", "/data/local/su"
                            )
                            val hasSu = suPaths.any { java.io.File(it).exists() } ||
                                try {
                                    val p = ProcessBuilder("which", "su")
                                        .redirectErrorStream(true).start()
                                    val out = p.inputStream.bufferedReader().readText().trim()
                                    p.waitFor(2, java.util.concurrent.TimeUnit.SECONDS)
                                    out.isNotEmpty()
                                } catch (_: Exception) { false }
                            mainHandler.post { result.success(hasSu) }
                        }.start()
                    }

                    "logcat_test_root" -> {
                        // Triggers the SuperUser / Magisk prompt and verifies
                        // root access actually works — without granting any
                        // permission. We run `su -c "id -u"` and require the
                        // trimmed stdout to be exactly "0" before declaring
                        // success. A clean exit code alone is not enough —
                        // some tampered su builds return 0 on denial. Once
                        // approved the user can stream logcat via
                        // `su -c logcat …` directly, which is what
                        // LogcatService does when useRoot=true.
                        // Returns one of:
                        //   "granted" — su works, uid 0 confirmed
                        //   "denied"  — SuperUser prompt rejected / timeout /
                        //               returned anything other than "0"
                        //   "no_su"   — su binary not found / not callable
                        //   "failed"  — anything else
                        Thread {
                            val res: String = try {
                                val proc = Runtime.getRuntime().exec(arrayOf("su", "-c", "id -u"))
                                val finished = proc.waitFor(20, java.util.concurrent.TimeUnit.SECONDS)
                                if (!finished) {
                                    try { proc.destroyForcibly() } catch (_: Exception) {}
                                    "denied"
                                } else {
                                    val out = try {
                                        proc.inputStream.bufferedReader().readText().trim()
                                    } catch (_: Exception) { "" }
                                    if (out == "0") "granted" else "denied"
                                }
                            } catch (_: java.io.IOException) {
                                "no_su"
                            } catch (_: SecurityException) {
                                "denied"
                            } catch (_: Exception) {
                                "failed"
                            }
                            mainHandler.post { result.success(res) }
                        }.start()
                    }

                    "logcat_check_adb_enabled" -> {
                        val usbOn = try {
                            android.provider.Settings.Global.getInt(
                                contentResolver, "adb_enabled", 0) == 1
                        } catch (_: Exception) { true }
                        val wifiOn = try {
                            android.provider.Settings.Global.getInt(
                                contentResolver, "adb_wifi_enabled", 0) == 1
                        } catch (_: Exception) { true }
                        result.success(mapOf(
                            "usbDebugging" to usbOn,
                            "wirelessDebugging" to wifiOn
                        ))
                    }

                    "open_developer_options" -> {
                        try {
                            val intent = android.content.Intent(
                                android.provider.Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
                            intent.flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
                            startActivity(intent)
                        } catch (_: Exception) {}
                        result.success(null)
                    }

                    "open_wireless_debugging" -> {
                        try {
                            val intent = android.content.Intent(
                                android.provider.Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
                            intent.flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
                            startActivity(intent)
                        } catch (_: Exception) {}
                        result.success(null)
                    }

                    "check_overlay_permission" -> {
                        val ok = android.provider.Settings.canDrawOverlays(applicationContext)
                        result.success(ok)
                    }

                    "request_overlay_permission" -> {
                        try {
                            val intent = android.content.Intent(
                                android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                android.net.Uri.parse("package:$packageName"))
                            intent.flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
                            startActivity(intent)
                        } catch (_: Exception) {}
                        result.success(null)
                    }

                    "show_floating_pair" -> {
                        // Stop any existing instance first
                        stopService(android.content.Intent(this, FloatingPairService::class.java))
                        Thread.sleep(200)
                        // Start the floating overlay service
                        android.content.Intent(this, FloatingPairService::class.java).also {
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O)
                                startForegroundService(it)
                            else
                                startService(it)
                        }
                        // Open Wireless Debugging settings
                        try {
                            android.content.Intent(
                                android.provider.Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).also {
                                it.flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
                                startActivity(it)
                            }
                        } catch (_: Exception) {}
                        result.success(null)
                    }

                    "logcat_get_app_label" -> {
                        val pkg = call.argument<String>("packageName") ?: ""
                        executor.execute {
                            val label: String? = try {
                                val info = packageManager.getApplicationInfo(pkg, 0)
                                packageManager.getApplicationLabel(info).toString()
                            } catch (_: Exception) { null }
                            mainHandler.post { result.success(label) }
                        }
                    }

                    "logcat_create_zip_document" -> {
                        val filename   = call.argument<String>("filename") ?: "export.zip"
                        val content    = call.argument<String>("content")
                        val sourcePath = call.argument<String>("sourcePath")
                        val txtBytes = when {
                            content    != null -> content.toByteArray(Charsets.UTF_8)
                            sourcePath != null -> try { java.io.File(sourcePath).readBytes() } catch (_: Exception) { ByteArray(0) }
                            else               -> ByteArray(0)
                        }
                        val baos = java.io.ByteArrayOutputStream()
                        val zos  = java.util.zip.ZipOutputStream(baos)
                        val entryName = filename.removeSuffix(".zip") + ".txt"
                        zos.putNextEntry(java.util.zip.ZipEntry(entryName))
                        zos.write(txtBytes)
                        zos.closeEntry()
                        zos.close()
                        pendingDocBytes  = baos.toByteArray()
                        pendingDocResult = result
                        val intent = android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT).apply {
                            addCategory(android.content.Intent.CATEGORY_OPENABLE)
                            type = "application/zip"
                            putExtra(android.content.Intent.EXTRA_TITLE, filename)
                        }
                        try {
                            startActivityForResult(intent, REQ_CREATE_DOC)
                        } catch (e: Exception) {
                            pendingDocBytes = null; pendingDocResult = null
                            result.error("LAUNCH_ERROR", e.message, null)
                        }
                    }

                    "logcat_create_document" -> {
                        val filename   = call.argument<String>("filename") ?: "export.txt"
                        val content    = call.argument<String>("content")
                        val sourcePath = call.argument<String>("sourcePath")
                        pendingDocBytes = when {
                            content    != null -> content.toByteArray(Charsets.UTF_8)
                            sourcePath != null -> try { java.io.File(sourcePath).readBytes() } catch (_: Exception) { ByteArray(0) }
                            else               -> ByteArray(0)
                        }
                        pendingDocResult = result
                        val intent = android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT).apply {
                            addCategory(android.content.Intent.CATEGORY_OPENABLE)
                            type = "text/plain"
                            putExtra(android.content.Intent.EXTRA_TITLE, filename)
                        }
                        try {
                            startActivityForResult(intent, REQ_CREATE_DOC)
                        } catch (e: Exception) {
                            pendingDocBytes  = null
                            pendingDocResult = null
                            result.error("LAUNCH_ERROR", e.message, null)
                        }
                    }

                    "logcat_get_app_icon" -> {
                        val pkg = call.argument<String>("packageName") ?: ""
                        executor.execute {
                            val bytes: ByteArray? = try {
                                drawableToBytes(packageManager.getApplicationIcon(pkg))
                            } catch (_: Exception) { null }
                            mainHandler.post { result.success(bytes) }
                        }
                    }

                    // ── Installed apps list ────────────────────────────────────
                    "logcat_get_installed_apps" -> {
                        executor.execute {
                            val pm = packageManager
                            val apps = pm.getInstalledApplications(android.content.pm.PackageManager.GET_META_DATA)
                                .filter { it.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM == 0 ||
                                          it.flags and android.content.pm.ApplicationInfo.FLAG_UPDATED_SYSTEM_APP != 0 }
                                .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
                                .mapNotNull { info ->
                                    val apkPath = info.sourceDir ?: return@mapNotNull null
                                    val label   = try { pm.getApplicationLabel(info).toString() } catch (_: Exception) { info.packageName }
                                    mapOf(
                                        "packageName" to info.packageName,
                                        "appName"     to label,
                                        "apkPath"     to apkPath,
                                    )
                                }
                            mainHandler.post { result.success(apps) }
                        }
                    }

                    // ── Shizuku ────────────────────────────────────────────────
                    "logcat_shizuku_grant" -> {
                        executor.execute {
                            val res = ShizukuHelper.grantReadLogs(packageName, applicationContext)
                            mainHandler.post { result.success(res) }
                        }
                    }

                    "logcat_check_after_shizuku" -> {
                        val wasSet = ShizukuHelper.checkAndClearAfterFlag(applicationContext)
                        result.success(wasSet)
                    }

                    // ── Auto-start on boot ─────────────────────────────────────
                    "logcat_get_autostart" -> {
                        val on = getSharedPreferences(
                            BootReceiver.PREFS, MODE_PRIVATE
                        ).getBoolean(BootReceiver.KEY_AUTOSTART, false)
                        result.success(on)
                    }
                    "logcat_set_autostart" -> {
                        val on = call.argument<Boolean>("enabled") ?: false
                        getSharedPreferences(BootReceiver.PREFS, MODE_PRIVATE)
                            .edit().putBoolean(BootReceiver.KEY_AUTOSTART, on).apply()
                        result.success(null)
                    }

                    "logcat_pair_adb" -> {
                        val pairCode = call.argument<String>("pairCode") ?: run {
                            result.error("INVALID_ARG", "pairCode required", null); return@setMethodCallHandler
                        }
                        executor.execute {
                            try {
                                val adbBin = BinRef.r(applicationInfo.nativeLibraryDir)
                                val homeDir = filesDir.absolutePath
                                val tmpDir  = cacheDir.absolutePath
                                fun adbProc(vararg args: String): ProcessBuilder =
                                    ProcessBuilder(*args)
                                        .redirectErrorStream(true)
                                        .also { pb ->
                                            pb.environment()["HOME"]   = homeDir
                                            pb.environment()["TMPDIR"] = tmpDir
                                        }

                                // ── Helper: mDNS discover host+port for a service type ──────────
                                fun discoverService(serviceType: String, timeoutSec: Long)
                                        : Pair<String, Int> {
                                    var host = ""
                                    var port = 0
                                    val latch = CountDownLatch(1)
                                    val nsd = applicationContext.getSystemService(NSD_SERVICE) as NsdManager

                                    val resolveListener = object : NsdManager.ResolveListener {
                                        override fun onResolveFailed(i: NsdServiceInfo, c: Int) {
                                            latch.countDown()
                                        }
                                        override fun onServiceResolved(i: NsdServiceInfo) {
                                            if (i.port > 0) {
                                                host = i.host?.hostAddress ?: ""
                                                port = i.port
                                            }
                                            latch.countDown()
                                        }
                                    }
                                    var discListener: NsdManager.DiscoveryListener? = null
                                    discListener = object : NsdManager.DiscoveryListener {
                                        override fun onDiscoveryStarted(r: String) {}
                                        override fun onDiscoveryStopped(r: String) {}
                                        override fun onStartDiscoveryFailed(r: String, c: Int) { latch.countDown() }
                                        override fun onStopDiscoveryFailed(r: String, c: Int) {}
                                        override fun onServiceFound(svc: NsdServiceInfo) {
                                            try { nsd.stopServiceDiscovery(discListener) } catch (_: Exception) {}
                                            nsd.resolveService(svc, resolveListener)
                                        }
                                        override fun onServiceLost(svc: NsdServiceInfo) {}
                                    }
                                    nsd.discoverServices(serviceType, NsdManager.PROTOCOL_DNS_SD, discListener!!)
                                    latch.await(timeoutSec, TimeUnit.SECONDS)
                                    try { nsd.stopServiceDiscovery(discListener) } catch (_: Exception) {}
                                    return Pair(host, port)
                                }

                                // ── Step 0: Discover pairing service (user must have dialog open) ─
                                val (pairHost, pairPort) = discoverService("_adb-tls-pairing._tcp", 30)
                                if (pairPort == 0) {
                                    mainHandler.post {
                                        result.error("PAIR_ERROR",
                                            "No pairing service found.\nMake sure the \"Pair device with pairing code\" dialog is open in Wireless Debugging.", null)
                                    }
                                    return@execute
                                }

                                // ── Step 1: Clean server before pair ─────────────────────────────
                                adbProc(adbBin, "kill-server").start().apply {
                                    inputStream.bufferedReader().readText(); waitFor()
                                }
                                Thread.sleep(500)
                                adbProc(adbBin, "start-server").start().apply {
                                    inputStream.bufferedReader().readText(); waitFor()
                                }
                                Thread.sleep(800)

                                // ── Step 2: Pair to localhost:PORT (LADB uses localhost, not IP) ──
                                val pairAddr = "localhost:$pairPort"
                                val pairProc = adbProc(adbBin, "pair", pairAddr).start()
                                val pairOutput = StringBuilder()
                                val pairReader = Thread {
                                    try {
                                        pairProc.inputStream.bufferedReader()
                                            .forEachLine { pairOutput.appendLine(it) }
                                    } catch (_: Exception) {}
                                }.also { it.start() }
                                Thread.sleep(2000)
                                try {
                                    pairProc.outputStream.writer().apply {
                                        write(pairCode); write("\n"); flush()
                                    }
                                } catch (_: Exception) {}
                                pairProc.waitFor(20, TimeUnit.SECONDS)
                                pairProc.destroyForcibly().waitFor()
                                pairReader.join(2000)
                                val pairOut = pairOutput.toString()

                                if ("Successfully" !in pairOut) {
                                    mainHandler.post {
                                        result.error("PAIR_ERROR",
                                            "Pairing failed [$pairAddr]: $pairOut", null)
                                    }
                                    return@execute
                                }

                                // ── Step 3: Determine the connect port via three methods ──────────
                                // Method A — getprop service.adb.tcp.port (same method as LADB)
                                val getPropPort = try {
                                    val gp = ProcessBuilder("getprop", "service.adb.tcp.port")
                                        .redirectErrorStream(true).start()
                                    val v = gp.inputStream.bufferedReader().readText().trim()
                                    gp.waitFor()
                                    v.toIntOrNull() ?: 0
                                } catch (_: Exception) { 0 }

                                // Method B — SystemProperties reflection fallback
                                val sysPropPort = if (getPropPort > 0) getPropPort else try {
                                    val sp = Class.forName("android.os.SystemProperties")
                                        .getMethod("get", String::class.java, String::class.java)
                                        .invoke(null, "service.adb.tcp.port", "0") as String
                                    sp.trim().toIntOrNull() ?: 0
                                } catch (_: Exception) { 0 }

                                // Method C — mDNS discovery (run with short timeout; port above is primary)
                                val (connHost, connPort) = discoverService("_adb-tls-connect._tcp", 15)

                                // Build deduplicated candidate list — localhost always first (LADB approach:
                                // even if mDNS resolves a LAN IP, localhost is used for same-device ADB)
                                val candidates = linkedSetOf<String>()
                                for (port in listOf(sysPropPort, connPort).distinct()) {
                                    if (port > 0) {
                                        candidates += "localhost:$port"
                                        candidates += "127.0.0.1:$port"
                                    }
                                }
                                // Only add LAN IP if mDNS resolved AND it differs from localhost ports
                                if (connHost.isNotEmpty() && connPort > 0 &&
                                    !connHost.startsWith("127.") && connHost != "localhost")
                                    candidates += "$connHost:$connPort"

                                // ── Step 4: Explicit connect (up to 3 rounds) ────────────────────
                                var devOut = ""
                                var hasDevice = false

                                fun checkDevices(): Boolean {
                                    devOut = adbProc(adbBin, "devices").start()
                                        .let { it.inputStream.bufferedReader().readText().also { _ -> it.waitFor() } }
                                    return devOut.lines().drop(1).any { it.contains("\tdevice") }
                                }

                                // Short wait to let ADB server settle after pairing
                                Thread.sleep(1000)

                                outer@ for (round in 1..3) {
                                    for (target in candidates) {
                                        val out = adbProc(adbBin, "connect", target).start()
                                            .let { it.inputStream.bufferedReader().readText().also { _ -> it.waitFor() } }
                                        if ("connected" in out.lowercase() || "already connected" in out.lowercase()) {
                                            Thread.sleep(800)
                                            if (checkDevices()) break@outer
                                        }
                                    }
                                    if (checkDevices()) break
                                    if (round < 3) Thread.sleep(1500)
                                }

                                // Final device check (also catches auto-connect path)
                                if (!hasDevice) hasDevice = checkDevices()

                                if (!hasDevice) {
                                    val tried = candidates.joinToString(", ").ifEmpty { "no port found" }
                                    val portInfo = "getprop=$getPropPort  sysProp=$sysPropPort  mDNS=$connPort"
                                    mainHandler.post {
                                        result.error("PAIR_ERROR",
                                            "Paired ✓ but device not visible.\n" +
                                            "Tried: $tried\n($portInfo)\n\n" +
                                            "Try:\n" +
                                            "• Toggle Wireless Debugging off → on, then pair again\n" +
                                            "• Use Settings → Reset & Re-pair", null)
                                    }
                                    return@execute
                                }

                                // ── Step 6: Grant READ_LOGS ───────────────────────────────────────
                                Thread.sleep(500)
                                val devList = adbProc(adbBin, "devices").start()
                                    .let { it.inputStream.bufferedReader().readText().also { _ -> it.waitFor() } }
                                val serial = devList.lines().drop(1)
                                    .firstOrNull { it.contains("\tdevice") }
                                    ?.split("\t")?.firstOrNull()?.trim() ?: ""

                                val grantArgs = if (serial.isNotEmpty())
                                    arrayOf(adbBin, "-s", serial, "shell", "pm", "grant", packageName,
                                        "android.permission.READ_LOGS")
                                else
                                    arrayOf(adbBin, "shell", "pm", "grant", packageName,
                                        "android.permission.READ_LOGS")
                                val grantProc = adbProc(*grantArgs).start()
                                val grantOut  = grantProc.inputStream.bufferedReader().readText()
                                val grantExit = grantProc.waitFor()
                                if (grantExit != 0 && grantOut.isNotBlank()) {
                                    mainHandler.post {
                                        result.error("PAIR_ERROR",
                                            "Paired ✓ Connected ✓ but grant failed: $grantOut", null)
                                    }
                                    return@execute
                                }

                                mainHandler.post {
                                    result.success("Paired ✓  Connected ✓  Permission granted ✓")
                                }
                            } catch (e: Exception) {
                                mainHandler.post {
                                    result.error("PAIR_ERROR", e.message ?: "Unknown error", null)
                                }
                            }
                        }
                    }

                    "logcat_run_adb" -> {
                        val command = call.argument<String>("command") ?: run {
                            result.error("INVALID_ARG", "command required", null); return@setMethodCallHandler
                        }
                        executor.execute {
                            try {
                                val adbBin = BinRef.r(applicationInfo.nativeLibraryDir)
                                val homeDir = filesDir.absolutePath
                                val tmpDir  = cacheDir.absolutePath

                                // Strip leading "adb " prefix if user typed the full command
                                val cmd = command.trim().let { c ->
                                    if (c.lowercase().startsWith("adb ")) c.substring(4).trim() else c
                                }

                                // Special: "clear" is handled client-side only
                                if (cmd == "clear" || cmd == "exit") {
                                    mainHandler.post { result.success(mapOf("output" to "", "exitCode" to 0, "special" to cmd)) }
                                    return@execute
                                }

                                // Tokenise respecting single/double quotes
                                val args = mutableListOf(adbBin)
                                val regex = Regex("""'([^']*)'|"([^"]*)"|(\S+)""")
                                regex.findAll(cmd).forEach { m ->
                                    args.add(m.groupValues.drop(1).firstOrNull { it.isNotEmpty() } ?: m.value)
                                }

                                val proc = ProcessBuilder(*args.toTypedArray())
                                    .redirectErrorStream(true)
                                    .also { pb ->
                                        pb.environment()["HOME"]   = homeDir
                                        pb.environment()["TMPDIR"] = tmpDir
                                    }.start()

                                val output   = proc.inputStream.bufferedReader().readText()
                                val exitCode = proc.waitFor()
                                mainHandler.post { result.success(mapOf("output" to output.trimEnd(), "exitCode" to exitCode)) }
                            } catch (e: Exception) {
                                mainHandler.post { result.error("ADB_ERROR", e.message ?: "Unknown error", null) }
                            }
                        }
                    }

                    "logcat_get_crashes" -> {
                        executor.execute {
                            // Access crash file directly (app files dir)
                            val crashFile = java.io.File(filesDir, "logcat_crashes.json")
                            val arr = try { org.json.JSONArray(crashFile.readText()) }
                                      catch (_: Exception) { org.json.JSONArray() }
                            val list = mutableListOf<Map<String, Any>>()
                            for (i in 0 until arr.length()) {
                                val o = arr.getJSONObject(i)
                                list.add(mapOf(
                                    "id"          to o.optString("id"),
                                    "timestamp"   to o.optString("timestamp"),
                                    "packageName" to o.optString("packageName"),
                                    "appName"     to o.optString("appName"),
                                    "type"        to o.optString("type"),
                                    "log"         to o.optString("log"),
                                ))
                            }
                            mainHandler.post { result.success(list) }
                        }
                    }

                    "logcat_delete_crash" -> {
                        val id = call.argument<String>("id") ?: run {
                            result.error("INVALID_ARG", "id required", null); return@setMethodCallHandler
                        }
                        executor.execute {
                            val crashFile = java.io.File(filesDir, "logcat_crashes.json")
                            val arr = try { org.json.JSONArray(crashFile.readText()) }
                                      catch (_: Exception) { org.json.JSONArray() }
                            val updated = org.json.JSONArray()
                            for (i in 0 until arr.length()) {
                                val o = arr.getJSONObject(i)
                                if (o.optString("id") != id) updated.put(o)
                            }
                            crashFile.writeText(updated.toString())
                            LogcatService.invalidateCrashHashes()
                            mainHandler.post { result.success(null) }
                        }
                    }

                    "logcat_clear_all_crashes" -> {
                        executor.execute {
                            java.io.File(filesDir, "logcat_crashes.json").writeText("[]")
                            LogcatService.invalidateCrashHashes()
                            mainHandler.post { result.success(null) }
                        }
                    }

                    "logcat_save_recording" -> {
                        val lines = call.argument<List<String>>("lines") ?: emptyList()
                        executor.execute {
                            try {
                                val dir = java.io.File(filesDir, "logcat_recordings").also { it.mkdirs() }
                                val ts  = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.getDefault()).format(java.util.Date())
                                val f   = java.io.File(dir, "recording_$ts.txt")
                                f.writeText(lines.joinToString("\n"))
                                mainHandler.post { result.success(f.absolutePath) }
                            } catch (e: Exception) {
                                mainHandler.post { result.error("SAVE_ERROR", e.message, null) }
                            }
                        }
                    }

                    "logcat_get_recordings" -> {
                        executor.execute {
                            val dir = java.io.File(filesDir, "logcat_recordings")
                            val list = if (dir.isDirectory) {
                                dir.listFiles()?.sortedByDescending { it.lastModified() }?.map {
                                    mapOf("path" to it.absolutePath, "name" to it.name,
                                          "size" to it.length(), "modified" to it.lastModified())
                                } ?: emptyList()
                            } else emptyList()
                            mainHandler.post { result.success(list) }
                        }
                    }

                    "logcat_delete_recording" -> {
                        val path = call.argument<String>("path") ?: run {
                            result.error("INVALID_ARG", "path required", null); return@setMethodCallHandler
                        }
                        executor.execute {
                            java.io.File(path).delete()
                            mainHandler.post { result.success(null) }
                        }
                    }

                    else -> result.notImplemented()
                }
            }

        // ── Storage utilities ────────────────────────────────────────────────
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, STORE_CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "getRootDir" -> result.success(Environment.getExternalStorageDirectory().absolutePath)
                    "hasManagePermission" -> {
                        val granted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
                            Environment.isExternalStorageManager() else true
                        result.success(granted)
                    }
                    "openManagePermissionSettings" -> {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            try {
                                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                                    .apply { data = Uri.parse("package:$packageName") })
                            } catch (_: Exception) {
                                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                            }
                        }
                        result.success(null)
                    }
                    "ensureOutputDir" -> {
                        val path = call.argument<String>("path") ?: run {
                            result.error("INVALID_ARG", "path required", null); return@setMethodCallHandler
                        }
                        val dir = File(path); dir.mkdirs()
                        result.success(dir.exists())
                    }
                    "getSdkInt" -> result.success(Build.VERSION.SDK_INT)
                    "openFolder" -> {
                        val path = call.argument<String>("path") ?: run { result.success(null); return@setMethodCallHandler }
                        try {
                            val uri = androidx.core.content.FileProvider.getUriForFile(
                                this, "$packageName.fileprovider", File(path))
                            startActivity(Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(uri, "resource/folder")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            })
                        } catch (_: Exception) {
                            try {
                                startActivity(Intent(Intent.ACTION_VIEW).apply {
                                    setDataAndType(android.net.Uri.parse("file://$path"), "*/*")
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                })
                            } catch (_: Exception) {}
                        }
                        result.success(null)
                    }

                    // ── Self-update installer ──────────────────────────────────────
                    "getContentUri" -> {
                        val filePath = call.argument<String>("filePath") ?: run {
                            result.error("INVALID_ARG", "filePath required", null); return@setMethodCallHandler
                        }
                        try {
                            val uri = androidx.core.content.FileProvider.getUriForFile(
                                this, "$packageName.fileprovider", File(filePath))
                            result.success(uri.toString())
                        } catch (e: Exception) {
                            result.success("file://$filePath")
                        }
                    }

                    "installUpdate" -> {
                        val cUri = call.argument<String>("contentUri") ?: ""
                        val fUri = call.argument<String>("fileUri")    ?: ""

                        if (cUri.isEmpty() && fUri.isEmpty()) {
                            result.error("INVALID_ARG", "contentUri required", null)
                            return@setMethodCallHandler
                        }

                        val apkUri = Uri.parse(cUri.ifEmpty { fUri })

                        // ── 1. Permission check (Android 8+) ──────────────────
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                            !packageManager.canRequestPackageInstalls()) {

                            // Store URIs so we can resume after permission grant
                            pendingInstallUri      = apkUri
                            pendingInstallFileUri  = fUri

                            val settingsIntent = Intent(
                                Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                Uri.parse("package:$packageName")
                            )
                            @Suppress("DEPRECATION")
                            startActivityForResult(settingsIntent, REQ_INSTALL_PERM)

                            // Background poller: fires the installer the instant
                            // the user toggles the permission ON — no Back press needed.
                            val pollUri  = apkUri
                            val pollFUri = fUri
                            Thread {
                                var attempts = 0
                                while (attempts < 120) {
                                    Thread.sleep(500)
                                    attempts++
                                    if (packageManager.canRequestPackageInstalls()) {
                                        Handler(Looper.getMainLooper()).post {
                                            installViaSession(pollUri, pollFUri)
                                        }
                                        break
                                    }
                                }
                            }.start()

                            result.success(mapOf(
                                "needsPermission"    to true,
                                "signatureConflict"  to false,
                                "conflictingPackage" to ""))
                            return@setMethodCallHandler
                        }

                        // ── 2. Install via PackageInstaller Session API ────────
                        // APK bytes streamed on a background thread; BroadcastReceiver
                        // registered on the main thread waits for STATUS_PENDING_USER_ACTION
                        // and then launches the system "Do you want to install?" dialog.
                        installViaSession(
                            apkUri        = apkUri,
                            fileUriString = fUri,
                            onSuccess = {
                                result.success(mapOf(
                                    "needsPermission"    to false,
                                    "signatureConflict"  to false,
                                    "conflictingPackage" to ""))
                            },
                            onError = { msg ->
                                result.error("INSTALL_ERROR", msg, null)
                            }
                        )
                    }

                    "setForceUpdate" -> {
                        val enabled = call.argument<Boolean>("enabled") ?: false
                        getSharedPreferences("taurus_prefs", Context.MODE_PRIVATE)
                            .edit().putBoolean("force_update", enabled).apply()
                        result.success(null)
                    }

                    "triggerUninstall" -> {
                        val pkg = call.argument<String>("packageName") ?: packageName
                        try {
                            startActivity(Intent(Intent.ACTION_DELETE).apply {
                                data = Uri.parse("package:$pkg")
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            })
                        } catch (_: Exception) {}
                        result.success(null)
                    }

                    // ── so_copy_lib ───────────────────────────────────────────
                    // Extracts libapp.so from the user's uploaded zip into outputDir.
                    "so_copy_lib" -> {
                        val zipPath = call.argument<String>("zipPath") ?: ""
                        val outDir  = call.argument<String>("outputDir") ?: run {
                            result.error("INVALID_ARG", "outputDir required", null)
                            return@setMethodCallHandler
                        }
                        executor.execute {
                            try {
                                // 1. Search the output folder recursively first — blutter artifact
                                //    may have already extracted libapp.so somewhere inside it.
                                val existing = java.io.File(outDir)
                                    .walkTopDown()
                                    .firstOrNull { it.isFile && it.name == "libapp.so" }
                                if (existing != null) {
                                    mainHandler.post { result.success(existing.absolutePath) }
                                    return@execute
                                }
                                // 2. Try extracting from the user's original uploaded zip.
                                if (zipPath.isNotEmpty() && java.io.File(zipPath).exists()) {
                                    val dest = java.io.File(outDir, "libapp.so")
                                    java.util.zip.ZipFile(zipPath).use { zf ->
                                        val entry = zf.entries().asSequence()
                                            .firstOrNull { !it.isDirectory && it.name.endsWith("libapp.so") }
                                        if (entry != null) {
                                            java.io.File(outDir).mkdirs()
                                            zf.getInputStream(entry).use { inp ->
                                                java.io.FileOutputStream(dest).use { out -> inp.copyTo(out) }
                                            }
                                            mainHandler.post { result.success(dest.absolutePath) }
                                            return@execute
                                        }
                                    }
                                }
                                mainHandler.post { result.error("NOT_FOUND", "libapp.so not found", null) }
                            } catch (e: Exception) {
                                mainHandler.post { result.error("COPY_ERROR", e.message, null) }
                            }
                        }
                    }

                    // ── so_search ─────────────────────────────────────────────
                    // Byte-level UTF-8 string search in a .so file.
                    // Returns up to 300 matches: [{value, offset, length}]
                    "so_search" -> {
                        val soPath = call.argument<String>("soPath") ?: run {
                            result.error("INVALID_ARG", "soPath required", null)
                            return@setMethodCallHandler
                        }
                        val query = call.argument<String>("query") ?: run {
                            result.error("INVALID_ARG", "query required", null)
                            return@setMethodCallHandler
                        }
                        executor.execute {
                            try {
                                val bytes  = java.io.File(soPath).readBytes()
                                val qBytes = query.toByteArray(Charsets.UTF_8)
                                val hits   = mutableListOf<Map<String, Any>>()
                                var i = 0
                                outer@ while (i <= bytes.size - qBytes.size) {
                                    for (j in qBytes.indices) {
                                        if (bytes[i + j] != qBytes[j]) { i++; continue@outer }
                                    }
                                    // Expand to full null-terminated string
                                    var s = i
                                    var e = i + qBytes.size
                                    while (s > 0 && bytes[s - 1] != 0.toByte()) s--
                                    while (e < bytes.size && bytes[e] != 0.toByte()) e++
                                    val full = try { String(bytes, s, e - s, Charsets.UTF_8) }
                                               catch (_: Exception) { query }
                                    hits.add(mapOf("value" to full, "offset" to s, "length" to (e - s)))
                                    i = e + 1
                                    if (hits.size >= 300) break
                                }
                                mainHandler.post { result.success(hits) }
                            } catch (e: Exception) {
                                mainHandler.post { result.error("SEARCH_ERROR", e.message, null) }
                            }
                        }
                    }

                    // ── so_apply_patches ──────────────────────────────────────
                    // Applies raw byte patches IN-PLACE at known offsets.
                    // patches: [{offset:int, replacement:String, length:int}]
                    "so_apply_patches" -> {
                        val soPath = call.argument<String>("soPath") ?: run {
                            result.error("INVALID_ARG", "soPath required", null)
                            return@setMethodCallHandler
                        }
                        @Suppress("UNCHECKED_CAST")
                        val patches = call.argument<List<Map<String, Any>>>("patches") ?: emptyList()
                        executor.execute {
                            try {
                                val soFile = java.io.File(soPath)
                                if (!soFile.exists()) throw Exception("File not found: $soPath")
                                java.io.RandomAccessFile(soFile, "rw").use { raf ->
                                    for (patch in patches) {
                                        val offset      = (patch["offset"]      as? Number)?.toLong() ?: continue
                                        val replacement = (patch["replacement"] as? String) ?: continue
                                        val length      = (patch["length"]      as? Number)?.toInt() ?: continue
                                        val repBytes    = replacement.toByteArray(Charsets.UTF_8)
                                        val write       = ByteArray(length)
                                        repBytes.copyInto(write, 0, 0, minOf(repBytes.size, length))
                                        raf.seek(offset)
                                        raf.write(write)
                                    }
                                }
                                mainHandler.post { result.success(soPath) }
                            } catch (e: Exception) {
                                mainHandler.post { result.error("PATCH_ERROR", e.message, null) }
                            }
                        }
                    }

                    // ── so_patch_string ───────────────────────────────────────
                    // FlutterMod-identical string patcher:
                    //   1. Convert oldStr/newStr to UTF-8 bytes
                    //   2. Validate newBytes.size ≤ origBytes.size
                    //   3. Search entire libapp.so for oldStr bytes
                    //   4. Reject if 0 or >1 matches
                    //   5. Patch in-place: write newStr bytes + zero-pad remainder
                    "so_patch_string" -> {
                        val soPath = call.argument<String>("soPath") ?: run {
                            result.error("INVALID_ARG", "soPath required", null)
                            return@setMethodCallHandler
                        }
                        val oldStr = call.argument<String>("oldStr") ?: run {
                            result.error("INVALID_ARG", "oldStr required", null)
                            return@setMethodCallHandler
                        }
                        val newStr = call.argument<String>("newStr") ?: ""
                        executor.execute {
                            try {
                                if (oldStr.isEmpty()) throw Exception("Original string is empty")
                                val soFile = java.io.File(soPath)
                                if (!soFile.exists()) throw Exception("The .so file does not exist.")

                                val origBytes = oldStr.toByteArray(Charsets.UTF_8)
                                val newBytes  = newStr.toByteArray(Charsets.UTF_8)

                                if (newBytes.size > origBytes.size)
                                    throw Exception("New string is too long!")

                                // Search the entire file for origBytes
                                val fileBytes = soFile.readBytes()
                                val matches   = mutableListOf<Long>()
                                outer@ for (i in 0..fileBytes.size - origBytes.size) {
                                    for (j in origBytes.indices) {
                                        if (fileBytes[i + j] != origBytes[j]) continue@outer
                                    }
                                    matches.add(i.toLong())
                                }

                                val patchAll       = call.argument<Boolean>("patchAll") ?: false
                                @Suppress("UNCHECKED_CAST")
                                val specificOffsets = call.argument<List<Int>>("offsets")

                                when {
                                    matches.isEmpty() ->
                                        throw Exception("Original string NOT FOUND!")
                                    matches.size > 1 && !patchAll && specificOffsets == null -> {
                                        // Return match list so Flutter can show a picker
                                        val contexts = matches.map { off ->
                                            val s = maxOf(0, off.toInt() - 24)
                                            val e = minOf(fileBytes.size, off.toInt() + origBytes.size + 24)
                                            String(fileBytes, s, e - s, Charsets.UTF_8)
                                                .replace(Regex("[\\x00-\\x1F\\x7F]"), "·")
                                        }
                                        mainHandler.post {
                                            result.success(mapOf(
                                                "status"   to "multiple",
                                                "count"    to matches.size,
                                                "offsets"  to matches.map { it.toInt() },
                                                "contexts" to contexts,
                                            ))
                                        }
                                    }
                                    else -> {
                                        val toPatch: List<Long> = when {
                                            specificOffsets != null -> specificOffsets.map { it.toLong() }
                                            else -> matches   // patchAll or single match
                                        }
                                        java.io.RandomAccessFile(soFile, "rw").use { raf ->
                                            for (off in toPatch) {
                                                raf.seek(off)
                                                raf.write(newBytes)
                                                repeat(origBytes.size - newBytes.size) { raf.write(0) }
                                            }
                                        }
                                        mainHandler.post {
                                            result.success(mapOf(
                                                "status" to "ok",
                                                "count"  to toPatch.size,
                                            ))
                                        }
                                    }
                                }
                            } catch (e: Exception) {
                                mainHandler.post { result.error("PATCH_ERROR", e.message, null) }
                            }
                        }
                    }

                    // ── so_patch_int ──────────────────────────────────────────
                    // Integer patcher: searches libapp.so for a 32-bit or 64-bit
                    // little-endian integer and patches it in-place.
                    "so_patch_int" -> {
                        val soPath = call.argument<String>("soPath") ?: run {
                            result.error("INVALID_ARG", "soPath required", null)
                            return@setMethodCallHandler
                        }
                        val oldValStr = call.argument<String>("oldVal") ?: run {
                            result.error("INVALID_ARG", "oldVal required", null)
                            return@setMethodCallHandler
                        }
                        val newValStr = call.argument<String>("newVal") ?: run {
                            result.error("INVALID_ARG", "newVal required", null)
                            return@setMethodCallHandler
                        }
                        val bits = call.argument<Int>("bits") ?: 32
                        @Suppress("UNCHECKED_CAST")
                        val specificOffsets = call.argument<List<Int>>("offsets")

                        executor.execute {
                            try {
                                val oldVal = oldValStr.toLong()
                                val newVal = newValStr.toLong()
                                val byteCount = if (bits == 64) 8 else 4

                                // Range check
                                val maxUnsigned = if (bits == 32) 0xFFFFFFFFL else Long.MAX_VALUE
                                val minSigned   = if (bits == 32) Int.MIN_VALUE.toLong() else Long.MIN_VALUE
                                if (newVal > maxUnsigned || newVal < minSigned)
                                    throw Exception("New value out of range for $bits-bit integer")

                                fun longToLE(v: Long, n: Int): ByteArray {
                                    val b = ByteArray(n)
                                    for (i in 0 until n) b[i] = ((v ushr (i * 8)) and 0xFF).toByte()
                                    return b
                                }

                                val oldBytes = longToLE(oldVal, byteCount)
                                val newBytes = longToLE(newVal, byteCount)

                                val soFile = java.io.File(soPath)
                                if (!soFile.exists()) throw Exception("The .so file does not exist.")

                                val fileBytes = soFile.readBytes()
                                val matches   = mutableListOf<Long>()
                                outer@ for (i in 0..fileBytes.size - byteCount) {
                                    for (j in oldBytes.indices) {
                                        if (fileBytes[i + j] != oldBytes[j]) continue@outer
                                    }
                                    matches.add(i.toLong())
                                }

                                if (matches.size > 500)
                                    throw Exception("Too many matches (${matches.size}) — value too common. Try a more unique number.")

                                when {
                                    matches.isEmpty() ->
                                        throw Exception("Value $oldVal NOT FOUND in libapp.so")
                                    matches.size > 1 && specificOffsets == null -> {
                                        val contexts = matches.map { off ->
                                            val hexOff = "0x${off.toString(16).uppercase()}"
                                            val surrounding = fileBytes.sliceArray(
                                                maxOf(0, off.toInt() - 4)
                                                    until minOf(fileBytes.size, off.toInt() + byteCount + 4)
                                            )
                                            val hexBytes = surrounding.joinToString(" ") {
                                                "%02X".format(it.toInt() and 0xFF)
                                            }
                                            "@ $hexOff  [$hexBytes]"
                                        }
                                        mainHandler.post {
                                            result.success(mapOf(
                                                "status"   to "multiple",
                                                "count"    to matches.size,
                                                "offsets"  to matches.map { it.toInt() },
                                                "contexts" to contexts,
                                            ))
                                        }
                                    }
                                    else -> {
                                        val toPatch: List<Long> = specificOffsets?.map { it.toLong() } ?: matches
                                        java.io.RandomAccessFile(soFile, "rw").use { raf ->
                                            for (off in toPatch) {
                                                raf.seek(off)
                                                raf.write(newBytes)
                                            }
                                        }
                                        mainHandler.post {
                                            result.success(mapOf(
                                                "status" to "ok",
                                                "count"  to toPatch.size,
                                            ))
                                        }
                                    }
                                }
                            } catch (e: Exception) {
                                mainHandler.post { result.error("PATCH_ERROR", e.message, null) }
                            }
                        }
                    }

                    // ── so_scan_dump ──────────────────────────────────────────
                    // Parses Blutter asm/ files into function blocks grouped by
                    // file.  Returns FlutterMod-style results:
                    //   [{fileName, matchCount, blocks:[{funcName, offset, value,
                    //     headerText, contextText}]}]
                    "so_scan_dump" -> {
                        val dumpFolder = call.argument<String>("dumpFolder") ?: run {
                            result.error("INVALID_ARG", "dumpFolder required", null)
                            return@setMethodCallHandler
                        }
                        val keyword = call.argument<String>("keyword") ?: run {
                            result.error("INVALID_ARG", "keyword required", null)
                            return@setMethodCallHandler
                        }
                        executor.execute {
                            try {
                                val root   = java.io.File(dumpFolder)
                                val asmDir = java.io.File(root, "asm")
                                if (!asmDir.isDirectory) {
                                    mainHandler.post { result.error("NOT_FOUND", "asm/ folder not found in dump folder", null) }
                                    return@execute
                                }

                                // ── Regexes (compiled once, reused across threads) ────────────
                                val boolRe     = Regex("""0x([0-9a-fA-F]+):\s+(?:add|mov|movk|csel)[^\n]*#0x(20|30)(?!\s*,)""")
                                val addrRe     = Regex("""addr:\s*(0x[0-9a-fA-F]+)""")
                                val funcNameRe = Regex("""[\w${'$'}]+(?=\s*\()""")

                                val kw           = keyword.lowercase()
                                val totalBlocks  = java.util.concurrent.atomic.AtomicInteger(0)
                                val BLOCK_LIMIT  = 200
                                val CTX_WIN      = 15
                                val KW_WIN       = 600

                                val allFiles = asmDir.walkTopDown().filter { it.isFile }.sortedBy { it.name }.toList()

                                // ── Scan one file; returns null if no matches ──────────────────
                                fun scanFile(file: java.io.File): Map<String, Any>? {
                                    // ① Whole-file keyword pre-filter: skip files that don't
                                    //   contain the keyword at all — avoids heavy line-by-line
                                    //   parsing for the vast majority of files.
                                    if (!file.readText().contains(kw, ignoreCase = true)) return null
                                    if (totalBlocks.get() >= BLOCK_LIMIT) return null

                                    val blocks          = mutableListOf<Map<String, Any>>()
                                    val ctxWindow       = java.util.ArrayDeque<String>(CTX_WIN + 1)
                                    val kwWindow        = java.util.ArrayDeque<String>(KW_WIN + 1)
                                    // ② O(1) keyword-in-window check: maintain a hit counter
                                    //   instead of scanning the whole window on every bool match.
                                    var kwHitCount      = 0
                                    var currentFuncName = ""

                                    try {
                                        java.io.BufferedReader(java.io.FileReader(file)).use { br ->
                                            var line = br.readLine()
                                            while (line != null) {
                                                if (totalBlocks.get() >= BLOCK_LIMIT) break

                                                // ── Maintain ctx window ────────────────────────
                                                ctxWindow.addLast(line)
                                                if (ctxWindow.size > CTX_WIN) ctxWindow.removeFirst()

                                                // ── Maintain kw window with O(1) hit counter ──
                                                val lineHasKw = line.contains(kw, ignoreCase = true)
                                                if (lineHasKw) kwHitCount++
                                                kwWindow.addLast(line)
                                                if (kwWindow.size > KW_WIN) {
                                                    val evicted = kwWindow.removeFirst()
                                                    if (evicted.contains(kw, ignoreCase = true)) kwHitCount--
                                                }

                                                // ── Track function name from addr: line ───────
                                                if (line.contains("addr:") && addrRe.containsMatchIn(line)) {
                                                    val sigLine = if (line.contains("(")) line
                                                    else ctxWindow.toList().asReversed().firstOrNull { wl ->
                                                        val t = wl.trimStart()
                                                        !t.startsWith("//") && !t.startsWith("}") && wl.contains("(")
                                                    } ?: line
                                                    currentFuncName = funcNameRe.findAll(sigLine)
                                                        .lastOrNull()?.value ?: file.nameWithoutExtension
                                                }

                                                // ③ String pre-filter before expensive regex ──
                                                if (line.contains("0x") &&
                                                    (line.contains("#0x20") || line.contains("#0x30")) &&
                                                    kwHitCount > 0) {

                                                    val bm = boolRe.find(line)
                                                    if (bm != null) {
                                                        val patchOffset = bm.groupValues[1]
                                                        val curValue    = if (bm.groupValues[2] == "20") "true" else "false"

                                                        val ctx = StringBuilder()
                                                        ctxWindow.toList().dropLast(1).forEach { ctx.appendLine(it) }
                                                        ctx.append(">>> $line")

                                                        val headerLine = ctxWindow.toList().asReversed().firstOrNull { wl ->
                                                            val t = wl.trimStart()
                                                            !t.startsWith("//") && !t.startsWith("}") && wl.contains("(")
                                                        } ?: ""

                                                        blocks.add(mapOf(
                                                            "funcName"    to currentFuncName,
                                                            "offset"      to patchOffset,
                                                            "value"       to curValue,
                                                            "headerText"  to headerLine.trim(),
                                                            "contextText" to ctx.toString().trimEnd(),
                                                        ))
                                                        totalBlocks.incrementAndGet()
                                                    }
                                                }

                                                line = br.readLine()
                                            }
                                        }
                                    } catch (_: Exception) { /* skip unreadable files */ }

                                    return if (blocks.isNotEmpty()) mapOf(
                                        "fileName"   to file.name,
                                        "matchCount" to blocks.size,
                                        "blocks"     to blocks,
                                    ) else null
                                }

                                // ④ Parallel file processing across all CPU cores ─────────────
                                val fileGroups = allFiles.parallelStream()
                                    .map { scanFile(it) }
                                    .filter { it != null }
                                    .sorted(compareBy { it!!["fileName"] as String })
                                    .collect(java.util.stream.Collectors.toList())
                                    .filterNotNull()

                                mainHandler.post { result.success(fileGroups) }
                            } catch (e: Exception) {
                                mainHandler.post { result.error("SCAN_ERROR", e.message, null) }
                            }
                        }
                    }

                    // ── so_apply_bool_patches ─────────────────────────────────
                    // ARM64 boolean toggle — patches libapp.so IN-PLACE (no copy),
                    // exactly like FlutterMod: RandomAccessFile seeks to each offset
                    // and writes the modified byte directly into the original file.
                    "so_apply_bool_patches" -> {
                        val soPath = call.argument<String>("soPath") ?: run {
                            result.error("INVALID_ARG", "soPath required", null)
                            return@setMethodCallHandler
                        }
                        @Suppress("UNCHECKED_CAST")
                        val patches = call.argument<List<Map<String, Any>>>("patches") ?: emptyList()
                        executor.execute {
                            try {
                                val soFile = java.io.File(soPath)
                                if (!soFile.exists()) throw Exception("File not found: $soPath")
                                var count = 0
                                // Open in read-write mode — modifies the original file in-place
                                java.io.RandomAccessFile(soFile, "rw").use { raf ->
                                    for (patch in patches) {
                                        val hexOff   = (patch["offset"] as? String) ?: continue
                                        val toggleTo = (patch["toggleTo"] as? String) ?: continue
                                        val off = hexOff.toLong(16)
                                        if (off < 0 || off + 3 >= raf.length()) continue

                                        // ARM64 ADD immediate: imm12 in bits [21:10]
                                        // true  = NULL + #0x20 → byte[1] bit 6 = 0
                                        // false = NULL + #0x30 → byte[1] bit 6 = 1
                                        raf.seek(off + 1)
                                        val b1 = raf.read() and 0xFF
                                        val patched = if (toggleTo == "false") (b1 or 0x40) else (b1 and 0xBF)
                                        raf.seek(off + 1)
                                        raf.write(patched)
                                        count++
                                    }
                                }
                                mainHandler.post { result.success(mapOf("path" to soPath, "count" to count)) }
                            } catch (e: Exception) {
                                mainHandler.post { result.error("PATCH_ERROR", e.message, null) }
                            }
                        }
                    }

                    // ── so_scan_flutter_apps ──────────────────────────────────
                    // Scans every installed APK for lib/arm64-v8a/libapp.so.
                    // Returns [{packageName, appName, apkPath, soSize}]
                    "so_scan_flutter_apps" -> {
                        executor.execute {
                            try {
                                val pm   = packageManager
                                val apps = pm.getInstalledApplications(0)
                                val hits = mutableListOf<Map<String, Any>>()
                                for (info in apps) {
                                    val apkPath = info.sourceDir ?: continue
                                    try {
                                        java.util.zip.ZipFile(apkPath).use { zf ->
                                            val entry = zf.getEntry("lib/arm64-v8a/libapp.so")
                                                ?: zf.entries().asSequence()
                                                    .firstOrNull { !it.isDirectory && it.name.endsWith("libapp.so") }
                                            if (entry != null) {
                                                val label = try {
                                                    pm.getApplicationLabel(info).toString()
                                                } catch (_: Exception) { info.packageName }
                                                hits.add(mapOf(
                                                    "packageName" to info.packageName,
                                                    "appName"     to label,
                                                    "apkPath"     to apkPath,
                                                    "soSize"      to entry.size,
                                                ))
                                            }
                                        }
                                    } catch (_: Exception) {}
                                }
                                mainHandler.post { result.success(hits) }
                            } catch (e: Exception) {
                                mainHandler.post { result.error("SCAN_ERROR", e.message, null) }
                            }
                        }
                    }

                    // ── so_extract_from_apk ───────────────────────────────────
                    // Extracts lib/arm64-v8a/libapp.so from the given APK into outputDir.
                    "so_extract_from_apk" -> {
                        val apkPath = call.argument<String>("apkPath") ?: run {
                            result.error("INVALID_ARG", "apkPath required", null)
                            return@setMethodCallHandler
                        }
                        val outDir = call.argument<String>("outputDir") ?: run {
                            result.error("INVALID_ARG", "outputDir required", null)
                            return@setMethodCallHandler
                        }
                        executor.execute {
                            try {
                                java.io.File(outDir).mkdirs()
                                val dest = java.io.File(outDir, "libapp.so")
                                java.util.zip.ZipFile(apkPath).use { zf ->
                                    val entry = zf.getEntry("lib/arm64-v8a/libapp.so")
                                        ?: zf.entries().asSequence()
                                            .firstOrNull { !it.isDirectory && it.name.endsWith("libapp.so") }
                                        ?: run {
                                            mainHandler.post { result.error("NOT_FOUND", "libapp.so not in APK", null) }
                                            return@execute
                                        }
                                    zf.getInputStream(entry).use { inp ->
                                        dest.outputStream().use { out -> inp.copyTo(out) }
                                    }
                                }
                                mainHandler.post { result.success(dest.absolutePath) }
                            } catch (e: Exception) {
                                mainHandler.post { result.error("EXTRACT_ERROR", e.message, null) }
                            }
                        }
                    }

                    // ── ASM Editor backend ───────────────────────────────────────────────

                    "asm_init_edit" -> {
                        val outputDir = call.argument<String>("outputDir") ?: run {
                            result.error("INVALID_ARG", "outputDir required", null); return@setMethodCallHandler
                        }
                        val asmSrc = java.io.File(outputDir, "asm")
                        val asmDst = java.io.File(outputDir, "asm_edit")
                        if (!asmSrc.exists()) {
                            result.error("NOT_FOUND", "asm/ folder not found in outputDir", null)
                            return@setMethodCallHandler
                        }
                        executor.execute {
                            try {
                                if (!asmDst.exists()) {
                                    asmSrc.copyRecursively(asmDst, overwrite = false)
                                }
                                mainHandler.post { result.success(asmDst.absolutePath) }
                            } catch (e: Exception) {
                                mainHandler.post { result.error("COPY_ERROR", e.message, null) }
                            }
                        }
                    }

                    "asm_list_dir" -> {
                        val dir = call.argument<String>("dir") ?: run {
                            result.error("INVALID_ARG", "dir required", null); return@setMethodCallHandler
                        }
                        val f = java.io.File(dir)
                        if (!f.exists() || !f.isDirectory) {
                            result.error("NOT_FOUND", "Not a directory: $dir", null); return@setMethodCallHandler
                        }
                        val entries = f.listFiles()
                            ?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
                            ?.map { mapOf("name" to it.name, "path" to it.absolutePath, "isDir" to it.isDirectory, "size" to it.length(), "childCount" to if (it.isDirectory) (it.listFiles()?.size ?: 0) else 0) }
                            ?: emptyList()
                        result.success(entries)
                    }

                    "asm_read_file" -> {
                        val path = call.argument<String>("path") ?: run {
                            result.error("INVALID_ARG", "path required", null); return@setMethodCallHandler
                        }
                        val f = java.io.File(path)
                        if (!f.exists()) {
                            result.error("NOT_FOUND", "File not found: $path", null); return@setMethodCallHandler
                        }
                        executor.execute {
                            try {
                                val text = f.readText()
                                mainHandler.post { result.success(text) }
                            } catch (e: Exception) {
                                mainHandler.post { result.error("READ_ERROR", e.message, null) }
                            }
                        }
                    }

                    "asm_save_and_patch" -> {
                        val editPath = call.argument<String>("editPath") ?: run {
                            result.error("INVALID_ARG", "editPath required", null); return@setMethodCallHandler
                        }
                        val soPath = call.argument<String>("soPath") ?: run {
                            result.error("INVALID_ARG", "soPath required", null); return@setMethodCallHandler
                        }
                        @Suppress("UNCHECKED_CAST")
                        val origLines = call.argument<List<String>>("origLines") ?: emptyList()
                        @Suppress("UNCHECKED_CAST")
                        val newLines  = call.argument<List<String>>("newLines") ?: emptyList()
                        executor.execute {
                            try {
                                val soFile = java.io.File(soPath)
                                if (!soFile.exists()) throw Exception("libapp.so not found: $soPath")
                                val patchResults = mutableListOf<Map<String, Any>>()
                                var patchCount = 0; var errorCount = 0
                                java.io.RandomAccessFile(soFile, "rw").use { raf ->
                                    for (i in origLines.indices) {
                                        if (i >= newLines.size) break
                                        val ol = origLines[i]; val nl = newLines[i]
                                        if (ol == nl) continue
                                        val pr = arm64PatchLine(raf, ol, nl)
                                        patchResults.add(pr)
                                        if (pr["success"] as Boolean) patchCount++ else errorCount++
                                    }
                                }
                                java.io.File(editPath).writeText(newLines.joinToString("\n"))
                                mainHandler.post { result.success(mapOf("patchCount" to patchCount, "errorCount" to errorCount, "results" to patchResults)) }
                            } catch (e: Exception) {
                                mainHandler.post { result.error("PATCH_ERROR", e.message, null) }
                            }
                        }
                    }

                    "asm_revert_file" -> {
                        val editPath = call.argument<String>("editPath") ?: run {
                            result.error("INVALID_ARG", "editPath required", null); return@setMethodCallHandler
                        }
                        val origPath = call.argument<String>("origPath") ?: run {
                            result.error("INVALID_ARG", "origPath required", null); return@setMethodCallHandler
                        }
                        executor.execute {
                            try {
                                val orig = java.io.File(origPath)
                                val edit = java.io.File(editPath)
                                if (!orig.exists()) throw Exception("Original not found: $origPath")
                                orig.copyTo(edit, overwrite = true)
                                mainHandler.post { result.success(edit.readText()) }
                            } catch (e: Exception) {
                                mainHandler.post { result.error("REVERT_ERROR", e.message, null) }
                            }
                        }
                    }

                    "asm_search_all" -> {
                        val rootDir = call.argument<String>("rootDir") ?: run {
                            result.error("INVALID_ARG", "rootDir required", null); return@setMethodCallHandler
                        }
                        val keyword = call.argument<String>("keyword") ?: run {
                            result.error("INVALID_ARG", "keyword required", null); return@setMethodCallHandler
                        }
                        executor.execute {
                            try {
                                val hits = mutableListOf<Map<String, Any>>()
                                val kw = keyword.lowercase()
                                java.io.File(rootDir).walkTopDown().filter { it.isFile }.forEach { file ->
                                    var lineNum = 0
                                    file.forEachLine { line ->
                                        lineNum++
                                        if (line.lowercase().contains(kw)) {
                                            hits.add(mapOf("filePath" to file.absolutePath, "fileName" to file.name, "lineNum" to lineNum, "line" to line))
                                        }
                                    }
                                }
                                mainHandler.post { result.success(hits) }
                            } catch (e: Exception) {
                                mainHandler.post { result.error("SEARCH_ERROR", e.message, null) }
                            }
                        }
                    }

                    else -> result.notImplemented()
                }
            }

        // ── Notifications ────────────────────────────────────────────────────
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, NOTIF_CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "requestPermission" -> {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            val perm = Manifest.permission.POST_NOTIFICATIONS
                            if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED)
                                ActivityCompat.requestPermissions(this, arrayOf(perm), 9001)
                        }
                        result.success(true)
                    }
                    "showProcessing" -> {
                        NotificationHelper.showProcessing(this,
                            call.argument("title") ?: "Taurus Shield",
                            call.argument("body")  ?: "Processing…")
                        result.success(null)
                    }
                    "showResult" -> {
                        NotificationHelper.showResult(this,
                            call.argument<Boolean>("success") ?: true,
                            call.argument("title") ?: "Taurus Shield",
                            call.argument("body")  ?: "")
                        result.success(null)
                    }
                    "cancelProcessing" -> { NotificationHelper.cancelProcessing(this); result.success(null) }
                    else -> result.notImplemented()
                }
            }

        // ── HBC / Blutter channel ────────────────────────────────────────────
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, HBC_CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {

                    "startProcessing" -> {
                        val filePath  = call.argument<String>("filePath")  ?: run { result.error("INVALID_ARG", "filePath required", null); return@setMethodCallHandler }
                        val fileName  = call.argument<String>("fileName")  ?: ""
                        val mode      = call.argument<String>("mode")      ?: "dsm"
                        val outputDir = call.argument<String>("outputDir") ?: run { result.error("INVALID_ARG", "outputDir required", null); return@setMethodCallHandler }
                        val intent = Intent(this, ProcessingService::class.java).apply {
                            putExtra("filePath", filePath); putExtra("fileName", fileName)
                            putExtra("mode", mode);         putExtra("outputDir", outputDir)
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
                        else startService(intent)
                        result.success(true)
                    }

                    "getProcessingState" -> result.success(ProcessingService.getState(this))

                    "disassemble" -> {
                        val hbcFilePath = call.argument<String>("hbcFilePath") ?: run { result.error("INVALID_ARG", "hbcFilePath required", null); return@setMethodCallHandler }
                        val outputDir   = call.argument<String>("outputDir")   ?: run { result.error("INVALID_ARG", "outputDir required", null); return@setMethodCallHandler }
                        LogBridge.clear()
                        executor.execute {
                            val res = runPython("do_disassemble", hbcFilePath, outputDir)
                            LogBridge.done()
                            mainHandler.post { result.success(res) }
                        }
                    }

                    "assemble" -> {
                        val hasmFilePath = call.argument<String>("hasmFilePath") ?: run { result.error("INVALID_ARG", "hasmFilePath required", null); return@setMethodCallHandler }
                        val outputDir    = call.argument<String>("outputDir")    ?: run { result.error("INVALID_ARG", "outputDir required", null); return@setMethodCallHandler }
                        LogBridge.clear()
                        executor.execute {
                            val res = runPython("do_assemble", hasmFilePath, outputDir)
                            LogBridge.done()
                            mainHandler.post { result.success(res) }
                        }
                    }

                    "blutter_analyze" -> {
                        if (BlutterCloudService.isRunning(this)) {
                            result.success(mapOf("success" to false, "started" to false, "error" to "Analysis already in progress"))
                            return@setMethodCallHandler
                        }
                        val filePath  = call.argument<String>("filePath")  ?: run { result.error("INVALID_ARG", "filePath required", null); return@setMethodCallHandler }
                        val outputDir = call.argument<String>("outputDir") ?: run { result.error("INVALID_ARG", "outputDir required", null); return@setMethodCallHandler }
                        val fileName  = call.argument<String>("fileName")  ?: filePath.substringAfterLast('/')
                        val intent = Intent(this, BlutterCloudService::class.java).apply {
                            putExtra("filePath", filePath)
                            putExtra("fileName", fileName)
                            putExtra("outputDir", outputDir)
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
                        else startService(intent)
                        result.success(mapOf("success" to true, "started" to true))
                    }

                    "blutter_cloud_state" -> {
                        result.success(BlutterCloudService.getState(this))
                    }

                    "blutter_clear_state" -> {
                        BlutterCloudService.clearState(this)
                        result.success(null)
                    }

                    "blutter_cancel" -> {
                        BlutterCloudService.cancel(this)
                        result.success(null)
                    }

                    "blutter_save_page" -> {
                        val idx = call.argument<Int>("pageIdx") ?: 0
                        BlutterCloudService.savePage(this, idx)
                        result.success(null)
                    }

                    "dex2c_analyze" -> {
                        if (Dex2CCloudService.isRunning(this)) {
                            result.success(mapOf("success" to false, "started" to false, "error" to "Protection already in progress"))
                            return@setMethodCallHandler
                        }
                        val filePath  = call.argument<String>("filePath")  ?: run { result.error("INVALID_ARG", "filePath required", null); return@setMethodCallHandler }
                        val outputDir = call.argument<String>("outputDir") ?: run { result.error("INVALID_ARG", "outputDir required", null); return@setMethodCallHandler }
                        val fileName  = call.argument<String>("fileName")  ?: filePath.substringAfterLast('/')
                        val signApk   = call.argument<Boolean>("signApk") ?: true
                        val intent = Intent(this, Dex2CCloudService::class.java).apply {
                            putExtra("filePath", filePath)
                            putExtra("fileName", fileName)
                            putExtra("outputDir", outputDir)
                            putExtra("signApk", signApk)
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
                        else startService(intent)
                        result.success(mapOf("success" to true, "started" to true))
                    }

                    "dex2c_cloud_state" -> {
                        result.success(Dex2CCloudService.getState(this))
                    }

                    "dex2c_clear_state" -> {
                        Dex2CCloudService.clearState(this)
                        result.success(null)
                    }

                    "dex2c_cancel" -> {
                        Dex2CCloudService.cancel(this)
                        result.success(null)
                    }

                    "temphost_start_foreground" -> {
                        TempHostForegroundService.start(this)
                        result.success(null)
                    }

                    "temphost_stop_foreground" -> {
                        TempHostForegroundService.stop(this)
                        result.success(null)
                    }

                    "vmProtect_analyze" -> {
                        if (VmProtectCloudService.isRunning(this)) {
                            result.success(mapOf("success" to false, "started" to false, "error" to "VM protection already in progress"))
                            return@setMethodCallHandler
                        }
                        val filePath  = call.argument<String>("filePath")  ?: run { result.error("INVALID_ARG", "filePath required", null); return@setMethodCallHandler }
                        val outputDir = call.argument<String>("outputDir") ?: run { result.error("INVALID_ARG", "outputDir required", null); return@setMethodCallHandler }
                        val fileName  = call.argument<String>("fileName")  ?: filePath.substringAfterLast('/')
                        val signApk   = call.argument<Boolean>("signApk") ?: true
                        val intent = Intent(this, VmProtectCloudService::class.java).apply {
                            putExtra("filePath",  filePath)
                            putExtra("fileName",  fileName)
                            putExtra("outputDir", outputDir)
                            putExtra("signApk",   signApk)
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
                        else startService(intent)
                        result.success(mapOf("success" to true, "started" to true))
                    }

                    "vmProtect_cloud_state" -> {
                        result.success(VmProtectCloudService.getState(this))
                    }

                    "vmProtect_clear_state" -> {
                        VmProtectCloudService.clearState(this)
                        result.success(null)
                    }

                    "vmProtect_cancel" -> {
                        VmProtectCloudService.cancel(this)
                        result.success(null)
                    }

                    "dptshell_analyze" -> {
                        if (DptShellCloudService.isRunning(this)) {
                            result.success(mapOf("success" to false, "started" to false, "error" to "Shell protection already in progress"))
                            return@setMethodCallHandler
                        }
                        val filePath  = call.argument<String>("filePath")  ?: run { result.error("INVALID_ARG", "filePath required", null); return@setMethodCallHandler }
                        val outputDir = call.argument<String>("outputDir") ?: run { result.error("INVALID_ARG", "outputDir required", null); return@setMethodCallHandler }
                        val fileName  = call.argument<String>("fileName")  ?: filePath.substringAfterLast('/')
                        val signApk   = call.argument<Boolean>("signApk") ?: true
                        val intent = Intent(this, DptShellCloudService::class.java).apply {
                            putExtra("filePath", filePath)
                            putExtra("fileName", fileName)
                            putExtra("outputDir", outputDir)
                            putExtra("signApk", signApk)
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
                        else startService(intent)
                        result.success(mapOf("success" to true, "started" to true))
                    }

                    "dptshell_cloud_state" -> {
                        result.success(DptShellCloudService.getState(this))
                    }

                    "dptshell_clear_state" -> {
                        DptShellCloudService.clearState(this)
                        result.success(null)
                    }

                    "dptshell_cancel" -> {
                        DptShellCloudService.cancel(this)
                        result.success(null)
                    }

                    "apktool_analyze" -> {
                        if (ApkToolCloudService.isRunning(this)) {
                            result.success(mapOf("success" to false, "started" to false, "error" to "APK Tool operation already in progress"))
                            return@setMethodCallHandler
                        }
                        val filePath  = call.argument<String>("filePath")  ?: run { result.error("INVALID_ARG", "filePath required", null); return@setMethodCallHandler }
                        val outputDir = call.argument<String>("outputDir") ?: run { result.error("INVALID_ARG", "outputDir required", null); return@setMethodCallHandler }
                        val fileName  = call.argument<String>("fileName")  ?: filePath.substringAfterLast('/')
                        val mode      = call.argument<String>("mode")      ?: "decompile"
                        val signApk   = call.argument<Boolean>("signApk") ?: false
                        val intent = Intent(this, ApkToolCloudService::class.java).apply {
                            putExtra("filePath",  filePath)
                            putExtra("fileName",  fileName)
                            putExtra("outputDir", outputDir)
                            putExtra("mode",      mode)
                            putExtra("signApk",   signApk)
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
                        else startService(intent)
                        result.success(mapOf("success" to true, "started" to true))
                    }

                    "apktool_cloud_state" -> {
                        result.success(ApkToolCloudService.getState(this))
                    }

                    "apktool_clear_state" -> {
                        ApkToolCloudService.clearState(this)
                        result.success(null)
                    }

                    "apktool_cancel" -> {
                        ApkToolCloudService.cancel(this)
                        result.success(null)
                    }

                    "apks_extract_base" -> {
                        val apksPath  = call.argument<String>("apksPath")  ?: run { result.error("INVALID_ARG", "apksPath required", null); return@setMethodCallHandler }
                        val outputDir = call.argument<String>("outputDir") ?: run { result.error("INVALID_ARG", "outputDir required", null); return@setMethodCallHandler }
                        LogBridge.clear()
                        executor.execute {
                            val res = runPython("do_apks_extract_base", apksPath, outputDir)
                            LogBridge.done()
                            mainHandler.post { result.success(res) }
                        }
                    }

                    "apks_merge_universal" -> {
                        val apksPath  = call.argument<String>("apksPath")  ?: run { result.error("INVALID_ARG", "apksPath required", null); return@setMethodCallHandler }
                        val outputDir = call.argument<String>("outputDir") ?: run { result.error("INVALID_ARG", "outputDir required", null); return@setMethodCallHandler }
                        LogBridge.clear()
                        executor.execute {
                            val res = runPython("do_apks_merge_universal", apksPath, outputDir)
                            LogBridge.done()
                            mainHandler.post { result.success(res) }
                        }
                    }

                    "apk_to_aab" -> {
                        val apkPath   = call.argument<String>("apkPath")   ?: run { result.error("INVALID_ARG", "apkPath required", null); return@setMethodCallHandler }
                        val outputDir = call.argument<String>("outputDir") ?: run { result.error("INVALID_ARG", "outputDir required", null); return@setMethodCallHandler }
                        LogBridge.clear()
                        ApkToAabConverter().convert(
                            apkPath   = apkPath,
                            outputDir = outputDir,
                            onLog     = { line -> LogBridge.push(line) },
                            onComplete = { res ->
                                LogBridge.done()
                                result.success(res)
                            }
                        )
                    }

                    "aab_to_apk" -> {
                        val aabPath   = call.argument<String>("aabPath")   ?: run { result.error("INVALID_ARG", "aabPath required", null); return@setMethodCallHandler }
                        val outputDir = call.argument<String>("outputDir") ?: run { result.error("INVALID_ARG", "outputDir required", null); return@setMethodCallHandler }
                        LogBridge.clear()
                        executor.execute {
                            val res = runPython("do_aab_to_apk", aabPath, outputDir)
                            LogBridge.done()
                            mainHandler.post { result.success(res) }
                        }
                    }

                    "jsEncryptor_analyze" -> {
                        if (JsEncryptorService.isRunning(this)) {
                            result.success(mapOf("success" to false, "started" to false, "error" to "Encryption already in progress"))
                            return@setMethodCallHandler
                        }
                        val filePath    = call.argument<String>("filePath")    ?: run { result.error("INVALID_ARG", "filePath required", null); return@setMethodCallHandler }
                        val outputDir   = call.argument<String>("outputDir")   ?: run { result.error("INVALID_ARG", "outputDir required", null); return@setMethodCallHandler }
                        val fileName    = call.argument<String>("fileName")    ?: filePath.substringAfterLast('/')
                        val method      = call.argument<String>("method")      ?: "encmatrix"
                        val subzeroKey  = call.argument<String>("subzeroKey") ?: ""
                        val intent = Intent(this, JsEncryptorService::class.java).apply {
                            putExtra("filePath",    filePath)
                            putExtra("fileName",    fileName)
                            putExtra("outputDir",   outputDir)
                            putExtra("method",      method)
                            if (subzeroKey.isNotEmpty()) putExtra("subzeroKey", subzeroKey)
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
                        else startService(intent)
                        result.success(mapOf("success" to true, "started" to true))
                    }

                    "jsEncryptor_state" -> {
                        result.success(JsEncryptorService.getState(this))
                    }

                    "jsEncryptor_clear_state" -> {
                        JsEncryptorService.clearState(this)
                        result.success(null)
                    }

                    "jsEncryptor_cancel" -> {
                        JsEncryptorService.cancel(this)
                        result.success(null)
                    }

                    "jsEncryptor_batch_analyze" -> {
                        if (JsEncryptorService.isRunning(this)) {
                            result.success(mapOf("success" to false, "error" to "Already processing"))
                            return@setMethodCallHandler
                        }
                        val zipPath   = call.argument<String>("zipPath")   ?: run { result.error("INVALID_ARG", "zipPath required", null); return@setMethodCallHandler }
                        val zipName   = call.argument<String>("zipName")   ?: zipPath.substringAfterLast('/')
                        val outputDir = call.argument<String>("outputDir") ?: run { result.error("INVALID_ARG", "outputDir required", null); return@setMethodCallHandler }
                        val tasksJson = call.argument<String>("tasksJson") ?: "[]"
                        val intent = Intent(this, JsEncryptorService::class.java).apply {
                            putExtra("mode",      "batch")
                            putExtra("zipPath",   zipPath)
                            putExtra("zipName",   zipName)
                            putExtra("outputDir", outputDir)
                            putExtra("tasksJson", tasksJson)
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
                        else startService(intent)
                        result.success(mapOf("success" to true))
                    }

                    "jsEncryptor_batch_state" -> {
                        result.success(JsEncryptorService.getBatchState(this))
                    }

                    "jsEncryptor_batch_clear_state" -> {
                        JsEncryptorService.clearBatchState(this)
                        result.success(null)
                    }

                    "jsEncryptor_batch_cancel" -> {
                        JsEncryptorService.cancel(this)
                        result.success(null)
                    }

                    "phpAlom_start" -> {
                        if (PhpEncryptorService.isRunning(this)) {
                            result.success(mapOf("success" to false, "error" to "PHP Alom already running"))
                            return@setMethodCallHandler
                        }
                        val zipPath   = call.argument<String>("zipPath")   ?: run { result.error("INVALID_ARG", "zipPath required", null); return@setMethodCallHandler }
                        val baseName  = call.argument<String>("baseName")  ?: run { result.error("INVALID_ARG", "baseName required", null); return@setMethodCallHandler }
                        val depth     = call.argument<Int>("depth")        ?: 2
                        val outputDir = call.argument<String>("outputDir") ?: run { result.error("INVALID_ARG", "outputDir required", null); return@setMethodCallHandler }
                        val intent = Intent(this, PhpEncryptorService::class.java).apply {
                            putExtra("zipPath",   zipPath)
                            putExtra("baseName",  baseName)
                            putExtra("depth",     depth)
                            putExtra("outputDir", outputDir)
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
                        else startService(intent)
                        result.success(mapOf("success" to true))
                    }

                    "phpAlom_state" -> {
                        result.success(PhpEncryptorService.getState(this))
                    }

                    "phpAlom_clear_state" -> {
                        PhpEncryptorService.clearState(this)
                        result.success(null)
                    }

                    "phpAlom_cancel" -> {
                        PhpEncryptorService.cancel(this)
                        result.success(null)
                    }

                    "adsPatch_analyze" -> {
                        if (AdsPatchService.isRunning(this)) {
                            result.success(mapOf("success" to false, "started" to false, "error" to "Ads patch already in progress"))
                            return@setMethodCallHandler
                        }
                        val filePath   = call.argument<String>("filePath")   ?: run { result.error("INVALID_ARG", "filePath required", null); return@setMethodCallHandler }
                        val outputDir  = call.argument<String>("outputDir")  ?: run { result.error("INVALID_ARG", "outputDir required", null); return@setMethodCallHandler }
                        val fileName   = call.argument<String>("fileName")   ?: filePath.substringAfterLast('/')
                        val patchLevel = call.argument<String>("patchLevel") ?: "advance"
                        val signApk    = call.argument<Boolean>("signApk")   ?: true
                        val intent = Intent(this, AdsPatchService::class.java).apply {
                            putExtra("filePath",   filePath)
                            putExtra("fileName",   fileName)
                            putExtra("outputDir",  outputDir)
                            putExtra("patchLevel", patchLevel)
                            putExtra("signApk",    signApk)
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
                        else startService(intent)
                        result.success(mapOf("success" to true, "started" to true))
                    }

                    "adsPatch_cloud_state" -> {
                        result.success(AdsPatchService.getState(this))
                    }

                    "adsPatch_clear_state" -> {
                        AdsPatchService.clearState(this)
                        result.success(null)
                    }

                    "adsPatch_cancel" -> {
                        AdsPatchService.cancel(this)
                        result.success(null)
                    }

                    "reflutter_analyze" -> {
                        if (ReFlutterService.isRunning(this)) {
                            result.success(mapOf("success" to false, "started" to false, "error" to "ReFlutter already in progress"))
                            return@setMethodCallHandler
                        }
                        val filePath  = call.argument<String>("filePath")  ?: run { result.error("INVALID_ARG", "filePath required", null); return@setMethodCallHandler }
                        val outputDir = call.argument<String>("outputDir") ?: run { result.error("INVALID_ARG", "outputDir required", null); return@setMethodCallHandler }
                        val fileName  = call.argument<String>("fileName")  ?: filePath.substringAfterLast('/')
                        val intent = Intent(this, ReFlutterService::class.java).apply {
                            putExtra("filePath",  filePath)
                            putExtra("fileName",  fileName)
                            putExtra("outputDir", outputDir)
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
                        else startService(intent)
                        result.success(mapOf("success" to true, "started" to true))
                    }

                    "reflutter_cloud_state" -> {
                        result.success(ReFlutterService.getState(this))
                    }

                    "reflutter_clear_state" -> {
                        ReFlutterService.clearState(this)
                        result.success(null)
                    }

                    "reflutter_cancel" -> {
                        ReFlutterService.cancel(this)
                        result.success(null)
                    }

                    "pineHook_analyze" -> {
                        if (PineHookService.isRunning(this)) {
                            result.success(mapOf("success" to false, "started" to false, "error" to "Pine Hook injection already in progress"))
                            return@setMethodCallHandler
                        }
                        val filePath       = call.argument<String>("filePath")    ?: run { result.error("INVALID_ARG", "filePath required", null); return@setMethodCallHandler }
                        val outputDir      = call.argument<String>("outputDir")   ?: run { result.error("INVALID_ARG", "outputDir required", null); return@setMethodCallHandler }
                        val fileName       = call.argument<String>("fileName")    ?: filePath.substringAfterLast('/')
                        val modulesJson    = call.argument<String>("modulesJson") ?: "[]"
                        val intent = Intent(this, PineHookService::class.java).apply {
                            putExtra("filePath",    filePath)
                            putExtra("fileName",    fileName)
                            putExtra("outputDir",   outputDir)
                            putExtra("modulesJson", modulesJson)
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
                        else startService(intent)
                        result.success(mapOf("success" to true, "started" to true))
                    }

                    "pineHook_state" -> {
                        result.success(PineHookService.getState(this))
                    }

                    "pineHook_clear_state" -> {
                        PineHookService.clearState(this)
                        result.success(null)
                    }

                    "pineHook_cancel" -> {
                        PineHookService.cancel(this)
                        result.success(null)
                    }

                    "sslUnpin_analyze" -> {
                        if (SslUnpinService.isRunning(this)) {
                            result.success(mapOf("success" to false, "started" to false, "error" to "SSL Unpinner already running"))
                            return@setMethodCallHandler
                        }
                        val filePath  = call.argument<String>("filePath")  ?: run { result.error("INVALID_ARG", "filePath required", null); return@setMethodCallHandler }
                        val outputDir = call.argument<String>("outputDir") ?: run { result.error("INVALID_ARG", "outputDir required", null); return@setMethodCallHandler }
                        val fileName  = call.argument<String>("fileName")  ?: filePath.substringAfterLast('/')
                        val signApk   = call.argument<Boolean>("signApk")  ?: true
                        val intent = Intent(this, SslUnpinService::class.java).apply {
                            putExtra("filePath",  filePath)
                            putExtra("fileName",  fileName)
                            putExtra("outputDir", outputDir)
                            putExtra("signApk",   signApk)
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
                        else startService(intent)
                        result.success(mapOf("success" to true, "started" to true))
                    }

                    "sslUnpin_state" -> {
                        result.success(SslUnpinService.getState(this))
                    }

                    "sslUnpin_clear_state" -> {
                        SslUnpinService.clearState(this)
                        result.success(null)
                    }

                    "sslUnpin_cancel" -> {
                        SslUnpinService.cancel(this)
                        result.success(null)
                    }

                    "antiKiller_analyze" -> {
                        if (AntiKillerService.isRunning(this)) {
                            result.success(mapOf("success" to false, "started" to false, "error" to "Anti-killer already in progress"))
                            return@setMethodCallHandler
                        }
                        val filePath     = call.argument<String>("filePath")     ?: run { result.error("INVALID_ARG", "filePath required", null); return@setMethodCallHandler }
                        val outputDir    = call.argument<String>("outputDir")    ?: run { result.error("INVALID_ARG", "outputDir required", null); return@setMethodCallHandler }
                        val fileName     = call.argument<String>("fileName")     ?: filePath.substringAfterLast('/')
                        val mainActivity = call.argument<String>("mainActivity") ?: ""
                        val intent = Intent(this, AntiKillerService::class.java).apply {
                            putExtra("filePath",     filePath)
                            putExtra("fileName",     fileName)
                            putExtra("outputDir",    outputDir)
                            putExtra("mainActivity", mainActivity)
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
                        else startService(intent)
                        result.success(mapOf("success" to true, "started" to true))
                    }

                    "antiKiller_cloud_state" -> {
                        result.success(AntiKillerService.getState(this))
                    }

                    "antiKiller_clear_state" -> {
                        AntiKillerService.clearState(this)
                        result.success(null)
                    }

                    "antiKiller_cancel" -> {
                        AntiKillerService.cancel(this)
                        result.success(null)
                    }

                    else -> result.notImplemented()
                }
            }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, SECRETS_CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "getWorkerUrl"  -> result.success(NativeSecrets.workerUrl())
                    "getUpdaterUrl" -> result.success(NativeSecrets.updaterUrl())
                    "getAndroidId"  -> result.success(
                        Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: ""
                    )
                    else            -> result.notImplemented()
                }
            }

        // ── Python IDLE — on-device Chaquopy interpreter ─────────────────────
        val pythonIdleService = PythonIdleService()
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, PYTHON_CHANNEL)
            .setMethodCallHandler { call, result ->
                pythonIdleService.handle(call, result, mainHandler)
            }

        // ── DEX Tools — on-device DEX/Smali/Java conversion ──────────────────
        val dexToolsService = DexToolsService()
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, DEX_TOOLS_CHANNEL)
            .setMethodCallHandler { call, result ->
                executor.execute {
                    dexToolsService.handle(call, result)
                }
            }
    }

    // ── APK self-update via PackageInstaller API ───────────────────────────────
    // Works on Android 5+ including Android 13+ where ACTION_VIEW + content://
    // URIs fail due to queryIntentActivities returning empty without QUERY_ALL_PACKAGES.

    /**
     * Installs an APK using the PackageInstaller Session API (fully async).
     *
     * Thread model:
     *   - APK byte streaming runs on a NEW background thread (never blocks UI).
     *   - BroadcastReceiver registration and session.commit() are posted back to
     *     the main thread so there is no race with the broadcast arriving before
     *     the receiver is registered.
     *   - [onSuccess] / [onError] are always called on the main thread.
     *
     * How it works:
     *   1. Background thread: create session, stream APK bytes, fsync.
     *   2. Main thread: register one-shot BroadcastReceiver, commit session.
     *   3. System processes the APK; sends STATUS_PENDING_USER_ACTION broadcast
     *      carrying the REAL system confirmation Intent inside EXTRA_INTENT.
     *   4. Receiver extracts that intent and calls startActivity() — this shows
     *      the "Do you want to install?" dialog. If the Activity is in the
     *      background, the intent is saved as pendingConfirmIntent and launched
     *      on the next onResume() call.
     */
    private fun installViaSession(
        apkUri: Uri,
        fileUriString: String,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        val handler = Handler(Looper.getMainLooper())
        val pi = packageManager.packageInstaller

        Thread {
            // Resolve the APK source — prefer direct file access for efficiency
            val apkFile: File? = when {
                fileUriString.startsWith("file://") ->
                    try { File(java.net.URI(fileUriString)) } catch (_: Exception) { null }
                fileUriString.startsWith("/") -> File(fileUriString)
                else -> null
            }

            val fileSize = apkFile?.takeIf { it.exists() }?.length() ?: -1L

            var sessionId = -1
            var session: PackageInstaller.Session? = null

            try {
                sessionId = pi.createSession(
                    PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
                )
                session = pi.openSession(sessionId)

                val inputStream: java.io.InputStream =
                    if (apkFile?.exists() == true) apkFile.inputStream()
                    else contentResolver.openInputStream(apkUri)
                        ?: throw Exception("Cannot open APK stream")

                inputStream.buffered().use { input ->
                    session.openWrite("base.apk", 0, fileSize).use { output ->
                        input.copyTo(output, bufferSize = 65536)
                        session.fsync(output)
                    }
                }

                // Hand off register + commit to the main thread so the receiver
                // is guaranteed to be registered before the broadcast arrives.
                val capturedSession = session
                val capturedId      = sessionId

                handler.post {
                    try {
                        val action = "$packageName.INSTALLER_SESSION_$capturedId"

                        // One-shot receiver — fires when Android has processed the APK
                        val receiver = object : BroadcastReceiver() {
                            override fun onReceive(ctx: Context, intent: Intent) {
                                try { ctx.unregisterReceiver(this) } catch (_: Exception) {}

                                val status = intent.getIntExtra(
                                    PackageInstaller.EXTRA_STATUS,
                                    PackageInstaller.STATUS_FAILURE
                                )
                                if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
                                    // System gives us the REAL confirmation Intent
                                    @Suppress("DEPRECATION")
                                    val confirm: Intent? =
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                            intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
                                        } else {
                                            intent.getParcelableExtra(Intent.EXTRA_INTENT)
                                        }

                                    if (confirm != null) {
                                        installerLaunched = true
                                        confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        // Android 10+ blocks startActivity() from a background
                                        // context. If we're in the foreground, fire immediately;
                                        // otherwise save and launch on the next onResume().
                                        var launched = false
                                        if (isAppInForeground) {
                                            try {
                                                startActivity(confirm)
                                                launched = true
                                            } catch (_: Exception) {}
                                        }
                                        if (!launched) {
                                            pendingConfirmIntent = confirm
                                        }
                                    }
                                }
                                // STATUS_SUCCESS / STATUS_FAILURE — nothing more to do here.
                            }
                        }

                        // Clear any stale confirmation intent from a previous session
                        pendingConfirmIntent = null

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            registerReceiver(receiver, IntentFilter(action), RECEIVER_NOT_EXPORTED)
                        } else {
                            @Suppress("UnspecifiedRegisterReceiverFlag")
                            registerReceiver(receiver, IntentFilter(action))
                        }

                        val piFlags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
                        val broadcastPi = PendingIntent.getBroadcast(
                            this@MainActivity,
                            capturedId,
                            Intent(action).setPackage(packageName),
                            piFlags
                        )
                        capturedSession.commit(broadcastPi.intentSender)
                        capturedSession.close()
                        onSuccess()

                    } catch (e: Exception) {
                        try { capturedSession.close() } catch (_: Exception) {}
                        try { pi.abandonSession(capturedId) } catch (_: Exception) {}
                        onError(e.message ?: "Commit error")
                    }
                }

            } catch (e: Exception) {
                try { session?.close() } catch (_: Exception) {}
                if (sessionId >= 0) try { pi.abandonSession(sessionId) } catch (_: Exception) {}
                handler.post { onError(e.message ?: "Session error") }
            }
        }.start()
    }

    // ── ARM64 in-place patcher ────────────────────────────────────────────────

    private fun arm64PatchLine(raf: java.io.RandomAccessFile, origLine: String, newLine: String): Map<String, Any> {
        // Accept bare "0xADDR:", "// 0xADDR:", and Blutter-style "  //   0xADDR:" lines.
        // Lines without an address (annotations, separators, blank comments) are text-only
        // changes — saved to file but not patched into the SO binary, so skip silently.
        val addrMatch = Regex("""^\s*(?://+\s*)?\s*0x([0-9a-fA-F]+):""").find(origLine)
            ?: return mapOf("success" to true, "line" to origLine, "note" to "Skipped non-instruction line")
        val fileOffset = addrMatch.groupValues[1].toLongOrNull(16)
            ?: return mapOf("success" to false, "line" to origLine, "error" to "Invalid hex address")
        if (fileOffset < 0 || fileOffset + 3 >= raf.length())
            return mapOf("success" to false, "line" to origLine,
                "error" to "Offset 0x${fileOffset.toString(16)} out of file bounds")
        raf.seek(fileOffset)
        val bytes = ByteArray(4); raf.read(bytes)
        val origWord = (bytes[0].toInt() and 0xFF) or ((bytes[1].toInt() and 0xFF) shl 8) or
                       ((bytes[2].toInt() and 0xFF) shl 16) or ((bytes[3].toInt() and 0xFF) shl 24)
        // Strip both // and ; style comments from the instruction operands
        val newInstr = newLine.substringAfter(":")
            .replace(Regex("""//.*$"""), "")
            .replace(Regex("""\s*;.*$"""), "")
            .trim()
        if (newInstr.isEmpty())
            return mapOf("success" to false, "line" to origLine, "error" to "Empty instruction after address")
        // Dart pseudo-code annotations (e.g. "r0 = true", "r1 = null") share an address
        // with the real ARM64 instruction but cannot be encoded — skip them silently.
        val isDartAnnotation = newInstr.contains('=') &&
            Regex("""^[a-zA-Z]\w*\s*=""").containsMatchIn(newInstr)
        if (isDartAnnotation)
            return mapOf("success" to true, "line" to origLine,
                "offset" to "0x${fileOffset.toString(16)}", "note" to "Skipped Dart annotation")
        val newWord = encodeArm64Instruction(newInstr, fileOffset, origWord)
            ?: return mapOf("success" to false, "line" to origLine,
                "error" to "Cannot encode: '$newInstr' — unsupported instruction or invalid operands")
        if (newWord == origWord)
            return mapOf("success" to true, "line" to origLine,
                "offset" to "0x${fileOffset.toString(16)}", "note" to "No byte change")
        raf.seek(fileOffset)
        raf.write(byteArrayOf(
            (newWord and 0xFF).toByte(), ((newWord shr 8) and 0xFF).toByte(),
            ((newWord shr 16) and 0xFF).toByte(), ((newWord shr 24) and 0xFF).toByte()
        ))
        return mapOf("success" to true, "line" to origLine,
            "offset" to "0x${fileOffset.toString(16)}",
            "from" to "0x${origWord.toUInt().toString(16).padStart(8,'0')}",
            "to"   to "0x${newWord.toUInt().toString(16).padStart(8,'0')}")
    }

    // ── Full ARM64 encoder (radare-level coverage) ────────────────────────────

    private fun encodeArm64Instruction(instr: String, pc: Long, origWord: Int): Int? {
        val parts    = instr.trim().split(Regex("\\s+"), limit = 2)
        val mnemonic = parts[0].lowercase()
        val opStr    = if (parts.size > 1) parts[1].trim() else ""
        return when (mnemonic) {
            // ── System / misc ────────────────────────────────────────────────
            "nop"  -> 0xD503201F.toInt()
            "ret"  -> 0xD65F03C0.toInt()
            "isb"  -> 0xD5033FDF.toInt()
            "dsb"  -> 0xD503309F.toInt()
            "dmb"  -> 0xD5033BBF.toInt()
            "brk"  -> { val i = a64Imm(opStr)?.toInt() ?: 0
                        0xD4200000.toInt() or ((i and 0xFFFF) shl 5) }
            "hlt"  -> { val i = a64Imm(opStr)?.toInt() ?: 0
                        0xD4400000.toInt() or ((i and 0xFFFF) shl 5) }
            "svc"  -> { val i = a64Imm(opStr)?.toInt() ?: 0
                        0xD4000001.toInt() or ((i and 0xFFFF) shl 5) }
            // ── Branches ─────────────────────────────────────────────────────
            "b"  -> { val t = a64Imm(opStr) ?: return null; val d = ((t - pc) / 4).toInt()
                      if (d < -(1 shl 25) || d >= (1 shl 25)) return null
                      0x14000000.toInt() or (d and 0x03FFFFFF) }
            "bl" -> { val t = a64Imm(opStr) ?: return null; val d = ((t - pc) / 4).toInt()
                      if (d < -(1 shl 25) || d >= (1 shl 25)) return null
                      0x94000000.toInt() or (d and 0x03FFFFFF) }
            "blr" -> { val r = a64Reg(opStr) ?: return null; 0xD63F0000.toInt() or (r shl 5) }
            "br"  -> { val r = a64Reg(opStr) ?: return null; 0xD61F0000.toInt() or (r shl 5) }
            "cbz"  -> a64Cbz(0, opStr, pc)
            "cbnz" -> a64Cbz(1, opStr, pc)
            "tbz"  -> a64Tbz(0, opStr, pc)
            "tbnz" -> a64Tbz(1, opStr, pc)
            // ── Add / subtract ───────────────────────────────────────────────
            "add","adds","sub","subs" -> {
                val p = opStr.split(",").map { it.trim() }
                if (p.size >= 3 && !p[2].trimStart().startsWith("#") && a64Reg(p[2].split(",")[0]) != null)
                    a64AddSubShiftedReg(mnemonic, opStr)
                else
                    a64AddSubImm(mnemonic, opStr)
            }
            "cmp","cmn" -> {
                val sf   = a64Sf(opStr)
                val zr   = if (sf == 1) "xzr" else "wzr"
                val mn   = if (mnemonic == "cmp") "subs" else "adds"
                val p    = opStr.split(",", limit = 2); if (p.size < 2) return null
                val rhs  = p[1].trim()
                if (!rhs.startsWith("#") && a64Reg(rhs.split(",")[0]) != null)
                    a64AddSubShiftedReg(mn, "$zr, $opStr")
                else
                    a64AddSubImm(mn, "$zr, $opStr")
            }
            "neg","negs" -> {
                val sf = a64Sf(opStr); val zr = if (sf == 1) "xzr" else "wzr"
                val mn = if (mnemonic == "negs") "subs" else "sub"
                val p  = opStr.split(",", limit = 2); if (p.size < 2) return null
                a64AddSubShiftedReg(mn, "${p[0].trim()}, $zr, ${p[1].trim()}")
            }
            // ── Data movement ────────────────────────────────────────────────
            "mov","movz" -> a64Movz(opStr)
            "movn"       -> a64Movn(opStr)
            "movk"       -> a64Movk(opStr)
            // ── Logical ──────────────────────────────────────────────────────
            "and","ands","orr","orn","eor","eon","bic","bics" -> {
                val p = opStr.split(",").map { it.trim() }
                if (p.size >= 3 && p[2].trimStart().startsWith("#"))
                    a64LogicalImm(mnemonic, opStr)
                else
                    a64LogicalShiftedReg(mnemonic, opStr)
            }
            "tst" -> {
                val sf = a64Sf(opStr); val zr = if (sf == 1) "xzr" else "wzr"
                val p  = opStr.split(",", limit = 2); if (p.size < 2) return null
                if (p[1].trim().startsWith("#")) a64LogicalImm("ands", "$zr, $opStr")
                else a64LogicalShiftedReg("ands", "$zr, $opStr")
            }
            "mvn" -> {
                val sf = a64Sf(opStr); val zr = if (sf == 1) "xzr" else "wzr"
                val p  = opStr.split(",", limit = 2); if (p.size < 2) return null
                a64LogicalShiftedReg("orn", "${p[0].trim()}, $zr, ${p[1].trim()}")
            }
            // ── Conditional select / set ─────────────────────────────────────
            "csel"  -> a64Csel(0b00, opStr)
            "csinc" -> a64Csel(0b01, opStr)
            "csinv" -> a64Csel(0b10, opStr)
            "csneg" -> a64Csel(0b11, opStr)
            "cset"  -> a64Cset(0b01, opStr)
            "csetm" -> a64Cset(0b10, opStr)
            "cinc"  -> { val p = opStr.split(",").map { it.trim() }; if (p.size < 3) return null
                         a64Csel(0b01, "${p[0]}, ${p[1]}, ${p[1]}, ${a64InvertCond(p[2])}") }
            "cinv"  -> { val p = opStr.split(",").map { it.trim() }; if (p.size < 3) return null
                         a64Csel(0b10, "${p[0]}, ${p[1]}, ${p[1]}, ${a64InvertCond(p[2])}") }
            "cneg"  -> { val p = opStr.split(",").map { it.trim() }; if (p.size < 3) return null
                         a64Csel(0b11, "${p[0]}, ${p[1]}, ${p[1]}, ${a64InvertCond(p[2])}") }
            // ── Shift (immediate) ─────────────────────────────────────────────
            "lsl" -> a64ShiftImm("lsl", opStr)
            "lsr" -> a64ShiftImm("lsr", opStr)
            "asr" -> a64ShiftImm("asr", opStr)
            "ror" -> a64ShiftImm("ror", opStr)
            // ── Bitfield ─────────────────────────────────────────────────────
            "ubfm" -> a64Bitfield(2, opStr)
            "sbfm" -> a64Bitfield(0, opStr)
            "bfm"  -> a64Bitfield(1, opStr)
            "ubfx" -> { val p = opStr.split(",").map { it.trim() }; if (p.size < 4) return null
                        val l = a64Imm(p[2])?.toInt() ?: return null; val w = a64Imm(p[3])?.toInt() ?: return null
                        a64Bitfield(2, "${p[0]}, ${p[1]}, #$l, #${l+w-1}") }
            "sbfx" -> { val p = opStr.split(",").map { it.trim() }; if (p.size < 4) return null
                        val l = a64Imm(p[2])?.toInt() ?: return null; val w = a64Imm(p[3])?.toInt() ?: return null
                        a64Bitfield(0, "${p[0]}, ${p[1]}, #$l, #${l+w-1}") }
            "bfi"  -> { val p = opStr.split(",").map { it.trim() }; if (p.size < 4) return null
                        val l = a64Imm(p[2])?.toInt() ?: return null; val w = a64Imm(p[3])?.toInt() ?: return null
                        val sf = a64Sf(opStr); val bits = if (sf==1) 64 else 32
                        a64Bitfield(1, "${p[0]}, ${p[1]}, #${(bits-l)%bits}, #${w-1}") }
            "bfxil"-> { val p = opStr.split(",").map { it.trim() }; if (p.size < 4) return null
                        val l = a64Imm(p[2])?.toInt() ?: return null; val w = a64Imm(p[3])?.toInt() ?: return null
                        a64Bitfield(1, "${p[0]}, ${p[1]}, #$l, #${l+w-1}") }
            // ── Load / store (integer) ────────────────────────────────────────
            "ldr"   -> a64LdrStr(3, 1, opStr)
            "str"   -> a64LdrStr(3, 0, opStr)
            "ldrb"  -> a64LdrStr(0, 1, opStr)
            "strb"  -> a64LdrStr(0, 0, opStr)
            "ldrh"  -> a64LdrStr(1, 1, opStr)
            "strh"  -> a64LdrStr(1, 0, opStr)
            "ldrsb" -> { val sf = a64Sf(opStr); a64LdrStr(0, if(sf==1) 2 else 3, opStr) }
            "ldrsh" -> { val sf = a64Sf(opStr); a64LdrStr(1, if(sf==1) 2 else 3, opStr) }
            "ldrsw" -> a64LdrStr(2, 2, opStr)
            "ldur"  -> a64LdurStur(3, 1, opStr)
            "stur"  -> a64LdurStur(3, 0, opStr)
            "ldurb" -> a64LdurStur(0, 1, opStr)
            "sturb" -> a64LdurStur(0, 0, opStr)
            "ldurh" -> a64LdurStur(1, 1, opStr)
            "sturh" -> a64LdurStur(1, 0, opStr)
            "ldursw"-> a64LdurStur(2, 2, opStr)
            "ldp"   -> a64LdpStp(1, opStr)
            "stp"   -> a64LdpStp(0, opStr)
            // ── Multiply / divide ─────────────────────────────────────────────
            "mul"   -> a64Mul("mul",   opStr)
            "mneg"  -> a64Mul("mneg",  opStr)
            "madd"  -> a64Mul("madd",  opStr)
            "msub"  -> a64Mul("msub",  opStr)
            "smull" -> a64Mul("smull", opStr)
            "umull" -> a64Mul("umull", opStr)
            "smulh" -> a64Mul("smulh", opStr)
            "umulh" -> a64Mul("umulh", opStr)
            "sdiv"  -> a64Div(1, opStr)
            "udiv"  -> a64Div(0, opStr)
            // ── Address computation ───────────────────────────────────────────
            "adrp" -> { val p = opStr.split(",").map{it.trim()}; if(p.size<2) return null
                        val rd=a64Reg(p[0]) ?: return null
                        val t=a64Imm(p[1]) ?: return null
                        val d=((t - (pc and -0x1000L)) ushr 12).toInt()
                        if(d < -(1 shl 20)||d>=(1 shl 20)) return null
                        0x90000000.toInt() or ((d and 3) shl 29) or (((d ushr 2) and 0x7FFFF) shl 5) or rd }
            "adr"  -> { val p = opStr.split(",").map{it.trim()}; if(p.size<2) return null
                        val rd=a64Reg(p[0]) ?: return null
                        val t=a64Imm(p[1]) ?: return null
                        val d=(t - pc).toInt()
                        if(d < -(1 shl 20)||d>=(1 shl 20)) return null
                        0x10000000.toInt() or ((d and 3) shl 29) or (((d ushr 2) and 0x7FFFF) shl 5) or rd }
            else -> {
                if (mnemonic.startsWith("b.")) {
                    val cond = a64Cond(mnemonic.drop(2)) ?: return null
                    val t = a64Imm(opStr) ?: return null
                    val d = ((t - pc) / 4).toInt()
                    if (d < -(1 shl 18) || d >= (1 shl 18)) return null
                    0x54000000.toInt() or ((d and 0x7FFFF) shl 5) or cond
                } else null
            }
        }
    }

    // ── Register name parser (supports Blutter aliases) ───────────────────────
    private fun a64Reg(s: String): Int? {
        val t = s.trim().trimEnd(',').lowercase()
        return when {
            t == "xzr" || t == "wzr" || t == "null" -> 31
            t == "sp"  || t == "wsp" -> 31
            t == "fp"  -> 29
            t == "lr"  -> 30
            t.startsWith("x") -> t.drop(1).toIntOrNull()?.takeIf { it in 0..31 }
            t.startsWith("w") -> t.drop(1).toIntOrNull()?.takeIf { it in 0..31 }
            else -> null
        }
    }

    private fun a64Imm(s: String): Long? {
        val t = s.trim().trimEnd(',').trimStart('#')
        return when {
            t.startsWith("0x") || t.startsWith("0X") -> t.drop(2).toLongOrNull(16)
            t.startsWith("-0x") || t.startsWith("-0X") -> t.drop(3).toLongOrNull(16)?.let { -it }
            else -> t.toLongOrNull()
        }
    }

    private fun a64Sf(ops: String) = if (ops.trimStart().lowercase().firstOrNull() == 'x') 1 else 0

    // ── Bit-mask immediate encoder (DecodeBitMask inverse) ────────────────────
    private fun encodeBitMask(sf: Int, imm: Long): Triple<Int,Int,Int>? {
        if (imm == 0L) return null
        val bits = if (sf == 1) 64 else 32
        val fullMask = if (bits == 64) -1L else (1L shl bits) - 1L
        if (imm and fullMask == fullMask) return null
        for (log2 in 1..if (sf==1) 6 else 5) {
            val esize = 1 shl log2
            val eMask = if (esize == 64) -1L else (1L shl esize) - 1L
            val chunk = imm and eMask
            if (chunk == 0L || chunk == eMask) continue
            var ok = true
            var sh = esize
            while (sh < bits) { if (((imm ushr sh) and eMask) != chunk) { ok=false; break }; sh += esize }
            if (!ok) continue
            var transitions = 0; var runStart = 0
            for (i in 0 until esize) {
                val cur  = (chunk ushr i) and 1L
                val next = (chunk ushr ((i+1) % esize)) and 1L
                if (cur==0L && next==1L) { transitions++; runStart=(i+1)%esize }
            }
            if (transitions != 1) continue
            val numOnes = java.lang.Long.bitCount(chunk).toInt()
            return Triple(if(esize==64) 1 else 0, (esize - runStart) % esize, ((-esize) and 0x3F) or (numOnes-1))
        }
        return null
    }

    // ── Logical immediate ─────────────────────────────────────────────────────
    private fun a64LogicalImm(mnem: String, ops: String): Int? {
        val p = ops.split(",").map{it.trim()}; if(p.size<3) return null
        val sf=a64Sf(ops); val rd=a64Reg(p[0]) ?: return null; val rn=a64Reg(p[1]) ?: return null
        val imm=a64Imm(p[2]) ?: return null
        val (N,immr,imms) = encodeBitMask(sf, imm) ?: return null
        val opc = when(mnem) {"and"->0;"orr"->1;"eor"->2;"ands","tst"->3; else->return null}
        return (sf shl 31) or (opc shl 29) or (0b100100 shl 23) or (N shl 22) or (immr shl 16) or (imms shl 10) or (rn shl 5) or rd
    }

    // ── Logical shifted register ──────────────────────────────────────────────
    private fun a64LogicalShiftedReg(mnem: String, ops: String): Int? {
        val p = ops.split(",").map{it.trim()}; if(p.size<3) return null
        val sf=a64Sf(ops); val rd=a64Reg(p[0]) ?: return null
        val rn=a64Reg(p[1]) ?: return null; val rm=a64Reg(p[2]) ?: return null
        var shType=0; var shAmt=0
        if(p.size>=4){ val s=p[3].lowercase()
            shType=when{s.contains("lsl")->0;s.contains("lsr")->1;s.contains("asr")->2;s.contains("ror")->3;else->0}
            shAmt=a64Imm(s.replace(Regex("lsl|lsr|asr|ror"),""))?.toInt() ?: 0 }
        val (opc,N) = when(mnem){"and"->0b00 to 0;"bic"->0b00 to 1;"orr"->0b01 to 0;"orn"->0b01 to 1
            "eor"->0b10 to 0;"eon"->0b10 to 1;"ands"->0b11 to 0;"bics"->0b11 to 1; else->return null}
        return (sf shl 31) or (opc shl 29) or (0b01010 shl 24) or (shType shl 22) or (N shl 21) or (rm shl 16) or (shAmt shl 10) or (rn shl 5) or rd
    }

    // ── Add/sub shifted register ──────────────────────────────────────────────
    private fun a64AddSubShiftedReg(mnem: String, ops: String): Int? {
        val p = ops.split(",").map{it.trim()}; if(p.size<3) return null
        val sf=a64Sf(ops); val rd=a64Reg(p[0]) ?: return null
        val rn=a64Reg(p[1]) ?: return null; val rm=a64Reg(p[2]) ?: return null
        var shType=0; var shAmt=0
        if(p.size>=4){ val s=p[3].lowercase()
            shType=when{s.contains("lsl")->0;s.contains("lsr")->1;s.contains("asr")->2;else->0}
            shAmt=a64Imm(s.replace(Regex("lsl|lsr|asr"),""))?.toInt() ?: 0 }
        val op = if(mnem.startsWith("sub")||mnem=="cmp"||mnem=="neg"||mnem=="negs") 1 else 0
        val S  = if(mnem.endsWith("s")||mnem=="cmp"||mnem=="cmn") 1 else 0
        return (sf shl 31) or (op shl 30) or (S shl 29) or (0b01011 shl 24) or (shType shl 22) or (rm shl 16) or (shAmt shl 10) or (rn shl 5) or rd
    }

    // ── Load/store register ───────────────────────────────────────────────────
    // sizeHint 0=byte 1=half 2=word 3=auto(64/32 from reg)  opc: 0=store 1=load 2=ldrs64 3=ldrs32
    private fun a64LdrStr(sizeHint: Int, opc: Int, ops: String): Int? {
        val brkIdx = ops.indexOf('['); if(brkIdx<0) return null
        val rtStr  = ops.substring(0, brkIdx).trim().trimEnd(',').trim()
        val rt     = a64Reg(rtStr) ?: return null
        val isX    = rtStr.lowercase().trimStart().firstOrNull() == 'x'
        val size   = if(sizeHint==3) (if(isX) 3 else 2) else sizeHint
        val mem    = ops.substring(brkIdx)
        val isPreIdx = mem.contains("]!")
        val closeIdx = mem.indexOf(']')
        val postStr  = if(!isPreIdx && closeIdx >= 0 && closeIdx < mem.lastIndex)
            mem.substring(closeIdx+1).trim().trimStart(',').trim() else null
        val innerRaw = mem.removePrefix("[").let { raw ->
            if(isPreIdx) raw.replace("]!","") else raw.substring(0, raw.indexOf(']'))
        }
        val inner = innerRaw.split(",").map{it.trim()}
        val rn    = a64Reg(inner[0]) ?: return null
        val elemBytes = 1 shl size
        // Check for register-offset form: [Rn, Rm {, extend #s}]
        if(inner.size >= 2 && !inner[1].startsWith("#") && a64Reg(inner[1].split(" ")[0]) != null) {
            val rmStr = inner[1].split(" ")[0]
            val rm    = a64Reg(rmStr) ?: return null
            val extPart = if(inner.size >= 3) inner.drop(2).joinToString(",") else inner[1].substringAfter(" ", "")
            val extLow  = extPart.lowercase()
            val option  = when { extLow.contains("uxtw")->0b010; extLow.contains("sxtw")->0b110
                                 extLow.contains("sxtx")->0b111; else->0b011 }
            val shiftAmt = a64Imm(extLow.replace(Regex("uxtw|lsl|sxtw|sxtx"),""))?.toInt() ?: 0
            val S = if(shiftAmt > 0) 1 else 0
            return (size shl 30) or (0b111 shl 27) or (opc shl 22) or (1 shl 21) or (rm shl 16) or (option shl 13) or (S shl 12) or (0b10 shl 10) or (rn shl 5) or rt
        }
        val byteOff = if(inner.size>1) a64Imm(inner[1])?.toInt() ?: 0 else 0
        val postOff = postStr?.let { a64Imm(it)?.toInt() }
        return if(!isPreIdx && postOff==null) {
            // Unsigned offset
            if(byteOff < 0 || byteOff % elemBytes != 0 || byteOff / elemBytes > 0xFFF) return null
            (size shl 30) or (0b111 shl 27) or (1 shl 24) or (opc shl 22) or ((byteOff/elemBytes) shl 10) or (rn shl 5) or rt
        } else {
            // Pre/post indexed (simm9)
            val simm9 = if(isPreIdx) byteOff else postOff!!
            if(simm9 < -256 || simm9 > 255) return null
            val idx = if(isPreIdx) 0b11 else 0b01
            (size shl 30) or (0b111 shl 27) or (opc shl 22) or ((simm9 and 0x1FF) shl 12) or (idx shl 10) or (rn shl 5) or rt
        }
    }

    // ── Unscaled offset (LDUR/STUR) ───────────────────────────────────────────
    private fun a64LdurStur(sizeHint: Int, opc: Int, ops: String): Int? {
        val brkIdx = ops.indexOf('['); if(brkIdx<0) return null
        val rtStr  = ops.substring(0, brkIdx).trim().trimEnd(',').trim()
        val rt     = a64Reg(rtStr) ?: return null
        val isX    = rtStr.lowercase().trimStart().firstOrNull() == 'x'
        val size   = if(sizeHint==3) (if(isX) 3 else 2) else sizeHint
        val inner  = ops.substring(brkIdx+1, ops.indexOf(']')).split(",").map{it.trim()}
        val rn     = a64Reg(inner[0]) ?: return null
        val simm9  = if(inner.size>1) a64Imm(inner[1])?.toInt() ?: 0 else 0
        if(simm9 < -256 || simm9 > 255) return null
        return (size shl 30) or (0b111 shl 27) or (opc shl 22) or ((simm9 and 0x1FF) shl 12) or (rn shl 5) or rt
    }

    // ── Load/store pair ───────────────────────────────────────────────────────
    private fun a64LdpStp(L: Int, ops: String): Int? {
        val brkIdx = ops.indexOf('['); if(brkIdx<0) return null
        val regPart = ops.substring(0, brkIdx).split(",").map{it.trim().trimEnd(',')}
        if(regPart.size < 2) return null
        val rt1 = a64Reg(regPart[0]) ?: return null
        val rt2 = a64Reg(regPart[1]) ?: return null
        val sf  = if(regPart[0].lowercase().trimStart().firstOrNull()=='x') 1 else 0
        val opc = if(sf==1) 0b10 else 0b00
        val mem = ops.substring(brkIdx)
        val isPreIdx  = mem.contains("]!")
        val closeIdx  = mem.indexOf(']')
        val postStr   = if(!isPreIdx && closeIdx>=0 && closeIdx<mem.lastIndex)
            mem.substring(closeIdx+1).trim().trimStart(',').trim() else null
        val innerRaw  = mem.removePrefix("[").let { if(isPreIdx) it.replace("]!","") else it.substring(0, it.indexOf(']')) }
        val inner     = innerRaw.split(",").map{it.trim()}
        val rn        = a64Reg(inner[0]) ?: return null
        val byteOff   = if(inner.size>1) a64Imm(inner[1])?.toInt() ?: 0 else 0
        val postOff   = postStr?.let { a64Imm(it)?.toInt() }
        val scale     = if(sf==1) 3 else 2
        val rawOff    = if(isPreIdx||postOff!=null) (if(isPreIdx) byteOff else postOff!!) else byteOff
        if(rawOff % (1 shl scale) != 0) return null
        val imm7      = rawOff / (1 shl scale)
        if(imm7 < -64 || imm7 > 63) return null
        val mode      = when { isPreIdx->0b011; postOff!=null->0b001; else->0b010 }
        return (opc shl 30) or (0b101 shl 27) or (mode shl 23) or (L shl 22) or ((imm7 and 0x7F) shl 15) or (rt2 shl 10) or (rn shl 5) or rt1
    }

    // ── Shifts (immediate aliases of UBFM/SBFM/EXTR) ─────────────────────────
    private fun a64ShiftImm(mnem: String, ops: String): Int? {
        val p = ops.split(",").map{it.trim()}; if(p.size<3) return null
        val sf=a64Sf(ops); val bits=if(sf==1) 64 else 32
        val rd=a64Reg(p[0]) ?: return null; val rn=a64Reg(p[1]) ?: return null
        val amt=a64Imm(p[2])?.toInt() ?: return null
        if(amt<0||amt>=bits) return null
        val N=sf
        return when(mnem) {
            "lsl" -> { val immr=((-amt) and (bits-1)); val imms=bits-1-amt
                       (sf shl 31) or (0b10 shl 29) or (0b100110 shl 23) or (N shl 22) or (immr shl 16) or (imms shl 10) or (rn shl 5) or rd }
            "lsr" -> (sf shl 31) or (0b10 shl 29) or (0b100110 shl 23) or (N shl 22) or (amt shl 16) or ((bits-1) shl 10) or (rn shl 5) or rd
            "asr" -> (sf shl 31) or (0b00 shl 29) or (0b100110 shl 23) or (N shl 22) or (amt shl 16) or ((bits-1) shl 10) or (rn shl 5) or rd
            "ror" -> (sf shl 31) or (0b00 shl 29) or (0b100111 shl 23) or (N shl 22) or (rn shl 16) or (amt shl 10) or (rn shl 5) or rd
            else -> null
        }
    }

    // ── Bitfield (UBFM/SBFM/BFM) ─────────────────────────────────────────────
    private fun a64Bitfield(opc: Int, ops: String): Int? {
        val p = ops.split(",").map{it.trim()}; if(p.size<4) return null
        val sf=a64Sf(ops); val rd=a64Reg(p[0]) ?: return null; val rn=a64Reg(p[1]) ?: return null
        val immr=a64Imm(p[2])?.toInt() ?: return null; val imms=a64Imm(p[3])?.toInt() ?: return null
        val bits=if(sf==1) 64 else 32
        if(immr<0||immr>=bits||imms<0||imms>=bits) return null
        return (sf shl 31) or (opc shl 29) or (0b100110 shl 23) or (sf shl 22) or (immr shl 16) or (imms shl 10) or (rn shl 5) or rd
    }

    // ── Multiply ──────────────────────────────────────────────────────────────
    private fun a64Mul(mnem: String, ops: String): Int? {
        val p = ops.split(",").map{it.trim()}; if(p.size<3) return null
        val sf=a64Sf(ops)
        val rd=a64Reg(p[0]) ?: return null; val rn=a64Reg(p[1]) ?: return null; val rm=a64Reg(p[2]) ?: return null
        return when(mnem) {
            "mul"   -> (sf shl 31) or (0b11011 shl 24) or (rm shl 16) or (31 shl 10) or (rn shl 5) or rd
            "mneg"  -> (sf shl 31) or (0b11011 shl 24) or (rm shl 16) or (1 shl 15) or (31 shl 10) or (rn shl 5) or rd
            "madd"  -> { if(p.size<4) return null; val ra=a64Reg(p[3]) ?: return null
                         (sf shl 31) or (0b11011 shl 24) or (rm shl 16) or (ra shl 10) or (rn shl 5) or rd }
            "msub"  -> { if(p.size<4) return null; val ra=a64Reg(p[3]) ?: return null
                         (sf shl 31) or (0b11011 shl 24) or (rm shl 16) or (1 shl 15) or (ra shl 10) or (rn shl 5) or rd }
            "smull" -> 0x80000000.toInt() or (0b11011 shl 24) or (0b001 shl 21) or (rm shl 16) or (31 shl 10) or (rn shl 5) or rd
            "umull" -> 0x80000000.toInt() or (0b11011 shl 24) or (0b101 shl 21) or (rm shl 16) or (31 shl 10) or (rn shl 5) or rd
            "smulh" -> 0x80000000.toInt() or (0b11011 shl 24) or (0b010 shl 21) or (rm shl 16) or (31 shl 10) or (rn shl 5) or rd
            "umulh" -> 0x80000000.toInt() or (0b11011 shl 24) or (0b110 shl 21) or (rm shl 16) or (31 shl 10) or (rn shl 5) or rd
            else -> null
        }
    }

    // ── Divide ────────────────────────────────────────────────────────────────
    private fun a64Div(signed: Int, ops: String): Int? {
        val p = ops.split(",").map{it.trim()}; if(p.size<3) return null
        val sf=a64Sf(ops); val rd=a64Reg(p[0]) ?: return null
        val rn=a64Reg(p[1]) ?: return null; val rm=a64Reg(p[2]) ?: return null
        return (sf shl 31) or (0b11010110 shl 21) or (rm shl 16) or ((if(signed==1) 0b11 else 0b10) shl 10) or (rn shl 5) or rd
    }

    // ── Invert condition (for CINC/CINV/CNEG) ────────────────────────────────
    private fun a64InvertCond(c: String): String = when(c.lowercase().trim()) {
        "eq"->"ne";"ne"->"eq";"cs"->"cc";"hs"->"cc";"cc"->"cs";"lo"->"cs"
        "mi"->"pl";"pl"->"mi";"vs"->"vc";"vc"->"vs"
        "hi"->"ls";"ls"->"hi";"ge"->"lt";"lt"->"ge";"gt"->"le";"le"->"gt"
        "al"->"nv";"nv"->"al"; else->c
    }

    private fun a64AddSubImm(mnem: String, ops: String): Int? {
        val p = ops.split(",").map { it.trim() }; if (p.size < 3) return null
        val rd = a64Reg(p[0]) ?: return null; val rn = a64Reg(p[1]) ?: return null
        val imm = a64Imm(p[2]) ?: return null
        val sf = a64Sf(ops); val op = if (mnem.startsWith("sub")) 1 else 0; val S = if (mnem.endsWith("s")) 1 else 0
        var sh = 0; var imm12 = imm.toInt()
        if (p.size >= 4 && p[3].contains("12")) { sh = 1 }
        else if (imm > 0xFFF) { if (imm % 0x1000 == 0L && imm / 0x1000 <= 0xFFF) { sh=1; imm12=(imm/0x1000).toInt() } else return null }
        if (imm12 < 0 || imm12 > 0xFFF) return null
        return (sf shl 31) or (op shl 30) or (S shl 29) or (0x11 shl 24) or (sh shl 22) or (imm12 shl 10) or (rn shl 5) or rd
    }

    private fun a64Movz(ops: String): Int? {
        val p = ops.split(",").map { it.trim() }; if (p.size < 2) return null
        val rd = a64Reg(p[0]) ?: return null; val imm = a64Imm(p[1]) ?: return null
        val sf = a64Sf(ops); var hw = 0
        if (p.size >= 3) { hw = (a64Imm(p[2].lowercase().replace("lsl","").trim().trimStart('#'))?.toInt() ?: 0) / 16 }
        val imm16 = imm.toInt(); if (imm16 < 0 || imm16 > 0xFFFF || hw < 0 || hw > 3) return null
        return (sf shl 31) or (0b10 shl 29) or (0b100101 shl 23) or (hw shl 21) or (imm16 shl 5) or rd
    }

    private fun a64Movn(ops: String): Int? {
        val p = ops.split(",").map { it.trim() }; if (p.size < 2) return null
        val rd = a64Reg(p[0]) ?: return null; val imm = a64Imm(p[1]) ?: return null
        val sf = a64Sf(ops); var hw = 0
        if (p.size >= 3) { hw = (a64Imm(p[2].lowercase().replace("lsl","").trim().trimStart('#'))?.toInt() ?: 0) / 16 }
        val imm16 = imm.toInt(); if (imm16 < 0 || imm16 > 0xFFFF || hw < 0 || hw > 3) return null
        return (sf shl 31) or (0b00 shl 29) or (0b100101 shl 23) or (hw shl 21) or (imm16 shl 5) or rd
    }

    private fun a64Movk(ops: String): Int? {
        val p = ops.split(",").map { it.trim() }; if (p.size < 2) return null
        val rd = a64Reg(p[0]) ?: return null; val imm = a64Imm(p[1]) ?: return null
        val sf = a64Sf(ops); var hw = 0
        if (p.size >= 3) { hw = ((a64Imm(p[2].lowercase().replace("lsl","").trim().trimStart('#'))?.toInt() ?: 0)) / 16 }
        val imm16 = imm.toInt(); if (imm16 < 0 || imm16 > 0xFFFF || hw < 0 || hw > 3) return null
        return (sf shl 31) or (0b11 shl 29) or (0b100101 shl 23) or (hw shl 21) or (imm16 shl 5) or rd
    }

    private fun a64Cond(s: String): Int? = when (s.lowercase().trim()) {
        "eq"->0;"ne"->1;"cs","hs"->2;"cc","lo"->3;"mi"->4;"pl"->5;"vs"->6;"vc"->7
        "hi"->8;"ls"->9;"ge"->10;"lt"->11;"gt"->12;"le"->13;"al"->14;"nv"->15; else->null
    }

    private fun a64Csel(op2: Int, ops: String): Int? {
        val p = ops.split(",").map { it.trim() }; if (p.size < 4) return null
        val rd = a64Reg(p[0]) ?: return null; val rn = a64Reg(p[1]) ?: return null
        val rm = a64Reg(p[2]) ?: return null; val cond = a64Cond(p[3]) ?: return null
        val sf = a64Sf(ops)
        return (sf shl 31) or (0b11010100 shl 21) or (rm shl 16) or (cond shl 12) or (op2 shl 10) or (rn shl 5) or rd
    }

    private fun a64Cset(op2: Int, ops: String): Int? {
        val p = ops.split(",").map { it.trim() }; if (p.size < 2) return null
        val rd = a64Reg(p[0]) ?: return null; val cond = a64Cond(p[1]) ?: return null
        val sf = a64Sf(ops)
        return (sf shl 31) or (0b11010100 shl 21) or (31 shl 16) or ((cond xor 1) shl 12) or (op2 shl 10) or (31 shl 5) or rd
    }

    private fun a64Cbz(op: Int, ops: String, pc: Long): Int? {
        val p = ops.split(",").map { it.trim() }; if (p.size < 2) return null
        val rt = a64Reg(p[0]) ?: return null; val t = a64Imm(p[1]) ?: return null
        val sf = a64Sf(ops); val d = ((t - pc) / 4).toInt()
        if (d < -(1 shl 18) || d >= (1 shl 18)) return null
        return (sf shl 31) or (0b011010 shl 25) or (op shl 24) or ((d and 0x7FFFF) shl 5) or rt
    }

    private fun a64Tbz(op: Int, ops: String, pc: Long): Int? {
        val p = ops.split(",").map { it.trim() }; if (p.size < 3) return null
        val rt = a64Reg(p[0]) ?: return null
        val bit = a64Imm(p[1])?.toInt() ?: return null
        val t = a64Imm(p[2]) ?: return null; val d = ((t - pc) / 4).toInt()
        if (d < -(1 shl 13) || d >= (1 shl 13)) return null
        return ((bit shr 5) and 1 shl 31) or (0b011011 shl 25) or (op shl 24) or ((bit and 0x1F) shl 19) or ((d and 0x3FFF) shl 5) or rt
    }

    // ── HBC Python bridge ─────────────────────────────────────────────────────

    private fun runPython(method: String, arg1: String, arg2: String): Map<String, Any?> {
        return try {
            val py     = Python.getInstance()
            val bridge = py.getModule("api_bridge")
            val fn     = bridge[method] ?: return mapOf("status" to "error", "log" to "Function '$method' not found", "outputDir" to arg2)
            val map    = fn.call(arg1, arg2).asMap().entries.associate { it.key.toString() to it.value }
            mapOf(
                "status"     to (map["status"]?.toString()      ?: "error"),
                "log"        to (map["log"]?.toString()         ?: ""),
                "outputDir"  to (map["output_dir"]?.toString()  ?: arg2),
                "outputPath" to (map["output_path"]?.toString() ?: ""),
                "error"      to (map["error"]?.toString()       ?: "")
            )
        } catch (e: Exception) {
            mapOf("status" to "error", "log" to "Python error: ${e.message}", "outputDir" to arg2, "error" to (e.message ?: ""))
        }
    }

    /**
     * Converts any Drawable (including AdaptiveIconDrawable on API 26+) to a
     * 96×96 PNG byte array.  AdaptiveIcons are drawn on a plain white background
     * so the foreground layer renders cleanly (same approach as Glide's IconGlideModule).
     */
    private fun drawableToBytes(drawable: android.graphics.drawable.Drawable): ByteArray {
        val size = 96
        val bmp = android.graphics.Bitmap.createBitmap(size, size, android.graphics.Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bmp)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            drawable is android.graphics.drawable.AdaptiveIconDrawable) {
            canvas.drawColor(android.graphics.Color.WHITE)
        }
        drawable.setBounds(0, 0, size, size)
        drawable.draw(canvas)
        val baos = java.io.ByteArrayOutputStream()
        bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 90, baos)
        bmp.recycle()
        return baos.toByteArray()
    }
}
