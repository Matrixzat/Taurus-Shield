package com.taurus.shield

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.os.PowerManager
import java.io.File
import java.util.concurrent.Executors

class ForgeService : Service() {

    companion object {
        const val PREFS       = "forge_svc"
        const val KEY_RUNNING = "running"
        const val KEY_LOGS    = "logs"
        const val KEY_STATUS  = "result_status"
        const val KEY_OUTPUT  = "output_path"
        const val KEY_ERROR   = "error"
        const val KEY_MODE    = "mode"
        const val KEY_PROGRESS = "progress"

        const val NOTIF_ID    = 1010

        @Volatile private var _currentProcess: Process? = null

        fun cancelCurrent() {
            _currentProcess?.destroyForcibly()
            _currentProcess = null
        }

        fun isRunning(context: Context): Boolean {
            return context.getSharedPreferences(PREFS, MODE_PRIVATE)
                .getBoolean(KEY_RUNNING, false)
        }

        fun getState(context: Context): Map<String, Any?> {
            val p = context.getSharedPreferences(PREFS, MODE_PRIVATE)
            return mapOf(
                "running"  to p.getBoolean(KEY_RUNNING, false),
                "logs"     to (p.getString(KEY_LOGS, "") ?: ""),
                "status"   to (p.getString(KEY_STATUS, "") ?: ""),
                "output"   to (p.getString(KEY_OUTPUT, "") ?: ""),
                "error"    to (p.getString(KEY_ERROR, "") ?: ""),
                "mode"     to (p.getString(KEY_MODE, "") ?: ""),
                "progress" to p.getInt(KEY_PROGRESS, 0),
            )
        }
    }

    private val executor = Executors.newSingleThreadExecutor()
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val mode = intent?.getStringExtra("mode") ?: return bail()

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "TaurusShield::Forge")
        wakeLock?.acquire(30 * 60 * 1000L)

        NotificationHelper.createChannels(this)
        val notifTitle = if (mode == "compress") "Compressing..." else "Extracting..."
        val notif = NotificationHelper.buildProcessingNotif(this, notifTitle, "Black Forge")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, notif)
        }

        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        prefs.edit()
            .putBoolean(KEY_RUNNING, true)
            .putString(KEY_LOGS, "")
            .putString(KEY_STATUS, "")
            .putString(KEY_OUTPUT, "")
            .putString(KEY_ERROR, "")
            .putString(KEY_MODE, mode)
            .putInt(KEY_PROGRESS, 0)
            .apply()

        when (mode) {
            "compress" -> handleCompress(intent)
            "extract"  -> handleExtract(intent)
            else -> bail()
        }

        return START_NOT_STICKY
    }

    private fun handleCompress(intent: Intent) {
        val files      = intent.getStringArrayListExtra("files") ?: return finish("No files", true)
        val format     = intent.getStringExtra("format") ?: "7z"
        val level      = intent.getIntExtra("level", 7)
        val encryption = intent.getStringExtra("encryption") ?: "none"
        val password   = intent.getStringExtra("password") ?: ""
        val split      = intent.getStringExtra("split")
        val deleteSource = intent.getBooleanExtra("deleteSource", false)

        executor.execute {
            try {
                val bin = BinRef.c(applicationInfo.nativeLibraryDir)
                val outDir = File(Environment.getExternalStorageDirectory(), "Taurus-Shield/output/forge")
                outDir.mkdirs()
                val baseName = File(files.first()).nameWithoutExtension
                val ext = when {
                    format.contains(".") -> format
                    format == "7z" -> "7z"
                    format == "zip" -> "zip"
                    format == "tar" -> "tar"
                    format == "bzip2" -> "bz2"
                    format == "gzip" -> "gz"
                    format == "xz" -> "xz"
                    format == "lz4" -> "lz4"
                    format == "zstd" -> "zst"
                    else -> format
                }
                val outName = "$baseName.$ext"
                val outPath = File(outDir, outName).absolutePath

                val env = mapOf(
                    "HOME" to filesDir.absolutePath,
                    "TMPDIR" to cacheDir.absolutePath
                )

                val isTarCombo = format.startsWith("tar.")
                val args = mutableListOf(bin, "a")

                if (isTarCombo) {
                    updateLog("Creating tar archive...")
                    val innerTar = File(outDir, "$baseName.tar").absolutePath
                    val tarArgs = mutableListOf(bin, "a", "-ttar", innerTar)
                    tarArgs.addAll(files)
                    val tarPb = ProcessBuilder(tarArgs).redirectErrorStream(true)
                    tarPb.environment().putAll(env)
                    val tarProc = tarPb.start()
                    tarProc.inputStream.bufferedReader().readText()
                    tarProc.waitFor()

                    val compType = when (format.substringAfter("tar.")) {
                        "gz" -> "gzip"
                        "bz2" -> "bzip2"
                        "xz" -> "xz"
                        "lz4" -> "lz4"
                        "zstd" -> "zstd"
                        else -> format.substringAfter("tar.")
                    }
                    args.add("-t$compType")
                    args.add("-mx=$level")
                    args.add(outPath)
                    args.add(innerTar)
                } else {
                    args.add("-t$format")
                    args.add("-mx=$level")

                    if (encryption != "none" && password.isNotEmpty()) {
                        args.add("-p$password")
                        if (encryption == "aes256_full") {
                            args.add("-mhe=on")
                        }
                    }

                    if (split != null) {
                        val volSize = split.lowercase()
                            .replace("mb", "m")
                            .replace("gb", "g")
                        args.add("-v$volSize")
                    }

                    args.add(outPath)
                    args.addAll(files)
                }

                updateLog("Compressing ${files.size} file(s)...")

                val pb = ProcessBuilder(args).redirectErrorStream(true)
                pb.environment().putAll(env)

                val proc = pb.start()
                _currentProcess = proc
                val outputLines = StringBuilder()
                val pctRegex = Regex("""^\s*(\d+)\s*%""")
                proc.inputStream.bufferedReader().forEachLine { line ->
                    outputLines.appendLine(line)
                    val pct = pctRegex.find(line)?.groupValues?.get(1)?.toIntOrNull()
                    if (pct != null) {
                        updateProgress(pct)
                        updateLog("Compressing... $pct%")
                    }
                }
                val exitCode = proc.waitFor()
                _currentProcess = null

                val output = outputLines.toString()
                // 7-zip exit codes: 0 = success, 1 = warning (non-fatal, archive still created)
                val archiveCreated = File(outPath).exists()
                if (exitCode == 0 || (exitCode == 1 && archiveCreated)) {
                    if (deleteSource) {
                        files.forEach { path ->
                            try { File(path).delete() } catch (_: Exception) {}
                        }
                    }
                    updateProgress(100)
                    finish(outPath, false)
                    NotificationHelper.showResult(
                        this, true,
                        "Compression Complete",
                        "Saved to: /Taurus-Shield/output/forge/$outName"
                    )
                } else if (exitCode == 255 || exitCode == -1) {
                    finish("Cancelled by user", true)
                } else {
                    val cleanOutput = output.lines()
                        .filterNot { it.startsWith("~ ") }
                        .joinToString("\n").trim()
                        .ifEmpty { output }.take(200)
                    finish("Exit code: $exitCode\n$cleanOutput", true)
                    NotificationHelper.showResult(this, false, "Compression Failed", cleanOutput)
                }
            } catch (e: Exception) {
                finish(e.message ?: "Unknown error", true)
                NotificationHelper.showResult(this, false, "Forge Error", e.message ?: "")
            }
        }
    }

    private fun handleExtract(intent: Intent) {
        val file     = intent.getStringExtra("file") ?: return finish("No file", true)
        val password = intent.getStringExtra("password") ?: ""

        executor.execute {
            try {
                val bin = BinRef.c(applicationInfo.nativeLibraryDir)
                val srcFile = File(file)
                val outDir = File(Environment.getExternalStorageDirectory(),
                    "Taurus-Shield/output/forge/${srcFile.nameWithoutExtension}")
                outDir.mkdirs()

                val args = mutableListOf(bin, "x", "-y")
                if (password.isNotEmpty()) {
                    args.add("-p$password")
                }
                args.add("-o${outDir.absolutePath}")
                args.add(file)

                val env = mapOf(
                    "HOME" to filesDir.absolutePath,
                    "TMPDIR" to cacheDir.absolutePath
                )

                updateLog("Extracting ${srcFile.name}...")

                val pb = ProcessBuilder(args).redirectErrorStream(true)
                pb.environment().putAll(env)

                val proc = pb.start()
                _currentProcess = proc
                val outputLines = StringBuilder()
                val pctRegex = Regex("""^\s*(\d+)\s*%""")
                proc.inputStream.bufferedReader().forEachLine { line ->
                    outputLines.appendLine(line)
                    val pct = pctRegex.find(line)?.groupValues?.get(1)?.toIntOrNull()
                    if (pct != null) {
                        updateProgress(pct)
                        updateLog("Extracting... $pct%")
                    }
                }
                val exitCode = proc.waitFor()
                _currentProcess = null

                val output = outputLines.toString()
                // 7-zip exit codes: 0 = success, 1 = warning (non-fatal, files still extracted)
                val extractedSomething = outDir.listFiles()?.isNotEmpty() == true
                if (exitCode == 0 || (exitCode == 1 && extractedSomething)) {
                    updateProgress(100)
                    finish(outDir.absolutePath, false)
                    NotificationHelper.showResult(
                        this, true,
                        "Extraction Complete",
                        "Saved to: /Taurus-Shield/output/forge/${srcFile.nameWithoutExtension}/"
                    )
                } else if (exitCode == 255 || exitCode == -1) {
                    finish("Cancelled by user", true)
                } else {
                    val cleanOutput = output.lines()
                        .filterNot { it.startsWith("~ ") }
                        .joinToString("\n").trim()
                        .ifEmpty { output }.take(200)
                    finish("Exit code: $exitCode\n$cleanOutput", true)
                    NotificationHelper.showResult(this, false, "Extraction Failed", cleanOutput)
                }
            } catch (e: Exception) {
                finish(e.message ?: "Unknown error", true)
                NotificationHelper.showResult(this, false, "Forge Error", e.message ?: "")
            }
        }
    }

    private fun updateLog(msg: String) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString(KEY_LOGS, msg)
            .apply()
    }

    private fun updateProgress(pct: Int) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putInt(KEY_PROGRESS, pct.coerceIn(0, 100))
            .apply()
    }

    private fun finish(result: String, isError: Boolean) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putBoolean(KEY_RUNNING, false)
            .putString(if (isError) KEY_ERROR else KEY_OUTPUT, result)
            .putString(KEY_STATUS, if (isError) "error" else "success")
            .apply()

        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun bail(): Int {
        finish("Invalid arguments", true)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        wakeLock?.let { if (it.isHeld) it.release() }
    }
}
