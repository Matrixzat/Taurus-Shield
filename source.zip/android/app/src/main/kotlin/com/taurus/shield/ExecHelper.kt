package com.taurus.shield

object ExecHelper {

    init {
        System.loadLibrary("exec_helper")
    }

    private var logCallback: ((String) -> Unit)? = null

    @JvmStatic
    fun onNativeLog(line: String) {
        logCallback?.invoke(line)
    }

    @JvmStatic
    private external fun nativeExec(binaryPath: String, args: Array<String>): Int

    fun exec(binaryPath: String, args: List<String>, onLog: (String) -> Unit): Int {
        logCallback = onLog
        return try {
            nativeExec(binaryPath, args.toTypedArray())
        } finally {
            logCallback = null
        }
    }
}
