package com.taurus.shield

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class TamperActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0A0A0A"))
            setPadding(72, 72, 72, 72)
        }

        val icon = TextView(this).apply {
            text = "\uD83D\uDEE1"
            textSize = 64f
            gravity = Gravity.CENTER
        }

        val title = TextView(this).apply {
            text = "Integrity Violation Detected"
            textSize = 22f
            setTextColor(Color.parseColor("#FF3B30"))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, 40, 0, 0)
        }

        val body = TextView(this).apply {
            text = "A compromised environment has been detected — root access (su/Magisk), a hooking framework (Frida), or an active debugger is present on this device.\n\nTaurus Shield has been suspended to protect its internal components and your data."
            textSize = 14f
            setTextColor(Color.parseColor("#AAAAAA"))
            gravity = Gravity.CENTER
            setLineSpacing(0f, 1.5f)
            setPadding(0, 32, 0, 0)
        }

        val divider = TextView(this).apply {
            text = "─────────────────────────"
            setTextColor(Color.parseColor("#333333"))
            gravity = Gravity.CENTER
            setPadding(0, 40, 0, 40)
        }

        val detail = TextView(this).apply {
            text = "Checks: su/Magisk paths · Frida maps scan · Port 27042 · TracerPid · ptrace(TRACEME)"
            textSize = 11f
            setTextColor(Color.parseColor("#555555"))
            gravity = Gravity.CENTER
        }

        val exitBtn = Button(this).apply {
            text = "Close Application"
            textSize = 15f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#FF3B30"))
            setPadding(0, 32, 0, 32)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = 64
            layoutParams = lp
            setOnClickListener {
                finishAffinity()
                android.os.Process.killProcess(android.os.Process.myPid())
            }
        }

        root.addView(icon)
        root.addView(title)
        root.addView(body)
        root.addView(divider)
        root.addView(detail)
        root.addView(exitBtn)

        setContentView(root)
    }

    override fun onBackPressed() {
        // Block back navigation — user must exit
        finishAffinity()
        android.os.Process.killProcess(android.os.Process.myPid())
    }
}
