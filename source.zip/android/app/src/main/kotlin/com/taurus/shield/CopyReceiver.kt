package com.taurus.shield

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.Toast

class CopyReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_COPY_CRASH = "com.taurus.shield.COPY_CRASH"
        const val EXTRA_LOG         = "crash_log"
        const val EXTRA_NOTIF_ID    = "notif_id"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_COPY_CRASH) return
        val log     = intent.getStringExtra(EXTRA_LOG) ?: return
        val notifId = intent.getIntExtra(EXTRA_NOTIF_ID, -1)

        val pending = goAsync()
        Thread {
            try {
                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("crash_log", log))
                Handler(Looper.getMainLooper()).post {
                    Toast.makeText(context, "Crash log copied", Toast.LENGTH_SHORT).show()
                }
                if (notifId >= 0) {
                    val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    nm.cancel(notifId)
                }
            } finally {
                pending.finish()
            }
        }.start()
    }
}
