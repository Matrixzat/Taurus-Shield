package com.taurus.shield

import android.os.Handler
import com.chaquo.python.Python
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.util.concurrent.Executors

class PythonIdleService {

    private val executor = Executors.newSingleThreadExecutor()

    // Injected once per run — intercepts input() so it doesn't hang
    private val INPUT_MOCK = """
import builtins as _bi
def _idle_input(prompt=''):
    import sys as _s
    if prompt:
        _s.stdout.write(str(prompt))
    raise EOFError("[Python IDLE] input() is not supported. Assign values as variables instead.")
_bi.input = _idle_input
del _idle_input, _bi
""".trimIndent()

    // Clears all user-defined names from __main__ (keeps dunder names)
    private val RESET_CODE = """
import sys as _sys
_main = _sys.modules['__main__']
for _k in list(vars(_main).keys()):
    if not _k.startswith('__'):
        try:
            delattr(_main, _k)
        except Exception:
            pass
del _sys, _main, _k
""".trimIndent()

    fun handle(call: MethodCall, result: MethodChannel.Result, mainHandler: Handler) {
        when (call.method) {

            // ── Run code ──────────────────────────────────────────────────────
            "run_code" -> {
                val code = call.argument<String>("code") ?: run {
                    result.error("NO_CODE", "No code provided", null)
                    return
                }
                executor.execute {
                    var stdout = ""
                    var stderr = ""
                    try {
                        val py       = Python.getInstance()
                        val io       = py.getModule("io")
                        val sys      = py.getModule("sys")
                        val builtins = py.getBuiltins()

                        val stdoutBuf = io.callAttr("StringIO")
                        val stderrBuf = io.callAttr("StringIO")
                        sys["stdout"] = stdoutBuf
                        sys["stderr"] = stderrBuf

                        try {
                            // vars(__main__) gives us the module's global dict
                            val mainModule = py.getModule("__main__")
                            val globals    = builtins.callAttr("vars", mainModule)

                            // Install input() mock so it never hangs
                            builtins.callAttr("exec", INPUT_MOCK, globals)
                            // Run user code in the persistent __main__ namespace
                            builtins.callAttr("exec", code, globals)

                        } catch (e: com.chaquo.python.PyException) {
                            val msg = e.message ?: "Python error"
                            try { stderrBuf.callAttr("write", "$msg\n") }
                            catch (_: Exception) { stderr = msg }
                        } catch (e: Exception) {
                            val msg = e.message ?: "Unexpected error"
                            try { stderrBuf.callAttr("write", "$msg\n") }
                            catch (_: Exception) { stderr = msg }
                        }

                        stdout = try { stdoutBuf.callAttr("getvalue").toString() } catch (_: Exception) { "" }
                        if (stderr.isEmpty()) {
                            stderr = try { stderrBuf.callAttr("getvalue").toString() } catch (_: Exception) { "" }
                        }

                    } catch (e: Exception) {
                        stderr = "Runtime error: ${e.message}"
                    } finally {
                        // Restore stdout/stderr so other features stay intact
                        try {
                            val sys2 = Python.getInstance().getModule("sys")
                            sys2["stdout"] = sys2["__stdout__"]
                            sys2["stderr"] = sys2["__stderr__"]
                        } catch (_: Exception) {}
                    }

                    val out = stdout
                    val err = stderr
                    mainHandler.post {
                        result.success(mapOf("stdout" to out, "stderr" to err))
                    }
                }
            }

            // ── Reset session — wipes all user-defined names from __main__ ──
            "reset_session" -> {
                executor.execute {
                    try {
                        val py       = Python.getInstance()
                        val builtins = py.getBuiltins()
                        builtins.callAttr("exec", RESET_CODE)
                    } catch (_: Exception) {}
                    mainHandler.post { result.success(null) }
                }
            }

            else -> result.notImplemented()
        }
    }
}
