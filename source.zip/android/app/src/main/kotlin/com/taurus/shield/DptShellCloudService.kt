package com.taurus.shield

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

class DptShellCloudService : Service() {

    companion object {
        const val PREFS = "dptshell_cloud_svc"
        const val KEY_RUNNING     = "running"
        const val KEY_PHASE       = "phase"
        const val KEY_LOGS        = "logs"
        const val KEY_STATUS      = "result_status"
        const val KEY_OUTPUT_DIR  = "output_dir"
        const val KEY_ERROR       = "error"
        const val KEY_FILE_NAME   = "file_name"
        const val KEY_FILE_PATH   = "file_path"
        const val KEY_JOB_ID      = "job_id"
        const val KEY_ASSET_ID    = "asset_id"
        const val KEY_RUN_ID      = "run_id"
        const val KEY_TRIGGER_AT  = "trigger_at"
        const val KEY_STEP        = "current_step"

        fun isRunning(context: Context): Boolean {
            return context.getSharedPreferences(PREFS, MODE_PRIVATE)
                .getBoolean(KEY_RUNNING, false)
        }

        fun getState(context: Context): Map<String, Any?> {
            val p = context.getSharedPreferences(PREFS, MODE_PRIVATE)
            return mapOf(
                "running"     to p.getBoolean(KEY_RUNNING, false),
                "phase"       to (p.getString(KEY_PHASE, "") ?: ""),
                "logs"        to (p.getString(KEY_LOGS, "") ?: ""),
                "status"      to (p.getString(KEY_STATUS, "") ?: ""),
                "outputDir"   to (p.getString(KEY_OUTPUT_DIR, "") ?: ""),
                "error"       to (p.getString(KEY_ERROR, "") ?: ""),
                "fileName"    to (p.getString(KEY_FILE_NAME, "") ?: ""),
                "filePath"    to (p.getString(KEY_FILE_PATH, "") ?: ""),
                "jobId"       to (p.getString(KEY_JOB_ID, "") ?: ""),
                "runId"       to p.getLong(KEY_RUN_ID, 0),
                "currentStep" to (p.getString(KEY_STEP, "") ?: ""),
            )
        }

        fun clearState(context: Context) {
            context.getSharedPreferences(PREFS, MODE_PRIVATE).edit().clear().apply()
        }

        private val cancelFlag = AtomicBoolean(false)
        private var workerThread: Thread? = null

        fun cancel(context: Context) {
            cancelFlag.set(true)
            workerThread?.interrupt()
            context.stopService(Intent(context, DptShellCloudService::class.java))
        }
    }

    private val executor = Executors.newSingleThreadExecutor()
    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var prefs: SharedPreferences
    private val logBuf = StringBuilder()

    private val WORKER by lazy { NativeSecrets.workerUrl() }

    override fun onBind(intent: Intent?): IBinder? = null

    private var signApk = true

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val filePath  = intent?.getStringExtra("filePath")  ?: return bail()
        val fileName  = intent.getStringExtra("fileName")   ?: filePath.substringAfterLast('/')
        val outputDir = intent.getStringExtra("outputDir")  ?: return bail()
        signApk       = intent.getBooleanExtra("signApk", true)

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "TaurusShield::DptShellCloud")
        wakeLock?.acquire(60 * 60 * 1000L)

        NotificationHelper.createChannels(this)
        val notif = NotificationHelper.buildProcessingNotif(this, "DPT Shell Protection", "Uploading...")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NotificationHelper.NOTIF_PROCESSING, notif,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NotificationHelper.NOTIF_PROCESSING, notif)
        }

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        prefs.edit()
            .putBoolean(KEY_RUNNING, true)
            .putString(KEY_PHASE, "uploading")
            .putString(KEY_LOGS, "")
            .putString(KEY_STATUS, "")
            .putString(KEY_OUTPUT_DIR, outputDir)
            .putString(KEY_ERROR, "")
            .putString(KEY_FILE_NAME, fileName)
            .putString(KEY_FILE_PATH, filePath)
            .putString(KEY_JOB_ID, "")
            .putLong(KEY_RUN_ID, 0)
            .putString(KEY_STEP, "Uploading")
            .apply()

        cancelFlag.set(false)
        LogBridge.clear()

        executor.execute {
            workerThread = Thread.currentThread()
            runCloudProtection(filePath, fileName, outputDir)
        }

        return START_NOT_STICKY
    }

    private fun bail(): Int { stopSelf(); return START_NOT_STICKY }

    private fun log(line: String) {
        LogBridge.push(line)
        logBuf.appendLine(line)
        prefs.edit().putString(KEY_LOGS, logBuf.toString()).apply()
    }

    private fun updateStep(step: String) {
        prefs.edit().putString(KEY_STEP, step).apply()
        NotificationHelper.showProcessing(this, "DPT Shell Protection", step)
    }

    private fun finish(success: Boolean, outputDir: String, error: String) {
        LogBridge.done()
        prefs.edit()
            .putBoolean(KEY_RUNNING, false)
            .putString(KEY_STATUS, if (success) "success" else "error")
            .putString(KEY_OUTPUT_DIR, outputDir)
            .putString(KEY_ERROR, error)
            .putString(KEY_PHASE, "done")
            .apply()

        val fileName = prefs.getString(KEY_FILE_NAME, "file") ?: "file"
        NotificationHelper.showResult(
            this, success,
            if (success) "DPT Shell — Complete" else "DPT Shell — Failed",
            if (success) "$fileName shell protected successfully. Tap to view results."
            else "Shell protection failed: $error"
        )

        releaseWake()
        stopForeground(true)
        stopSelf()
    }

    private fun finishCancelled(outputDir: String) {
        cancelFlag.set(false)
        val runId = prefs.getLong(KEY_RUN_ID, 0L)
        if (runId != 0L) {
            try { workerPost("/cancel-run?run_id=$runId") } catch (_: Exception) {}
        }
        LogBridge.push("Shell protection cancelled by user.")
        LogBridge.done()
        prefs.edit()
            .putBoolean(KEY_RUNNING, false)
            .putString(KEY_STATUS, "cancelled")
            .putString(KEY_OUTPUT_DIR, outputDir)
            .putString(KEY_ERROR, "Cancelled by user")
            .putString(KEY_PHASE, "done")
            .apply()
        NotificationHelper.cancelProcessing(this)
        releaseWake()
        stopForeground(true)
        stopSelf()
    }

    private fun packApkToZip(apkFile: File): File {
        val tmp = File(cacheDir, "dpt_pack_${System.currentTimeMillis()}.zip")
        ZipOutputStream(FileOutputStream(tmp)).use { zos ->
            zos.putNextEntry(ZipEntry(apkFile.name))
            apkFile.inputStream().use { input -> input.copyTo(zos) }
            zos.closeEntry()
        }
        return tmp
    }

    private fun runCloudProtection(filePath: String, fileName: String, outputDir: String) {
        val file = File(filePath)
        val sizeMb = String.format("%.1f", file.length() / 1_048_576.0)

        try {
            val uploadFile: File
            if (file.name.lowercase().endsWith(".apk")) {
                updateStep("Packaging APK for upload...")
                log("Packaging APK into ZIP for cloud processing...")
                uploadFile = packApkToZip(file)
                log("Package ready: ${uploadFile.name}")
            } else {
                uploadFile = file
                log("Using provided ZIP file.")
            }

            val uploadMb = String.format("%.1f", uploadFile.length() / 1_048_576.0)
            updateStep("Uploading $uploadMb MB...")
            log("Uploading $uploadMb MB for shell protection...")
            val triggerAt = System.currentTimeMillis()
            val signParam = if (signApk) "true" else "false"
            val responseJson = withNetworkRetry("upload") { workerPostFile("/dptshell?sign=$signParam", uploadFile) } ?: run {
                if (uploadFile != file) uploadFile.delete()
                log("Upload failed — check connection")
                finish(false, outputDir, "Upload failed"); return
            }
            if (uploadFile != file) uploadFile.delete()

            val responseObj = JSONObject(responseJson)
            val jobId   = responseObj.getString("job_id")
            val assetId = responseObj.getLong("asset_id")
            log("Upload complete. Job ID: $jobId")

            prefs.edit()
                .putString(KEY_JOB_ID, jobId)
                .putLong(KEY_ASSET_ID, assetId)
                .putLong(KEY_TRIGGER_AT, triggerAt)
                .putString(KEY_PHASE, "finding_run")
                .apply()

            updateStep("Dispatching to cluster...")
            log("Dispatching to secure protection cluster...")
            Thread.sleep(4_000)
            if (cancelFlag.get()) { finishCancelled(outputDir); return }

            val runId = findRun(triggerAt)
            if (cancelFlag.get()) { finishCancelled(outputDir); return }
            if (runId == null) {
                workerDelete("/asset?asset_id=$assetId")
                log("Could not reach the protection engine")
                finish(false, outputDir, "Could not reach protection engine"); return
            }

            prefs.edit()
                .putLong(KEY_RUN_ID, runId)
                .putString(KEY_PHASE, "polling")
                .apply()

            log("Protection started — streaming live progress...")
            val success = pollUntilDone(runId)
            if (cancelFlag.get()) { finishCancelled(outputDir); return }
            if (!success) {
                log("Protection engine returned a failure")
                finish(false, outputDir, "Protection failed"); return
            }

            prefs.edit().putString(KEY_PHASE, "downloading").apply()
            updateStep("Downloading results...")
            log("Downloading protected APK...")

            val outDir = outputDir
            File(outDir).mkdirs()

            val tmpZip = File(outDir, "_artifact_tmp.zip")
            val downloaded = withNetworkRetry("download") {
                if (workerDownloadToFile("/artifact?run_id=$runId&job_id=$jobId&prefix=dptshell", tmpZip)) true else null
            } == true

            if (!downloaded) {
                log("Artifact download failed — no network after retries")
                finish(false, outputDir, "Download failed"); return
            }

            updateStep("Extracting results...")
            log("Extracting protected APK...")
            val outRoot = File(outDir).canonicalFile
            var count = 0
            ZipFile(tmpZip).use { zf ->
                val entries = zf.entries()
                while (entries.hasMoreElements()) {
                    val entry = entries.nextElement()
                    if (entry.isDirectory) continue
                    val outFile = File(outDir, entry.name).canonicalFile
                    if (!outFile.path.startsWith(outRoot.path)) continue
                    outFile.parentFile?.mkdirs()
                    zf.getInputStream(entry).use { inp ->
                        outFile.outputStream().use { out -> inp.copyTo(out) }
                    }
                    count++
                }
            }
            tmpZip.delete()
            log("Saved $count files to Taurus-Shield folder.")

            val outApk = File(outDir, "out.apk")
            if (!outApk.exists()) {
                log("ERROR: Protected APK (out.apk) not found in output")
                finish(false, outDir, "Protected APK not found in output")
                return
            }
            log("Protected APK: ${outApk.length() / 1024}KB")

            finish(true, outDir, "")

        } catch (e: Exception) {
            if (cancelFlag.get() || e is InterruptedException) {
                finishCancelled(outputDir)
            } else {
                log("Cloud error: ${e.message}")
                finish(false, outputDir, e.message ?: "Unknown error")
            }
        }
    }

    private fun findRun(afterMs: Long): Long? {
        repeat(40) { attempt ->
            Thread.sleep(3_000)
            if (cancelFlag.get()) return null
            val body = workerGet("/find-run?after=$afterMs&workflow=dptshell.yml") ?: run {
                log("Waiting for cluster node... (${(attempt + 1) * 3}s)"); return@repeat
            }
            val json = JSONObject(body)
            if (json.optBoolean("found")) {
                val runId = json.getLong("run_id")
                log("Node acquired (task #${json.optInt("run_number")})")
                updateStep("Node acquired")
                return runId
            }
            log("Waiting for cluster node... (${(attempt + 1) * 3}s)")
        }
        return null
    }

    private fun pollUntilDone(runId: Long): Boolean {
        var lastStep          = ""
        var sameStepCount     = 0
        var activePolls       = 0
        val maxActive         = 360
        var consecutiveNetFails = 0

        while (activePolls < maxActive) {
            Thread.sleep(5_000)
            if (cancelFlag.get()) return false

            val elapsed    = activePolls * 5
            val elapsedStr = if (elapsed >= 60) "${elapsed / 60}m ${elapsed % 60}s" else "${elapsed}s"

            val liveBody = workerGet("/job-live?run_id=$runId")
            var gotLive = false
            if (liveBody != null) {
                try {
                    val liveJson = JSONObject(liveBody)
                    val currentStep = liveJson.optString("current_step", "")
                    val done  = liveJson.optInt("completed_count", 0)
                    val total = liveJson.optInt("total_steps", 0)
                    if (currentStep.isNotEmpty()) {
                        gotLive = true
                        if (currentStep != lastStep) {
                            sameStepCount = 0
                            val progress = if (total > 0) " ($done/$total)" else ""
                            val friendly = friendlyStepName(currentStep)
                            log("⚙ $friendly$progress")
                            updateStep(friendly)
                            lastStep = currentStep
                        } else {
                            sameStepCount++
                            if (sameStepCount % 2 == 0) {
                                val friendly = friendlyStepName(currentStep)
                                log("   ⏳ $friendly — $elapsedStr")
                                updateStep("$friendly ($elapsedStr)")
                            }
                        }
                    }
                } catch (_: Exception) {}
            }

            val body = workerGet("/status?run_id=$runId")
            if (body == null) {
                consecutiveNetFails++
                if (!gotLive) {
                    log("   ⚠ Network unavailable — waiting to reconnect... ($consecutiveNetFails)")
                    updateStep("Waiting for network...")
                }
                continue   // don't count this poll — network is down
            }
            consecutiveNetFails = 0
            activePolls++

            if (!gotLive) log("   ⏳ waiting... $elapsedStr")
            val json       = JSONObject(body)
            val status     = json.optString("status")
            val conclusion = json.optString("conclusion")

            if (status == "completed") {
                if (conclusion != "success") {
                    log("── Protection engine error ──")
                    try {
                        val errorDetail = workerGet("/job-error?run_id=$runId")
                        if (!errorDetail.isNullOrBlank()) {
                            errorDetail.lines().map { it.trim() }.filter { it.isNotEmpty() }
                                .takeLast(12).forEach { log(it) }
                        }
                    } catch (_: Exception) {}
                }
                return conclusion == "success"
            }
        }
        log("Timed out waiting for cloud protection.")
        return false
    }

    private fun friendlyStepName(step: String): String {
        return when {
            step.contains("Download", true) && step.contains("ZIP", true)      -> "Downloading uploaded file..."
            step.contains("Extract", true) && step.contains("APK", true)       -> "Extracting APK & rules..."
            step.contains("Install", true) && step.contains("Java", true)      -> "Installing Java environment..."
            step.contains("Download", true) && step.contains("dpt", true)      -> "Downloading DPT Shell engine..."
            step.contains("Run DPT", true) || step.contains("protection", true) -> "Applying shell protection..."
            step.contains("Collect", true) || step.contains("output", true)    -> "Collecting protected APK..."
            step.contains("Sign APK", true)                                     -> "Signing APK with debug key..."
            step.contains("Upload", true) && step.contains("output", true)     -> "Packaging output..."
            step.contains("Queued", true)                                       -> "Waiting for cluster node..."
            step.contains("Set up job", true)                                  -> "Preparing environment..."
            step.contains("Complete job", true)                                -> "Finalizing..."
            else -> step
        }
    }

    private fun workerPostFile(path: String, file: File): String? {
        val total = file.length()
        val conn  = (URL(WORKER + path).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/zip")
            setRequestProperty("Content-Length", total.toString())
            connectTimeout = 30_000
            readTimeout    = 300_000
            doOutput       = true
            setFixedLengthStreamingMode(total)
        }
        var sent = 0L; var lastPct = -1
        val buf  = ByteArray(65_536)
        file.inputStream().use { inp ->
            conn.outputStream.use { out ->
                var n: Int
                while (inp.read(buf).also { n = it } != -1) {
                    out.write(buf, 0, n); sent += n
                    val pct = ((sent * 99) / total).toInt()
                    if (pct != lastPct) {
                        lastPct = pct
                        LogBridge.push("DOWNLOAD_PROGRESS:$pct")
                        if (pct % 10 == 0) updateStep("Uploading... $pct%")
                    }
                }
            }
        }
        LogBridge.push("DOWNLOAD_PROGRESS:100")
        val code = conn.responseCode
        val body = try { conn.inputStream.bufferedReader().readText() } catch (_: Exception) { null }
        conn.disconnect()
        return if (code in 200..299) body else null
    }

    private fun workerGet(path: String): String? {
        val conn = (URL(WORKER + path).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout    = 30_000
        }
        val code = conn.responseCode
        val body = try { conn.inputStream.bufferedReader().readText() } catch (_: Exception) { null }
        conn.disconnect()
        return if (code in 200..299) body else null
    }

    private fun workerDownloadToFile(path: String, outFile: File): Boolean {
        val conn = (URL(WORKER + path).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30_000
            readTimeout    = 180_000
        }
        if (conn.responseCode !in 200..299) { conn.disconnect(); return false }
        val total   = conn.contentLengthLong.takeIf { it > 0 } ?: 1L
        var done    = 0L; var lastPct = -1
        val buf     = ByteArray(32_768)
        conn.inputStream.use { inp ->
            FileOutputStream(outFile).use { out ->
                var n: Int
                while (inp.read(buf).also { n = it } != -1) {
                    out.write(buf, 0, n); done += n
                    val pct = ((done * 100) / total).toInt().coerceIn(0, 99)
                    if (pct != lastPct) {
                        lastPct = pct
                        LogBridge.push("DOWNLOAD_PROGRESS:$pct")
                        if (pct % 10 == 0) updateStep("Downloading... $pct%")
                    }
                }
            }
        }
        conn.disconnect()
        LogBridge.push("DOWNLOAD_PROGRESS:100")
        return true
    }

    private fun workerDelete(path: String) {
        try {
            val conn = (URL(WORKER + path).openConnection() as HttpURLConnection).apply {
                requestMethod = "DELETE"; connectTimeout = 10_000; readTimeout = 10_000
            }
            conn.responseCode; conn.disconnect()
        } catch (_: Exception) {}
    }

    // ── Network retry helper ──────────────────────────────────────────────────
    // Cloud job keeps running on the server even when network is off.
    // This only retries the HTTP call — never restarts the cloud job.
    private fun <T> withNetworkRetry(
        label: String,
        maxAttempts: Int = 40,
        delayMs: Long = 15_000L,
        isSuccess: (T?) -> Boolean = { it != null },
        block: () -> T?
    ): T? {
        var attempt = 0
        while (attempt < maxAttempts) {
            if (cancelFlag.get()) return null
            val result = try { block() } catch (_: Exception) { null }
            if (isSuccess(result)) return result
            attempt++
            if (attempt >= maxAttempts) break
            log("   ⚠ Network unavailable — retrying $label in ${delayMs / 1000}s... ($attempt/$maxAttempts)")
            updateStep("Waiting for network...")
            try { Thread.sleep(delayMs) } catch (_: InterruptedException) { return null }
        }
        return null
    }

    private fun workerPost(path: String) {
        try {
            val conn = (URL(WORKER + path).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = false
                connectTimeout = 10_000
                readTimeout = 10_000
            }
            conn.responseCode; conn.disconnect()
        } catch (_: Exception) {}
    }

    private fun releaseWake() {
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
    }

    override fun onDestroy() { releaseWake(); super.onDestroy() }
}
