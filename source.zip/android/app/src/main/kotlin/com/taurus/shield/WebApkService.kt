package com.taurus.shield

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

/**
 * Foreground service that keeps the Web 2 Apk Builder operation alive
 * while the user navigates away from the app — mirrors CryptoService.
 *
 * The actual build work continues on WebApkBridge's background thread;
 * this service only holds the process in the foreground with a WakeLock.
 */
class WebApkService : Service() {

    companion object {
        private const val NOTIF_ID    = 1013
        private const val EXTRA_TITLE = "title"

        fun start(context: Context, title: String = "Building APK…") {
            val intent = Intent(context, WebApkService::class.java)
                .putExtra(EXTRA_TITLE, title)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                context.startForegroundService(intent)
            else
                context.startService(intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, WebApkService::class.java))
        }
    }

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val title = intent?.getStringExtra(EXTRA_TITLE) ?: "Building APK…"

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "TaurusShield::WebApk")
        wakeLock?.acquire(2 * 60 * 60 * 1000L) // max 2 hours

        NotificationHelper.createChannels(this)
        val notif = NotificationHelper.buildProcessingNotif(this, title, "Web 2 Apk Builder")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, notif)
        }

        return START_NOT_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        stopForeground(STOP_FOREGROUND_REMOVE)
    }
}
