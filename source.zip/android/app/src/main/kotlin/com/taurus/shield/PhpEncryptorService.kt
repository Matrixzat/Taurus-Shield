package com.taurus.shield

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class PhpEncryptorService : Service() {

    companion object {
        const val PREFS          = "phpenc_alom_state"
        const val K_RUNNING      = "running"
        const val K_STATUS       = "status"
        const val K_LOG          = "log"
        const val K_OUTPUT_PATH  = "outputPath"
        const val K_SUCCESS      = "success"
        const val K_STEP         = "step"
        const val K_JOB_ID       = "jobId"
        const val K_RUN_ID       = "runId"

        private val cancelFlag = AtomicBoolean(false)

        fun isRunning(ctx: Context): Boolean =
            ctx.getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(K_RUNNING, false)

        fun getState(ctx: Context): Map<String, Any?> {
            val p = ctx.getSharedPreferences(PREFS, MODE_PRIVATE)
            return mapOf(
                "running"    to p.getBoolean(K_RUNNING, false),
                "status"     to (p.getString(K_STATUS, "idle") ?: "idle"),
                "log"        to (p.getString(K_LOG, "") ?: ""),
                "outputPath" to p.getString(K_OUTPUT_PATH, null),
                "success"    to p.getBoolean(K_SUCCESS, false),
                "step"       to (p.getString(K_STEP, "") ?: ""),
            )
        }

        fun clearState(ctx: Context) {
            ctx.getSharedPreferences(PREFS, MODE_PRIVATE).edit().clear().apply()
        }

        fun cancel(ctx: Context) {
            cancelFlag.set(true)
            ctx.stopService(Intent(ctx, PhpEncryptorService::class.java))
        }
    }

    private val executor = Executors.newSingleThreadExecutor()
    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var prefs: SharedPreferences
    private val logBuf = StringBuilder()

    private val WORKER by lazy { NativeSecrets.workerUrl() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val zipPath   = intent?.getStringExtra("zipPath")   ?: return bail()
        val baseName  = intent.getStringExtra("baseName")   ?: return bail()
        val depth     = intent.getIntExtra("depth", 2)
        val outputDir = intent.getStringExtra("outputDir")  ?: return bail()

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "TaurusShield::PhpAlom")
        wakeLock?.acquire(60 * 60 * 1000L)

        NotificationHelper.createChannels(this)
        val notif = NotificationHelper.buildProcessingNotif(this, "PHP Alom", "Uploading...")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NotificationHelper.NOTIF_PROCESSING, notif,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NotificationHelper.NOTIF_PROCESSING, notif)
        }

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        logBuf.clear()
        prefs.edit()
            .putBoolean(K_RUNNING, true)
            .putString(K_STATUS, "running")
            .putString(K_LOG, "")
            .putString(K_STEP, "Uploading")
            .putBoolean(K_SUCCESS, false)
            .remove(K_OUTPUT_PATH)
            .remove(K_JOB_ID)
            .remove(K_RUN_ID)
            .apply()

        cancelFlag.set(false)
        executor.execute { runAlom(zipPath, baseName, depth, outputDir) }
        return START_NOT_STICKY
    }

    private fun bail(): Int { stopSelf(); return START_NOT_STICKY }

    private fun log(line: String) {
        logBuf.appendLine(line)
        prefs.edit().putString(K_LOG, logBuf.toString()).apply()
    }

    private fun updateStep(step: String) {
        prefs.edit().putString(K_STEP, step).apply()
        NotificationHelper.showProcessing(this, "PHP Alom", step)
    }

    private fun finish(success: Boolean, outputPath: String?, error: String) {
        prefs.edit()
            .putBoolean(K_RUNNING, false)
            .putString(K_STATUS, if (success) "done" else "error")
            .putBoolean(K_SUCCESS, success)
            .putString(K_OUTPUT_PATH, outputPath)
            .putString(K_STEP, "")
            .apply()
        NotificationHelper.showResult(
            this, success,
            if (success) "PHP Alom — Complete" else "PHP Alom — Failed",
            if (success) "Obfuscation complete. Tap to view output."
            else "Obfuscation failed: $error"
        )
        releaseWake()
        stopForeground(true)
        stopSelf()
    }

    private fun finishCancelled() {
        prefs.edit()
            .putBoolean(K_RUNNING, false)
            .putString(K_STATUS, "cancelled")
            .putBoolean(K_SUCCESS, false)
            .apply()
        releaseWake()
        stopForeground(true)
        stopSelf()
    }

    private fun runAlom(zipPath: String, baseName: String, depth: Int, outputDir: String) {
        try {
            val file   = File(zipPath)
            val sizeKb = String.format("%.1f", file.length() / 1024.0)
            log("[INFO]  Uploading ${file.name} (${sizeKb} KB) to Alom cluster...")

            val uploadBody = postZip("/php-alom?depth=$depth", file)
                ?: run { log("[ERROR] Upload failed — check connection"); finish(false, null, "Upload failed"); return }

            val uploadJson  = JSONObject(uploadBody)
            val jobId       = uploadJson.getString("job_id")
            val triggeredAt = uploadJson.getLong("triggered_at")
            log("[OK]    Job dispatched — ID: $jobId")
            log("[CLOUD] Waiting for cluster node...")
            prefs.edit().putString(K_JOB_ID, jobId).apply()

            updateStep("Finding cluster node...")

            var runId: Long? = null
            for (i in 0 until 40) {
                if (cancelFlag.get()) { finishCancelled(); return }
                Thread.sleep(3_000)
                val rawFind = workerGet("/find-run?after=$triggeredAt&workflow=php-alom.yml")
                if (rawFind == null) {
                    log("   ⏳ Waiting for node... (${(i + 1) * 3}s)")
                    continue
                }
                val json = JSONObject(rawFind)
                if (json.optBoolean("found")) {
                    runId = json.getLong("run_id")
                    log("[OK]    Node acquired (task #${json.optInt("run_number")})")
                    break
                }
                log("   ⏳ Waiting for node... (${(i + 1) * 3}s)")
            }

            if (runId == null) {
                log("[ERROR] Could not reach cluster — timed out")
                finish(false, null, "Cluster timeout"); return
            }

            prefs.edit().putLong(K_RUN_ID, runId).apply()

            updateStep("Obfuscating (depth $depth)...")
            log("[CLOUD] Obfuscating PHP files with Alom (depth $depth)...")

            var jobSuccess = false
            for (i in 0 until 360) {
                if (cancelFlag.get()) { finishCancelled(); return }
                Thread.sleep(5_000)
                val elapsed    = (i + 1) * 5
                val elapsedStr = if (elapsed >= 60) "${elapsed / 60}m ${elapsed % 60}s" else "${elapsed}s"
                val rawStatus = workerGet("/status?run_id=$runId")
                if (rawStatus == null) {
                    log("   ⏳ Obfuscating... $elapsedStr")
                    continue
                }
                val json       = JSONObject(rawStatus)
                val status     = json.optString("status")
                val conclusion = json.optString("conclusion")
                if (status == "completed") {
                    jobSuccess = conclusion == "success"
                    if (!jobSuccess) log("[ERROR] Alom job failed — $conclusion")
                    break
                }
                log("   ⏳ Obfuscating... $elapsedStr")
                updateStep("Obfuscating... $elapsedStr")
            }

            if (!jobSuccess) { finish(false, null, "Alom job failed"); return }

            updateStep("Downloading output...")
            log("[CLOUD] Downloading obfuscated output...")

            File(outputDir).mkdirs()
            val outFile    = File(outputDir, "${baseName}_alom.zip")
            val downloaded = workerDownloadToFile(
                "/artifact?run_id=$runId&job_id=$jobId&prefix=php-alom", outFile)

            if (!downloaded) {
                log("[ERROR] Artifact download failed")
                finish(false, null, "Download failed"); return
            }

            log("[OK]    Download complete (${String.format("%.1f", outFile.length() / 1024.0)} KB)")
            log("[SAVED] → ${outFile.name}")
            finish(true, outFile.absolutePath, "")

        } catch (e: Exception) {
            if (cancelFlag.get() || e is InterruptedException) {
                finishCancelled()
            } else {
                log("[ERROR] ${e.message}")
                finish(false, null, e.message ?: "Unknown error")
            }
        }
    }

    private fun postZip(path: String, file: File): String? {
        val total = file.length()
        val conn  = (URL(WORKER + path).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/zip")
            setRequestProperty("Content-Length", total.toString())
            connectTimeout = 30_000
            readTimeout    = 300_000
            doOutput       = true
            setFixedLengthStreamingMode(total)
        }
        file.inputStream().use { inp ->
            conn.outputStream.use { out -> inp.copyTo(out) }
        }
        val code = conn.responseCode
        val body = try { conn.inputStream.bufferedReader().readText() } catch (_: Exception) { null }
        conn.disconnect()
        return if (code in 200..299) body else null
    }

    private fun workerGet(path: String): String? {
        val conn = (URL(WORKER + path).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout    = 30_000
        }
        val code = conn.responseCode
        val body = try { conn.inputStream.bufferedReader().readText() } catch (_: Exception) { null }
        conn.disconnect()
        return if (code in 200..299) body else null
    }

    private fun workerDownloadToFile(path: String, outFile: File): Boolean {
        val conn = (URL(WORKER + path).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30_000
            readTimeout    = 180_000
        }
        if (conn.responseCode !in 200..299) { conn.disconnect(); return false }
        conn.inputStream.use { inp ->
            FileOutputStream(outFile).use { out -> inp.copyTo(out) }
        }
        conn.disconnect()
        return true
    }

    private fun releaseWake() {
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
    }

    override fun onDestroy() { releaseWake(); super.onDestroy() }
}
