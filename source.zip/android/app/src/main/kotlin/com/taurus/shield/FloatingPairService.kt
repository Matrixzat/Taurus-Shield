package com.taurus.shield

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.nsd.*
import android.os.*
import android.util.TypedValue
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.*
import android.widget.*
import java.util.concurrent.*

class FloatingPairService : Service() {

    companion object {
        const val CHANNEL_ID     = "taurus_pair_channel"
        const val NOTIF_ID       = 9001
        const val ACTION_DISMISS = "com.taurus.shield.DISMISS_PAIR"
    }

    private var wm: WindowManager? = null
    private var rootView: View?    = null
    private var wmParams: WindowManager.LayoutParams? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val executor    = Executors.newSingleThreadExecutor()

    // ── Lifecycle ────────────────────────────────────────────────────────────

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIF_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_DISMISS) { dismissWithAnimation(); return START_NOT_STICKY }
        showFloating()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        rootView?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        executor.shutdownNow()
    }

    // ── Pixel helpers ────────────────────────────────────────────────────────

    private fun dp(v: Float) =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()

    private fun sp(v: Float) =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)

    // ── Dismiss animation ────────────────────────────────────────────────────

    private fun dismissWithAnimation() {
        val rv = rootView ?: run { stopSelf(); return }
        mainHandler.post {
            rv.animate()
                .alpha(0f)
                .translationY(dp(28f).toFloat())
                .scaleX(0.94f)
                .scaleY(0.94f)
                .setDuration(200)
                .setInterpolator(DecelerateInterpolator())
                .withEndAction { stopSelf() }
                .start()
        }
    }

    // ── Build the floating window ─────────────────────────────────────────────

    private fun showFloating() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        // ── outer card ──────────────────────────────────────────────────────
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#13132b"))
                cornerRadius = dp(20f).toFloat()
                setStroke(dp(1f), Color.parseColor("#7c3aed"))
            }
            elevation = dp(16f).toFloat()
            clipToOutline = true
            outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        }

        // ── gradient header (also drag handle) ──────────────────────────────
        val headerBg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#6d28d9"), Color.parseColor("#9333ea"))
        ).apply {
            cornerRadii = floatArrayOf(
                dp(19f).toFloat(), dp(19f).toFloat(),
                dp(19f).toFloat(), dp(19f).toFloat(),
                0f, 0f, 0f, 0f
            )
        }

        val header = FrameLayout(this).apply {
            background = headerBg
            setPadding(dp(16f), dp(13f), dp(16f), dp(13f))
        }

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        // drag-dots indicator
        titleRow.addView(TextView(this).apply {
            text = "⋮⋮"
            setTextColor(Color.parseColor("#c4b5fd"))
            setTextSize(TypedValue.COMPLEX_UNIT_PX, sp(14f))
            setPadding(0, 0, dp(8f), 0)
            letterSpacing = -0.15f
        })

        titleRow.addView(TextView(this).apply {
            text = "🛡  Taurus Shield — Pair ADB"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_PX, sp(13f))
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })

        val closeBtn = TextView(this).apply {
            text = "✕"
            setTextColor(Color.parseColor("#ddd6fe"))
            setTextSize(TypedValue.COMPLEX_UNIT_PX, sp(16f))
            setPadding(dp(10f), dp(4f), 0, dp(4f))
            setOnClickListener { dismissWithAnimation() }
        }

        titleRow.addView(closeBtn)
        header.addView(titleRow)

        // ── body ─────────────────────────────────────────────────────────────
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16f), dp(14f), dp(16f), dp(18f))
        }

        // subtitle
        val subtitleTv = TextView(this).apply {
            text = "Open Wireless Debugging → \"Pair device with pairing code\"\nthen enter the 6-digit code below."
            setTextColor(Color.parseColor("#94a3b8"))
            setTextSize(TypedValue.COMPLEX_UNIT_PX, sp(11f))
            setPadding(0, 0, 0, dp(12f))
            setLineSpacing(dp(2f).toFloat(), 1.0f)
        }
        body.addView(subtitleTv)

        // code input
        val codeEdit = EditText(this).apply {
            hint = "6-digit code"
            setHintTextColor(Color.parseColor("#475569"))
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_PX, sp(24f))
            gravity = Gravity.CENTER
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            maxLines = 1
            isSingleLine = true
            letterSpacing = 0.35f
            imeOptions = EditorInfo.IME_ACTION_DONE
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#0c0c1e"))
                cornerRadius = dp(10f).toFloat()
                setStroke(dp(1f), Color.parseColor("#334155"))
            }
            setPadding(dp(14f), dp(14f), dp(14f), dp(14f))
        }
        body.addView(codeEdit)

        // status text
        val statusTv = TextView(this).apply {
            setTextColor(Color.parseColor("#60a5fa"))
            setTextSize(TypedValue.COMPLEX_UNIT_PX, sp(11f))
            setPadding(dp(2f), dp(8f), dp(2f), 0)
            visibility = View.GONE
            setLineSpacing(dp(2f).toFloat(), 1.0f)
        }
        body.addView(statusTv)

        // pair button with gradient
        val btnBg = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.parseColor("#7c3aed"), Color.parseColor("#a855f7"))
        ).apply { cornerRadius = dp(10f).toFloat() }

        val pairBtn = TextView(this).apply {
            text = "PAIR & GRANT PERMISSION"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_PX, sp(13f))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = btnBg
            setPadding(0, dp(14f), 0, dp(14f))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(12f) }
        }

        // button press animation
        pairBtn.setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
            }
            false
        }

        pairBtn.setOnClickListener {
            val code = codeEdit.text.toString().trim()
            if (code.length < 6) {
                setStatus(statusTv, "⚠  Enter the full 6-digit code first.", "#f87171")
                shakePairBtn(pairBtn)
                return@setOnClickListener
            }
            pairBtn.isEnabled = false
            pairBtn.setTextColor(Color.parseColor("#94a3b8"))
            (pairBtn.background as? GradientDrawable)?.setColor(Color.parseColor("#1e2940"))
            doPairing(code, statusTv, pairBtn)
        }

        body.addView(pairBtn)
        card.addView(header)
        card.addView(body)

        // ── WindowManager setup ──────────────────────────────────────────────
        val root = FrameLayout(this)
        val screenW = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
            wm!!.currentWindowMetrics.bounds.width()
        else resources.displayMetrics.widthPixels

        val cardW = minOf(screenW - dp(28f), dp(330f))
        root.addView(card, FrameLayout.LayoutParams(
            cardW,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL
        ))

        val params = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(60f)
        }

        wmParams  = params
        rootView  = root
        wm?.addView(root, params)

        // ── entrance animation ───────────────────────────────────────────────
        root.alpha        = 0f
        root.translationY = dp(-20f).toFloat()
        root.scaleX       = 0.92f
        root.scaleY       = 0.92f
        root.animate()
            .alpha(1f)
            .translationY(0f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(320)
            .setInterpolator(OvershootInterpolator(1.2f))
            .start()

        // ── drag support on header ───────────────────────────────────────────
        // Use arrays so lambda capture mutation works across Kotlin/JVM versions
        val rawXY = floatArrayOf(0f, 0f)   // [0]=rawX0, [1]=rawY0
        val pXY   = intArrayOf(0, 0)       // [0]=px0,   [1]=py0

        header.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    rawXY[0] = ev.rawX; rawXY[1] = ev.rawY
                    pXY[0]   = wmParams!!.x; pXY[1] = wmParams!!.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    wmParams!!.x = pXY[0] + (ev.rawX - rawXY[0]).toInt()
                    wmParams!!.y = pXY[1] + (ev.rawY - rawXY[1]).toInt()
                    try { wm?.updateViewLayout(root, wmParams) } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }
    }

    // ── Shake animation for invalid input ────────────────────────────────────

    private fun shakePairBtn(v: View) {
        val anim = android.view.animation.TranslateAnimation(
            0f, dp(6f).toFloat(), 0f, 0f
        ).apply {
            duration = 60; repeatCount = 5
            repeatMode = android.view.animation.Animation.REVERSE
        }
        mainHandler.post { v.startAnimation(anim) }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun setStatus(tv: TextView, msg: String, colorHex: String = "#60a5fa") =
        mainHandler.post {
            tv.text = msg
            tv.setTextColor(Color.parseColor(colorHex))
            if (tv.visibility != View.VISIBLE) {
                tv.visibility = View.VISIBLE
                tv.alpha = 0f
                tv.animate().alpha(1f).setDuration(200).start()
            }
        }

    private fun resetBtn(btn: TextView) = mainHandler.post {
        btn.isEnabled = true
        btn.text = "PAIR & GRANT PERMISSION"
        btn.setTextColor(Color.WHITE)
        (btn.background as? GradientDrawable)?.apply {
            colors = intArrayOf(Color.parseColor("#7c3aed"), Color.parseColor("#a855f7"))
        }
    }

    // ── mDNS helper ───────────────────────────────────────────────────────────

    private fun discoverPort(serviceType: String, timeoutSec: Long): Int {
        var port = 0
        val latch = CountDownLatch(1)
        val nsd = applicationContext.getSystemService(NSD_SERVICE) as NsdManager

        val resolveL = object : NsdManager.ResolveListener {
            override fun onResolveFailed(i: NsdServiceInfo, c: Int) { latch.countDown() }
            override fun onServiceResolved(i: NsdServiceInfo) {
                if (i.port > 0) port = i.port
                latch.countDown()
            }
        }
        var discL: NsdManager.DiscoveryListener? = null
        discL = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(r: String) {}
            override fun onDiscoveryStopped(r: String) {}
            override fun onStartDiscoveryFailed(r: String, c: Int) { latch.countDown() }
            override fun onStopDiscoveryFailed(r: String, c: Int) {}
            override fun onServiceFound(svc: NsdServiceInfo) {
                try { nsd.stopServiceDiscovery(discL) } catch (_: Exception) {}
                nsd.resolveService(svc, resolveL)
            }
            override fun onServiceLost(svc: NsdServiceInfo) {}
        }
        nsd.discoverServices(serviceType, NsdManager.PROTOCOL_DNS_SD, discL!!)
        latch.await(timeoutSec, TimeUnit.SECONDS)
        try { nsd.stopServiceDiscovery(discL) } catch (_: Exception) {}
        return port
    }

    // ── Main pairing logic (LADB-exact) ───────────────────────────────────────

    private fun doPairing(pairCode: String, statusTv: TextView, pairBtn: TextView) {
        val adbBin  = BinRef.r(applicationInfo.nativeLibraryDir)
        val homeDir = filesDir.absolutePath
        val tmpDir  = cacheDir.absolutePath

        fun adbProc(vararg args: String) = ProcessBuilder(*args)
            .also { pb ->
                pb.environment()["HOME"]   = homeDir
                pb.environment()["TMPDIR"] = tmpDir
                pb.environment()["ADB_VENDOR_KEYS"] = homeDir
                pb.environment()["HOSTNAME"] = "Logcat"
                pb.environment()["USER"]     = "Taurus-Shield"
                pb.environment()["LOGNAME"]  = "Taurus-Shield"
            }

        fun patchAdbKeyName() {
            try {
                val pubKeyFile = java.io.File(homeDir, ".android/adbkey.pub")
                if (pubKeyFile.exists()) {
                    val content = pubKeyFile.readText().trim()
                    val parts = content.split(" ", limit = 2)
                    if (parts.isNotEmpty()) {
                        pubKeyFile.writeText(parts[0] + " Taurus-Shield@Logcat\n")
                    }
                }
            } catch (_: Exception) {}
        }

        fun ensureKeysAndPatch() {
            val androidDir = java.io.File(homeDir, ".android")
            if (!androidDir.exists()) androidDir.mkdirs()
            val keyFile = java.io.File(androidDir, "adbkey")
            val pubFile = java.io.File(androidDir, "adbkey.pub")
            var needGen = !keyFile.exists()
            if (!needGen && pubFile.exists()) {
                val comment = try {
                    pubFile.readText().trim().split(" ", limit = 2).getOrElse(1) { "" }
                } catch (_: Exception) { "" }
                if (comment != "Taurus-Shield@Logcat") needGen = true
            }
            if (needGen) {
                try { keyFile.delete() } catch (_: Exception) {}
                try { pubFile.delete() } catch (_: Exception) {}
                adbProc(adbBin, "start-server").start().apply {
                    inputStream.bufferedReader().readText(); waitFor()
                }
                Thread.sleep(500)
                adbProc(adbBin, "kill-server").start().apply {
                    inputStream.bufferedReader().readText(); waitFor()
                }
                Thread.sleep(300)
            }
            patchAdbKeyName()
        }

        executor.execute {
            try {
                // Step -1: Check USB Debugging is enabled
                val usbOn = try {
                    android.provider.Settings.Global.getInt(
                        contentResolver, "adb_enabled", 0) == 1
                } catch (_: Exception) { true }
                if (!usbOn) {
                    setStatus(statusTv,
                        "⚠  USB Debugging is OFF.\nEnable it first:\nSettings → Developer Options → USB Debugging",
                        "#f87171")
                    resetBtn(pairBtn); return@execute
                }

                // Step -1b: Check Wireless Debugging is enabled
                val wifiOn = try {
                    android.provider.Settings.Global.getInt(
                        contentResolver, "adb_wifi_enabled", 0) == 1
                } catch (_: Exception) { true }
                if (!wifiOn) {
                    setStatus(statusTv,
                        "⚠  Wireless Debugging is OFF.\nEnable it first:\nSettings → Developer Options → Wireless Debugging",
                        "#f87171")
                    resetBtn(pairBtn); return@execute
                }

                // Step 0: discover pairing port via mDNS
                setStatus(statusTv, "🔍  Waiting for pairing service…\nKeep \"Pair device with code\" dialog open")
                val pairPort = discoverPort("_adb-tls-pairing._tcp", 30)
                if (pairPort == 0) {
                    setStatus(statusTv,
                        "❌  No pairing service found.\nOpen Settings → Wireless Debugging → \"Pair device with pairing code\"",
                        "#f87171")
                    resetBtn(pairBtn); return@execute
                }

                // Step 0b: disconnect all existing devices to avoid "more than one device"
                setStatus(statusTv, "⚙  Cleaning up old connections…")
                try {
                    adbProc(adbBin, "disconnect").start().apply {
                        inputStream.bufferedReader().readText(); waitFor()
                    }
                } catch (_: Exception) {}

                // Step 1: ensure keys exist, kill server, patch key name, start fresh
                setStatus(statusTv, "⚙  Starting ADB server…")
                adbProc(adbBin, "kill-server").start().apply {
                    inputStream.bufferedReader().readText(); waitFor()
                }
                Thread.sleep(500)

                ensureKeysAndPatch()

                adbProc(adbBin, "start-server").start().apply {
                    inputStream.bufferedReader().readText(); waitFor()
                }
                Thread.sleep(800)

                // Step 2: LADB-exact — pair localhost:PORT, stdin code after 5s
                setStatus(statusTv, "🔗  Pairing on port $pairPort…")
                patchAdbKeyName()
                val pairProc = adbProc(adbBin, "pair", "localhost:$pairPort")
                    .redirectErrorStream(true)
                    .start()
                val pairOut = StringBuilder()
                val pairReader = Thread {
                    try { pairProc.inputStream.bufferedReader().forEachLine { pairOut.appendLine(it) } }
                    catch (_: Exception) {}
                }.also { it.start() }
                Thread.sleep(5000)
                try {
                    pairProc.outputStream.writer().apply { write(pairCode); write("\n"); flush() }
                } catch (_: Exception) {}
                pairProc.waitFor(10, TimeUnit.SECONDS)
                pairProc.destroyForcibly().waitFor()
                pairReader.join(2000)
                val pairOutStr = pairOut.toString()

                if (pairProc.exitValue() != 0 && "Successfully" !in pairOutStr) {
                    setStatus(statusTv, "❌  Pairing failed:\n$pairOutStr", "#f87171")
                    resetBtn(pairBtn); return@execute
                }

                // Step 3: kill-server after pair, re-patch key, restart
                setStatus(statusTv, "✓  Paired! Restarting server…", "#4ade80")
                adbProc(adbBin, "kill-server").start().apply {
                    inputStream.bufferedReader().readText(); waitFor()
                }
                Thread.sleep(500)
                patchAdbKeyName()
                adbProc(adbBin, "start-server").start().apply {
                    inputStream.bufferedReader().readText(); waitFor()
                }
                Thread.sleep(3000)

                // Step 4: wait-for-device
                setStatus(statusTv, "📡  Connecting…")
                try {
                    adbProc(adbBin, "wait-for-device").start().waitFor(15, TimeUnit.SECONDS)
                } catch (_: Exception) {}

                var devOut = adbProc(adbBin, "devices").redirectErrorStream(true).start()
                    .let { it.inputStream.bufferedReader().readText().also { _ -> it.waitFor() } }
                var hasDevice = devOut.lines().drop(1).any { it.contains("\tdevice") }

                // Step 5: explicit connect if auto-connect missed
                if (!hasDevice) {
                    val connPort = discoverPort("_adb-tls-connect._tcp", 8)
                    if (connPort > 0) {
                        for (target in listOf("localhost:$connPort", "127.0.0.1:$connPort")) {
                            val out = adbProc(adbBin, "connect", target).redirectErrorStream(true).start()
                                .let { it.inputStream.bufferedReader().readText().also { _ -> it.waitFor() } }
                            if ("connected" in out.lowercase()) break
                            Thread.sleep(500)
                        }
                    }
                    devOut = adbProc(adbBin, "devices").redirectErrorStream(true).start()
                        .let { it.inputStream.bufferedReader().readText().also { _ -> it.waitFor() } }
                    hasDevice = devOut.lines().drop(1).any { it.contains("\tdevice") }
                }

                if (!hasDevice) {
                    setStatus(statusTv, "⚠  Paired ✓ but device not visible.\ndevices: $devOut", "#fbbf24")
                    resetBtn(pairBtn); return@execute
                }

                // Step 5b: disconnect stale devices, keep only the one we just paired
                val deviceLines = devOut.lines().drop(1)
                    .filter { it.contains("\tdevice") }
                    .map { it.split("\t").first().trim() }
                val targetDevice = deviceLines.firstOrNull() ?: ""

                if (deviceLines.size > 1 && targetDevice.isNotEmpty()) {
                    for (dev in deviceLines.drop(1)) {
                        try {
                            adbProc(adbBin, "disconnect", dev).start().apply {
                                inputStream.bufferedReader().readText(); waitFor()
                            }
                        } catch (_: Exception) {}
                    }
                    Thread.sleep(500)
                }

                // Step 6: grant READ_LOGS
                setStatus(statusTv, "🔑  Granting READ_LOGS permission…")
                Thread.sleep(500)
                val grantArgs = if (targetDevice.isNotEmpty())
                    arrayOf("-s", targetDevice, "shell", "pm", "grant", packageName,
                        "android.permission.READ_LOGS")
                else
                    arrayOf("shell", "pm", "grant", packageName,
                        "android.permission.READ_LOGS")
                val grantProc = adbProc(adbBin, *grantArgs).redirectErrorStream(true).start()
                val grantOut  = grantProc.inputStream.bufferedReader().readText()
                val grantExit = grantProc.waitFor()

                if (grantExit != 0 && grantOut.isNotBlank()) {
                    if ("more than one" in grantOut.lowercase()) {
                        setStatus(statusTv, "⚠  Multiple devices detected. Retrying with cleanup…", "#fbbf24")
                        try {
                            adbProc(adbBin, "disconnect").start().apply {
                                inputStream.bufferedReader().readText(); waitFor()
                            }
                        } catch (_: Exception) {}
                        Thread.sleep(500)
                        adbProc(adbBin, "kill-server").start().apply {
                            inputStream.bufferedReader().readText(); waitFor()
                        }
                        Thread.sleep(300)
                        patchAdbKeyName()
                        adbProc(adbBin, "start-server").start().apply {
                            inputStream.bufferedReader().readText(); waitFor()
                        }
                        Thread.sleep(2000)
                        try {
                            adbProc(adbBin, "wait-for-device").start().waitFor(10, TimeUnit.SECONDS)
                        } catch (_: Exception) {}
                        val retryProc = adbProc(adbBin, "shell", "pm", "grant", packageName,
                            "android.permission.READ_LOGS").redirectErrorStream(true).start()
                        val retryOut  = retryProc.inputStream.bufferedReader().readText()
                        val retryExit = retryProc.waitFor()
                        if (retryExit != 0 && retryOut.isNotBlank()) {
                            setStatus(statusTv, "⚠  Connected ✓  Grant failed:\n$retryOut", "#f87171")
                            resetBtn(pairBtn); return@execute
                        }
                    } else {
                        setStatus(statusTv, "⚠  Connected ✓  Grant failed:\n$grantOut", "#f87171")
                        resetBtn(pairBtn); return@execute
                    }
                }

                setStatus(statusTv, "🎉  All done! Permission granted.\nClosing in 3 seconds…", "#4ade80")
                Thread.sleep(3000)
                dismissWithAnimation()

            } catch (e: Exception) {
                setStatus(statusTv, "❌  Error: ${e.message}", "#f87171")
                resetBtn(pairBtn)
            }
        }
    }

    // ── Notification ──────────────────────────────────────────────────────────

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager::class.java.cast(getSystemService(NOTIFICATION_SERVICE))
                ?.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "ADB Pairing", NotificationManager.IMPORTANCE_LOW)
                        .also { it.description = "Taurus Shield ADB pairing overlay" }
                )
        }
    }

    private fun buildNotification(): Notification {
        val dismissPi = PendingIntent.getService(this, 0,
            Intent(this, FloatingPairService::class.java).setAction(ACTION_DISMISS),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("ADB Pairing Active")
                .setContentText("Taurus Shield pairing dialog is visible")
                .setSmallIcon(android.R.drawable.ic_menu_manage)
                .addAction(Notification.Action.Builder(null, "Dismiss", dismissPi).build())
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("ADB Pairing Active")
                .setContentText("Taurus Shield pairing dialog is visible")
                .setSmallIcon(android.R.drawable.ic_menu_manage)
                .setOngoing(true)
                .build()
        }
    }
}
