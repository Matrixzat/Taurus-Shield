package com.taurus.shield

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import com.chaquo.python.Python
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.OutputStream
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class PineHookService : Service() {

    companion object {
        const val PREFS           = "pine_hook_svc"
        const val KEY_RUNNING     = "running"
        const val KEY_PHASE       = "phase"
        const val KEY_LOGS        = "logs"
        const val KEY_STATUS      = "result_status"
        const val KEY_OUTPUT_DIR  = "output_dir"
        const val KEY_OUTPUT_PATH = "output_path"
        const val KEY_ERROR       = "error"
        const val KEY_FILE_NAME   = "file_name"
        const val KEY_FILE_PATH   = "file_path"
        const val KEY_MODULES     = "modules_json"
        const val KEY_STEP        = "current_step"

        fun isRunning(context: Context): Boolean =
            context.getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_RUNNING, false)

        fun getState(context: Context): Map<String, Any?> {
            val p = context.getSharedPreferences(PREFS, MODE_PRIVATE)
            return mapOf(
                "running"    to p.getBoolean(KEY_RUNNING, false),
                "phase"      to (p.getString(KEY_PHASE, "") ?: ""),
                "logs"       to (p.getString(KEY_LOGS, "") ?: ""),
                "status"     to (p.getString(KEY_STATUS, "") ?: ""),
                "outputDir"  to (p.getString(KEY_OUTPUT_DIR, "") ?: ""),
                "outputPath" to (p.getString(KEY_OUTPUT_PATH, "") ?: ""),
                "error"      to (p.getString(KEY_ERROR, "") ?: ""),
                "fileName"   to (p.getString(KEY_FILE_NAME, "") ?: ""),
                "filePath"   to (p.getString(KEY_FILE_PATH, "") ?: ""),
                "currentStep" to (p.getString(KEY_STEP, "") ?: ""),
            )
        }

        fun clearState(context: Context) {
            context.getSharedPreferences(PREFS, MODE_PRIVATE).edit().clear().apply()
        }

        private val cancelFlag   = AtomicBoolean(false)
        private var workerThread: Thread? = null

        fun cancel(context: Context) {
            cancelFlag.set(true)
            workerThread?.interrupt()
            context.stopService(Intent(context, PineHookService::class.java))
        }
    }

    private val executor = Executors.newSingleThreadExecutor()
    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var prefs: SharedPreferences
    private val logBuf = StringBuilder()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) return bail()

        val filePath       = intent.getStringExtra("filePath")       ?: return bail()
        val outputDir      = intent.getStringExtra("outputDir")      ?: return bail()
        val modulesJson    = intent.getStringExtra("modulesJson")    ?: "[]"
        val fileName       = intent.getStringExtra("fileName")       ?: filePath.substringAfterLast('/')

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)

        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "TaurusShield:PineHook"
        ).apply { acquire(90 * 60 * 1000L) }

        val notification = NotificationHelper.buildProcessingNotif(this, "Pine Hook Injector", fileName)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NotificationHelper.NOTIF_PROCESSING, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NotificationHelper.NOTIF_PROCESSING, notification)
        }

        prefs.edit()
            .putBoolean(KEY_RUNNING, true)
            .putString(KEY_PHASE, "injecting")
            .putString(KEY_LOGS, "")
            .putString(KEY_STATUS, "")
            .putString(KEY_OUTPUT_DIR, outputDir)
            .putString(KEY_OUTPUT_PATH, "")
            .putString(KEY_ERROR, "")
            .putString(KEY_FILE_NAME, fileName)
            .putString(KEY_FILE_PATH, filePath)
            .putString(KEY_MODULES, modulesJson)
            .putString(KEY_STEP, "Injecting Pine Framework...")
            .apply()

        cancelFlag.set(false)
        logBuf.clear()
        LogBridge.clear()

        executor.execute {
            workerThread = Thread.currentThread()
            runPineInject(filePath, fileName, outputDir, modulesJson)
        }
        return START_NOT_STICKY
    }

    private fun bail(): Int { stopSelf(); return START_NOT_STICKY }

    private fun log(line: String) {
        LogBridge.push(line)
        logBuf.appendLine(line)
        prefs.edit().putString(KEY_LOGS, logBuf.toString()).apply()
    }

    private fun updateStep(step: String) {
        prefs.edit().putString(KEY_STEP, step).apply()
        NotificationHelper.showProcessing(this, "Pine Hook Injector", step)
    }

    private fun finish(success: Boolean, outputPath: String, outputDir: String, error: String) {
        LogBridge.done()
        prefs.edit()
            .putBoolean(KEY_RUNNING, false)
            .putString(KEY_STATUS, if (success) "success" else "error")
            .putString(KEY_OUTPUT_PATH, outputPath)
            .putString(KEY_OUTPUT_DIR, outputDir)
            .putString(KEY_ERROR, error)
            .putString(KEY_PHASE, "done")
            .apply()
        NotificationHelper.showResult(
            this, success,
            "Pine Hook Injector",
            if (success) "Injection complete — sign with MT Manager."
            else "Injection failed: $error"
        )
        releaseWake()
        stopForeground(true)
        stopSelf()
    }

    private fun runPineInject(
        filePath: String,
        fileName: String,
        outputDir: String,
        modulesJson: String,
    ) {
        try {
            updateStep("Preparing APK...")
            val cleanPath = try {
                sanitizeApk(filePath)
            } catch (e: Throwable) {
                log("Warning: APK sanitize failed (${e.message}), using original")
                filePath
            }

            updateStep("Running Pine injection...")

            val py     = Python.getInstance()
            val bridge = py.getModule("pinehook_bridge")
            val fn     = bridge["do_pine_inject"]
                ?: run { finish(false, "", outputDir, "Python bridge function not found"); return }

            val raw    = fn.call(cleanPath, outputDir, modulesJson)
            val map    = raw.asMap().entries.associate { it.key.toString() to it.value }

            val status     = map["status"]?.toString() ?: "error"
            val outputPath = map["output_path"]?.toString() ?: ""
            val outDir     = map["output_dir"]?.toString() ?: outputDir
            val error      = map["error"]?.toString() ?: ""

            if (status == "ok") {
                updateStep("Aligning APK (resources.arsc)...")
                val alignedPath = try {
                    fixApkAlignment(outputPath)
                } catch (e: Throwable) {
                    log("Warning: alignment step failed (${e.message}), using unaligned output")
                    outputPath
                }

                val finalPath = alignedPath

                // Inject hook_guide.json into the APK's hook/ directory and zero-out
                // config.json (Python bridge writes "{}" — we replace with 0 bytes so
                // the user fills it from scratch using the guide).
                try {
                    val guideContent = assets.open("pine_hook_guide.json")
                        .bufferedReader().use { it.readText() }
                    injectGuideIntoApk(finalPath, guideContent)
                    log("  Embedded hook_guide.json → hook/ (inside APK)")
                    log("  Cleared hook/config.json — ready to fill")
                } catch (e: Throwable) {
                    log("  Warning: could not embed hook guide (${e.message})")
                }

                updateStep("Injection complete!")
                finish(true, finalPath, outDir, "")
            } else {
                finish(false, "", outDir, error.ifBlank { "Unknown error" })
            }

        } catch (e: Throwable) {
            if (cancelFlag.get() || e is InterruptedException) {
                cancelFlag.set(false)
                LogBridge.push("Cancelled by user.")
                LogBridge.done()
                prefs.edit()
                    .putBoolean(KEY_RUNNING, false)
                    .putString(KEY_STATUS, "cancelled")
                    .putString(KEY_ERROR, "Cancelled")
                    .putString(KEY_PHASE, "done")
                    .apply()
                NotificationHelper.cancelProcessing(this)
            } else {
                try { log("Error: ${e.message}") } catch (_: Throwable) {}
                try { finish(false, "", outputDir, e.message ?: "Unknown error") } catch (_: Throwable) {}
            }
            releaseWake()
            stopForeground(true)
            stopSelf()
        }
    }

    /**
     * Strips overlapping / duplicate ZIP entries that cause Python's zipfile module to raise
     * "Overlapped entries (possible zip bomb)".
     *
     * Two-pass strategy:
     *   Pass 1 — ZipInputStream (local file headers, sequential scan).
     *             Immune to central-directory tricks (zip-bomb APKs).
     *   Pass 2 — java.util.zip.ZipFile (central directory).
     *             Catches entries whose local headers are at offsets
     *             ZipInputStream could not reach — common in sign-killed APKs
     *             where the manifest or other entries are stored at non-sequential
     *             offsets after signature removal.
     *
     * Returns the path of a clean temp copy (original is untouched).
     */
    private fun sanitizeApk(apkPath: String): String {
        val src = File(apkPath)
        if (!src.exists()) return apkPath

        val tmp  = File(src.parent, src.nameWithoutExtension + "_clean.apk")
        val seen = LinkedHashSet<String>()

        ZipOutputStream(BufferedOutputStream(FileOutputStream(tmp))).use { zout ->
            zout.setLevel(Deflater.DEFAULT_COMPRESSION)

            // ── Pass 1: ZipInputStream (local headers) ──────────────────────
            try {
                ZipInputStream(FileInputStream(src)).use { zin ->
                    var entry = try { zin.nextEntry } catch (_: Throwable) { null }
                    while (entry != null) {
                        try {
                            // Strip stale signature artifacts so users never need to
                            // "kill signature" after injection (which re-zips and breaks
                            // resources.arsc alignment → Android error -124).
                            if (!isSignatureEntry(entry.name) && seen.add(entry.name)) {
                                val bytes = zin.readBytes()
                                writeZipEntry(zout, entry, bytes)
                            }
                        } catch (e: Throwable) {
                            log("sanitize p1: skip '${entry.name}' (${e.message})")
                        }
                        entry = try { zin.nextEntry } catch (_: Throwable) { null }
                    }
                }
            } catch (e: Throwable) {
                log("sanitize p1 partial: ${e.message}")
            }

            // ── Pass 2: ZipFile (central directory) — recovery for missed entries ─
            // Critical for sign-killed APKs: AndroidManifest.xml may be invisible
            // to the sequential local-header scan but present in the central directory.
            try {
                ZipFile(src).use { zf ->
                    val entries = zf.entries()
                    while (entries.hasMoreElements()) {
                        val ze = entries.nextElement()
                        if (!isSignatureEntry(ze.name) && seen.add(ze.name)) {
                            try {
                                val bytes = zf.getInputStream(ze).readBytes()
                                writeZipEntry(zout, ze, bytes)
                                log("sanitize p2 recovered: '${ze.name}'")
                            } catch (e: Throwable) {
                                log("sanitize p2: skip '${ze.name}' (${e.message})")
                            }
                        }
                    }
                }
            } catch (e: Throwable) {
                log("sanitize p2 (ZipFile) skipped: ${e.message}")
            }
        }

        val hasMf = seen.contains("AndroidManifest.xml")
        log("APK sanitized: ${seen.size} entries kept, manifest=${hasMf}")
        if (!hasMf) log("WARNING: AndroidManifest.xml not found in input APK!")
        return tmp.absolutePath
    }

    /**
     * Returns true for ZIP entries that belong to the APK signature block and
     * should be stripped from the output.  Removing these means the injected APK
     * has no stale cert/manifest files, so users can sign directly without first
     * running a "signature killer" that re-zips the file and destroys
     * resources.arsc alignment (Android install error -124).
     */
    private fun isSignatureEntry(name: String): Boolean {
        val n = name.uppercase()
        if (!n.startsWith("META-INF/")) return false
        // Keep META-INF entries that are NOT signature-related (e.g. services/)
        val leaf = n.removePrefix("META-INF/")
        return leaf == "MANIFEST.MF"          ||
               leaf.endsWith(".SF")           ||
               leaf.endsWith(".RSA")          ||
               leaf.endsWith(".DSA")          ||
               leaf.endsWith(".EC")           ||
               leaf == "ANDROID.SF"           ||
               leaf == "ANDROID.RSA"          ||
               leaf.startsWith("SIG-")        ||
               leaf == "CERT.SF"              ||
               leaf == "CERT.RSA"
    }

    /** Writes a single entry into [zout], preserving STORED vs DEFLATED and metadata. */
    private fun writeZipEntry(zout: ZipOutputStream, src: ZipEntry, bytes: ByteArray) {
        val ze = ZipEntry(src.name)
        if (src.method == ZipEntry.STORED) {
            ze.method         = ZipEntry.STORED
            ze.size           = bytes.size.toLong()
            ze.compressedSize = bytes.size.toLong()
            val crc = CRC32().also { it.update(bytes) }
            ze.crc            = crc.value
        } else {
            ze.method = ZipEntry.DEFLATED
        }
        ze.extra            = src.extra
        ze.comment          = src.comment
        ze.lastModifiedTime = src.lastModifiedTime
        zout.putNextEntry(ze)
        zout.write(bytes)
        zout.closeEntry()
    }

    /**
     * Re-zips the APK so that resources.arsc (and any other already-stored entries)
     * are STORED (uncompressed) and 4-byte aligned, satisfying Android R+ install rule -124.
     * Returns the path of the fixed APK (overwrites in-place via temp file swap).
     */
    private fun fixApkAlignment(apkPath: String): String {
        if (apkPath.isEmpty() || !File(apkPath).exists()) return apkPath

        val src  = File(apkPath)
        val tmp  = File(apkPath + ".align_tmp")

        class CountingOutputStream(private val delegate: OutputStream) : OutputStream() {
            var count: Long = 0L
            override fun write(b: Int)                      { delegate.write(b); count++ }
            override fun write(b: ByteArray, off: Int, len: Int) { delegate.write(b, off, len); count += len }
            override fun flush() = delegate.flush()
            override fun close() = delegate.close()
        }

        val counting = CountingOutputStream(BufferedOutputStream(FileOutputStream(tmp)))
        val zout = ZipOutputStream(counting)
        zout.setLevel(9)

        ZipInputStream(FileInputStream(src)).use { zin ->
            var entry = zin.nextEntry
            while (entry != null) {
                val bytes = zin.readBytes()

                val needsAlign = entry.method == ZipEntry.STORED ||
                                 entry.name == "resources.arsc"

                val ze = ZipEntry(entry.name)

                if (needsAlign) {
                    // Calculate padding needed so file data starts on 4-byte boundary.
                    // Local file header = 30 bytes + name.length + extra.length
                    // current position after header = counting.count + 30 + name.length + extraLen
                    val nameLen    = entry.name.toByteArray(Charsets.UTF_8).size
                    val baseOffset = counting.count + 30L + nameLen
                    val extraLen   = ((4 - ((baseOffset) % 4)) % 4).toInt()
                    ze.extra = ByteArray(extraLen)   // zero-padded extra field

                    ze.method          = ZipEntry.STORED
                    ze.size            = bytes.size.toLong()
                    ze.compressedSize  = bytes.size.toLong()
                    val crc = CRC32().also { it.update(bytes) }
                    ze.crc             = crc.value
                } else {
                    ze.method = ZipEntry.DEFLATED
                    ze.extra  = entry.extra
                }

                ze.comment         = entry.comment
                ze.lastModifiedTime = entry.lastModifiedTime

                zout.putNextEntry(ze)
                zout.write(bytes)
                zout.closeEntry()

                entry = zin.nextEntry
            }
        }

        // Add a minimal MANIFEST.MF as the very last entry so resources.arsc alignment
        // is unaffected.  This lets MT Manager's sign/resign flow recognise the APK as
        // "processable" rather than refusing with "APK not signed".  Users just hit Sign
        // (not Kill) — MT Manager replaces this placeholder with a real certificate.
        val mfBytes = "Manifest-Version: 1.0\r\nCreated-By: Taurus-PineHook\r\n\r\n".toByteArray()
        val mfEntry = ZipEntry("META-INF/MANIFEST.MF")
        mfEntry.method = ZipEntry.DEFLATED
        zout.putNextEntry(mfEntry)
        zout.write(mfBytes)
        zout.closeEntry()

        zout.finish()
        zout.close()

        // Swap temp → original
        src.delete()
        tmp.renameTo(src)

        log("APK aligned: resources.arsc stored uncompressed + 4-byte boundary")
        return apkPath
    }

    /**
     * Re-writes the APK at [apkPath] in-place, replacing AndroidManifest.xml with a
     * version that has the four split-related attributes stripped out.
     *
     * Why: When an .apks / .xapk bundle's base.apk has android:requiredSplitTypes,
     * android:splitTypes, android:isFeatureSplit, or android:isSplitRequired in its
     * binary manifest, Android still demands the separate split APKs even after we
     * have merged them all into one fat APK — causing INSTALL_FAILED_MISSING_SPLIT.
     * Removing those four attributes (which is exactly what AntiSplit M does via
     * ARSCLib) tells the installer there are no outstanding splits required.
     */
    private fun patchApkManifestInPlace(apkPath: String) {
        val src = File(apkPath)
        val tmp = File(apkPath + ".manpatch_tmp")
        var didPatch = false

        ZipOutputStream(BufferedOutputStream(FileOutputStream(tmp))).use { zout ->
            zout.setLevel(Deflater.DEFAULT_COMPRESSION)
            ZipFile(src).use { zf ->
                val entries = zf.entries()
                while (entries.hasMoreElements()) {
                    val ze = entries.nextElement()
                    var bytes = zf.getInputStream(ze).readBytes()
                    if (ze.name == "AndroidManifest.xml") {
                        val patched = patchBinaryManifest(bytes)
                        if (!patched.contentEquals(bytes)) { bytes = patched; didPatch = true }
                    }
                    writeZipEntry(zout, ze, bytes)
                }
            }
        }

        src.delete()
        tmp.renameTo(src)
        log("Manifest split-attr patch applied: $didPatch")
    }

    /**
     * Parses a binary Android manifest (AXML format) and returns a new byte array
     * with every attribute whose name is one of:
     *   requiredSplitTypes | splitTypes | isFeatureSplit | isSplitRequired
     * removed from every START_ELEMENT chunk.
     *
     * The binary format (little-endian):
     *   File header   : type(2) headerSize(2) fileSize(4)
     *   String pool   : type(2) hdrSize(2) chunkSize(4) strCount(4) styleCount(4)
     *                   flags(4) stringsStart(4) stylesStart(4)
     *                   [offsets: strCount×4] [string data]
     *   Resource map  : type(2) hdrSize(2) chunkSize(4) [resId×…]
     *   Namespace/element chunks …
     *   START_ELEMENT : type(2) hdrSize(2) chunkSize(4) lineNo(4) comment(4)
     *                   ns(4) name(4) attrStart(2) attrSize(2) attrCount(2) …
     *                   Each attr (20 bytes): ns(4) name(4) raw(4) tvSize(2) res0(1) type(1) data(4)
     */
    private fun patchBinaryManifest(data: ByteArray): ByteArray {
        if (data.size < 8) return data

        val intAt   = { p: Int -> (data[p].toInt() and 0xFF) or
                                  ((data[p+1].toInt() and 0xFF) shl 8) or
                                  ((data[p+2].toInt() and 0xFF) shl 16) or
                                  ((data[p+3].toInt() and 0xFF) shl 24) }
        val shortAt = { p: Int -> (data[p].toInt() and 0xFF) or ((data[p+1].toInt() and 0xFF) shl 8) }

        if (shortAt(0) != 0x0003) return data          // not binary XML

        val spStart = shortAt(2)                        // file header size = first chunk = sp offset
        if (spStart + 28 > data.size) return data
        if (shortAt(spStart) != 0x0001) return data     // not string pool

        val spHeaderSize = shortAt(spStart + 2)
        val stringCount  = intAt(spStart + 8)
        val isUtf8       = (intAt(spStart + 16) and 0x100) != 0
        val stringsStart = intAt(spStart + 20)

        val offsetsBase  = spStart + spHeaderSize
        val strDataBase  = spStart + stringsStart

        val targets      = setOf("requiredSplitTypes", "splitTypes", "isFeatureSplit", "isSplitRequired")
        val targetIdx    = mutableSetOf<Int>()
        val foundNames   = mutableMapOf<Int, String>()

        for (i in 0 until stringCount) {
            val offPos = offsetsBase + i * 4
            if (offPos + 4 > data.size) break
            val absPos = strDataBase + intAt(offPos)
            if (absPos >= data.size) continue
            val str = try {
                if (isUtf8) readBinXmlUtf8(data, absPos) else readBinXmlUtf16(data, absPos)
            } catch (_: Throwable) { continue }
            if (str in targets) { targetIdx.add(i); foundNames[i] = str }
        }

        if (targetIdx.isEmpty()) { log("manifest patch: no split attrs found"); return data }
        log("manifest patch: targeting attrs ${foundNames.values}")

        val out        = java.io.ByteArrayOutputStream(data.size)
        var pos        = 0
        var totalGone  = 0

        while (pos < data.size) {
            if (pos + 8 > data.size) { out.write(data, pos, data.size - pos); break }
            val chunkType   = shortAt(pos)
            val chunkSize   = intAt(pos + 4)
            if (chunkSize <= 0 || pos + chunkSize > data.size) {
                out.write(data, pos, data.size - pos); break
            }

            if (chunkType == 0x0102) {              // START_ELEMENT
                val attrStart  = shortAt(pos + 24)  // offset from byte-16 to attr data
                val attrSize   = shortAt(pos + 26)  // bytes per attr (always 20)
                val attrCount  = shortAt(pos + 28)
                val attrsOff   = pos + 16 + attrStart

                if (attrSize == 20 && attrCount > 0) {
                    val kept = mutableListOf<ByteArray>()
                    for (a in 0 until attrCount) {
                        val ap = attrsOff + a * 20
                        if (ap + 20 > data.size) break
                        val nameIdx = intAt(ap + 4)
                        if (nameIdx in targetIdx) {
                            log("manifest patch: dropped '${foundNames[nameIdx]}' at line ${intAt(pos + 8)}")
                        } else {
                            kept.add(data.copyOfRange(ap, ap + 20))
                        }
                    }
                    val removed = attrCount - kept.size
                    if (removed > 0) {
                        totalGone += removed
                        val newChunkSize = chunkSize - removed * 20
                        val newAttrCount = kept.size
                        // Write header bytes (everything up to attrsOff), patching sizes
                        val hdr = data.copyOfRange(pos, attrsOff)
                        // patch chunkSize @ hdr[4..7]
                        hdr[4] = (newChunkSize and 0xFF).toByte()
                        hdr[5] = ((newChunkSize shr 8) and 0xFF).toByte()
                        hdr[6] = ((newChunkSize shr 16) and 0xFF).toByte()
                        hdr[7] = ((newChunkSize shr 24) and 0xFF).toByte()
                        // patch attrCount @ hdr[28..29] (pos-relative = 28, pos offset in hdr = attrsOff-pos-16+12 = 28)
                        val attrCountOff = 28   // always 28 from chunk start
                        hdr[attrCountOff]     = (newAttrCount and 0xFF).toByte()
                        hdr[attrCountOff + 1] = ((newAttrCount shr 8) and 0xFF).toByte()
                        out.write(hdr)
                        for (ab in kept) out.write(ab)
                        pos += chunkSize
                        continue
                    }
                }
            }

            out.write(data, pos, chunkSize)
            pos += chunkSize
        }

        val result = out.toByteArray()
        if (totalGone > 0) {
            val sz = result.size
            result[4] = (sz and 0xFF).toByte()
            result[5] = ((sz shr 8) and 0xFF).toByte()
            result[6] = ((sz shr 16) and 0xFF).toByte()
            result[7] = ((sz shr 24) and 0xFF).toByte()
            log("manifest patch: removed $totalGone split attrs, ${data.size}→${result.size} bytes")
        }
        return result
    }

    /** Reads a UTF-8 string from an AXML string pool entry. */
    private fun readBinXmlUtf8(data: ByteArray, pos: Int): String {
        var p = pos
        var u16 = data[p].toInt() and 0xFF; p++
        if (u16 and 0x80 != 0) { u16 = ((u16 and 0x7F) shl 8) or (data[p].toInt() and 0xFF); p++ }
        var u8 = data[p].toInt() and 0xFF; p++
        if (u8 and 0x80 != 0) { u8 = ((u8 and 0x7F) shl 8) or (data[p].toInt() and 0xFF); p++ }
        return String(data, p, u8, Charsets.UTF_8)
    }

    /** Reads a UTF-16LE string from an AXML string pool entry. */
    private fun readBinXmlUtf16(data: ByteArray, pos: Int): String {
        var p = pos
        var len = (data[p].toInt() and 0xFF) or ((data[p+1].toInt() and 0xFF) shl 8); p += 2
        if (len and 0x8000 != 0) {
            len = ((len and 0x7FFF) shl 16) or ((data[p].toInt() and 0xFF) or ((data[p+1].toInt() and 0xFF) shl 8)); p += 2
        }
        return String(data, p, len * 2, Charsets.UTF_16LE)
    }

    private fun injectGuideIntoApk(apkPath: String, guideJson: String) {
        val src = File(apkPath)
        val dst = File(src.parent, "guided_${src.name}")
        val guideBytes = guideJson.toByteArray(Charsets.UTF_8)
        ZipFile(src).use { zf ->
            ZipOutputStream(BufferedOutputStream(FileOutputStream(dst))).use { zout ->
                zout.setLevel(Deflater.DEFAULT_COMPRESSION)
                for (entry in zf.entries()) {
                    val data = if (entry.name == "hook/config.json") {
                        ByteArray(0)
                    } else {
                        zf.getInputStream(entry).readBytes()
                    }
                    writeZipEntry(zout, entry, data)
                }
                if (zf.getEntry("hook/hook_guide.json") == null) {
                    val ge = ZipEntry("hook/hook_guide.json").apply { method = ZipEntry.DEFLATED }
                    zout.putNextEntry(ge)
                    zout.write(guideBytes)
                    zout.closeEntry()
                }
            }
        }
        src.delete()
        dst.renameTo(src)
    }

    private fun releaseWake() {
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        releaseWake()
    }
}
