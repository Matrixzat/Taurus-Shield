package com.taurus.shield

internal object SslTargetsNative {
    init {
        System.loadLibrary("ssl_native")
    }

    @JvmStatic external fun getVoidTargets(): Array<String>
    @JvmStatic external fun getBoolTargets(): Array<String>
    @JvmStatic external fun getHeuristicStrings(): Array<String>
    @JvmStatic external fun getNscStrings(): Array<String>
}
