package com.taurus.shield

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class PairingNotificationListener : NotificationListenerService() {

    companion object {
        @Volatile var latestPairingCode: String? = null
        @Volatile var codeTimestamp: Long = 0L

        fun consumeCode(): String? {
            val code = latestPairingCode
            if (code != null && System.currentTimeMillis() - codeTimestamp < 120_000L) {
                latestPairingCode = null
                return code
            }
            latestPairingCode = null
            return null
        }

        fun peekCode(): String? {
            val code = latestPairingCode
            if (code != null && System.currentTimeMillis() - codeTimestamp < 120_000L) {
                return code
            }
            return null
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val pkg = sbn.packageName ?: return
        if (pkg != "android" && pkg != "com.android.settings" &&
            pkg != "com.android.systemui" && !pkg.contains("settings")) return

        try {
            val extras = sbn.notification?.extras ?: return
            val title = extras.getCharSequence("android.title")?.toString() ?: ""
            val text  = extras.getCharSequence("android.text")?.toString() ?: ""
            val big   = extras.getCharSequence("android.bigText")?.toString() ?: ""
            val combined = "$title $text $big"

            val lower = combined.lowercase()
            if (!lower.contains("pair") && !lower.contains("debug") &&
                !lower.contains("wireless") && !lower.contains("wi-fi")) return

            val match = Regex("\\b(\\d{6})\\b").find(combined)
            if (match != null) {
                latestPairingCode = match.groupValues[1]
                codeTimestamp = System.currentTimeMillis()
            }
        } catch (_: Exception) {}
    }
}
