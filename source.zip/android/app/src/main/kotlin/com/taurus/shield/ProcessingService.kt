package com.taurus.shield

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.util.concurrent.Executors

class ProcessingService : Service() {

    companion object {
        const val PREFS         = "taurus_svc"
        const val KEY_RUNNING   = "running"
        const val KEY_LOGS      = "logs"
        const val KEY_STATUS    = "result_status"
        const val KEY_OUTPUT_DIR  = "output_dir"
        const val KEY_OUTPUT_PATH = "output_path"
        const val KEY_ERROR     = "error"
        const val KEY_FILE_NAME = "file_name"
        const val KEY_FILE_PATH = "file_path"
        const val KEY_MODE      = "mode"

        fun isRunning(context: Context): Boolean {
            return context.getSharedPreferences(PREFS, MODE_PRIVATE)
                .getBoolean(KEY_RUNNING, false)
        }

        fun getState(context: Context): Map<String, Any?> {
            val p = context.getSharedPreferences(PREFS, MODE_PRIVATE)
            return mapOf(
                "running"    to p.getBoolean(KEY_RUNNING, false),
                "logs"       to (p.getString(KEY_LOGS, "") ?: ""),
                "status"     to (p.getString(KEY_STATUS, "") ?: ""),
                "outputDir"  to (p.getString(KEY_OUTPUT_DIR, "") ?: ""),
                "outputPath" to (p.getString(KEY_OUTPUT_PATH, "") ?: ""),
                "error"      to (p.getString(KEY_ERROR, "") ?: ""),
                "fileName"   to (p.getString(KEY_FILE_NAME, "") ?: ""),
                "filePath"   to (p.getString(KEY_FILE_PATH, "") ?: ""),
                "mode"       to (p.getString(KEY_MODE, "") ?: ""),
            )
        }
    }

    private val executor = Executors.newSingleThreadExecutor()
    private val logPumpExecutor = Executors.newSingleThreadExecutor()
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val filePath  = intent?.getStringExtra("filePath")  ?: return bail()
        val fileName  = intent.getStringExtra("fileName")   ?: filePath.substringAfterLast('/')
        val mode      = intent.getStringExtra("mode")       ?: "dsm"
        val outputDir = intent.getStringExtra("outputDir")  ?: return bail()

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "TaurusShield::Processing")
        wakeLock?.acquire(30 * 60 * 1000L)

        NotificationHelper.createChannels(this)
        val notif = NotificationHelper.buildProcessingNotif(this, "Processing...", fileName)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NotificationHelper.NOTIF_PROCESSING, notif,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NotificationHelper.NOTIF_PROCESSING, notif)
        }

        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        prefs.edit()
            .putBoolean(KEY_RUNNING, true)
            .putString(KEY_LOGS, "")
            .putString(KEY_STATUS, "")
            .putString(KEY_OUTPUT_DIR, outputDir)
            .putString(KEY_OUTPUT_PATH, "")
            .putString(KEY_ERROR, "")
            .putString(KEY_FILE_NAME, fileName)
            .putString(KEY_FILE_PATH, filePath)
            .putString(KEY_MODE, mode)
            .apply()

        if (!Python.isStarted()) {
            Python.start(AndroidPlatform(this))
        }

        LogBridge.clear()

        logPumpExecutor.execute {
            val sb = StringBuilder()
            var count = 0
            while (true) {
                val line = LogBridge.poll(200L)
                when {
                    line == null -> continue
                    line == LogBridge.DONE -> break
                    else -> {
                        sb.appendLine(line)
                        count++
                        if (count % 3 == 0) {
                            prefs.edit().putString(KEY_LOGS, sb.toString()).apply()
                        }
                    }
                }
            }
            prefs.edit().putString(KEY_LOGS, sb.toString()).apply()
        }

        executor.execute {
            val isAsm  = mode == "asm" || mode == "zip"
            val method = if (isAsm) "do_assemble" else "do_disassemble"
            val result = runPython(method, filePath, outputDir)
            LogBridge.done()

            Thread.sleep(600)

            val status = result["status"] as? String ?: "error"
            val resDir = result["outputDir"] as? String ?: outputDir
            val resPath = result["outputPath"] as? String ?: ""
            val resErr = result["error"] as? String ?: ""

            prefs.edit()
                .putBoolean(KEY_RUNNING, false)
                .putString(KEY_STATUS, status)
                .putString(KEY_OUTPUT_DIR, resDir)
                .putString(KEY_OUTPUT_PATH, resPath)
                .putString(KEY_ERROR, resErr)
                .apply()

            val success = status == "success"
            NotificationHelper.showResult(
                this@ProcessingService, success,
                if (success) "Taurus Shield — Done" else "Taurus Shield — Failed",
                if (success) "$fileName processed successfully. Tap to open the app."
                else "$fileName could not be processed. Tap to view the log."
            )

            releaseWake()
            stopForeground(true)
            stopSelf()
        }

        return START_STICKY
    }

    private fun bail(): Int { stopSelf(); return START_NOT_STICKY }

    private fun releaseWake() {
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
    }

    override fun onDestroy() { releaseWake(); super.onDestroy() }

    private fun runPython(method: String, arg1: String, arg2: String): Map<String, Any?> {
        return try {
            val py     = Python.getInstance()
            val bridge = py.getModule("api_bridge")
            val fn     = bridge[method] ?: return mapOf(
                "status" to "error", "log" to "Function '$method' not found", "outputDir" to arg2
            )
            val pyResult = fn.call(arg1, arg2)
            val map: Map<String, Any?> = pyResult.asMap().entries
                .associate { it.key.toString() to it.value }
            mapOf(
                "status"     to (map["status"]?.toString()      ?: "error"),
                "log"        to (map["log"]?.toString()         ?: ""),
                "outputDir"  to (map["output_dir"]?.toString()  ?: arg2),
                "outputPath" to (map["output_path"]?.toString() ?: ""),
                "error"      to (map["error"]?.toString()       ?: "")
            )
        } catch (e: Exception) {
            mapOf(
                "status" to "error", "log" to "Python error: ${e.message}",
                "outputDir" to arg2, "error" to (e.message ?: "Unknown error")
            )
        }
    }
}
