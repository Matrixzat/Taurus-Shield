package com.taurus.shield

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.os.PowerManager
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

class ModEngineService : Service() {

    companion object {
        const val PREFS       = "mod_engine_svc"
        const val KEY_RUNNING = "running"
        const val KEY_PHASE   = "phase"
        const val KEY_LOGS    = "logs"
        const val KEY_STATUS  = "result_status"
        const val KEY_RESULT        = "result"
        const val KEY_DUMP_CS       = "dump_cs_path"
        const val KEY_DUMP_H        = "dump_h_path"
        const val KEY_SCRIPT_JSON   = "script_json_path"
        const val KEY_STRING_LIT    = "stringliteral_path"
        const val KEY_IDA_PY        = "ida_py_path"
        const val KEY_IDA_STRUCT    = "ida_struct_path"
        const val KEY_GHIDRA_PY     = "ghidra_py_path"
        const val KEY_JOB_ID        = "job_id"
        const val KEY_RUN_ID        = "run_id"
        const val KEY_PROGRESS      = "progress"

        const val ACTION_DUMP  = "com.taurus.shield.MOD_ENGINE_DUMP"
        const val ACTION_BUILD = "com.taurus.shield.MOD_ENGINE_BUILD"
        const val ACTION_STOP  = "com.taurus.shield.MOD_ENGINE_STOP"

        const val EXTRA_APK_PATH      = "apk_path"
        const val EXTRA_ZIP_PATH      = "zip_path"
        const val EXTRA_GAME_NAME     = "game_name"
        const val EXTRA_FEATURES_JSON = "features_json"

        private const val NOTIF_ID = 4001
        private const val DUMP_WORKFLOW  = "game-dump.yml"

        private val cancelFlag = AtomicBoolean(false)
        private var workerThread: Thread? = null

        fun isRunning(context: Context): Boolean =
            context.getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_RUNNING, false)

        fun cancel(context: Context) {
            cancelFlag.set(true)
            workerThread?.interrupt()
            // Tell the cloud engine to stop the run immediately
            val runId = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getLong(KEY_RUN_ID, 0L)
            if (runId > 0L) {
                Thread {
                    try {
                        val workerUrl = NativeSecrets.workerUrl()
                        val conn = (java.net.URL("$workerUrl/cancel-run?run_id=$runId")
                            .openConnection() as java.net.HttpURLConnection).apply {
                            requestMethod = "POST"
                            connectTimeout = 10_000
                            readTimeout    = 10_000
                            doOutput = false
                        }
                        conn.responseCode
                        conn.disconnect()
                    } catch (_: Exception) {}
                }.start()
            }
            context.stopService(Intent(context, ModEngineService::class.java))
        }

        fun prefs(ctx: Context): SharedPreferences =
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

        fun clearState(ctx: Context) {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_RUNNING, false)
                .putString(KEY_PHASE, "")
                .putString(KEY_LOGS, "")
                .putString(KEY_STATUS, "")
                .putString(KEY_RESULT, "")
                .putString(KEY_DUMP_CS, "")
                .putString(KEY_DUMP_H, "")
                .putString(KEY_SCRIPT_JSON, "")
                .putString(KEY_STRING_LIT, "")
                .putString(KEY_IDA_PY, "")
                .putString(KEY_IDA_STRUCT, "")
                .putString(KEY_GHIDRA_PY, "")
                .putString(KEY_JOB_ID, "")
                .putLong(KEY_RUN_ID, 0L)
                .putInt(KEY_PROGRESS, -1)
                .apply()
        }
    }

    private val WORKER by lazy { NativeSecrets.workerUrl() }

    private val executor  = Executors.newSingleThreadExecutor()
    private lateinit var prefs: SharedPreferences
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Acquire wakelock immediately — before any async work
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "TaurusShield::ModEngine")
        wakeLock?.acquire(90 * 60 * 1000L)

        NotificationHelper.createChannels(this)
        startForegroundCompat()

        cancelFlag.set(false)

        when (intent?.action) {
            ACTION_DUMP  -> handleDump(intent)
            ACTION_BUILD -> handlePatch(intent)
            ACTION_STOP  -> { releaseWake(); stopForeground(true); stopSelf() }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val notif = NotificationHelper.buildProcessingNotif(
            this, "Mod Engine", "Processing…")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    // ── DUMP ──────────────────────────────────────────────────────────────────
    private fun handleDump(intent: Intent) {
        val zipPath = intent.getStringExtra(EXTRA_ZIP_PATH) ?: run { bail(); return }
        prefs.edit()
            .putBoolean(KEY_RUNNING, true)
            .putString(KEY_PHASE, "uploading")
            .putString(KEY_JOB_ID, "")
            .putString(KEY_LOGS, "")
            .putString(KEY_STATUS, "running")
            .apply()

        executor.execute {
            workerThread = Thread.currentThread()
            try {
                log("Starting game analysis…")
                val zipFile = java.io.File(zipPath)
                if (!zipFile.exists()) throw RuntimeException("Zip file not found at: $zipPath")
                val zipMb = "%.1f MB".format(zipFile.length() / 1_048_576.0)
                log("IL2CPP zip ready — $zipMb")

                updatePhase("uploading")
                log("Uploading to secure cluster…")
                val uploadBody = workerPost("/game-dump", zipFile)
                    ?: throw RuntimeException("Upload failed — check network")

                val uploadJson  = JSONObject(uploadBody)
                val jobId       = uploadJson.getString("job_id")
                val triggeredAt = uploadJson.optLong("triggered_at", System.currentTimeMillis())

                prefs.edit().putString(KEY_JOB_ID, jobId).apply()
                log("Upload complete — queuing analysis…")
                updatePhase("dispatching")

                Thread.sleep(4_000L)
                log("Connecting to cloud engine…")
                updatePhase("finding_run")

                val runId = findRun(triggeredAt, DUMP_WORKFLOW)
                    ?: throw RuntimeException("Cloud engine not ready — check connection and try again")

                prefs.edit().putLong(KEY_RUN_ID, runId).apply()

                log("Engine ready — analysing IL2CPP symbols…")
                updatePhase("analysing")
                pollUntilDone(runId)

                log("Downloading analysis results…")
                updatePhase("downloading")
                val outDir = File(Environment.getExternalStorageDirectory(), "Taurus-Shield/output/mod-engine").also { it.mkdirs() }

                val tmpZip = File(outDir, "_dump_${jobId}_artifact.zip")
                // GitHub's artifact API may return 404 for a few seconds right after the
                // workflow completes — retry up to 12 × 5 s = 60 s (mirrors Dex2C withNetworkRetry).
                var dlOk = false
                for (dlRetry in 0 until 12) {
                    if (cancelFlag.get()) break
                    if (dlRetry > 0) {
                        log("Artifact not ready yet — retrying in 5s… ($dlRetry/12)")
                        updatePhase("downloading")
                        Thread.sleep(5_000)
                    }
                    dlOk = workerDownloadToFile("/artifact?run_id=$runId&job_id=$jobId&prefix=game-dump", tmpZip)
                    if (dlOk) break
                }
                if (!dlOk) throw RuntimeException("Result not ready — cloud job may have failed")

                val outFile = File(outDir, "dump_${jobId}.json")
                val editor  = prefs.edit()

                data class DumpEntry(val entryName: String, val dest: File, val key: String, val label: String)
                val entries = listOf(
                    DumpEntry("dump.cs",     File(outDir, "dump_${jobId}.cs"),     KEY_DUMP_CS,     "dump.cs"),
                    DumpEntry("script.json", File(outDir, "script_${jobId}.json"), KEY_SCRIPT_JSON, "script.json"),
                )

                ZipFile(tmpZip).use { zip ->
                    val offsetsEntry = zip.getEntry("offsets.json")
                        ?: throw RuntimeException("offsets.json not found in artifact — dump may have failed")
                    zip.getInputStream(offsetsEntry).use { src ->
                        FileOutputStream(outFile).use { dst -> src.copyTo(dst) }
                    }
                    log("offsets.json saved ✓  (${outFile.length() / 1024} KB)")

                    for (de in entries) {
                        val zipEntry = zip.getEntry(de.entryName) ?: continue
                        zip.getInputStream(zipEntry).use { src ->
                            FileOutputStream(de.dest).use { dst -> src.copyTo(dst) }
                        }
                        editor.putString(de.key, de.dest.absolutePath)
                        log("${de.label} saved ✓  (${de.dest.length() / 1024} KB)")
                    }
                }
                editor.apply()
                tmpZip.delete()

                log("Analysis complete ✓")
                log("Saved to Internal Storage/Taurus-Shield/output/mod-engine/")
                finishSuccess(outFile.absolutePath)
                NotificationHelper.showResult(this,
                    true, "Game Analysis Complete", "Tap to select features to mod")

            } catch (e: Exception) {
                if (cancelFlag.get() || e is InterruptedException) {
                    finishCancelled()
                } else {
                    log("Error: ${e.message}")
                    finishError(e.message ?: "Unknown error")
                }
            } finally {
                releaseWake()
                stopForeground(true)
                stopSelf()
            }
        }
    }

    // ── PATCH — on-device ARM64 binary patching, no cloud needed ─────────────
    private fun handlePatch(intent: Intent) {
        val apkPath      = intent.getStringExtra(EXTRA_APK_PATH)      ?: run { bail(); return }
        val gameName     = intent.getStringExtra(EXTRA_GAME_NAME)      ?: "game"
        val featuresJson = intent.getStringExtra(EXTRA_FEATURES_JSON)  ?: "[]"

        prefs.edit()
            .putBoolean(KEY_RUNNING, true)
            .putString(KEY_PHASE, "extracting")
            .putString(KEY_JOB_ID, "")
            .putString(KEY_LOGS, "")
            .putString(KEY_STATUS, "running")
            .putInt(KEY_PROGRESS, -1)
            .apply()

        executor.execute {
            workerThread = Thread.currentThread()
            try {
                val safeGame = gameName.replace(" ", "_")
                log("Starting on-device patch for '$gameName'…")
                updatePhase("extracting")

                // ── 1. Extract libil2cpp.so from APK ──────────────────────────
                val outDir = File(Environment.getExternalStorageDirectory(),
                    "Taurus-Shield/output/mod-engine").also { it.mkdirs() }
                val outFile = File(outDir, "${safeGame}_libil2cpp_patched.so")
                var soSize = 0L

                ZipFile(apkPath).use { zip ->
                    val entries = zip.entries().toList()
                    val entry = entries.firstOrNull { it.name.contains("arm64-v8a/libil2cpp.so") }
                        ?: entries.firstOrNull { it.name.contains("libil2cpp.so") }
                        ?: throw RuntimeException("libil2cpp.so (arm64-v8a) not found in APK")
                    // entry.size may be -1 for some zip implementations — log what we know
                    val knownSize = entry.size.takeIf { it > 0 }
                    log("Found ${entry.name.substringAfterLast('/')}${
                        if (knownSize != null) " — ${"%.1f".format(knownSize / 1_048_576.0)} MB" else ""}")
                    updateProgress(0)
                    zip.getInputStream(entry).use { inp ->
                        FileOutputStream(outFile).use { out ->
                            val buf = ByteArray(65_536)
                            var n: Int; var wrote = 0L
                            while (inp.read(buf).also { n = it } != -1) {
                                out.write(buf, 0, n); wrote += n
                                // only show extraction progress if size is known
                                if (knownSize != null && knownSize > 0) {
                                    updateProgress(((wrote * 50L) / knownSize).toInt().coerceIn(0, 50))
                                }
                            }
                        }
                    }
                }
                // Use actual file size after extraction — the definitive truth
                soSize = outFile.length()
                if (soSize == 0L) throw RuntimeException("Extracted libil2cpp.so is empty — APK may be corrupt")
                log("Extracted ${"%.1f".format(soSize / 1_048_576.0)} MB — applying patches…")
                updatePhase("patching")

                // ── 2. Patch bytes at each offset ─────────────────────────────
                val features = org.json.JSONArray(featuresJson)
                val count    = features.length()
                var applied  = 0
                var skipped  = 0

                java.io.RandomAccessFile(outFile, "rw").use { raf ->
                    for (i in 0 until count) {
                        if (cancelFlag.get()) break
                        val feat      = features.getJSONObject(i)
                        val offsetStr = feat.optString("file_offset", "")
                        val type      = feat.optString("type", "bool")
                        val value     = feat.opt("value")
                        val label     = "${feat.optString("class")}.${feat.optString("method")}"

                        val fileOff = offsetStr.removePrefix("0x").toLongOrNull(16)
                        if (fileOff == null || fileOff < 0L || fileOff >= soSize) {
                            log("  ⚠ Skip $label — offset out of range"); skipped++; continue
                        }
                        // ARM64 instructions must be 4-byte aligned
                        if (fileOff % 4L != 0L) {
                            log("  ⚠ Skip $label — offset 0x${fileOff.toString(16)} not 4-byte aligned"); skipped++; continue
                        }
                        // branch_always needs the existing instruction bytes —
                        // read them from the file before building the patch
                        val patchValue: Any? = if (type == "branch_always") {
                            val buf4 = ByteArray(4)
                            raf.seek(fileOff)
                            raf.readFully(buf4)
                            (buf4[0].toInt() and 0xFF) or
                                ((buf4[1].toInt() and 0xFF) shl 8) or
                                ((buf4[2].toInt() and 0xFF) shl 16) or
                                ((buf4[3].toInt() and 0xFF) shl 24)
                        } else value

                        val patch = buildArm64Patch(type, patchValue)
                        if (patch == null) {
                            log("  ⚠ Skip $label — unsupported type '$type'${
                                if (type == "branch_always") " (no recognised conditional branch at offset)" else ""
                            }"); skipped++; continue
                        }
                        if (fileOff + patch.size > soSize) {
                            log("  ⚠ Skip $label — patch exceeds binary"); skipped++; continue
                        }
                        raf.seek(fileOff)
                        raf.write(patch)
                        applied++
                        val pct = 50 + ((applied.toLong() * 50L) / count.toLong().coerceAtLeast(1L)).toInt()
                        updateProgress(pct.coerceIn(50, 100))
                        log("  ✓ $label @ $offsetStr")
                    }
                }
                updateProgress(100)
                log("Done — $applied patched${if (skipped > 0) ", $skipped skipped" else ""} ✓")
                log("Saved → Internal Storage/Taurus-Shield/output/mod-engine/")
                log("Open APK with MT Manager → replace lib/arm64-v8a/libil2cpp.so → install.")
                finishSuccess(outFile.absolutePath)
                NotificationHelper.showResult(this, true,
                    "Patched! $applied method(s) applied",
                    "Replace libil2cpp.so in APK via MT Manager, then install")

            } catch (e: Exception) {
                if (cancelFlag.get() || e is InterruptedException) finishCancelled()
                else { log("Error: ${e.message}"); finishError(e.message ?: "Unknown error") }
            } finally {
                releaseWake()
                stopForeground(true)
                stopSelf()
            }
        }
    }

    // ── Branch conversion helper ──────────────────────────────────────────────
    // Reads the existing conditional branch instruction and converts it to
    // an unconditional B targeting the same offset.  Returns null if the
    // instruction at that address is not a recognised conditional branch.
    private fun convertToUnconditionalBranch(insn: Int): Int? {
        // B.cond: bits[31:24]=0x54, bit[4]=0 → bits[23:5]=imm19
        if ((insn ushr 24) == 0x54 && (insn and 0x10) == 0) {
            val imm19 = (insn ushr 5) and 0x7FFFF
            val s = if (imm19 and 0x40000 != 0) (imm19 or -0x80000) else imm19
            return 0x14000000 or (s and 0x3FFFFFF)
        }
        // CBZ / CBNZ: bits[31:24] ∈ {0x34,0x35,0xB4,0xB5} → bits[23:5]=imm19
        val op8 = (insn ushr 24) and 0xFF
        if (op8 == 0x34 || op8 == 0x35 || op8 == 0xB4 || op8 == 0xB5) {
            val imm19 = (insn ushr 5) and 0x7FFFF
            val s = if (imm19 and 0x40000 != 0) (imm19 or -0x80000) else imm19
            return 0x14000000 or (s and 0x3FFFFFF)
        }
        // TBZ / TBNZ: bits[29:24]=0x1B → bits[18:5]=imm14
        if ((insn ushr 24) and 0x3F == 0x1B) {
            val imm14 = (insn ushr 5) and 0x3FFF
            val s = if (imm14 and 0x2000 != 0) (imm14 or -0x4000) else imm14
            return 0x14000000 or (s and 0x3FFFFFF)
        }
        // Already an unconditional B: bits[31:26]=0b000101=5
        if ((insn ushr 26) and 0x3F == 5) return insn
        return null  // not a recognised conditional branch
    }

    // ── ARM64 patch builder ───────────────────────────────────────────────────
    // Writes minimal ARM64 instructions at each method's file offset:
    //   bool/int/long    → MOVZ W0,#lo [+ MOVK W0,#hi,LSL#16] + RET
    //   float            → MOVZ/MOVK + FMOV S0,W0 + RET
    //   void             → RET
    //   nop              → NOP × count  (D503201F each)
    //   branch_never     → NOP          (kills the conditional jump)
    //   branch_always    → B #target    (reads existing insn, makes it unconditional)
    private fun buildArm64Patch(type: String, value: Any?): ByteArray? {
        val RET = byteArrayOf(0xC0.toByte(), 0x03, 0x5F.toByte(), 0xD6.toByte())

        fun i32le(v: Int): ByteArray = byteArrayOf(
            (v and 0xFF).toByte(), ((v ushr 8) and 0xFF).toByte(),
            ((v ushr 16) and 0xFF).toByte(), ((v ushr 24) and 0xFF).toByte())

        // MOVZ W0, #imm16  (zero-extends, clears upper half)
        fun movzW0(imm16: Int) = i32le(0x52800000 or ((imm16 and 0xFFFF) shl 5))
        // MOVK W0, #imm16, LSL#16  (keeps lower 16, sets upper 16)
        fun movkW0Hi(imm16: Int) = i32le(0x72A00000 or ((imm16 and 0xFFFF) shl 5))
        // FMOV S0, W0
        val fmovS0W0 = i32le(0x1E270000)

        fun intPatch(v: Long): ByteArray {
            val lo = (v and 0xFFFFL).toInt()
            val hi = ((v ushr 16) and 0xFFFFL).toInt()
            return if (hi == 0) movzW0(lo) + RET
            else movzW0(lo) + movkW0Hi(hi) + RET
        }

        return when (type) {
            "void" -> RET
            "bool" -> {
                val v = when (value) {
                    is Boolean -> if (value) 1L else 0L
                    is Number  -> value.toLong()
                    is String  -> if (value == "true" || value == "1") 1L else 0L
                    else       -> 1L
                }
                intPatch(v.coerceIn(0L, 1L))
            }
            "int", "long" -> {
                val v = when (value) {
                    is Number -> value.toLong()
                    is String -> value.toLongOrNull() ?: 1L
                    else      -> 1L
                }
                intPatch(v and 0xFFFFFFFFL)
            }
            "float" -> {
                val fv = when (value) {
                    is Number -> value.toFloat()
                    is String -> value.toFloatOrNull() ?: 1.0f
                    else      -> 1.0f
                }
                val bits = java.lang.Float.floatToRawIntBits(fv).toLong() and 0xFFFFFFFFL
                val lo = (bits and 0xFFFFL).toInt()
                val hi = ((bits ushr 16) and 0xFFFFL).toInt()
                if (hi == 0) movzW0(lo) + fmovS0W0 + RET
                else movzW0(lo) + movkW0Hi(hi) + fmovS0W0 + RET
            }
            // NOP — writes N × ARM64 NOP instructions (D503201F each)
            "nop" -> {
                val count = when (value) {
                    is Number -> value.toInt().coerceIn(1, 64)
                    is String -> value.toIntOrNull()?.coerceIn(1, 64) ?: 1
                    else      -> 1
                }
                val nop = i32le(0xD503201F.toInt())
                (1..count).fold(byteArrayOf()) { acc, _ -> acc + nop }
            }
            // branch_never — writes NOP, killing the conditional branch
            "branch_never" -> i32le(0xD503201F.toInt())
            // branch_always — converts B.cond / CBZ / CBNZ / TBZ / TBNZ → unconditional B
            // value must be the existing 4 bytes decoded as a little-endian Int
            // (the patch loop pre-reads this for us)
            "branch_always" -> {
                val existing = when (value) {
                    is Number -> value.toInt()
                    else      -> return null
                }
                val unconditional = convertToUnconditionalBranch(existing) ?: return null
                i32le(unconditional)
            }
            else -> null
        }
    }

    // ── Finish helpers ────────────────────────────────────────────────────────

    private fun finishSuccess(resultPath: String) {
        prefs.edit()
            .putBoolean(KEY_RUNNING, false)
            .putString(KEY_PHASE, "done")
            .putString(KEY_STATUS, "success")
            .putString(KEY_RESULT, resultPath)
            .apply()
    }

    private fun finishError(msg: String) {
        prefs.edit()
            .putBoolean(KEY_RUNNING, false)
            .putString(KEY_PHASE, "error")
            .putString(KEY_STATUS, "error:$msg")
            .apply()
    }

    private fun finishCancelled() {
        prefs.edit()
            .putBoolean(KEY_RUNNING, false)
            .putString(KEY_PHASE, "cancelled")
            .putString(KEY_STATUS, "cancelled")
            .apply()
    }

    private fun bail() { releaseWake(); stopForeground(true); stopSelf() }

    private fun releaseWake() {
        if (wakeLock?.isHeld == true) wakeLock?.release()
    }

    // ── Polling helpers ───────────────────────────────────────────────────────

    private fun findRun(afterMs: Long, workflow: String): Long? {
        repeat(40) { attempt ->
            Thread.sleep(3_000)
            if (cancelFlag.get()) return null
            val body = workerGet("/find-run?after=$afterMs&workflow=$workflow") ?: run {
                log("Waiting for engine node… (${(attempt + 1) * 3}s)")
                return@repeat
            }
            val json = JSONObject(body)
            if (json.optBoolean("found")) {
                log("Engine node ready")
                return json.getLong("run_id")
            }
            log("Waiting for engine node… (${(attempt + 1) * 3}s)")
        }
        return null
    }

    private fun pollUntilDone(runId: Long, maxActivePolls: Int = 120): Boolean {
        var lastStep = ""
        var sameCount = 0
        var activePolls = 0
        var consecutiveNetFails = 0

        while (activePolls < maxActivePolls) {
            Thread.sleep(5_000)
            if (cancelFlag.get()) return false

            val elapsed    = activePolls * 5
            val elapsedStr = if (elapsed >= 60) "${elapsed / 60}m ${elapsed % 60}s" else "${elapsed}s"

            val liveBody = workerGet("/job-live?run_id=$runId")
            var gotLive = false
            if (liveBody != null) {
                try {
                    val lj   = JSONObject(liveBody)
                    val step = lj.optString("current_step", "")
                    val done = lj.optInt("completed_count", 0)
                    val tot  = lj.optInt("total_steps", 0)
                    if (step.isNotEmpty()) {
                        gotLive = true
                        val friendly = friendlyStepName(step)
                        if (step != lastStep) {
                            val pct = if (tot > 0) " ($done/$tot)" else ""
                            log("⚙ $friendly$pct")
                            updatePhase(friendly)
                            lastStep = step
                            sameCount = 0
                        } else {
                            sameCount++
                            if (sameCount % 2 == 0) {
                                log("   ⏳ $friendly — $elapsedStr")
                                updatePhase("$friendly ($elapsedStr)")
                            }
                        }
                    }
                } catch (_: Exception) {}
            }

            val statusBody = workerGet("/status?run_id=$runId")
            if (statusBody == null) {
                consecutiveNetFails++
                if (!gotLive) {
                    log("   ⚠ Network unavailable — retrying… ($consecutiveNetFails)")
                    updatePhase("Waiting for network…")
                }
                continue  // don't count network failures as a poll
            }
            consecutiveNetFails = 0
            activePolls++

            if (!gotLive) log("   ⏳ building… $elapsedStr")

            val sj = JSONObject(statusBody)
            val status     = sj.optString("status", "")
            val conclusion = sj.optString("conclusion", "")

            if (status == "completed") {
                return conclusion == "success"
            }
        }
        log("Timed out waiting for cloud engine.")
        return false
    }

    private fun friendlyStepName(step: String): String = when {
        step.contains("Set up job",      ignoreCase = true) -> "Preparing environment…"
        step.contains("Download",        ignoreCase = true) -> "Downloading game file…"
        step.contains("Extract",         ignoreCase = true) -> "Extracting binaries…"
        step.contains("Install",         ignoreCase = true) -> "Installing build tools…"
        step.contains("dependencies",    ignoreCase = true) -> "Installing build tools…"
        step.contains("patch",           ignoreCase = true) -> "Patching binary…"
        step.contains("sign",            ignoreCase = true) -> "Signing APK…"
        step.contains("upload",          ignoreCase = true) -> "Packaging output…"
        step.contains("Complete job",    ignoreCase = true) -> "Finalising…"
        step.contains("Queued",          ignoreCase = true) -> "Waiting for build node…"
        step.contains("analysis",        ignoreCase = true) -> "Analysing symbols…"
        step.contains("dump",            ignoreCase = true) -> "Dumping IL2CPP metadata…"
        step.contains("extract",         ignoreCase = true) -> "Extracting binaries…"
        else -> step
    }

    // ── IL2CPP slim-zip extractor ─────────────────────────────────────────────
    // Reads the game APK, pulls out ONLY libil2cpp.so + global-metadata.dat,
    // writes them into a tiny zip at cacheDir — far smaller than the full APK.
    private fun extractIl2cppZip(apkPath: String): File? {
        return try {
            val outFile = File(cacheDir, "il2cpp_slim_${System.currentTimeMillis()}.zip")
            ZipFile(apkPath).use { apk ->
                val entries = apk.entries().toList()

                // Prefer arm64-v8a, fall back to armeabi-v7a
                val soEntry = entries.firstOrNull { it.name.contains("arm64-v8a/libil2cpp.so") }
                    ?: entries.firstOrNull { it.name.contains("libil2cpp.so") }

                val metaEntry = entries.firstOrNull { it.name.contains("global-metadata.dat") }

                if (soEntry == null || metaEntry == null) return null

                ZipOutputStream(FileOutputStream(outFile)).use { zos ->
                    // Write libil2cpp.so flat at root of zip
                    zos.putNextEntry(ZipEntry("libil2cpp.so"))
                    apk.getInputStream(soEntry).use { it.copyTo(zos) }
                    zos.closeEntry()

                    // Write global-metadata.dat flat at root of zip
                    zos.putNextEntry(ZipEntry("global-metadata.dat"))
                    apk.getInputStream(metaEntry).use { it.copyTo(zos) }
                    zos.closeEntry()
                }
            }
            if (outFile.exists() && outFile.length() > 0) outFile else null
        } catch (_: Exception) { null }
    }

    // ── Network helpers ───────────────────────────────────────────────────────

    /**
     * Blocks the calling thread until a real internet connection is confirmed
     * or the cancel flag is set.  Checks every 5 s and logs every 3 attempts.
     */
    private fun waitForNetwork(context: String) {
        var attempt = 0
        while (!cancelFlag.get()) {
            val ok = try {
                val conn = (java.net.URL("https://www.google.com/generate_204")
                    .openConnection() as HttpURLConnection).apply {
                    connectTimeout = 5_000; readTimeout = 5_000
                    instanceFollowRedirects = false
                }
                val code = conn.responseCode
                conn.disconnect()
                code in 200..299 || code == 204
            } catch (_: Exception) { false }

            if (ok) return

            attempt++
            if (attempt % 3 == 1) log("No network — waiting to resume ($context)…")
            Thread.sleep(5_000)
        }
    }

    // ── HTTP helpers — every call retries forever until success or cancel ──────

    private fun workerGet(path: String): String? {
        var attempt = 0
        while (!cancelFlag.get()) {
            try {
                val conn = (URL(WORKER + path).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15_000; readTimeout = 30_000
                }
                val code = conn.responseCode
                val body = try { conn.inputStream.bufferedReader().readText() } catch (_: Exception) { null }
                conn.disconnect()
                if (code in 200..299) return body
            } catch (_: Exception) {}
            if (cancelFlag.get()) return null
            attempt++
            if (attempt % 2 == 1) log("Network unavailable — retrying… ($attempt)")
            waitForNetwork("GET")
            Thread.sleep(3_000)
        }
        return null
    }

    /**
     * Upload a binary file with full retry.
     * On each retry the file is re-read from the start — no partial resume.
     */
    private fun workerPost(path: String, file: File): String? {
        var attempt = 0
        while (!cancelFlag.get()) {
            try {
                val total = file.length()
                val conn = (URL(WORKER + path).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    setRequestProperty("Content-Type", "application/octet-stream")
                    setRequestProperty("Content-Length", total.toString())
                    connectTimeout = 30_000; readTimeout = 600_000
                    doOutput = true
                    setFixedLengthStreamingMode(total)
                }
                val buf = ByteArray(65_536)
                var sent = 0L
                var lastPct = -1
                updateProgress(0)
                file.inputStream().use { inp ->
                    conn.outputStream.use { out ->
                        var n: Int
                        while (inp.read(buf).also { n = it } != -1) {
                            out.write(buf, 0, n)
                            sent += n
                            val pct = if (total > 0) ((sent * 100L) / total).toInt() else 0
                            if (pct != lastPct) { lastPct = pct; updateProgress(pct) }
                        }
                    }
                }
                updateProgress(100)
                val code = conn.responseCode
                val body = try { conn.inputStream.bufferedReader().readText() } catch (_: Exception) { null }
                conn.disconnect()
                if (code in 200..299) return body
            } catch (_: Exception) {}
            if (cancelFlag.get()) return null
            attempt++
            log("Upload interrupted — waiting for network, retry $attempt…")
            updateProgress(-1)
            waitForNetwork("upload")
            Thread.sleep(4_000)
        }
        return null
    }

    private fun workerPostJson(path: String, json: String): String? {
        val bytes = json.toByteArray(Charsets.UTF_8)
        var attempt = 0
        while (!cancelFlag.get()) {
            try {
                val conn = (URL(WORKER + path).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Content-Length", bytes.size.toString())
                    connectTimeout = 15_000; readTimeout = 30_000
                    doOutput = true
                }
                conn.outputStream.write(bytes)
                val code = conn.responseCode
                val body = try { conn.inputStream.bufferedReader().readText() } catch (_: Exception) { null }
                conn.disconnect()
                if (code in 200..299) return body
            } catch (_: Exception) {}
            if (cancelFlag.get()) return null
            attempt++
            waitForNetwork("dispatch")
            Thread.sleep(3_000)
        }
        return null
    }

    /**
     * Download a file with full retry.
     * Deletes any partial file before each attempt so the output is always clean.
     */
    private fun workerDownloadToFile(path: String, outFile: File): Boolean {
        var attempt = 0
        while (!cancelFlag.get()) {
            outFile.delete() // remove any partial bytes from previous attempt
            try {
                val conn = (URL(WORKER + path).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 30_000; readTimeout = 300_000
                }
                val code = conn.responseCode
                if (code !in 200..299) { conn.disconnect(); return false }
                val total = conn.contentLengthLong
                val buf = ByteArray(32_768)
                var received = 0L
                var lastPct = -1
                updateProgress(0)
                conn.inputStream.use { inp ->
                    FileOutputStream(outFile).use { out ->
                        var n: Int
                        while (inp.read(buf).also { n = it } != -1) {
                            if (cancelFlag.get()) return false
                            out.write(buf, 0, n)
                            received += n
                            if (total > 0) {
                                val pct = ((received * 100L) / total).toInt()
                                if (pct != lastPct) { lastPct = pct; updateProgress(pct) }
                            }
                        }
                    }
                }
                updateProgress(100)
                conn.disconnect()
                if (outFile.exists() && outFile.length() > 0) return true
            } catch (_: Exception) {}
            if (cancelFlag.get()) return false
            attempt++
            log("Download interrupted — waiting for network, retry $attempt…")
            updateProgress(-1)
            waitForNetwork("download")
            Thread.sleep(4_000)
        }
        return false
    }

    // ── Logging ───────────────────────────────────────────────────────────────

    private val sensitivePatterns = listOf(
        Regex("https?://", RegexOption.IGNORE_CASE),
        Regex("github", RegexOption.IGNORE_CASE),
        Regex("workers\\.dev", RegexOption.IGNORE_CASE),
        Regex("cloudflare", RegexOption.IGNORE_CASE),
        Regex("Authorization", RegexOption.IGNORE_CASE),
        Regex("Bearer\\s", RegexOption.IGNORE_CASE),
        Regex("token\\s*[:=]", RegexOption.IGNORE_CASE),
        Regex("GITHUB_", RegexOption.IGNORE_CASE),
        Regex("asset_id\\s*[:=]", RegexOption.IGNORE_CASE),
        Regex("run_id\\s*[:=]", RegexOption.IGNORE_CASE),
        Regex("release_id", RegexOption.IGNORE_CASE),
        Regex("curl\\s+-", RegexOption.IGNORE_CASE),
    )

    private fun sanitiseMsg(msg: String): String? {
        return if (sensitivePatterns.any { it.containsMatchIn(msg) }) null else msg
    }

    private fun log(msg: String) {
        val safe = sanitiseMsg(msg) ?: return   // drop lines with sensitive content
        val existing = prefs.getString(KEY_LOGS, "") ?: ""
        prefs.edit()
            .putString(KEY_LOGS, (if (existing.isEmpty()) safe else "$existing\n$safe").takeLast(8000))
            .apply()
    }

    private fun updatePhase(phase: String) {
        prefs.edit().putString(KEY_PHASE, phase).apply()
    }

    private fun updateProgress(pct: Int) {
        prefs.edit().putInt(KEY_PROGRESS, pct.coerceIn(-1, 100)).apply()
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
        releaseWake()
    }
}
